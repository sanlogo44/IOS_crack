/*
 * Phantom OS - GUI Widget Base Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/widget.h"

namespace phantom::gui {

static Widget::WidgetId nextWidgetId = 1;

Widget::Widget(WidgetId id, const std::string& tag)
    : id_(id), tag_(tag) {
    if (id_ == 0) {
        id_ = nextWidgetId++;
    }
}

void Widget::setEnabled(bool enabled) {
    if (enabled) {
        flags_ = flags_ | WidgetFlags::ENABLED;
        if (state_ == WidgetState::DISABLED) {
            state_ = WidgetState::NORMAL;
        }
    } else {
        flags_ = flags_ & ~WidgetFlags::ENABLED;
        state_ = WidgetState::DISABLED;
    }
}

void Widget::addChild(WidgetPtr child) {
    if (child) {
        child->parent_ = this;
        children_.push_back(std::move(child));
    }
}

Widget* Widget::getChild(size_t index) {
    if (index >= children_.size()) return nullptr;
    return children_[index].get();
}

const Widget* Widget::getChild(size_t index) const {
    if (index >= children_.size()) return nullptr;
    return children_[index].get();
}

std::vector<Widget*> Widget::getChildren() {
    std::vector<Widget*> result;
    result.reserve(children_.size());
    for (auto& c : children_) {
        result.push_back(c.get());
    }
    return result;
}

std::vector<const Widget*> Widget::getChildren() const {
    std::vector<const Widget*> result;
    result.reserve(children_.size());
    for (auto& c : children_) {
        result.push_back(c.get());
    }
    return result;
}

Size Widget::onMeasure() const {
    return preferredSize_;
}

void Widget::performClick() {
    if (!isClickable() || !isEnabled()) return;
    if (onClick_) {
        onClick_(this);
    }
}

}  // namespace phantom::gui
