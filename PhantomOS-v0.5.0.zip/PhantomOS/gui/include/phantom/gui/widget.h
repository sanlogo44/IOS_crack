/*
 * Phantom OS - GUI Widget Base
 * Base class for all UI widgets
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/geometry.h"
#include "phantom/gui/bitmap_font.h"
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include <functional>

namespace phantom::gui {

class Widget;
using WidgetPtr = std::unique_ptr<Widget>;

enum class WidgetVisibility {
    VISIBLE = 0,
    HIDDEN = 1,
    GONE = 2,  // hidden + no layout space
};

enum class WidgetState {
    NORMAL = 0,
    PRESSED = 1,
    FOCUSED = 2,
    DISABLED = 3,
};

// Widget flags
enum class WidgetFlags : uint32_t {
    NONE = 0,
    CLICKABLE = 1 << 0,
    FOCUSABLE = 1 << 1,
    ENABLED = 1 << 2,
    VISIBLE = 1 << 3,
};

inline WidgetFlags operator|(WidgetFlags a, WidgetFlags b) {
    return static_cast<WidgetFlags>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}

inline WidgetFlags operator&(WidgetFlags a, WidgetFlags b) {
    return static_cast<WidgetFlags>(static_cast<uint32_t>(a) & static_cast<uint32_t>(b));
}

inline WidgetFlags operator~(WidgetFlags a) {
    return static_cast<WidgetFlags>(~static_cast<uint32_t>(a));
}

inline bool hasWidgetFlag(WidgetFlags flags, WidgetFlags test) {
    return (static_cast<uint32_t>(flags) & static_cast<uint32_t>(test)) != 0;
}

class Widget {
public:
    using WidgetId = uint32_t;

    Widget() = default;
    Widget(WidgetId id, const std::string& tag = "");
    virtual ~Widget() = default;

    // Identity
    WidgetId getId() const { return id_; }
    const std::string& getTag() const { return tag_; }
    void setTag(const std::string& tag) { tag_ = tag; }

    // Layout bounds
    Rect getBounds() const { return bounds_; }
    void setBounds(const Rect& bounds) { bounds_ = bounds; }
    Point getPosition() const { return Point(bounds_.x, bounds_.y); }
    void setPosition(int32_t x, int32_t y) { bounds_.x = x; bounds_.y = y; }
    Size getSize() const { return bounds_.size(); }
    void setSize(int32_t w, int32_t h) { bounds_.width = w; bounds_.height = h; }

    // Visibility
    WidgetVisibility getVisibility() const { return visibility_; }
    void setVisibility(WidgetVisibility v) { visibility_ = v; }
    bool isVisible() const { return visibility_ == WidgetVisibility::VISIBLE; }
    bool isGone() const { return visibility_ == WidgetVisibility::GONE; }

    // State
    WidgetState getState() const { return state_; }
    void setState(WidgetState s) { state_ = s; }

    // Flags
    WidgetFlags getFlags() const { return flags_; }
    void setFlags(WidgetFlags f) { flags_ = f; }
    bool isClickable() const { return hasWidgetFlag(flags_, WidgetFlags::CLICKABLE); }
    bool isFocusable() const { return hasWidgetFlag(flags_, WidgetFlags::FOCUSABLE); }
    bool isEnabled() const { return hasWidgetFlag(flags_, WidgetFlags::ENABLED); }
    void setEnabled(bool enabled);

    // Padding
    struct Padding {
        int32_t left = 0;
        int32_t top = 0;
        int32_t right = 0;
        int32_t bottom = 0;
    };

    Padding getPadding() const { return padding_; }
    void setPadding(int32_t l, int32_t t, int32_t r, int32_t b) { padding_ = {l, t, r, b}; }
    void setPadding(int32_t all) { padding_ = {all, all, all, all}; }

    // Preferred size (computed by layout)
    Size getPreferredSize() const { return preferredSize_; }
    void setPreferredSize(int32_t w, int32_t h) { preferredSize_ = Size(w, h); }

    // Children (for container widgets)
    void addChild(WidgetPtr child);
    Widget* getChild(size_t index);
    const Widget* getChild(size_t index) const;
    size_t getChildCount() const { return children_.size(); }
    std::vector<Widget*> getChildren();
    std::vector<const Widget*> getChildren() const;

    // Parent
    Widget* getParent() { return parent_; }
    const Widget* getParent() const { return parent_; }

    // Hit testing
    bool containsPoint(int32_t x, int32_t y) const { return bounds_.contains(x, y); }

    // Virtual: measure preferred size (default: use preferredSize_)
    virtual Size onMeasure() const;

    // Virtual: layout children (default: no-op)
    virtual void onLayout() {}

    // Virtual: render widget into framebuffer
    virtual void onRender(Framebuffer& fb, const BitmapFont& font) const {}

    // Virtual: handle touch event
    virtual bool onTouchDown(int32_t x, int32_t y) { return false; }
    virtual bool onTouchUp(int32_t x, int32_t y) { return false; }
    virtual bool onTouchMove(int32_t x, int32_t y) { return false; }

    // Click callback
    using ClickCallback = std::function<void(Widget*)>;
    void setOnClick(const ClickCallback& cb) { onClick_ = cb; }

    // Invoke click (triggers callback if clickable and enabled)
    void performClick();

protected:
    WidgetId id_ = 0;
    std::string tag_;
    Rect bounds_;
    WidgetVisibility visibility_ = WidgetVisibility::VISIBLE;
    WidgetState state_ = WidgetState::NORMAL;
    WidgetFlags flags_ = WidgetFlags::VISIBLE | WidgetFlags::ENABLED;
    Padding padding_;
    Size preferredSize_ = Size(0, 0);

    std::vector<WidgetPtr> children_;
    Widget* parent_ = nullptr;
    ClickCallback onClick_;
};

}  // namespace phantom::gui
