# Phantom OS

**Sichere, datenschutzorientierte Android-basierte Plattform — Für iPhone X (A11 SoC)**

**Version:** 0.38.0 — Storage Manager
**Lizenz:** GPL-3.0  
**Status:** Framework-Prototyp mit GUI-Widget-Toolkit, Layout-System, Text-Rendering, Konfiguration, Lokalisierung, URI-Schema, App-Sandbox, erweiterten Widgets, Animation System, Theme System, App Lifecycle Manager, IPC Message Bus, Package Manager, Linux Compatibility Layer, Settings App Prototyp, Terminal App Prototyp, File Manager Prototyp, System Monitor Prototyp, Network Intrusion Detection System, System Server / Init Process, Device Driver Framework, Logging & Telemetry Server, Notification Manager, Crash Reporter, Update Manager, Backup & Restore Manager, Recovery Mode Manager, KeyStore / Crypto Service, Device Lock / Authentication Manager, Network / Connectivity Manager, Power Manager und Clipboard Manager, Location Manager, Sensor Manager, Camera Manager, Audio Manager, Telephony Manager, Bluetooth Manager, Display Manager, NFC Manager, Vibrator Manager, USB Manager, Storage Manager  
**Entwicklungsphase:** Phase 0 abgeschlossen, Phase 1 (AOSP Setup) BLOCKIERT

---

## Was ist Phantom OS?

Phantom OS ist ein Android-basiertes Betriebssystem, das mit maximaler Datenschutz-Sicherheit, minimaler Telemetrie und kompletter lokaler Kontrolle entwickelt wird. Das Projekt zielt darauf ab, eine funktionsfähige Android-Plattform auf einem iPhone X (A11 SoC) bereitzustellen — unter Einhaltung der Android Compatibility Definition Document (CDD) und der GPL-3.0-Lizenz.

## Aktueller Status (v0.32.0)

### Abgeschlossen:
- Vollständige Systemarchitektur (21 Sektionen)
- Threat Model und Privacy-Architektur
- iPhone X Hardware-Analyse mit Status-Markern
- Framework: Service Manager (Lifecycle, Priority, Health-Check)
- Privacy Layer: Permission Manager (Default-Deny, 15 Berechtigungen, 5 Grant-Typen)
- Privacy Layer: Identity Manager (App-spezifische IDs, Hardware-ID-Schutz)
- Privacy Layer: Data Sanitizer (Location-Approximation, Metadaten-Entfernung)
- HAL: Interfaces für alle Hardware-Komponenten
- HAL: Mock-Implementierungen (iPhone X Simulation)
- Mock Runtime: Demonstriert Framework + Privacy + HAL
- GUI: Geometry, Color, Framebuffer, Surface, Window, WindowManager, Compositor, InputDispatcher
- GUI: Bitmap Font (5x7, ASCII 32-126, Text-Rendering, Clipping)
- GUI: Widget Toolkit (Label, Button, TextField, ListView)
- GUI: Layout-System (LinearLayout vertikal/horizontal, FrameLayout, Gravity, Padding)
- GUI: Erweiterte Widgets (CheckBox, RadioButton mit Group-Support, ProgressBar, Slider)
- GUI: Multi-Line-Text-Rendering (Word-Wrapping, Alignment, TextLine-Struktur)
- GUI: Erweiterte Layouts (RelativeLayout, GridLayout mit Spans)
- GUI: Animation System (Easing Functions, ValueAnimator, PropertyAnimator, Transition, AnimationManager)
- System: Property-Based Configuration (Key-Value, Typed Access, .properties Format)
- System: Lokalisierung (Deutsch/Englisch, 50+ Übersetzungen, Fallback)
- System: Custom URI Scheme (phapp://, Parser, Query-Params, Percent-Encoding)
- System: App Sandbox (Policy-Modell, 4 Profile, Syscall-Rules, File-Access, Capabilities)
- Framework: App Lifecycle Manager (7 States, Lifecycle Callbacks, State History, Start/Pause/Resume/Stop/Destroy)
- System: IPC Message Bus (Endpoint Registration, Send/Broadcast/Round-Robin, Message Types, Delivery Callbacks, Statistics)
- System: Package Manager (Local Repository, Manifest-Based Install/Uninstall/Update, Semantic Versioning, Dependency Resolution, Topological Sort, Cycle Detection, Sandbox Profiles, App Lifecycle Integration)
- System: Linux Compatibility Layer (Simulated Program Execution, Kali/Arch/CSI-Linux Support, Distro Profiles, Package Format Mapping, Process Management, State Callbacks, Package Integration)
- App: Settings App Prototyp (5 Panels, Display/Privacy/Network/Storage/About, HAL-Integration, Config-Integration, Theme-Integration, Privacy-Integration, Widget Tree, Framebuffer Rendering, Touch Handling, State Change Callbacks)
- System: Notification Manager (Channels, DND, Grouping, Privacy, Badges, 7 States, 6 Priorities, 13 Categories, Queue, Expiry, Snooze, Stats, Callbacks)
- System: Crash Reporter (Crash Capture, Deduplication via FNV-1a Hash, Crash Groups, Privacy Scrubbing: Email/Path/IP/Address/UUID/Username, Rate Limiting, Retry with Exponential Backoff, Upload Queue, Archive, Stats, LogServer Integration, 4 Privacy Levels, 13 Crash Types, 4 Severities, 8 States)
- System: Update Manager (Update Checking, Semantic Versioning, Download Queue, Pause/Resume/Cancel, Checksum Verification Model, Signature Verification, Staged Installation, Rollback Points, Auto-Rollback, Maintenance Windows, Critical Bypass, 6 Update Types, 15 States, 4 Channels, 4 Priorities, 4 Policies, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Backup & Restore Manager (Backup Creation, Incremental Backups, Checksum Verification, Restore Planning, Restore Execution, Dry-Run Restore, Retention Policy, Auto-Pruning, Privacy Scrubbing, Encryption Support, Scheduling, 6 Backup Types, 10 Backup States, 4 Destinations, 4 Privacy Levels, 4 Restore Modes, 19 Result Codes, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Recovery Mode Manager (Session Management, Action Queue, System Verification, Update Rollback, Backup Restore, Cache Wipe, Factory Reset, Filesystem Repair, Diagnostic Scans, Recovery Reports, 7 Recovery Modes, 11 Recovery States, 8 Recovery Actions, 8 Boot Reasons, 6 Diagnostic Statuses, 4 Diagnostic Severities, 22 Result Codes, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: KeyStore / Crypto Service (Key Generation, Key Import, Key Derivation, Key Management, Access Control, Encryption, Decryption, Signing, Verification, Key Wrapping, Key Unwrapping, Attestation, Certificates, Backup Hooks, 8 Key Types, 8 Key Purposes, 7 Key States, 4 Storage Backends, 8 Crypto Algorithms, 4 Security Levels, 4 Access Scopes, 4 Certificate States, 25 Result Codes, Stats, History, Callbacks, LogServer/CrashReporter Integration)
- System: Device Lock / Authentication Manager (Credential Enrollment, Device Lock, Authentication, Rate Limiting/Lockout, Sessions, Recovery Keys, 6 Auth Methods, 7 Lock States, 20 Auth Result Codes, Stats, Events, Callbacks, LogServer/CrashReporter Integration)
- System: Network / Connectivity Manager (Radio Control, Flugmodus, Scanning, Profile, Connections, Captive Portal, Limited, Roaming, Metered/Data Usage, Policies, App Network Access, MAC-Randomisierung, DNS Privacy, NIDS Integration, 5 Network Types, 9 Network States, 16 Result Codes, Stats, Events, Callbacks, LogServer/CrashReporter/NIDS Integration)
- System: Power Manager (Battery Management, Schwellwerte mit Hysterese, Auto Power Saver, Manueller Override, Wake Locks mit Timeout und Expiry, Suspend/Resume, Hibernate, Shutdown, Reboot, Thermal Management mit Throttling und erzwungenem Power-Off, Policy Queries, Restzeit-Schaetzung, 7 Battery States, 5 Power Sources, 4 Power Modes, 7 System Power States, 13 Result Codes, Stats, Events, Callbacks, LogServer/CrashReporter Integration)
- System: Clipboard Manager (8 Clipboard Data Types, 6 Clip States, 5 Expiry Policies, 4 Paste Grant Types, 15 Result Codes, 14 Event Types, Privacy-Flags, Sensitive-Erkennung, Cross-App-Confirmation, Paste-Grants mit Einmalverbrauch, Sensitive-Redaction, Expiry via Zeitinjektion, Pinning, History mit Kapazitaet und Trim, Metadaten-Peek, Stats, Events, Callbacks, LogServer/CrashReporter Integration)
- System: Location Manager (5 Location Providers, 6 Provider States, 5 Location Accuracy Levels, 4 Location Permissions, 4 Request States, 3 Geofence Transitions, 15 Result Codes, 17 Event Types, Privacy-Flag-Bitmaske, Provider Management, Per-App Location Policy mit ALLOW_ONCE, Location Updates mit Mock-Override, Privacy Transform mit Grid-Snapping, getLastKnownLocation, requestSingleLocation, Continuous Updates mit Distance/Interval-Filter, Geofencing, History, Mock Location, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Sensor Manager (10 Sensor Types, 6 Sensor States, 5 Accuracy Levels, 4 Permissions, 4 Request States, 3 Privacy Modes, 15 Result Codes, 17 Event Types, Privacy-Flag-Bitmaske, Sensor Management mit Capabilities, Per-App Sensor Policy mit ALLOW_ONCE und Rate Limiting, Sensor Updates mit Mock-Override, getLastReading, requestSingleReading, Continuous Updates mit Batching/Flush, History, Mock Sensor, Privacy Transform, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Camera Manager (5 Cameras: Front/Rear/Depth/IR/Mock, 7 Camera States, 3 Facing Modes, 4 Permissions, 4 Request States, 3 Privacy Modes, 4 Capture Modes, 15 Result Codes, 17 Event Types, 9 Privacy-Flags, Session-Lifecycle mit Open/Close/Expiry/Capacity, Single/Burst-Capture mit Rate-Limiting, getLastFrame, requestSingleCapture, Mock-Kamera, Privacy-Transform mit Blur/Redact/Metadata-Only, Privacy-Indicator, History, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Audio Manager (6 Audio Devices: Built-in Mic/Speaker/Receiver/Wired Headset/Bluetooth/Mock, 7 Audio States, 5 Routes, 4 Permissions, 4 Request States, 3 Privacy Modes, 4 Capture Modes, 15 Result Codes, 17 Event Types, 9 Privacy-Flags, Audio-Routing mit Route/Mute/Volume, Session-Lifecycle mit Open/Close/Pause/Resume/Expiry/Capacity, Capture mit Rate-Limiting, getLastFrame, requestSingleCapture, Mock-Audio, Privacy-Transform mit Mute/Low-Sample-Rate/Redact/Metadata-Only, Privacy-Indicator (nur Input-Geraete), History, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Telephony Manager (2 SIM-Slots, 9 Radio Techs, 6 Sim States, 6 Network Reg States, 4 Data Conn States, 6 Call States, 5 SMS States, 4 Permissions, 3 Privacy Modes, 15 Result Codes, 18 Event Types, 9 Privacy-Flags, SIM/Subscription-Management, Cell Identity/Signal, Per-App Policy mit ALLOW_ONCE, Privacy-Transform mit Redact/Pseudonymize/Coarse-Cell/Metadata-Only/Disable-Roaming, Call-Stubs, SMS-Stubs, Identifier Access, Mock SIM/Cell/Signal, Privacy-Indicator, History, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: Bluetooth Manager (5 Adapter States, 3 Scan Modes, 4 Device Types, 6 Device States, 4 Bond States, 12 Profile Types, 4 Permissions, 3 Privacy Modes, 17 Result Codes, 16 Event Types, 8 Privacy-Flags, Adapter Control, Scanning mit Mock-Results, Device Management, Pairing/Bonding, Connection Management, Profile Management, Per-App Policy mit ALLOW_ONCE, Identifier Access, Privacy-Transform mit Redact/Pseudonymize/Metadata-Only, Mock Devices, Privacy-Indicator, History, Events, Stats, Callbacks, LogServer/CrashReporter Integration)
- System: USB / Lightning Manager (5 Port States, 7 USB Modes, 3 USB Roles, 9 Device Classes, 2 Transfer Directions, 5 Transfer States, 4 Permissions, 3 Privacy Modes, 14 USB Result Codes, 15 USB Event Types, 8 Privacy-Flags, Port Control, Mode/Role Management, Device Management, Transfer Management, Debugging Control, Per-App Policy mit ALLOW_ONCE-Einmalverbrauch, Privacy Transform mit Redact/Pseudonymize/Metadata-Only, Mock Devices, Privacy-Indicator, History, Events, Stats, Callbacks, Failure Simulation, Zeitinjektion, LogServer/CrashReporter Integration)
- System: Storage Manager (5 Volume Types (INTERNAL, EXTERNAL, USB, CACHE, APP_PRIVATE), 6 Volume States (UNMOUNTED, MOUNTING, MOUNTED, READ_ONLY, CHECKING, ERROR_STATE), 6 File Types (UNKNOWN, FILE, DIRECTORY, SYMLINK, DEVICE, SOCKET), 4 Access Modes (READ, WRITE, READ_WRITE, APPEND), 4 Permissions (DENY, ALLOW_FOREGROUND, ALLOW_ALWAYS, ALLOW_ONCE), 3 Privacy Modes (FULL, REDACTED, METADATA_ONLY), 8 Privacy-Flags (REQUIRE_FOREGROUND, NO_HISTORY, REDACT_PATHS, PSEUDONYMIZE, METADATA_ONLY, MOCK_ALLOWED, INDICATOR_REQUIRED, ENCRYPTION_REQUIRED), 7 Filesystem Types (UNKNOWN, EXT4, F2FS, FAT32, EXFAT, TMPFS, OVERLAY), 16 Storage Result Codes, 15 Storage Event Types, 7 Operation Types, Volume Management (mount/unmount/check/format), Storage Stats (total/free/used/cache/quota), File Operations (create/delete/rename/list/setReadOnly), Per-App Policy mit ALLOW_ONCE-Einmalverbrauch, Privacy Transform with Redact/Pseudonymize/Metadata-Only, Mock Volumes/Files, Privacy-Indicator, History, Events, Stats, Callbacks, Failure Simulation, Zeitinjektion, LogServer/CrashReporter Integration)
- CMake Build-System
- 56 C++ Test-Suiten (193 neue Testfälle in v0.38.0, alle PASS)
- 10 Python-Projektstruktur-Tests (alle PASS)

### Blockiert:
- AOSP Source Setup (benötigt 64GB RAM, 400GB Disk)
- Physische Hardware-Tests (iPhone X Testgerät erforderlich)

## Schnellstart

```bash
# 1. Build
cd PhantomOS
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j$(nproc)

# 2. Tests ausführen
ctest --output-on-failure

# 3. Mock Runtime starten
./bin/phantom_mock_runtime

# 4. Projektstruktur validieren
python3 ../tools/validate_project.py
python3 ../tests/test_project_structure.py
```

## Projektstruktur

```
PhantomOS/
├── android/              # AOSP Source (leer — Phase 1)
├── boot/                 # Bootloader und Boot ROM Exploit (leer)
├── kernel/               # ARM64 Kernel Source (leer — Phase 3)
├── hal/                  # Hardware Abstraction Layer
│   ├── include/phantom/hal/   # HAL Interfaces
│   └── mock/                 # Mock-Implementierungen
├── framework/            # Phantom OS Framework
│   ├── include/phantom/      # Service Manager, App Lifecycle Manager
│   └── src/                  # Implementierung
├── libraries/
│   ├── privacy/          # Privacy Layer
│   │   ├── include/phantom/privacy/  # Permission, Identity, Data Sanitizer
│   │   └── src/                       # Implementierung
│   ├── config/           # Konfigurationssystem
│   │   ├── include/phantom/config/   # Property-Based Config
│   │   └── src/                        # Implementierung
│   ├── i18n/             # Lokalisierung
│   │   ├── include/phantom/i18n/      # Localization
│   │   └── src/                        # Implementierung
│   ├── uri/              # URI-Schema
│   │   ├── include/phantom/uri/       # URI Parser (phapp://)
│   │   └── src/                        # Implementierung
│   ├── security/         # App Sandbox
│   │   ├── include/phantom/security/ # Sandbox Policy
│   │   └── src/                         # Implementierung
│   └── ipc/              # IPC Message Bus
│       ├── include/phantom/ipc/     # Message Types, Message Bus
│       └── src/                        # Implementierung
│   └── package_manager/  # Package Manager
│       ├── include/phantom/package_manager/  # Package Types, Package Manager
│       └── src/                              # Implementierung
│   └── linux_compat/     # Linux Compatibility Layer
│       ├── include/phantom/linux_compat/     # Linux Program Types, Program Executor
│       └── src/                              # Implementierung
├── system/               # System Runtime
│   └── src/                  # Mock Runtime
├── gui/                  # GUI Framework
│   ├── include/phantom/gui/   # Geometry, Color, Framebuffer, Font, Widgets, Layout
│   └── src/                   # Implementierung
├── apps/                 # Anwendungen
│   ├── settings/        # Settings App Prototyp (v0.10.0)
│   ├── terminal/        # Terminal App Prototyp (v0.11.0)
│   ├── filemanager/     # File Manager Prototyp (v0.12.0)
│   ├── sysmon/          # System Monitor Prototyp (v0.13.0)
├── security/           # Sicherheitskomponenten
│   └── nids/            # Network Intrusion Detection System (v0.14.0)
├── system/             # Systemdienste
│   ├── server/         # System Server / Init Process (v0.15.0)
│   ├── logging/        # Log Server / Telemetry (v0.17.0)
│   ├── notifications/  # Notification Manager (v0.18.0)
│   ├── crashreporter/  # Crash Reporter (v0.19.0)
│   ├── updatemanager/  # Update Manager (v0.20.0)
│   ├── backup/         # Backup & Restore Manager (v0.21.0)
│   ├── recovery/       # Recovery Mode Manager (v0.22.0)
│   ├── keystore/       # KeyStore / Crypto Service (v0.23.0)
│   ├── auth/           # Device Lock / Authentication Manager (v0.24.0)
│   ├── network/         # Network / Connectivity Manager (v0.25.0)
│   ├── power/           # Power Manager (v0.26.0)
│   ├── clipboard/     # Clipboard Manager (v0.27.0)
│   ├── bluetooth/     # Bluetooth Manager (v0.33.0)
│   ├── display/      # Display Manager (v0.34.0)
│   ├── nfc/          # NFC Manager (v0.35.0)
│   ├── vibrator/      # Vibrator Manager (v0.36.0)
│   ├── usb/          # USB Manager (v0.37.0)
│   ├── storage/      # Storage Manager (v0.38.0)
│   └── src/            # Mock Runtime
├── drivers/            # Hardware-Treiber
│   └── framework/      # Device Driver Framework (v0.16.0)
├── sdk/                  # Developer SDK (leer)
├── tools/                # Build- und Test-Tools
├── tests/                # Unit Tests
│   ├── unit/                 # C++ Unit Tests
│   └── test_project_structure.py  # Python Struktur-Tests
├── docs/                 # Architektur und Dokumentation
├── CMakeLists.txt        # CMake Build-System
├── README.md             # Diese Datei
├── install.md            # Installationsanleitung
├── TODO.md               # Aufgaben-Tracker
├── Erledigt.md           # Abgeschlossene Aufgaben
├── Getestet.md           # Testergebnisse
└── LICENSE               # GPL-3.0
```

## Schlüsselkomponenten

### Phantom Framework
Service Manager mit Lifecycle-Management (CREATED → STARTING → RUNNING → STOPPING → STOPPED), Prioritätsbasierter Start-Reihenfolge (CRITICAL > HIGH > NORMAL > LOW), Health-Checks und State-Change-Callbacks.

### App Lifecycle Manager (v0.7.0)
Verwaltet den kompletten Lebenszyklus von Anwendungen: 7 States (REGISTERED → STARTING → RUNNING → PAUSED → STOPPING → STOPPED → CRASHED), Lifecycle Callbacks (onCreate, onStart, onResume, onPause, onStop, onDestroy), State History Tracking, Start/Pause/Resume/Stop/Destroy Operationen, Duplicate Detection, Auto-Start Support, Stop-All mit Reverse-Priority-Order.

### Privacy Layer
- **Permission Manager:** Default-Deny mit 15 Berechtigungstypen, 5 Grant-Typen (ALLOW_ONCE, ALLOW_10_MIN, ALLOW_WHILE_USING, ALLOW_ALWAYS, DENY), zeitlich begrenzte Grants, Privacy-Profile (Normal, Privacy, Maximum, Developer, Custom), Location-Approximation (Precise → Approximate → City → Region → Country → None).
- **Identity Manager:** App-spezifische Identifikatoren (keine globalen Geräte-IDs), Hardware-ID-Schutz (IMEI, MAC, Seriennummer standardmäßig DENIED).
- **Data Sanitizer:** Metadaten-Entfernung (GPS, Geräteinfo, Kamera-Metadaten etc.), Location-Approximation auf 6 Genauigkeitsstufen.

### HAL (Hardware Abstraction Layer)
Saubere C++ Interfaces für Display, Input, Storage, Network, Sensors, Camera, Audio, Power. Mock-Implementierungen simulieren iPhone X Hardware (2436x1125 OLED, 458 DPI, 64GB NVMe, Wi-Fi 6, Bluetooth 5.0, A11 Bionic SoC).

### GUI Framework
- **Bitmap Font:** 5x7 Fixed-Width Font für ASCII 32-126, Text-Rendering mit Clipping.
- **Widget Toolkit:** Label (Textanzeige), Button (Klickbar mit Callback), TextField (Editierbar mit Cursor), ListView (Scrollbar mit Item-Callbacks).
- **Layout-System:** LinearLayout (Vertikal/Horizontal, Spacing, Gravity, Padding), FrameLayout (Stacking, Center/Fill-Gravity).

### System-Komponenten (v0.4.0)
- **Configuration:** Property-Based Key-Value Store mit Typed Access (String/Int/Bool/Float), Defaults, .properties Format laden/speichern.
- **Localization (i18n):** Deutsch/Englisch Übersetzungen, Locale-Verwaltung, Fallback-Logik, 50+ vordefinierte UI-Strings.
- **URI Scheme:** phapp:// Parser mit App-ID, Pfad, Query-Parameters, Percent-Encoding/Decoding.
- **App Sandbox:** Policy-Modell mit 4 Profilen (STRICT, NORMAL, DEVELOPER, NETWORK), Syscall-Rules, File-Access-Control, Resource-Limits, Capability-System. Seccomp-bpf als Stub (Prototype-Modus).

### IPC Message Bus (v0.7.0)
In-Process Message Bus für Inter-Process Communication: Endpoint Registration mit Owner-App und Message-Handler, Send (Direct), Broadcast (an alle aktiven Endpoints) und Round-Robin (verteilt auf alle berechtigten Endpoints), Message Types mit Payload und Key-Value Parameters, Endpoint State Management (ACTIVE/INACTIVE/BLOCKED), Allowed Types Filtering, Reply Support, Delivery Callbacks, Message Statistics (Sent/Delivered/Failed per Endpoint und Global).

### Package Manager (v0.8.0)
Lokaler manifest-basierter Package Manager für Installation, Deinstallation und Updates: Package Types (PackageVersion mit Semantic Versioning, PackageDependency mit Version Constraints und optional flag, PackageInfo, PackageManifest mit Permissions, Dependencies, Sandbox Profile und Auto-Start), Install States (AVAILABLE → INSTALLING → INSTALLED → UPDATING → REMOVING → REMOVED → FAILED), 17 Result Codes, Local Repository (addAvailablePackage, removeAvailablePackage), Manifest Validation, Install (from Manifest oder Package ID), Uninstall (Force/Purge Optionen), Update (mit Downgrade-Blocking), Dependency Checking (Version Constraints, Optional Dependencies), Batch Install mit Topological Sort und Cycle Detection, App Lifecycle Integration (Register/Unregister, Permission Transfer, Auto-Start), Query Operations (Installed Packages, Dependents, Dependencies, Available Count), State Change Callbacks.

### Settings App (v0.10.0)
Prototyp einer Settings-Anwendung mit 5 Panels (Display, Privacy, Network, Storage, About): Widget-Tree mit Navigation (5 Buttons), Display-Panel (Brightness-Slider, Dark-Mode-Checkbox), Privacy-Panel (Privacy-Profile RadioButtons, Telemetry/Crash-Reports/Analytics/Tracking CheckBoxes, Location-Accuracy-Label, Permissions-Summary), Network-Panel (Wi-Fi/Bluetooth/Cellular Status), Storage-Panel (ProgressBar, Storage-Info), About-Panel (OS-Version, Device, Battery, Display-Info). Integration mit Config (10 Properties), ThemeManager (Dark/Light Toggle), PermissionManager (Privacy-Profile Selection, Location-Accuracy), HAL (Display/Power/Storage/Network). Framebuffer-Rendering mit rekursivem Widget-Tree-Traversal. Touch-Handling mit Hit-Testing. State-Change-Callbacks. Panel-Visibility (VISIBLE/GONE).

### Terminal App (v0.11.0)
GUI Terminal-Emulator mit Linux Compatibility Layer Integration: 14 Built-in Befehle (help, ls, ps, kill, run, clear, version, uname, echo, whoami, pwd, cd, date, history), Command-Parser mit Quote-Support (doppelte und einfache Anfuehrungszeichen), Output-Buffer mit konfigurierbarem Max-Limit und automatischem Trimming, Command-History mit Up/Down-Navigation, Prompt mit Working-Directory-Anzeige und anpassbarem Prefix, Scrolling (scrollUp/scrollDown/scrollToBottom), Text-Input (insertChar/deleteChar/clearInput/submitInput), ProgramExecutor-Integration (run/ps/kill Befehle fuer registrierte Linux-Programme), Output-Callback fuer externe Listener, Widget-Tree (Output-Area mit Label, Input-Area mit Prompt + TextField), LinearLayout fuer Root/Output/Input, rekursives Framebuffer-Rendering, Touch-Handling mit Hit-Testing, Theme-Integration (Dark/Light Mode), Re-Initialisierung nach Shutdown.

### File Manager (v0.12.0)
GUI Dateimanager mit simuliertem Dateisystem und Sandbox-Integration: Simulated Filesystem (/, /home/user, /System, /var, /tmp mit Dateien und Verzeichnissen), Navigation (navigateTo mit absoluten Pfaden, navigateInto fuer Unterverzeichnisse, navigateUp, navigateBack mit History), Datei-Operationen (createFolder, deleteEntry mit NOT_EMPTY-Check, renameEntry, copyEntry), File Type Detection (.txt/.md/.log=TEXT, .cfg/.conf=CONFIG, .png/.jpg=IMAGE, .bin/.so=BINARY, .sh=EXECUTABLE), ListView fuer Dateiliste mit Item-Callbacks (Text + Click), Toolbar mit Back/Up/NewDir/Delete Buttons, Path Bar mit aktueller Pfadanzeige, Status Bar mit Verzeichnis-/Dateizaehler und Selektionsinfo, Breadcrumbs Navigation, Sandbox-Profile (default/restricted/full mit Pfad-Validierung), Operation Callbacks fuer externe Listener, Selection (setSelectedIndex, getSelectedEntry, getSelectedPath), Sorting (Directories zuerst, dann alphabetisch), rekursives Framebuffer-Rendering, Touch-Handling mit Hit-Testing, Theme-Integration (Dark/Light Mode).

### System Monitor (v0.13.0)
GUI Systemueberwachung mit HAL- und ProgramExecutor-Integration: 4 Tabs (Overview, Processes, Hardware, Network), System Info (OS-Version, Kernel, Geraet, CPU-Modell, Kerne, Frequenz, Speicher, CPU-Auslastung, Uptime, Prozessanzahl), Simulated Process List (30 Prozesse mit PID, Name, State, CPU-Auslastung, Memory), Process Management (killProcess mit Init-Schutz, refreshProcessList mit CPU-Fluktuation, Selection, Multiple Kills), Hardware Status (Display mit Aufloesung/DPI/Typ/Helligkeit, Storage mit Total/Available/Encrypted/Filesystem, Battery mit Level/Charging/Voltage/Temperature, Power State), Network Status (Wi-Fi/Bluetooth/Cellular/Interface), HAL Integration (Display/Storage/Network/Power HAL), ProgramExecutor Integration (startProgram, getRunningProcesses, terminateProcess), CPU Activity Simulation, Format Helpers (formatBytes, formatUptime, formatPercentage), Tab Navigation mit Visibility Toggle, ListView fuer Prozessliste mit Item-Callbacks, Kill Button, Update Callbacks, rekursives Framebuffer-Rendering, Touch-Handling mit Hit-Testing, Theme-Integration (Dark/Light Mode).

### Network Intrusion Detection System (v0.14.0)
Netzwerk-Intrusion-Detection-System mit Angriffserkennung und Firewall-Verwaltung: 5 Default-Detection-Rules (Port Scan, DDoS, Packet Flood, Unauthorized Access, Rate Anomaly), Custom Rule Management (Add/Remove/Enable/Disable), Connection Monitoring (Register/Update/Close/Clear), Attack Detection (Port Scan, DDoS, Packet Flood, Unauthorized Access, Rate Anomaly), Attack Simulation (simulatePortScan, simulateDdosAttack, simulatePacketFlood, simulateUnauthorizedAccess, simulateNormalTraffic), Alert Management (Get/Acknowledge/Clear, Filter by Severity), Firewall Management (Block/Unblock IP, Port Range, Active Rules, Duplicate Detection), Event Logging (Security Events, Filter by Severity), Traffic Statistics (Packets/Bytes/Connections/Alerts), Alert Callbacks, Event Callbacks, Detection Engine (runDetection with all detectors), String Helpers for all enums.

### System Server / Init Process (v0.15.0)
Zentraler Systemdienst fuer Boot-Sequenz, Service-Lifecycle und Systemzustandsverwaltung: System-State-Machine (OFF → BOOTING → INITIALIZING → RUNNING → SHUTTING_DOWN → REBOOTING → ERROR_STATE), Boot-Sequence mit 7 Phasen (PRE_INIT → INIT → CORE_SERVICES → SYSTEM_SERVICES → APP_SERVICES → POST_BOOT → COMPLETE), 14 Default-Services (4 Core: hal/config/privacy/sandbox, 4 System: ipc/pkgmgr/lifecycle/linuxcompat, 2 Network: network/nids, 4 Apps: settings/terminal/filemanager/sysmon, 1 Optional: telemetry disabled), Service-Management (Register/Unregister/Start/Stop/Restart/Enable/Disable), Dependency Resolution (Topological Sort, Circular Dependency Detection), Health Monitoring (Unknown/Healthy/Degraded/Unhealthy/Critical, Overall Health), Auto-Restart (Max-Restarts, Failed Service Check), Service Groups (CORE/SYSTEM/NETWORK/APPS/OPTIONAL), Service Types (NATIVE/HAL/DAEMON/APP/DRIVER), Boot Event Logging, System Stats (Total/Running/Failed/Disabled Services, Boot Time, Init Time, Restarts), State Change Callbacks, Service State Callbacks, Boot Event Callbacks, Priority-based Startup Order, String Helpers for all enums.

### Device Driver Framework (v0.16.0)
Zentrale Treiber-Infrastruktur fuer Hardware-Erkennung, Treiber-Lifecycle und Geraeteverwaltung: 12 Default-Treiber (Display, Power, Input, Storage, GPU, Network, Bluetooth, Audio, Camera, Sensor, USB, Thermal) mit Prioritaeten (CRITICAL/HIGH/NORMAL/LOW/OPTIONAL), 16 Default-Geraete (OLED-Display, Battery, Charger, Touchscreen, NVMe-Storage, GPU, Wi-Fi, Bluetooth, Speaker, Microphone, Front/Rear Camera, Accelerometer, Gyroscope, Proximity, USB-C, Thermal) mit Bus-Typen (INTERNAL/PCIE/I2C/SPI/UART/USB/SDIO), Treiber-Lifecycle (UNLOADED → LOADING → LOADED → INITIALIZING → ACTIVE → SUSPENDED), Geraete-Lifecycle (ABSENT → DETECTED → READY → ACTIVE → SUSPENDED), Device Binding (Driver-Device-Zuordnung, Auto-Init), Device Discovery (Hotplug-Erkennung, Auto-Detect), Dependency Resolution (Topological Sort, Circular Dependency Detection, Priority-based Load Order), Error Handling (Error Count, Last Error, Clear Errors, Set Error), Driver Events (Logging, Callbacks), Driver Stats (Total/Loaded/Active/Error Drivers, Total/Active/Error Devices, Uptime), String Helpers for all 6 enums.

### Logging & Telemetry Server (v0.17.0)
Zentraler System-Logging-Dienst fuer Protokollierung, Filterung, Log-Rotation und Telemetry-Collection: 6 Log-Levels (TRACE, DEBUG, INFO, WARN, ERROR, FATAL), 10 Log-Sources (KERNEL, DRIVER, SERVICE, APP, SECURITY, NETWORK, HAL, SYSTEM_SERVER, NIDS, FRAMEWORK), 12 Log-Categories (BOOT, SHUTDOWN, DRIVER_EVENT, SERVICE_EVENT, SECURITY_EVENT, NETWORK_EVENT, USER_ACTION, SYSTEM_ERROR, PERFORMANCE, CONFIG_CHANGE, APP_EVENT, GENERAL), Circular Buffer mit konfigurierbarer Max-Size und automatischer Rotation, Log-Filter (by Level, Source, Category, Tag, Component, Enable/Disable), Log Access (by Level, Source, Category, Tag, Component, ID, Time-Range, Recent), Log Management (Clear, Trim by Age, Min-Level), Telemetry Metrics (CPU, Memory, Disk, Network, Battery, Process Count, Uptime, Temperature, Custom) mit Privacy-Levels (FULL, ANONYMIZED, MINIMAL, DISABLED), Telemetry Snapshots (System-Metriken, Auto-Anonymization bei MINIMAL), Log Export (Text, CSV, Filtered Export, Telemetry Export), Log Callbacks und Telemetry Callbacks, Log Stats (Total Entries, Buffer Size, Entries by Level, Dropped, Exports, Active Filters, Telemetry Count), String Helpers fuer alle 6 Enums plus String-to-LogLevel Parser.

### Notification Manager (v0.18.0)
Systemweiter Notification Management Service mit Channels, DND, Grouping, Privacy und Badges: 6 Prioritaeten (MIN, LOW, DEFAULT, HIGH, MAX, NONE), 13 Kategorien (MESSAGE, CALL, EMAIL, SOCIAL, ALARM, REMINDER, ERROR, SYSTEM, SECURITY, UPDATE, TRANSPORT, MEDIA, OTHER), 6 Channel-Importance-Level (NONE, MIN, LOW, DEFAULT, HIGH, URGENT), 7 Notification-States (PENDING, ACTIVE, SNOOZED, DISMISSED, EXPIRED, CANCELLED, BLOCKED), 13 Result-Codes, App-Permission-System (Default-Allow, Block-List), Notification Channels (Create/Update/Delete/Enable/Disable, pro App isoliert, Importance, Badge, LockScreen, Vibration, Lights, Sound, DND-Override), Post/Update/Cancel/CancelAll/CancelTagged/Dismiss/Snooze/Unsnooze, Queue mit Max-Size und automatischer Rotation, Expiry-Processing (Time-based, Age-based, Ongoing-Schutz), Query (Active, History, Recent, ByApp, ByCategory, ByPriority, ByChannel, ByState, ById, GetSnoozed), Notification Groups (Create/Add/Remove, GroupKey, Summary, ChildIds, GroupAlertBehavior), Do Not Disturb (4 Modi: OFF/PRIORITY_ONLY/TOTAL_SILENCE/ALARMS_ONLY, Schedule, Suppression-Logic), Privacy Modes (SHOW_ALL, HIDE_CONTENT, REDACT, HIDE_ALL, Notification-level Override, Text-Redaction), Badge Management (Auto-Increment/Decrement, Explicit, Clear, GetAll), 6 Callbacks (Posted, Updated, Dismissed, Cancelled, Expired, Blocked), Notification Stats, String Helpers fuer alle 8 Enums plus String-to-Priority und String-to-State Parser.

### Crash Reporter (v0.19.0)
Systemweiter Crash Reporting Service: 13 Crash Types (SIGSEGV, SIGABRT, SIGFPE, SIGILL, SIGBUS, SIGPIPE, SIGTERM, SIGKILL, OOM, ANR, NATIVE_CRASH, JAVA_EXCEPTION, UNKNOWN), 4 Crash Severities (FATAL, CRITICAL, MAJOR, MINOR), 8 Crash States (CAPTURED, PROCESSING, QUEUED, UPLOADED, FAILED, RETRYING, ARCHIVED, DISMISSED), 4 Privacy Levels (FULL, ANONYMIZED, MINIMAL, DISABLED), 3 Upload Policies (NEVER, WIFI_ONLY, ALWAYS), Crash Capture (captureCrash, captureSignalCrash, captureAnr, captureOom), Stack Trace Handling (StackFrame mit Library, Function, Address, Filename, Line, Column), Deduplication via FNV-1a Hash (appId + crashType + top 5 Stack-Frames + Reason), Crash Groups (Grouping, Count, FirstSeen, LastSeen, HighestSeverity, TopFrame), Rate Limiting (Max Crashes per Hour), Queue Management (Max-Size, auto-rotation to archive), Archive Management (Max-Size, auto-rotation, Clear, ClearAll), Upload Queue (Queue, MarkUploaded, MarkUploadFailed, ProcessUploadQueue), Retry Policy (Max retries, Exponential backoff), Privacy Scrubbing (Email, Path, IP, Memory Address, Device ID/UUID, Username, All), Privacy Level Processing (FULL: no scrub, ANONYMIZED: scrub PII, MINIMAL: strip PII-heavy fields, DISABLED: no capture), Processing (processPending, processRetries, processCrash), Query (Active, Archive, Recent, ByApp, ByType, BySeverity, ByState, ByGroup, ById, Retrying), Count Operations, Export (Text, CSV, ExportAll, SaveReportToFile), 5 Callbacks (Captured, Processed, Uploaded, Failed, Archived), Crash Stats, LogServer Integration (Optional), String Helpers fuer alle 6 Enums plus Parser und Signal-to-CrashType.

### Update Manager (v0.20.0)
Systemweiter Update-Management-Service: 6 Update Types (OS, APP, SECURITY_PATCH, DRIVER, CONFIG, FIRMWARE), 15 Update States (IDLE, CHECKING, AVAILABLE, QUEUED, DOWNLOADING, PAUSED, DOWNLOADED, VERIFYING, VERIFIED, STAGED, INSTALLING, INSTALLED, FAILED, CANCELLED, ROLLED_BACK), 4 Update Channels (STABLE, BETA, NIGHTLY, SECURITY), 4 Update Priorities (LOW, NORMAL, HIGH, CRITICAL), 4 Update Policies (MANUAL, NOTIFY_ONLY, AUTO_DOWNLOAD, AUTO_INSTALL), Update Checking (simuliert, checkForUpdates), Semantic Versioning (compareVersions, isNewerVersion, Multi-Digit-Support), Download Management (Queue, Start, Pause, Resume, Cancel, Progress mit Clamping), Download Queue (Max-Size, auto-rotation), Checksum Verification Model (FNV-1a-basiert, computeChecksum, verifyChecksum), Signature Verification (verifySignature, simuliert), Staged Installation (stageUpdate, commitStagedUpdate), Rollback Points (Create, Query, Auto-Rollback bei Failure), Maintenance Windows (Enabled, Start Hour/Minute, Duration, WeekendsOnly, Critical Bypass), Schedule (Auto-Check, Interval, nextCheckTime), Channel Filtering (SECURITY immer erlaubt), Policy (MANUAL, NOTIFY_ONLY, AUTO_DOWNLOAD, AUTO_INSTALL), Privacy (Telemetry standardmäßig deaktiviert, anonyme Checks standardmäßig aktiviert), 6 Callbacks (Available, Progress, Verify, InstallComplete, InstallFailed, Rollback), Stats (Total/ByType/ByChannel/ByPriority/PerPackage, History), History (Max-Size, Clear, ClearAll), Query (ByType, ByChannel, ByPriority, ByState, Count), LogServer Integration (Optional), CrashReporter Integration (Optional), String Helpers fuer alle 6 Enums plus Parser.

### Backup & Restore Manager (v0.21.0)
Systemweiter Backup- und Restore-Management-Service: 6 Backup Types (FULL_SYSTEM, APP_DATA, SETTINGS, MEDIA, CONFIG, SECURITY_KEYS), 10 Backup States (IDLE, SCANNING, BACKING_UP, VERIFYING, COMPLETED, FAILED, CANCELLED, RESTORING, RESTORED, RESTORE_FAILED), 4 Backup Destinations (LOCAL, EXTERNAL, ENCRYPTED_ARCHIVE, CLOUD_STUB), 4 Backup Privacy Levels (FULL, ANONYMIZED, MINIMAL, DISABLED), 4 Restore Modes (FULL, SELECTIVE, MERGE, DRY_RUN), 19 Backup Result Codes, Backup Creation (createBackup, Validierung, Auto-Sizing), Incremental Backups (createIncrementalBackup, Base-Backup-Referenz), Checksum Verification (FNV-1a-basiert, computeChecksum, verifyChecksum, verifyBackup), Restore Planning (planRestore, RestorePlan mit Estimated Size/Time, Summary), Restore Execution (executeRestore, executeRestoreFromPlan, Auto-Verify vor Restore), Dry-Run Restore (Simulation ohne Aenderungen), Cancel Restore, Retention Policy (Max-Backups, Max-Age-Days, Auto-Prune, Keep-Latest-Per-Type, Min-Backups-Per-Type), Auto-Pruning (pruneBackups, getExpiredBackups, getExpiredCount), Privacy Scrubbing (ANONYMIZED: Device-ID-Anonymisierung, Pfad-Masking; MINIMAL: PII-Stripping), Encryption Support (requireEncryption, encrypted flag, encryption key reference), Scheduling (Auto-Backup, Interval, shouldAutoBackup), Progress Tracking (getBackupProgress, getActiveBackups, updateBackupProgress), History (getHistory, clearHistory, moveToHistory), Query (ByType, ByDestination, ByState, Count), 5 Callbacks (BackupComplete, BackupFailed, Progress, RestoreComplete, RestoreFailed), Stats (Total/ByType/ByDestination, BytesBackedUp/Restored, Verifications, Pruned, Cancelled), LogServer Integration (Optional), CrashReporter Integration (Optional), String Helpers fuer alle 6 Enums plus Parser.

### Recovery Mode Manager (v0.22.0)
Systemweiter Recovery- und Diagnose-Management-Service: 7 Recovery Modes (NORMAL_BOOT, SAFE_MODE, RECOVERY_SHELL, UPDATE_RECOVERY, BACKUP_RESTORE, FACTORY_RESET, DIAGNOSTIC), 11 Recovery States (IDLE, ENTERING, ACTIVE, SCANNING, REPAIRING, RESTORING, APPLYING_UPDATE, WIPING, REBOOTING, FAILED, COMPLETED), 8 Recovery Actions (VERIFY_SYSTEM, APPLY_UPDATE, ROLLBACK_UPDATE, RESTORE_BACKUP, WIPE_CACHE, FACTORY_RESET, RUN_DIAGNOSTICS, REPAIR_FILESYSTEM), 8 Boot Reasons (NORMAL, RECOVERY_REQUESTED, OTA_FAILURE, BOOT_FAILURE, SAFE_MODE_REQUESTED, KERNEL_PANIC, WATCHDOG_RESET, POWER_LOSS), 6 Diagnostic Statuses (NOT_RUN, RUNNING, PASSED, WARNINGS, FAILED, SKIPPED), 4 Diagnostic Severities (INFO, WARNING, ERROR, CRITICAL), 22 Recovery Result Codes, Session Management (enterRecovery, exitRecovery, getCurrentSession, isInRecovery), Action Queue (queueAction, cancelAction, executeNextAction, executeAllActions), Individual Recovery Operations (verifySystem, applyUpdate, rollbackUpdate, restoreBackup, wipeCache, factoryReset, repairFilesystem), Diagnostic Scans (runDiagnostics, 8 Default Checks: Filesystem/Boot/System/Cache Partition, User Data, Kernel Log, Hardware Watchdog, Memory Test), Recovery Reports (generateReport, getHistory, clearHistory), Query (ByMode, ByBootReason), Progress Tracking (getProgress), 4 Callbacks (State, Action, Progress, Complete), Stats (Total Sessions/Recoveries/FactoryResets/SafeModeBoots/DiagnosticsRun/Repairs/UpdatesApplied/Rollbacks/BackupRestores/CacheWipes/Failures, ByMode, ByBootReason, DiagnosticChecks/Failures), LogServer Integration (Optional), CrashReporter Integration (Optional), String Helpers fuer alle 7 Enums plus Parser.

### KeyStore / Crypto Service (v0.23.0)
Zentraler Kryptographie- und Schluesselverwaltungs-Service: 8 Key Types (AES_128, AES_256, RSA_2048, RSA_4096, ECDSA_P256, HMAC_SHA256, DERIVED_SECRET, RAW_SECRET), 8 Key Purposes (ENCRYPT, DECRYPT, SIGN, VERIFY, WRAP, UNWRAP, DERIVE, ATTEST), 7 Key States (ACTIVE, DISABLED, EXPIRED, REVOKED, ROTATED, DESTROYED, COMPROMISED), 4 Storage Backends (MEMORY, SECURE_STORAGE_STUB, HARDWARE_BACKED_STUB, BACKUP_BLOB), 8 Crypto Algorithms (AES_GCM_STUB, AES_CBC_STUB, RSA_OAEP_STUB, ECDSA_P256_STUB, HMAC_SHA256_STUB, PBKDF2_SHA256_STUB, HKDF_SHA256_STUB, FNV1A_MAC_STUB), 4 Security Levels (SOFTWARE, SECURE_STORAGE, HARDWARE_BACKED_STUB, SECURE_ENCLAVE_STUB), 4 Access Scopes (SYSTEM_ONLY, APP_PRIVATE, SHARED_APPS, RECOVERY_ONLY), 4 Certificate States (VALID, EXPIRED, REVOKED, UNTRUSTED), 25 KeyStore Result Codes, Key Generation (generateKey mit FNV-1a basiertem Key Material), Key Import (importKey), Key Derivation (deriveKey mit PBKDF2-SHA256 und HKDF-SHA256 Stubs), Key Management (getKeyMetadata, getKeyByAlias, listKeys, getKeysByOwner/Type/State, deleteKey, disableKey, enableKey, revokeKey, rotateKey), Access Control (grantAccess, revokeAccess, checkAccess mit Purpose Bitmask, AccessScope, Access Grants mit Expiry), Crypto Operations (encrypt/decrypt mit XOR-Keystream, sign/verify mit FNV-1a MAC, wrapKey/unwrapKey), Backup Hooks (exportKeyBlob/importKeyBlob, getRecoveryKeys, getKeysByScope), Attestation (attestKey mit Certificate Chain Stub), Certificates (createSelfSignedCertificate, importCertificate, getCertificate, getCertificatesForKey, revokeCertificate), Stats (Total Keys, Generated/Imported/Derived/Deleted/Rotated/Disabled/Revoked, Encrypt/Decrypt/Sign/Verify/Wrap/Unwrap Ops, Attestations, Certificates, Failures, ByType/Backend/State/SecurityLevel), History (getHistory, clearHistory, maxHistory), 2 Callbacks (KeyState, Crypto), Failure Simulation (failNextOperation), LogServer Integration (Optional), CrashReporter Integration (Optional), String Helpers fuer alle 9 Enums plus Parser.

### Device Lock / Authentication Manager (v0.24.0)
Zentraler Geraete-Sperre- und Authentifizierungs-Service: 6 Auth Methods (PIN, PASSWORD, PATTERN, BIOMETRIC_STUB, RECOVERY_KEY, TRUSTED_SESSION), 7 Lock States (UNCONFIGURED, UNLOCKED, LOCKED, AUTHENTICATING, TEMP_LOCKED, RECOVERY_REQUIRED, DISABLED), 20 Auth Result Codes, 3 Session States (ACTIVE, EXPIRED, REVOKED), 5 Credential States (ACTIVE, DISABLED, EXPIRED, COMPROMISED, ROTATED), 10 Auth Event Types, Credential Enrollment (enrollCredential mit Policy-Validierung: Laenge, Ziffern, Alphanumerisch, Biometrie-Freigabe), Credential Lifecycle (changeCredential mit Rotation und Versionserhoehung, removeCredential mit letzter-Credential-Schutz, disable/enable, markCredentialCompromised mit Session-Revokation), Lock Control (lockDevice, unlockDevice via Trusted Session, setLockDisabled system-only, Auto-Lock-Timeout mit shouldAutoLock), Authentication (authenticate mit FNV-1a gehashten Secrets und Salt, Use-Count, Session-Erstellung), Rate Limiting (per Owner und Methode, Failed-Attempt-Tracking, temporärer Lockout mit ablaufbarer Dauer, Reset durch System oder Erfolg, Recovery Required nach wiederholten Lockouts), Sessions (createSession bei Auth, validateSession mit Owner-Check, refreshSession, revokeSession, revokeAllSessions, processExpiredSessions, Session-Capacity mit Oldest-Eviction, 5 Minuten Default-Dauer), Recovery Keys (generateRecoveryKey im XXXX-...-Format, Rotation bei Neugenerierung, authenticateWithRecoveryKey entsperrt aus LOCKED/TEMP_LOCKED/RECOVERY_REQUIRED, eigenes Rate Limiting mit 3 Versuchen und 10 Minuten Sperre), Events (Event-Buffer mit Max-Size und Rotation, getEventsByType, clearEvents mit History), Stats (Credentials Enrolled/Removed/Rotated/Disabled, Auth Attempts/Success/Failures, Lockouts, Locks/Unlocks, Sessions Created/Revoked/Expired, Recovery Keys/Unlocks, ByMethod/ByResult/ByEventType), 2 Callbacks (LockState, AuthEvent), Failure Simulation (failNextAuth), Zeitinjektion fuer Tests (setCurrentTimeForTesting), LogServer Integration (Optional), CrashReporter Integration (Optional), String Helpers fuer alle 6 Enums plus Parser.

### Network / Connectivity Manager (v0.25.0)
Systemweiter Netzwerk- und Konnektivitaets-Service: 5 Network Types (WIFI, CELLULAR, BLUETOOTH_PAN, USB_TETHER, LOOPBACK), 9 Network States (DISABLED, DISCONNECTED, SCANNING, CONNECTING, CONNECTED, CAPTIVE_PORTAL, LIMITED, ROAMING, FAILED), 4 Security Types (OPEN, WPA2, WPA3, ENTERPRISE_STUB), 5 Network Policies (NORMAL, METERED, DATA_SAVER, PRIVACY, BLOCKED), 16 Network Result Codes, 9 Network Event Types, Radio Control (setRadioEnabled, Loopback nicht deaktivierbar, Flugmodus system-only mit automatischem Connection-Teardown), Scanning (requestScan mit deterministischen Mock-Netzwerken, FNV-1a Signalstaerke und BSSID, Altersfilter via getScanResults), Profile Management (addProfile mit FNV-1a gehashtem Passwort und per-Profil Salt, keine Klartext-Speicherung, removeProfile mit Active-Profile-Schutz, updateProfile mit Passwort-Rotation, getProfileBySsid, Kapazitaetslimit), Connection Handling (connect mit App-Access-Check, Policy-Check und Passwort-Verifikation, disconnect, reconnect, checkConnectivity), Captive Portal Detection (CAPTIVE_PORTAL State, Portal-Erkennung via checkConnectivity), Limited Networks (LIMITED State), Cellular Roaming (ROAMING State), Metered Connections (Cellular und DATA_SAVER standardgetaktet), Data Usage (updateDataUsage mit Metered-Default-Deny fuer Apps, Metered-Bytes-Tracking, resetDataUsage), Network Policies (per Network Type, system-only, METERED/DATA_SAVER/PRIVACY/BLOCKED), App Network Access (Default-Allow mit Metered-Deny als Privacy-Default, Block-List, Kapazitaetslimit), Privacy (MAC-Randomisierung pro Verbindung mit lokal administrierten Adressen, feste Geraete-MAC bei Deaktivierung, DNS Privacy, PRIVACY-Policy erzwingt beide), NIDS Integration (Connection-Registrierung bei Connect, Close bei Disconnect, Firewall-Check des Gateways mit FIREWALL_BLOCKED), Events (Ring-Buffer mit Rotation, getEvents mit Limit, getEventsByType, clearEvents mit History-Archivierung), Stats (Scans/Networks Found, Connect Attempts/Successful/Failed, Auth Failures, Disconnects, Reconnects, Captive Portals, Firewall Blocks, Bytes Rx/Tx/Metered, Profiles, Apps Blocked, ByNetworkType/ByEventType/ByResult), 2 Callbacks (ConnectionState mit Old/New, NetworkEvent), Failure Simulation (failNextConnection, One-Shot), Zeitinjektion fuer Tests (setCurrentTimeForTesting), LogServer Integration (Optional), CrashReporter Integration (Optional, ANR bei Auth-Failure), String Helpers fuer alle 6 Enums plus Parser (stringToNetworkType, stringToNetworkState, stringToNetworkResult).

### Power Manager (v0.26.0)
Zentraler Energie- und Systemzustands-Service: 7 Battery States (UNKNOWN, DISCHARGING, CHARGING, FULL, LOW, CRITICAL, NOT_PRESENT), 5 Power Sources (BATTERY, USB, AC_ADAPTER, WIRELESS_STUB, UNKNOWN), 4 Power Modes (PERFORMANCE, BALANCED, BATTERY_SAVER, EXTREME_SAVER), 7 System Power States (AWAKE, IDLE, SUSPENDING, SUSPENDED, HIBERNATING, SHUTTING_DOWN, REBOOTING), 5 Thermal States (NORMAL, WARM, HOT, CRITICAL, SHUTDOWN), 5 Wake Lock Types (PARTIAL, DISPLAY, NETWORK, CPU, FULL), 7 Wake Reasons (POWER_BUTTON, TOUCH, TIMER, NETWORK, CHARGER, ALARM, SYSTEM), 5 Charging Types (NONE, TRICKLE, STANDARD, FAST_STUB, WIRELESS_STUB), 13 Power Result Codes, 13 Power Event Types, Battery Management (Level-Tracking, Drain/Charge-Simulation mit Clamping, Schwellwerte low=20/critical=5/autoSaver=15 mit Hysterese, Low-Warning nur beim Eintritt in LOW, keine Doppelausloesung bei CRITICAL→LOW), Auto Power Saver (level<=critical→EXTREME_SAVER, entladend level<=autoSaver→BATTERY_SAVER, ladend level>autoSaver+5→BALANCED, manueller Override blockt Auto-Regeln bis Re-Aktivierung), Wake Locks (Acquire mit Owner/Tag/Type/Timeout, Duplicate-Schutz, Kapazitaetslimit, Owner-Checks mit System-Release, Freigabe aller Locks eines Owners, Expiry via Zeitinjektion, timeout 0 = nie), System Power Control (Suspend/Hibernate/Shutdown/Reboot system-only, Wake-Lock-Blockade mit force-Override, Batterie-Check bei Hibernation mit BATTERY_TOO_LOW, sofortiger Reboot-Abschluss zurueck in AWAKE), Thermal Management (Throttle 0/15/40/75/100 Prozent je Thermal State, Mode-Penalties BATTERY_SAVER 30 / EXTREME_SAVER 60, gedeckelt auf 100, CRITICAL blockt Suspend/Hibernate mit THERMAL_CRITICAL, SHUTDOWN erzwingt Power-Off ungeachtet von Wake Locks), Policy Queries (shouldRestrictBackgroundActivity, shouldRestrictNetwork nur in EXTREME_SAVER, shouldDimDisplay in beiden Saver-Modi, getCpuThrottlePercent, estimateRemainingMinutes modell-abhaengig: Performance/Balanced 3, Battery Saver 5, Extreme Saver 7 Minuten pro Prozent, ladend (100-level)*2), Events (Ring-Buffer mit Rotation, getEvents mit Limit, getEventsByType, clearEvents mit History-Archivierung), Stats (Level Changes, Low/Critical Warnings, Mode Changes, Thermal Transitions, Wake Locks Acquired/Released/Expired, Suspend/Resume/Hibernate/Shutdown/Reboot, ByBatteryState/ByPowerMode/ByEventType/ByResult), 3 Callbacks (Battery mit Old/New Level und State, PowerMode mit Old/New, PowerEvent), Failure Simulation (failNextOperation, One-Shot, geprueft vor Berechtigungschecks), Zeitinjektion fuer Tests (setCurrentTimeForTesting), LogServer Integration (Optional), CrashReporter Integration (Optional, Thermal CRITICAL/SHUTDOWN und simulierte kritische Fehlschlaege), String Helpers fuer alle 10 Enums plus Parser (stringToBatteryState, stringToPowerMode, stringToPowerResult).

### Clipboard Manager (v0.27.0)
Zentraler Clipboard-Service mit Datenschutz-Fokus: 8 Clipboard Data Types (TEXT, URL, HTML, IMAGE_STUB, FILE_LIST_STUB, RICH_TEXT_STUB, BINARY_STUB, UNKNOWN), 6 Clip States (EMPTY, ACTIVE, EXPIRED, PINNED, CLEARED, REDACTED), 5 Expiry Policies (NEVER, AFTER_TIMEOUT, AFTER_READ, ON_OWNER_EXIT, ON_SYSTEM_LOCK), 4 Paste Grant Types (NONE, ALLOW_ONCE, ALLOW_ALWAYS, DENY_ALWAYS), 15 Clipboard Result Codes, 14 Clipboard Event Types, Privacy-Flag-Bitmaske (CLIPBOARD_PRIVACY_NONE, SENSITIVE, REDACT_ON_CROSS_APP, REQUIRE_CONFIRMATION, NO_HISTORY, ENCRYPTED_STUB), Sensitive-Erkennung (case-insensitive: password=, token=, api_key, secret, 16-stellige Ziffernfolgen; setzt automatisch SENSITIVE, REDACT_ON_CROSS_APP und REQUIRE_CONFIRMATION; NEVER mit Timeout 0 erhaelt AFTER_TIMEOUT 60s als Fallback), Cross-App-Schutz (Default CONFIRMATION_REQUIRED ohne Datenleck, App-Policies mit Precedence DENY_ALWAYS/ALLOW_ALWAYS/ALLOW_ONCE mit Consumption, Paste-Grants je Source-Owner und Requester mit ALLOW_ONCE-Einmalverbrauch, DENY_ALWAYS und ALLOW_ALWAYS), Sensitive-Redaktion (Owner- und System-Reads unredigiert, nur cross-App-Reads von REDACT_ON_CROSS_APP-Clips liefern [REDACTED] mit SENSITIVE_REDACTED, Zustand REDACTED nur im Output ohne History-Mutation), Expiry Management (AFTER_TIMEOUT mit Zeitinjektion, AFTER_READ verbraucht beim ersten erfolgreichen Read ausser gepinnt, ON_OWNER_EXIT/ON_SYSTEM_LOCK system-only, expired Clips bleiben in History und sind nur mit includeExpired sichtbar), Pinning (Owner/System only, Double-Pin und Expired BAD_STATE, gepinnte Clips blockieren History-Trimming), History (newest-first, Kapazitaet mit Trim aeltester ungepinnter Nicht-Primär-Clips, alle gepinnt → CAPACITY_EXCEEDED, App sieht nur eigene Clips, System alle, NO_HISTORY-Clips landen nie in History), Metadaten-Peek ohne Datenzugriff, Clear-Operationen (clearPrimaryClip, clearOwnerClips, clearAllClips, revokePasteAccess mit korrekten NotFound/Empty-Codes), Stats (byDataType[8], byEventType[14], byResult[15], Totals inkl. clipsSet/clipsRead/readsDenied/redactions/bytesStored/bytesRead), Events (Ring-Buffer mit Rotation, getEventsByType, clearEvents), 3 Callbacks (Clip, Access, Event), Failure Simulation (failNextOperation, One-Shot, geprueft frueh in Set/Get/Clear), LogServer Integration (Optional, nur Metadaten, niemals Clipboard-Inhalte), CrashReporter Integration (Optional, captureAnr bei simulierten Fehlschlaegen), String Helpers fuer alle 6 Enums.

### Linux Compatibility Layer (v0.9.0)
Simulierte Programmausführung für Kali Linux, Arch Linux und CSI-Linux Programme: Linux Distribution Profiles (GENERIC_LINUX, KALI_LINUX, ARCH_LINUX, CSI_LINUX), Package Format Mapping (DEB für Kali, PACMAN für Arch, TAR für CSI/Generic), CPU Architecture Support (ARM64, X86_64, ARMV7), Program Types (CLI, GUI, SERVICE), Process States (REGISTERED → STARTING → RUNNING → EXITED → FAILED → TERMINATED → TIMEOUT), Program Registration (valid/duplicate/invalid/empty path), Program Execution (synchronous mit stdout/stderr capture, asynchronous mit PID allocation), Process Termination (mit state transitions), Timeout Simulation, Process Query (getProcessInfo, getRunningProcesses, getAllProcesses), Multiple Instances Support, State Change Callbacks, Package Integration (registerProgramFromPackage), Distro-Specific Query (getProgramsByDistro).

## Architektur-Dokumentation

Die vollständige Architektur-Dokumentation befindet sich unter `docs/architecture.md` mit folgenden Sektionen:

1. Overview — 2. System Architecture — 3. Kernel — 4. AOSP — 5. Android Runtime — 6. Phantom Framework — 7. Privacy Layer — 8. Security Layer — 9. Phantom HAL — 10. GUI — 11. App System — 12. Google Play — 13. Update System — 14. Hardware — 15. Data Flow — 16. Threat Model — 17. Privacy Model — 18. Development Environment — 19. Test Strategy — 20. Roadmap — 21. Risks

Weitere Dokumentation:
- `docs/privacy.md` — Datenschutz-Dokumentation
- `docs/threat-model.md` — Bedrohungsmodell
- `docs/security-architecture.md` — Sicherheitsarchitektur
- `docs/android-compatibility.md` — Android-Kompatibilität
- `docs/google-play-compatibility.md` — Google Play Assessment
- `docs/roadmap.md` — Entwicklungs-Roadmap

## Datenschutz

Phantom OS folgt dem Prinzip: **So wenig persönliche Daten wie möglich erfassen, speichern und weitergeben.**

- Keine Telemetrie standardmäßig
- Keine automatischen Absturzberichte standardmäßig
- Keine Cloud-Analyse standardmäßig
- Kein Tracking standardmäßig
- Hardware-IDs (IMEI, MAC, Seriennummer) werden standardmäßig nicht an Apps weitergegeben
- App-spezifische Identifikatoren statt globaler Geräte-IDs
- Location-Approximation je nach Privacy-Profil
- Metadaten-Entfernung aus Mediendateien

Siehe `docs/privacy.md` für Details.

## Lizenz

Phantom OS ist unter der GNU General Public License v3.0 (GPL-3.0) lizenziert. Siehe `LICENSE` für den vollständigen Lizenztext.
