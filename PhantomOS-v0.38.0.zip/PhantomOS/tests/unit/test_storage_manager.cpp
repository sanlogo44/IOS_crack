#include "phantom/storage/storage_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <cstdio>
#include <cstring>

static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

#define test(name, condition) \
    do { \
        tests_run++; \
        if (condition) { \
            tests_passed++; \
            printf("  [PASS] %s\n", name); \
        } else { \
            tests_failed++; \
            printf("  [FAIL] %s\n", name); \
        } \
    } while(0)

// ============================================================
// Test 1: Lifecycle
// ============================================================
static void testLifecycle() {
    printf("\n=== Test 1: Lifecycle ===\n");
    StorageManager mgr;
    test("not initialized initially", !mgr.isInitialized());
    test("initialize SUCCESS", mgr.initialize());
    test("initialized", mgr.isInitialized());
    test("shutdown", (mgr.shutdown(), true));
    test("not initialized after shutdown", !mgr.isInitialized());
}

// ============================================================
// Test 2: Volume Management
// ============================================================
static void testVolumeManagement() {
    printf("\n=== Test 2: Volume Management ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Default volumes should exist
    test("internal volume exists", mgr.getVolume("internal").id == "internal");
    test("cache volume exists", mgr.getVolume("cache").id == "cache");
    test("app_private volume exists", mgr.getVolume("app_private").id == "app_private");
    test("volume count >= 3", mgr.getVolumeCount() >= 3);
    test("mounted count >= 3", mgr.getMountedVolumeCount() >= 3);

    // Mount a new volume
    StorageVolume vol;
    vol.id = "usb1";
    vol.label = "USB Drive";
    vol.type = VolumeType::USB;
    vol.totalBytes = 16ULL * 1024 * 1024 * 1024;
    vol.freeBytes = vol.totalBytes;
    test("mountVolume SUCCESS", mgr.mountVolume(vol, "system") == StorageResult::SUCCESS);
    test("mounted count >= 4", mgr.getMountedVolumeCount() >= 4);
    test("volume count >= 4", mgr.getVolumeCount() >= 4);

    // Duplicate mount
    test("mountVolume duplicate ALREADY_MOUNTED",
         mgr.mountVolume(vol, "system") == StorageResult::ALREADY_MOUNTED);

    // Non-system owner
    test("mountVolume non-system PERMISSION_DENIED",
         mgr.mountVolume(vol, "app1") == StorageResult::PERMISSION_DENIED);

    // Unmount
    test("unmountVolume SUCCESS", mgr.unmountVolume("usb1", "system") == StorageResult::SUCCESS);
    test("unmountVolume already NOT_MOUNTED",
         mgr.unmountVolume("usb1", "system") == StorageResult::NOT_MOUNTED);

    // Unmount non-existent
    test("unmountVolume non-existent NOT_FOUND",
         mgr.unmountVolume("nonexist", "system") == StorageResult::NOT_FOUND);

    // Check volume
    test("checkVolume SUCCESS", mgr.checkVolume("internal", "system") == StorageResult::SUCCESS);

    // Format volume
    test("formatVolume SUCCESS",
         mgr.formatVolume("usb1", FilesystemType::F2FS, "system") == StorageResult::SUCCESS);
    test("formatted fs type F2FS",
         mgr.getVolume("usb1").fsType == FilesystemType::F2FS);

    mgr.shutdown();
}

// ============================================================
// Test 3: Storage Stats
// ============================================================
static void testStorageStats() {
    printf("\n=== Test 3: Storage Stats ===\n");
    StorageManager mgr;
    mgr.initialize();

    uint64_t total = mgr.getTotalBytes();
    uint64_t free = mgr.getFreeBytes();
    uint64_t used = mgr.getUsedBytes();

    test("totalBytes > 0", total > 0);
    test("freeBytes > 0", free > 0);
    test("usedBytes > 0", used > 0);
    test("total = used + free", total == used + free);

    // Cache bytes
    test("cacheBytes >= 0", mgr.getCacheBytes() >= 0);

    // App quota
    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_NONE, 1024 * 1024);
    test("app quota set", mgr.getAppQuotaBytes("app1") == 1024 * 1024);
    test("app used bytes 0", mgr.getAppUsedBytes("app1") == 0);

    // Set quota
    test("setAppQuota SUCCESS",
         mgr.setAppQuota("app1", 2 * 1024 * 1024, "system") == StorageResult::SUCCESS);
    test("quota updated", mgr.getAppQuotaBytes("app1") == 2 * 1024 * 1024);

    mgr.shutdown();
}

// ============================================================
// Test 4: File Operations
// ============================================================
static void testFileOperations() {
    printf("\n=== Test 4: File Operations ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Set app policy
    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_NONE, 100);

    // Create file
    test("createFile SUCCESS",
         mgr.createFile("/data/app1/test.txt", "app1") == StorageResult::SUCCESS);

    // Create directory
    test("createDirectory SUCCESS",
         mgr.createDirectory("/data/app1/docs", "app1") == StorageResult::SUCCESS);

    // Get file
    StorageFile file = mgr.getFile("/data/app1/test.txt", "app1");
    test("getFile found", !file.path.empty());
    test("file type FILE", file.type == FileType::FILE);

    // List directory
    auto files = mgr.listDirectory("/data/app1", "app1");
    test("listDirectory has entries", files.size() >= 2);

    // Rename file
    test("renameFile SUCCESS",
         mgr.renameFile("/data/app1/test.txt", "/data/app1/renamed.txt", "app1") == StorageResult::SUCCESS);

    // Delete file
    test("deleteFile SUCCESS",
         mgr.deleteFile("/data/app1/renamed.txt", "app1") == StorageResult::SUCCESS);

    // Delete non-existent
    test("deleteFile NOT_FOUND",
         mgr.deleteFile("/data/app1/nonexist.txt", "app1") == StorageResult::NOT_FOUND);

    // Delete directory with contents
    mgr.createDirectory("/data/app1/parent", "app1");
    mgr.createFile("/data/app1/parent/child.txt", "app1");
    test("deleteDirectory NOT_EMPTY",
         mgr.deleteDirectory("/data/app1/parent", "app1") == StorageResult::NOT_EMPTY);

    // Set read-only
    mgr.createFile("/data/app1/ro.txt", "app1");
    test("setFileReadOnly SUCCESS",
         mgr.setFileReadOnly("/data/app1/ro.txt", true, "app1") == StorageResult::SUCCESS);

    // Permission denied
    mgr.setAppStoragePolicy("app2", StoragePermission::DENY, StoragePrivacyMode::FULL);
    test("createFile DENY PERMISSION_DENIED",
         mgr.createFile("/data/app2/test.txt", "app2") == StorageResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test 5: Permissions & Policy
// ============================================================
static void testPermissionsPolicy() {
    printf("\n=== Test 5: Permissions & Policy ===\n");
    StorageManager mgr;
    mgr.initialize();

    // DENY
    mgr.setAppStoragePolicy("app_d", StoragePermission::DENY, StoragePrivacyMode::FULL);
    test("DENY checkAppAccess false", !mgr.checkAppAccess("app_d"));

    // ALLOW_ALWAYS
    mgr.setAppStoragePolicy("app_a", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    test("ALLOW_ALWAYS checkAppAccess true", mgr.checkAppAccess("app_a"));

    // ALLOW_FOREGROUND (not foreground)
    mgr.setAppStoragePolicy("app_f", StoragePermission::ALLOW_FOREGROUND, StoragePrivacyMode::FULL);
    test("ALLOW_FOREGROUND background false", !mgr.checkAppAccess("app_f"));

    // Set foreground
    mgr.setAppForeground("app_f", true);
    test("ALLOW_FOREGROUND foreground true", mgr.checkAppAccess("app_f"));

    // ALLOW_ONCE
    mgr.setAppStoragePolicy("app_o", StoragePermission::ALLOW_ONCE, StoragePrivacyMode::FULL);
    test("ALLOW_ONCE first access true", mgr.checkAppAccess("app_o"));
    test("ALLOW_ONCE consumed after createFile",
         mgr.createFile("/data/test.txt", "app_o") == StorageResult::SUCCESS);
    test("ALLOW_ONCE second access false", !mgr.checkAppAccess("app_o"));

    // Non-system setAppStoragePolicy
    test("setAppStoragePolicy non-system PERMISSION_DENIED",
         mgr.setAppStoragePolicy("app_x", StoragePermission::ALLOW_ALWAYS,
                                 StoragePrivacyMode::FULL, STORAGE_PRIVACY_NONE, 0, false, "app1")
         == StorageResult::PERMISSION_DENIED);

    // Clear policy
    test("clearAppStoragePolicy SUCCESS",
         mgr.clearAppStoragePolicy("app_a", "system") == StorageResult::SUCCESS);
    test("cleared policy access false", !mgr.checkAppAccess("app_a"));

    // Clear non-existent
    test("clearAppStoragePolicy NOT_FOUND",
         mgr.clearAppStoragePolicy("nonexist", "system") == StorageResult::NOT_FOUND);

    // REQUIRE_FOREGROUND flag
    mgr.setAppStoragePolicy("app_rf", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_REQUIRE_FOREGROUND);
    test("REQUIRE_FOREGROUND background denied", !mgr.checkAppAccess("app_rf"));
    mgr.setAppForeground("app_rf", true);
    test("REQUIRE_FOREGROUND foreground allowed", mgr.checkAppAccess("app_rf"));

    // ALLOW_ONCE on getVolumeInfo
    mgr.setAppStoragePolicy("app_vo", StoragePermission::ALLOW_ONCE, StoragePrivacyMode::FULL);
    StorageVolume vol;
    test("first getVolumeInfo ALLOW_ONCE SUCCESS",
         mgr.getVolumeInfo("internal", vol, "app_vo") == StorageResult::SUCCESS);
    test("ALLOW_ONCE consumed for volumeInfo", !mgr.checkAppAccess("app_vo"));
    test("second getVolumeInfo PERMISSION_DENIED",
         mgr.getVolumeInfo("internal", vol, "app_vo") == StorageResult::PERMISSION_DENIED);

    // privacyApplications tracked
    test("stats privacyApplications >= 1", mgr.getStats().privacyApplications >= 1);

    mgr.shutdown();
}

// ============================================================
// Test 6: Privacy Transforms
// ============================================================
static void testPrivacyTransforms() {
    printf("\n=== Test 6: Privacy Transforms ===\n");
    StorageManager mgr;
    mgr.initialize();

    // FULL mode - no transform
    mgr.setAppStoragePolicy("app_full", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    std::string path = mgr.applyPrivacyTransform("/data/test/file.txt", "app_full");
    test("FULL mode no transform", path == "/data/test/file.txt");

    // REDACTED with REDACT_PATHS
    mgr.setAppStoragePolicy("app_red", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::REDACTED, STORAGE_PRIVACY_REDACT_PATHS);
    path = mgr.applyPrivacyTransform("/data/test/file.txt", "app_red");
    test("REDACTED + REDACT_PATHS returns [REDACTED]", path == "[REDACTED]");

    // REDACTED with PSEUDONYMIZE
    mgr.setAppStoragePolicy("app_pseudo", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::REDACTED, STORAGE_PRIVACY_PSEUDONYMIZE);
    path = mgr.applyPrivacyTransform("/data/test/file.txt", "app_pseudo");
    test("REDACTED + PSEUDONYMIZE returns hash", path.find("vol_") == 0);
    test("PSEUDONYMIZE deterministic",
         mgr.applyPrivacyTransform("/data/test/file.txt", "app_pseudo") == path);
    test("PSEUDONYMIZE different input different hash",
         mgr.applyPrivacyTransform("/data/other/file.txt", "app_pseudo") != path);

    // METADATA_ONLY
    mgr.setAppStoragePolicy("app_meta", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::METADATA_ONLY);
    path = mgr.applyPrivacyTransform("/data/test/file.txt", "app_meta");
    test("METADATA_ONLY returns [REDACTED]", path == "[REDACTED]");

    // System owner - no transform
    path = mgr.applyPrivacyTransform("/data/test/file.txt", "system");
    test("system owner no transform", path == "/data/test/file.txt");

    // Volume info with METADATA_ONLY
    mgr.setAppStoragePolicy("app_vi", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::METADATA_ONLY, STORAGE_PRIVACY_METADATA_ONLY);
    StorageVolume vol;
    mgr.getVolumeInfo("internal", vol, "app_vi");
    test("METADATA_ONLY volume totalBytes redacted", vol.totalBytes == 0);
    test("METADATA_ONLY volume label redacted", vol.label == "[REDACTED]");
    test("METADATA_ONLY volume mountPoint redacted", vol.mountPoint == "[REDACTED]");

    mgr.shutdown();
}

// ============================================================
// Test 7: Mock
// ============================================================
static void testMock() {
    printf("\n=== Test 7: Mock ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Enable mock
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true, "system") == StorageResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    // Non-system
    test("setMockEnabled non-system PERMISSION_DENIED",
         mgr.setMockEnabled(false, "app1") == StorageResult::PERMISSION_DENIED);

    // Set mock volume
    StorageVolume vol;
    vol.id = "mock_vol";
    vol.label = "Mock Volume";
    vol.type = VolumeType::USB;
    vol.state = VolumeState::MOUNTED;
    vol.totalBytes = 8ULL * 1024 * 1024 * 1024;
    vol.freeBytes = vol.totalBytes;
    test("setMockVolume SUCCESS", mgr.setMockVolume(vol) == StorageResult::SUCCESS);
    test("mock volume exists", mgr.getVolume("mock_vol").id == "mock_vol");

    // Add mock file
    test("addMockFile SUCCESS",
         mgr.addMockFile("/mock/test.txt", FileType::FILE, 1024) == StorageResult::SUCCESS);

    // Remove mock file
    test("removeMockFile SUCCESS",
         mgr.removeMockFile("/mock/test.txt") == StorageResult::SUCCESS);

    // Remove non-existent
    test("removeMockFile NOT_FOUND",
         mgr.removeMockFile("/mock/nonexist") == StorageResult::NOT_FOUND);

    // Disable mock and try
    mgr.setMockEnabled(false, "system");
    test("addMockFile when disabled BAD_STATE",
         mgr.addMockFile("/mock/test.txt", FileType::FILE, 1024) == StorageResult::BAD_STATE);

    mgr.shutdown();
}

// ============================================================
// Test 8: History
// ============================================================
static void testHistory() {
    printf("\n=== Test 8: History ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Generate some events
    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.createFile("/data/app1/file1.txt", "app1");
    mgr.createFile("/data/app1/file2.txt", "app1");
    mgr.createFile("/data/app1/file3.txt", "app1");

    auto history = mgr.getHistory("app1");
    test("history populated", history.size() >= 3);

    // Clear history
    test("clearHistory SUCCESS", mgr.clearHistory("system") == StorageResult::SUCCESS);
    test("history cleared", mgr.getHistory("app1").size() <= 1);

    // Non-system clear
    test("clearHistory non-system PERMISSION_DENIED",
         mgr.clearHistory("app1") == StorageResult::PERMISSION_DENIED);

    // Clear app history
    mgr.setAppStoragePolicy("app2", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.createFile("/data/app2/file.txt", "app2");
    test("clearAppHistory SUCCESS",
         mgr.clearAppHistory("app2", "system") == StorageResult::SUCCESS);

    // NO_HISTORY flag
    mgr.setAppStoragePolicy("app_nh", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_NO_HISTORY);
    mgr.createFile("/data/app_nh/file.txt", "app_nh");
    auto nhHistory = mgr.getHistory("app_nh");
    // Events should not be in history due to NO_HISTORY flag
    test("NO_HISTORY flag reduces history entries", nhHistory.size() <= 1);

    mgr.shutdown();
}

// ============================================================
// Test 9: Events
// ============================================================
static void testEvents() {
    printf("\n=== Test 9: Events ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Generate events
    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.createFile("/data/app1/test.txt", "app1");
    mgr.deleteFile("/data/app1/test.txt", "app1");

    auto events = mgr.getEvents();
    test("events populated", events.size() >= 2);

    // Events by type
    auto createdEvents = mgr.getEventsByType(StorageEventType::FILE_CREATED);
    test("events by type FILE_CREATED", createdEvents.size() >= 1);

    // Clear events
    test("clearEvents SUCCESS", mgr.clearEvents("system") == StorageResult::SUCCESS);
    test("events cleared", mgr.getEvents().empty());

    // Event callback
    bool callbackCalled = false;
    mgr.setEventCallback([&callbackCalled](const StorageEvent&) {
        callbackCalled = true;
    });
    mgr.setAppStoragePolicy("app_cb", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    test("event callback called", callbackCalled);

    // Access callback
    bool accessCalled = false;
    mgr.setAccessCallback([&accessCalled](const std::string&, StorageOpType, bool) {
        accessCalled = true;
    });
    mgr.createFile("/data/app_cb/test.txt", "app_cb");
    test("access callback called", accessCalled);

    mgr.shutdown();
}

// ============================================================
// Test 10: Stats
// ============================================================
static void testStats() {
    printf("\n=== Test 10: Stats ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Generate activity
    StorageVolume vol;
    vol.id = "stat_vol";
    vol.label = "Stat Volume";
    vol.type = VolumeType::USB;
    mgr.mountVolume(vol, "system");
    mgr.unmountVolume("stat_vol", "system");
    mgr.checkVolume("internal", "system");
    mgr.formatVolume("stat_vol", FilesystemType::EXT4, "system");

    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.createFile("/data/app1/f1.txt", "app1");
    mgr.createFile("/data/app1/f2.txt", "app1");
    mgr.deleteFile("/data/app1/f1.txt", "app1");
    mgr.renameFile("/data/app1/f2.txt", "/data/app1/f3.txt", "app1");

    auto stats = mgr.getStats();
    test("volumeMounts >= 1", stats.volumeMounts >= 1);
    test("volumeUnmounts >= 1", stats.volumeUnmounts >= 1);
    test("volumeChecks >= 1", stats.volumeChecks >= 1);
    test("volumeFormats >= 1", stats.volumeFormats >= 1);
    test("filesCreated >= 2", stats.filesCreated >= 2);
    test("filesDeleted >= 1", stats.filesDeleted >= 1);
    test("filesRenamed >= 1", stats.filesRenamed >= 1);
    test("permissionsChanged >= 1", stats.permissionsChanged >= 1);

    // Reset stats
    test("resetStats SUCCESS", mgr.resetStats("system") == StorageResult::SUCCESS);
    auto resetStats = mgr.getStats();
    test("stats reset volumeMounts 0", resetStats.volumeMounts == 0);
    test("stats reset filesCreated 0", resetStats.filesCreated == 0);

    // Non-system reset
    test("resetStats non-system PERMISSION_DENIED",
         mgr.resetStats("app1") == StorageResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test 11: Failure Simulation
// ============================================================
static void testFailureSimulation() {
    printf("\n=== Test 11: Failure Simulation ===\n");
    StorageManager mgr;
    mgr.initialize();

    mgr.setFailNextOperation(true);
    test("mountVolume with fail SIMULATED_FAILURE",
         mgr.mountVolume(StorageVolume{}, "system") == StorageResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("unmountVolume with fail SIMULATED_FAILURE",
         mgr.unmountVolume("internal", "system") == StorageResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("createFile with fail SIMULATED_FAILURE",
         mgr.createFile("/data/test.txt", "system") == StorageResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("deleteFile with fail SIMULATED_FAILURE",
         mgr.deleteFile("/data/test.txt", "system") == StorageResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("renameFile with fail SIMULATED_FAILURE",
         mgr.renameFile("/a", "/b", "system") == StorageResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setAppStoragePolicy with fail SIMULATED_FAILURE",
         mgr.setAppStoragePolicy("app", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL) == StorageResult::SIMULATED_FAILURE);

    // Test totalFailures increments
    int failuresBefore = mgr.getStats().totalFailures;
    mgr.setFailNextOperation(true);
    mgr.mountVolume(StorageVolume{}, "system");
    test("totalFailures increments on simulated failure",
         mgr.getStats().totalFailures == failuresBefore + 1);

    test("failNextOperation resets correctly", !mgr.getFailNextOperation());

    mgr.shutdown();
}

// ============================================================
// Test 12: Time Injection
// ============================================================
static void testTimeInjection() {
    printf("\n=== Test 12: Time Injection ===\n");
    StorageManager mgr;
    mgr.initialize();

    mgr.setCurrentTimeForTesting(1000000);
    test("time override active", mgr.getCurrentTime() == 1000000);

    mgr.setAppStoragePolicy("app1", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.createFile("/data/app1/test.txt", "app1");

    auto events = mgr.getEvents();
    if (!events.empty()) {
        test("event timestamp matches injected time", events.back().timestamp == 1000000);
    }

    mgr.clearTimeOverride();
    test("time override cleared", mgr.getCurrentTime() != 1000000);

    mgr.shutdown();
}

// ============================================================
// Test 13: String Helpers
// ============================================================
static void testStringHelpers() {
    printf("\n=== Test 13: String Helpers ===\n");

    // Result
    test("SUCCESS string", strcmp(StorageManager::resultToString(StorageResult::SUCCESS), "SUCCESS") == 0);
    test("NOT_INITIALIZED string", strcmp(StorageManager::resultToString(StorageResult::NOT_INITIALIZED), "NOT_INITIALIZED") == 0);
    test("QUOTA_EXCEEDED string", strcmp(StorageManager::resultToString(StorageResult::QUOTA_EXCEEDED), "QUOTA_EXCEEDED") == 0);
    test("SIMULATED_FAILURE string", strcmp(StorageManager::resultToString(StorageResult::SIMULATED_FAILURE), "SIMULATED_FAILURE") == 0);

    // VolumeType
    test("INTERNAL string", strcmp(StorageManager::volumeTypeToString(VolumeType::INTERNAL), "INTERNAL") == 0);
    test("USB string", strcmp(StorageManager::volumeTypeToString(VolumeType::USB), "USB") == 0);

    // VolumeState
    test("MOUNTED string", strcmp(StorageManager::volumeStateToString(VolumeState::MOUNTED), "MOUNTED") == 0);
    test("UNMOUNTED string", strcmp(StorageManager::volumeStateToString(VolumeState::UNMOUNTED), "UNMOUNTED") == 0);

    // FileType
    test("FILE string", strcmp(StorageManager::fileTypeToString(FileType::FILE), "FILE") == 0);
    test("DIRECTORY string", strcmp(StorageManager::fileTypeToString(FileType::DIRECTORY), "DIRECTORY") == 0);

    // Permission
    test("ALLOW_ONCE string", strcmp(StorageManager::permissionToString(StoragePermission::ALLOW_ONCE), "ALLOW_ONCE") == 0);
    test("DENY string", strcmp(StorageManager::permissionToString(StoragePermission::DENY), "DENY") == 0);

    // PrivacyMode
    test("FULL string", strcmp(StorageManager::privacyModeToString(StoragePrivacyMode::FULL), "FULL") == 0);
    test("REDACTED string", strcmp(StorageManager::privacyModeToString(StoragePrivacyMode::REDACTED), "REDACTED") == 0);

    // EventType
    test("VOLUME_MOUNTED string", strcmp(StorageManager::eventTypeToString(StorageEventType::VOLUME_MOUNTED), "VOLUME_MOUNTED") == 0);
    test("FILE_DELETED string", strcmp(StorageManager::eventTypeToString(StorageEventType::FILE_DELETED), "FILE_DELETED") == 0);

    // FilesystemType
    test("EXT4 string", strcmp(StorageManager::fsTypeToString(FilesystemType::EXT4), "EXT4") == 0);
    test("F2FS string", strcmp(StorageManager::fsTypeToString(FilesystemType::F2FS), "F2FS") == 0);

    // OpType
    test("READ string", strcmp(StorageManager::opTypeToString(StorageOpType::READ), "READ") == 0);
    test("WRITE string", strcmp(StorageManager::opTypeToString(StorageOpType::WRITE), "WRITE") == 0);

    // Parsers
    test("stringToResult SUCCESS", StorageManager::stringToResult("SUCCESS") == StorageResult::SUCCESS);
    test("stringToResult QUOTA_EXCEEDED", StorageManager::stringToResult("QUOTA_EXCEEDED") == StorageResult::QUOTA_EXCEEDED);
    test("stringToVolumeType USB", StorageManager::stringToVolumeType("USB") == VolumeType::USB);
    test("stringToFilesystemType F2FS", StorageManager::stringToFilesystemType("F2FS") == FilesystemType::F2FS);

    // FileAccessMode
    test("READ access mode", strcmp(StorageManager::accessModeToString(FileAccessMode::READ), "READ") == 0);
    test("WRITE access mode", strcmp(StorageManager::accessModeToString(FileAccessMode::WRITE), "WRITE") == 0);
    test("READ_WRITE access mode", strcmp(StorageManager::accessModeToString(FileAccessMode::READ_WRITE), "READ_WRITE") == 0);
    test("APPEND access mode", strcmp(StorageManager::accessModeToString(FileAccessMode::APPEND), "APPEND") == 0);
}

// ============================================================
// Test 14: LogServer / CrashReporter Integration
// ============================================================
static void testIntegration() {
    printf("\n=== Test 14: LogServer / CrashReporter Integration ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Set LogServer and CrashReporter (null for testing, but should not crash)
    mgr.setLogServer(nullptr);
    mgr.setCrashReporter(nullptr);

    // Operations should still work
    test("createFile with null LogServer SUCCESS",
         mgr.createFile("/data/test.txt", "system") == StorageResult::SUCCESS);

    mgr.shutdown();
}

// ============================================================
// Test 15: Quota Enforcement
// ============================================================
static void testQuotaEnforcement() {
    printf("\n=== Test 15: Quota Enforcement ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Set quota to 3
    mgr.setAppStoragePolicy("app_q", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_NONE, 3);

    test("first file within quota",
         mgr.createFile("/data/app_q/f1.txt", "app_q") == StorageResult::SUCCESS);
    test("second file within quota",
         mgr.createFile("/data/app_q/f2.txt", "app_q") == StorageResult::SUCCESS);
    test("third file within quota",
         mgr.createFile("/data/app_q/f3.txt", "app_q") == StorageResult::SUCCESS);
    test("fourth file QUOTA_EXCEEDED",
         mgr.createFile("/data/app_q/f4.txt", "app_q") == StorageResult::QUOTA_EXCEEDED);

    // Check stats
    test("quotaExceeded in stats", mgr.getStats().quotaExceeded >= 1);

    mgr.shutdown();
}

// ============================================================
// Test 16: ALLOW_ONCE on Identifier Access
// ============================================================
static void testAllowOnceIdentifierAccess() {
    printf("\n=== Test 16: ALLOW_ONCE on Identifier Access ===\n");
    StorageManager mgr;
    mgr.initialize();

    // ALLOW_ONCE on getVolumeLabel
    mgr.setAppStoragePolicy("app_vol", StoragePermission::ALLOW_ONCE, StoragePrivacyMode::FULL);

    std::string label;
    test("first getVolumeLabel ALLOW_ONCE SUCCESS",
         mgr.getVolumeLabel("internal", label, "app_vol") == StorageResult::SUCCESS);
    test("ALLOW_ONCE consumed for volumeLabel", !mgr.checkAppAccess("app_vol"));

    test("second getVolumeLabel PERMISSION_DENIED",
         mgr.getVolumeLabel("internal", label, "app_vol") == StorageResult::PERMISSION_DENIED);

    // ALLOW_ONCE on getVolumeInfo
    mgr.setAppStoragePolicy("app_vi2", StoragePermission::ALLOW_ONCE, StoragePrivacyMode::FULL);
    StorageVolume vol;
    test("first getVolumeInfo ALLOW_ONCE SUCCESS",
         mgr.getVolumeInfo("internal", vol, "app_vi2") == StorageResult::SUCCESS);
    test("ALLOW_ONCE consumed for volumeInfo", !mgr.checkAppAccess("app_vi2"));
    test("second getVolumeInfo PERMISSION_DENIED",
         mgr.getVolumeInfo("internal", vol, "app_vi2") == StorageResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test 17: REQUIRE_FOREGROUND Flag
// ============================================================
static void testRequireForegroundFlag() {
    printf("\n=== Test 17: REQUIRE_FOREGROUND Flag ===\n");
    StorageManager mgr;
    mgr.initialize();

    mgr.setAppStoragePolicy("app_rf", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_REQUIRE_FOREGROUND);

    test("checkAppAccess background denied with REQUIRE_FOREGROUND",
         !mgr.checkAppAccess("app_rf"));

    test("createFile background denied",
         mgr.createFile("/data/app_rf/test.txt", "app_rf") == StorageResult::PERMISSION_DENIED);

    mgr.setAppForeground("app_rf", true);
    test("checkAppAccess foreground allowed with REQUIRE_FOREGROUND",
         mgr.checkAppAccess("app_rf"));
    test("createFile foreground SUCCESS",
         mgr.createFile("/data/app_rf/test.txt", "app_rf") == StorageResult::SUCCESS);

    mgr.shutdown();
}

// ============================================================
// Test 18: Full Workflow
// ============================================================
static void testFullWorkflow() {
    printf("\n=== Test 18: Full Workflow ===\n");
    StorageManager mgr;
    test("1. initialize", mgr.initialize());
    test("2. default volumes exist", mgr.getVolumeCount() >= 3);

    // Set app policy
    test("3. setAppStoragePolicy SUCCESS",
         mgr.setAppStoragePolicy("app_wf", StoragePermission::ALLOW_ALWAYS,
                                 StoragePrivacyMode::REDACTED, STORAGE_PRIVACY_PSEUDONYMIZE, 100, true)
         == StorageResult::SUCCESS);
    test("4. foreground set",
         mgr.setAppForeground("app_wf", true) == StorageResult::SUCCESS);

    // File operations
    test("5. createFile SUCCESS",
         mgr.createFile("/data/app_wf/test.txt", "app_wf") == StorageResult::SUCCESS);
    test("6. createDirectory SUCCESS",
         mgr.createDirectory("/data/app_wf/docs", "app_wf") == StorageResult::SUCCESS);
    test("7. getFile found",
         !mgr.getFile("/data/app_wf/test.txt", "app_wf").path.empty());
    test("8. listDirectory has entries",
         mgr.listDirectory("/data/app_wf", "app_wf").size() >= 2);
    test("9. renameFile SUCCESS",
         mgr.renameFile("/data/app_wf/test.txt", "/data/app_wf/renamed.txt", "app_wf") == StorageResult::SUCCESS);
    test("10. deleteFile SUCCESS",
         mgr.deleteFile("/data/app_wf/renamed.txt", "app_wf") == StorageResult::SUCCESS);

    // Volume operations
    StorageVolume vol;
    vol.id = "wf_vol";
    vol.label = "Workflow Volume";
    vol.type = VolumeType::USB;
    test("11. mountVolume SUCCESS", mgr.mountVolume(vol, "system") == StorageResult::SUCCESS);
    test("12. checkVolume SUCCESS", mgr.checkVolume("wf_vol", "system") == StorageResult::SUCCESS);
    test("13. formatVolume SUCCESS",
         mgr.formatVolume("wf_vol", FilesystemType::EXT4, "system") == StorageResult::SUCCESS);
    test("14. unmountVolume SUCCESS", mgr.unmountVolume("wf_vol", "system") == StorageResult::SUCCESS);

    // Privacy
    std::string label;
    test("15. getVolumeLabel SUCCESS",
         mgr.getVolumeLabel("internal", label, "app_wf") == StorageResult::SUCCESS);

    // Stats
    auto stats = mgr.getStats();
    test("16. stats populated", stats.volumeMounts >= 1);

    // Events
    auto events = mgr.getEvents();
    test("17. events populated", events.size() >= 5);

    // History
    auto history = mgr.getHistory("app_wf");
    test("18. history populated", history.size() >= 3);

    // Clear history
    test("19. clearHistory SUCCESS", mgr.clearHistory("system") == StorageResult::SUCCESS);
    test("20. history cleared", mgr.getHistory("app_wf").size() <= 1);

    // Shutdown
    test("21. shutdown", (mgr.shutdown(), true));
    test("22. not initialized after shutdown", !mgr.isInitialized());
}

// ============================================================
// Test 19: File Access Policy & Privacy
// ============================================================
static void testFileAccessPolicy() {
    printf("\n=== Test 19: File Access Policy & Privacy ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Create a file as system
    mgr.setMockEnabled(true, "system");
    mgr.addMockFile("/data/shared/test.txt", FileType::FILE, 1024);
    mgr.setMockEnabled(false, "system");

    // DENY app - getFile returns empty
    mgr.setAppStoragePolicy("app_deny", StoragePermission::DENY, StoragePrivacyMode::FULL);
    StorageFile deniedFile = mgr.getFile("/data/shared/test.txt", "app_deny");
    test("DENY getFile returns empty", deniedFile.path.empty());

    // DENY app - listDirectory returns empty
    auto deniedList = mgr.listDirectory("/data/shared", "app_deny");
    test("DENY listDirectory returns empty", deniedList.empty());

    // ALLOW_ALWAYS + FULL - getFile returns file
    mgr.setAppStoragePolicy("app_full", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.setAppForeground("app_full", true);
    StorageFile fullFile = mgr.getFile("/data/shared/test.txt", "app_full");
    test("FULL getFile returns file", !fullFile.path.empty());
    test("FULL getFile path not redacted", fullFile.path == "/data/shared/test.txt");

    // REDACTED + REDACT_PATHS - getFile path redacted
    mgr.setAppStoragePolicy("app_red", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::REDACTED, STORAGE_PRIVACY_REDACT_PATHS);
    mgr.setAppForeground("app_red", true);
    StorageFile redFile = mgr.getFile("/data/shared/test.txt", "app_red");
    test("REDACTED getFile path redacted", redFile.path == "[REDACTED]");

    // REQUIRE_FOREGROUND background - getFile returns empty
    mgr.setAppStoragePolicy("app_bg", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_REQUIRE_FOREGROUND);
    StorageFile bgFile = mgr.getFile("/data/shared/test.txt", "app_bg");
    test("REQUIRE_FOREGROUND background getFile empty", bgFile.path.empty());

    // Set foreground - getFile works
    mgr.setAppForeground("app_bg", true);
    StorageFile fgFile = mgr.getFile("/data/shared/test.txt", "app_bg");
    test("REQUIRE_FOREGROUND foreground getFile works", !fgFile.path.empty());

    // ALLOW_ONCE - first getFile succeeds, second returns empty
    mgr.setAppStoragePolicy("app_once", StoragePermission::ALLOW_ONCE, StoragePrivacyMode::FULL);
    mgr.setAppForeground("app_once", true);
    StorageFile onceFile1 = mgr.getFile("/data/shared/test.txt", "app_once");
    test("ALLOW_ONCE first getFile works", !onceFile1.path.empty());
    StorageFile onceFile2 = mgr.getFile("/data/shared/test.txt", "app_once");
    test("ALLOW_ONCE second getFile empty (consumed)", onceFile2.path.empty());

    mgr.shutdown();
}

// ============================================================
// Test 20: Privacy Indicator
// ============================================================
static void testPrivacyIndicator() {
    printf("\n=== Test 20: Privacy Indicator ===\n");
    StorageManager mgr;
    mgr.initialize();

    // Initially inactive
    test("indicator initially inactive", !mgr.isIndicatorActive());
    test("active users initially empty", mgr.getActiveStorageUsers().empty());

    // App with ALLOW_ALWAYS does an operation
    mgr.setAppStoragePolicy("app_ind", StoragePermission::ALLOW_ALWAYS,
                            StoragePrivacyMode::FULL, STORAGE_PRIVACY_INDICATOR_REQUIRED);
    mgr.setAppForeground("app_ind", true);
    mgr.createFile("/data/app_ind/test.txt", "app_ind");

    test("indicator active after app access", mgr.isIndicatorActive());
    test("active users contains app", !mgr.getActiveStorageUsers().empty());
    test("last access time > 0", mgr.getLastAccessTime() > 0);

    // System operations don't add to active users
    mgr.setAppStoragePolicy("app_sys", StoragePermission::ALLOW_ALWAYS, StoragePrivacyMode::FULL);
    mgr.setAppForeground("app_sys", true);
    mgr.createFile("/data/sys_test.txt", "system");

    // Shutdown clears indicator
    mgr.shutdown();
    StorageManager mgr2;
    mgr2.initialize();
    test("indicator inactive after reinit", !mgr2.isIndicatorActive());
    mgr2.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("========================================\n");
    printf("  PhantomOS Storage Manager Tests\n");
    printf("========================================\n");

    testLifecycle();
    testVolumeManagement();
    testStorageStats();
    testFileOperations();
    testPermissionsPolicy();
    testPrivacyTransforms();
    testMock();
    testHistory();
    testEvents();
    testStats();
    testFailureSimulation();
    testTimeInjection();
    testStringHelpers();
    testIntegration();
    testQuotaEnforcement();
    testAllowOnceIdentifierAccess();
    testRequireForegroundFlag();
    testFullWorkflow();
    testFileAccessPolicy();
    testPrivacyIndicator();

    printf("\n==================================================\n");
    printf("  Results: %d run, %d passed, %d failed\n",
           tests_run, tests_passed, tests_failed);
    printf("==================================================\n");

    return tests_failed > 0 ? 1 : 0;
}
