#include "phantom/storage/storage_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <algorithm>
#include <chrono>
#include <cstring>

// ============================================================
// Storage Manager Implementation
// ============================================================

StorageManager::StorageManager() {}

StorageManager::~StorageManager() {
    shutdown();
}

// ============================================================
// Lifecycle
// ============================================================

bool StorageManager::initialize() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (initialized_) return true;

    initialized_ = true;

    // Default internal volume (64GB NVMe as per iPhone X spec)
    StorageVolume internal;
    internal.id = "internal";
    internal.label = "Internal Storage";
    internal.type = VolumeType::INTERNAL;
    internal.state = VolumeState::MOUNTED;
    internal.fsType = FilesystemType::EXT4;
    internal.mountPoint = "/data";
    internal.totalBytes = 64ULL * 1024 * 1024 * 1024;
    internal.freeBytes = 42ULL * 1024 * 1024 * 1024;
    internal.usedBytes = internal.totalBytes - internal.freeBytes;
    internal.encrypted = true;
    internal.readOnly = false;
    internal.removable = false;
    internal.primary = true;
    volumes_[internal.id] = internal;

    // Cache volume
    StorageVolume cache;
    cache.id = "cache";
    cache.label = "Cache";
    cache.type = VolumeType::CACHE;
    cache.state = VolumeState::MOUNTED;
    cache.fsType = FilesystemType::EXT4;
    cache.mountPoint = "/cache";
    cache.totalBytes = 2ULL * 1024 * 1024 * 1024;
    cache.freeBytes = 1ULL * 1024 * 1024 * 1024;
    cache.usedBytes = cache.totalBytes - cache.freeBytes;
    cache.encrypted = false;
    cache.readOnly = false;
    cache.removable = false;
    cache.primary = false;
    volumes_[cache.id] = cache;

    // App private volume
    StorageVolume appPrivate;
    appPrivate.id = "app_private";
    appPrivate.label = "App Private Storage";
    appPrivate.type = VolumeType::APP_PRIVATE;
    appPrivate.state = VolumeState::MOUNTED;
    appPrivate.fsType = FilesystemType::EXT4;
    appPrivate.mountPoint = "/data/app";
    appPrivate.totalBytes = 32ULL * 1024 * 1024 * 1024;
    appPrivate.freeBytes = 24ULL * 1024 * 1024 * 1024;
    appPrivate.usedBytes = appPrivate.totalBytes - appPrivate.freeBytes;
    appPrivate.encrypted = true;
    appPrivate.readOnly = false;
    appPrivate.removable = false;
    appPrivate.primary = false;
    volumes_[appPrivate.id] = appPrivate;

    return true;
}

bool StorageManager::isInitialized() const {
    return initialized_;
}

void StorageManager::shutdown() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return;

    // Unmount all volumes
    for (auto& [id, vol] : volumes_) {
        vol.state = VolumeState::UNMOUNTED;
    }
    volumes_.clear();
    mockFiles_.clear();
    appPolicies_.clear();
    appUsedBytes_.clear();
    history_.clear();
    events_.clear();
    activeUsers_.clear();
    indicatorActive_ = false;
    mockEnabled_ = false;
    failNextOperation_ = false;
    stats_ = StorageStats{};
    initialized_ = false;
}

// ============================================================
// Volume Management
// ============================================================

StorageResult StorageManager::mountVolume(const StorageVolume& volume, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;
    if (volume.id.empty()) return StorageResult::INVALID_PARAMETER;
    if (volumes_.find(volume.id) != volumes_.end()) return StorageResult::ALREADY_MOUNTED;
    if (volume.state == VolumeState::MOUNTED || volume.state == VolumeState::READ_ONLY) return StorageResult::ALREADY_MOUNTED;

    StorageVolume vol = volume;
    vol.state = VolumeState::MOUNTED;
    if (vol.totalBytes == 0) {
        vol.totalBytes = 64ULL * 1024 * 1024 * 1024;
        vol.freeBytes = vol.totalBytes;
        vol.usedBytes = 0;
    }
    volumes_[vol.id] = vol;
    stats_.volumeMounts++;

    recordEvent(StorageEventType::VOLUME_MOUNTED, StorageResult::SUCCESS, vol.id, owner, "Volume mounted: " + vol.label);
    logToServer("Volume mounted: " + vol.id);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::unmountVolume(const std::string& volumeId, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageResult::NOT_FOUND;
    if (it->second.state == VolumeState::UNMOUNTED) return StorageResult::NOT_MOUNTED;

    it->second.state = VolumeState::UNMOUNTED;
    stats_.volumeUnmounts++;

    recordEvent(StorageEventType::VOLUME_UNMOUNTED, StorageResult::SUCCESS, volumeId, owner, "Volume unmounted: " + it->second.label);
    logToServer("Volume unmounted: " + volumeId);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::checkVolume(const std::string& volumeId, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageResult::NOT_FOUND;

    VolumeState oldState = it->second.state;
    it->second.state = VolumeState::CHECKING;
    recordEvent(StorageEventType::VOLUME_CHECKED, StorageResult::SUCCESS, volumeId, owner, "Volume checking: " + it->second.label);

    // Simulate check completion
    it->second.state = oldState;
    stats_.volumeChecks++;

    recordEvent(StorageEventType::STATE_CHANGED, StorageResult::SUCCESS, volumeId, owner, "Volume check complete: " + it->second.label);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::formatVolume(const std::string& volumeId, FilesystemType fsType, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageResult::NOT_FOUND;
    if (it->second.type == VolumeType::INTERNAL && it->second.primary) {
        // Allow formatting but require explicit owner check
    }

    it->second.fsType = fsType;
    it->second.state = VolumeState::MOUNTED;
    it->second.usedBytes = 0;
    it->second.freeBytes = it->second.totalBytes;
    stats_.volumeFormats++;

    recordEvent(StorageEventType::VOLUME_FORMATTED, StorageResult::SUCCESS, volumeId, owner, "Volume formatted: " + it->second.label);
    logToServer("Volume formatted: " + volumeId);
    return StorageResult::SUCCESS;
}

StorageVolume StorageManager::getVolume(const std::string& volumeId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageVolume{};
    return it->second;
}

std::vector<StorageVolume> StorageManager::getAllVolumes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StorageVolume> result;
    for (const auto& [id, vol] : volumes_) {
        result.push_back(vol);
    }
    return result;
}

std::vector<StorageVolume> StorageManager::getMountedVolumes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StorageVolume> result;
    for (const auto& [id, vol] : volumes_) {
        if (vol.state == VolumeState::MOUNTED || vol.state == VolumeState::READ_ONLY) {
            result.push_back(vol);
        }
    }
    return result;
}

size_t StorageManager::getVolumeCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return volumes_.size();
}

size_t StorageManager::getMountedVolumeCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    size_t count = 0;
    for (const auto& [id, vol] : volumes_) {
        if (vol.state == VolumeState::MOUNTED || vol.state == VolumeState::READ_ONLY) count++;
    }
    return count;
}

// ============================================================
// Storage Stats
// ============================================================

uint64_t StorageManager::getTotalBytes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    uint64_t total = 0;
    for (const auto& [id, vol] : volumes_) {
        if (vol.state == VolumeState::MOUNTED || vol.state == VolumeState::READ_ONLY) {
            total += vol.totalBytes;
        }
    }
    return total;
}

uint64_t StorageManager::getFreeBytes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    uint64_t free = 0;
    for (const auto& [id, vol] : volumes_) {
        if (vol.state == VolumeState::MOUNTED || vol.state == VolumeState::READ_ONLY) {
            free += vol.freeBytes;
        }
    }
    return free;
}

uint64_t StorageManager::getUsedBytes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    uint64_t used = 0;
    for (const auto& [id, vol] : volumes_) {
        if (vol.state == VolumeState::MOUNTED || vol.state == VolumeState::READ_ONLY) {
            used += vol.usedBytes;
        }
    }
    return used;
}

uint64_t StorageManager::getCacheBytes() const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = volumes_.find("cache");
    if (it == volumes_.end()) return 0;
    return it->second.usedBytes;
}

uint64_t StorageManager::getAppQuotaBytes(const std::string& appId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return 0;
    return it->second.quotaBytes;
}

uint64_t StorageManager::getAppUsedBytes(const std::string& appId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = appUsedBytes_.find(appId);
    if (it == appUsedBytes_.end()) return 0;
    return it->second;
}

StorageResult StorageManager::setAppQuota(const std::string& appId, uint64_t quotaBytes, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return StorageResult::NOT_FOUND;

    it->second.quotaBytes = quotaBytes;
    recordEvent(StorageEventType::PERMISSION_CHANGED, StorageResult::SUCCESS, "", owner, "Quota set for " + appId);
    return StorageResult::SUCCESS;
}

// ============================================================
// File Operations
// ============================================================

StorageResult StorageManager::createFile(const std::string& path, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (path.empty()) return StorageResult::INVALID_PARAMETER;
    if (!checkAppAccess(appId)) return StorageResult::PERMISSION_DENIED;

    // Check quota
    auto policyIt = appPolicies_.find(appId);
    if (policyIt != appPolicies_.end() && policyIt->second.quotaBytes > 0) {
        auto usedIt = appUsedBytes_.find(appId);
        uint64_t used = (usedIt != appUsedBytes_.end()) ? usedIt->second : 0;
        if (used >= policyIt->second.quotaBytes) {
            stats_.quotaExceeded++;
            recordEvent(StorageEventType::QUOTA_EXCEEDED, StorageResult::QUOTA_EXCEEDED, "", appId, "Quota exceeded for " + appId);
            return StorageResult::QUOTA_EXCEEDED;
        }
    }

    // Consume ALLOW_ONCE
    if (policyIt != appPolicies_.end() && policyIt->second.permission == StoragePermission::ALLOW_ONCE) {
        policyIt->second.oneShotUsed = true;
    }

    // Create mock file entry
    StorageFile file;
    file.name = path.substr(path.find_last_of('/') + 1);
    file.path = path;
    file.type = FileType::FILE;
    file.size = 0;
    file.lastModified = getCurrentTime();
    file.readable = true;
    file.writable = true;
    mockFiles_[path][appId] = file;
    stats_.filesCreated++;

    // Track app usage
    appUsedBytes_[appId]++;

    recordEvent(StorageEventType::FILE_CREATED, StorageResult::SUCCESS, "", appId, "File created: " + path);
    notifyAccessCallback(appId, StorageOpType::CREATE, true);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::createDirectory(const std::string& path, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (path.empty()) return StorageResult::INVALID_PARAMETER;
    if (!checkAppAccess(appId)) return StorageResult::PERMISSION_DENIED;

    auto policyIt = appPolicies_.find(appId);
    if (policyIt != appPolicies_.end() && policyIt->second.permission == StoragePermission::ALLOW_ONCE) {
        policyIt->second.oneShotUsed = true;
    }

    StorageFile dir;
    dir.name = path.substr(path.find_last_of('/') + 1);
    dir.path = path;
    dir.type = FileType::DIRECTORY;
    dir.size = 0;
    dir.lastModified = getCurrentTime();
    dir.readable = true;
    dir.writable = true;
    mockFiles_[path][appId] = dir;
    stats_.filesCreated++;

    recordEvent(StorageEventType::FILE_CREATED, StorageResult::SUCCESS, "", appId, "Directory created: " + path);
    notifyAccessCallback(appId, StorageOpType::CREATE, true);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::deleteFile(const std::string& path, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (path.empty()) return StorageResult::INVALID_PARAMETER;
    if (!checkAppAccess(appId)) return StorageResult::PERMISSION_DENIED;

    auto pathIt = mockFiles_.find(path);
    if (pathIt == mockFiles_.end()) return StorageResult::NOT_FOUND;

    // Check if directory is empty
    for (const auto& [p, files] : mockFiles_) {
        if (p != path && p.find(path + "/") == 0) {
            return StorageResult::NOT_EMPTY;
        }
    }

    mockFiles_.erase(path);
    stats_.filesDeleted++;

    recordEvent(StorageEventType::FILE_DELETED, StorageResult::SUCCESS, "", appId, "File deleted: " + path);
    notifyAccessCallback(appId, StorageOpType::DELETE, true);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::deleteDirectory(const std::string& path, const std::string& appId) {
    return deleteFile(path, appId);
}

StorageResult StorageManager::renameFile(const std::string& oldPath, const std::string& newPath, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (oldPath.empty() || newPath.empty()) return StorageResult::INVALID_PARAMETER;
    if (!checkAppAccess(appId)) return StorageResult::PERMISSION_DENIED;

    auto oldIt = mockFiles_.find(oldPath);
    if (oldIt == mockFiles_.end()) return StorageResult::NOT_FOUND;

    auto files = oldIt->second;
    mockFiles_.erase(oldIt);

    for (auto& [aid, file] : files) {
        file.path = newPath;
        file.name = newPath.substr(newPath.find_last_of('/') + 1);
        file.lastModified = getCurrentTime();
        mockFiles_[newPath][aid] = file;
    }
    stats_.filesRenamed++;

    recordEvent(StorageEventType::FILE_RENAMED, StorageResult::SUCCESS, "", appId, "File renamed: " + oldPath + " -> " + newPath);
    notifyAccessCallback(appId, StorageOpType::RENAME, true);
    return StorageResult::SUCCESS;
}

StorageFile StorageManager::getFile(const std::string& path, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto pathIt = mockFiles_.find(path);
    if (pathIt == mockFiles_.end()) return StorageFile{};

    // System owner bypasses access checks
    if (isSystemOwner(appId)) {
        if (pathIt->second.empty()) return StorageFile{};
        return pathIt->second.begin()->second;
    }

    // Check app access
    if (!checkAppAccess(appId)) return StorageFile{};

    // Consume ALLOW_ONCE
    auto policyIt = appPolicies_.find(appId);
    if (policyIt != appPolicies_.end() && policyIt->second.permission == StoragePermission::ALLOW_ONCE) {
        policyIt->second.oneShotUsed = true;
    }

    auto fileIt = pathIt->second.find(appId);
    if (fileIt == pathIt->second.end()) {
        if (!pathIt->second.empty()) {
            StorageFile file = pathIt->second.begin()->second;
            // Apply privacy transform to path
            file.path = applyPrivacyTransform(file.path, appId);
            file.name = applyPrivacyTransform(file.name, appId);
            return file;
        }
        return StorageFile{};
    }

    StorageFile file = fileIt->second;
    file.path = applyPrivacyTransform(file.path, appId);
    file.name = applyPrivacyTransform(file.name, appId);
    return file;
}

std::vector<StorageFile> StorageManager::listDirectory(const std::string& path, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StorageFile> result;

    // Check app access for non-system owners
    if (!isSystemOwner(appId) && !checkAppAccess(appId)) {
        return result; // empty list for denied apps
    }

    std::string prefix = path;
    if (prefix.back() != '/') prefix += '/';

    for (const auto& [p, files] : mockFiles_) {
        if (p.find(prefix) == 0 && p != prefix) {
            std::string remaining = p.substr(prefix.length());
            if (remaining.find('/') == std::string::npos) {
                // Direct child
                if (!files.empty()) {
                    StorageFile file = files.begin()->second;
                    // Apply privacy transform for non-system owners
                    if (!isSystemOwner(appId)) {
                        file.path = applyPrivacyTransform(file.path, appId);
                        file.name = applyPrivacyTransform(file.name, appId);
                    }
                    result.push_back(file);
                }
            }
        }
    }
    return result;
}

StorageResult StorageManager::setFileReadOnly(const std::string& path, bool readOnly, const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!checkAppAccess(appId)) return StorageResult::PERMISSION_DENIED;

    auto pathIt = mockFiles_.find(path);
    if (pathIt == mockFiles_.end()) return StorageResult::NOT_FOUND;

    for (auto& [aid, file] : pathIt->second) {
        file.writable = !readOnly;
    }
    return StorageResult::SUCCESS;
}

// ============================================================
// Per-App Policy
// ============================================================

StorageResult StorageManager::setAppStoragePolicy(const std::string& appId, StoragePermission permission,
                                                   StoragePrivacyMode privacyMode,
                                                   uint32_t privacyFlags, uint64_t quotaBytes,
                                                   bool allowExternal, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return StorageResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;
    if (appId.empty()) return StorageResult::INVALID_PARAMETER;

    StoragePolicy policy;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.quotaBytes = quotaBytes;
    policy.allowExternal = allowExternal;
    policy.allowCache = true;
    policy.foreground = false;
    policy.oneShotUsed = false;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;
    if (privacyFlags != STORAGE_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    recordEvent(StorageEventType::PERMISSION_CHANGED, StorageResult::SUCCESS, "", owner, "Policy set for " + appId);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::clearAppStoragePolicy(const std::string& appId, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return StorageResult::NOT_FOUND;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;
    recordEvent(StorageEventType::PERMISSION_CHANGED, StorageResult::SUCCESS, "", owner, "Policy cleared for " + appId);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::setAppForeground(const std::string& appId, bool foreground) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return StorageResult::NOT_FOUND;

    it->second.foreground = foreground;
    return StorageResult::SUCCESS;
}

bool StorageManager::checkAppAccess(const std::string& appId) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const StoragePolicy& policy = it->second;

    // REQUIRE_FOREGROUND flag overrides permission to require foreground
    if ((policy.privacyFlags & STORAGE_PRIVACY_REQUIRE_FOREGROUND) && !policy.foreground)
        return false;

    switch (policy.permission) {
        case StoragePermission::DENY:
            return false;
        case StoragePermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case StoragePermission::ALLOW_ALWAYS:
            return true;
        case StoragePermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

// ============================================================
// Identifier Access
// ============================================================

StorageResult StorageManager::getVolumeLabel(const std::string& volumeId, std::string& outLabel,
                                              const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;

    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageResult::NOT_FOUND;

    if (!isSystemOwner(appId)) {
        if (!checkAppAccess(appId))
            return StorageResult::PERMISSION_DENIED;

        // Consume ALLOW_ONCE
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.permission == StoragePermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }
    }

    outLabel = applyPrivacyTransform(it->second.label, appId);
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::getVolumeInfo(const std::string& volumeId, StorageVolume& outVolume,
                                             const std::string& appId) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;

    auto it = volumes_.find(volumeId);
    if (it == volumes_.end()) return StorageResult::NOT_FOUND;

    if (!isSystemOwner(appId)) {
        if (!checkAppAccess(appId))
            return StorageResult::PERMISSION_DENIED;

        // Consume ALLOW_ONCE
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.permission == StoragePermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }

        // Copy to local before applying privacy transforms
        StorageVolume local = it->second;
        local.label = applyPrivacyTransform(it->second.label, appId);
        local.mountPoint = applyPrivacyTransform(it->second.mountPoint, appId);

        if (policyIt != appPolicies_.end()) {
            if (policyIt->second.privacyMode == StoragePrivacyMode::METADATA_ONLY ||
                (policyIt->second.privacyFlags & STORAGE_PRIVACY_METADATA_ONLY)) {
                local.totalBytes = 0;
                local.freeBytes = 0;
                local.usedBytes = 0;
                local.label = "[REDACTED]";
                local.mountPoint = "[REDACTED]";
            }
        }

        outVolume = local;
    } else {
        outVolume = it->second;
    }

    return StorageResult::SUCCESS;
}

// ============================================================
// Privacy
// ============================================================

std::string StorageManager::applyPrivacyTransform(const std::string& path, const std::string& appId) const {
    if (isSystemOwner(appId)) return path;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return path;

    const StoragePolicy& policy = it->second;

    if (policy.privacyMode == StoragePrivacyMode::FULL) {
        if (policy.privacyFlags & STORAGE_PRIVACY_REDACT_PATHS) {
            return "[REDACTED]";
        }
        return path;
    }

    if (policy.privacyMode == StoragePrivacyMode::REDACTED) {
        if (policy.privacyFlags & STORAGE_PRIVACY_PSEUDONYMIZE) {
            return fnv1aHash(path);
        }
        return "[REDACTED]";
    }

    if (policy.privacyMode == StoragePrivacyMode::METADATA_ONLY) {
        return "[REDACTED]";
    }

    return path;
}

bool StorageManager::isIndicatorActive() const {
    return indicatorActive_;
}

std::vector<std::string> StorageManager::getActiveStorageUsers() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return activeUsers_;
}

uint64_t StorageManager::getLastAccessTime() const {
    return lastAccessTime_;
}

// ============================================================
// Mock
// ============================================================

StorageResult StorageManager::setMockEnabled(bool enabled, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    stats_.mockSetups++;
    return StorageResult::SUCCESS;
}

bool StorageManager::isMockEnabled() const {
    return mockEnabled_;
}

StorageResult StorageManager::setMockVolume(const StorageVolume& volume) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!mockEnabled_) return StorageResult::BAD_STATE;

    volumes_[volume.id] = volume;
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::addMockFile(const std::string& path, FileType type, uint64_t size) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!mockEnabled_) return StorageResult::BAD_STATE;
    if (path.empty()) return StorageResult::INVALID_PARAMETER;

    StorageFile file;
    file.name = path.substr(path.find_last_of('/') + 1);
    file.path = path;
    file.type = type;
    file.size = size;
    file.lastModified = getCurrentTime();
    file.readable = true;
    file.writable = true;
    mockFiles_[path]["system"] = file;
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::removeMockFile(const std::string& path) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!mockEnabled_) return StorageResult::BAD_STATE;

    auto it = mockFiles_.find(path);
    if (it == mockFiles_.end()) return StorageResult::NOT_FOUND;

    mockFiles_.erase(it);
    return StorageResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<StorageEvent> StorageManager::getHistory(const std::string& appId, size_t limit) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StorageEvent> result;
    for (const auto& event : history_) {
        if (isSystemOwner(appId) || event.appId == appId) {
            result.push_back(event);
        }
    }
    if (limit > 0 && result.size() > limit) {
        result.resize(limit);
    }
    return result;
}

StorageResult StorageManager::clearHistory(const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    // Clear history_ vector itself
    history_.clear();
    events_.clear();
    stats_.historyClears++;

    recordEvent(StorageEventType::HISTORY_CLEARED, StorageResult::SUCCESS, "", owner, "History cleared");
    return StorageResult::SUCCESS;
}

StorageResult StorageManager::clearAppHistory(const std::string& appId, const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner) && owner != appId) return StorageResult::PERMISSION_DENIED;

    history_.erase(
        std::remove_if(history_.begin(), history_.end(),
                       [&appId](const StorageEvent& e) { return e.appId == appId; }),
        history_.end());

    return StorageResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<StorageEvent> StorageManager::getEvents(size_t limit) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (limit == 0) return events_;
    if (events_.size() <= limit) return events_;
    return std::vector<StorageEvent>(events_.end() - limit, events_.end());
}

std::vector<StorageEvent> StorageManager::getEventsByType(StorageEventType type, size_t limit) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<StorageEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
        }
        if (limit > 0 && result.size() >= limit) break;
    }
    return result;
}

StorageResult StorageManager::clearEvents(const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    // Events are already in history_ from recordEvent, just clear events_
    events_.clear();
    return StorageResult::SUCCESS;
}

void StorageManager::setEventCallback(StorageEventCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    eventCallback_ = callback;
}

void StorageManager::setAccessCallback(StorageAccessCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    accessCallback_ = callback;
}

// ============================================================
// Stats
// ============================================================

StorageStats StorageManager::getStats() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return stats_;
}

StorageResult StorageManager::resetStats(const std::string& owner) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return StorageResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return StorageResult::PERMISSION_DENIED;

    stats_ = StorageStats{};
    return StorageResult::SUCCESS;
}

// ============================================================
// Time Injection
// ============================================================

uint64_t StorageManager::getCurrentTime() const {
    if (timeOverrideActive_) return timeOverride_;
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

// ============================================================
// Private Helpers
// ============================================================

bool StorageManager::isSystemOwner(const std::string& owner) const {
    return owner == "system" || owner == "root" || owner == "server";
}

void StorageManager::recordEvent(StorageEventType type, StorageResult result,
                                  const std::string& volumeId, const std::string& appId,
                                  const std::string& message) {
    StorageEvent event;
    event.type = type;
    event.result = result;
    event.volumeId = volumeId;
    event.appId = appId;
    event.message = message;
    event.timestamp = getCurrentTime();

    events_.push_back(event);
    if (events_.size() > 512) {
        events_.erase(events_.begin());
    }

    if (events_.size() > static_cast<size_t>(stats_.byEventType[static_cast<int>(type)])) {
        // Just increment
    }
    stats_.byEventType[static_cast<int>(type) % 16]++;
    stats_.byResult[static_cast<int>(result) % 16]++;

    // Don't add NO_HISTORY events to history
    if (!(appPolicies_.count(appId) && (appPolicies_.at(appId).privacyFlags & STORAGE_PRIVACY_NO_HISTORY))) {
        history_.push_back(event);
        trimHistory();
    }

    lastAccessTime_ = event.timestamp;

    // Track active storage users for privacy indicator
    if (!appId.empty() && !isSystemOwner(appId)) {
        if (std::find(activeUsers_.begin(), activeUsers_.end(), appId) == activeUsers_.end()) {
            activeUsers_.push_back(appId);
        }
    }

    // Update indicator
    updateIndicator();

    // Notify callback
    if (eventCallback_) {
        eventCallback_(event);
    }
}

std::string StorageManager::fnv1aHash(const std::string& input) const {
    uint64_t hash = 14695981039346656037ULL;
    for (char c : input) {
        hash ^= static_cast<uint8_t>(c);
        hash *= 1099511628211ULL;
    }
    return "vol_" + std::to_string(hash % 1000000);
}

void StorageManager::notifyAccessCallback(const std::string& appId, StorageOpType op, bool granted) {
    if (accessCallback_) {
        accessCallback_(appId, op, granted);
    }
}

void StorageManager::logToServer(const std::string& message, bool isWarning) const {
    if (!logServer_) return;
    if (isWarning) {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "StorageManager");
    } else {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "StorageManager");
    }
}

void StorageManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("StorageManager", "StorageManager", 0, reason);
}

void StorageManager::updateIndicator() {
    bool shouldActivate = !activeUsers_.empty();
    if (shouldActivate != indicatorActive_) {
        indicatorActive_ = shouldActivate;
        stats_.indicatorToggleCount++;
        recordEvent(StorageEventType::INDICATOR_ON, StorageResult::SUCCESS, "", "", "Indicator toggled");
    }
}

void StorageManager::trimHistory() {
    if (history_.size() > 1000) {
        history_.erase(history_.begin(), history_.begin() + (history_.size() - 1000));
    }
}

// ============================================================
// String Helpers
// ============================================================

const char* StorageManager::resultToString(StorageResult r) {
    switch (r) {
        case StorageResult::SUCCESS: return "SUCCESS";
        case StorageResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case StorageResult::NOT_FOUND: return "NOT_FOUND";
        case StorageResult::ALREADY_MOUNTED: return "ALREADY_MOUNTED";
        case StorageResult::NOT_MOUNTED: return "NOT_MOUNTED";
        case StorageResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case StorageResult::BAD_STATE: return "BAD_STATE";
        case StorageResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case StorageResult::INSUFFICIENT_SPACE: return "INSUFFICIENT_SPACE";
        case StorageResult::QUOTA_EXCEEDED: return "QUOTA_EXCEEDED";
        case StorageResult::READ_ONLY_MODE: return "READ_ONLY_MODE";
        case StorageResult::CHECKSUM_FAILED: return "CHECKSUM_FAILED";
        case StorageResult::CORRUPTED: return "CORRUPTED";
        case StorageResult::NOT_EMPTY: return "NOT_EMPTY";
        case StorageResult::TOO_MANY_OPEN_FILES: return "TOO_MANY_OPEN_FILES";
        case StorageResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::volumeTypeToString(VolumeType t) {
    switch (t) {
        case VolumeType::INTERNAL: return "INTERNAL";
        case VolumeType::EXTERNAL: return "EXTERNAL";
        case VolumeType::USB: return "USB";
        case VolumeType::CACHE: return "CACHE";
        case VolumeType::APP_PRIVATE: return "APP_PRIVATE";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::volumeStateToString(VolumeState s) {
    switch (s) {
        case VolumeState::UNMOUNTED: return "UNMOUNTED";
        case VolumeState::MOUNTING: return "MOUNTING";
        case VolumeState::MOUNTED: return "MOUNTED";
        case VolumeState::READ_ONLY: return "READ_ONLY";
        case VolumeState::CHECKING: return "CHECKING";
        case VolumeState::ERROR_STATE: return "ERROR_STATE";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::fileTypeToString(FileType t) {
    switch (t) {
        case FileType::UNKNOWN: return "UNKNOWN";
        case FileType::FILE: return "FILE";
        case FileType::DIRECTORY: return "DIRECTORY";
        case FileType::SYMLINK: return "SYMLINK";
        case FileType::DEVICE: return "DEVICE";
        case FileType::SOCKET: return "SOCKET";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::permissionToString(StoragePermission p) {
    switch (p) {
        case StoragePermission::DENY: return "DENY";
        case StoragePermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case StoragePermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case StoragePermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::privacyModeToString(StoragePrivacyMode m) {
    switch (m) {
        case StoragePrivacyMode::FULL: return "FULL";
        case StoragePrivacyMode::REDACTED: return "REDACTED";
        case StoragePrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::eventTypeToString(StorageEventType e) {
    switch (e) {
        case StorageEventType::STATE_CHANGED: return "STATE_CHANGED";
        case StorageEventType::VOLUME_MOUNTED: return "VOLUME_MOUNTED";
        case StorageEventType::VOLUME_UNMOUNTED: return "VOLUME_UNMOUNTED";
        case StorageEventType::VOLUME_CHECKED: return "VOLUME_CHECKED";
        case StorageEventType::VOLUME_FORMATTED: return "VOLUME_FORMATTED";
        case StorageEventType::FILE_CREATED: return "FILE_CREATED";
        case StorageEventType::FILE_DELETED: return "FILE_DELETED";
        case StorageEventType::FILE_RENAMED: return "FILE_RENAMED";
        case StorageEventType::QUOTA_EXCEEDED: return "QUOTA_EXCEEDED";
        case StorageEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case StorageEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case StorageEventType::INDICATOR_ON: return "INDICATOR_ON";
        case StorageEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case StorageEventType::MOCK_SET: return "MOCK_SET";
        case StorageEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::fsTypeToString(FilesystemType f) {
    switch (f) {
        case FilesystemType::UNKNOWN: return "UNKNOWN";
        case FilesystemType::EXT4: return "EXT4";
        case FilesystemType::F2FS: return "F2FS";
        case FilesystemType::FAT32: return "FAT32";
        case FilesystemType::EXFAT: return "EXFAT";
        case FilesystemType::TMPFS: return "TMPFS";
        case FilesystemType::OVERLAY: return "OVERLAY";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::opTypeToString(StorageOpType o) {
    switch (o) {
        case StorageOpType::READ: return "READ";
        case StorageOpType::WRITE: return "WRITE";
        case StorageOpType::DELETE: return "DELETE";
        case StorageOpType::CREATE: return "CREATE";
        case StorageOpType::RENAME: return "RENAME";
        case StorageOpType::LIST: return "LIST";
        case StorageOpType::STAT: return "STAT";
        default: return "UNKNOWN";
    }
}

const char* StorageManager::accessModeToString(FileAccessMode m) {
    switch (m) {
        case FileAccessMode::READ: return "READ";
        case FileAccessMode::WRITE: return "WRITE";
        case FileAccessMode::READ_WRITE: return "READ_WRITE";
        case FileAccessMode::APPEND: return "APPEND";
        default: return "UNKNOWN";
    }
}

// Parsers
StorageResult StorageManager::stringToResult(const std::string& s) {
    if (s == "SUCCESS") return StorageResult::SUCCESS;
    if (s == "NOT_INITIALIZED") return StorageResult::NOT_INITIALIZED;
    if (s == "NOT_FOUND") return StorageResult::NOT_FOUND;
    if (s == "ALREADY_MOUNTED") return StorageResult::ALREADY_MOUNTED;
    if (s == "NOT_MOUNTED") return StorageResult::NOT_MOUNTED;
    if (s == "PERMISSION_DENIED") return StorageResult::PERMISSION_DENIED;
    if (s == "BAD_STATE") return StorageResult::BAD_STATE;
    if (s == "INVALID_PARAMETER") return StorageResult::INVALID_PARAMETER;
    if (s == "INSUFFICIENT_SPACE") return StorageResult::INSUFFICIENT_SPACE;
    if (s == "QUOTA_EXCEEDED") return StorageResult::QUOTA_EXCEEDED;
    if (s == "READ_ONLY_MODE") return StorageResult::READ_ONLY_MODE;
    if (s == "CHECKSUM_FAILED") return StorageResult::CHECKSUM_FAILED;
    if (s == "CORRUPTED") return StorageResult::CORRUPTED;
    if (s == "NOT_EMPTY") return StorageResult::NOT_EMPTY;
    if (s == "TOO_MANY_OPEN_FILES") return StorageResult::TOO_MANY_OPEN_FILES;
    if (s == "SIMULATED_FAILURE") return StorageResult::SIMULATED_FAILURE;
    return StorageResult::SUCCESS;
}

VolumeType StorageManager::stringToVolumeType(const std::string& s) {
    if (s == "INTERNAL") return VolumeType::INTERNAL;
    if (s == "EXTERNAL") return VolumeType::EXTERNAL;
    if (s == "USB") return VolumeType::USB;
    if (s == "CACHE") return VolumeType::CACHE;
    if (s == "APP_PRIVATE") return VolumeType::APP_PRIVATE;
    return VolumeType::INTERNAL;
}

FilesystemType StorageManager::stringToFilesystemType(const std::string& s) {
    if (s == "UNKNOWN") return FilesystemType::UNKNOWN;
    if (s == "EXT4") return FilesystemType::EXT4;
    if (s == "F2FS") return FilesystemType::F2FS;
    if (s == "FAT32") return FilesystemType::FAT32;
    if (s == "EXFAT") return FilesystemType::EXFAT;
    if (s == "TMPFS") return FilesystemType::TMPFS;
    if (s == "OVERLAY") return FilesystemType::OVERLAY;
    return FilesystemType::UNKNOWN;
}
