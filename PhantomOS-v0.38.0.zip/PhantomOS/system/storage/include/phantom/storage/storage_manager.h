#ifndef PHANTOM_STORAGE_MANAGER_H
#define PHANTOM_STORAGE_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <mutex>
#include <string>
#include <vector>

// Forward declarations
namespace phantom::logging { class LogServer; }
namespace phantom::crashreporter { class CrashReporter; }

using LogServer = phantom::logging::LogServer;
using CrashReporter = phantom::crashreporter::CrashReporter;

// ============================================================
// Volume Type
// ============================================================
enum class VolumeType : uint8_t {
    INTERNAL,       // Internal NVMe storage
    EXTERNAL,       // External SD card (stub)
    USB,            // USB-mounted storage
    CACHE,          // Cache partition
    APP_PRIVATE     // App-private storage (sandboxed)
};

// ============================================================
// Volume State
// ============================================================
enum class VolumeState : uint8_t {
    UNMOUNTED,
    MOUNTING,
    MOUNTED,
    READ_ONLY,
    CHECKING,
    ERROR_STATE
};

// ============================================================
// File Type
// ============================================================
enum class FileType : uint8_t {
    UNKNOWN,
    FILE,
    DIRECTORY,
    SYMLINK,
    DEVICE,
    SOCKET
};

// ============================================================
// File Access Mode
// ============================================================
enum class FileAccessMode : uint8_t {
    READ,
    WRITE,
    READ_WRITE,
    APPEND
};

// ============================================================
// Storage Permission
// ============================================================
enum class StoragePermission : uint8_t {
    DENY,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

// ============================================================
// Storage Privacy Mode
// ============================================================
enum class StoragePrivacyMode : uint8_t {
    FULL,
    REDACTED,
    METADATA_ONLY
};

// ============================================================
// Storage Privacy Flags (bitmask)
// ============================================================
static constexpr uint32_t STORAGE_PRIVACY_NONE                = 0x00;
static constexpr uint32_t STORAGE_PRIVACY_REQUIRE_FOREGROUND  = 0x01;
static constexpr uint32_t STORAGE_PRIVACY_NO_HISTORY          = 0x02;
static constexpr uint32_t STORAGE_PRIVACY_REDACT_PATHS        = 0x04;
static constexpr uint32_t STORAGE_PRIVACY_PSEUDONYMIZE        = 0x08;
static constexpr uint32_t STORAGE_PRIVACY_METADATA_ONLY      = 0x10;
static constexpr uint32_t STORAGE_PRIVACY_MOCK_ALLOWED       = 0x20;
static constexpr uint32_t STORAGE_PRIVACY_INDICATOR_REQUIRED = 0x40;
static constexpr uint32_t STORAGE_PRIVACY_ENCRYPTION_REQUIRED = 0x80;

// ============================================================
// Storage Result Codes
// ============================================================
enum class StorageResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    NOT_FOUND,
    ALREADY_MOUNTED,
    NOT_MOUNTED,
    PERMISSION_DENIED,
    BAD_STATE,
    INVALID_PARAMETER,
    INSUFFICIENT_SPACE,
    QUOTA_EXCEEDED,
    READ_ONLY_MODE,
    CHECKSUM_FAILED,
    CORRUPTED,
    NOT_EMPTY,
    TOO_MANY_OPEN_FILES,
    SIMULATED_FAILURE
};

// ============================================================
// Storage Event Types
// ============================================================
enum class StorageEventType : uint8_t {
    STATE_CHANGED,
    VOLUME_MOUNTED,
    VOLUME_UNMOUNTED,
    VOLUME_CHECKED,
    VOLUME_FORMATTED,
    FILE_CREATED,
    FILE_DELETED,
    FILE_RENAMED,
    QUOTA_EXCEEDED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    MOCK_SET,
    HISTORY_CLEARED
};

// ============================================================
// Storage Operation Types
// ============================================================
enum class StorageOpType : uint8_t {
    READ,
    WRITE,
    DELETE,
    CREATE,
    RENAME,
    LIST,
    STAT
};

// ============================================================
// Filesystem Type
// ============================================================
enum class FilesystemType : uint8_t {
    UNKNOWN,
    EXT4,
    F2FS,
    FAT32,
    EXFAT,
    TMPFS,
    OVERLAY
};

// ============================================================
// Data Structures
// ============================================================

struct StorageVolume {
    std::string id;
    std::string label;
    VolumeType type = VolumeType::INTERNAL;
    VolumeState state = VolumeState::UNMOUNTED;
    FilesystemType fsType = FilesystemType::EXT4;
    std::string mountPoint;
    uint64_t totalBytes = 0;
    uint64_t freeBytes = 0;
    uint64_t usedBytes = 0;
    bool encrypted = false;
    bool readOnly = false;
    bool removable = false;
    bool primary = false;
};

struct StorageFile {
    std::string name;
    std::string path;
    FileType type = FileType::FILE;
    uint64_t size = 0;
    uint64_t lastModified = 0;
    bool readable = true;
    bool writable = true;
    bool executable = false;
    bool hidden = false;
};

struct StoragePolicy {
    StoragePermission permission = StoragePermission::DENY;
    StoragePrivacyMode privacyMode = StoragePrivacyMode::FULL;
    uint32_t privacyFlags = STORAGE_PRIVACY_NONE;
    uint64_t quotaBytes = 0;
    bool allowExternal = false;
    bool allowCache = true;
    bool foreground = false;
    bool oneShotUsed = false;
};

struct StorageEvent {
    StorageEventType type = StorageEventType::STATE_CHANGED;
    StorageResult result = StorageResult::SUCCESS;
    std::string volumeId;
    std::string appId;
    std::string message;
    uint64_t timestamp = 0;
};

struct StorageStats {
    uint32_t volumeMounts = 0;
    uint32_t volumeUnmounts = 0;
    uint32_t volumeChecks = 0;
    uint32_t volumeFormats = 0;
    uint32_t filesCreated = 0;
    uint32_t filesDeleted = 0;
    uint32_t filesRenamed = 0;
    uint32_t quotaExceeded = 0;
    uint32_t permissionsChanged = 0;
    uint32_t privacyApplications = 0;
    uint32_t historyClears = 0;
    uint32_t totalFailures = 0;
    uint32_t indicatorToggleCount = 0;
    uint32_t mockSetups = 0;
    uint32_t byEventType[16] = {0};
    uint32_t byResult[16] = {0};
};

// ============================================================
// Callback Types
// ============================================================
using StorageEventCallback = std::function<void(const StorageEvent&)>;
using StorageAccessCallback = std::function<void(const std::string& appId, StorageOpType op, bool granted)>;

// ============================================================
// Storage Manager
// ============================================================

class StorageManager {
public:
    StorageManager();
    ~StorageManager();

    // ---- Lifecycle ----
    bool initialize();
    bool isInitialized() const;
    void shutdown();

    // ---- Volume Management ----
    StorageResult mountVolume(const StorageVolume& volume, const std::string& owner);
    StorageResult unmountVolume(const std::string& volumeId, const std::string& owner);
    StorageResult checkVolume(const std::string& volumeId, const std::string& owner);
    StorageResult formatVolume(const std::string& volumeId, FilesystemType fsType, const std::string& owner);
    StorageVolume getVolume(const std::string& volumeId) const;
    std::vector<StorageVolume> getAllVolumes() const;
    std::vector<StorageVolume> getMountedVolumes() const;
    size_t getVolumeCount() const;
    size_t getMountedVolumeCount() const;

    // ---- Storage Stats ----
    uint64_t getTotalBytes() const;
    uint64_t getFreeBytes() const;
    uint64_t getUsedBytes() const;
    uint64_t getCacheBytes() const;
    uint64_t getAppQuotaBytes(const std::string& appId) const;
    uint64_t getAppUsedBytes(const std::string& appId) const;
    StorageResult setAppQuota(const std::string& appId, uint64_t quotaBytes, const std::string& owner);

    // ---- File Operations ----
    StorageResult createFile(const std::string& path, const std::string& appId);
    StorageResult createDirectory(const std::string& path, const std::string& appId);
    StorageResult deleteFile(const std::string& path, const std::string& appId);
    StorageResult deleteDirectory(const std::string& path, const std::string& appId);
    StorageResult renameFile(const std::string& oldPath, const std::string& newPath, const std::string& appId);
    StorageFile getFile(const std::string& path, const std::string& appId);
    std::vector<StorageFile> listDirectory(const std::string& path, const std::string& appId);
    StorageResult setFileReadOnly(const std::string& path, bool readOnly, const std::string& appId);

    // ---- Per-App Policy ----
    StorageResult setAppStoragePolicy(const std::string& appId, StoragePermission permission,
                                       StoragePrivacyMode privacyMode,
                                       uint32_t privacyFlags = STORAGE_PRIVACY_NONE,
                                       uint64_t quotaBytes = 0, bool allowExternal = false,
                                       const std::string& owner = "system");
    StorageResult clearAppStoragePolicy(const std::string& appId, const std::string& owner);
    StorageResult setAppForeground(const std::string& appId, bool foreground);
    bool checkAppAccess(const std::string& appId) const;

    // ---- Identifier Access ----
    StorageResult getVolumeLabel(const std::string& volumeId, std::string& outLabel,
                                  const std::string& appId);
    StorageResult getVolumeInfo(const std::string& volumeId, StorageVolume& outVolume,
                                 const std::string& appId);

    // ---- Privacy ----
    std::string applyPrivacyTransform(const std::string& path, const std::string& appId) const;
    bool isIndicatorActive() const;
    std::vector<std::string> getActiveStorageUsers() const;
    uint64_t getLastAccessTime() const;

    // ---- Mock ----
    StorageResult setMockEnabled(bool enabled, const std::string& owner);
    bool isMockEnabled() const;
    StorageResult setMockVolume(const StorageVolume& volume);
    StorageResult addMockFile(const std::string& path, FileType type, uint64_t size);
    StorageResult removeMockFile(const std::string& path);

    // ---- History ----
    std::vector<StorageEvent> getHistory(const std::string& appId, size_t limit = 0) const;
    StorageResult clearHistory(const std::string& owner);
    StorageResult clearAppHistory(const std::string& appId, const std::string& owner);

    // ---- Events ----
    std::vector<StorageEvent> getEvents(size_t limit = 0) const;
    std::vector<StorageEvent> getEventsByType(StorageEventType type, size_t limit = 0) const;
    StorageResult clearEvents(const std::string& owner);
    void setEventCallback(StorageEventCallback callback);
    void setAccessCallback(StorageAccessCallback callback);

    // ---- Stats ----
    StorageStats getStats() const;
    StorageResult resetStats(const std::string& owner);

    // ---- Failure Simulation ----
    void setFailNextOperation(bool fail) { failNextOperation_ = fail; }
    bool getFailNextOperation() const { return failNextOperation_; }

    // ---- Time Injection ----
    void setCurrentTimeForTesting(uint64_t time) { timeOverride_ = time; timeOverrideActive_ = true; }
    void clearTimeOverride() { timeOverrideActive_ = false; }
    uint64_t getCurrentTime() const;

    // ---- LogServer / CrashReporter Integration ----
    void setLogServer(LogServer* server) { logServer_ = server; }
    void setCrashReporter(CrashReporter* reporter) { crashReporter_ = reporter; }

    // ---- String Helpers ----
    static const char* resultToString(StorageResult r);
    static const char* volumeTypeToString(VolumeType t);
    static const char* volumeStateToString(VolumeState s);
    static const char* fileTypeToString(FileType t);
    static const char* permissionToString(StoragePermission p);
    static const char* privacyModeToString(StoragePrivacyMode m);
    static const char* eventTypeToString(StorageEventType e);
    static const char* fsTypeToString(FilesystemType f);
    static const char* opTypeToString(StorageOpType o);
    static const char* accessModeToString(FileAccessMode m);

    // Parsers
    static StorageResult stringToResult(const std::string& s);
    static VolumeType stringToVolumeType(const std::string& s);
    static FilesystemType stringToFilesystemType(const std::string& s);

private:
    bool initialized_ = false;
    bool failNextOperation_ = false;
    bool mockEnabled_ = false;
    bool indicatorActive_ = false;
    uint64_t timeOverride_ = 0;
    bool timeOverrideActive_ = false;

    std::map<std::string, StorageVolume> volumes_;
    std::map<std::string, std::map<std::string, StorageFile>> mockFiles_; // path -> appId -> file
    std::map<std::string, StoragePolicy> appPolicies_;
    std::map<std::string, uint64_t> appUsedBytes_;
    std::vector<StorageEvent> history_;
    std::vector<StorageEvent> events_;
    StorageStats stats_;
    std::vector<std::string> activeUsers_;
    uint64_t lastAccessTime_ = 0;

    StorageEventCallback eventCallback_;
    StorageAccessCallback accessCallback_;

    LogServer* logServer_ = nullptr;
    CrashReporter* crashReporter_ = nullptr;
    mutable std::mutex mutex_;

    bool isSystemOwner(const std::string& owner) const;
    void recordEvent(StorageEventType type, StorageResult result,
                     const std::string& volumeId, const std::string& appId,
                     const std::string& message);
    std::string fnv1aHash(const std::string& input) const;
    void notifyAccessCallback(const std::string& appId, StorageOpType op, bool granted);
    void logToServer(const std::string& message, bool isWarning = false) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updateIndicator();
    void trimHistory();
};

#endif // PHANTOM_STORAGE_MANAGER_H
