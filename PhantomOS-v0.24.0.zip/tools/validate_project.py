#!/usr/bin/env python3
"""
Phantom OS - Project Structure Validator v0.23.0

Validates project structure, required files, documentation,
and v0.23.0 C++ components.
"""

import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

REQUIRED_DIRS = [
    "android", "kernel", "boot", "hal", "drivers", "framework",
    "system", "gui", "apps", "libraries", "sdk", "tools", "tests", "docs",
    "framework/include/phantom", "framework/src",
    "libraries/privacy/include/phantom/privacy", "libraries/privacy/src",
    "libraries/config/include/phantom/config", "libraries/config/src",
    "libraries/i18n/include/phantom/i18n", "libraries/i18n/src",
    "libraries/uri/include/phantom/uri", "libraries/uri/src",
    "libraries/security/include/phantom/security", "libraries/security/src",
    "libraries/ipc/include/phantom/ipc", "libraries/ipc/src",
    "libraries/package_manager/include/phantom/package_manager", "libraries/package_manager/src",
    "libraries/linux_compat/include/phantom/linux_compat", "libraries/linux_compat/src",
    "hal/include/phantom/hal", "hal/mock",
    "system/src", "tests/unit",
    "gui/include/phantom/gui", "gui/src",
    "gui/include/phantom/gui/widgets", "gui/src/widgets",
    # v0.10.0 Settings App
    "apps/settings/include/phantom/settings", "apps/settings/src",
    # v0.11.0 Terminal App
    "apps/terminal/include/phantom/terminal", "apps/terminal/src",
    # v0.12.0 File Manager
    "apps/filemanager/include/phantom/filemanager", "apps/filemanager/src",
    # v0.13.0 System Monitor
    "apps/sysmon/include/phantom/sysmon", "apps/sysmon/src",
    # v0.14.0 NIDS
    "security/nids/include/phantom/nids", "security/nids/src",
    # v0.15.0 System Server
    "system/server/include/phantom/sysserver", "system/server/src",
    # v0.16.0 Driver Framework
    "drivers/framework/include/phantom/drivers", "drivers/framework/src",
    # v0.17.0 Log Server
    "system/logging/include/phantom/logging", "system/logging/src",
    # v0.18.0 Notification Manager + v0.19.0 Crash Reporter + v0.20.0 Update Manager
    "system/notifications/include/phantom/notifications", "system/notifications/src",
    "system/crashreporter/include/phantom/crashreporter", "system/crashreporter/src",
    "system/updatemanager/include/phantom/updatemanager", "system/updatemanager/src",
    # v0.21.0 Backup & Restore Manager
    "system/backup/include/phantom/backup", "system/backup/src",
    # v0.22.0 Recovery Mode Manager
    "system/recovery/include/phantom/recovery", "system/recovery/src",
    # v0.23.0 KeyStore / Crypto Service
    "system/keystore/include/phantom/keystore", "system/keystore/src",
    # v0.24.0 Device Lock / Authentication Manager
    "system/auth/include/phantom/auth", "system/auth/src",
]

REQUIRED_FILES = [
    "README.md", "TODO.md", "Erledigt.md", "Getestet.md", "install.md", "LICENSE",
    "CMakeLists.txt",
]

REQUIRED_DOCS = [
    "docs/architecture.md",
    "docs/hardware-iphone-x.md",
    "docs/privacy.md",
    "docs/privacy-architecture.md",
    "docs/data-flows.md",
    "docs/threat-model.md",
    "docs/security-architecture.md",
    "docs/android-compatibility.md",
    "docs/google-play-compatibility.md",
    "docs/roadmap.md",
    "docs/phase-0-development-environment.md",
]

# v0.4.0 C++ components
REQUIRED_CPP_FILES = [
    "hal/include/phantom/hal/hal_types.h",
    "hal/include/phantom/hal/hal_interfaces.h",
    "hal/mock/mock_hal.cpp",
    "hal/mock/mock_hal_factory.h",
    "framework/include/phantom/service.h",
    "framework/include/phantom/service_manager.h",
    "framework/src/service_manager.cpp",
    "libraries/privacy/include/phantom/privacy/permission.h",
    "libraries/privacy/src/permission.cpp",
    "libraries/privacy/include/phantom/privacy/permission_manager.h",
    "libraries/privacy/src/permission_manager.cpp",
    "libraries/privacy/include/phantom/privacy/identity_manager.h",
    "libraries/privacy/src/identity_manager.cpp",
    "libraries/privacy/include/phantom/privacy/data_sanitizer.h",
    "libraries/privacy/src/data_sanitizer.cpp",
    "system/src/mock_runtime.cpp",
    # v0.3.0 GUI components
    "gui/include/phantom/gui/geometry.h",
    "gui/include/phantom/gui/color.h",
    "gui/include/phantom/gui/framebuffer.h",
    "gui/src/framebuffer.cpp",
    "gui/include/phantom/gui/surface.h",
    "gui/src/surface.cpp",
    "gui/include/phantom/gui/window.h",
    "gui/src/window.cpp",
    "gui/include/phantom/gui/window_manager.h",
    "gui/src/window_manager.cpp",
    "gui/include/phantom/gui/compositor.h",
    "gui/src/compositor.cpp",
    "gui/include/phantom/gui/input_dispatcher.h",
    "gui/src/input_dispatcher.cpp",
    # v0.4.0 GUI components
    "gui/include/phantom/gui/bitmap_font.h",
    "gui/src/bitmap_font.cpp",
    "gui/include/phantom/gui/widget.h",
    "gui/src/widget.cpp",
    "gui/include/phantom/gui/layout.h",
    "gui/src/layout.cpp",
    "gui/include/phantom/gui/widgets/widgets.h",
    "gui/src/widgets/widgets.cpp",
    # v0.4.0 System libraries
    "libraries/config/include/phantom/config/config.h",
    "libraries/config/src/config.cpp",
    "libraries/i18n/include/phantom/i18n/localization.h",
    "libraries/i18n/src/localization.cpp",
    "libraries/uri/include/phantom/uri/uri_parser.h",
    "libraries/uri/src/uri_parser.cpp",
    "libraries/security/include/phantom/security/sandbox.h",
    "libraries/security/src/sandbox.cpp",
    # v0.5.0 GUI components
    "gui/include/phantom/gui/multi_line_text.h",
    "gui/src/multi_line_text.cpp",
    "gui/include/phantom/gui/extended_layout.h",
    "gui/src/extended_layout.cpp",
    "gui/include/phantom/gui/widgets/extended_widgets.h",
    "gui/src/widgets/extended_widgets.cpp",
    # v0.6.0 GUI components
    "gui/include/phantom/gui/animation.h",
    "gui/src/animation.cpp",
    # v0.6.0 Theme System
    "gui/include/phantom/gui/theme.h",
    "gui/src/theme.cpp",
    # v0.7.0 Framework components
    "framework/include/phantom/app_lifecycle.h",
    "framework/src/app_lifecycle.cpp",
    # v0.7.0 IPC components
    "libraries/ipc/include/phantom/ipc/message.h",
    "libraries/ipc/include/phantom/ipc/message_bus.h",
    "libraries/ipc/src/message_bus.cpp",
]

REQUIRED_TESTS = [
    "tests/test_project_structure.py",
    "tests/unit/test_permission.cpp",
    "tests/unit/test_permission_manager.cpp",
    "tests/unit/test_identity.cpp",
    "tests/unit/test_data_sanitizer.cpp",
    "tests/unit/test_service_manager.cpp",
    "tests/unit/test_hal_mock.cpp",
    "tests/unit/test_gui_geometry.cpp",
    "tests/unit/test_framebuffer.cpp",
    "tests/unit/test_window_manager.cpp",
    "tests/unit/test_compositor.cpp",
    "tests/unit/test_input_dispatcher.cpp",
    # v0.4.0 tests
    "tests/unit/test_bitmap_font.cpp",
    "tests/unit/test_widgets.cpp",
    "tests/unit/test_layout.cpp",
    "tests/unit/test_config.cpp",
    "tests/unit/test_i18n.cpp",
    "tests/unit/test_uri.cpp",
    "tests/unit/test_sandbox.cpp",
    # v0.5.0 tests
    "tests/unit/test_multi_line_text.cpp",
    "tests/unit/test_extended_widgets.cpp",
    "tests/unit/test_extended_layouts.cpp",
    # v0.6.0 tests
    "tests/unit/test_animation.cpp",
    # v0.6.0 Theme System tests
    "tests/unit/test_theme.cpp",
    # v0.8.0 Package Manager components
    "libraries/package_manager/include/phantom/package_manager/package.h",
    "libraries/package_manager/include/phantom/package_manager/package_manager.h",
    "libraries/package_manager/src/package_manager.cpp",
    # v0.9.0 Linux Compatibility Layer components
    "libraries/linux_compat/include/phantom/linux_compat/linux_program.h",
    "libraries/linux_compat/include/phantom/linux_compat/program_executor.h",
    "libraries/linux_compat/src/program_executor.cpp",

    # v0.7.0 tests
    "tests/unit/test_app_lifecycle.cpp",
    "tests/unit/test_ipc.cpp",
    "tests/unit/test_package_manager.cpp",
    "tests/unit/test_linux_compat.cpp",
    # v0.10.0 Settings App components
    "apps/settings/include/phantom/settings/settings_app.h",
    "apps/settings/src/settings_app.cpp",
    # v0.11.0 Terminal App components
    "apps/terminal/include/phantom/terminal/terminal_app.h",
    "apps/terminal/src/terminal_app.cpp",
    # v0.12.0 File Manager components
    "apps/filemanager/include/phantom/filemanager/file_manager.h",
    "apps/filemanager/src/file_manager.cpp",
    # v0.13.0 System Monitor components
    "apps/sysmon/include/phantom/sysmon/system_monitor.h",
    "apps/sysmon/src/system_monitor.cpp",
    # v0.14.0 NIDS components
    "security/nids/include/phantom/nids/nids_engine.h",
    "security/nids/src/nids_engine.cpp",
    # v0.15.0 System Server components
    "system/server/include/phantom/sysserver/system_server.h",
    "system/server/src/system_server.cpp",
    # v0.16.0 Driver Framework components
    "drivers/framework/include/phantom/drivers/driver_manager.h",
    "drivers/framework/src/driver_manager.cpp",
    # v0.17.0 Log Server components
    "system/logging/include/phantom/logging/log_server.h",
    "system/logging/src/log_server.cpp",
    # v0.10.0 Settings App test
    "tests/unit/test_settings_app.cpp",
    # v0.11.0 Terminal App test
    "tests/unit/test_terminal_app.cpp",
    # v0.12.0 File Manager test
    "tests/unit/test_file_manager.cpp",
    # v0.13.0 System Monitor test
    "tests/unit/test_system_monitor.cpp",
    # v0.14.0 NIDS test
    "tests/unit/test_nids_engine.cpp",
    # v0.15.0 System Server test
    "tests/unit/test_system_server.cpp",
    # v0.16.0 Driver Framework test
    "tests/unit/test_driver_framework.cpp",
    # v0.17.0 Log Server test
    "tests/unit/test_log_server.cpp",
    # v0.18.0 Notification Manager + v0.19.0 Crash Reporter + v0.20.0 Update Manager components and test
    "system/notifications/include/phantom/notifications/notification_manager.h",
    "system/notifications/src/notification_manager.cpp",
    "system/crashreporter/include/phantom/crashreporter/crash_reporter.h",
    "system/crashreporter/src/crash_reporter.cpp",
    "system/updatemanager/include/phantom/updatemanager/update_manager.h",
    "system/updatemanager/src/update_manager.cpp",
    # v0.21.0 Backup & Restore Manager components
    "system/backup/include/phantom/backup/backup_manager.h",
    "system/backup/src/backup_manager.cpp",
    # v0.22.0 Recovery Mode Manager components
    "system/recovery/include/phantom/recovery/recovery_manager.h",
    "system/recovery/src/recovery_manager.cpp",
    # v0.23.0 KeyStore / Crypto Service components
    "system/keystore/include/phantom/keystore/keystore_manager.h",
    "system/keystore/src/keystore_manager.cpp",
    # v0.24.0 Device Lock / Authentication Manager components
    "system/auth/include/phantom/auth/auth_manager.h",
    "system/auth/src/auth_manager.cpp",
    # v0.18.0 Notification Manager + v0.19.0 Crash Reporter + v0.20.0 Update Manager test
    "tests/unit/test_notification_manager.cpp",
    "tests/unit/test_crash_reporter.cpp",
    "tests/unit/test_update_manager.cpp",
    # v0.21.0 Backup & Restore Manager test
    "tests/unit/test_backup_manager.cpp",
    # v0.22.0 Recovery Mode Manager test
    "tests/unit/test_recovery_manager.cpp",
    # v0.23.0 KeyStore / Crypto Service test
    "tests/unit/test_keystore_manager.cpp",
    # v0.24.0 Device Lock / Authentication Manager test
    "tests/unit/test_auth_manager.cpp",
]

REQUIRED_TOOLS = [
    "tools/validate_project.py",
    "tools/build.sh",
]

ARCH_REQUIRED_SECTIONS = [
    "Overview", "System Architecture", "Kernel", "AOSP", "Android Runtime",
    "Phantom Framework", "Privacy Layer", "Security Layer", "Phantom HAL",
    "GUI", "App System", "Google Play", "Update System", "Hardware",
    "Data Flow", "Threat Model", "Privacy Model", "Development Environment",
    "Test Strategy", "Roadmap", "Risks",
]


def check_directory_exists(path):
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isdir(full_path):
        return True, f"  [PASS] Directory: {path}"
    else:
        return False, f"  [FAIL] Directory missing: {path}"


def check_file_exists(path):
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isfile(full_path):
        size = os.path.getsize(full_path)
        if size > 0:
            return True, f"  [PASS] File ({size}B): {path}"
        else:
            return False, f"  [FAIL] File empty: {path}"
    else:
        return False, f"  [FAIL] File missing: {path}"


def check_doc_sections(path, required_sections):
    full_path = os.path.join(PROJECT_ROOT, path)
    if not os.path.isfile(full_path):
        return False, f"  [FAIL] Document missing: {path}"
    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()
    missing = [s for s in required_sections if s.lower() not in content.lower()]
    if missing:
        return False, f"  [FAIL] {path} missing: {', '.join(missing)}"
    else:
        return True, f"  [PASS] {path} has all required sections"


def main():
    print("=" * 60)
    print("  Phantom OS v0.23.0 - Project Validation")
    print("=" * 60)
    print()

    all_passed = True
    errors = []

    # Directories
    print("Checking directories...")
    for d in REQUIRED_DIRS:
        passed, msg = check_directory_exists(d)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing directory: {d}")
    print()

    # Required files
    print("Checking required files...")
    for f in REQUIRED_FILES:
        passed, msg = check_file_exists(f)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing file: {f}")
    print()

    # Documentation
    print("Checking documentation...")
    for doc in REQUIRED_DOCS:
        passed, msg = check_file_exists(doc)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing doc: {doc}")
    print()

    # C++ components
    print("Checking C++ components (v0.21.0)...")
    for f in REQUIRED_CPP_FILES:
        passed, msg = check_file_exists(f)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing C++ file: {f}")
    print()

    # Architecture sections
    print("Checking architecture document sections...")
    passed, msg = check_doc_sections("docs/architecture.md", ARCH_REQUIRED_SECTIONS)
    print(msg)
    if not passed:
        all_passed = False
        errors.append("Architecture doc missing sections")
    print()

    # Tests
    print("Checking test files...")
    for t in REQUIRED_TESTS:
        passed, msg = check_file_exists(t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing test: {t}")
    print()

    # Tools
    print("Checking tools...")
    for t in REQUIRED_TOOLS:
        passed, msg = check_file_exists(t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing tool: {t}")
    print()

    # Summary
    print("=" * 60)
    if all_passed:
        print("  RESULT: ALL CHECKS PASSED")
    else:
        print(f"  RESULT: {len(errors)} ERRORS FOUND")
        for e in errors:
            print(f"    - {e}")
    print("=" * 60)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
