/*
 * Phantom OS - USB Manager Tests
 * v0.37.0
 *
 * Comprehensive unit tests for the USB Manager.
 */

#include "phantom/usb/usb_manager.h"
#include <cassert>
#include <cstdio>
#include <algorithm>

using namespace phantom::usb;

static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

#define test(name, condition) do { \
    tests_run++; \
    if (condition) { tests_passed++; printf("  [PASS] %s\n", name); } \
    else { tests_failed++; printf("  [FAIL] %s\n", name); } \
} while (0)

// ============================================================
// Test 1: Lifecycle
// ============================================================
static void testLifecycle() {
    printf("\n=== Test 1: Lifecycle ===\n");
    UsbManager mgr;
    test("not initialized", !mgr.isInitialized());
    test("initialize SUCCESS", mgr.initialize() == UsbResult::SUCCESS);
    test("initialized", mgr.isInitialized());
    test("initialize again ALREADY", mgr.initialize() == UsbResult::ALREADY_INITIALIZED);
    test("shutdown SUCCESS", mgr.shutdown() == UsbResult::SUCCESS);
    test("not initialized after shutdown", !mgr.isInitialized());
    test("shutdown again NOT_INITIALIZED", mgr.shutdown() == UsbResult::NOT_INITIALIZED);
    test("reinitialize after shutdown SUCCESS", mgr.initialize() == UsbResult::SUCCESS);
    test("initialized after reinit", mgr.isInitialized());
    mgr.shutdown();
}

// ============================================================
// Test 2: Port State
// ============================================================
static void testPortState() {
    printf("\n=== Test 2: Port State ===\n");
    UsbManager mgr;
    mgr.initialize();
    test("initial state DISCONNECTED", mgr.getPortState() == UsbState::DISCONNECTED);
    test("enablePort SUCCESS", mgr.enablePort() == UsbResult::SUCCESS);
    test("state CONNECTED", mgr.getPortState() == UsbState::CONNECTED);
    test("isPortEnabled", mgr.isPortEnabled());
    test("enablePort again BAD_STATE", mgr.enablePort() == UsbResult::BAD_STATE);
    test("disablePort SUCCESS", mgr.disablePort() == UsbResult::SUCCESS);
    test("state DISCONNECTED", mgr.getPortState() == UsbState::DISCONNECTED);
    test("disablePort again BAD_STATE", mgr.disablePort() == UsbResult::BAD_STATE);
    test("stats stateChanges >= 2", mgr.getStats().stateChanges >= 2);
    test("enablePort non-system PERMISSION_DENIED",
         mgr.enablePort("app1") == UsbResult::PERMISSION_DENIED);
    test("disablePort non-system PERMISSION_DENIED",
         mgr.disablePort("app1") == UsbResult::PERMISSION_DENIED);
    mgr.shutdown();
}

// ============================================================
// Test 3: Mode / Role
// ============================================================
static void testModeRole() {
    printf("\n=== Test 3: Mode / Role ===\n");
    UsbManager mgr;
    mgr.initialize();

    test("initial mode NONE", mgr.getMode() == UsbMode::NONE);
    test("initial role DEVICE", mgr.getRole() == UsbRole::DEVICE);

    test("setMode when DISCONNECTED NOT_CONNECTED",
         mgr.setMode(UsbMode::MTP) == UsbResult::NOT_CONNECTED);
    test("setRole when DISCONNECTED NOT_CONNECTED",
         mgr.setRole(UsbRole::HOST) == UsbResult::NOT_CONNECTED);

    mgr.enablePort();

    test("setMode MTP SUCCESS", mgr.setMode(UsbMode::MTP) == UsbResult::SUCCESS);
    test("mode MTP", mgr.getMode() == UsbMode::MTP);
    test("setMode MTP again BAD_STATE",
         mgr.setMode(UsbMode::MTP) == UsbResult::BAD_STATE);
    test("setMode CHARGING_ONLY SUCCESS",
         mgr.setMode(UsbMode::CHARGING_ONLY) == UsbResult::SUCCESS);
    test("mode CHARGING_ONLY", mgr.getMode() == UsbMode::CHARGING_ONLY);

    test("setRole HOST SUCCESS", mgr.setRole(UsbRole::HOST) == UsbResult::SUCCESS);
    test("role HOST", mgr.getRole() == UsbRole::HOST);
    test("setRole HOST again BAD_STATE",
         mgr.setRole(UsbRole::HOST) == UsbResult::BAD_STATE);
    test("setRole OTG SUCCESS", mgr.setRole(UsbRole::OTG) == UsbResult::SUCCESS);
    test("role OTG", mgr.getRole() == UsbRole::OTG);

    test("setMode non-system PERMISSION_DENIED",
         mgr.setMode(UsbMode::PTP, "app1") == UsbResult::PERMISSION_DENIED);
    test("setRole non-system PERMISSION_DENIED",
         mgr.setRole(UsbRole::DEVICE, "app1") == UsbResult::PERMISSION_DENIED);

    test("stats modeChanges >= 2", mgr.getStats().modeChanges >= 2);
    test("stats roleChanges >= 2", mgr.getStats().roleChanges >= 2);

    mgr.shutdown();
}

// ============================================================
// Test 4: Device Management
// ============================================================
static void testDeviceManagement() {
    printf("\n=== Test 4: Device Management ===\n");
    UsbManager mgr;
    mgr.initialize();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test Device";
    dev.vendorId = 0x1234;
    dev.productId = 0x5678;
    dev.deviceClass = UsbDeviceClass::STORAGE;
    dev.serial = "SN001";
    dev.trusted = true;

    test("connectDevice when DISCONNECTED NOT_CONNECTED",
         mgr.connectDevice(dev) == UsbResult::NOT_CONNECTED);

    mgr.enablePort();

    test("connectDevice SUCCESS", mgr.connectDevice(dev) == UsbResult::SUCCESS);
    test("deviceCount 1", mgr.getDeviceCount() == 1);
    test("connectedDeviceCount 1", mgr.getConnectedDeviceCount() == 1);

    test("connectDevice duplicate ALREADY_CONNECTED",
         mgr.connectDevice(dev) == UsbResult::ALREADY_CONNECTED);

    UsbDevice dev2;
    dev2.id = "dev2";
    dev2.name = "Test Device 2";
    dev2.deviceClass = UsbDeviceClass::HID;
    dev2.serial = "SN002";

    test("connectDevice dev2 SUCCESS", mgr.connectDevice(dev2) == UsbResult::SUCCESS);
    test("deviceCount 2", mgr.getDeviceCount() == 2);

    UsbDevice outDev;
    test("getDevice dev1 found", mgr.getDevice("dev1", outDev));
    test("getDevice name", outDev.name == "Test Device");
    test("getDevice serial", outDev.serial == "SN001");

    test("getDevice not found", !mgr.getDevice("nonexistent", outDev));

    auto allDevs = mgr.getAllDevices();
    test("getAllDevices size 2", allDevs.size() == 2);

    auto connDevs = mgr.getConnectedDevices();
    test("getConnectedDevices size 2", connDevs.size() == 2);

    test("disconnectDevice dev1 SUCCESS",
         mgr.disconnectDevice("dev1") == UsbResult::SUCCESS);
    test("deviceCount 1", mgr.getDeviceCount() == 1);

    test("disconnectDevice nonexistent DEVICE_NOT_FOUND",
         mgr.disconnectDevice("nonexistent") == UsbResult::DEVICE_NOT_FOUND);

    test("disconnectAllDevices SUCCESS",
         mgr.disconnectAllDevices() == UsbResult::SUCCESS);
    test("deviceCount 0", mgr.getDeviceCount() == 0);

    test("connectDevice empty id INVALID_PARAMETER",
         mgr.connectDevice(UsbDevice{}, "system") == UsbResult::INVALID_PARAMETER);

    test("connectDevice non-system PERMISSION_DENIED",
         mgr.connectDevice(dev, "app1") == UsbResult::PERMISSION_DENIED);

    // Capacity test
    mgr.disconnectAllDevices();
    for (uint32_t i = 0; i < USB_DEFAULT_MAX_DEVICES; ++i) {
        UsbDevice d;
        d.id = "capdev" + std::to_string(i);
        d.name = "CapDevice " + std::to_string(i);
        d.serial = "SN" + std::to_string(i);
        mgr.connectDevice(d);
    }
    UsbDevice extraDev;
    extraDev.id = "extra_dev";
    extraDev.name = "Extra Device";
    extraDev.serial = "SN_EXTRA";
    test("max devices CAPACITY_EXCEEDED",
         mgr.connectDevice(extraDev) == UsbResult::CAPACITY_EXCEEDED);

    mgr.shutdown();
}

// ============================================================
// Test 5: Transfers
// ============================================================
static void testTransfers() {
    printf("\n=== Test 5: Transfers ===\n");
    UsbManager mgr;
    mgr.initialize();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Storage Device";
    dev.deviceClass = UsbDeviceClass::STORAGE;
    dev.serial = "SN001";

    mgr.enablePort();
    mgr.connectDevice(dev);

    test("startTransfer SUCCESS",
         mgr.startTransfer("dev1", UsbTransferDirection::IN, 1024) == UsbResult::SUCCESS);
    test("transfersStarted >= 1", mgr.getStats().transfersStarted >= 1);

    auto activeTransfers = mgr.getActiveTransfers();
    test("getActiveTransfers size 1", activeTransfers.size() == 1);

    uint64_t transferId = activeTransfers[0].id;
    UsbTransfer outTransfer;
    test("getTransfer found", mgr.getTransfer(transferId, outTransfer));
    test("transfer state ACTIVE", outTransfer.state == UsbTransferState::ACTIVE);
    test("transfer bytesTotal 1024", outTransfer.bytesTotal == 1024);
    test("transfer direction IN", outTransfer.direction == UsbTransferDirection::IN);

    test("completeTransfer SUCCESS",
         mgr.completeTransfer(transferId) == UsbResult::SUCCESS);
    test("transfersCompleted >= 1", mgr.getStats().transfersCompleted >= 1);

    test("completeTransfer again BAD_STATE",
         mgr.completeTransfer(transferId) == UsbResult::BAD_STATE);

    // Test cancel
    mgr.startTransfer("dev1", UsbTransferDirection::OUT, 2048);
    auto active = mgr.getActiveTransfers();
    test("getActiveTransfers has new transfer", active.size() >= 1);
    uint64_t cancelId = active[0].id;

    test("cancelTransfer SUCCESS",
         mgr.cancelTransfer(cancelId) == UsbResult::SUCCESS);
    test("transfersCancelled >= 1", mgr.getStats().transfersCancelled >= 1);

    test("cancelTransfer again BAD_STATE",
         mgr.cancelTransfer(cancelId) == UsbResult::BAD_STATE);

    // Test fail
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 512);
    active = mgr.getActiveTransfers();
    uint64_t failId = active[0].id;
    test("failTransfer SUCCESS",
         mgr.failTransfer(failId) == UsbResult::SUCCESS);
    test("transfersFailed >= 1", mgr.getStats().transfersFailed >= 1);

    // Test error cases
    test("startTransfer empty deviceId INVALID_PARAMETER",
         mgr.startTransfer("", UsbTransferDirection::IN, 100) == UsbResult::INVALID_PARAMETER);
    test("startTransfer 0 bytes INVALID_PARAMETER",
         mgr.startTransfer("dev1", UsbTransferDirection::IN, 0) == UsbResult::INVALID_PARAMETER);
    test("startTransfer nonexistent device DEVICE_NOT_FOUND",
         mgr.startTransfer("nonexistent", UsbTransferDirection::IN, 100) == UsbResult::DEVICE_NOT_FOUND);
    test("startTransfer non-system PERMISSION_DENIED",
         mgr.startTransfer("dev1", UsbTransferDirection::IN, 100, "app1") == UsbResult::PERMISSION_DENIED);

    test("completeTransfer nonexistent DEVICE_NOT_FOUND",
         mgr.completeTransfer(99999) == UsbResult::DEVICE_NOT_FOUND);

    test("cancelTransfer nonexistent DEVICE_NOT_FOUND",
         mgr.cancelTransfer(99999) == UsbResult::DEVICE_NOT_FOUND);

    // Test all transfers
    auto allTransfers = mgr.getAllTransfers();
    test("getAllTransfers non-empty", allTransfers.size() > 0);

    // Disconnect device cancels active transfers
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 256);
    mgr.disconnectDevice("dev1");

    mgr.shutdown();
}

// ============================================================
// Test 6: Debugging
// ============================================================
static void testDebugging() {
    printf("\n=== Test 6: Debugging ===\n");
    UsbManager mgr;
    mgr.initialize();

    test("debugging initially disabled", !mgr.isDebuggingEnabled());

    test("enableDebugging when DISCONNECTED NOT_CONNECTED",
         mgr.enableDebugging() == UsbResult::NOT_CONNECTED);

    mgr.enablePort();

    test("enableDebugging SUCCESS", mgr.enableDebugging() == UsbResult::SUCCESS);
    test("debugging enabled", mgr.isDebuggingEnabled());
    test("enableDebugging again BAD_STATE",
         mgr.enableDebugging() == UsbResult::BAD_STATE);

    test("disableDebugging SUCCESS", mgr.disableDebugging() == UsbResult::SUCCESS);
    test("debugging disabled", !mgr.isDebuggingEnabled());
    test("disableDebugging again BAD_STATE",
         mgr.disableDebugging() == UsbResult::BAD_STATE);

    test("stats debuggingToggles >= 2", mgr.getStats().debuggingToggles >= 2);

    test("enableDebugging non-system PERMISSION_DENIED",
         mgr.enableDebugging("app1") == UsbResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test 7: Permissions / Policy
// ============================================================
static void testPermissions() {
    printf("\n=== Test 7: Permissions / Policy ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test Device";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    test("setAppUsbPolicy SUCCESS",
         mgr.setAppUsbPolicy("app1", UsbPermission::ALLOW_ALWAYS,
                             UsbPrivacyMode::FULL) == UsbResult::SUCCESS);

    UsbPolicy policy = mgr.getAppUsbPolicy("app1");
    test("policy permission ALLOW_ALWAYS",
         policy.permission == UsbPermission::ALLOW_ALWAYS);
    test("policy privacyMode FULL",
         policy.privacyMode == UsbPrivacyMode::FULL);

    test("checkAppAccess app1 allowed", mgr.checkAppAccess("app1"));
    test("checkAppAccess app2 denied", !mgr.checkAppAccess("app2"));

    // ALLOW_FOREGROUND
    mgr.setAppUsbPolicy("app2", UsbPermission::ALLOW_FOREGROUND,
                        UsbPrivacyMode::REDACTED);
    test("checkAppAccess app2 foreground false denied",
         !mgr.checkAppAccess("app2"));
    mgr.setAppForeground("app2", true);
    test("checkAppAccess app2 foreground true allowed",
         mgr.checkAppAccess("app2"));

    // ALLOW_ONCE
    mgr.setAppUsbPolicy("app3", UsbPermission::ALLOW_ONCE,
                        UsbPrivacyMode::FULL);
    test("checkAppAccess app3 ALLOW_ONCE before use",
         mgr.checkAppAccess("app3"));
    test("startTransfer app3 SUCCESS",
         mgr.startTransfer("dev1", UsbTransferDirection::IN, 100, "app3") == UsbResult::SUCCESS);
    test("checkAppAccess app3 ALLOW_ONCE after use",
         !mgr.checkAppAccess("app3"));

    // DENY
    mgr.setAppUsbPolicy("app4", UsbPermission::DENY, UsbPrivacyMode::FULL);
    test("checkAppAccess app4 DENY", !mgr.checkAppAccess("app4"));

    // Clear policy
    test("clearAppUsbPolicy app1 SUCCESS",
         mgr.clearAppUsbPolicy("app1") == UsbResult::SUCCESS);
    test("checkAppAccess app1 after clear denied",
         !mgr.checkAppAccess("app1"));

    test("clearAppUsbPolicy nonexistent DEVICE_NOT_FOUND",
         mgr.clearAppUsbPolicy("nonexistent") == UsbResult::DEVICE_NOT_FOUND);

    test("clearAppUsbPolicy non-system PERMISSION_DENIED",
         mgr.clearAppUsbPolicy("app2", "app3") == UsbResult::PERMISSION_DENIED);

    test("setAppUsbPolicy non-system PERMISSION_DENIED",
         mgr.setAppUsbPolicy("app5", UsbPermission::ALLOW_ALWAYS,
                             UsbPrivacyMode::FULL, 0, false, "app1") == UsbResult::PERMISSION_DENIED);

    test("setAppUsbPolicy empty appId INVALID_PARAMETER",
         mgr.setAppUsbPolicy("", UsbPermission::ALLOW_ALWAYS,
                             UsbPrivacyMode::FULL) == UsbResult::INVALID_PARAMETER);

    test("stats permissionsChanged >= 5", mgr.getStats().permissionsChanged >= 5);

    // Foreground preservation on policy update
    mgr.setAppUsbPolicy("app6", UsbPermission::ALLOW_FOREGROUND,
                        UsbPrivacyMode::FULL);
    mgr.setAppForeground("app6", true);
    mgr.setAppUsbPolicy("app6", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::REDACTED);
    UsbPolicy p = mgr.getAppUsbPolicy("app6");
    test("foreground preserved on update", p.foreground == true);

    mgr.shutdown();
}

// ============================================================
// Test 8: Identifier Access / Privacy Transform
// ============================================================
static void testIdentifierAccess() {
    printf("\n=== Test 8: Identifier Access / Privacy Transform ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test Device";
    dev.vendorId = 0x1234;
    dev.productId = 0x5678;
    dev.serial = "ABCDEF123456";
    dev.deviceClass = UsbDeviceClass::STORAGE;
    mgr.connectDevice(dev);

    // System access - full serial
    std::string serial;
    test("getDeviceSerial system SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "system") == UsbResult::SUCCESS);
    test("system gets full serial", serial == "ABCDEF123456");

    // FULL privacy mode
    mgr.setAppUsbPolicy("app1", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL);
    test("getDeviceSerial app1 FULL SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app1") == UsbResult::SUCCESS);
    test("app1 FULL gets full serial", serial == "ABCDEF123456");

    // REDACTED privacy mode
    mgr.setAppUsbPolicy("app2", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::REDACTED);
    test("getDeviceSerial app2 REDACTED SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app2") == UsbResult::SUCCESS);
    test("app2 REDACTED gets masked serial",
         serial != "ABCDEF123456" && serial.find("AB") == 0);

    // METADATA_ONLY privacy mode
    mgr.setAppUsbPolicy("app3", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::METADATA_ONLY);
    test("getDeviceSerial app3 METADATA_ONLY SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app3") == UsbResult::SUCCESS);
    test("app3 METADATA_ONLY gets REDACTED", serial == "[REDACTED]");

    // PSEUDONYMIZE flag
    mgr.setAppUsbPolicy("app4", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_PSEUDONYMIZE);
    test("getDeviceSerial app4 PSEUDONYMIZE SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app4") == UsbResult::SUCCESS);
    test("app4 PSEUDONYMIZE gets pseudonym",
         serial != "ABCDEF123456" && serial.find("PSUDO-") == 0);

    // REDACT_SERIAL flag
    mgr.setAppUsbPolicy("app5", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_REDACT_SERIAL);
    test("getDeviceSerial app5 REDACT_SERIAL SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app5") == UsbResult::SUCCESS);
    test("app5 REDACT_SERIAL gets masked", serial != "ABCDEF123456");

    // METADATA_ONLY flag
    mgr.setAppUsbPolicy("app6", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_METADATA_ONLY);
    test("getDeviceSerial app6 METADATA_ONLY flag SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app6") == UsbResult::SUCCESS);
    test("app6 METADATA_ONLY flag gets REDACTED", serial == "[REDACTED]");

    // DENY permission
    mgr.setAppUsbPolicy("app7", UsbPermission::DENY, UsbPrivacyMode::FULL);
    test("getDeviceSerial app7 DENY PERMISSION_DENIED",
         mgr.getDeviceSerial("dev1", serial, "app7") == UsbResult::PERMISSION_DENIED);

    // Nonexistent device
    test("getDeviceSerial nonexistent DEVICE_NOT_FOUND",
         mgr.getDeviceSerial("nonexistent", serial, "system") == UsbResult::DEVICE_NOT_FOUND);

    // getDeviceInfo with METADATA_ONLY
    UsbDevice outDev;
    mgr.setAppUsbPolicy("app8", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::METADATA_ONLY);
    test("getDeviceInfo app8 METADATA_ONLY SUCCESS",
         mgr.getDeviceInfo("dev1", outDev, "app8") == UsbResult::SUCCESS);
    test("app8 vendorId redacted", outDev.vendorId == 0);
    test("app8 productId redacted", outDev.productId == 0);
    test("app8 serial redacted", outDev.serial == "[REDACTED]");

    // getDeviceInfo with FULL
    mgr.setAppUsbPolicy("app9", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL);
    test("getDeviceInfo app9 FULL SUCCESS",
         mgr.getDeviceInfo("dev1", outDev, "app9") == UsbResult::SUCCESS);
    test("app9 vendorId preserved", outDev.vendorId == 0x1234);

    // ALLOW_FOREGROUND without foreground
    mgr.setAppUsbPolicy("app10", UsbPermission::ALLOW_FOREGROUND,
                        UsbPrivacyMode::FULL);
    test("getDeviceSerial app10 foreground false PERMISSION_DENIED",
         mgr.getDeviceSerial("dev1", serial, "app10") == UsbResult::PERMISSION_DENIED);
    mgr.setAppForeground("app10", true);
    test("getDeviceSerial app10 foreground true SUCCESS",
         mgr.getDeviceSerial("dev1", serial, "app10") == UsbResult::SUCCESS);

    mgr.shutdown();
}

// ============================================================
// Test 9: History
// ============================================================
static void testHistory() {
    printf("\n=== Test 9: History ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100);

    size_t histCount = mgr.getHistoryCount();
    test("history non-empty after operations", histCount > 0);

    auto hist = mgr.getHistory("system");
    test("getHistory system non-empty", hist.size() > 0);

    auto appHist = mgr.getHistory("app1");
    test("getHistory app1 empty (no events for app1)", appHist.empty());

    // NO_HISTORY flag
    mgr.setAppUsbPolicy("app_nohist", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_NO_HISTORY);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 200, "app_nohist");
    auto noHist = mgr.getHistory("app_nohist");
    test("NO_HISTORY flag prevents history", noHist.empty());

    // Clear history
    test("clearHistory SUCCESS", mgr.clearHistory() == UsbResult::SUCCESS);
    test("history reduced after clear", mgr.getHistoryCount() <= 1);

    // clearHistory non-system
    test("clearHistory non-system PERMISSION_DENIED",
         mgr.clearHistory("app1") == UsbResult::PERMISSION_DENIED);

    // Clear app history
    mgr.connectDevice(dev);
    mgr.setAppUsbPolicy("app_clear", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 50, "app_clear");
    size_t before = mgr.getHistory("app_clear").size();
    test("app_clear has history", before > 0);
    test("clearAppHistory SUCCESS",
         mgr.clearAppHistory("app_clear", "system") == UsbResult::SUCCESS);
    test("app_clear history cleared",
         mgr.getHistory("app_clear").empty());

    // clearAppHistory non-owner
    mgr.setAppUsbPolicy("app_owner", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 50, "app_owner");
    test("clearAppHistory non-owner PERMISSION_DENIED",
         mgr.clearAppHistory("app_owner", "other_app") == UsbResult::PERMISSION_DENIED);

    // History capacity
    UsbManager mgr2;
    mgr2.initialize(5, 10);
    mgr2.enablePort();
    mgr2.connectDevice(dev);
    for (int i = 0; i < 20; ++i) {
        mgr2.startTransfer("dev1", UsbTransferDirection::IN, 10);
        mgr2.completeTransfer(mgr2.getActiveTransfers().empty() ? 0 :
                               mgr2.getActiveTransfers()[0].id);
    }
    test("history capped at maxHistory", mgr2.getHistoryCount() <= 5);

    mgr.shutdown();
}

// ============================================================
// Test 10: Mock / Testing
// ============================================================
static void testMock() {
    printf("\n=== Test 10: Mock / Testing ===\n");
    UsbManager mgr;
    mgr.initialize();

    test("mock initially disabled", !mgr.isMockEnabled());

    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == UsbResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    test("setMockEnabled non-system PERMISSION_DENIED",
         mgr.setMockEnabled(false, "app1") == UsbResult::PERMISSION_DENIED);

    UsbDevice mockDev;
    mockDev.id = "mock1";
    mockDev.name = "Mock Device";
    mockDev.serial = "MOCK_SN";
    mockDev.deviceClass = UsbDeviceClass::HID;

    test("setMockDevice SUCCESS",
         mgr.setMockDevice(mockDev) == UsbResult::SUCCESS);
    test("stats mockDevicesSet >= 1", mgr.getStats().mockDevicesSet >= 1);

    test("setMockDevice again (replace) SUCCESS",
         mgr.setMockDevice(mockDev) == UsbResult::SUCCESS);

    test("addMockDevice duplicate ALREADY_CONNECTED",
         mgr.addMockDevice(mockDev) == UsbResult::ALREADY_CONNECTED);

    UsbDevice mockDev2;
    mockDev2.id = "mock2";
    mockDev2.name = "Mock Device 2";
    mockDev2.serial = "MOCK_SN2";

    test("addMockDevice SUCCESS",
         mgr.addMockDevice(mockDev2) == UsbResult::SUCCESS);

    test("removeMockDevice SUCCESS",
         mgr.removeMockDevice("mock2") == UsbResult::SUCCESS);
    test("removeMockDevice not found DEVICE_NOT_FOUND",
         mgr.removeMockDevice("mock2") == UsbResult::DEVICE_NOT_FOUND);

    test("setMockDevice empty id INVALID_PARAMETER",
         mgr.setMockDevice(UsbDevice{}) == UsbResult::INVALID_PARAMETER);

    test("setMockDevice non-system PERMISSION_DENIED",
         mgr.setMockDevice(mockDev, "app1") == UsbResult::PERMISSION_DENIED);

    // Events check
    auto mockEvents = mgr.getEventsByType(UsbEventType::MOCK_DEVICE_SET);
    test("MOCK_DEVICE_SET events recorded", mockEvents.size() >= 2);

    mgr.shutdown();
}

// ============================================================
// Test 11: Privacy Indicator
// ============================================================
static void testPrivacyIndicator() {
    printf("\n=== Test 11: Privacy Indicator ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    test("indicator initially off", !mgr.isPrivacyIndicatorOn());

    mgr.setAppUsbPolicy("app1", UsbPermission::ALLOW_ALWAYS, UsbPrivacyMode::FULL);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100, "app1");

    test("indicator on after transfer", mgr.isPrivacyIndicatorOn());
    test("activeUsbUsers has app1",
         std::find(mgr.getActiveUsbUsers().begin(),
                   mgr.getActiveUsbUsers().end(), "app1") != mgr.getActiveUsbUsers().end());
    test("lastAccessTime > 0", mgr.getLastAccessTime() > 0);

    // Clear policy removes from active users
    mgr.clearAppUsbPolicy("app1");
    test("indicator off after policy cleared",
         !mgr.isPrivacyIndicatorOn());

    // Indicator events
    auto onEvents = mgr.getEventsByType(UsbEventType::INDICATOR_ON);
    auto offEvents = mgr.getEventsByType(UsbEventType::INDICATOR_OFF);
    test("INDICATOR_ON events", onEvents.size() >= 1);
    test("INDICATOR_OFF events", offEvents.size() >= 1);
    test("stats indicatorToggleCount >= 2", mgr.getStats().indicatorToggleCount >= 2);

    mgr.shutdown();
}

// ============================================================
// Test 12: Events
// ============================================================
static void testEvents() {
    printf("\n=== Test 12: Events ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    size_t eventCount = mgr.getEventCount();
    test("events non-empty after operations", eventCount > 0);

    auto events = mgr.getEvents();
    test("getEvents returns all", events.size() == eventCount);

    auto eventsByType = mgr.getEventsByType(UsbEventType::DEVICE_CONNECTED);
    test("getEventsByType DEVICE_CONNECTED non-empty",
         eventsByType.size() >= 1);

    auto recentEvents = mgr.getEvents(5);
    test("getEvents(5) returns at most 5", recentEvents.size() <= 5);

    test("clearEvents SUCCESS", mgr.clearEvents() == UsbResult::SUCCESS);
    test("events cleared", mgr.getEventCount() == 0);

    // Ring buffer test
    UsbManager mgr2;
    mgr2.initialize(128, 5);
    mgr2.enablePort();
    for (int i = 0; i < 10; ++i) {
        UsbDevice d;
        d.id = "dev" + std::to_string(i);
        d.name = "Dev" + std::to_string(i);
        d.serial = "SN" + std::to_string(i);
        mgr2.connectDevice(d);
        mgr2.disconnectDevice(d.id);
    }
    test("events ring buffer capped at maxEvents",
         mgr2.getEventCount() <= 5);

    // History archived on clearEvents
    test("history grew after clearEvents",
         mgr2.getHistoryCount() > 0);

    mgr.shutdown();
}

// ============================================================
// Test 13: Stats
// ============================================================
static void testStats() {
    printf("\n=== Test 13: Stats ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);
    mgr.setMode(UsbMode::MTP);
    mgr.setRole(UsbRole::HOST);
    mgr.enableDebugging();
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100);
    mgr.completeTransfer(mgr.getActiveTransfers()[0].id);
    mgr.setAppUsbPolicy("app1", UsbPermission::ALLOW_ALWAYS, UsbPrivacyMode::FULL);

    UsbStats stats = mgr.getStats();
    test("stats stateChanges >= 1", stats.stateChanges >= 1);
    test("stats devicesConnected >= 1", stats.devicesConnected >= 1);
    test("stats modeChanges >= 1", stats.modeChanges >= 1);
    test("stats roleChanges >= 1", stats.roleChanges >= 1);
    test("stats transfersStarted >= 1", stats.transfersStarted >= 1);
    test("stats transfersCompleted >= 1", stats.transfersCompleted >= 1);
    test("stats debuggingToggles >= 1", stats.debuggingToggles >= 1);
    test("stats permissionsChanged >= 1", stats.permissionsChanged >= 1);
    test("stats byEventType has data", stats.byEventType[0] >= 0);
    test("stats byResult has data", stats.byResult[0] >= 0);

    mgr.resetStats();
    UsbStats reset = mgr.getStats();
    test("stats reset stateChanges 0", reset.stateChanges == 0);
    test("stats reset devicesConnected 0", reset.devicesConnected == 0);
    test("stats reset transfersStarted 0", reset.transfersStarted == 0);

    mgr.shutdown();
}

// ============================================================
// Test 14: Callbacks
// ============================================================
static void testCallbacks() {
    printf("\n=== Test 14: Callbacks ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    int eventCount = 0;
    UsbEventType lastType = UsbEventType::STATE_CHANGED;

    mgr.setEventCallback([&eventCount, &lastType](const UsbEvent& event) {
        eventCount++;
        lastType = event.type;
    });

    int accessCount = 0;
    UsbResult lastAccessResult = UsbResult::SUCCESS;

    mgr.setAccessCallback([&accessCount, &lastAccessResult](const std::string& appId, UsbResult result) {
        accessCount++;
        lastAccessResult = result;
    });

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    test("event callback fired", eventCount > 0);
    test("last event type DEVICE_CONNECTED",
         lastType == UsbEventType::DEVICE_CONNECTED);

    mgr.setAppUsbPolicy("app1", UsbPermission::ALLOW_ALWAYS, UsbPrivacyMode::FULL);
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100, "app1");

    test("access callback fired for app1", accessCount > 0);
    test("access result SUCCESS", lastAccessResult == UsbResult::SUCCESS);

    // System operations don't trigger access callback
    int accessBefore = accessCount;
    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100, "system");
    test("access callback not fired for system",
         accessCount == accessBefore);

    mgr.shutdown();
}

// ============================================================
// Test 15: Failure Simulation
// ============================================================
static void testFailureSimulation() {
    printf("\n=== Test 15: Failure Simulation ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    test("failNextOperation set", true);
    mgr.setFailNextOperation(true);
    test("enablePort with fail SIMULATED_FAILURE",
         mgr.disablePort() == UsbResult::SIMULATED_FAILURE);
    test("failNextOperation reset after one use", !mgr.getFailNextOperation());
    // Test failure on various operations
    mgr.setFailNextOperation(true);
    test("setMode with fail SIMULATED_FAILURE",
         mgr.setMode(UsbMode::MTP) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setRole with fail SIMULATED_FAILURE",
         mgr.setRole(UsbRole::HOST) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("connectDevice with fail SIMULATED_FAILURE",
         mgr.connectDevice(dev) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("disconnectDevice with fail SIMULATED_FAILURE",
         mgr.disconnectDevice("dev1") == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("startTransfer with fail SIMULATED_FAILURE",
         mgr.startTransfer("dev1", UsbTransferDirection::IN, 100) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("completeTransfer with fail SIMULATED_FAILURE",
         mgr.completeTransfer(1) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("cancelTransfer with fail SIMULATED_FAILURE",
         mgr.cancelTransfer(1) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("failTransfer with fail SIMULATED_FAILURE",
         mgr.failTransfer(1) == UsbResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("enableDebugging with fail SIMULATED_FAILURE",
         mgr.enableDebugging() == UsbResult::SIMULATED_FAILURE);

    // Test totalFailures increments on simulated failure
    UsbStats statsBefore = mgr.getStats();
    int failuresBefore = statsBefore.totalFailures;
    mgr.setFailNextOperation(true);
    mgr.enablePort();  // Simulated failure
    test("totalFailures increments on simulated failure",
         mgr.getStats().totalFailures == failuresBefore + 1);
    test("failNextOperation resets correctly", !mgr.getFailNextOperation());

    mgr.shutdown();
}

// ============================================================
// Test 16: Time Injection
// ============================================================
static void testTimeInjection() {
    printf("\n=== Test 16: Time Injection ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    mgr.setCurrentTimeForTesting(1000000);

    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);

    UsbDevice outDev;
    mgr.getDevice("dev1", outDev);
    test("connectedAt matches injected time",
         outDev.connectedAt == 1000000);

    mgr.startTransfer("dev1", UsbTransferDirection::IN, 100);
    auto transfers = mgr.getActiveTransfers();
    test("transfer timestamp matches injected time",
         transfers[0].timestamp == 1000000);

    mgr.setCurrentTimeForTesting(2000000);
    mgr.startTransfer("dev1", UsbTransferDirection::OUT, 200);
    transfers = mgr.getActiveTransfers();
    test("second transfer timestamp updated",
         transfers.back().timestamp == 2000000);

    mgr.clearTimeOverride();

    mgr.shutdown();
}

// ============================================================
// Test 17: String Helpers
// ============================================================
static void testStringHelpers() {
    printf("\n=== Test 17: String Helpers ===\n");

    test("stateToString DISCONNECTED",
         std::string(UsbManager::stateToString(UsbState::DISCONNECTED)) == "DISCONNECTED");
    test("stateToString CONNECTED",
         std::string(UsbManager::stateToString(UsbState::CONNECTED)) == "CONNECTED");
    test("stateToString CONFIGURED",
         std::string(UsbManager::stateToString(UsbState::CONFIGURED)) == "CONFIGURED");
    test("stateToString SUSPENDED",
         std::string(UsbManager::stateToString(UsbState::SUSPENDED)) == "SUSPENDED");
    test("stateToString ERROR_STATE",
         std::string(UsbManager::stateToString(UsbState::ERROR_STATE)) == "ERROR_STATE");

    test("modeToString NONE",
         std::string(UsbManager::modeToString(UsbMode::NONE)) == "NONE");
    test("modeToString CHARGING_ONLY",
         std::string(UsbManager::modeToString(UsbMode::CHARGING_ONLY)) == "CHARGING_ONLY");
    test("modeToString MTP",
         std::string(UsbManager::modeToString(UsbMode::MTP)) == "MTP");
    test("modeToString PTP",
         std::string(UsbManager::modeToString(UsbMode::PTP)) == "PTP");
    test("modeToString TETHERING",
         std::string(UsbManager::modeToString(UsbMode::TETHERING)) == "TETHERING");
    test("modeToString DEBUG",
         std::string(UsbManager::modeToString(UsbMode::DEBUG)) == "DEBUG");
    test("modeToString ACCESSORY",
         std::string(UsbManager::modeToString(UsbMode::ACCESSORY)) == "ACCESSORY");

    test("roleToString DEVICE",
         std::string(UsbManager::roleToString(UsbRole::DEVICE)) == "DEVICE");
    test("roleToString HOST",
         std::string(UsbManager::roleToString(UsbRole::HOST)) == "HOST");
    test("roleToString OTG",
         std::string(UsbManager::roleToString(UsbRole::OTG)) == "OTG");

    test("deviceClassToString STORAGE",
         std::string(UsbManager::deviceClassToString(UsbDeviceClass::STORAGE)) == "STORAGE");
    test("deviceClassToString HID",
         std::string(UsbManager::deviceClassToString(UsbDeviceClass::HID)) == "HID");
    test("deviceClassToString AUDIO",
         std::string(UsbManager::deviceClassToString(UsbDeviceClass::AUDIO)) == "AUDIO");

    test("transferDirectionToString IN",
         std::string(UsbManager::transferDirectionToString(UsbTransferDirection::IN)) == "IN");
    test("transferDirectionToString OUT",
         std::string(UsbManager::transferDirectionToString(UsbTransferDirection::OUT)) == "OUT");

    test("transferStateToString ACTIVE",
         std::string(UsbManager::transferStateToString(UsbTransferState::ACTIVE)) == "ACTIVE");
    test("transferStateToString COMPLETED",
         std::string(UsbManager::transferStateToString(UsbTransferState::COMPLETED)) == "COMPLETED");
    test("transferStateToString CANCELLED",
         std::string(UsbManager::transferStateToString(UsbTransferState::CANCELLED)) == "CANCELLED");

    test("permissionToString DENY",
         std::string(UsbManager::permissionToString(UsbPermission::DENY)) == "DENY");
    test("permissionToString ALLOW_FOREGROUND",
         std::string(UsbManager::permissionToString(UsbPermission::ALLOW_FOREGROUND)) == "ALLOW_FOREGROUND");
    test("permissionToString ALLOW_ALWAYS",
         std::string(UsbManager::permissionToString(UsbPermission::ALLOW_ALWAYS)) == "ALLOW_ALWAYS");
    test("permissionToString ALLOW_ONCE",
         std::string(UsbManager::permissionToString(UsbPermission::ALLOW_ONCE)) == "ALLOW_ONCE");

    test("privacyModeToString FULL",
         std::string(UsbManager::privacyModeToString(UsbPrivacyMode::FULL)) == "FULL");
    test("privacyModeToString REDACTED",
         std::string(UsbManager::privacyModeToString(UsbPrivacyMode::REDACTED)) == "REDACTED");
    test("privacyModeToString METADATA_ONLY",
         std::string(UsbManager::privacyModeToString(UsbPrivacyMode::METADATA_ONLY)) == "METADATA_ONLY");

    test("resultToString SUCCESS",
         std::string(UsbManager::resultToString(UsbResult::SUCCESS)) == "SUCCESS");
    test("resultToString NOT_INITIALIZED",
         std::string(UsbManager::resultToString(UsbResult::NOT_INITIALIZED)) == "NOT_INITIALIZED");
    test("resultToString PERMISSION_DENIED",
         std::string(UsbManager::resultToString(UsbResult::PERMISSION_DENIED)) == "PERMISSION_DENIED");
    test("resultToString DEVICE_NOT_FOUND",
         std::string(UsbManager::resultToString(UsbResult::DEVICE_NOT_FOUND)) == "DEVICE_NOT_FOUND");
    test("resultToString SIMULATED_FAILURE",
         std::string(UsbManager::resultToString(UsbResult::SIMULATED_FAILURE)) == "SIMULATED_FAILURE");

    test("eventTypeToString STATE_CHANGED",
         std::string(UsbManager::eventTypeToString(UsbEventType::STATE_CHANGED)) == "STATE_CHANGED");
    test("eventTypeToString DEVICE_CONNECTED",
         std::string(UsbManager::eventTypeToString(UsbEventType::DEVICE_CONNECTED)) == "DEVICE_CONNECTED");
    test("eventTypeToString TRANSFER_STARTED",
         std::string(UsbManager::eventTypeToString(UsbEventType::TRANSFER_STARTED)) == "TRANSFER_STARTED");
    test("eventTypeToString INDICATOR_ON",
         std::string(UsbManager::eventTypeToString(UsbEventType::INDICATOR_ON)) == "INDICATOR_ON");

    // Parser tests
    test("stringToResult SUCCESS",
         UsbManager::stringToResult("SUCCESS") == UsbResult::SUCCESS);
    test("stringToResult PERMISSION_DENIED",
         UsbManager::stringToResult("PERMISSION_DENIED") == UsbResult::PERMISSION_DENIED);
    test("stringToResult default SUCCESS",
         UsbManager::stringToResult("UNKNOWN") == UsbResult::SUCCESS);

    test("stringToMode MTP",
         UsbManager::stringToMode("MTP") == UsbMode::MTP);
    test("stringToMode PTP",
         UsbManager::stringToMode("PTP") == UsbMode::PTP);
    test("stringToMode default NONE",
         UsbManager::stringToMode("UNKNOWN") == UsbMode::NONE);

    test("stringToDeviceClass STORAGE",
         UsbManager::stringToDeviceClass("STORAGE") == UsbDeviceClass::STORAGE);
    test("stringToDeviceClass HID",
         UsbManager::stringToDeviceClass("HID") == UsbDeviceClass::HID);
    test("stringToDeviceClass default UNKNOWN",
         UsbManager::stringToDeviceClass("UNKNOWN") == UsbDeviceClass::UNKNOWN);
}

// ============================================================
// Test 18: LogServer / CrashReporter Integration
// ============================================================
static void testIntegration() {
    printf("\n=== Test 18: LogServer / CrashReporter Integration ===\n");
    UsbManager mgr;
    mgr.initialize();

    test("getLogServer null initially", mgr.getLogServer() == nullptr);
    test("getCrashReporter null initially", mgr.getCrashReporter() == nullptr);

    // Set to non-null (we can't easily create real objects, just test the setters)
    phantom::logging::LogServer* logServer = nullptr;
    mgr.setLogServer(logServer);
    test("setLogServer works", mgr.getLogServer() == logServer);

    phantom::crashreporter::CrashReporter* crashReporter = nullptr;
    mgr.setCrashReporter(crashReporter);
    test("setCrashReporter works", mgr.getCrashReporter() == crashReporter);

    // Operations should not crash with null integration
    mgr.enablePort();
    UsbDevice dev;
    dev.id = "dev1";
    dev.name = "Test";
    dev.serial = "SN001";
    mgr.connectDevice(dev);
    mgr.setMode(UsbMode::MTP);
    mgr.enableDebugging();
    mgr.disableDebugging();
    mgr.disconnectDevice("dev1");

    test("operations complete without crash with null integration", true);

    mgr.shutdown();
}

// ============================================================
// Test 19: Full Workflow
// ============================================================
static void testFullWorkflow() {
    printf("\n=== Test 19: Full Workflow ===\n");
    UsbManager mgr;

    // 1. Initialize
    test("1. initialize SUCCESS", mgr.initialize() == UsbResult::SUCCESS);

    // 2. Enable port
    test("2. enablePort SUCCESS", mgr.enablePort() == UsbResult::SUCCESS);

    // 3. Set mode to MTP
    test("3. setMode MTP SUCCESS", mgr.setMode(UsbMode::MTP) == UsbResult::SUCCESS);

    // 4. Set role to HOST
    test("4. setRole HOST SUCCESS", mgr.setRole(UsbRole::HOST) == UsbResult::SUCCESS);

    // 5. Connect device
    UsbDevice dev;
    dev.id = "wf_dev1";
    dev.name = "Workflow Device";
    dev.vendorId = 0x05AC;
    dev.productId = 0x1234;
    dev.deviceClass = UsbDeviceClass::STORAGE;
    dev.serial = "WFSN001";
    dev.trusted = true;
    test("5. connectDevice SUCCESS", mgr.connectDevice(dev) == UsbResult::SUCCESS);

    // 6. Set app policy
    test("6. setAppUsbPolicy SUCCESS",
         mgr.setAppUsbPolicy("wf_app", UsbPermission::ALLOW_FOREGROUND,
                             UsbPrivacyMode::REDACTED) == UsbResult::SUCCESS);

    // 7. Set foreground
    test("7. setAppForeground SUCCESS",
         mgr.setAppForeground("wf_app", true) == UsbResult::SUCCESS);

    // 8. Start transfer
    test("8. startTransfer SUCCESS",
         mgr.startTransfer("wf_dev1", UsbTransferDirection::IN, 4096, "wf_app") == UsbResult::SUCCESS);

    // 9. Complete transfer
    auto active = mgr.getActiveTransfers();
    test("9. getActiveTransfers has transfer", active.size() >= 1);
    test("9. completeTransfer SUCCESS",
         mgr.completeTransfer(active[0].id) == UsbResult::SUCCESS);

    // 10. Get device serial with privacy
    std::string serial;
    test("10. getDeviceSerial SUCCESS",
         mgr.getDeviceSerial("wf_dev1", serial, "wf_app") == UsbResult::SUCCESS);
    test("10. serial redacted", serial != "WFSN001");

    // 11. Enable debugging
    test("11. enableDebugging SUCCESS", mgr.enableDebugging() == UsbResult::SUCCESS);

    // 12. Disable debugging
    test("12. disableDebugging SUCCESS", mgr.disableDebugging() == UsbResult::SUCCESS);

    // 13. Check stats
    UsbStats stats = mgr.getStats();
    test("13. stats populated", stats.stateChanges >= 1 && stats.devicesConnected >= 1);

    // 14. Check events
    test("14. events populated", mgr.getEventCount() > 0);

    // 15. Check history
    test("15. history populated", mgr.getHistoryCount() > 0);

    // 16. Clear history
    test("16. clearHistory SUCCESS", mgr.clearHistory() == UsbResult::SUCCESS);

    // 17. Disconnect device
    test("17. disconnectDevice SUCCESS",
         mgr.disconnectDevice("wf_dev1") == UsbResult::SUCCESS);

    // 18. Disable port
    test("18. disablePort SUCCESS", mgr.disablePort() == UsbResult::SUCCESS);

    // 19. Shutdown
    test("19. shutdown SUCCESS", mgr.shutdown() == UsbResult::SUCCESS);

    test("20. not initialized after shutdown", !mgr.isInitialized());
}

// ============================================================
// Test 20: ALLOW_ONCE on Identifier Access
// ============================================================
static void testAllowOnceIdentifierAccess() {
    printf("\n=== Test 20: ALLOW_ONCE on Identifier Access ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev_ao1";
    dev.name = "AllowOnce Device";
    dev.serial = "AO123456789";
    dev.vendorId = 0x1111;
    dev.productId = 0x2222;
    mgr.connectDevice(dev);

    // ALLOW_ONCE on getDeviceSerial
    mgr.setAppUsbPolicy("app_ao", UsbPermission::ALLOW_ONCE, UsbPrivacyMode::FULL);

    std::string serial;
    test("first getDeviceSerial ALLOW_ONCE SUCCESS",
         mgr.getDeviceSerial("dev_ao1", serial, "app_ao") == UsbResult::SUCCESS);
    test("ALLOW_ONCE consumed for serial",
         !mgr.checkAppAccess("app_ao"));

    test("second getDeviceSerial ALLOW_ONCE PERMISSION_DENIED",
         mgr.getDeviceSerial("dev_ao1", serial, "app_ao") == UsbResult::PERMISSION_DENIED);

    // ALLOW_ONCE on getDeviceInfo
    mgr.setAppUsbPolicy("app_ao2", UsbPermission::ALLOW_ONCE, UsbPrivacyMode::FULL);
    UsbDevice outDev;
    test("first getDeviceInfo ALLOW_ONCE SUCCESS",
         mgr.getDeviceInfo("dev_ao1", outDev, "app_ao2") == UsbResult::SUCCESS);
    test("ALLOW_ONCE consumed for deviceInfo",
         !mgr.checkAppAccess("app_ao2"));
    test("second getDeviceInfo ALLOW_ONCE PERMISSION_DENIED",
         mgr.getDeviceInfo("dev_ao1", outDev, "app_ao2") == UsbResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test 21: REQUIRE_FOREGROUND Flag
// ============================================================
static void testRequireForegroundFlag() {
    printf("\n=== Test 21: REQUIRE_FOREGROUND Flag ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    UsbDevice dev;
    dev.id = "dev_rf1";
    dev.name = "RF Device";
    dev.serial = "RF111222333";
    mgr.connectDevice(dev);

    // ALLOW_ALWAYS + REQUIRE_FOREGROUND flag
    mgr.setAppUsbPolicy("app_rf", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_REQUIRE_FOREGROUND);

    test("checkAppAccess background denied with REQUIRE_FOREGROUND",
         !mgr.checkAppAccess("app_rf"));

    std::string serial;
    test("getDeviceSerial background denied",
         mgr.getDeviceSerial("dev_rf1", serial, "app_rf") == UsbResult::PERMISSION_DENIED);

    mgr.setAppForeground("app_rf", true);
    test("checkAppAccess foreground allowed with REQUIRE_FOREGROUND",
         mgr.checkAppAccess("app_rf"));
    test("getDeviceSerial foreground SUCCESS",
         mgr.getDeviceSerial("dev_rf1", serial, "app_rf") == UsbResult::SUCCESS);

    mgr.shutdown();
}

// ============================================================
// Test 22: Debugging Access Control
// ============================================================
static void testDebuggingAccessControl() {
    printf("\n=== Test 22: Debugging Access Control ===\n");
    UsbManager mgr;
    mgr.initialize();
    mgr.enablePort();

    // App without allowDebugging - denied
    mgr.setAppUsbPolicy("app_dbg1", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_NONE, false);
    test("enableDebugging without allowDebugging PERMISSION_DENIED",
         mgr.enableDebugging("app_dbg1") == UsbResult::PERMISSION_DENIED);

    // App with allowDebugging=true - allowed
    mgr.setAppUsbPolicy("app_dbg2", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_NONE, true);
    test("enableDebugging with allowDebugging SUCCESS",
         mgr.enableDebugging("app_dbg2") == UsbResult::SUCCESS);
    test("debugging enabled", mgr.isDebuggingEnabled());

    mgr.disableDebugging();

    // App with allowDebugging=true but BLOCK_DEBUGGING flag - denied
    mgr.setAppUsbPolicy("app_dbg3", UsbPermission::ALLOW_ALWAYS,
                        UsbPrivacyMode::FULL, USB_PRIVACY_BLOCK_DEBUGGING, true);
    test("enableDebugging with BLOCK_DEBUGGING PERMISSION_DENIED",
         mgr.enableDebugging("app_dbg3") == UsbResult::PERMISSION_DENIED);

    // Stats: privacyApplications incremented when privacy flags set
    UsbStats stats = mgr.getStats();
    test("stats privacyApplications >= 1",
         stats.privacyApplications >= 1);

    mgr.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("==================================================\n");
    printf("  Phantom OS v0.37.0 - USB Manager Tests\n");
    printf("==================================================\n");

    testLifecycle();
    testPortState();
    testModeRole();
    testDeviceManagement();
    testTransfers();
    testDebugging();
    testPermissions();
    testIdentifierAccess();
    testHistory();
    testMock();
    testPrivacyIndicator();
    testEvents();
    testStats();
    testCallbacks();
    testFailureSimulation();
    testTimeInjection();
    testStringHelpers();
    testIntegration();
    testFullWorkflow();
    testAllowOnceIdentifierAccess();
    testRequireForegroundFlag();
    testDebuggingAccessControl();

    printf("\n==================================================\n");
    printf("  Results: %d run, %d passed, %d failed\n",
           tests_run, tests_passed, tests_failed);
    printf("==================================================\n");

    return (tests_failed == 0) ? 0 : 1;
}
