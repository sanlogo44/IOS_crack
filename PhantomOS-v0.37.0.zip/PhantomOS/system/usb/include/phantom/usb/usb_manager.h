/*
 * Phantom OS - USB Manager (Lightning / USB Connectivity)
 * v0.37.0 - License: GPL-3.0
 *
 * Privacy-first USB service: Lightning/USB port management,
 * accessory detection, OTG host/device role switching, MTP/PTP
 * file transfer modes, USB debugging control, per-app USB access
 * policy with foreground-only enforcement, privacy indicator,
 * mock devices for testing, events, stats, callbacks and
 * optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. USB devices are deterministic
 * stubs. The LogServer must never log per-app USB transfer data.
 */

#ifndef PHANTOM_USB_USB_MANAGER_H
#define PHANTOM_USB_USB_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace usb {

// ============================================================
// Constants
// ============================================================

static const uint32_t USB_PRIVACY_NONE = 0;
static const uint32_t USB_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t USB_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t USB_PRIVACY_REDACT_SERIAL = 1 << 2;
static const uint32_t USB_PRIVACY_PSEUDONYMIZE = 1 << 3;
static const uint32_t USB_PRIVACY_METADATA_ONLY = 1 << 4;
static const uint32_t USB_PRIVACY_MOCK_ALLOWED = 1 << 5;
static const uint32_t USB_PRIVACY_INDICATOR_REQUIRED = 1 << 6;
static const uint32_t USB_PRIVACY_BLOCK_DEBUGGING = 1 << 7;

static const uint32_t USB_DEFAULT_MAX_DEVICES = 16;
static const uint32_t USB_DEFAULT_MAX_TRANSFERS = 32;
static const uint32_t USB_DEFAULT_MAX_HISTORY = 128;
static const uint32_t USB_DEFAULT_MAX_EVENTS = 256;
static const uint32_t USB_DEFAULT_MAX_TRANSFER_BYTES = 4294967295U;

// ============================================================
// Enums
// ============================================================

enum class UsbState : uint8_t {
    DISCONNECTED = 0,
    CONNECTED,
    CONFIGURED,
    SUSPENDED,
    ERROR_STATE
};

enum class UsbMode : uint8_t {
    NONE = 0,
    CHARGING_ONLY,
    MTP,
    PTP,
    TETHERING,
    DEBUG,
    ACCESSORY
};

enum class UsbRole : uint8_t {
    DEVICE = 0,
    HOST,
    OTG
};

enum class UsbDeviceClass : uint8_t {
    UNKNOWN = 0,
    AUDIO,
    COMM,
    HID,
    STORAGE,
    HUB,
    VIDEO,
    WIRELESS,
    MISCELLANEOUS
};

enum class UsbTransferDirection : uint8_t {
    IN = 0,
    OUT
};

enum class UsbTransferState : uint8_t {
    PENDING = 0,
    ACTIVE,
    COMPLETED,
    FAILED,
    CANCELLED
};

enum class UsbPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class UsbPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class UsbResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    NOT_CONNECTED,
    ALREADY_CONNECTED,
    DEVICE_NOT_FOUND,
    MODE_NOT_SUPPORTED,
    ROLE_NOT_SUPPORTED,
    CAPACITY_EXCEEDED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class UsbEventType : uint8_t {
    STATE_CHANGED = 0,
    DEVICE_CONNECTED,
    DEVICE_DISCONNECTED,
    MODE_CHANGED,
    ROLE_CHANGED,
    TRANSFER_STARTED,
    TRANSFER_COMPLETED,
    TRANSFER_FAILED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    MOCK_DEVICE_SET,
    DEBUGGING_TOGGLED,
    HISTORY_CLEARED
};

// ============================================================
// Data structures
// ============================================================

struct UsbDevice {
    std::string id;
    std::string name;
    uint16_t vendorId = 0;
    uint16_t productId = 0;
    UsbDeviceClass deviceClass = UsbDeviceClass::UNKNOWN;
    std::string serial;
    bool trusted = false;
    uint64_t connectedAt = 0;
};

struct UsbTransfer {
    uint64_t id = 0;
    std::string deviceId;
    UsbTransferDirection direction = UsbTransferDirection::IN;
    uint64_t bytesTotal = 0;
    uint64_t bytesTransferred = 0;
    UsbTransferState state = UsbTransferState::PENDING;
    uint64_t timestamp = 0;
    std::string appId;
};

struct UsbPolicy {
    std::string appId;
    UsbPermission permission = UsbPermission::DENY;
    UsbPrivacyMode privacyMode = UsbPrivacyMode::FULL;
    uint32_t privacyFlags = USB_PRIVACY_NONE;
    bool allowDebugging = false;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
};

struct UsbEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    UsbEventType type = UsbEventType::STATE_CHANGED;
    UsbResult result = UsbResult::SUCCESS;
    std::string appId;
    std::string detail;
};

struct UsbStats {
    uint64_t stateChanges = 0;
    uint64_t devicesConnected = 0;
    uint64_t devicesDisconnected = 0;
    uint64_t modeChanges = 0;
    uint64_t roleChanges = 0;
    uint64_t transfersStarted = 0;
    uint64_t transfersCompleted = 0;
    uint64_t transfersFailed = 0;
    uint64_t transfersCancelled = 0;
    uint64_t permissionsChanged = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t mockDevicesSet = 0;
    uint64_t debuggingToggles = 0;
    uint64_t byEventType[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[14] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// USB Manager
// ============================================================

class UsbManager {
public:
    UsbManager() = default;
    ~UsbManager() = default;

    UsbManager(const UsbManager&) = delete;
    UsbManager& operator=(const UsbManager&) = delete;

    // ---- Lifecycle ----
    UsbResult initialize(size_t maxHistory = 128, size_t maxEvents = 256);
    UsbResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Port state ----
    UsbResult enablePort(const std::string& owner = "system");
    UsbResult disablePort(const std::string& owner = "system");
    UsbState getPortState() const { return portState_; }
    bool isPortEnabled() const { return portState_ != UsbState::DISCONNECTED; }

    // ---- Mode / Role ----
    UsbResult setMode(UsbMode mode, const std::string& owner = "system");
    UsbMode getMode() const { return currentMode_; }
    UsbResult setRole(UsbRole role, const std::string& owner = "system");
    UsbRole getRole() const { return currentRole_; }

    // ---- Device management ----
    UsbResult connectDevice(const UsbDevice& device, const std::string& owner = "system");
    UsbResult disconnectDevice(const std::string& deviceId, const std::string& owner = "system");
    UsbResult disconnectAllDevices(const std::string& owner = "system");
    bool getDevice(const std::string& deviceId, UsbDevice& outDevice) const;
    std::vector<UsbDevice> getAllDevices() const;
    std::vector<UsbDevice> getConnectedDevices() const;
    size_t getDeviceCount() const { return devices_.size(); }
    size_t getConnectedDeviceCount() const;

    // ---- Transfers ----
    UsbResult startTransfer(const std::string& deviceId, UsbTransferDirection direction,
                            uint64_t bytesTotal, const std::string& appId = "system");
    UsbResult completeTransfer(uint64_t transferId, const std::string& owner = "system");
    UsbResult cancelTransfer(uint64_t transferId, const std::string& owner = "system");
    UsbResult failTransfer(uint64_t transferId, const std::string& owner = "system");
    bool getTransfer(uint64_t transferId, UsbTransfer& outTransfer) const;
    std::vector<UsbTransfer> getActiveTransfers() const;
    std::vector<UsbTransfer> getAllTransfers() const;

    // ---- Debugging ----
    UsbResult enableDebugging(const std::string& owner = "system");
    UsbResult disableDebugging(const std::string& owner = "system");
    bool isDebuggingEnabled() const { return debuggingEnabled_; }

    // ---- Permission / policy ----
    UsbResult setAppUsbPolicy(const std::string& appId,
                              UsbPermission permission,
                              UsbPrivacyMode privacyMode,
                              uint32_t privacyFlags = USB_PRIVACY_NONE,
                              bool allowDebugging = false,
                              const std::string& owner = "system");
    UsbPolicy getAppUsbPolicy(const std::string& appId) const;
    UsbResult clearAppUsbPolicy(const std::string& appId,
                                const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    UsbResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Identifier access ----
    UsbResult getDeviceSerial(const std::string& deviceId, std::string& outSerial,
                               const std::string& appId);
    UsbResult getDeviceInfo(const std::string& deviceId, UsbDevice& outDevice,
                             const std::string& appId);

    // ---- History ----
    std::vector<UsbEvent> getHistory(const std::string& appId,
                                     size_t limit = 0) const;
    UsbResult clearHistory(const std::string& owner = "system");
    UsbResult clearAppHistory(const std::string& appId,
                              const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    UsbResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    UsbResult setMockDevice(const UsbDevice& device, const std::string& owner = "system");
    UsbResult addMockDevice(const UsbDevice& device, const std::string& owner = "system");
    UsbResult removeMockDevice(const std::string& deviceId, const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeUsbUsers_.empty(); }
    std::vector<std::string> getActiveUsbUsers() const { return activeUsbUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<UsbEvent> getEvents(size_t limit = 0) const;
    std::vector<UsbEvent> getEventsByType(UsbEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    UsbResult clearEvents();

    // ---- Stats ----
    UsbStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const UsbEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, UsbResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* stateToString(UsbState state);
    static const char* modeToString(UsbMode mode);
    static const char* roleToString(UsbRole role);
    static const char* deviceClassToString(UsbDeviceClass cls);
    static const char* transferDirectionToString(UsbTransferDirection dir);
    static const char* transferStateToString(UsbTransferState state);
    static const char* permissionToString(UsbPermission permission);
    static const char* privacyModeToString(UsbPrivacyMode mode);
    static const char* resultToString(UsbResult result);
    static const char* eventTypeToString(UsbEventType type);
    static UsbResult stringToResult(const std::string& str);
    static UsbMode stringToMode(const std::string& str);
    static UsbDeviceClass stringToDeviceClass(const std::string& str);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(UsbEventType type, UsbResult result,
                     const std::string& appId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void createDefaultMockDevices();
    std::string applyPrivacyTransform(const std::string& serial,
                                      const std::string& appId) const;
    std::string pseudonymizeDeviceId(const std::string& id) const;
    uint32_t fnv1aHash(const std::string& data) const;

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;

    UsbState portState_ = UsbState::DISCONNECTED;
    UsbMode currentMode_ = UsbMode::NONE;
    UsbRole currentRole_ = UsbRole::DEVICE;
    bool debuggingEnabled_ = false;

    std::map<std::string, UsbDevice> devices_;
    std::map<uint64_t, UsbTransfer> transfers_;
    uint64_t nextTransferId_ = 1;
    std::map<std::string, UsbPolicy> appPolicies_;

    std::vector<UsbEvent> history_;
    std::vector<UsbEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    std::vector<UsbDevice> mockDevices_;
    bool prevIndicatorOn_ = false;

    std::vector<std::string> activeUsbUsers_;
    uint64_t lastAccessTime_ = 0;

    UsbStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const UsbEvent&)> eventCallback_;
    std::function<void(const std::string&, UsbResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace usb
}  // namespace phantom

#endif  // PHANTOM_USB_USB_MANAGER_H
