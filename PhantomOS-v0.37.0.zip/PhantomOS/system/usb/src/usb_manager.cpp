/*
 * Phantom OS - USB Manager Implementation
 * v0.37.0 - License: GPL-3.0
 *
 * Implementation of the privacy-first USB/Lightning connectivity service.
 * All data is simulated in-memory.
 */

#include "phantom/usb/usb_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <sstream>

namespace phantom {
namespace usb {

// ============================================================
// FNV-1a Hash (deterministic, for pseudonymization)
// ============================================================

uint32_t UsbManager::fnv1aHash(const std::string& data) const {
    uint32_t hash = 2166136261U;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= 16777619U;
    }
    return hash;
}

// ============================================================
// Lifecycle
// ============================================================

UsbResult UsbManager::initialize(size_t maxHistory, size_t maxEvents) {
    if (initialized_) return UsbResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0)
        return UsbResult::INVALID_PARAMETER;

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;

    initialized_ = true;
    portState_ = UsbState::DISCONNECTED;
    currentMode_ = UsbMode::NONE;
    currentRole_ = UsbRole::DEVICE;
    debuggingEnabled_ = false;
    mockEnabled_ = false;

    devices_.clear();
    transfers_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeUsbUsers_.clear();
    mockDevices_.clear();

    nextTransferId_ = 1;
    nextEventId_ = 1;

    createDefaultMockDevices();

    stats_ = UsbStats{};

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::shutdown() {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    devices_.clear();
    transfers_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeUsbUsers_.clear();
    mockDevices_.clear();

    portState_ = UsbState::DISCONNECTED;
    currentMode_ = UsbMode::NONE;
    currentRole_ = UsbRole::DEVICE;
    debuggingEnabled_ = false;
    mockEnabled_ = false;
    initialized_ = false;

    return UsbResult::SUCCESS;
}

// ============================================================
// Port state
// ============================================================

UsbResult UsbManager::enablePort(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ != UsbState::DISCONNECTED) return UsbResult::BAD_STATE;

    portState_ = UsbState::CONNECTED;
    stats_.stateChanges++;
    recordEvent(UsbEventType::STATE_CHANGED, UsbResult::SUCCESS,
                owner, "Port enabled");
    logToServer("INFO", "USB port enabled");

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::disablePort(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::BAD_STATE;

    portState_ = UsbState::DISCONNECTED;
    currentMode_ = UsbMode::NONE;
    currentRole_ = UsbRole::DEVICE;
    debuggingEnabled_ = false;
    devices_.clear();
    transfers_.clear();
    activeUsbUsers_.clear();
    updatePrivacyIndicator();

    stats_.stateChanges++;
    recordEvent(UsbEventType::STATE_CHANGED, UsbResult::SUCCESS,
                owner, "Port disabled");
    logToServer("INFO", "USB port disabled");

    return UsbResult::SUCCESS;
}

// ============================================================
// Mode / Role
// ============================================================

UsbResult UsbManager::setMode(UsbMode mode, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;
    if (mode == currentMode_) return UsbResult::BAD_STATE;

    // OTG role requires HOST or OTG role
    if (mode == UsbMode::ACCESSORY && currentRole_ == UsbRole::HOST)
        return UsbResult::MODE_NOT_SUPPORTED;

    UsbMode old = currentMode_;
    currentMode_ = mode;
    stats_.modeChanges++;
    recordEvent(UsbEventType::MODE_CHANGED, UsbResult::SUCCESS,
                owner, std::string("Mode: ") + modeToString(old) + " -> " + modeToString(mode));
    logToServer("INFO", "USB mode changed to " + std::string(modeToString(mode)));

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::setRole(UsbRole role, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;
    if (role == currentRole_) return UsbResult::BAD_STATE;

    UsbRole old = currentRole_;
    currentRole_ = role;
    stats_.roleChanges++;
    recordEvent(UsbEventType::ROLE_CHANGED, UsbResult::SUCCESS,
                owner, std::string("Role: ") + roleToString(old) + " -> " + roleToString(role));
    logToServer("INFO", "USB role changed to " + std::string(roleToString(role)));

    return UsbResult::SUCCESS;
}

// ============================================================
// Device management
// ============================================================

UsbResult UsbManager::connectDevice(const UsbDevice& device, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;
    if (device.id.empty()) return UsbResult::INVALID_PARAMETER;
    if (devices_.find(device.id) != devices_.end()) return UsbResult::ALREADY_CONNECTED;
    if (devices_.size() >= USB_DEFAULT_MAX_DEVICES) return UsbResult::CAPACITY_EXCEEDED;

    UsbDevice dev = device;
    dev.connectedAt = getCurrentTimeMs();
    devices_[device.id] = dev;

    stats_.devicesConnected++;
    recordEvent(UsbEventType::DEVICE_CONNECTED, UsbResult::SUCCESS,
                owner, "Device: " + device.name);

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::disconnectDevice(const std::string& deviceId, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;

    auto it = devices_.find(deviceId);
    if (it == devices_.end()) return UsbResult::DEVICE_NOT_FOUND;

    std::string name = it->second.name;
    devices_.erase(it);

    // Cancel active transfers for this device
    for (auto& [id, transfer] : transfers_) {
        if (transfer.deviceId == deviceId &&
            (transfer.state == UsbTransferState::ACTIVE || transfer.state == UsbTransferState::PENDING)) {
            transfer.state = UsbTransferState::CANCELLED;
            stats_.transfersCancelled++;
        }
    }

    stats_.devicesDisconnected++;
    recordEvent(UsbEventType::DEVICE_DISCONNECTED, UsbResult::SUCCESS,
                owner, "Device: " + name);

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::disconnectAllDevices(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;

    size_t count = devices_.size();
    devices_.clear();

    // Cancel all active transfers
    for (auto& [id, transfer] : transfers_) {
        if (transfer.state == UsbTransferState::ACTIVE || transfer.state == UsbTransferState::PENDING) {
            transfer.state = UsbTransferState::CANCELLED;
            stats_.transfersCancelled++;
        }
    }

    stats_.devicesDisconnected += count;
    recordEvent(UsbEventType::DEVICE_DISCONNECTED, UsbResult::SUCCESS,
                owner, "All devices disconnected");

    return UsbResult::SUCCESS;
}

bool UsbManager::getDevice(const std::string& deviceId, UsbDevice& outDevice) const {
    auto it = devices_.find(deviceId);
    if (it == devices_.end()) return false;
    outDevice = it->second;
    return true;
}

std::vector<UsbDevice> UsbManager::getAllDevices() const {
    std::vector<UsbDevice> result;
    result.reserve(devices_.size());
    for (const auto& [id, dev] : devices_) {
        result.push_back(dev);
    }
    return result;
}

std::vector<UsbDevice> UsbManager::getConnectedDevices() const {
    return getAllDevices();
}

size_t UsbManager::getConnectedDeviceCount() const {
    return devices_.size();
}

// ============================================================
// Transfers
// ============================================================

UsbResult UsbManager::startTransfer(const std::string& deviceId, UsbTransferDirection direction,
                                    uint64_t bytesTotal, const std::string& appId) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;
    if (deviceId.empty()) return UsbResult::INVALID_PARAMETER;
    if (bytesTotal == 0) return UsbResult::INVALID_PARAMETER;
    if (devices_.find(deviceId) == devices_.end()) return UsbResult::DEVICE_NOT_FOUND;
    if (transfers_.size() >= USB_DEFAULT_MAX_TRANSFERS) return UsbResult::CAPACITY_EXCEEDED;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return UsbResult::PERMISSION_DENIED;

    UsbTransfer transfer;
    transfer.id = nextTransferId_++;
    transfer.deviceId = deviceId;
    transfer.direction = direction;
    transfer.bytesTotal = bytesTotal;
    transfer.bytesTransferred = 0;
    transfer.state = UsbTransferState::ACTIVE;
    transfer.timestamp = getCurrentTimeMs();
    transfer.appId = appId;

    transfers_[transfer.id] = transfer;

    stats_.transfersStarted++;
    recordEvent(UsbEventType::TRANSFER_STARTED, UsbResult::SUCCESS,
                appId, "Transfer " + std::to_string(transfer.id) + " (" + std::to_string(bytesTotal) + " bytes)");

    if (std::find(activeUsbUsers_.begin(), activeUsbUsers_.end(), appId) == activeUsbUsers_.end()) {
        activeUsbUsers_.push_back(appId);
        updatePrivacyIndicator();
    }
    lastAccessTime_ = getCurrentTimeMs();

    // Consume ALLOW_ONCE
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == UsbPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
    }

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::completeTransfer(uint64_t transferId, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    auto it = transfers_.find(transferId);
    if (it == transfers_.end()) return UsbResult::DEVICE_NOT_FOUND;
    if (it->second.state != UsbTransferState::ACTIVE) return UsbResult::BAD_STATE;

    it->second.state = UsbTransferState::COMPLETED;
    it->second.bytesTransferred = it->second.bytesTotal;

    stats_.transfersCompleted++;
    recordEvent(UsbEventType::TRANSFER_COMPLETED, UsbResult::SUCCESS,
                owner, "Transfer " + std::to_string(transferId) + " completed");

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::cancelTransfer(uint64_t transferId, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    auto it = transfers_.find(transferId);
    if (it == transfers_.end()) return UsbResult::DEVICE_NOT_FOUND;
    if (it->second.state != UsbTransferState::ACTIVE && it->second.state != UsbTransferState::PENDING)
        return UsbResult::BAD_STATE;

    it->second.state = UsbTransferState::CANCELLED;

    stats_.transfersCancelled++;
    recordEvent(UsbEventType::TRANSFER_FAILED, UsbResult::SUCCESS,
                owner, "Transfer " + std::to_string(transferId) + " cancelled");

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::failTransfer(uint64_t transferId, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    auto it = transfers_.find(transferId);
    if (it == transfers_.end()) return UsbResult::DEVICE_NOT_FOUND;
    if (it->second.state != UsbTransferState::ACTIVE) return UsbResult::BAD_STATE;

    it->second.state = UsbTransferState::FAILED;

    stats_.transfersFailed++;
    recordEvent(UsbEventType::TRANSFER_FAILED, UsbResult::OPERATION_FAILED,
                owner, "Transfer " + std::to_string(transferId) + " failed");

    return UsbResult::SUCCESS;
}

bool UsbManager::getTransfer(uint64_t transferId, UsbTransfer& outTransfer) const {
    auto it = transfers_.find(transferId);
    if (it == transfers_.end()) return false;
    outTransfer = it->second;
    return true;
}

std::vector<UsbTransfer> UsbManager::getActiveTransfers() const {
    std::vector<UsbTransfer> result;
    for (const auto& [id, transfer] : transfers_) {
        if (transfer.state == UsbTransferState::ACTIVE || transfer.state == UsbTransferState::PENDING) {
            result.push_back(transfer);
        }
    }
    return result;
}

std::vector<UsbTransfer> UsbManager::getAllTransfers() const {
    std::vector<UsbTransfer> result;
    result.reserve(transfers_.size());
    for (const auto& [id, transfer] : transfers_) {
        result.push_back(transfer);
    }
    return result;
}

// ============================================================
// Debugging
// ============================================================

UsbResult UsbManager::enableDebugging(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) {
        // Non-system apps need allowDebugging=true in their policy
        auto it = appPolicies_.find(owner);
        if (it == appPolicies_.end() || !it->second.allowDebugging)
            return UsbResult::PERMISSION_DENIED;
        // BLOCK_DEBUGGING flag blocks debugging even with allowDebugging
        if (it->second.privacyFlags & USB_PRIVACY_BLOCK_DEBUGGING)
            return UsbResult::PERMISSION_DENIED;
    }
    if (portState_ == UsbState::DISCONNECTED) return UsbResult::NOT_CONNECTED;
    if (debuggingEnabled_) return UsbResult::BAD_STATE;

    debuggingEnabled_ = true;
    stats_.debuggingToggles++;
    recordEvent(UsbEventType::DEBUGGING_TOGGLED, UsbResult::SUCCESS,
                owner, "Debugging enabled");
    logToServer("WARN", "USB debugging enabled");

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::disableDebugging(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; stats_.totalFailures++; return UsbResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (!debuggingEnabled_) return UsbResult::BAD_STATE;

    debuggingEnabled_ = false;
    stats_.debuggingToggles++;
    recordEvent(UsbEventType::DEBUGGING_TOGGLED, UsbResult::SUCCESS,
                owner, "Debugging disabled");
    logToServer("INFO", "USB debugging disabled");

    return UsbResult::SUCCESS;
}

// ============================================================
// Permission / policy
// ============================================================

UsbResult UsbManager::setAppUsbPolicy(const std::string& appId,
                                      UsbPermission permission,
                                      UsbPrivacyMode privacyMode,
                                      uint32_t privacyFlags,
                                      bool allowDebugging,
                                      const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (appId.empty()) return UsbResult::INVALID_PARAMETER;

    UsbPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.allowDebugging = allowDebugging;
    policy.lastGrantedAt = (permission != UsbPermission::DENY) ? getCurrentTimeMs() : 0;
    policy.oneShotUsed = false;
    policy.foreground = false;

    // Preserve foreground state if updating existing policy
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) {
        policy.foreground = it->second.foreground;
    }

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;
    if (privacyFlags != USB_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }
    recordEvent(UsbEventType::PERMISSION_CHANGED, UsbResult::SUCCESS,
                owner, "Policy set for " + appId);

    return UsbResult::SUCCESS;
}

UsbPolicy UsbManager::getAppUsbPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    UsbPolicy defaultPolicy;
    defaultPolicy.appId = appId;
    return defaultPolicy;
}

UsbResult UsbManager::clearAppUsbPolicy(const std::string& appId,
                                       const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return UsbResult::DEVICE_NOT_FOUND;

    // Remove from active users if present
    auto userIt = std::find(activeUsbUsers_.begin(), activeUsbUsers_.end(), appId);
    if (userIt != activeUsbUsers_.end()) {
        activeUsbUsers_.erase(userIt);
        updatePrivacyIndicator();
    }

    appPolicies_.erase(it);
    stats_.permissionsChanged++;
    recordEvent(UsbEventType::PERMISSION_CHANGED, UsbResult::SUCCESS,
                owner, "Policy cleared for " + appId);

    return UsbResult::SUCCESS;
}

bool UsbManager::checkAppAccess(const std::string& appId) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const UsbPolicy& policy = it->second;

    // REQUIRE_FOREGROUND flag overrides permission to require foreground
    if ((policy.privacyFlags & USB_PRIVACY_REQUIRE_FOREGROUND) && !policy.foreground)
        return false;

    switch (policy.permission) {
        case UsbPermission::DENY:
            return false;
        case UsbPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case UsbPermission::ALLOW_ALWAYS:
            return true;
        case UsbPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

UsbResult UsbManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return UsbResult::DEVICE_NOT_FOUND;

    it->second.foreground = foreground;

    return UsbResult::SUCCESS;
}

// ============================================================
// Identifier access
// ============================================================

UsbResult UsbManager::getDeviceSerial(const std::string& deviceId, std::string& outSerial,
                                       const std::string& appId) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    auto it = devices_.find(deviceId);
    if (it == devices_.end()) return UsbResult::DEVICE_NOT_FOUND;

    if (!isSystemOwner(appId)) {
        if (!checkAppAccess(appId))
            return UsbResult::PERMISSION_DENIED;

        // Consume ALLOW_ONCE
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.permission == UsbPermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }
    }

    outSerial = applyPrivacyTransform(it->second.serial, appId);
    return UsbResult::SUCCESS;
}

UsbResult UsbManager::getDeviceInfo(const std::string& deviceId, UsbDevice& outDevice,
                                     const std::string& appId) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    auto it = devices_.find(deviceId);
    if (it == devices_.end()) return UsbResult::DEVICE_NOT_FOUND;

    if (!isSystemOwner(appId)) {
        if (!checkAppAccess(appId))
            return UsbResult::PERMISSION_DENIED;

        // Consume ALLOW_ONCE
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.permission == UsbPermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }

        // Copy to local before applying privacy transforms
        UsbDevice local = it->second;

        // Apply privacy transform to serial
        local.serial = applyPrivacyTransform(it->second.serial, appId);

        // METADATA_ONLY: redact vendor/product IDs
        if (policyIt != appPolicies_.end()) {
            if (policyIt->second.privacyMode == UsbPrivacyMode::METADATA_ONLY ||
                (policyIt->second.privacyFlags & USB_PRIVACY_METADATA_ONLY)) {
                local.vendorId = 0;
                local.productId = 0;
                local.serial = "[REDACTED]";
            }
        }

        // Only assign to output after all privacy transforms applied
        outDevice = local;
    } else {
        outDevice = it->second;
    }

    return UsbResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<UsbEvent> UsbManager::getHistory(const std::string& appId,
                                             size_t limit) const {
    std::vector<UsbEvent> result;
    for (const auto& event : history_) {
        if (isSystemOwner(appId) || event.appId == appId) {
            result.push_back(event);
        }
    }
    if (limit > 0 && result.size() > limit) {
        result.resize(limit);
    }
    return result;
}

UsbResult UsbManager::clearHistory(const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    // Archive events to history before clearing
    for (const auto& event : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(event);
    }

    history_.clear();
    stats_.historyClears++;
    recordEvent(UsbEventType::HISTORY_CLEARED, UsbResult::SUCCESS,
                owner, "History cleared");

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::clearAppHistory(const std::string& appId,
                                      const std::string& requester) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    bool isSystem = isSystemOwner(requester);
    if (!isSystem && appId != requester) return UsbResult::PERMISSION_DENIED;

    auto it = history_.begin();
    while (it != history_.end()) {
        if (it->appId == appId) {
            it = history_.erase(it);
        } else {
            ++it;
        }
    }

    return UsbResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

UsbResult UsbManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    return UsbResult::SUCCESS;
}

UsbResult UsbManager::setMockDevice(const UsbDevice& device, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (device.id.empty()) return UsbResult::INVALID_PARAMETER;

    // Replace existing mock device or add new one
    bool found = false;
    for (auto& dev : mockDevices_) {
        if (dev.id == device.id) {
            dev = device;
            found = true;
            break;
        }
    }
    if (!found) {
        mockDevices_.push_back(device);
    }

    stats_.mockDevicesSet++;
    recordEvent(UsbEventType::MOCK_DEVICE_SET, UsbResult::SUCCESS,
                owner, "Mock device: " + device.name);

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::addMockDevice(const UsbDevice& device, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;
    if (device.id.empty()) return UsbResult::INVALID_PARAMETER;

    for (const auto& dev : mockDevices_) {
        if (dev.id == device.id) return UsbResult::ALREADY_CONNECTED;
    }

    mockDevices_.push_back(device);
    stats_.mockDevicesSet++;
    recordEvent(UsbEventType::MOCK_DEVICE_SET, UsbResult::SUCCESS,
                owner, "Mock device added: " + device.name);

    return UsbResult::SUCCESS;
}

UsbResult UsbManager::removeMockDevice(const std::string& deviceId, const std::string& owner) {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return UsbResult::PERMISSION_DENIED;

    auto it = std::find_if(mockDevices_.begin(), mockDevices_.end(),
                           [&deviceId](const UsbDevice& d) { return d.id == deviceId; });
    if (it == mockDevices_.end()) return UsbResult::DEVICE_NOT_FOUND;

    mockDevices_.erase(it);
    return UsbResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<UsbEvent> UsbManager::getEvents(size_t limit) const {
    std::vector<UsbEvent> result;
    if (limit == 0) {
        result = events_;
    } else {
        size_t start = (events_.size() > limit) ? (events_.size() - limit) : 0;
        for (size_t i = start; i < events_.size(); ++i) {
            result.push_back(events_[i]);
        }
    }
    return result;
}

std::vector<UsbEvent> UsbManager::getEventsByType(UsbEventType type) const {
    std::vector<UsbEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
        }
    }
    return result;
}

UsbResult UsbManager::clearEvents() {
    if (!initialized_) return UsbResult::NOT_INITIALIZED;

    // Archive events to history before clearing
    for (const auto& event : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(event);
    }

    events_.clear();
    return UsbResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void UsbManager::resetStats() {
    stats_ = UsbStats{};
}

// ============================================================
// Private helpers
// ============================================================

uint64_t UsbManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
}

bool UsbManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "root" || app.empty();
}

void UsbManager::recordEvent(UsbEventType type, UsbResult result,
                             const std::string& appId,
                             const std::string& detail) {
    UsbEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.detail = detail;

    // Add to events ring buffer
    if (events_.size() >= maxEvents_) {
        events_.erase(events_.begin());
    }
    events_.push_back(event);

    // Add to history (unless NO_HISTORY flag set for this app)
    bool noHistory = false;
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && (it->second.privacyFlags & USB_PRIVACY_NO_HISTORY)) {
            noHistory = true;
        }
    }

    if (!noHistory) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(event);
    }

    // Update stats
    uint8_t typeIdx = static_cast<uint8_t>(type);
    uint8_t resultIdx = static_cast<uint8_t>(result);
    if (typeIdx < 15) stats_.byEventType[typeIdx]++;
    if (resultIdx < 14) stats_.byResult[resultIdx]++;

    if (result != UsbResult::SUCCESS) {
        stats_.totalFailures++;
    }

    if (type == UsbEventType::INDICATOR_ON || type == UsbEventType::INDICATOR_OFF) {
        stats_.indicatorToggleCount++;
    }

    // Fire callbacks
    if (eventCallback_) {
        eventCallback_(event);
    }
    if (accessCallback_ && !isSystemOwner(appId)) {
        accessCallback_(appId, result);
    }
}

void UsbManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "UsbManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "UsbManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "UsbManager");
    }
}

void UsbManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("UsbManager", "UsbManager", 0, reason);
}

void UsbManager::updatePrivacyIndicator() {
    bool indicatorOn = !activeUsbUsers_.empty();
    if (indicatorOn != prevIndicatorOn_) {
        prevIndicatorOn_ = indicatorOn;
        if (indicatorOn) {
            recordEvent(UsbEventType::INDICATOR_ON, UsbResult::SUCCESS,
                        "system", "USB indicator ON");
        } else {
            recordEvent(UsbEventType::INDICATOR_OFF, UsbResult::SUCCESS,
                        "system", "USB indicator OFF");
        }
    }
}

void UsbManager::createDefaultMockDevices() {
    UsbDevice dev1;
    dev1.id = "mock_usb_storage_1";
    dev1.name = "Mock USB Storage";
    dev1.vendorId = 0x05AC;
    dev1.productId = 0x1234;
    dev1.deviceClass = UsbDeviceClass::STORAGE;
    dev1.serial = "MOCK001";
    dev1.trusted = true;
    mockDevices_.push_back(dev1);

    UsbDevice dev2;
    dev2.id = "mock_usb_hid_1";
    dev2.name = "Mock USB HID";
    dev2.vendorId = 0x05AC;
    dev2.productId = 0x5678;
    dev2.deviceClass = UsbDeviceClass::HID;
    dev2.serial = "MOCK002";
    dev2.trusted = false;
    mockDevices_.push_back(dev2);

    UsbDevice dev3;
    dev3.id = "mock_usb_audio_1";
    dev3.name = "Mock USB Audio";
    dev3.vendorId = 0x05AC;
    dev3.productId = 0x9ABC;
    dev3.deviceClass = UsbDeviceClass::AUDIO;
    dev3.serial = "MOCK003";
    dev3.trusted = true;
    mockDevices_.push_back(dev3);
}

std::string UsbManager::applyPrivacyTransform(const std::string& serial,
                                              const std::string& appId) const {
    if (isSystemOwner(appId)) return serial;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return "[REDACTED]";

    const UsbPolicy& policy = it->second;
    uint32_t flags = policy.privacyFlags;

    // METADATA_ONLY: no serial at all
    if (policy.privacyMode == UsbPrivacyMode::METADATA_ONLY ||
        (flags & USB_PRIVACY_METADATA_ONLY)) {
        return "[REDACTED]";
    }

    // REDACTED mode: mask serial
    if (policy.privacyMode == UsbPrivacyMode::REDACTED ||
        (flags & USB_PRIVACY_REDACT_SERIAL)) {
        if (serial.length() <= 2) return "[REDACTED]";
        return serial.substr(0, 2) + std::string(serial.length() - 2, '*');
    }

    // PSEUDONYMIZE: deterministic pseudonym
    if (flags & USB_PRIVACY_PSEUDONYMIZE) {
        return pseudonymizeDeviceId(serial);
    }

    return serial;
}

std::string UsbManager::pseudonymizeDeviceId(const std::string& id) const {
    uint32_t hash = fnv1aHash(id);
    std::stringstream ss;
    ss << "PSUDO-" << std::hex << hash;
    return ss.str();
}

// ============================================================
// String helpers
// ============================================================

const char* UsbManager::stateToString(UsbState state) {
    switch (state) {
        case UsbState::DISCONNECTED: return "DISCONNECTED";
        case UsbState::CONNECTED: return "CONNECTED";
        case UsbState::CONFIGURED: return "CONFIGURED";
        case UsbState::SUSPENDED: return "SUSPENDED";
        case UsbState::ERROR_STATE: return "ERROR_STATE";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::modeToString(UsbMode mode) {
    switch (mode) {
        case UsbMode::NONE: return "NONE";
        case UsbMode::CHARGING_ONLY: return "CHARGING_ONLY";
        case UsbMode::MTP: return "MTP";
        case UsbMode::PTP: return "PTP";
        case UsbMode::TETHERING: return "TETHERING";
        case UsbMode::DEBUG: return "DEBUG";
        case UsbMode::ACCESSORY: return "ACCESSORY";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::roleToString(UsbRole role) {
    switch (role) {
        case UsbRole::DEVICE: return "DEVICE";
        case UsbRole::HOST: return "HOST";
        case UsbRole::OTG: return "OTG";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::deviceClassToString(UsbDeviceClass cls) {
    switch (cls) {
        case UsbDeviceClass::UNKNOWN: return "UNKNOWN";
        case UsbDeviceClass::AUDIO: return "AUDIO";
        case UsbDeviceClass::COMM: return "COMM";
        case UsbDeviceClass::HID: return "HID";
        case UsbDeviceClass::STORAGE: return "STORAGE";
        case UsbDeviceClass::HUB: return "HUB";
        case UsbDeviceClass::VIDEO: return "VIDEO";
        case UsbDeviceClass::WIRELESS: return "WIRELESS";
        case UsbDeviceClass::MISCELLANEOUS: return "MISCELLANEOUS";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::transferDirectionToString(UsbTransferDirection dir) {
    switch (dir) {
        case UsbTransferDirection::IN: return "IN";
        case UsbTransferDirection::OUT: return "OUT";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::transferStateToString(UsbTransferState state) {
    switch (state) {
        case UsbTransferState::PENDING: return "PENDING";
        case UsbTransferState::ACTIVE: return "ACTIVE";
        case UsbTransferState::COMPLETED: return "COMPLETED";
        case UsbTransferState::FAILED: return "FAILED";
        case UsbTransferState::CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::permissionToString(UsbPermission permission) {
    switch (permission) {
        case UsbPermission::DENY: return "DENY";
        case UsbPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case UsbPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case UsbPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::privacyModeToString(UsbPrivacyMode mode) {
    switch (mode) {
        case UsbPrivacyMode::FULL: return "FULL";
        case UsbPrivacyMode::REDACTED: return "REDACTED";
        case UsbPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::resultToString(UsbResult result) {
    switch (result) {
        case UsbResult::SUCCESS: return "SUCCESS";
        case UsbResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case UsbResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case UsbResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case UsbResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case UsbResult::NOT_CONNECTED: return "NOT_CONNECTED";
        case UsbResult::ALREADY_CONNECTED: return "ALREADY_CONNECTED";
        case UsbResult::DEVICE_NOT_FOUND: return "DEVICE_NOT_FOUND";
        case UsbResult::MODE_NOT_SUPPORTED: return "MODE_NOT_SUPPORTED";
        case UsbResult::ROLE_NOT_SUPPORTED: return "ROLE_NOT_SUPPORTED";
        case UsbResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case UsbResult::BAD_STATE: return "BAD_STATE";
        case UsbResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case UsbResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* UsbManager::eventTypeToString(UsbEventType type) {
    switch (type) {
        case UsbEventType::STATE_CHANGED: return "STATE_CHANGED";
        case UsbEventType::DEVICE_CONNECTED: return "DEVICE_CONNECTED";
        case UsbEventType::DEVICE_DISCONNECTED: return "DEVICE_DISCONNECTED";
        case UsbEventType::MODE_CHANGED: return "MODE_CHANGED";
        case UsbEventType::ROLE_CHANGED: return "ROLE_CHANGED";
        case UsbEventType::TRANSFER_STARTED: return "TRANSFER_STARTED";
        case UsbEventType::TRANSFER_COMPLETED: return "TRANSFER_COMPLETED";
        case UsbEventType::TRANSFER_FAILED: return "TRANSFER_FAILED";
        case UsbEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case UsbEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case UsbEventType::INDICATOR_ON: return "INDICATOR_ON";
        case UsbEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case UsbEventType::MOCK_DEVICE_SET: return "MOCK_DEVICE_SET";
        case UsbEventType::DEBUGGING_TOGGLED: return "DEBUGGING_TOGGLED";
        case UsbEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

UsbResult UsbManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return UsbResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return UsbResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return UsbResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return UsbResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return UsbResult::PERMISSION_DENIED;
    if (str == "NOT_CONNECTED") return UsbResult::NOT_CONNECTED;
    if (str == "ALREADY_CONNECTED") return UsbResult::ALREADY_CONNECTED;
    if (str == "DEVICE_NOT_FOUND") return UsbResult::DEVICE_NOT_FOUND;
    if (str == "MODE_NOT_SUPPORTED") return UsbResult::MODE_NOT_SUPPORTED;
    if (str == "ROLE_NOT_SUPPORTED") return UsbResult::ROLE_NOT_SUPPORTED;
    if (str == "CAPACITY_EXCEEDED") return UsbResult::CAPACITY_EXCEEDED;
    if (str == "BAD_STATE") return UsbResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return UsbResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return UsbResult::SIMULATED_FAILURE;
    return UsbResult::SUCCESS;
}

UsbMode UsbManager::stringToMode(const std::string& str) {
    if (str == "NONE") return UsbMode::NONE;
    if (str == "CHARGING_ONLY") return UsbMode::CHARGING_ONLY;
    if (str == "MTP") return UsbMode::MTP;
    if (str == "PTP") return UsbMode::PTP;
    if (str == "TETHERING") return UsbMode::TETHERING;
    if (str == "DEBUG") return UsbMode::DEBUG;
    if (str == "ACCESSORY") return UsbMode::ACCESSORY;
    return UsbMode::NONE;
}

UsbDeviceClass UsbManager::stringToDeviceClass(const std::string& str) {
    if (str == "UNKNOWN") return UsbDeviceClass::UNKNOWN;
    if (str == "AUDIO") return UsbDeviceClass::AUDIO;
    if (str == "COMM") return UsbDeviceClass::COMM;
    if (str == "HID") return UsbDeviceClass::HID;
    if (str == "STORAGE") return UsbDeviceClass::STORAGE;
    if (str == "HUB") return UsbDeviceClass::HUB;
    if (str == "VIDEO") return UsbDeviceClass::VIDEO;
    if (str == "WIRELESS") return UsbDeviceClass::WIRELESS;
    if (str == "MISCELLANEOUS") return UsbDeviceClass::MISCELLANEOUS;
    return UsbDeviceClass::UNKNOWN;
}

}  // namespace usb
}  // namespace phantom
