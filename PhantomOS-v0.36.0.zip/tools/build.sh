#!/bin/bash
# Phantom OS - Build Script
# Usage: ./tools/build.sh [Debug|Release]
#
# License: GPL-3.0

set -e

BUILD_TYPE="${1:-Release}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_ROOT/build"

echo "=== Phantom OS Build ==="
echo "Build type: $BUILD_TYPE"
echo "Project root: $PROJECT_ROOT"
echo ""

# Create build directory
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Configure
echo "Configuring..."
cmake .. -DCMAKE_BUILD_TYPE="$BUILD_TYPE"

# Build
echo ""
echo "Building..."
cmake --build . -j$(nproc)

# Test
echo ""
echo "Running tests..."
ctest --output-on-failure

echo ""
echo "=== Build complete ==="
echo "Mock runtime: $BUILD_DIR/bin/phantom_mock_runtime"
