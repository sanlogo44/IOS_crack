/*
 * Phantom OS - Configuration System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/config/config.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace phantom::config {

std::string Config::trim(const std::string& s) {
    size_t start = 0;
    while (start < s.length() && std::isspace(static_cast<unsigned char>(s[start]))) {
        start++;
    }
    size_t end = s.length();
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1]))) {
        end--;
    }
    return s.substr(start, end - start);
}

void Config::defineProperty(const std::string& key, PropertyType type,
                            const std::string& defaultValue,
                            const std::string& description) {
    definitions_[key] = {key, type, defaultValue, description};
}

bool Config::set(const std::string& key, const std::string& value) {
    if (definitions_.find(key) == definitions_.end()) return false;
    overrides_[key] = value;
    return true;
}

bool Config::setInt(const std::string& key, int64_t value) {
    return set(key, std::to_string(value));
}

bool Config::setBool(const std::string& key, bool value) {
    return set(key, value ? "true" : "false");
}

bool Config::setFloat(const std::string& key, double value) {
    return set(key, std::to_string(value));
}

std::string Config::get(const std::string& key) const {
    auto it = overrides_.find(key);
    if (it != overrides_.end()) return it->second;

    auto defIt = definitions_.find(key);
    if (defIt != definitions_.end()) return defIt->second.defaultValue;

    return "";
}

int64_t Config::getInt(const std::string& key) const {
    std::string val = get(key);
    try {
        return std::stoll(val);
    } catch (...) {
        return 0;
    }
}

bool Config::getBool(const std::string& key) const {
    std::string val = get(key);
    // Lowercase comparison
    std::string lower;
    lower.reserve(val.length());
    for (char c : val) {
        lower += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return (lower == "true" || lower == "1" || lower == "yes" || lower == "on");
}

double Config::getFloat(const std::string& key) const {
    std::string val = get(key);
    try {
        return std::stod(val);
    } catch (...) {
        return 0.0;
    }
}

bool Config::isDefined(const std::string& key) const {
    return definitions_.find(key) != definitions_.end();
}

bool Config::isOverridden(const std::string& key) const {
    return overrides_.find(key) != overrides_.end();
}

std::vector<std::string> Config::getDefinedKeys() const {
    std::vector<std::string> keys;
    keys.reserve(definitions_.size());
    for (const auto& pair : definitions_) {
        keys.push_back(pair.first);
    }
    return keys;
}

std::vector<std::string> Config::getOverriddenKeys() const {
    std::vector<std::string> keys;
    keys.reserve(overrides_.size());
    for (const auto& pair : overrides_) {
        keys.push_back(pair.first);
    }
    return keys;
}

int Config::loadFromString(const std::string& content) {
    int count = 0;
    std::istringstream stream(content);
    std::string line;

    while (std::getline(stream, line)) {
        std::string trimmed = trim(line);

        // Skip empty lines and comments
        if (trimmed.empty()) continue;
        if (trimmed[0] == '#' || trimmed[0] == '!') continue;

        // Find separator
        size_t sep = trimmed.find('=');
        if (sep == std::string::npos) {
            sep = trimmed.find(':');
        }
        if (sep == std::string::npos) continue;

        std::string key = trim(trimmed.substr(0, sep));
        std::string value = trim(trimmed.substr(sep + 1));

        if (key.empty()) continue;

        // Only set if defined, otherwise define as string
        if (!isDefined(key)) {
            defineProperty(key, PropertyType::STRING, value, "");
        } else {
            set(key, value);
        }
        count++;
    }

    return count;
}

bool Config::loadFromFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::stringstream ss;
    ss << file.rdbuf();
    file.close();

    loadFromString(ss.str());
    return true;
}

std::string Config::saveToString() const {
    std::ostringstream ss;

    // Write definitions that are not overridden
    for (const auto& pair : definitions_) {
        const PropertyInfo& info = pair.second;
        std::string value = get(info.key);
        ss << "# " << info.description << "\n";
        ss << info.key << "=" << value << "\n";
    }

    return ss.str();
}

bool Config::saveToFile(const std::string& path) const {
    std::ofstream file(path);
    if (!file.is_open()) return false;
    file << saveToString();
    file.close();
    return true;
}

void Config::clearOverrides() {
    overrides_.clear();
}

void Config::clear() {
    definitions_.clear();
    overrides_.clear();
}

const PropertyInfo* Config::getPropertyInfo(const std::string& key) const {
    auto it = definitions_.find(key);
    if (it == definitions_.end()) return nullptr;
    return &it->second;
}

std::vector<PropertyInfo> Config::getAllPropertyInfo() const {
    std::vector<PropertyInfo> result;
    result.reserve(definitions_.size());
    for (const auto& pair : definitions_) {
        result.push_back(pair.second);
    }
    return result;
}

}  // namespace phantom::config
