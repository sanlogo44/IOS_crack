/*
 * Phantom OS - Property-Based Configuration System
 * Key-value store with typed access, defaults, and .properties format
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <unordered_map>
#include <vector>
#include <cstdint>

namespace phantom::config {

enum class PropertyType {
    STRING = 0,
    INTEGER = 1,
    BOOLEAN = 2,
    FLOAT = 3,
};

struct PropertyInfo {
    std::string key;
    PropertyType type;
    std::string defaultValue;
    std::string description;
};

class Config {
public:
    Config() = default;

    // Define a property with default value
    void defineProperty(const std::string& key, PropertyType type,
                        const std::string& defaultValue,
                        const std::string& description = "");

    // Set a property value (returns false if key not defined)
    bool set(const std::string& key, const std::string& value);
    bool setInt(const std::string& key, int64_t value);
    bool setBool(const std::string& key, bool value);
    bool setFloat(const std::string& key, double value);

    // Get a property value (returns default if not set)
    std::string get(const std::string& key) const;
    int64_t getInt(const std::string& key) const;
    bool getBool(const std::string& key) const;
    double getFloat(const std::string& key) const;

    // Check if a property is defined
    bool isDefined(const std::string& key) const;
    bool isOverridden(const std::string& key) const;

    // Get all defined property keys
    std::vector<std::string> getDefinedKeys() const;
    std::vector<std::string> getOverriddenKeys() const;

    // Load from .properties format string
    // Format: key=value (one per line, # comments, ! comments)
    // Returns number of properties loaded
    int loadFromString(const std::string& content);

    // Load from file
    bool loadFromFile(const std::string& path);

    // Save to .properties format string
    std::string saveToString() const;

    // Save to file
    bool saveToFile(const std::string& path) const;

    // Clear all overrides (revert to defaults)
    void clearOverrides();

    // Clear everything (definitions and overrides)
    void clear();

    // Get property info
    const PropertyInfo* getPropertyInfo(const std::string& key) const;

    // Get all property info
    std::vector<PropertyInfo> getAllPropertyInfo() const;

    // Count
    size_t getDefinedCount() const { return definitions_.size(); }
    size_t getOverriddenCount() const { return overrides_.size(); }

private:
    std::unordered_map<std::string, PropertyInfo> definitions_;
    std::unordered_map<std::string, std::string> overrides_;

    // Trim whitespace
    static std::string trim(const std::string& s);
};

}  // namespace phantom::config
