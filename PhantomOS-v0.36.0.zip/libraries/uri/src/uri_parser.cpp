/*
 * Phantom OS - URI Scheme Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/uri/uri_parser.h"
#include <cctype>
#include <sstream>
#include <iomanip>

namespace phantom::uri {

// PhAppUri methods

std::string PhAppUri::getParam(const std::string& key, const std::string& defaultValue) const {
    auto it = queryParams.find(key);
    if (it != queryParams.end()) return it->second;
    return defaultValue;
}

bool PhAppUri::hasParam(const std::string& key) const {
    return queryParams.find(key) != queryParams.end();
}

std::vector<std::string> PhAppUri::getParamKeys() const {
    std::vector<std::string> keys;
    keys.reserve(queryParams.size());
    for (const auto& pair : queryParams) {
        keys.push_back(pair.first);
    }
    return keys;
}

std::string PhAppUri::toString() const {
    std::string result = scheme + "://" + appId;
    if (!path.empty()) {
        if (path[0] != '/') result += "/";
        result += path;
    }
    if (!queryParams.empty()) {
        result += "?";
        bool first = true;
        for (const auto& pair : queryParams) {
            if (!first) result += "&";
            result += UriParser::percentEncode(pair.first);
            result += "=";
            result += UriParser::percentEncode(pair.second);
            first = false;
        }
    }
    return result;
}

bool PhAppUri::isValid() const {
    return scheme == "phapp" && !appId.empty() && UriParser::isValidAppId(appId);
}

// UriParser methods

bool UriParser::isValidAppId(const std::string& appId) {
    if (appId.empty()) return false;
    for (char c : appId) {
        if (!std::isalnum(static_cast<unsigned char>(c)) && c != '-' && c != '_' && c != '.') {
            return false;
        }
    }
    return true;
}

void UriParser::parseQueryString(const std::string& query,
                                 std::unordered_map<std::string, std::string>& params) {
    std::string current;
    for (size_t i = 0; i <= query.length(); ++i) {
        char c = (i < query.length()) ? query[i] : '&';
        if (c == '&') {
            // Process current param
            size_t eq = current.find('=');
            if (eq != std::string::npos) {
                std::string key = percentDecode(current.substr(0, eq));
                std::string value = percentDecode(current.substr(eq + 1));
                params[key] = value;
            } else if (!current.empty()) {
                std::string key = percentDecode(current);
                params[key] = "";
            }
            current.clear();
        } else {
            current += c;
        }
    }
}

std::string UriParser::percentDecode(const std::string& s) {
    std::string result;
    for (size_t i = 0; i < s.length(); ++i) {
        if (s[i] == '%' && i + 2 < s.length()) {
            std::string hex = s.substr(i + 1, 2);
            try {
                int val = std::stoi(hex, nullptr, 16);
                result += static_cast<char>(val);
                i += 2;
            } catch (...) {
                result += s[i];
            }
        } else if (s[i] == '+') {
            result += ' ';
        } else {
            result += s[i];
        }
    }
    return result;
}

std::string UriParser::percentEncode(const std::string& s) {
    std::ostringstream ss;
    for (char c : s) {
        if (std::isalnum(static_cast<unsigned char>(c)) || c == '-' || c == '_' || c == '.' || c == '~') {
            ss << c;
        } else {
            ss << '%' << std::uppercase << std::setfill('0') << std::setw(2)
               << std::hex << static_cast<int>(static_cast<unsigned char>(c));
        }
    }
    return ss.str();
}

std::string UriParser::getScheme(const std::string& uri) {
    size_t pos = uri.find("://");
    if (pos == std::string::npos) return "";
    return uri.substr(0, pos);
}

bool UriParser::isValid(const std::string& uri) {
    PhAppUri parsed;
    return parse(uri, parsed);
}

bool UriParser::parse(const std::string& uri, PhAppUri& out) {
    out = PhAppUri{};

    // Check scheme
    size_t schemeEnd = uri.find("://");
    if (schemeEnd == std::string::npos) return false;

    std::string scheme = uri.substr(0, schemeEnd);
    if (scheme != "phapp") return false;

    std::string rest = uri.substr(schemeEnd + 3);
    if (rest.empty()) return false;

    // Split off query string
    std::string query;
    size_t queryPos = rest.find('?');
    if (queryPos != std::string::npos) {
        query = rest.substr(queryPos + 1);
        rest = rest.substr(0, queryPos);
    }

    // Split app ID and path
    std::string appId;
    std::string path;

    size_t pathPos = rest.find('/');
    if (pathPos != std::string::npos) {
        appId = rest.substr(0, pathPos);
        path = rest.substr(pathPos + 1);
        // Ensure path starts without leading slash (stored relative)
    } else {
        appId = rest;
        path = "";
    }

    // Validate app ID
    if (!isValidAppId(appId)) return false;

    out.scheme = scheme;
    out.appId = appId;
    out.path = path;

    // Parse query params
    if (!query.empty()) {
        parseQueryString(query, out.queryParams);
    }

    return true;
}

}  // namespace phantom::uri
