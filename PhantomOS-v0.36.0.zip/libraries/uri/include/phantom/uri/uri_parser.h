/*
 * Phantom OS - Custom URI Scheme (phapp://)
 * Parser and validator for phapp:// URIs
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <unordered_map>
#include <vector>

namespace phantom::uri {

struct PhAppUri {
    std::string scheme;       // "phapp"
    std::string appId;        // host portion (e.g., "settings")
    std::string path;         // path portion (e.g., "/wifi")
    std::unordered_map<std::string, std::string> queryParams;

    // Get a query parameter
    std::string getParam(const std::string& key, const std::string& defaultValue = "") const;

    // Check if a query parameter exists
    bool hasParam(const std::string& key) const;

    // Get all query parameter keys
    std::vector<std::string> getParamKeys() const;

    // Reconstruct the URI string
    std::string toString() const;

    // Check if this is a valid phapp URI
    bool isValid() const;
};

class UriParser {
public:
    // Parse a URI string into a PhAppUri
    // Returns false if parsing fails
    static bool parse(const std::string& uri, PhAppUri& out);

    // Quick validation check
    static bool isValid(const std::string& uri);

    // Get the scheme from a URI string
    static std::string getScheme(const std::string& uri);

    // Percent-decode a string
    static std::string percentDecode(const std::string& s);

    // Percent-encode a string
    static std::string percentEncode(const std::string& s);

public:
    // Validate app ID (alphanumeric, dash, underscore, dot)
    static bool isValidAppId(const std::string& appId);

private:
    // Parse query string into key-value pairs
    static void parseQueryString(const std::string& query,
                                 std::unordered_map<std::string, std::string>& params);
};

}  // namespace phantom::uri
