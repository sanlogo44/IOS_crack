/*
 * Phantom OS - IPC Message Bus Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/ipc/message_bus.h"
#include <chrono>
#include <algorithm>
#include <cstdio>

namespace phantom::ipc {

MessageBus& MessageBus::getInstance() {
    static MessageBus instance;
    return instance;
}

IpcResult MessageBus::registerEndpoint(const std::string& endpointId,
                                       const std::string& ownerApp,
                                       MessageHandler handler) {
    if (endpointId.empty()) return IpcResult::INVALID_ENDPOINT_NAME;

    std::lock_guard<std::mutex> lock(mutex_);
    if (endpoints_.find(endpointId) != endpoints_.end()) {
        return IpcResult::ENDPOINT_ALREADY_EXISTS;
    }

    Endpoint ep;
    ep.info.id = endpointId;
    ep.info.owner_app = ownerApp;
    ep.info.state = EndpointState::ACTIVE;
    ep.info.messages_received = 0;
    ep.info.messages_sent = 0;
    ep.handler = handler;
    ep.round_robin_index = 0;

    endpoints_[endpointId] = std::move(ep);
    return IpcResult::SUCCESS;
}

IpcResult MessageBus::unregisterEndpoint(const std::string& endpointId) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = endpoints_.find(endpointId);
    if (it == endpoints_.end()) return IpcResult::ENDPOINT_NOT_FOUND;

    EndpointState oldState = it->second.info.state;
    endpoints_.erase(it);

    if (state_callback_ && oldState != EndpointState::INACTIVE) {
        state_callback_(endpointId, oldState, EndpointState::INACTIVE);
    }
    return IpcResult::SUCCESS;
}

IpcResult MessageBus::setEndpointHandler(const std::string& endpointId, MessageHandler handler) {
    std::lock_guard<std::mutex> lock(mutex_);
    Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return IpcResult::ENDPOINT_NOT_FOUND;
    ep->handler = handler;
    return IpcResult::SUCCESS;
}

IpcResult MessageBus::setEndpointState(const std::string& endpointId, EndpointState state) {
    std::lock_guard<std::mutex> lock(mutex_);
    Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return IpcResult::ENDPOINT_NOT_FOUND;

    EndpointState oldState = ep->info.state;
    ep->info.state = state;

    if (state_callback_ && oldState != state) {
        state_callback_(endpointId, oldState, state);
    }
    return IpcResult::SUCCESS;
}

IpcResult MessageBus::addAllowedType(const std::string& endpointId, const std::string& messageType) {
    std::lock_guard<std::mutex> lock(mutex_);
    Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return IpcResult::ENDPOINT_NOT_FOUND;

    auto& types = ep->info.allowed_types;
    if (std::find(types.begin(), types.end(), messageType) == types.end()) {
        types.push_back(messageType);
    }
    return IpcResult::SUCCESS;
}

IpcResult MessageBus::removeAllowedType(const std::string& endpointId, const std::string& messageType) {
    std::lock_guard<std::mutex> lock(mutex_);
    Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return IpcResult::ENDPOINT_NOT_FOUND;

    auto& types = ep->info.allowed_types;
    auto it = std::find(types.begin(), types.end(), messageType);
    if (it != types.end()) {
        types.erase(it);
    }
    return IpcResult::SUCCESS;
}

std::string MessageBus::send(const std::string& source, const std::string& target,
                              const std::string& type, const std::string& payload,
                              const std::unordered_map<std::string, std::string>& params) {
    // Collect everything we need under lock, then deliver outside lock
    MessageHandler targetHandler;
    std::string targetId;
    bool targetExists = false;
    bool targetActive = false;
    bool typeAllowed = false;

    {
        std::lock_guard<std::mutex> lock(mutex_);

        uint32_t seq = ++sequence_counter_;
        Message msg;
        msg.id = "msg_" + std::to_string(seq);
        msg.source = source;
        msg.target = target;
        msg.type = type;
        msg.payload = payload;
        msg.params = params;
        msg.priority = MessagePriority::NORMAL;
        msg.delivery = DeliveryMode::DIRECT;
        msg.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        msg.sequence = seq;
        msg.requires_reply = false;

        total_sent_++;

        Endpoint* srcEp = findEndpoint(source);
        if (srcEp) srcEp->info.messages_sent++;

        // Register message for reply lookup
        message_registry_[msg.id] = {source, target};

        Endpoint* tgtEp = findEndpoint(target);
        if (!tgtEp) {
            total_failed_++;
            // Notify delivery callback outside lock
            auto msgId = msg.id;
            auto result = IpcResult::ENDPOINT_NOT_FOUND;
            mutex_.unlock();
            notifyDelivery(msgId, result);
            mutex_.lock();
            return msg.id;
        }

        targetId = target;
        targetExists = true;

        if (tgtEp->info.state != EndpointState::ACTIVE) {
            total_failed_++;
            auto msgId = msg.id;
            auto result = IpcResult::ENDPOINT_NOT_FOUND;
            mutex_.unlock();
            notifyDelivery(msgId, result);
            mutex_.lock();
            return msg.id;
        }

        targetActive = true;

        if (!isTypeAllowedUnsafe(target, type)) {
            total_failed_++;
            auto msgId = msg.id;
            auto result = IpcResult::PERMISSION_DENIED;
            mutex_.unlock();
            notifyDelivery(msgId, result);
            mutex_.lock();
            return msg.id;
        }

        typeAllowed = true;
        targetHandler = tgtEp->handler;
        tgtEp->info.messages_received++;

        // Save message ID for later stats update
        auto msgId = msg.id;

        // Deliver outside lock
        mutex_.unlock();
        bool delivered = false;
        if (targetHandler) {
            delivered = targetHandler(msg);
        }
        mutex_.lock();

        if (delivered) {
            total_delivered_++;
            auto result = IpcResult::SUCCESS;
            mutex_.unlock();
            notifyDelivery(msgId, result);
            mutex_.lock();
        } else {
            total_failed_++;
            auto result = IpcResult::HANDLER_FAILED;
            mutex_.unlock();
            notifyDelivery(msgId, result);
            mutex_.lock();
        }

        return msgId;
    }

    return "";
}

std::string MessageBus::broadcast(const std::string& source,
                                   const std::string& type, const std::string& payload,
                                   const std::unordered_map<std::string, std::string>& params) {
    // Collect candidates and handler list under lock
    std::vector<std::pair<std::string, MessageHandler>> targets;
    std::string msgId;
    Message msgTemplate;

    {
        std::lock_guard<std::mutex> lock(mutex_);

        uint32_t seq = ++sequence_counter_;
        msgId = "msg_" + std::to_string(seq);

        msgTemplate.id = msgId;
        msgTemplate.source = source;
        msgTemplate.target = "";  // Empty for broadcast
        msgTemplate.type = type;
        msgTemplate.payload = payload;
        msgTemplate.params = params;
        msgTemplate.priority = MessagePriority::NORMAL;
        msgTemplate.delivery = DeliveryMode::BROADCAST;
        msgTemplate.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        msgTemplate.sequence = seq;
        msgTemplate.requires_reply = false;

        total_sent_++;

        Endpoint* srcEp = findEndpoint(source);
        if (srcEp) srcEp->info.messages_sent++;

        // Register for reply lookup
        message_registry_[msgId] = {source, ""};

        for (auto& [id, ep] : endpoints_) {
            if (id == source) continue;
            if (ep.info.state != EndpointState::ACTIVE) continue;
            if (!isTypeAllowedUnsafe(id, type)) continue;
            targets.push_back({id, ep.handler});
            ep.info.messages_received++;
        }
    }

    // Deliver outside lock
    uint32_t delivered_count = 0;
    for (auto& [id, handler] : targets) {
        Message copy = msgTemplate;
        copy.target = id;
        if (handler && handler(copy)) {
            delivered_count++;
        }
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        total_delivered_ += delivered_count;

        if (delivered_count == 0) {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::NO_HANDLER);
            mutex_.lock();
        } else {
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::SUCCESS);
            mutex_.lock();
        }
    }

    return msgId;
}

std::string MessageBus::sendRoundRobin(const std::string& source, const std::string& type,
                                        const std::string& payload,
                                        const std::unordered_map<std::string, std::string>& params) {
    std::vector<std::string> candidates;
    size_t rrIndex = 0;
    std::string msgId;
    Message msgTemplate;
    std::string targetId;
    MessageHandler targetHandler;

    {
        std::lock_guard<std::mutex> lock(mutex_);

        // Find all active endpoints that accept this type, excluding source
        for (const auto& [id, ep] : endpoints_) {
            if (id == source) continue;
            if (ep.info.state != EndpointState::ACTIVE) continue;
            if (!isTypeAllowedUnsafe(id, type)) continue;
            candidates.push_back(id);
        }

        uint32_t seq = ++sequence_counter_;
        msgId = "msg_" + std::to_string(seq);

        msgTemplate.id = msgId;
        msgTemplate.source = source;
        msgTemplate.type = type;
        msgTemplate.payload = payload;
        msgTemplate.params = params;
        msgTemplate.priority = MessagePriority::NORMAL;
        msgTemplate.delivery = DeliveryMode::ROUND_ROBIN;
        msgTemplate.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        msgTemplate.sequence = seq;
        msgTemplate.requires_reply = false;

        total_sent_++;

        Endpoint* srcEp = findEndpoint(source);
        if (srcEp) srcEp->info.messages_sent++;

        if (candidates.empty()) {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::NO_HANDLER);
            mutex_.lock();
            return msgId;
        }

        // Get round-robin index from source endpoint
        if (srcEp) {
            if (srcEp->round_robin_index >= candidates.size()) {
                srcEp->round_robin_index = 0;
            }
            rrIndex = srcEp->round_robin_index;
            srcEp->round_robin_index = (rrIndex + 1) % candidates.size();
        }

        targetId = candidates[rrIndex];

        Endpoint* tgtEp = findEndpoint(targetId);
        if (tgtEp) {
            targetHandler = tgtEp->handler;
            tgtEp->info.messages_received++;
            message_registry_[msgId] = {source, targetId};
        }

        msgTemplate.target = targetId;
    }

    // Deliver outside lock
    bool delivered = false;
    if (targetHandler) {
        delivered = targetHandler(msgTemplate);
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (delivered) {
            total_delivered_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::SUCCESS);
            mutex_.lock();
        } else {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::HANDLER_FAILED);
            mutex_.lock();
        }
    }

    return msgId;
}

std::string MessageBus::reply(const std::string& source, const std::string& replyToId,
                              const std::string& payload,
                              const std::unordered_map<std::string, std::string>& params) {
    std::string msgId;
    std::string targetId;
    MessageHandler targetHandler;
    Message msgTemplate;

    {
        std::lock_guard<std::mutex> lock(mutex_);

        // Look up original message to find target
        auto it = message_registry_.find(replyToId);
        std::string originalSource;
        std::string originalTarget;

        if (it != message_registry_.end()) {
            originalSource = it->second.first;
            originalTarget = it->second.second;
        }

        // Reply goes to the original source (which is the target of the reply)
        // If the original message was sent TO us, reply goes back to original source
        // If the original message was sent BY us, reply goes to original target
        if (!originalTarget.empty() && originalTarget == source) {
            // We were the target of the original, reply goes to original source
            targetId = originalSource;
        } else if (!originalSource.empty() && originalSource == source) {
            // We were the source of the original, reply goes to original target
            targetId = originalTarget;
        } else {
            // Can't determine reply target
            targetId = originalSource;
        }

        uint32_t seq = ++sequence_counter_;
        msgId = "msg_" + std::to_string(seq);

        msgTemplate.id = msgId;
        msgTemplate.source = source;
        msgTemplate.target = targetId;
        msgTemplate.type = "reply";
        msgTemplate.payload = payload;
        msgTemplate.params = params;
        msgTemplate.priority = MessagePriority::NORMAL;
        msgTemplate.delivery = DeliveryMode::DIRECT;
        msgTemplate.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        msgTemplate.sequence = seq;
        msgTemplate.requires_reply = false;
        msgTemplate.reply_to = replyToId;

        total_sent_++;

        Endpoint* srcEp = findEndpoint(source);
        if (srcEp) srcEp->info.messages_sent++;

        // Register this reply message
        message_registry_[msgId] = {source, targetId};

        if (targetId.empty()) {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::ENDPOINT_NOT_FOUND);
            mutex_.lock();
            return msgId;
        }

        Endpoint* tgtEp = findEndpoint(targetId);
        if (!tgtEp || tgtEp->info.state != EndpointState::ACTIVE) {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::ENDPOINT_NOT_FOUND);
            mutex_.lock();
            return msgId;
        }

        targetHandler = tgtEp->handler;
        tgtEp->info.messages_received++;
    }

    // Deliver outside lock
    bool delivered = false;
    if (targetHandler) {
        delivered = targetHandler(msgTemplate);
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (delivered) {
            total_delivered_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::SUCCESS);
            mutex_.lock();
        } else {
            total_failed_++;
            mutex_.unlock();
            notifyDelivery(msgId, IpcResult::HANDLER_FAILED);
            mutex_.lock();
        }
    }

    return msgId;
}

bool MessageBus::isEndpointRegistered(const std::string& endpointId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return endpoints_.find(endpointId) != endpoints_.end();
}

bool MessageBus::isEndpointActive(const std::string& endpointId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const Endpoint* ep = findEndpoint(endpointId);
    return ep && ep->info.state == EndpointState::ACTIVE;
}

EndpointInfo MessageBus::getEndpointInfo(const std::string& endpointId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return EndpointInfo{};
    return ep->info;
}

std::vector<std::string> MessageBus::getRegisteredEndpoints() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, ep] : endpoints_) {
        result.push_back(id);
    }
    return result;
}

std::vector<std::string> MessageBus::getActiveEndpoints() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, ep] : endpoints_) {
        if (ep.info.state == EndpointState::ACTIVE) {
            result.push_back(id);
        }
    }
    return result;
}

size_t MessageBus::getEndpointCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return endpoints_.size();
}

size_t MessageBus::getActiveEndpointCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    size_t count = 0;
    for (const auto& [id, ep] : endpoints_) {
        if (ep.info.state == EndpointState::ACTIVE) count++;
    }
    return count;
}

uint64_t MessageBus::getTotalMessagesSent() const {
    return total_sent_.load();
}

uint64_t MessageBus::getTotalMessagesDelivered() const {
    return total_delivered_.load();
}

uint64_t MessageBus::getTotalMessagesFailed() const {
    return total_failed_.load();
}

uint64_t MessageBus::getMessagesReceivedBy(const std::string& endpointId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return 0;
    return ep->info.messages_received;
}

uint64_t MessageBus::getMessagesSentBy(const std::string& endpointId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return 0;
    return ep->info.messages_sent;
}

void MessageBus::setEndpointStateCallback(EndpointStateCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    state_callback_ = std::move(callback);
}

void MessageBus::setDeliveryCallback(DeliveryCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    delivery_callback_ = std::move(callback);
}

bool MessageBus::isTypeAllowed(const std::string& endpointId, const std::string& messageType) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return isTypeAllowedUnsafe(endpointId, messageType);
}

void MessageBus::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    endpoints_.clear();
    message_registry_.clear();
    state_callback_ = nullptr;
    delivery_callback_ = nullptr;
    total_sent_ = 0;
    total_delivered_ = 0;
    total_failed_ = 0;
    sequence_counter_ = 0;
}

const char* MessageBus::resultToString(IpcResult result) {
    switch (result) {
        case IpcResult::SUCCESS:               return "SUCCESS";
        case IpcResult::ENDPOINT_NOT_FOUND:    return "ENDPOINT_NOT_FOUND";
        case IpcResult::ENDPOINT_ALREADY_EXISTS: return "ENDPOINT_ALREADY_EXISTS";
        case IpcResult::INVALID_MESSAGE:       return "INVALID_MESSAGE";
        case IpcResult::NO_HANDLER:            return "NO_HANDLER";
        case IpcResult::HANDLER_FAILED:        return "HANDLER_FAILED";
        case IpcResult::PERMISSION_DENIED:     return "PERMISSION_DENIED";
        case IpcResult::TIMEOUT:               return "TIMEOUT";
        case IpcResult::QUEUE_FULL:            return "QUEUE_FULL";
        case IpcResult::INVALID_ENDPOINT_NAME: return "INVALID_ENDPOINT_NAME";
        default: return "UNKNOWN";
    }
}

const char* MessageBus::stateToString(EndpointState state) {
    switch (state) {
        case EndpointState::INACTIVE: return "INACTIVE";
        case EndpointState::ACTIVE:    return "ACTIVE";
        case EndpointState::BLOCKED:   return "BLOCKED";
        default: return "UNKNOWN";
    }
}

const char* MessageBus::priorityToString(MessagePriority priority) {
    switch (priority) {
        case MessagePriority::URGENT: return "URGENT";
        case MessagePriority::HIGH:    return "HIGH";
        case MessagePriority::NORMAL:  return "NORMAL";
        case MessagePriority::LOW:      return "LOW";
        default: return "UNKNOWN";
    }
}

const char* MessageBus::deliveryToString(DeliveryMode mode) {
    switch (mode) {
        case DeliveryMode::DIRECT:      return "DIRECT";
        case DeliveryMode::BROADCAST:   return "BROADCAST";
        case DeliveryMode::ROUND_ROBIN:  return "ROUND_ROBIN";
        default: return "UNKNOWN";
    }
}

MessageBus::Endpoint* MessageBus::findEndpoint(const std::string& endpointId) {
    auto it = endpoints_.find(endpointId);
    if (it == endpoints_.end()) return nullptr;
    return &it->second;
}

const MessageBus::Endpoint* MessageBus::findEndpoint(const std::string& endpointId) const {
    auto it = endpoints_.find(endpointId);
    if (it == endpoints_.end()) return nullptr;
    return &it->second;
}

std::string MessageBus::generateMessageId() {
    uint32_t seq = ++sequence_counter_;
    return "msg_" + std::to_string(seq);
}

bool MessageBus::deliverMessage(Endpoint& endpoint, const Message& msg) {
    if (!endpoint.handler) return false;
    endpoint.info.messages_received++;
    bool result = endpoint.handler(msg);
    return result;
}

void MessageBus::notifyDelivery(const std::string& messageId, IpcResult result) {
    if (delivery_callback_) {
        delivery_callback_(messageId, result);
    }
}

bool MessageBus::isTypeAllowedUnsafe(const std::string& endpointId, const std::string& messageType) const {
    const Endpoint* ep = findEndpoint(endpointId);
    if (!ep) return false;
    if (ep->info.allowed_types.empty()) return true;
    return std::find(ep->info.allowed_types.begin(),
                     ep->info.allowed_types.end(), messageType) != ep->info.allowed_types.end();
}

}  // namespace phantom::ipc
