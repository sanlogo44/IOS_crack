/*
 * Phantom OS - IPC Message Bus
 * In-process message bus for inter-process communication
 *
 * License: GPL-3.0
 */

#pragma once

#include "message.h"
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <vector>

namespace phantom::ipc {

// Message handler callback
using MessageHandler = std::function<bool(const Message& msg)>;

// Endpoint callback for state changes
using EndpointStateCallback = std::function<void(const std::string& endpointId,
                                                  EndpointState oldState, EndpointState newState)>;

// Message delivery callback
using DeliveryCallback = std::function<void(const std::string& messageId,
                                             IpcResult result)>;

// IPC Message Bus - singleton
class MessageBus {
public:
    static MessageBus& getInstance();

    // Endpoint management
    IpcResult registerEndpoint(const std::string& endpointId,
                               const std::string& ownerApp = "",
                               MessageHandler handler = nullptr);
    IpcResult unregisterEndpoint(const std::string& endpointId);
    IpcResult setEndpointHandler(const std::string& endpointId, MessageHandler handler);
    IpcResult setEndpointState(const std::string& endpointId, EndpointState state);

    // Allow message types for an endpoint
    IpcResult addAllowedType(const std::string& endpointId, const std::string& messageType);
    IpcResult removeAllowedType(const std::string& endpointId, const std::string& messageType);

    // Send messages
    std::string send(const std::string& source, const std::string& target,
                     const std::string& type, const std::string& payload = "",
                     const std::unordered_map<std::string, std::string>& params = {});
    std::string broadcast(const std::string& source,
                          const std::string& type, const std::string& payload = "",
                          const std::unordered_map<std::string, std::string>& params = {});
    std::string sendRoundRobin(const std::string& source, const std::string& type,
                               const std::string& payload = "",
                               const std::unordered_map<std::string, std::string>& params = {});

    // Reply to a message
    std::string reply(const std::string& source, const std::string& replyToId,
                      const std::string& payload = "",
                      const std::unordered_map<std::string, std::string>& params = {});

    // Query operations
    bool isEndpointRegistered(const std::string& endpointId) const;
    bool isEndpointActive(const std::string& endpointId) const;
    EndpointInfo getEndpointInfo(const std::string& endpointId) const;
    std::vector<std::string> getRegisteredEndpoints() const;
    std::vector<std::string> getActiveEndpoints() const;
    size_t getEndpointCount() const;
    size_t getActiveEndpointCount() const;

    // Message statistics
    uint64_t getTotalMessagesSent() const;
    uint64_t getTotalMessagesDelivered() const;
    uint64_t getTotalMessagesFailed() const;
    uint64_t getMessagesReceivedBy(const std::string& endpointId) const;
    uint64_t getMessagesSentBy(const std::string& endpointId) const;

    // Callbacks
    void setEndpointStateCallback(EndpointStateCallback callback);
    void setDeliveryCallback(DeliveryCallback callback);

    // Check if a message type is allowed for an endpoint
    bool isTypeAllowed(const std::string& endpointId, const std::string& messageType) const;

    // Clear all endpoints (for testing)
    void clear();

    // Utility
    static const char* resultToString(IpcResult result);
    static const char* stateToString(EndpointState state);
    static const char* priorityToString(MessagePriority priority);
    static const char* deliveryToString(DeliveryMode mode);

private:
    MessageBus() = default;
    ~MessageBus() = default;
    MessageBus(const MessageBus&) = delete;
    MessageBus& operator=(const MessageBus&) = delete;

    struct Endpoint {
        EndpointInfo info;
        MessageHandler handler;
        size_t round_robin_index = 0;
    };

    std::unordered_map<std::string, Endpoint> endpoints_;
    std::unordered_map<std::string, std::pair<std::string, std::string>> message_registry_;  // messageId -> (source, target)
    EndpointStateCallback state_callback_;
    DeliveryCallback delivery_callback_;
    std::atomic<uint64_t> total_sent_{0};
    std::atomic<uint64_t> total_delivered_{0};
    std::atomic<uint64_t> total_failed_{0};
    std::atomic<uint32_t> sequence_counter_{0};

    mutable std::mutex mutex_;

    Endpoint* findEndpoint(const std::string& endpointId);
    const Endpoint* findEndpoint(const std::string& endpointId) const;
    std::string generateMessageId();
    bool deliverMessage(Endpoint& endpoint, const Message& msg);
    void notifyDelivery(const std::string& messageId, IpcResult result);
    bool isTypeAllowedUnsafe(const std::string& endpointId, const std::string& messageType) const;
};

}  // namespace phantom::ipc
