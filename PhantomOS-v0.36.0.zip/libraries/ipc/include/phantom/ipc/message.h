/*
 * Phantom OS - IPC Message Types
 * Message structure for inter-process communication
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace phantom::ipc {

// Message priority levels
enum class MessagePriority : uint8_t {
    URGENT   = 0,   // Time-critical messages
    HIGH     = 1,   // Important messages
    NORMAL   = 2,   // Standard messages
    LOW      = 3,    // Low-priority messages
};

// Message delivery mode
enum class DeliveryMode : uint8_t {
    DIRECT     = 0,   // Send to a specific endpoint
    BROADCAST  = 1,   // Send to all endpoints
    ROUND_ROBIN = 2,   // Send to next available endpoint
};

// IPC message structure
struct Message {
    std::string id;                    // Unique message ID
    std::string source;                // Source endpoint ID
    std::string target;                // Target endpoint ID (empty for broadcast)
    std::string type;                  // Message type/category
    std::string payload;               // String payload
    std::unordered_map<std::string, std::string> params;  // Key-value parameters
    MessagePriority priority = MessagePriority::NORMAL;
    DeliveryMode delivery = DeliveryMode::DIRECT;
    uint64_t timestamp = 0;            // Creation timestamp (ms)
    uint32_t sequence = 0;            // Sequence number
    bool requires_reply = false;       // Whether a reply is expected
    std::string reply_to;              // ID of message this is a reply to
};

// IPC result codes
enum class IpcResult : int8_t {
    SUCCESS                = 0,
    ENDPOINT_NOT_FOUND     = -1,
    ENDPOINT_ALREADY_EXISTS = -2,
    INVALID_MESSAGE        = -3,
    NO_HANDLER             = -4,
    HANDLER_FAILED         = -5,
    PERMISSION_DENIED      = -6,
    TIMEOUT                = -7,
    QUEUE_FULL             = -8,
    INVALID_ENDPOINT_NAME  = -9,
};

// Endpoint state
enum class EndpointState : uint8_t {
    INACTIVE = 0,
    ACTIVE   = 1,
    BLOCKED  = 2,
};

// Endpoint info
struct EndpointInfo {
    std::string id;                    // Unique endpoint identifier
    std::string owner_app;             // Owning app ID
    std::vector<std::string> allowed_types;  // Allowed message types (empty = all)
    EndpointState state = EndpointState::INACTIVE;
    uint64_t messages_received = 0;
    uint64_t messages_sent = 0;
};

}  // namespace phantom::ipc
