/*
 * Phantom OS - Data Sanitizer
 * Removes metadata from files before sharing
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <vector>
#include <cstdint>

namespace phantom::privacy {

// Metadata fields that can be stripped
enum class MetadataField : uint8_t {
    GPS_COORDINATES = 0,
    DEVICE_MANUFACTURER = 1,
    DEVICE_MODEL = 2,
    CAMERA_SERIAL = 3,
    SOFTWARE_VERSION = 4,
    USER_NAME = 5,
    APPLICATION_NAME = 6,
    CREATION_TIMESTAMP = 7,
    MODIFICATION_DATE = 8,
    ALL = 0xFF,
};

// Sanitization result
struct SanitizationResult {
    bool success = false;
    size_t original_size = 0;
    size_t sanitized_size = 0;
    std::vector<MetadataField> removed_fields;
    std::string error_message;
};

// Location approximation
struct GeoLocation {
    double latitude;
    double longitude;
};

// Approximate a location to the given accuracy level
// 0=Precise, 1=Approximate(~100m), 2=City, 3=Region, 4=Country, 5=None
GeoLocation approximateLocation(double lat, double lng, int accuracy_level);

// Sanitize a file by removing metadata
// This is a prototype — in production, actual metadata parsing (EXIF, etc.) would be done
SanitizationResult sanitizeFile(const std::string& file_path,
                                const std::string& output_path,
                                std::vector<MetadataField> fields_to_remove);

// Sanitize a buffer (for in-memory data)
SanitizationResult sanitizeBuffer(const std::vector<uint8_t>& input,
                                   std::vector<uint8_t>& output,
                                   std::vector<MetadataField> fields_to_remove);

// Convert metadata field to string
const char* metadataFieldToString(MetadataField field);

}  // namespace phantom::privacy
