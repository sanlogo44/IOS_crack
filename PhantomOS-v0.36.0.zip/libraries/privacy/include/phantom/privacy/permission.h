/*
 * Phantom OS - Permission System
 * Granular, time-limited permission system with default-deny
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <chrono>
#include <memory>

namespace phantom::privacy {

// All permission types in Phantom OS
enum class Permission : uint16_t {
    CAMERA = 0,
    MICROPHONE = 1,
    LOCATION = 2,
    CONTACTS = 3,
    PHOTOS = 4,
    FILES = 5,
    BLUETOOTH = 6,
    NEARBY_DEVICES = 7,
    NOTIFICATIONS = 8,
    NETWORK = 9,
    SENSORS = 10,
    CLIPBOARD = 11,
    PHONE = 12,
    SMS = 13,
    STORAGE = 14,
    // Sentinel
    PERMISSION_COUNT = 15,
};

// Permission grant types
enum class GrantType : uint8_t {
    DENY = 0,
    ALLOW_ONCE = 1,
    ALLOW_10_MIN = 2,
    ALLOW_WHILE_USING = 3,
    ALLOW_ALWAYS = 4,
};

// Location accuracy levels (for Location permission)
enum class LocationAccuracy : uint8_t {
    PRECISE = 0,      // Full GPS accuracy
    APPROXIMATE = 1,  // ~100m radius
    CITY = 2,         // City-level
    REGION = 3,       // State/region level
    COUNTRY = 4,      // Country-level
    NONE = 5,         // No location data
};

// Convert permission to string
const char* permissionToString(Permission p);

// Convert grant type to string
const char* grantTypeToString(GrantType g);

// Convert location accuracy to string
const char* locationAccuracyToString(LocationAccuracy a);

// Get default location accuracy for a privacy profile level
// 0=Normal, 1=Privacy, 2=Maximum Privacy, 3=Developer
LocationAccuracy defaultLocationAccuracy(int profileLevel);

// Permission grant entry
struct PermissionGrant {
    GrantType type = GrantType::DENY;
    LocationAccuracy location_accuracy = LocationAccuracy::NONE;  // Only for LOCATION
    std::chrono::steady_clock::time_point granted_at;
    std::chrono::steady_clock::time_point expires_at;  // For time-limited grants
    bool is_active = false;

    // Check if grant is currently valid
    bool isValid() const;

    // Check if grant has expired
    bool isExpired() const;
};

// App permission state - all permissions for a single app
class AppPermissionState {
public:
    explicit AppPermissionState(const std::string& app_id);

    // Get app ID
    const std::string& getAppId() const { return app_id_; }

    // Get grant for a permission
    const PermissionGrant& getGrant(Permission perm) const;

    // Set grant for a permission
    void setGrant(Permission perm, GrantType type,
                  LocationAccuracy loc_accuracy = LocationAccuracy::NONE);

    // Check if permission is currently granted (valid and not expired)
    bool isGranted(Permission perm) const;

    // Check if permission is denied
    bool isDenied(Permission perm) const;

    // Check if a time-limited grant has expired
    bool isExpired(Permission perm) const;

    // Expire any time-limited grants that have timed out
    void expireTimedGrants();

    // Get grant duration in seconds (for time-limited grants)
    int64_t getGrantDurationSeconds(GrantType type) const;

    // Reset all permissions to DENY
    void resetAll();

private:
    std::string app_id_;
    std::unordered_map<uint16_t, PermissionGrant> grants_;
};

}  // namespace phantom::privacy
