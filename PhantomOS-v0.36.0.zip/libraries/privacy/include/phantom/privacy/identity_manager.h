/*
 * Phantom OS - Identity Manager
 * App-specific identifier system — no global device IDs exposed to apps
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <unordered_map>
#include <array>
#include <mutex>
#include <vector>
#include <cstdint>

namespace phantom::privacy {

// Generates and manages app-specific pseudonymous identifiers
// Each app gets a unique identifier that cannot be correlated across apps
class IdentityManager {
public:
    static IdentityManager& getInstance();

    // Get or create an app-specific identifier
    // Returns a stable, app-specific, per-installation ID
    std::string getAppIdentifier(const std::string& app_id);

    // Rotate the identifier for a specific app (e.g., on user request)
    std::string rotateAppIdentifier(const std::string& app_id);

    // Remove an app's identifier (on uninstall)
    void removeAppIdentifier(const std::string& app_id);

    // Check if an app has an identifier
    bool hasIdentifier(const std::string& app_id) const;

    // Get the list of apps with identifiers
    std::vector<std::string> getAppsWithIdentifiers() const;

    // Hardware identifiers — these are NEVER exposed to apps
    // They can only be accessed by system services with explicit authorization

    // Check if a hardware identifier request should be denied
    // Returns true if the request should be DENIED
    static bool shouldDenyHardwareId(const std::string& requested_id);

    // List of protected hardware identifiers
    static const std::vector<std::string> protectedHardwareIds();

private:
    IdentityManager();
    ~IdentityManager() = default;
    IdentityManager(const IdentityManager&) = delete;
    IdentityManager& operator=(const IdentityManager&) = delete;

    mutable std::mutex mutex_;
    std::unordered_map<std::string, std::string> app_identifiers_;

    // Generate a random identifier
    std::string generateIdentifier() const;
};

}  // namespace phantom::privacy
