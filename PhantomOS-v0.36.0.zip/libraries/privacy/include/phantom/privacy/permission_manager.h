/*
 * Phantom OS - Permission Manager
 * Central manager for all app permissions
 *
 * License: GPL-3.0
 */

#pragma once

#include "permission.h"
#include <unordered_map>
#include <string>
#include <vector>
#include <functional>
#include <mutex>

namespace phantom::privacy {

// Privacy profile levels
enum class PrivacyProfile : uint8_t {
    NORMAL = 0,
    PRIVACY = 1,
    MAXIMUM_PRIVACY = 2,
    DEVELOPER = 3,
    CUSTOM = 4,
};

// Access log entry
struct AccessLogEntry {
    std::string app_id;
    Permission permission;
    int64_t timestamp;      // Unix timestamp
    int64_t duration_ms;    // Duration of access
    std::string reason;      // Why access was requested
};

// Permission check result
enum class PermissionCheckResult : uint8_t {
    GRANTED = 0,
    DENIED = 1,
    DENIED_BY_PROFILE = 2,    // Denied by privacy profile
    EXPIRED = 3,               // Time-limited grant expired
    NOT_REQUESTED = 4,        // App never requested this permission
};

// Permission Manager - central authority for all permission decisions
class PermissionManager {
public:
    // Singleton
    static PermissionManager& getInstance();

    // Register a new app
    void registerApp(const std::string& app_id);

    // Unregister an app (revokes all permissions)
    void unregisterApp(const std::string& app_id);

    // Request a permission for an app
    // Returns true if the permission should be granted (user must still be prompted)
    bool requestPermission(const std::string& app_id, Permission perm,
                            GrantType requested_type = GrantType::ALLOW_WHILE_USING,
                            LocationAccuracy loc_accuracy = LocationAccuracy::PRECISE);

    // Check if a permission is currently granted
    PermissionCheckResult checkPermission(const std::string& app_id, Permission perm) const;

    // Grant a permission (called after user approval)
    void grantPermission(const std::string& app_id, Permission perm, GrantType type,
                          LocationAccuracy loc_accuracy = LocationAccuracy::PRECISE);

    // Revoke a permission
    void revokePermission(const std::string& app_id, Permission perm);

    // Revoke all permissions for an app
    void revokeAllPermissions(const std::string& app_id);

    // Set privacy profile (affects default behaviors)
    void setPrivacyProfile(PrivacyProfile profile);
    PrivacyProfile getPrivacyProfile() const { return profile_; }

    // Expire any time-limited grants across all apps
    void expireAllTimedGrants();

    // Log access to a permission
    void logAccess(const std::string& app_id, Permission perm,
                   int64_t duration_ms, const std::string& reason);

    // Get access log
    std::vector<AccessLogEntry> getAccessLog() const;
    std::vector<AccessLogEntry> getAccessLogForApp(const std::string& app_id) const;
    std::vector<AccessLogEntry> getAccessLogForPermission(Permission perm) const;

    // Get all permissions for an app (for Privacy Center display)
    struct AppPermissionInfo {
        Permission permission;
        GrantType grant_type;
        bool is_active;
        LocationAccuracy location_accuracy;
        bool is_expired;
    };
    std::vector<AppPermissionInfo> getAppPermissions(const std::string& app_id) const;

    // Get all registered app IDs
    std::vector<std::string> getRegisteredApps() const;

    // Get the effective location accuracy for an app (considering profile)
    LocationAccuracy getEffectiveLocationAccuracy(const std::string& app_id) const;

private:
    PermissionManager() = default;
    ~PermissionManager() = default;
    PermissionManager(const PermissionManager&) = delete;
    PermissionManager& operator=(const PermissionManager&) = delete;

    mutable std::mutex mutex_;
    std::unordered_map<std::string, AppPermissionState> apps_;
    PrivacyProfile profile_ = PrivacyProfile::NORMAL;
    std::vector<AccessLogEntry> access_log_;

    // Check if a permission is blocked by the privacy profile
    bool isBlockedByProfile(Permission perm) const;
};

}  // namespace phantom::privacy
