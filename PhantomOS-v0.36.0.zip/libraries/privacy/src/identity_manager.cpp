/*
 * Phantom OS - Identity Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/identity_manager.h"
#include <random>
#include <sstream>
#include <iomanip>
#include <vector>
#include <chrono>

namespace phantom::privacy {

IdentityManager& IdentityManager::getInstance() {
    static IdentityManager instance;
    return instance;
}

IdentityManager::IdentityManager() {
    // Seed the random generator
    std::random_device rd;
    // Nothing else needed — generateIdentifier uses rd each time
}

std::string IdentityManager::generateIdentifier() const {
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dist;

    uint64_t part1 = dist(gen);
    uint64_t part2 = dist(gen);

    std::stringstream ss;
    ss << std::hex << std::setfill('0')
       << std::setw(16) << part1 << "-"
       << std::setw(16) << part2;
    return ss.str();
}

std::string IdentityManager::getAppIdentifier(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = app_identifiers_.find(app_id);
    if (it != app_identifiers_.end()) {
        return it->second;
    }
    // Generate new identifier
    std::string new_id = generateIdentifier();
    app_identifiers_[app_id] = new_id;
    return new_id;
}

std::string IdentityManager::rotateAppIdentifier(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::string new_id = generateIdentifier();
    app_identifiers_[app_id] = new_id;
    return new_id;
}

void IdentityManager::removeAppIdentifier(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    app_identifiers_.erase(app_id);
}

bool IdentityManager::hasIdentifier(const std::string& app_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return app_identifiers_.find(app_id) != app_identifiers_.end();
}

std::vector<std::string> IdentityManager::getAppsWithIdentifiers() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, _] : app_identifiers_) {
        result.push_back(id);
    }
    return result;
}

const std::vector<std::string>& protectedHardwareIdsList() {
    static const std::vector<std::string> ids = {
        "IMEI",
        "IMSI",
        "SERIAL_NUMBER",
        "WIFI_MAC",
        "BLUETOOTH_MAC",
        "ANDROID_ID",
        "ADVERTISING_ID",
        "SIM_INFO",
        "DEVICE_FINGERPRINT",
    };
    return ids;
}

bool IdentityManager::shouldDenyHardwareId(const std::string& requested_id) {
    // All hardware identifiers should be denied by default
    const auto& protected_ids = protectedHardwareIdsList();
    for (const auto& id : protected_ids) {
        // Case-insensitive comparison
        if (requested_id.size() == id.size()) {
            bool match = true;
            for (size_t i = 0; i < id.size(); ++i) {
                if (toupper(requested_id[i]) != id[i]) {
                    match = false;
                    break;
                }
            }
            if (match) return true;
        }
    }
    return false;
}

const std::vector<std::string> IdentityManager::protectedHardwareIds() {
    return protectedHardwareIdsList();
}

}  // namespace phantom::privacy
