/*
 * Phantom OS - Permission Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/permission_manager.h"
#include <chrono>
#include <algorithm>

namespace phantom::privacy {

PermissionManager& PermissionManager::getInstance() {
    static PermissionManager instance;
    return instance;
}

void PermissionManager::registerApp(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (apps_.find(app_id) == apps_.end()) {
        apps_.emplace(app_id, AppPermissionState(app_id));
    }
}

void PermissionManager::unregisterApp(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    apps_.erase(app_id);
}

bool PermissionManager::requestPermission(const std::string& app_id, Permission perm,
                                           GrantType requested_type,
                                           LocationAccuracy loc_accuracy) {
    std::lock_guard<std::mutex> lock(mutex_);

    // Ensure app is registered
    if (apps_.find(app_id) == apps_.end()) {
        apps_.emplace(app_id, AppPermissionState(app_id));
    }

    // Check if blocked by profile
    if (isBlockedByProfile(perm)) {
        return false;
    }

    // In Maximum Privacy mode, some permissions are always denied
    if (profile_ == PrivacyProfile::MAXIMUM_PRIVACY) {
        if (perm == Permission::LOCATION) {
            // Only allow city-level or worse
            if (loc_accuracy < LocationAccuracy::CITY) {
                loc_accuracy = LocationAccuracy::CITY;
            }
        }
    }

    // The actual grant happens in grantPermission() after user approval
    return true;
}

PermissionCheckResult PermissionManager::checkPermission(const std::string& app_id,
                                                          Permission perm) const {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = apps_.find(app_id);
    if (it == apps_.end()) {
        return PermissionCheckResult::NOT_REQUESTED;
    }

    // Check if blocked by profile
    if (isBlockedByProfile(perm)) {
        return PermissionCheckResult::DENIED_BY_PROFILE;
    }

    const auto& grant = it->second.getGrant(perm);

    if (grant.type == GrantType::DENY) {
        return PermissionCheckResult::DENIED;
    }

    if (grant.isExpired()) {
        return PermissionCheckResult::EXPIRED;
    }

    if (!grant.is_active) {
        return PermissionCheckResult::DENIED;
    }

    return PermissionCheckResult::GRANTED;
}

void PermissionManager::grantPermission(const std::string& app_id, Permission perm,
                                         GrantType type, LocationAccuracy loc_accuracy) {
    std::lock_guard<std::mutex> lock(mutex_);

    // Ensure app is registered
    if (apps_.find(app_id) == apps_.end()) {
        apps_.emplace(app_id, AppPermissionState(app_id));
    }

    // Apply profile restrictions
    if (profile_ == PrivacyProfile::MAXIMUM_PRIVACY && perm == Permission::LOCATION) {
        if (loc_accuracy < LocationAccuracy::CITY) {
            loc_accuracy = LocationAccuracy::CITY;
        }
    }
    if (profile_ == PrivacyProfile::PRIVACY && perm == Permission::LOCATION) {
        if (loc_accuracy < LocationAccuracy::APPROXIMATE) {
            loc_accuracy = LocationAccuracy::APPROXIMATE;
        }
    }

    apps_.at(app_id).setGrant(perm, type, loc_accuracy);
}

void PermissionManager::revokePermission(const std::string& app_id, Permission perm) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = apps_.find(app_id);
    if (it != apps_.end()) {
        it->second.setGrant(perm, GrantType::DENY);
    }
}

void PermissionManager::revokeAllPermissions(const std::string& app_id) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = apps_.find(app_id);
    if (it != apps_.end()) {
        it->second.resetAll();
    }
}

void PermissionManager::setPrivacyProfile(PrivacyProfile profile) {
    std::lock_guard<std::mutex> lock(mutex_);
    profile_ = profile;

    // Apply profile restrictions to existing grants
    for (auto& [id, state] : apps_) {
        if (profile == PrivacyProfile::MAXIMUM_PRIVACY) {
            // Downgrade location to city-level
            if (state.isGranted(Permission::LOCATION)) {
                auto& grant = const_cast<PermissionGrant&>(state.getGrant(Permission::LOCATION));
                if (grant.location_accuracy < LocationAccuracy::CITY) {
                    grant.location_accuracy = LocationAccuracy::CITY;
                }
            }
        } else if (profile == PrivacyProfile::PRIVACY) {
            // Downgrade location to approximate
            if (state.isGranted(Permission::LOCATION)) {
                auto& grant = const_cast<PermissionGrant&>(state.getGrant(Permission::LOCATION));
                if (grant.location_accuracy < LocationAccuracy::APPROXIMATE) {
                    grant.location_accuracy = LocationAccuracy::APPROXIMATE;
                }
            }
        }
    }
}

void PermissionManager::expireAllTimedGrants() {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [id, state] : apps_) {
        state.expireTimedGrants();
    }
}

void PermissionManager::logAccess(const std::string& app_id, Permission perm,
                                   int64_t duration_ms, const std::string& reason) {
    std::lock_guard<std::mutex> lock(mutex_);
    AccessLogEntry entry;
    entry.app_id = app_id;
    entry.permission = perm;
    entry.timestamp = std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    entry.duration_ms = duration_ms;
    entry.reason = reason;
    access_log_.push_back(entry);

    // Keep only last 10000 entries
    if (access_log_.size() > 10000) {
        access_log_.erase(access_log_.begin());
    }
}

std::vector<AccessLogEntry> PermissionManager::getAccessLog() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return access_log_;
}

std::vector<AccessLogEntry> PermissionManager::getAccessLogForApp(const std::string& app_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<AccessLogEntry> result;
    for (const auto& entry : access_log_) {
        if (entry.app_id == app_id) {
            result.push_back(entry);
        }
    }
    return result;
}

std::vector<AccessLogEntry> PermissionManager::getAccessLogForPermission(Permission perm) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<AccessLogEntry> result;
    for (const auto& entry : access_log_) {
        if (entry.permission == perm) {
            result.push_back(entry);
        }
    }
    return result;
}

std::vector<PermissionManager::AppPermissionInfo> PermissionManager::getAppPermissions(
        const std::string& app_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<AppPermissionInfo> result;
    auto it = apps_.find(app_id);
    if (it == apps_.end()) return result;

    for (int i = 0; i < static_cast<int>(Permission::PERMISSION_COUNT); ++i) {
        Permission p = static_cast<Permission>(i);
        const auto& grant = it->second.getGrant(p);
        AppPermissionInfo info;
        info.permission = p;
        info.grant_type = grant.type;
        info.is_active = grant.is_active;
        info.location_accuracy = grant.location_accuracy;
        info.is_expired = grant.isExpired();
        result.push_back(info);
    }
    return result;
}

std::vector<std::string> PermissionManager::getRegisteredApps() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, state] : apps_) {
        result.push_back(id);
    }
    return result;
}

LocationAccuracy PermissionManager::getEffectiveLocationAccuracy(const std::string& app_id) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = apps_.find(app_id);
    if (it == apps_.end()) return LocationAccuracy::NONE;

    const auto& grant = it->second.getGrant(Permission::LOCATION);
    if (!grant.isValid()) return LocationAccuracy::NONE;

    LocationAccuracy accuracy = grant.location_accuracy;

    // Apply profile restrictions
    if (profile_ == PrivacyProfile::MAXIMUM_PRIVACY) {
        if (accuracy < LocationAccuracy::CITY) {
            accuracy = LocationAccuracy::CITY;
        }
    } else if (profile_ == PrivacyProfile::PRIVACY) {
        if (accuracy < LocationAccuracy::APPROXIMATE) {
            accuracy = LocationAccuracy::APPROXIMATE;
        }
    }

    return accuracy;
}

bool PermissionManager::isBlockedByProfile(Permission /*perm*/) const {
    // Currently no permissions are completely blocked by profile
    // (profile restricts but doesn't block)
    return false;
}

}  // namespace phantom::privacy
