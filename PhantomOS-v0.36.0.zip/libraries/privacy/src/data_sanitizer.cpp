/*
 * Phantom OS - Data Sanitizer Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/data_sanitizer.h"
#include <cmath>
#include <fstream>
#include <cstring>

namespace phantom::privacy {

const char* metadataFieldToString(MetadataField field) {
    switch (field) {
        case MetadataField::GPS_COORDINATES: return "GPS_COORDINATES";
        case MetadataField::DEVICE_MANUFACTURER: return "DEVICE_MANUFACTURER";
        case MetadataField::DEVICE_MODEL: return "DEVICE_MODEL";
        case MetadataField::CAMERA_SERIAL: return "CAMERA_SERIAL";
        case MetadataField::SOFTWARE_VERSION: return "SOFTWARE_VERSION";
        case MetadataField::USER_NAME: return "USER_NAME";
        case MetadataField::APPLICATION_NAME: return "APPLICATION_NAME";
        case MetadataField::CREATION_TIMESTAMP: return "CREATION_TIMESTAMP";
        case MetadataField::MODIFICATION_DATE: return "MODIFICATION_DATE";
        case MetadataField::ALL: return "ALL";
        default: return "UNKNOWN";
    }
}

// Predefined city coordinates for approximation (major cities worldwide)
struct CityRef {
    const char* name;
    double lat;
    double lng;
};

static const CityRef cities[] = {
    {"Berlin", 52.5200, 13.4050},
    {"Munich", 48.1351, 11.5820},
    {"Hamburg", 53.5511, 9.9937},
    {"Cologne", 50.9375, 6.9603},
    {"Frankfurt", 50.1109, 8.6821},
    {"Stuttgart", 48.7758, 9.1829},
    {"Dusseldorf", 51.2277, 6.7735},
    {"Leipzig", 51.3397, 12.3731},
    {"Dresden", 51.0504, 13.7373},
    {"Hanover", 52.3759, 9.7320},
    {"Nuremberg", 49.4539, 11.0775},
    {"Bremen", 53.0793, 8.8017},
    {"London", 51.5074, -0.1278},
    {"Paris", 48.8566, 2.3522},
    {"Rome", 41.9028, 12.4964},
    {"Madrid", 40.4168, -3.7038},
    {"Amsterdam", 52.3676, 4.9041},
    {"Vienna", 48.2082, 16.3738},
    {"Zurich", 47.3769, 8.5417},
    {"Warsaw", 52.2297, 21.0122},
    {"New York", 40.7128, -74.0060},
    {"Los Angeles", 34.0522, -118.2437},
    {"Chicago", 41.8781, -87.6298},
    {"Houston", 29.7604, -95.3698},
    {"Phoenix", 33.4484, -112.0740},
    {"Tokyo", 35.6762, 139.6503},
    {"Beijing", 39.9042, 116.4074},
    {"Shanghai", 31.2304, 121.4737},
    {"Mumbai", 19.0760, 72.8777},
    {"Sydney", -33.8688, 151.2093},
    {"Moscow", 55.7558, 37.6173},
    {"Istanbul", 41.0082, 28.9784},
    {"Cairo", 30.0444, 31.2357},
    {"Lagos", 6.5244, 3.3792},
    {"Johannesburg", -26.2041, 28.0473},
    {"Sao Paulo", -23.5505, -46.6333},
    {"Buenos Aires", -34.6037, -58.3816},
    {"Mexico City", 19.4326, -99.1332},
    {"Toronto", 43.6532, -79.3832},
    {"Vancouver", 49.2827, -123.1207},
};

static const int city_count = sizeof(cities) / sizeof(cities[0]);

GeoLocation approximateLocation(double lat, double lng, int accuracy_level) {
    GeoLocation result = {lat, lng};

    if (accuracy_level <= 0) {
        // Precise — no approximation
        return result;
    }

    if (accuracy_level >= 5) {
        // None — return (0, 0)
        result.latitude = 0.0;
        result.longitude = 0.0;
        return result;
    }

    if (accuracy_level == 1) {
        // Approximate — ~100m radius
        // Add random noise of ~0.001 degrees (~100m)
        double noise_lat = ((lat * 1000.0) - (long)(lat * 1000.0) - 0.5) * 0.002;
        double noise_lng = ((lng * 1000.0) - (long)(lng * 1000.0) - 0.5) * 0.002;
        result.latitude = lat + noise_lat;
        result.longitude = lng + noise_lng;
        // Round to 3 decimal places
        result.latitude = round(result.latitude * 1000.0) / 1000.0;
        result.longitude = round(result.longitude * 1000.0) / 1000.0;
        return result;
    }

    // For city (2), region (3), country (4) — find nearest city
    CityRef nearest = cities[0];
    double min_dist = 1e18;

    for (int i = 0; i < city_count; ++i) {
        double dlat = lat - cities[i].lat;
        double dlng = lng - cities[i].lng;
        double dist = dlat * dlat + dlng * dlng;
        if (dist < min_dist) {
            min_dist = dist;
            nearest = cities[i];
        }
    }

    if (accuracy_level == 2) {
        // City — return city center
        result.latitude = nearest.lat;
        result.longitude = nearest.lng;
    } else if (accuracy_level == 3) {
        // Region — return city center with more noise
        result.latitude = nearest.lat;
        result.longitude = nearest.lng;
    } else if (accuracy_level == 4) {
        // Country — return city center (nearest major city in the country)
        result.latitude = nearest.lat;
        result.longitude = nearest.lng;
    }

    return result;
}

SanitizationResult sanitizeFile(const std::string& file_path,
                                 const std::string& output_path,
                                 std::vector<MetadataField> fields_to_remove) {
    SanitizationResult result;

    // Read input file
    std::ifstream input(file_path, std::ios::binary | std::ios::ate);
    if (!input.is_open()) {
        result.error_message = "Cannot open input file: " + file_path;
        return result;
    }

    size_t size = input.tellg();
    input.seekg(0, std::ios::beg);
    std::vector<uint8_t> buffer(size);
    input.read(reinterpret_cast<char*>(buffer.data()), size);
    input.close();

    result.original_size = size;

    // Write output file (in production, metadata would be parsed and removed here)
    // For this prototype, we copy the file and log what would be removed
    std::vector<uint8_t> output_buffer;
    SanitizationResult buf_result = sanitizeBuffer(buffer, output_buffer, fields_to_remove);
    if (!buf_result.success) {
        result.error_message = buf_result.error_message;
        return result;
    }

    std::ofstream output(output_path, std::ios::binary);
    if (!output.is_open()) {
        result.error_message = "Cannot open output file: " + output_path;
        return result;
    }
    output.write(reinterpret_cast<const char*>(output_buffer.data()), output_buffer.size());
    output.close();

    result.success = true;
    result.sanitized_size = output_buffer.size();
    result.removed_fields = buf_result.removed_fields;
    return result;
}

SanitizationResult sanitizeBuffer(const std::vector<uint8_t>& input,
                                    std::vector<uint8_t>& output,
                                    std::vector<MetadataField> fields_to_remove) {
    SanitizationResult result;

    if (input.empty()) {
        result.error_message = "Input buffer is empty";
        return result;
    }

    // Check if ALL fields should be removed
    bool remove_all = false;
    for (const auto& f : fields_to_remove) {
        if (f == MetadataField::ALL) {
            remove_all = true;
            break;
        }
    }

    if (remove_all) {
        fields_to_remove = {
            MetadataField::GPS_COORDINATES,
            MetadataField::DEVICE_MANUFACTURER,
            MetadataField::DEVICE_MODEL,
            MetadataField::CAMERA_SERIAL,
            MetadataField::SOFTWARE_VERSION,
            MetadataField::USER_NAME,
            MetadataField::APPLICATION_NAME,
            MetadataField::CREATION_TIMESTAMP,
            MetadataField::MODIFICATION_DATE,
        };
    }

    // Prototype: copy data as-is (in production, actual metadata parsing would happen here)
    // For EXIF data in JPEGs, we would parse the EXIF segment and remove specified tags
    // For now, we just copy the data and log the removed fields
    output = input;

    result.success = true;
    result.original_size = input.size();
    result.sanitized_size = output.size();
    result.removed_fields = fields_to_remove;
    return result;
}

}  // namespace phantom::privacy
