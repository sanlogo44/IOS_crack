/*
 * Phantom OS - Permission System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/permission.h"
#include <algorithm>

namespace phantom::privacy {

const char* permissionToString(Permission p) {
    switch (p) {
        case Permission::CAMERA: return "CAMERA";
        case Permission::MICROPHONE: return "MICROPHONE";
        case Permission::LOCATION: return "LOCATION";
        case Permission::CONTACTS: return "CONTACTS";
        case Permission::PHOTOS: return "PHOTOS";
        case Permission::FILES: return "FILES";
        case Permission::BLUETOOTH: return "BLUETOOTH";
        case Permission::NEARBY_DEVICES: return "NEARBY_DEVICES";
        case Permission::NOTIFICATIONS: return "NOTIFICATIONS";
        case Permission::NETWORK: return "NETWORK";
        case Permission::SENSORS: return "SENSORS";
        case Permission::CLIPBOARD: return "CLIPBOARD";
        case Permission::PHONE: return "PHONE";
        case Permission::SMS: return "SMS";
        case Permission::STORAGE: return "STORAGE";
        case Permission::PERMISSION_COUNT: return "PERMISSION_COUNT";
        default: return "UNKNOWN";
    }
}

const char* grantTypeToString(GrantType g) {
    switch (g) {
        case GrantType::DENY: return "DENY";
        case GrantType::ALLOW_ONCE: return "ALLOW_ONCE";
        case GrantType::ALLOW_10_MIN: return "ALLOW_10_MIN";
        case GrantType::ALLOW_WHILE_USING: return "ALLOW_WHILE_USING";
        case GrantType::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        default: return "UNKNOWN";
    }
}

const char* locationAccuracyToString(LocationAccuracy a) {
    switch (a) {
        case LocationAccuracy::PRECISE: return "PRECISE";
        case LocationAccuracy::APPROXIMATE: return "APPROXIMATE";
        case LocationAccuracy::CITY: return "CITY";
        case LocationAccuracy::REGION: return "REGION";
        case LocationAccuracy::COUNTRY: return "COUNTRY";
        case LocationAccuracy::NONE: return "NONE";
        default: return "UNKNOWN";
    }
}

LocationAccuracy defaultLocationAccuracy(int profileLevel) {
    switch (profileLevel) {
        case 0: return LocationAccuracy::PRECISE;       // Normal
        case 1: return LocationAccuracy::APPROXIMATE;    // Privacy
        case 2: return LocationAccuracy::CITY;           // Maximum Privacy
        case 3: return LocationAccuracy::PRECISE;       // Developer
        default: return LocationAccuracy::NONE;
    }
}

bool PermissionGrant::isValid() const {
    if (type == GrantType::DENY) return false;
    if (!is_active) return false;
    if (isExpired()) return false;
    return true;
}

bool PermissionGrant::isExpired() const {
    if (type == GrantType::ALLOW_ALWAYS || type == GrantType::ALLOW_WHILE_USING) {
        return false;  // No time limit
    }
    if (type == GrantType::DENY) {
        return false;  // Not applicable
    }
    // ALLOW_ONCE and ALLOW_10_MIN have time limits
    auto now = std::chrono::steady_clock::now();
    return now > expires_at;
}

// AppPermissionState implementation

AppPermissionState::AppPermissionState(const std::string& app_id)
    : app_id_(app_id) {
    // All permissions default to DENY
    for (int i = 0; i < static_cast<int>(Permission::PERMISSION_COUNT); ++i) {
        PermissionGrant grant;
        grant.type = GrantType::DENY;
        grant.is_active = false;
        grants_[static_cast<uint16_t>(i)] = grant;
    }
}

const PermissionGrant& AppPermissionState::getGrant(Permission perm) const {
    auto it = grants_.find(static_cast<uint16_t>(perm));
    if (it != grants_.end()) {
        return it->second;
    }
    // Return a default denied grant
    static PermissionGrant default_grant;
    return default_grant;
}

void AppPermissionState::setGrant(Permission perm, GrantType type,
                                   LocationAccuracy loc_accuracy) {
    PermissionGrant grant;
    grant.type = type;
    grant.granted_at = std::chrono::steady_clock::now();
    grant.is_active = (type != GrantType::DENY);

    // Set expiration for time-limited grants
    auto duration = std::chrono::seconds(getGrantDurationSeconds(type));
    grant.expires_at = grant.granted_at + duration;

    // Set location accuracy for LOCATION permission
    if (perm == Permission::LOCATION) {
        grant.location_accuracy = loc_accuracy;
    }

    grants_[static_cast<uint16_t>(perm)] = grant;
}

bool AppPermissionState::isGranted(Permission perm) const {
    const auto& grant = getGrant(perm);
    return grant.isValid();
}

bool AppPermissionState::isDenied(Permission perm) const {
    const auto& grant = getGrant(perm);
    return grant.type == GrantType::DENY || !grant.isValid();
}

bool AppPermissionState::isExpired(Permission perm) const {
    const auto& grant = getGrant(perm);
    return grant.isExpired();
}

void AppPermissionState::expireTimedGrants() {
    auto now = std::chrono::steady_clock::now();
    for (auto& [key, grant] : grants_) {
        if (grant.type != GrantType::ALLOW_ALWAYS &&
            grant.type != GrantType::ALLOW_WHILE_USING &&
            grant.type != GrantType::DENY) {
            if (now > grant.expires_at) {
                grant.is_active = false;
            }
        }
    }
}

int64_t AppPermissionState::getGrantDurationSeconds(GrantType type) const {
    switch (type) {
        case GrantType::DENY: return 0;
        case GrantType::ALLOW_ONCE: return 60;       // 1 minute (single use)
        case GrantType::ALLOW_10_MIN: return 600;     // 10 minutes
        case GrantType::ALLOW_WHILE_USING: return 0;  // No limit (foreground only)
        case GrantType::ALLOW_ALWAYS: return 0;       // No limit
        default: return 0;
    }
}

void AppPermissionState::resetAll() {
    for (auto& [key, grant] : grants_) {
        grant.type = GrantType::DENY;
        grant.is_active = false;
        grant.location_accuracy = LocationAccuracy::NONE;
    }
}

}  // namespace phantom::privacy
