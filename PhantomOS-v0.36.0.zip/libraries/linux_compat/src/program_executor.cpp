/*
 * Phantom OS - Program Executor Implementation
 * Simulated Linux program execution for Kali, Arch, CSI-Linux compatibility
 *
 * License: GPL-3.0
 */

#include "phantom/linux_compat/program_executor.h"
#include "phantom/package_manager/package_manager.h"
#include "phantom/package_manager/package.h"
#include "phantom/app_lifecycle.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <sstream>

namespace phantom::linux_compat {

// ============================================================
// Singleton
// ============================================================

ProgramExecutor& ProgramExecutor::getInstance() {
    static ProgramExecutor instance;
    return instance;
}

// ============================================================
// Private helpers
// ============================================================

RegisteredProgram* ProgramExecutor::findProgram(const std::string& programId) {
    auto it = programs_.find(programId);
    if (it == programs_.end()) return nullptr;
    return &it->second;
}

const RegisteredProgram* ProgramExecutor::findProgram(const std::string& programId) const {
    auto it = programs_.find(programId);
    if (it == programs_.end()) return nullptr;
    return &it->second;
}

ProcessInfo* ProgramExecutor::findProcess(uint32_t pid) {
    auto it = processes_.find(pid);
    if (it == processes_.end()) return nullptr;
    return &it->second;
}

const ProcessInfo* ProgramExecutor::findProcess(uint32_t pid) const {
    auto it = processes_.find(pid);
    if (it == processes_.end()) return nullptr;
    return &it->second;
}

uint32_t ProgramExecutor::allocatePid() {
    return next_pid_++;
}

void ProgramExecutor::setProcessState(ProcessInfo& proc, ProgramState newState) {
    ProgramState oldState = proc.state;
    proc.state = newState;
    if (state_callback_) {
        state_callback_(proc.pid, proc.program_id, oldState, newState);
    }
}

ProcessInfo ProgramExecutor::createProcess(const std::string& programId,
                                             const ExecutionOptions& options) {
    ProcessInfo proc;
    proc.pid = allocatePid();
    proc.program_id = programId;
    proc.state = ProgramState::REGISTERED;
    proc.args = options.args;
    proc.env = options.env;
    proc.working_dir = options.working_dir;
    proc.timeout_ms = options.timeout_ms;
    proc.exit_code = -1;

    auto now = std::chrono::steady_clock::now().time_since_epoch();
    proc.start_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();

    return proc;
}

std::string ProgramExecutor::buildStdout(const LinuxProgramInfo& info,
                                            const ExecutionOptions& options) const {
    std::ostringstream oss;
    oss << "Executing: " << info.executable_path;
    if (!options.args.empty()) {
        oss << " " << info.name;
        for (const auto& arg : options.args) {
            oss << " " << arg;
        }
    }
    if (!options.working_dir.empty()) {
        oss << "\nWorking directory: " << options.working_dir;
    }
    oss << "\n[" << distroToString(info.distro) << "/"
        << archToString(info.arch) << "] "
        << info.name << " v" << info.version;
    return oss.str();
}

// ============================================================
// Program registration
// ============================================================

ProgramExecutorResult ProgramExecutor::registerProgram(const LinuxProgramInfo& info) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (info.program_id.empty()) {
        return ProgramExecutorResult::INVALID_PROGRAM;
    }
    if (info.executable_path.empty()) {
        return ProgramExecutorResult::INVALID_PATH;
    }
    if (info.name.empty()) {
        return ProgramExecutorResult::INVALID_PROGRAM;
    }
    if (!isSupportedDistro(info.distro)) {
        return ProgramExecutorResult::UNSUPPORTED_DISTRO;
    }
    if (!isSupportedArch(info.arch)) {
        return ProgramExecutorResult::UNSUPPORTED_ARCH;
    }

    if (programs_.find(info.program_id) != programs_.end()) {
        return ProgramExecutorResult::ALREADY_REGISTERED;
    }

    RegisteredProgram entry;
    entry.info = info;
    programs_[info.program_id] = entry;

    return ProgramExecutorResult::SUCCESS;
}

ProgramExecutorResult ProgramExecutor::unregisterProgram(const std::string& programId,
                                                           bool force) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto* prog = findProgram(programId);
    if (!prog) {
        return ProgramExecutorResult::NOT_REGISTERED;
    }

    if (!prog->running_pids.empty() && !force) {
        return ProgramExecutorResult::ALREADY_RUNNING;
    }

    // Terminate any running processes if force
    if (!prog->running_pids.empty() && force) {
        for (uint32_t pid : prog->running_pids) {
            auto* proc = findProcess(pid);
            if (proc) {
                setProcessState(*proc, ProgramState::TERMINATED);
                auto now = std::chrono::steady_clock::now().time_since_epoch();
                proc->end_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
                proc->exit_code = 1;
            }
        }
        prog->running_pids.clear();
    }

    programs_.erase(programId);
    return ProgramExecutorResult::SUCCESS;
}

bool ProgramExecutor::isProgramRegistered(const std::string& programId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return programs_.find(programId) != programs_.end();
}

LinuxProgramInfo ProgramExecutor::getProgramInfo(const std::string& programId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto* prog = findProgram(programId);
    if (!prog) return LinuxProgramInfo();
    return prog->info;
}

std::vector<std::string> ProgramExecutor::getRegisteredPrograms() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, _] : programs_) {
        result.push_back(id);
    }
    return result;
}

std::vector<std::string> ProgramExecutor::getProgramsByDistro(LinuxDistro distro) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, prog] : programs_) {
        if (prog.info.distro == distro) {
            result.push_back(id);
        }
    }
    return result;
}

size_t ProgramExecutor::getRegisteredCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return programs_.size();
}

// ============================================================
// Program execution
// ============================================================

ProgramExecutorResult ProgramExecutor::executeProgram(
    const std::string& programId,
    const ExecutionOptions& options,
    ProcessInfo* outProcess
) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto* prog = findProgram(programId);
    if (!prog) {
        return ProgramExecutorResult::NOT_REGISTERED;
    }

    // Check if already running and multiple instances not allowed
    if (!prog->running_pids.empty() && !options.allow_multiple_instances) {
        return ProgramExecutorResult::ALREADY_RUNNING;
    }

    // Create simulated process
    ProcessInfo proc = createProcess(programId, options);
    processes_[proc.pid] = proc;

    // Transition to STARTING
    setProcessState(processes_[proc.pid], ProgramState::STARTING);

    // Simulate execution - transition to RUNNING then EXITED
    setProcessState(processes_[proc.pid], ProgramState::RUNNING);

    // Capture output
    if (options.capture_stdout) {
        processes_[proc.pid].stdout_output = buildStdout(prog->info, options);
    }
    if (options.capture_stderr) {
        processes_[proc.pid].stderr_output = "";
    }

    // Simulate immediate completion
    setProcessState(processes_[proc.pid], ProgramState::EXITED);
    auto now = std::chrono::steady_clock::now().time_since_epoch();
    processes_[proc.pid].end_timestamp =
        std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    processes_[proc.pid].exit_code = 0;

    if (outProcess) {
        *outProcess = processes_[proc.pid];
    }

    return ProgramExecutorResult::SUCCESS;
}

ProgramExecutorResult ProgramExecutor::startProgram(
    const std::string& programId,
    const ExecutionOptions& options,
    uint32_t* outPid
) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto* prog = findProgram(programId);
    if (!prog) {
        return ProgramExecutorResult::NOT_REGISTERED;
    }

    // Check if already running
    if (!prog->running_pids.empty() && !options.allow_multiple_instances) {
        return ProgramExecutorResult::ALREADY_RUNNING;
    }

    // Create simulated process
    ProcessInfo proc = createProcess(programId, options);
    processes_[proc.pid] = proc;

    // Transition to STARTING then RUNNING
    setProcessState(processes_[proc.pid], ProgramState::STARTING);
    setProcessState(processes_[proc.pid], ProgramState::RUNNING);

    // Capture initial output
    if (options.capture_stdout) {
        processes_[proc.pid].stdout_output = buildStdout(prog->info, options);
    }

    // Mark program as running
    prog->running_pids.insert(proc.pid);

    if (outPid) {
        *outPid = proc.pid;
    }

    return ProgramExecutorResult::SUCCESS;
}

ProgramExecutorResult ProgramExecutor::terminateProcess(uint32_t pid) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto* proc = findProcess(pid);
    if (!proc) {
        return ProgramExecutorResult::NOT_FOUND;
    }

    if (proc->state == ProgramState::EXITED ||
        proc->state == ProgramState::TERMINATED ||
        proc->state == ProgramState::FAILED) {
        return ProgramExecutorResult::ALREADY_EXITED;
    }

    if (proc->state != ProgramState::RUNNING) {
        return ProgramExecutorResult::NOT_RUNNING;
    }

    setProcessState(*proc, ProgramState::TERMINATED);
    auto now = std::chrono::steady_clock::now().time_since_epoch();
    proc->end_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    proc->exit_code = 1;

    // Update program running state
    auto* prog = findProgram(proc->program_id);
    if (prog) {
        prog->running_pids.erase(pid);
    }

    return ProgramExecutorResult::TERMINATED_OK;
}

ProgramExecutorResult ProgramExecutor::timeoutProcess(uint32_t pid) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto* proc = findProcess(pid);
    if (!proc) {
        return ProgramExecutorResult::NOT_FOUND;
    }

    if (proc->state == ProgramState::EXITED ||
        proc->state == ProgramState::TERMINATED ||
        proc->state == ProgramState::FAILED) {
        return ProgramExecutorResult::ALREADY_EXITED;
    }

    if (proc->state != ProgramState::RUNNING) {
        return ProgramExecutorResult::NOT_RUNNING;
    }

    setProcessState(*proc, ProgramState::TIMEOUT);
    auto now = std::chrono::steady_clock::now().time_since_epoch();
    proc->end_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
    proc->exit_code = 124;  // Standard timeout exit code

    // Update program running state
    auto* prog = findProgram(proc->program_id);
    if (prog) {
        prog->running_pids.erase(pid);
    }

    return ProgramExecutorResult::TIMEOUT;
}

// ============================================================
// Process query
// ============================================================

ProcessInfo ProgramExecutor::getProcessInfo(uint32_t pid) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto* proc = findProcess(pid);
    if (!proc) return ProcessInfo();
    return *proc;
}

std::vector<uint32_t> ProgramExecutor::getRunningProcesses() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<uint32_t> result;
    for (const auto& [pid, proc] : processes_) {
        if (proc.state == ProgramState::RUNNING ||
            proc.state == ProgramState::STARTING) {
            result.push_back(pid);
        }
    }
    return result;
}

std::vector<uint32_t> ProgramExecutor::getAllProcesses() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<uint32_t> result;
    for (const auto& [pid, _] : processes_) {
        result.push_back(pid);
    }
    return result;
}

bool ProgramExecutor::isProcessRunning(uint32_t pid) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto* proc = findProcess(pid);
    if (!proc) return false;
    return proc->state == ProgramState::RUNNING || proc->state == ProgramState::STARTING;
}

size_t ProgramExecutor::getRunningCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    size_t count = 0;
    for (const auto& [_, proc] : processes_) {
        if (proc.state == ProgramState::RUNNING || proc.state == ProgramState::STARTING) {
            count++;
        }
    }
    return count;
}

// ============================================================
// Package integration
// ============================================================

ProgramExecutorResult ProgramExecutor::registerProgramFromPackage(
    const std::string& packageId,
    LinuxDistro distro,
    CpuArchitecture arch
) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!isSupportedDistro(distro)) {
        return ProgramExecutorResult::UNSUPPORTED_DISTRO;
    }
    if (!isSupportedArch(arch)) {
        return ProgramExecutorResult::UNSUPPORTED_ARCH;
    }

    // Get package info from PackageManager
    auto& pm = phantom::package::PackageManager::getInstance();
    if (!pm.isPackageInstalled(packageId)) {
        return ProgramExecutorResult::PACKAGE_NOT_INSTALLED;
    }

    auto pkgInfo = pm.getInstalledPackageInfo(packageId);

    LinuxProgramInfo info;
    info.program_id = "linux." + packageId;
    info.name = pkgInfo.name;
    info.version = pkgInfo.version_str;
    info.distro = distro;
    info.arch = arch;
    info.executable_path = pkgInfo.install_path + "/" + pkgInfo.entry_point;
    info.package_id = packageId;
    info.sandbox_profile = "normal";
    info.type = ProgramType::CLI;
    info.description = "Registered from package: " + packageId;

    // Check if already registered
    if (programs_.find(info.program_id) != programs_.end()) {
        return ProgramExecutorResult::ALREADY_REGISTERED;
    }

    RegisteredProgram entry;
    entry.info = info;
    programs_[info.program_id] = entry;

    return ProgramExecutorResult::SUCCESS;
}

// ============================================================
// Callbacks
// ============================================================

void ProgramExecutor::setStateChangeCallback(ProcessStateCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    state_callback_ = callback;
}

// ============================================================
// Utility
// ============================================================

bool ProgramExecutor::isSupportedDistro(LinuxDistro distro) {
    return distro != LinuxDistro::UNKNOWN_DISTRO;
}

bool ProgramExecutor::isSupportedArch(CpuArchitecture arch) {
    return arch != CpuArchitecture::UNKNOWN_ARCH;
}

PackageFormat ProgramExecutor::getDistroPackageFormat(LinuxDistro distro) {
    return distroToPackageFormat(distro);
}

void ProgramExecutor::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    programs_.clear();
    processes_.clear();
    next_pid_ = 1;
    state_callback_ = nullptr;
}

}  // namespace phantom::linux_compat
