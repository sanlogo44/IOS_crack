/*
 * Phantom OS - Program Executor
 * Simulated Linux program execution for Kali, Arch, CSI-Linux compatibility
 *
 * License: GPL-3.0
 */

#pragma once

#include "linux_program.h"
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace phantom::framework { class AppLifecycleManager; }
namespace phantom::package { class PackageManager; }

namespace phantom::linux_compat {

// Registered program entry
struct RegisteredProgram {
    LinuxProgramInfo info;
    std::unordered_set<uint32_t> running_pids;  // All running PIDs for this program
};

// Process state change callback
using ProcessStateCallback = std::function<void(uint32_t pid,
                                                const std::string& programId,
                                                ProgramState oldState,
                                                ProgramState newState)>;

// Program Executor - singleton
class ProgramExecutor {
public:
    static ProgramExecutor& getInstance();

    // ============================================================
    // Program registration
    // ============================================================

    ProgramExecutorResult registerProgram(const LinuxProgramInfo& info);
    ProgramExecutorResult unregisterProgram(const std::string& programId, bool force = false);

    bool isProgramRegistered(const std::string& programId) const;
    LinuxProgramInfo getProgramInfo(const std::string& programId) const;
    std::vector<std::string> getRegisteredPrograms() const;
    std::vector<std::string> getProgramsByDistro(LinuxDistro distro) const;
    size_t getRegisteredCount() const;

    // ============================================================
    // Program execution
    // ============================================================

    // Execute a program synchronously (simulated - returns immediately with EXITED)
    ProgramExecutorResult executeProgram(
        const std::string& programId,
        const ExecutionOptions& options,
        ProcessInfo* outProcess = nullptr
    );

    // Start a program asynchronously (simulated - stays in RUNNING state)
    ProgramExecutorResult startProgram(
        const std::string& programId,
        const ExecutionOptions& options,
        uint32_t* outPid = nullptr
    );

    // Terminate a running process
    ProgramExecutorResult terminateProcess(uint32_t pid);

    // Simulate a process timeout
    ProgramExecutorResult timeoutProcess(uint32_t pid);

    // ============================================================
    // Process query
    // ============================================================

    ProcessInfo getProcessInfo(uint32_t pid) const;
    std::vector<uint32_t> getRunningProcesses() const;
    std::vector<uint32_t> getAllProcesses() const;
    bool isProcessRunning(uint32_t pid) const;
    size_t getRunningCount() const;

    // ============================================================
    // Package integration
    // ============================================================

    // Register a program from an installed package
    ProgramExecutorResult registerProgramFromPackage(
        const std::string& packageId,
        LinuxDistro distro,
        CpuArchitecture arch
    );

    // ============================================================
    // Callbacks
    // ============================================================

    void setStateChangeCallback(ProcessStateCallback callback);

    // ============================================================
    // Utility
    // ============================================================

    static bool isSupportedDistro(LinuxDistro distro);
    static bool isSupportedArch(CpuArchitecture arch);
    static PackageFormat getDistroPackageFormat(LinuxDistro distro);

    void clear();

private:
    ProgramExecutor() = default;
    ~ProgramExecutor() = default;
    ProgramExecutor(const ProgramExecutor&) = delete;
    ProgramExecutor& operator=(const ProgramExecutor&) = delete;

    std::unordered_map<std::string, RegisteredProgram> programs_;
    std::unordered_map<uint32_t, ProcessInfo> processes_;
    uint32_t next_pid_ = 1;
    ProcessStateCallback state_callback_;
    mutable std::mutex mutex_;

    RegisteredProgram* findProgram(const std::string& programId);
    const RegisteredProgram* findProgram(const std::string& programId) const;

    ProcessInfo* findProcess(uint32_t pid);
    const ProcessInfo* findProcess(uint32_t pid) const;

    void setProcessState(ProcessInfo& proc, ProgramState newState);
    uint32_t allocatePid();
    ProcessInfo createProcess(const std::string& programId, const ExecutionOptions& options);
    std::string buildStdout(const LinuxProgramInfo& info, const ExecutionOptions& options) const;
};

}  // namespace phantom::linux_compat
