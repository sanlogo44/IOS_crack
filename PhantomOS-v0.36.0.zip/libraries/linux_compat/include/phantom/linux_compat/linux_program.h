/*
 * Phantom OS - Linux Compatibility Layer
 * Types for Linux program execution support (Kali, Arch, CSI-Linux)
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <vector>
#include <cstdint>

namespace phantom::linux_compat {

// ============================================================
// Enums
// ============================================================

// Supported Linux distributions
enum class LinuxDistro {
    GENERIC_LINUX,   // Generic Linux program
    KALI_LINUX,      // Kali Linux (penetration testing)
    ARCH_LINUX,      // Arch Linux (rolling release)
    CSI_LINUX,       // CSI-Linux (forensics)
    UNKNOWN_DISTRO
};

// Package formats for different distros
enum class PackageFormat {
    DEB,             // Debian/Kali (.deb)
    PACMAN,          // Arch Linux (.pkg.tar.zst)
    TAR_ARCHIVE,     // Generic tarball
    APPIMAGE,        // AppImage
    UNKNOWN_FORMAT
};

// CPU architectures
enum class CpuArchitecture {
    ARM64,           // AArch64 (iPhone X native)
    X86_64,          // x86_64
    ARMV7,           // ARMv7 (32-bit)
    UNKNOWN_ARCH
};

// Program types
enum class ProgramType {
    CLI,             // Command-line tool
    GUI,             // Graphical application
    SERVICE,         // Background service/daemon
    UNKNOWN_TYPE
};

// Process states
enum class ProgramState {
    REGISTERED,      // Program registered, not started
    STARTING,        // Process is starting
    RUNNING,         // Process is running
    EXITED,          // Process exited normally
    FAILED,          // Process failed to start
    TERMINATED,      // Process was terminated
    TIMEOUT          // Process timed out
};

// Execution result codes
enum class ProgramExecutorResult {
    SUCCESS,
    INVALID_PROGRAM,
    INVALID_PATH,
    ALREADY_REGISTERED,
    NOT_REGISTERED,
    ALREADY_RUNNING,
    NOT_RUNNING,
    UNSUPPORTED_DISTRO,
    UNSUPPORTED_ARCH,
    PACKAGE_NOT_INSTALLED,
    EXECUTION_FAILED,
    TIMEOUT,
    DENIED,
    NOT_FOUND,
    INVALID_OPTIONS,
    TERMINATED_OK,
    ALREADY_EXITED
};

// ============================================================
// Structs
// ============================================================

// Linux program metadata
struct LinuxProgramInfo {
    std::string program_id;         // Unique program identifier
    std::string name;               // Display name
    std::string version;            // Version string
    LinuxDistro distro = LinuxDistro::GENERIC_LINUX;
    CpuArchitecture arch = CpuArchitecture::ARM64;
    std::string executable_path;    // Path to executable
    std::string package_id;         // Associated package ID (optional)
    std::vector<std::string> permissions;  // Required permissions
    std::string sandbox_profile;    // Sandbox profile name
    ProgramType type = ProgramType::CLI;
    std::string description;        // Program description
};

// Execution options
struct ExecutionOptions {
    std::vector<std::string> args;       // Command-line arguments
    std::vector<std::pair<std::string, std::string>> env;  // Environment variable overrides
    std::string working_dir;            // Working directory
    uint32_t timeout_ms = 0;             // Timeout in ms (0 = no timeout)
    bool capture_stdout = true;          // Capture stdout
    bool capture_stderr = true;          // Capture stderr
    bool allow_multiple_instances = false;  // Allow multiple instances
};

// Process information
struct ProcessInfo {
    uint32_t pid = 0;                    // Process ID (simulated)
    std::string program_id;             // Associated program
    ProgramState state = ProgramState::REGISTERED;
    std::vector<std::string> args;       // Arguments used
    std::vector<std::pair<std::string, std::string>> env;  // Environment
    std::string working_dir;            // Working directory
    std::string stdout_output;           // Captured stdout
    std::string stderr_output;           // Captured stderr
    int32_t exit_code = -1;              // Exit code (-1 = not exited)
    uint64_t start_timestamp = 0;        // Start time
    uint64_t end_timestamp = 0;          // End time
    uint32_t timeout_ms = 0;             // Configured timeout
};

// ============================================================
// Utility functions
// ============================================================

// String conversions
inline const char* distroToString(LinuxDistro distro) {
    switch (distro) {
        case LinuxDistro::GENERIC_LINUX: return "GENERIC_LINUX";
        case LinuxDistro::KALI_LINUX: return "KALI_LINUX";
        case LinuxDistro::ARCH_LINUX: return "ARCH_LINUX";
        case LinuxDistro::CSI_LINUX: return "CSI_LINUX";
        default: return "UNKNOWN_DISTRO";
    }
}

inline const char* packageFormatToString(PackageFormat fmt) {
    switch (fmt) {
        case PackageFormat::DEB: return "DEB";
        case PackageFormat::PACMAN: return "PACMAN";
        case PackageFormat::TAR_ARCHIVE: return "TAR_ARCHIVE";
        case PackageFormat::APPIMAGE: return "APPIMAGE";
        default: return "UNKNOWN_FORMAT";
    }
}

inline const char* archToString(CpuArchitecture arch) {
    switch (arch) {
        case CpuArchitecture::ARM64: return "ARM64";
        case CpuArchitecture::X86_64: return "X86_64";
        case CpuArchitecture::ARMV7: return "ARMV7";
        default: return "UNKNOWN_ARCH";
    }
}

inline const char* programTypeToString(ProgramType type) {
    switch (type) {
        case ProgramType::CLI: return "CLI";
        case ProgramType::GUI: return "GUI";
        case ProgramType::SERVICE: return "SERVICE";
        default: return "UNKNOWN_TYPE";
    }
}

inline const char* programStateToString(ProgramState state) {
    switch (state) {
        case ProgramState::REGISTERED: return "REGISTERED";
        case ProgramState::STARTING: return "STARTING";
        case ProgramState::RUNNING: return "RUNNING";
        case ProgramState::EXITED: return "EXITED";
        case ProgramState::FAILED: return "FAILED";
        case ProgramState::TERMINATED: return "TERMINATED";
        case ProgramState::TIMEOUT: return "TIMEOUT";
        default: return "UNKNOWN_STATE";
    }
}

inline const char* resultToString(ProgramExecutorResult result) {
    switch (result) {
        case ProgramExecutorResult::SUCCESS: return "SUCCESS";
        case ProgramExecutorResult::INVALID_PROGRAM: return "INVALID_PROGRAM";
        case ProgramExecutorResult::INVALID_PATH: return "INVALID_PATH";
        case ProgramExecutorResult::ALREADY_REGISTERED: return "ALREADY_REGISTERED";
        case ProgramExecutorResult::NOT_REGISTERED: return "NOT_REGISTERED";
        case ProgramExecutorResult::ALREADY_RUNNING: return "ALREADY_RUNNING";
        case ProgramExecutorResult::NOT_RUNNING: return "NOT_RUNNING";
        case ProgramExecutorResult::UNSUPPORTED_DISTRO: return "UNSUPPORTED_DISTRO";
        case ProgramExecutorResult::UNSUPPORTED_ARCH: return "UNSUPPORTED_ARCH";
        case ProgramExecutorResult::PACKAGE_NOT_INSTALLED: return "PACKAGE_NOT_INSTALLED";
        case ProgramExecutorResult::EXECUTION_FAILED: return "EXECUTION_FAILED";
        case ProgramExecutorResult::TIMEOUT: return "TIMEOUT";
        case ProgramExecutorResult::DENIED: return "DENIED";
        case ProgramExecutorResult::NOT_FOUND: return "NOT_FOUND";
        case ProgramExecutorResult::INVALID_OPTIONS: return "INVALID_OPTIONS";
        case ProgramExecutorResult::TERMINATED_OK: return "TERMINATED_OK";
        case ProgramExecutorResult::ALREADY_EXITED: return "ALREADY_EXITED";
        default: return "UNKNOWN_RESULT";
    }
}

// Get expected package format for a distro
inline PackageFormat distroToPackageFormat(LinuxDistro distro) {
    switch (distro) {
        case LinuxDistro::KALI_LINUX: return PackageFormat::DEB;
        case LinuxDistro::ARCH_LINUX: return PackageFormat::PACMAN;
        case LinuxDistro::CSI_LINUX: return PackageFormat::TAR_ARCHIVE;
        case LinuxDistro::GENERIC_LINUX: return PackageFormat::TAR_ARCHIVE;
        default: return PackageFormat::UNKNOWN_FORMAT;
    }
}

}  // namespace phantom::linux_compat
