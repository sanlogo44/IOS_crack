/*
 * Phantom OS - App Sandbox System
 * Policy-based sandbox with seccomp-bpf stubs (prototype-level)
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <cstdint>

namespace phantom::security {

// System call action
enum class SyscallAction {
    ALLOW = 0,
    DENY = 1,
    LOG = 2,      // Allow but log
    KILL = 3,     // Kill process on violation
};

// Sandbox profile preset
enum class SandboxProfile {
    NONE = 0,
    STRICT = 1,       // Minimal syscalls (read, write, exit, etc.)
    NORMAL = 2,       // Standard app sandbox
    DEVELOPER = 3,    // Relaxed for development
    NETWORK = 4,      // Allows network access
};

// File access mode
enum class FileAccess {
    NONE = 0,
    READ = 1,
    WRITE = 2,
    READ_WRITE = 3,
};

// Resource limits
struct ResourceLimits {
    int64_t maxMemoryBytes = -1;     // -1 = unlimited
    int64_t maxCpuTimeMs = -1;       // -1 = unlimited
    int64_t maxFileDescriptors = -1;  // -1 = unlimited
    int64_t maxProcesses = -1;       // -1 = unlimited
    int64_t maxNetworkConnections = -1;  // -1 = unlimited
};

// Sandbox policy for an app
struct SandboxPolicy {
    std::string appId;
    SandboxProfile profile = SandboxProfile::NORMAL;
    ResourceLimits limits;

    // Syscall rules: syscall name -> action
    std::unordered_map<std::string, SyscallAction> syscallRules;

    // File access rules: path prefix -> access mode
    std::unordered_map<std::string, FileAccess> fileRules;

    // Network access
    bool networkAllowed = false;
    bool internetAllowed = false;
    std::vector<std::string> allowedHosts;

    // Capabilities
    bool canAccessCamera = false;
    bool canAccessMicrophone = false;
    bool canAccessLocation = false;
    bool canAccessContacts = false;
    bool canAccessSms = false;
    bool canAccessPhone = false;
    bool canAccessStorage = false;
    bool canAccessBluetooth = false;
};

// Result of sandbox operations
enum class SandboxResult {
    SUCCESS = 0,
    POLICY_NOT_FOUND = 1,
    ALREADY_EXISTS = 2,
    INVALID_POLICY = 3,
    UNSUPPORTED = 4,     // seccomp-bpf not available on this platform
    APPLY_FAILED = 5,
};

class AppSandbox {
public:
    AppSandbox() = default;

    // Policy management
    SandboxResult registerPolicy(const SandboxPolicy& policy);
    SandboxResult updatePolicy(const std::string& appId, const SandboxPolicy& policy);
    SandboxResult removePolicy(const std::string& appId);

    // Query policies
    const SandboxPolicy* getPolicy(const std::string& appId) const;
    bool hasPolicy(const std::string& appId) const;
    std::vector<std::string> getRegisteredAppIds() const;
    size_t getPolicyCount() const { return policies_.size(); }

    // Check if a syscall is allowed for an app
    SyscallAction checkSyscall(const std::string& appId, const std::string& syscallName) const;

    // Check file access for an app
    FileAccess checkFileAccess(const std::string& appId, const std::string& path) const;

    // Check network access
    bool canAccessNetwork(const std::string& appId) const;

    // Check capability
    bool hasCapability(const std::string& appId, const std::string& capability) const;

    // Create a policy from a preset profile
    static SandboxPolicy createFromProfile(const std::string& appId, SandboxProfile profile);

    // Check if seccomp-bpf is available on this platform
    static bool isSeccompAvailable();

    // Apply sandbox to current process (prototype: returns UNSUPPORTED if seccomp not available)
    SandboxResult applySandbox(const std::string& appId) const;

    // Validate a policy
    static bool validatePolicy(const SandboxPolicy& policy, std::string& error);

    // Get all known syscall names for a profile
    static std::vector<std::string> getProfileSyscalls(SandboxProfile profile);

    // Get profile name
    static std::string getProfileName(SandboxProfile profile);

    // Get action name
    static std::string getActionName(SyscallAction action);

    // Get file access name
    static std::string getFileAccessName(FileAccess access);

private:
    std::unordered_map<std::string, SandboxPolicy> policies_;

    // Default syscall lists per profile
    static std::vector<std::string> getStrictSyscalls();
    static std::vector<std::string> getNormalSyscalls();
    static std::vector<std::string> getDeveloperSyscalls();
    static std::vector<std::string> getNetworkSyscalls();
};

}  // namespace phantom::security
