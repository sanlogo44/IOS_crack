/*
 * Phantom OS - App Sandbox Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/security/sandbox.h"

#ifdef __linux__
#include <sys/prctl.h>
// seccomp headers may not be available; guard with #ifdef
#endif

namespace phantom::security {

// ============================================================
// AppSandbox - Policy Management
// ============================================================

SandboxResult AppSandbox::registerPolicy(const SandboxPolicy& policy) {
    if (policy.appId.empty()) return SandboxResult::INVALID_POLICY;

    if (policies_.find(policy.appId) != policies_.end()) {
        return SandboxResult::ALREADY_EXISTS;
    }

    policies_[policy.appId] = policy;
    return SandboxResult::SUCCESS;
}

SandboxResult AppSandbox::updatePolicy(const std::string& appId, const SandboxPolicy& policy) {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return SandboxResult::POLICY_NOT_FOUND;

    it->second = policy;
    return SandboxResult::SUCCESS;
}

SandboxResult AppSandbox::removePolicy(const std::string& appId) {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return SandboxResult::POLICY_NOT_FOUND;

    policies_.erase(it);
    return SandboxResult::SUCCESS;
}

const SandboxPolicy* AppSandbox::getPolicy(const std::string& appId) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return nullptr;
    return &it->second;
}

bool AppSandbox::hasPolicy(const std::string& appId) const {
    return policies_.find(appId) != policies_.end();
}

std::vector<std::string> AppSandbox::getRegisteredAppIds() const {
    std::vector<std::string> ids;
    ids.reserve(policies_.size());
    for (const auto& pair : policies_) {
        ids.push_back(pair.first);
    }
    return ids;
}

SyscallAction AppSandbox::checkSyscall(const std::string& appId, const std::string& syscallName) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return SyscallAction::DENY;

    const SandboxPolicy& policy = it->second;

    // Check explicit rules first
    auto ruleIt = policy.syscallRules.find(syscallName);
    if (ruleIt != policy.syscallRules.end()) {
        return ruleIt->second;
    }

    // Default based on profile
    switch (policy.profile) {
        case SandboxProfile::NONE:
            return SyscallAction::ALLOW;
        case SandboxProfile::STRICT:
        case SandboxProfile::NORMAL:
        case SandboxProfile::DEVELOPER:
        case SandboxProfile::NETWORK:
            // Default deny for safety
            return SyscallAction::DENY;
    }
    return SyscallAction::DENY;
}

FileAccess AppSandbox::checkFileAccess(const std::string& appId, const std::string& path) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return FileAccess::NONE;

    const SandboxPolicy& policy = it->second;

    // Check each file rule (longest prefix match)
    FileAccess result = FileAccess::NONE;
    size_t bestMatch = 0;

    for (const auto& rule : policy.fileRules) {
        if (path.find(rule.first) == 0 && rule.first.length() > bestMatch) {
            result = rule.second;
            bestMatch = rule.first.length();
        }
    }

    return result;
}

bool AppSandbox::canAccessNetwork(const std::string& appId) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return false;
    return it->second.networkAllowed;
}

bool AppSandbox::hasCapability(const std::string& appId, const std::string& capability) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return false;

    const SandboxPolicy& policy = it->second;

    if (capability == "camera") return policy.canAccessCamera;
    if (capability == "microphone") return policy.canAccessMicrophone;
    if (capability == "location") return policy.canAccessLocation;
    if (capability == "contacts") return policy.canAccessContacts;
    if (capability == "sms") return policy.canAccessSms;
    if (capability == "phone") return policy.canAccessPhone;
    if (capability == "storage") return policy.canAccessStorage;
    if (capability == "bluetooth") return policy.canAccessBluetooth;
    if (capability == "network") return policy.networkAllowed;
    if (capability == "internet") return policy.internetAllowed;

    return false;
}

// ============================================================
// Policy Creation
// ============================================================

std::vector<std::string> AppSandbox::getStrictSyscalls() {
    return {
        "read", "write", "exit", "exit_group",
        "rt_sigaction", "rt_sigprocmask",
        "mmap", "munmap", "mprotect",
        "brk",
        "fstat", "close",
        "clock_gettime",
    };
}

std::vector<std::string> AppSandbox::getNormalSyscalls() {
    return {
        "read", "write", "exit", "exit_group",
        "rt_sigaction", "rt_sigprocmask", "rt_sigreturn",
        "mmap", "munmap", "mprotect", "mremap",
        "brk",
        "fstat", "stat", "lstat", "close",
        "openat", "readlinkat",
        "clock_gettime", "nanosleep",
        "futex",
        "getrandom",
        "ioctl",
        "dup", "dup2", "dup3",
        "pipe2",
        "eventfd2",
        "epoll_create1", "epoll_ctl", "epoll_wait",
    };
}

std::vector<std::string> AppSandbox::getDeveloperSyscalls() {
    auto syscalls = getNormalSyscalls();
    syscalls.push_back("ptrace");
    syscalls.push_back("process_vm_readv");
    return syscalls;
}

std::vector<std::string> AppSandbox::getNetworkSyscalls() {
    auto syscalls = getNormalSyscalls();
    syscalls.push_back("socket");
    syscalls.push_back("connect");
    syscalls.push_back("bind");
    syscalls.push_back("listen");
    syscalls.push_back("accept");
    syscalls.push_back("accept4");
    syscalls.push_back("sendto");
    syscalls.push_back("recvfrom");
    syscalls.push_back("sendmsg");
    syscalls.push_back("recvmsg");
    syscalls.push_back("shutdown");
    syscalls.push_back("getsockopt");
    syscalls.push_back("setsockopt");
    syscalls.push_back("getpeername");
    syscalls.push_back("getsockname");
    return syscalls;
}

SandboxPolicy AppSandbox::createFromProfile(const std::string& appId, SandboxProfile profile) {
    SandboxPolicy policy;
    policy.appId = appId;
    policy.profile = profile;

    std::vector<std::string> syscalls;
    switch (profile) {
        case SandboxProfile::NONE:
            return policy;  // No restrictions
        case SandboxProfile::STRICT:
            syscalls = getStrictSyscalls();
            policy.limits.maxMemoryBytes = 64 * 1024 * 1024;  // 64MB
            policy.limits.maxFileDescriptors = 32;
            policy.limits.maxProcesses = 0;
            break;
        case SandboxProfile::NORMAL:
            syscalls = getNormalSyscalls();
            policy.limits.maxMemoryBytes = 256 * 1024 * 1024;  // 256MB
            policy.limits.maxFileDescriptors = 256;
            policy.limits.maxProcesses = 0;
            policy.canAccessStorage = true;
            break;
        case SandboxProfile::DEVELOPER:
            syscalls = getDeveloperSyscalls();
            policy.limits.maxMemoryBytes = 512 * 1024 * 1024;  // 512MB
            policy.limits.maxFileDescriptors = 1024;
            policy.limits.maxProcesses = 4;
            policy.canAccessStorage = true;
            break;
        case SandboxProfile::NETWORK:
            syscalls = getNetworkSyscalls();
            policy.limits.maxMemoryBytes = 256 * 1024 * 1024;
            policy.limits.maxFileDescriptors = 256;
            policy.limits.maxNetworkConnections = 64;
            policy.networkAllowed = true;
            policy.internetAllowed = true;
            policy.canAccessStorage = true;
            break;
    }

    // Set all profile syscalls to ALLOW
    for (const auto& sc : syscalls) {
        policy.syscallRules[sc] = SyscallAction::ALLOW;
    }

    // File access rules based on profile
    if (profile != SandboxProfile::NONE) {
        policy.fileRules["/data/app/" + appId + "/"] = FileAccess::READ_WRITE;
        policy.fileRules["/data/data/" + appId + "/"] = FileAccess::READ_WRITE;
        policy.fileRules["/tmp/"] = FileAccess::READ_WRITE;
        policy.fileRules["/system/"] = FileAccess::READ;
        policy.fileRules["/res/"] = FileAccess::READ;
    }

    return policy;
}

// ============================================================
// Platform Support
// ============================================================

bool AppSandbox::isSeccompAvailable() {
#ifdef __linux__
    // Check if PR_SET_SECCOMP is available
    // In a real implementation, we'd check for SECCOMP_MODE_FILTER support
    // For the prototype, we return false to indicate stub mode
    return false;
#else
    return false;
#endif
}

SandboxResult AppSandbox::applySandbox(const std::string& appId) const {
    auto it = policies_.find(appId);
    if (it == policies_.end()) return SandboxResult::POLICY_NOT_FOUND;

    if (!isSeccompAvailable()) {
        return SandboxResult::UNSUPPORTED;
    }

    // In a real implementation, this would:
    // 1. Set up seccomp-bpf filter based on policy.syscallRules
    // 2. Set resource limits (setrlimit)
    // 3. Set up file path restrictions (landlock or chroot)
    // 4. Drop capabilities

    return SandboxResult::SUCCESS;
}

bool AppSandbox::validatePolicy(const SandboxPolicy& policy, std::string& error) {
    if (policy.appId.empty()) {
        error = "App ID cannot be empty";
        return false;
    }

    // Validate resource limits
    const auto& limits = policy.limits;
    if (limits.maxMemoryBytes != -1 && limits.maxMemoryBytes < 0) {
        error = "Invalid memory limit";
        return false;
    }
    if (limits.maxCpuTimeMs != -1 && limits.maxCpuTimeMs < 0) {
        error = "Invalid CPU time limit";
        return false;
    }
    if (limits.maxFileDescriptors != -1 && limits.maxFileDescriptors < 0) {
        error = "Invalid file descriptor limit";
        return false;
    }

    return true;
}

std::vector<std::string> AppSandbox::getProfileSyscalls(SandboxProfile profile) {
    switch (profile) {
        case SandboxProfile::NONE: return {};
        case SandboxProfile::STRICT: return getStrictSyscalls();
        case SandboxProfile::NORMAL: return getNormalSyscalls();
        case SandboxProfile::DEVELOPER: return getDeveloperSyscalls();
        case SandboxProfile::NETWORK: return getNetworkSyscalls();
    }
    return {};
}

std::string AppSandbox::getProfileName(SandboxProfile profile) {
    switch (profile) {
        case SandboxProfile::NONE: return "NONE";
        case SandboxProfile::STRICT: return "STRICT";
        case SandboxProfile::NORMAL: return "NORMAL";
        case SandboxProfile::DEVELOPER: return "DEVELOPER";
        case SandboxProfile::NETWORK: return "NETWORK";
    }
    return "UNKNOWN";
}

std::string AppSandbox::getActionName(SyscallAction action) {
    switch (action) {
        case SyscallAction::ALLOW: return "ALLOW";
        case SyscallAction::DENY: return "DENY";
        case SyscallAction::LOG: return "LOG";
        case SyscallAction::KILL: return "KILL";
    }
    return "UNKNOWN";
}

std::string AppSandbox::getFileAccessName(FileAccess access) {
    switch (access) {
        case FileAccess::NONE: return "NONE";
        case FileAccess::READ: return "READ";
        case FileAccess::WRITE: return "WRITE";
        case FileAccess::READ_WRITE: return "READ_WRITE";
    }
    return "UNKNOWN";
}

}  // namespace phantom::security
