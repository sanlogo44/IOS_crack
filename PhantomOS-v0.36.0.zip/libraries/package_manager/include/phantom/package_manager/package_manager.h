/*
 * Phantom OS - Package Manager
 * Local manifest-based package manager for install/uninstall/update
 *
 * License: GPL-3.0
 */

#pragma once

#include "package.h"
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace phantom::framework {
class AppLifecycleManager;
}

namespace phantom::package {

// Install options
struct InstallOptions {
    bool force = false;              // Force install even if already installed (for reinstall)
    bool skip_dependency_check = false;  // Skip dependency validation
};

// Uninstall options
struct UninstallOptions {
    bool force = false;              // Force uninstall even if app is running
    bool purge = false;             // Remove from available repository too
};

// Installed package entry
struct InstalledPackage {
    PackageManifest manifest;
    InstallState state = InstallState::INSTALLED;
    uint64_t install_timestamp = 0;   // When the package was installed
};

// Available package entry
struct AvailablePackage {
    PackageManifest manifest;
};

// State change callback
using PackageStateCallback = std::function<void(const std::string& packageId,
                                                 InstallState oldState, InstallState newState)>;

// Package Manager - singleton
class PackageManager {
public:
    static PackageManager& getInstance();

    // Local repository management
    PackageManagerResult addAvailablePackage(const PackageManifest& manifest);
    PackageManagerResult removeAvailablePackage(const std::string& packageId);
    std::vector<std::string> getAvailablePackages() const;
    bool isPackageAvailable(const std::string& packageId) const;
    PackageManifest getAvailableManifest(const std::string& packageId) const;

    // Manifest validation
    PackageManagerResult validateManifest(const PackageManifest& manifest) const;

    // Install / uninstall / update
    PackageManagerResult installPackage(const PackageManifest& manifest,
                                        InstallOptions options = {});
    PackageManagerResult installPackage(const std::string& packageId,
                                        InstallOptions options = {});
    PackageManagerResult uninstallPackage(const std::string& packageId,
                                          UninstallOptions options = {});
    PackageManagerResult updatePackage(const PackageManifest& manifest);

    // Batch install with topological sort (resolves dependencies)
    PackageManagerResult installWithDependencies(const std::vector<std::string>& packageIds);
    PackageManagerResult detectCycle(const std::vector<std::string>& packageIds) const;

    // Query operations
    bool isPackageInstalled(const std::string& packageId) const;
    InstallState getInstallState(const std::string& packageId) const;
    PackageInfo getInstalledPackageInfo(const std::string& packageId) const;
    PackageManifest getInstalledManifest(const std::string& packageId) const;
    std::vector<std::string> getInstalledPackages() const;
    std::vector<std::string> getDependents(const std::string& packageId) const;
    std::vector<PackageDependency> getDependencies(const std::string& packageId) const;
    size_t getInstalledCount() const;
    size_t getAvailableCount() const;

    // Version comparison
    static bool isNewerVersion(const PackageVersion& current, const PackageVersion& candidate);
    static bool isDowngrade(const PackageVersion& current, const PackageVersion& candidate);

    // State change callback
    void setStateChangeCallback(PackageStateCallback callback);

    // Clear all (for testing)
    void clear();

private:
    PackageManager() = default;
    ~PackageManager() = default;
    PackageManager(const PackageManager&) = delete;
    PackageManager& operator=(const PackageManager&) = delete;

    std::unordered_map<std::string, AvailablePackage> available_;
    std::unordered_map<std::string, InstalledPackage> installed_;

    PackageStateCallback state_callback_;
    mutable std::mutex mutex_;

    AvailablePackage* findAvailable(const std::string& packageId);
    const AvailablePackage* findAvailable(const std::string& packageId) const;
    InstalledPackage* findInstalled(const std::string& packageId);
    const InstalledPackage* findInstalled(const std::string& packageId) const;

    void setState(InstalledPackage& entry, InstallState newState);
    bool checkDependencies(const PackageManifest& manifest) const;
    bool checkDependency(const PackageDependency& dep) const;
    std::vector<std::string> topologicalSort(const std::vector<std::string>& packageIds) const;
    void topoDFS(const std::string& node,
                 std::unordered_map<std::string, int>& visited,
                 std::vector<std::string>& sorted,
                 const std::unordered_set<std::string>& needed) const;
    bool hasCycleDFS(const std::string& node,
                     std::unordered_map<std::string, int>& visited,
                     std::vector<std::string>& path) const;
};

}  // namespace phantom::package
