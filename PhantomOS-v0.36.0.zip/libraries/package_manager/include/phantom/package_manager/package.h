/*
 * Phantom OS - Package Types
 * Package metadata, manifest, and dependency definitions
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace phantom::package {

// Install state of a package
enum class InstallState : uint8_t {
    AVAILABLE   = 0,   // Package is in local repository but not installed
    INSTALLING  = 1,   // Package is being installed
    INSTALLED   = 2,   // Package is successfully installed
    UPDATING    = 3,   // Package is being updated
    REMOVING    = 4,    // Package is being removed
    REMOVED     = 5,    // Package has been removed
    FAILED      = 6,    // Last operation failed
};

// Package sandbox profile (maps to security sandbox profiles)
enum class SandboxProfile : uint8_t {
    STRICT    = 0,   // No network, no file access outside sandbox
    NORMAL    = 1,   // Standard app permissions
    DEVELOPER = 2,   // Elevated permissions for development
    NETWORK   = 3,   // Network access required
};

// Package version structure (semantic versioning: major.minor.patch)
struct PackageVersion {
    uint16_t major = 0;
    uint16_t minor = 0;
    uint16_t patch = 0;

    // Parse a version string "1.2.3" into components
    static PackageVersion parse(const std::string& str);

    // Convert to string
    std::string toString() const;

    // Comparison operators
    bool operator==(const PackageVersion& other) const;
    bool operator!=(const PackageVersion& other) const;
    bool operator<(const PackageVersion& other) const;
    bool operator<=(const PackageVersion& other) const;
    bool operator>(const PackageVersion& other) const;
    bool operator>=(const PackageVersion& other) const;
};

// Package dependency definition
struct PackageDependency {
    std::string package_id;           // Required package ID
    PackageVersion min_version;       // Minimum required version (0.0.0 = no minimum)
    PackageVersion max_version;       // Maximum allowed version (0.0.0 = no maximum)
    bool optional = false;            // If true, missing dependency is not an error

    // Check if a version satisfies this dependency
    bool satisfies(const PackageVersion& version) const;
};

// Package info - basic metadata
struct PackageInfo {
    std::string package_id;           // Unique package identifier (e.g., "com.phantom.settings")
    std::string app_id;              // Associated app ID (empty if no app)
    std::string name;                 // Human-readable name
    std::string version_str;         // Version string (e.g., "1.0.0")
    std::string min_os_version;      // Minimum OS version required
    std::string description;          // Package description
    std::string vendor;               // Vendor/author
    std::string entry_point;          // Entry point (e.g., "main")
    std::string install_path;         // Installation path
    PackageVersion version;           // Parsed version
};

// Package manifest - full package definition
struct PackageManifest {
    PackageInfo info;
    std::vector<std::string> permissions;          // Required permissions
    std::vector<PackageDependency> dependencies;    // Package dependencies
    SandboxProfile sandbox_profile = SandboxProfile::NORMAL;
    bool auto_start = false;                       // Auto-start on boot
};

// Result codes for package operations
enum class PackageManagerResult : int8_t {
    SUCCESS                    = 0,
    INVALID_MANIFEST           = -1,
    INVALID_PACKAGE_ID         = -2,
    ALREADY_INSTALLED          = -3,
    NOT_INSTALLED              = -4,
    ALREADY_AVAILABLE          = -5,
    NOT_AVAILABLE              = -6,
    DEPENDENCY_MISSING         = -7,
    DEPENDENCY_CONFLICT        = -8,
    VERSION_DOWNGRADE_BLOCKED  = -9,
    INSTALL_FAILED             = -10,
    UNINSTALL_FAILED           = -11,
    UPDATE_FAILED              = -12,
    APP_RUNNING                = -13,
    LIFECYCLE_REGISTRATION_FAILED = -14,
    PACKAGE_NOT_FOUND          = -15,
    INVALID_VERSION            = -16,
    CYCLE_DETECTED             = -17,
};

// Utility functions
const char* installStateToString(InstallState state);
const char* sandboxProfileToString(SandboxProfile profile);
const char* resultToString(PackageManagerResult result);

}  // namespace phantom::package
