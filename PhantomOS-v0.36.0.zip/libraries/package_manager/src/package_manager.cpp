/*
 * Phantom OS - Package Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/package_manager/package_manager.h"
#include "phantom/app_lifecycle.h"
#include <algorithm>
#include <chrono>
#include <queue>
#include <unordered_set>
#include <cstdio>
#include <sstream>

namespace phantom::package {

// ============================================================
// PackageVersion
// ============================================================

PackageVersion PackageVersion::parse(const std::string& str) {
    PackageVersion v;
    if (str.empty()) return v;

    std::string s = str;
    std::replace(s.begin(), s.end(), '.', ' ');

    std::istringstream iss(s);
    uint32_t major = 0, minor = 0, patch = 0;
    iss >> major >> minor >> patch;
    v.major = static_cast<uint16_t>(major);
    v.minor = static_cast<uint16_t>(minor);
    v.patch = static_cast<uint16_t>(patch);
    return v;
}

std::string PackageVersion::toString() const {
    return std::to_string(major) + "." + std::to_string(minor) + "." + std::to_string(patch);
}

bool PackageVersion::operator==(const PackageVersion& other) const {
    return major == other.major && minor == other.minor && patch == other.patch;
}

bool PackageVersion::operator!=(const PackageVersion& other) const {
    return !(*this == other);
}

bool PackageVersion::operator<(const PackageVersion& other) const {
    if (major != other.major) return major < other.major;
    if (minor != other.minor) return minor < other.minor;
    return patch < other.patch;
}

bool PackageVersion::operator<=(const PackageVersion& other) const {
    return *this < other || *this == other;
}

bool PackageVersion::operator>(const PackageVersion& other) const {
    return !(*this <= other);
}

bool PackageVersion::operator>=(const PackageVersion& other) const {
    return !(*this < other);
}

// ============================================================
// PackageDependency
// ============================================================

bool PackageDependency::satisfies(const PackageVersion& version) const {
    PackageVersion zero;
    if (min_version != zero && version < min_version) return false;
    if (max_version != zero && version > max_version) return false;
    return true;
}

// ============================================================
// Utility functions
// ============================================================

const char* installStateToString(InstallState state) {
    switch (state) {
        case InstallState::AVAILABLE:   return "AVAILABLE";
        case InstallState::INSTALLING:  return "INSTALLING";
        case InstallState::INSTALLED:   return "INSTALLED";
        case InstallState::UPDATING:    return "UPDATING";
        case InstallState::REMOVING:    return "REMOVING";
        case InstallState::REMOVED:     return "REMOVED";
        case InstallState::FAILED:      return "FAILED";
        default: return "UNKNOWN";
    }
}

const char* sandboxProfileToString(SandboxProfile profile) {
    switch (profile) {
        case SandboxProfile::STRICT:    return "STRICT";
        case SandboxProfile::NORMAL:    return "NORMAL";
        case SandboxProfile::DEVELOPER: return "DEVELOPER";
        case SandboxProfile::NETWORK:   return "NETWORK";
        default: return "UNKNOWN";
    }
}

const char* resultToString(PackageManagerResult result) {
    switch (result) {
        case PackageManagerResult::SUCCESS:                   return "SUCCESS";
        case PackageManagerResult::INVALID_MANIFEST:          return "INVALID_MANIFEST";
        case PackageManagerResult::INVALID_PACKAGE_ID:        return "INVALID_PACKAGE_ID";
        case PackageManagerResult::ALREADY_INSTALLED:         return "ALREADY_INSTALLED";
        case PackageManagerResult::NOT_INSTALLED:             return "NOT_INSTALLED";
        case PackageManagerResult::ALREADY_AVAILABLE:         return "ALREADY_AVAILABLE";
        case PackageManagerResult::NOT_AVAILABLE:             return "NOT_AVAILABLE";
        case PackageManagerResult::DEPENDENCY_MISSING:       return "DEPENDENCY_MISSING";
        case PackageManagerResult::DEPENDENCY_CONFLICT:      return "DEPENDENCY_CONFLICT";
        case PackageManagerResult::VERSION_DOWNGRADE_BLOCKED: return "VERSION_DOWNGRADE_BLOCKED";
        case PackageManagerResult::INSTALL_FAILED:           return "INSTALL_FAILED";
        case PackageManagerResult::UNINSTALL_FAILED:          return "UNINSTALL_FAILED";
        case PackageManagerResult::UPDATE_FAILED:             return "UPDATE_FAILED";
        case PackageManagerResult::APP_RUNNING:               return "APP_RUNNING";
        case PackageManagerResult::LIFECYCLE_REGISTRATION_FAILED: return "LIFECYCLE_REGISTRATION_FAILED";
        case PackageManagerResult::PACKAGE_NOT_FOUND:         return "PACKAGE_NOT_FOUND";
        case PackageManagerResult::INVALID_VERSION:           return "INVALID_VERSION";
        case PackageManagerResult::CYCLE_DETECTED:            return "CYCLE_DETECTED";
        default: return "UNKNOWN";
    }
}

// ============================================================
// PackageManager
// ============================================================

PackageManager& PackageManager::getInstance() {
    static PackageManager instance;
    return instance;
}

PackageManagerResult PackageManager::addAvailablePackage(const PackageManifest& manifest) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (manifest.info.package_id.empty()) return PackageManagerResult::INVALID_PACKAGE_ID;

    if (available_.find(manifest.info.package_id) != available_.end()) {
        return PackageManagerResult::ALREADY_AVAILABLE;
    }

    AvailablePackage pkg;
    pkg.manifest = manifest;
    available_[manifest.info.package_id] = std::move(pkg);
    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::removeAvailablePackage(const std::string& packageId) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = available_.find(packageId);
    if (it == available_.end()) return PackageManagerResult::NOT_AVAILABLE;
    available_.erase(it);
    return PackageManagerResult::SUCCESS;
}

std::vector<std::string> PackageManager::getAvailablePackages() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, pkg] : available_) {
        result.push_back(id);
    }
    return result;
}

bool PackageManager::isPackageAvailable(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return available_.find(packageId) != available_.end();
}

PackageManifest PackageManager::getAvailableManifest(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const AvailablePackage* pkg = findAvailable(packageId);
    if (!pkg) return PackageManifest{};
    return pkg->manifest;
}

PackageManagerResult PackageManager::validateManifest(const PackageManifest& manifest) const {
    if (manifest.info.package_id.empty()) return PackageManagerResult::INVALID_PACKAGE_ID;
    if (manifest.info.name.empty()) return PackageManagerResult::INVALID_MANIFEST;
    if (manifest.info.version_str.empty()) return PackageManagerResult::INVALID_MANIFEST;
    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::installPackage(const PackageManifest& manifest,
                                                     InstallOptions options) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto vr = validateManifest(manifest);
    if (vr != PackageManagerResult::SUCCESS) return vr;

    // Check if already installed
    auto it = installed_.find(manifest.info.package_id);
    if (it != installed_.end()) {
        if (!options.force) return PackageManagerResult::ALREADY_INSTALLED;
        // Force reinstall: remove first
        it->second.state = InstallState::REMOVED;
    }

    // Check dependencies
    if (!options.skip_dependency_check) {
        if (!checkDependencies(manifest)) {
            return PackageManagerResult::DEPENDENCY_MISSING;
        }
    }

    // Create installed entry
    InstalledPackage entry;
    entry.manifest = manifest;
    entry.state = InstallState::INSTALLING;
    entry.install_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();

    // Add to installed
    installed_[manifest.info.package_id] = entry;

    // Transition to INSTALLED
    InstalledPackage& installed = installed_[manifest.info.package_id];
    setState(installed, InstallState::INSTALLED);

    // Register with AppLifecycleManager if app_id is set
    if (!manifest.info.app_id.empty()) {
        auto& alm = framework::AppLifecycleManager::getInstance();
        framework::AppInfo appInfo;
        appInfo.app_id = manifest.info.app_id;
        appInfo.name = manifest.info.name;
        appInfo.version = manifest.info.version_str;
        appInfo.priority = framework::AppPriority::NORMAL;
        appInfo.target_sdk = 0;
        appInfo.required_permissions = manifest.permissions;
        appInfo.auto_start = manifest.auto_start;

        if (alm.isAppRegistered(manifest.info.app_id)) {
            // Already registered, skip
        } else {
            auto result = alm.registerApp(appInfo);
            if (result != framework::AppLifecycleResult::SUCCESS &&
                result != framework::AppLifecycleResult::ALREADY_REGISTERED) {
                setState(installed, InstallState::FAILED);
                return PackageManagerResult::LIFECYCLE_REGISTRATION_FAILED;
            }
        }
    }

    // Also add to available repository if not already there
    if (available_.find(manifest.info.package_id) == available_.end()) {
        AvailablePackage pkg;
        pkg.manifest = manifest;
        available_[manifest.info.package_id] = std::move(pkg);
    }

    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::installPackage(const std::string& packageId,
                                                     InstallOptions options) {
    std::lock_guard<std::mutex> lock(mutex_);

    const AvailablePackage* avail = findAvailable(packageId);
    if (!avail) return PackageManagerResult::NOT_AVAILABLE;

    PackageManifest manifest = avail->manifest;

    // Unlock to call the other installPackage overload? No - we're in the same lock.
    // Just inline the logic.
    auto vr = validateManifest(manifest);
    if (vr != PackageManagerResult::SUCCESS) return vr;

    auto it = installed_.find(packageId);
    if (it != installed_.end()) {
        if (!options.force) return PackageManagerResult::ALREADY_INSTALLED;
        it->second.state = InstallState::REMOVED;
    }

    if (!options.skip_dependency_check) {
        if (!checkDependencies(manifest)) {
            return PackageManagerResult::DEPENDENCY_MISSING;
        }
    }

    InstalledPackage entry;
    entry.manifest = manifest;
    entry.state = InstallState::INSTALLING;
    entry.install_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    installed_[packageId] = entry;

    InstalledPackage& installed = installed_[packageId];
    setState(installed, InstallState::INSTALLED);

    // Register with AppLifecycleManager
    if (!manifest.info.app_id.empty()) {
        auto& alm = framework::AppLifecycleManager::getInstance();
        framework::AppInfo appInfo;
        appInfo.app_id = manifest.info.app_id;
        appInfo.name = manifest.info.name;
        appInfo.version = manifest.info.version_str;
        appInfo.priority = framework::AppPriority::NORMAL;
        appInfo.required_permissions = manifest.permissions;
        appInfo.auto_start = manifest.auto_start;

        if (!alm.isAppRegistered(manifest.info.app_id)) {
            auto result = alm.registerApp(appInfo);
            if (result != framework::AppLifecycleResult::SUCCESS &&
                result != framework::AppLifecycleResult::ALREADY_REGISTERED) {
                setState(installed, InstallState::FAILED);
                return PackageManagerResult::LIFECYCLE_REGISTRATION_FAILED;
            }
        }
    }

    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::uninstallPackage(const std::string& packageId,
                                                       UninstallOptions options) {
    std::lock_guard<std::mutex> lock(mutex_);

    InstalledPackage* entry = findInstalled(packageId);
    if (!entry) return PackageManagerResult::NOT_INSTALLED;

    // Check if app is running
    if (!options.force && !entry->manifest.info.app_id.empty()) {
        auto& alm = framework::AppLifecycleManager::getInstance();
        if (alm.isAppRunning(entry->manifest.info.app_id)) {
            return PackageManagerResult::APP_RUNNING;
        }
    }

    setState(*entry, InstallState::REMOVING);

    // Unregister from AppLifecycleManager
    if (!entry->manifest.info.app_id.empty()) {
        auto& alm = framework::AppLifecycleManager::getInstance();
        if (alm.isAppRegistered(entry->manifest.info.app_id)) {
            // Try to unregister (will fail if running, which we already checked)
            alm.unregisterApp(entry->manifest.info.app_id);
        }
    }

    setState(*entry, InstallState::REMOVED);

    // Remove from installed
    installed_.erase(packageId);

    // Optionally purge from available
    if (options.purge) {
        available_.erase(packageId);
    }

    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::updatePackage(const PackageManifest& manifest) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto vr = validateManifest(manifest);
    if (vr != PackageManagerResult::SUCCESS) return vr;

    InstalledPackage* entry = findInstalled(manifest.info.package_id);
    if (!entry) return PackageManagerResult::NOT_INSTALLED;

    // Check for downgrade
    if (isDowngrade(entry->manifest.info.version, manifest.info.version)) {
        return PackageManagerResult::VERSION_DOWNGRADE_BLOCKED;
    }

    // Check if same version
    if (entry->manifest.info.version == manifest.info.version) {
        return PackageManagerResult::SUCCESS;  // Already up to date
    }

    // Check dependencies
    if (!checkDependencies(manifest)) {
        return PackageManagerResult::DEPENDENCY_MISSING;
    }

    setState(*entry, InstallState::UPDATING);

    // Update manifest
    entry->manifest = manifest;
    entry->install_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();

    setState(*entry, InstallState::INSTALLED);

    // Update lifecycle registration
    if (!manifest.info.app_id.empty()) {
        auto& alm = framework::AppLifecycleManager::getInstance();
        if (!alm.isAppRegistered(manifest.info.app_id)) {
            framework::AppInfo appInfo;
            appInfo.app_id = manifest.info.app_id;
            appInfo.name = manifest.info.name;
            appInfo.version = manifest.info.version_str;
            appInfo.priority = framework::AppPriority::NORMAL;
            appInfo.required_permissions = manifest.permissions;
            appInfo.auto_start = manifest.auto_start;
            alm.registerApp(appInfo);
        }
    }

    return PackageManagerResult::SUCCESS;
}

PackageManagerResult PackageManager::installWithDependencies(const std::vector<std::string>& packageIds) {
    std::lock_guard<std::mutex> lock(mutex_);

    // Detect cycles first
    auto cycleResult = detectCycle(packageIds);
    if (cycleResult != PackageManagerResult::SUCCESS) return cycleResult;

    // Topological sort
    auto sorted = topologicalSort(packageIds);
    if (sorted.empty() && !packageIds.empty()) {
        return PackageManagerResult::CYCLE_DETECTED;
    }

    // Install in order
    PackageManagerResult overall = PackageManagerResult::SUCCESS;
    for (const auto& pkgId : sorted) {
        const AvailablePackage* avail = findAvailable(pkgId);
        if (!avail) {
            return PackageManagerResult::NOT_AVAILABLE;
        }

        // Skip if already installed
        if (installed_.find(pkgId) != installed_.end()) continue;

        PackageManifest manifest = avail->manifest;

        if (!checkDependencies(manifest)) {
            return PackageManagerResult::DEPENDENCY_MISSING;
        }

        // Install
        InstalledPackage entry;
        entry.manifest = manifest;
        entry.state = InstallState::INSTALLING;
        entry.install_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        installed_[pkgId] = entry;
        setState(installed_[pkgId], InstallState::INSTALLED);

        // Register with AppLifecycleManager
        if (!manifest.info.app_id.empty()) {
            auto& alm = framework::AppLifecycleManager::getInstance();
            if (!alm.isAppRegistered(manifest.info.app_id)) {
                framework::AppInfo appInfo;
                appInfo.app_id = manifest.info.app_id;
                appInfo.name = manifest.info.name;
                appInfo.version = manifest.info.version_str;
                appInfo.priority = framework::AppPriority::NORMAL;
                appInfo.required_permissions = manifest.permissions;
                appInfo.auto_start = manifest.auto_start;
                alm.registerApp(appInfo);
            }
        }
    }

    return overall;
}

PackageManagerResult PackageManager::detectCycle(const std::vector<std::string>& packageIds) const {
    std::unordered_map<std::string, int> visited;  // 0=unvisited, 1=in-progress, 2=done

    for (const auto& pkgId : packageIds) {
        std::vector<std::string> path;
        if (hasCycleDFS(pkgId, visited, path)) {
            return PackageManagerResult::CYCLE_DETECTED;
        }
    }

    return PackageManagerResult::SUCCESS;
}

bool PackageManager::isPackageInstalled(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return installed_.find(packageId) != installed_.end();
}

InstallState PackageManager::getInstallState(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const InstalledPackage* entry = findInstalled(packageId);
    if (!entry) return InstallState::AVAILABLE;
    return entry->state;
}

PackageInfo PackageManager::getInstalledPackageInfo(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const InstalledPackage* entry = findInstalled(packageId);
    if (!entry) return PackageInfo{};
    return entry->manifest.info;
}

PackageManifest PackageManager::getInstalledManifest(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const InstalledPackage* entry = findInstalled(packageId);
    if (!entry) return PackageManifest{};
    return entry->manifest;
}

std::vector<std::string> PackageManager::getInstalledPackages() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, pkg] : installed_) {
        result.push_back(id);
    }
    return result;
}

std::vector<std::string> PackageManager::getDependents(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> result;
    for (const auto& [id, pkg] : installed_) {
        for (const auto& dep : pkg.manifest.dependencies) {
            if (dep.package_id == packageId) {
                result.push_back(id);
                break;
            }
        }
    }
    return result;
}

std::vector<PackageDependency> PackageManager::getDependencies(const std::string& packageId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const InstalledPackage* entry = findInstalled(packageId);
    if (!entry) return {};
    return entry->manifest.dependencies;
}

size_t PackageManager::getInstalledCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return installed_.size();
}

size_t PackageManager::getAvailableCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return available_.size();
}

bool PackageManager::isNewerVersion(const PackageVersion& current, const PackageVersion& candidate) {
    return candidate > current;
}

bool PackageManager::isDowngrade(const PackageVersion& current, const PackageVersion& candidate) {
    return candidate < current;
}

void PackageManager::setStateChangeCallback(PackageStateCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    state_callback_ = std::move(callback);
}

void PackageManager::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    available_.clear();
    installed_.clear();
    state_callback_ = nullptr;
}

// ============================================================
// Private methods
// ============================================================

AvailablePackage* PackageManager::findAvailable(const std::string& packageId) {
    auto it = available_.find(packageId);
    if (it == available_.end()) return nullptr;
    return &it->second;
}

const AvailablePackage* PackageManager::findAvailable(const std::string& packageId) const {
    auto it = available_.find(packageId);
    if (it == available_.end()) return nullptr;
    return &it->second;
}

InstalledPackage* PackageManager::findInstalled(const std::string& packageId) {
    auto it = installed_.find(packageId);
    if (it == installed_.end()) return nullptr;
    return &it->second;
}

const InstalledPackage* PackageManager::findInstalled(const std::string& packageId) const {
    auto it = installed_.find(packageId);
    if (it == installed_.end()) return nullptr;
    return &it->second;
}

void PackageManager::setState(InstalledPackage& entry, InstallState newState) {
    InstallState oldState = entry.state;
    entry.state = newState;
    if (state_callback_ && oldState != newState) {
        state_callback_(entry.manifest.info.package_id, oldState, newState);
    }
}

bool PackageManager::checkDependencies(const PackageManifest& manifest) const {
    for (const auto& dep : manifest.dependencies) {
        if (!checkDependency(dep)) return false;
    }
    return true;
}

bool PackageManager::checkDependency(const PackageDependency& dep) const {
    if (dep.optional) return true;

    // Check if dependency is installed
    const InstalledPackage* installed = findInstalled(dep.package_id);
    if (!installed) {
        // Check if it's at least available
        if (!findAvailable(dep.package_id)) return false;
        return false;  // Available but not installed = not satisfied
    }

    // Check version constraints
    if (!dep.satisfies(installed->manifest.info.version)) return false;

    return true;
}

std::vector<std::string> PackageManager::topologicalSort(const std::vector<std::string>& packageIds) const {
    // Collect all needed packages (requested + transitive dependencies)
    std::unordered_set<std::string> needed;
    std::queue<std::string> toProcess;
    for (const auto& id : packageIds) {
        if (needed.find(id) == needed.end()) {
            needed.insert(id);
            toProcess.push(id);
        }
    }
    while (!toProcess.empty()) {
        std::string id = toProcess.front();
        toProcess.pop();
        const AvailablePackage* pkg = findAvailable(id);
        if (!pkg) continue;
        for (const auto& dep : pkg->manifest.dependencies) {
            if (dep.optional) continue;
            if (needed.find(dep.package_id) == needed.end()) {
                needed.insert(dep.package_id);
                toProcess.push(dep.package_id);
            }
        }
    }

    // Topological sort via DFS
    std::vector<std::string> sorted;
    std::unordered_map<std::string, int> visited;

    for (const auto& id : needed) {
        if (visited.find(id) == visited.end()) {
            topoDFS(id, visited, sorted, needed);
        }
    }

    return sorted;
}

void PackageManager::topoDFS(const std::string& node,
                              std::unordered_map<std::string, int>& visited,
                              std::vector<std::string>& sorted,
                              const std::unordered_set<std::string>& needed) const {
    visited[node] = 1; // visiting

    const AvailablePackage* pkg = findAvailable(node);
    if (pkg) {
        for (const auto& dep : pkg->manifest.dependencies) {
            if (dep.optional) continue;
            if (needed.find(dep.package_id) != needed.end() &&
                visited.find(dep.package_id) == visited.end()) {
                topoDFS(dep.package_id, visited, sorted, needed);
            }
        }
    }

    visited[node] = 2; // visited
    sorted.push_back(node);
}

bool PackageManager::hasCycleDFS(const std::string& node,
                                  std::unordered_map<std::string, int>& visited,
                                  std::vector<std::string>& path) const {
    int state = visited[node];
    if (state == 1) return true;  // Cycle detected
    if (state == 2) return false;  // Already fully processed

    visited[node] = 1;  // Mark as in-progress
    path.push_back(node);

    // Find dependencies of this node
    const AvailablePackage* pkg = findAvailable(node);
    if (pkg) {
        for (const auto& dep : pkg->manifest.dependencies) {
            if (available_.find(dep.package_id) != available_.end()) {
                if (hasCycleDFS(dep.package_id, visited, path)) return true;
            }
        }
    }

    visited[node] = 2;  // Mark as done
    path.pop_back();
    return false;
}

}  // namespace phantom::package
