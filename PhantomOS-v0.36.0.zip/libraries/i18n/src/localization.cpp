/*
 * Phantom OS - Localization System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/i18n/localization.h"
#include <algorithm>

namespace phantom::i18n {

void Localization::setLocale(Locale locale) {
    currentLocale_ = locale;
}

std::string Localization::getLocaleCode(Locale locale) {
    switch (locale) {
        case Locale::ENGLISH: return "en";
        case Locale::GERMAN: return "de";
    }
    return "en";
}

Locale Localization::parseLocaleCode(const std::string& code) {
    if (code.length() >= 2) {
        std::string lower;
        lower.reserve(code.length());
        for (char c : code) {
            lower += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        }
        if (lower.substr(0, 2) == "de") return Locale::GERMAN;
    }
    return Locale::ENGLISH;
}

void Localization::registerTranslation(const std::string& key,
                                        const std::string& english,
                                        const std::string& german) {
    translations_[key] = {key, english, german};
}

std::string Localization::t(const std::string& key) const {
    return t(key, currentLocale_);
}

std::string Localization::t(const std::string& key, Locale locale) const {
    auto it = translations_.find(key);
    if (it == translations_.end()) return key;

    const TranslationEntry& entry = it->second;
    switch (locale) {
        case Locale::GERMAN:
            if (!entry.german.empty()) return entry.german;
            // Fall back to English
            if (!entry.english.empty()) return entry.english;
            return key;
        case Locale::ENGLISH:
            if (!entry.english.empty()) return entry.english;
            // Fall back to German
            if (!entry.german.empty()) return entry.german;
            return key;
    }
    return key;
}

bool Localization::hasTranslation(const std::string& key) const {
    return translations_.find(key) != translations_.end();
}

bool Localization::hasTranslation(const std::string& key, Locale locale) const {
    auto it = translations_.find(key);
    if (it == translations_.end()) return false;

    const TranslationEntry& entry = it->second;
    switch (locale) {
        case Locale::GERMAN: return !entry.german.empty();
        case Locale::ENGLISH: return !entry.english.empty();
    }
    return false;
}

std::vector<std::string> Localization::getKeys() const {
    std::vector<std::string> keys;
    keys.reserve(translations_.size());
    for (const auto& pair : translations_) {
        keys.push_back(pair.first);
    }
    return keys;
}

void Localization::clear() {
    translations_.clear();
}

void Localization::loadDefaults() {
    // Common UI strings
    registerTranslation("ok", "OK", "OK");
    registerTranslation("cancel", "Cancel", "Abbrechen");
    registerTranslation("yes", "Yes", "Ja");
    registerTranslation("no", "No", "Nein");
    registerTranslation("save", "Save", "Speichern");
    registerTranslation("delete", "Delete", "Löschen");
    registerTranslation("edit", "Edit", "Bearbeiten");
    registerTranslation("close", "Close", "Schließen");
    registerTranslation("back", "Back", "Zurück");
    registerTranslation("next", "Next", "Weiter");
    registerTranslation("done", "Done", "Fertig");
    registerTranslation("error", "Error", "Fehler");
    registerTranslation("warning", "Warning", "Warnung");
    registerTranslation("loading", "Loading...", "Laden...");

    // Settings
    registerTranslation("settings", "Settings", "Einstellungen");
    registerTranslation("wifi", "Wi-Fi", "WLAN");
    registerTranslation("bluetooth", "Bluetooth", "Bluetooth");
    registerTranslation("display", "Display", "Anzeige");
    registerTranslation("sound", "Sound", "Ton");
    registerTranslation("battery", "Battery", "Akku");
    registerTranslation("storage", "Storage", "Speicher");
    registerTranslation("privacy", "Privacy", "Datenschutz");
    registerTranslation("security", "Security", "Sicherheit");
    registerTranslation("about", "About", "Über");
    registerTranslation("language", "Language", "Sprache");

    // Phone app
    registerTranslation("phone", "Phone", "Telefon");
    registerTranslation("contacts", "Contacts", "Kontakte");
    registerTranslation("dialer", "Dialer", "Wähltastatur");
    registerTranslation("call", "Call", "Anrufen");
    registerTranslation("end_call", "End Call", "Anruf beenden");

    // Camera
    registerTranslation("camera", "Camera", "Kamera");
    registerTranslation("take_photo", "Take Photo", "Foto aufnehmen");
    registerTranslation("switch_camera", "Switch Camera", "Kamera wechseln");

    // System
    registerTranslation("phantom_os", "Phantom OS", "Phantom OS");
    registerTranslation("home", "Home", "Startseite");
    registerTranslation("search", "Search", "Suche");
    registerTranslation("notifications", "Notifications", "Benachrichtigungen");
    registerTranslation("airplane_mode", "Airplane Mode", "Flugmodus");

    // Permission dialog
    registerTranslation("permission_request", "Permission Request", "Berechtigungsanfrage");
    registerTranslation("allow", "Allow", "Erlauben");
    registerTranslation("deny", "Deny", "Verweigern");
    registerTranslation("allow_once", "Allow Once", "Einmal erlauben");
    registerTranslation("allow_always", "Allow Always", "Immer erlauben");

    // Network
    registerTranslation("connected", "Connected", "Verbunden");
    registerTranslation("disconnected", "Disconnected", "Getrennt");
    registerTranslation("scanning", "Scanning...", "Suche...");

    // Update
    registerTranslation("update_available", "Update Available", "Update verfügbar");
    registerTranslation("install_update", "Install Update", "Update installieren");
    registerTranslation("up_to_date", "Up to Date", "Aktuell");

    // Recovery
    registerTranslation("recovery_mode", "Recovery Mode", "Wiederherstellungsmodus");
    registerTranslation("factory_reset", "Factory Reset", "Auf Werkseinstellungen zurücksetzen");
    registerTranslation("reboot", "Reboot", "Neu starten");
}

}  // namespace phantom::i18n
