/*
 * Phantom OS - Localization System (i18n)
 * Locale management and translation catalogs for German and English
 *
 * License: GPL-3.0
 */

#pragma once

#include <string>
#include <unordered_map>
#include <vector>
#include <cstdint>

namespace phantom::i18n {

enum class Locale {
    ENGLISH = 0,
    GERMAN = 1,
};

struct TranslationEntry {
    std::string key;
    std::string english;
    std::string german;
};

class Localization {
public:
    Localization() = default;

    // Set active locale
    void setLocale(Locale locale);
    Locale getLocale() const { return currentLocale_; }

    // Get locale code string ("en" or "de")
    static std::string getLocaleCode(Locale locale);
    static Locale parseLocaleCode(const std::string& code);

    // Register a translation
    void registerTranslation(const std::string& key,
                             const std::string& english,
                             const std::string& german);

    // Translate a key in the current locale
    // Falls back to English, then to the key itself
    std::string t(const std::string& key) const;

    // Translate with a specific locale
    std::string t(const std::string& key, Locale locale) const;

    // Check if a translation exists
    bool hasTranslation(const std::string& key) const;
    bool hasTranslation(const std::string& key, Locale locale) const;

    // Get all registered keys
    std::vector<std::string> getKeys() const;

    // Get translation count
    size_t getTranslationCount() const { return translations_.size(); }

    // Clear all translations
    void clear();

    // Load built-in default translations
    void loadDefaults();

private:
    Locale currentLocale_ = Locale::ENGLISH;
    std::unordered_map<std::string, TranslationEntry> translations_;
};

}  // namespace phantom::i18n
