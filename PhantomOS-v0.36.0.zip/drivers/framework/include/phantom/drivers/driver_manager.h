/*
 * Phantom OS - Device Driver Framework
 * Driver registration, lifecycle, device enumeration, and management
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <functional>
#include <chrono>

namespace phantom::drivers {

// ============================================================
// Enums
// ============================================================

enum class DriverType {
    DISPLAY,        // Display/screen drivers
    INPUT,          // Touch, keyboard, sensors
    STORAGE,        // NVMe, SD card, USB storage
    NETWORK,        // Wi-Fi, Bluetooth, Cellular
    AUDIO,          // Speaker, microphone
    CAMERA,         // Camera sensors
    POWER,          // Battery, charger, power management
    BLUETOOTH,      // Bluetooth controller
    SENSOR,         // Accelerometer, gyroscope, etc.
    USB,            // USB host/device controller
    GPU,            // Graphics processing unit
    THERMAL,        // Thermal management
    UNKNOWN
};

enum class DriverState {
    UNLOADED,       // Driver not loaded
    LOADING,        // Driver is being loaded
    LOADED,         // Driver loaded but device not initialized
    INITIALIZING,   // Device is being initialized
    ACTIVE,         // Device is active and operational
    SUSPENDED,      // Device is suspended (low power)
    ERROR_STATE,    // Device in error state
    UNLOADING       // Driver is being unloaded
};

enum class DeviceStatus {
    ABSENT,         // No device present
    DETECTED,       // Device detected but not initialized
    READY,          // Device is ready
    ACTIVE,         // Device is active
    SUSPENDED,      // Device is suspended
    ERROR_STATE,    // Device has an error
    REMOVED         // Device was removed
};

enum class DriverPriority {
    CRITICAL,       // Must load first (display, power)
    HIGH,           // Important (input, storage)
    NORMAL,         // Standard (network, audio)
    LOW,            // Can wait (camera, sensors)
    OPTIONAL        // Non-essential
};

enum class DriverResult {
    SUCCESS,
    ALREADY_LOADED,
    NOT_FOUND,
    ALREADY_ACTIVE,
    INVALID_STATE,
    INIT_FAILED,
    LOAD_FAILED,
    DEVICE_NOT_FOUND,
    DEPENDENCY_FAILED,
    TIMEOUT,
    PERMISSION_DENIED,
    UNSUPPORTED
};

enum class DeviceBus {
    INTERNAL,       // On-chip peripheral
    PCIE,           // PCIe bus
    I2C,            // I2C bus
    SPI,            // SPI bus
    UART,           // UART serial
    USB,            // USB bus
    SDIO,           // SDIO bus
    VIRTUAL,        // Virtual/software device
    UNKNOWN
};

// ============================================================
// Structs
// ============================================================

struct DeviceInfo {
    uint32_t id = 0;
    std::string name;
    std::string description;
    std::string vendor;
    std::string model;
    std::string serial;
    DriverType type = DriverType::UNKNOWN;
    DeviceBus bus = DeviceBus::UNKNOWN;
    DeviceStatus status = DeviceStatus::ABSENT;
    uint32_t driverId = 0;
    std::string driverName;
    std::vector<std::string> capabilities;
    uint64_t detectedTime = 0;
    uint64_t activeTime = 0;
    bool hotplug = false;       // Hot-pluggable device
    bool removable = false;     // Removable device
};

struct DriverInfo {
    uint32_t id = 0;
    std::string name;
    std::string description;
    std::string version;
    std::string author;
    DriverType type = DriverType::UNKNOWN;
    DriverState state = DriverState::UNLOADED;
    DriverPriority priority = DriverPriority::NORMAL;
    std::vector<std::string> supportedDevices;
    std::vector<std::string> dependencies;
    std::vector<std::string> dependents;
    std::vector<uint32_t> boundDevices;
    bool autoLoad = true;
    bool autoInit = true;
    uint32_t initOrder = 50;    // Lower = earlier
    uint64_t loadTime = 0;
    uint64_t uptime = 0;
    uint32_t errorCount = 0;
    std::string lastError;
    std::string path;          // Driver path (simulated)
};

struct DriverStats {
    uint32_t totalDrivers = 0;
    uint32_t loadedDrivers = 0;
    uint32_t activeDrivers = 0;
    uint32_t errorDrivers = 0;
    uint32_t totalDevices = 0;
    uint32_t activeDevices = 0;
    uint32_t errorDevices = 0;
    uint32_t totalErrors = 0;
    uint64_t totalUptime = 0;
};

struct DriverEvent {
    uint32_t id = 0;
    std::string message;
    uint32_t driverId = 0;
    uint32_t deviceId = 0;
    DriverState driverState = DriverState::UNLOADED;
    DeviceStatus deviceStatus = DeviceStatus::ABSENT;
    uint64_t timestamp = 0;
    bool isError = false;
};

// ============================================================
// DriverManager - Core driver/device management
// ============================================================

class DriverManager {
public:
    DriverManager() = default;
    ~DriverManager() { shutdown(); }

    // Lifecycle
    DriverResult initialize();
    DriverResult shutdown();
    bool isInitialized() const { return initialized_; }
    DriverState getDriverState(const std::string& name) const;

    // Driver registration
    uint32_t registerDriver(const DriverInfo& driver);
    bool unregisterDriver(const std::string& name);
    DriverInfo getDriver(const std::string& name) const;
    DriverInfo getDriverById(uint32_t id) const;
    std::vector<DriverInfo> getDrivers() const;
    std::vector<DriverInfo> getDriversByType(DriverType type) const;
    std::vector<DriverInfo> getDriversByState(DriverState state) const;
    std::vector<DriverInfo> getDriversByPriority(DriverPriority priority) const;
    size_t getDriverCount() const;
    size_t getLoadedDriverCount() const;
    size_t getActiveDriverCount() const;

    // Driver lifecycle
    DriverResult loadDriver(const std::string& name);
    DriverResult unloadDriver(const std::string& name);
    DriverResult initDriver(const std::string& name);
    DriverResult suspendDriver(const std::string& name);
    DriverResult resumeDriver(const std::string& name);
    DriverResult reloadDriver(const std::string& name);

    // Device management
    uint32_t registerDevice(const DeviceInfo& device);
    bool unregisterDevice(const std::string& name);
    DeviceInfo getDevice(const std::string& name) const;
    DeviceInfo getDeviceById(uint32_t id) const;
    std::vector<DeviceInfo> getDevices() const;
    std::vector<DeviceInfo> getDevicesByType(DriverType type) const;
    std::vector<DeviceInfo> getDevicesByStatus(DeviceStatus status) const;
    std::vector<DeviceInfo> getDevicesByBus(DeviceBus bus) const;
    size_t getDeviceCount() const;
    size_t getActiveDeviceCount() const;

    // Device lifecycle
    DriverResult bindDevice(const std::string& deviceName, const std::string& driverName);
    DriverResult unbindDevice(const std::string& deviceName);
    DriverResult activateDevice(const std::string& name);
    DriverResult suspendDevice(const std::string& name);
    DriverResult removeDevice(const std::string& name);

    // Device discovery
    void discoverDevices();
    std::vector<DeviceInfo> detectHotplug() const;
    void setHotplugDetection(bool enabled) { hotplugEnabled_ = enabled; }
    bool isHotplugEnabled() const { return hotplugEnabled_; }

    // Dependency resolution
    std::vector<std::string> resolveDriverDependencies(const std::string& name) const;
    bool hasCircularDependency(const std::string& name) const;
    std::vector<std::string> getLoadOrder() const;

    // Error handling
    std::string getLastError(const std::string& driverName) const;
    uint32_t getErrorCount(const std::string& driverName) const;
    void clearErrors(const std::string& driverName);
    void setError(const std::string& driverName, const std::string& error);

    // Events
    std::vector<DriverEvent> getEvents() const;
    size_t getEventCount() const;
    void clearEvents();
    void setEventCallback(std::function<void(const DriverEvent&)> cb) { eventCb_ = cb; }

    // Stats
    DriverStats getStats() const;
    void resetStats();

    // Default drivers and devices
    void registerDefaultDrivers();
    void registerDefaultDevices();
    size_t getDefaultDriverCount() const { return defaultDrivers_.size(); }
    size_t getDefaultDeviceCount() const { return defaultDevices_.size(); }

    // String helpers
    static const char* driverTypeToString(DriverType type);
    static const char* driverStateToString(DriverState state);
    static const char* deviceStatusToString(DeviceStatus status);
    static const char* driverPriorityToString(DriverPriority priority);
    static const char* driverResultToString(DriverResult result);
    static const char* deviceBusToString(DeviceBus bus);

private:
    bool initialized_ = false;
    bool hotplugEnabled_ = true;

    std::vector<DriverInfo> drivers_;
    std::vector<DeviceInfo> devices_;
    std::vector<DriverEvent> events_;
    uint32_t nextDriverId_ = 1;
    uint32_t nextDeviceId_ = 1;
    uint32_t nextEventId_ = 1;

    std::vector<DriverInfo> defaultDrivers_;
    std::vector<DeviceInfo> defaultDevices_;

    std::function<void(const DriverEvent&)> eventCb_;

    // Helpers
    DriverInfo* findDriver(const std::string& name);
    const DriverInfo* findDriver(const std::string& name) const;
    DriverInfo* findDriverById(uint32_t id);
    const DriverInfo* findDriverById(uint32_t id) const;
    DeviceInfo* findDevice(const std::string& name);
    const DeviceInfo* findDevice(const std::string& name) const;
    DeviceInfo* findDeviceById(uint32_t id);
    const DeviceInfo* findDeviceById(uint32_t id) const;

    void setDriverState(DriverInfo& driver, DriverState state);
    void setDeviceStatus(DeviceInfo& device, DeviceStatus status);
    void logEvent(const std::string& message, uint32_t driverId, uint32_t deviceId,
                  DriverState driverState, DeviceStatus deviceStatus, bool isError = false);
    bool checkDriverDependencies(const std::string& name) const;
    bool areDependenciesLoaded(const std::string& name) const;
    void buildDefaultDrivers();
    void buildDefaultDevices();
    uint64_t getCurrentTimeMs() const;
};

}  // namespace phantom::drivers
