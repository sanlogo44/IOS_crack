/*
 * Phantom OS - Device Driver Framework Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/drivers/driver_manager.h"
#include <algorithm>
#include <unordered_set>

namespace phantom::drivers {

// ============================================================
// String Helpers
// ============================================================

const char* DriverManager::driverTypeToString(DriverType type) {
    switch (type) {
        case DriverType::DISPLAY: return "DISPLAY";
        case DriverType::INPUT: return "INPUT";
        case DriverType::STORAGE: return "STORAGE";
        case DriverType::NETWORK: return "NETWORK";
        case DriverType::AUDIO: return "AUDIO";
        case DriverType::CAMERA: return "CAMERA";
        case DriverType::POWER: return "POWER";
        case DriverType::BLUETOOTH: return "BLUETOOTH";
        case DriverType::SENSOR: return "SENSOR";
        case DriverType::USB: return "USB";
        case DriverType::GPU: return "GPU";
        case DriverType::THERMAL: return "THERMAL";
        default: return "UNKNOWN";
    }
}

const char* DriverManager::driverStateToString(DriverState state) {
    switch (state) {
        case DriverState::UNLOADED: return "UNLOADED";
        case DriverState::LOADING: return "LOADING";
        case DriverState::LOADED: return "LOADED";
        case DriverState::INITIALIZING: return "INITIALIZING";
        case DriverState::ACTIVE: return "ACTIVE";
        case DriverState::SUSPENDED: return "SUSPENDED";
        case DriverState::ERROR_STATE: return "ERROR_STATE";
        case DriverState::UNLOADING: return "UNLOADING";
        default: return "UNKNOWN";
    }
}

const char* DriverManager::deviceStatusToString(DeviceStatus status) {
    switch (status) {
        case DeviceStatus::ABSENT: return "ABSENT";
        case DeviceStatus::DETECTED: return "DETECTED";
        case DeviceStatus::READY: return "READY";
        case DeviceStatus::ACTIVE: return "ACTIVE";
        case DeviceStatus::SUSPENDED: return "SUSPENDED";
        case DeviceStatus::ERROR_STATE: return "ERROR_STATE";
        case DeviceStatus::REMOVED: return "REMOVED";
        default: return "UNKNOWN";
    }
}

const char* DriverManager::driverPriorityToString(DriverPriority priority) {
    switch (priority) {
        case DriverPriority::CRITICAL: return "CRITICAL";
        case DriverPriority::HIGH: return "HIGH";
        case DriverPriority::NORMAL: return "NORMAL";
        case DriverPriority::LOW: return "LOW";
        case DriverPriority::OPTIONAL: return "OPTIONAL";
        default: return "UNKNOWN";
    }
}

const char* DriverManager::driverResultToString(DriverResult result) {
    switch (result) {
        case DriverResult::SUCCESS: return "SUCCESS";
        case DriverResult::ALREADY_LOADED: return "ALREADY_LOADED";
        case DriverResult::NOT_FOUND: return "NOT_FOUND";
        case DriverResult::ALREADY_ACTIVE: return "ALREADY_ACTIVE";
        case DriverResult::INVALID_STATE: return "INVALID_STATE";
        case DriverResult::INIT_FAILED: return "INIT_FAILED";
        case DriverResult::LOAD_FAILED: return "LOAD_FAILED";
        case DriverResult::DEVICE_NOT_FOUND: return "DEVICE_NOT_FOUND";
        case DriverResult::DEPENDENCY_FAILED: return "DEPENDENCY_FAILED";
        case DriverResult::TIMEOUT: return "TIMEOUT";
        case DriverResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case DriverResult::UNSUPPORTED: return "UNSUPPORTED";
        default: return "UNKNOWN";
    }
}

const char* DriverManager::deviceBusToString(DeviceBus bus) {
    switch (bus) {
        case DeviceBus::INTERNAL: return "INTERNAL";
        case DeviceBus::PCIE: return "PCIE";
        case DeviceBus::I2C: return "I2C";
        case DeviceBus::SPI: return "SPI";
        case DeviceBus::UART: return "UART";
        case DeviceBus::USB: return "USB";
        case DeviceBus::SDIO: return "SDIO";
        case DeviceBus::VIRTUAL: return "VIRTUAL";
        default: return "UNKNOWN";
    }
}

// ============================================================
// Lifecycle
// ============================================================

DriverResult DriverManager::initialize() {
    if (initialized_) return DriverResult::ALREADY_LOADED;

    drivers_.clear();
    devices_.clear();
    events_.clear();
    nextDriverId_ = 1;
    nextDeviceId_ = 1;
    nextEventId_ = 1;

    buildDefaultDrivers();
    buildDefaultDevices();
    registerDefaultDrivers();
    registerDefaultDevices();

    initialized_ = true;
    logEvent("Driver manager initialized", 0, 0, DriverState::UNLOADED, DeviceStatus::ABSENT);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::shutdown() {
    if (!initialized_) return DriverResult::SUCCESS;

    // Unload all drivers in reverse order
    auto order = getLoadOrder();
    std::reverse(order.begin(), order.end());
    for (const auto& name : order) {
        unloadDriver(name);
    }

    drivers_.clear();
    devices_.clear();
    events_.clear();
    defaultDrivers_.clear();
    defaultDevices_.clear();
    nextDriverId_ = 1;
    nextDeviceId_ = 1;
    nextEventId_ = 1;
    eventCb_ = nullptr;

    initialized_ = false;
    return DriverResult::SUCCESS;
}

DriverState DriverManager::getDriverState(const std::string& name) const {
    const auto* d = findDriver(name);
    if (!d) return DriverState::UNLOADED;
    return d->state;
}

// ============================================================
// Driver Registration
// ============================================================

uint32_t DriverManager::registerDriver(const DriverInfo& driver) {
    if (findDriver(driver.name) != nullptr) return 0;

    DriverInfo d = driver;
    d.id = nextDriverId_++;
    d.state = DriverState::UNLOADED;
    drivers_.push_back(d);
    return d.id;
}

bool DriverManager::unregisterDriver(const std::string& name) {
    auto it = std::find_if(drivers_.begin(), drivers_.end(),
                           [&name](const DriverInfo& d) { return d.name == name; });
    if (it == drivers_.end()) return false;
    drivers_.erase(it);
    return true;
}

DriverInfo DriverManager::getDriver(const std::string& name) const {
    const auto* d = findDriver(name);
    if (d) return *d;
    return DriverInfo{};
}

DriverInfo DriverManager::getDriverById(uint32_t id) const {
    const auto* d = findDriverById(id);
    if (d) return *d;
    return DriverInfo{};
}

std::vector<DriverInfo> DriverManager::getDrivers() const {
    return drivers_;
}

std::vector<DriverInfo> DriverManager::getDriversByType(DriverType type) const {
    std::vector<DriverInfo> result;
    for (const auto& d : drivers_) {
        if (d.type == type) result.push_back(d);
    }
    return result;
}

std::vector<DriverInfo> DriverManager::getDriversByState(DriverState state) const {
    std::vector<DriverInfo> result;
    for (const auto& d : drivers_) {
        if (d.state == state) result.push_back(d);
    }
    return result;
}

std::vector<DriverInfo> DriverManager::getDriversByPriority(DriverPriority priority) const {
    std::vector<DriverInfo> result;
    for (const auto& d : drivers_) {
        if (d.priority == priority) result.push_back(d);
    }
    return result;
}

size_t DriverManager::getDriverCount() const {
    return drivers_.size();
}

size_t DriverManager::getLoadedDriverCount() const {
    size_t count = 0;
    for (const auto& d : drivers_) {
        if (d.state != DriverState::UNLOADED) count++;
    }
    return count;
}

size_t DriverManager::getActiveDriverCount() const {
    size_t count = 0;
    for (const auto& d : drivers_) {
        if (d.state == DriverState::ACTIVE) count++;
    }
    return count;
}

// ============================================================
// Driver Lifecycle
// ============================================================

DriverResult DriverManager::loadDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    if (d->state != DriverState::UNLOADED) return DriverResult::ALREADY_LOADED;

    if (!areDependenciesLoaded(name)) {
        setDriverState(*d, DriverState::ERROR_STATE);
        d->errorCount++;
        d->lastError = "Dependency not loaded";
        logEvent("Driver load failed (dependency): " + name, d->id, 0, DriverState::ERROR_STATE, DeviceStatus::ABSENT, true);
        return DriverResult::DEPENDENCY_FAILED;
    }

    setDriverState(*d, DriverState::LOADING);
    d->loadTime = getCurrentTimeMs();
    setDriverState(*d, DriverState::LOADED);

    logEvent("Driver loaded: " + name, d->id, 0, DriverState::LOADED, DeviceStatus::ABSENT);

    if (d->autoInit) {
        return initDriver(name);
    }

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::unloadDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    if (d->state == DriverState::UNLOADED) return DriverResult::SUCCESS;

    setDriverState(*d, DriverState::UNLOADING);

    // Unbind all devices bound to this driver
    for (auto& dev : devices_) {
        if (dev.driverId == d->id) {
            dev.driverId = 0;
            dev.driverName.clear();
            setDeviceStatus(dev, DeviceStatus::DETECTED);
        }
    }
    d->boundDevices.clear();

    setDriverState(*d, DriverState::UNLOADED);
    logEvent("Driver unloaded: " + name, d->id, 0, DriverState::UNLOADED, DeviceStatus::ABSENT);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::initDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    if (d->state == DriverState::ACTIVE) return DriverResult::ALREADY_ACTIVE;
    if (d->state != DriverState::LOADED && d->state != DriverState::SUSPENDED) {
        return DriverResult::INVALID_STATE;
    }

    setDriverState(*d, DriverState::INITIALIZING);
    setDriverState(*d, DriverState::ACTIVE);

    logEvent("Driver initialized: " + name, d->id, 0, DriverState::ACTIVE, DeviceStatus::ABSENT);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::suspendDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    if (d->state != DriverState::ACTIVE) return DriverResult::INVALID_STATE;

    setDriverState(*d, DriverState::SUSPENDED);
    logEvent("Driver suspended: " + name, d->id, 0, DriverState::SUSPENDED, DeviceStatus::ABSENT);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::resumeDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    if (d->state != DriverState::SUSPENDED) return DriverResult::INVALID_STATE;

    setDriverState(*d, DriverState::ACTIVE);
    logEvent("Driver resumed: " + name, d->id, 0, DriverState::ACTIVE, DeviceStatus::ABSENT);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::reloadDriver(const std::string& name) {
    DriverInfo* d = findDriver(name);
    if (!d) return DriverResult::NOT_FOUND;

    unloadDriver(name);
    return loadDriver(name);
}

// ============================================================
// Device Management
// ============================================================

uint32_t DriverManager::registerDevice(const DeviceInfo& device) {
    if (findDevice(device.name) != nullptr) return 0;

    DeviceInfo dev = device;
    dev.id = nextDeviceId_++;
    if (dev.status == DeviceStatus::ABSENT) {
        dev.status = DeviceStatus::DETECTED;
    }
    dev.detectedTime = getCurrentTimeMs();
    devices_.push_back(dev);
    return dev.id;
}

bool DriverManager::unregisterDevice(const std::string& name) {
    auto it = std::find_if(devices_.begin(), devices_.end(),
                           [&name](const DeviceInfo& d) { return d.name == name; });
    if (it == devices_.end()) return false;
    devices_.erase(it);
    return true;
}

DeviceInfo DriverManager::getDevice(const std::string& name) const {
    const auto* d = findDevice(name);
    if (d) return *d;
    return DeviceInfo{};
}

DeviceInfo DriverManager::getDeviceById(uint32_t id) const {
    const auto* d = findDeviceById(id);
    if (d) return *d;
    return DeviceInfo{};
}

std::vector<DeviceInfo> DriverManager::getDevices() const {
    return devices_;
}

std::vector<DeviceInfo> DriverManager::getDevicesByType(DriverType type) const {
    std::vector<DeviceInfo> result;
    for (const auto& d : devices_) {
        if (d.type == type) result.push_back(d);
    }
    return result;
}

std::vector<DeviceInfo> DriverManager::getDevicesByStatus(DeviceStatus status) const {
    std::vector<DeviceInfo> result;
    for (const auto& d : devices_) {
        if (d.status == status) result.push_back(d);
    }
    return result;
}

std::vector<DeviceInfo> DriverManager::getDevicesByBus(DeviceBus bus) const {
    std::vector<DeviceInfo> result;
    for (const auto& d : devices_) {
        if (d.bus == bus) result.push_back(d);
    }
    return result;
}

size_t DriverManager::getDeviceCount() const {
    return devices_.size();
}

size_t DriverManager::getActiveDeviceCount() const {
    size_t count = 0;
    for (const auto& d : devices_) {
        if (d.status == DeviceStatus::ACTIVE) count++;
    }
    return count;
}

// ============================================================
// Device Lifecycle
// ============================================================

DriverResult DriverManager::bindDevice(const std::string& deviceName, const std::string& driverName) {
    DeviceInfo* dev = findDevice(deviceName);
    if (!dev) return DriverResult::DEVICE_NOT_FOUND;

    DriverInfo* drv = findDriver(driverName);
    if (!drv) return DriverResult::NOT_FOUND;

    if (drv->state == DriverState::UNLOADED) return DriverResult::INVALID_STATE;

    dev->driverId = drv->id;
    dev->driverName = driverName;
    setDeviceStatus(*dev, DeviceStatus::READY);

    if (std::find(drv->boundDevices.begin(), drv->boundDevices.end(), dev->id) == drv->boundDevices.end()) {
        drv->boundDevices.push_back(dev->id);
    }

    logEvent("Device bound: " + deviceName + " -> " + driverName, drv->id, dev->id, drv->state, dev->status);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::unbindDevice(const std::string& deviceName) {
    DeviceInfo* dev = findDevice(deviceName);
    if (!dev) return DriverResult::DEVICE_NOT_FOUND;

    if (dev->driverId != 0) {
        DriverInfo* drv = findDriverById(dev->driverId);
        if (drv) {
            auto it = std::find(drv->boundDevices.begin(), drv->boundDevices.end(), dev->id);
            if (it != drv->boundDevices.end()) drv->boundDevices.erase(it);
        }
    }

    dev->driverId = 0;
    dev->driverName.clear();
    setDeviceStatus(*dev, DeviceStatus::DETECTED);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::activateDevice(const std::string& name) {
    DeviceInfo* dev = findDevice(name);
    if (!dev) return DriverResult::DEVICE_NOT_FOUND;

    if (dev->driverId == 0) return DriverResult::DEPENDENCY_FAILED;

    DriverInfo* drv = findDriverById(dev->driverId);
    if (!drv || drv->state != DriverState::ACTIVE) return DriverResult::INVALID_STATE;

    setDeviceStatus(*dev, DeviceStatus::ACTIVE);
    dev->activeTime = getCurrentTimeMs();

    logEvent("Device activated: " + name, drv->id, dev->id, drv->state, dev->status);

    return DriverResult::SUCCESS;
}

DriverResult DriverManager::suspendDevice(const std::string& name) {
    DeviceInfo* dev = findDevice(name);
    if (!dev) return DriverResult::DEVICE_NOT_FOUND;

    if (dev->status != DeviceStatus::ACTIVE) return DriverResult::INVALID_STATE;

    setDeviceStatus(*dev, DeviceStatus::SUSPENDED);
    return DriverResult::SUCCESS;
}

DriverResult DriverManager::removeDevice(const std::string& name) {
    DeviceInfo* dev = findDevice(name);
    if (!dev) return DriverResult::DEVICE_NOT_FOUND;

    if (!dev->removable) return DriverResult::PERMISSION_DENIED;

    unbindDevice(name);
    setDeviceStatus(*dev, DeviceStatus::REMOVED);

    logEvent("Device removed: " + name, 0, dev->id, DriverState::UNLOADED, dev->status);

    return DriverResult::SUCCESS;
}

// ============================================================
// Device Discovery
// ============================================================

void DriverManager::discoverDevices() {
    for (auto& dev : devices_) {
        if (dev.status == DeviceStatus::ABSENT) {
            setDeviceStatus(dev, DeviceStatus::DETECTED);
            dev.detectedTime = getCurrentTimeMs();
            logEvent("Device discovered: " + dev.name, 0, dev.id, DriverState::UNLOADED, dev.status);
        }
    }
}

std::vector<DeviceInfo> DriverManager::detectHotplug() const {
    std::vector<DeviceInfo> result;
    for (const auto& d : devices_) {
        if (d.hotplug) result.push_back(d);
    }
    return result;
}

// ============================================================
// Dependency Resolution
// ============================================================

std::vector<std::string> DriverManager::resolveDriverDependencies(const std::string& name) const {
    std::vector<std::string> result;
    std::unordered_set<std::string> visited;

    std::function<void(const std::string&)> visit = [&](const std::string& n) {
        if (visited.count(n)) return;
        visited.insert(n);
        const auto* d = findDriver(n);
        if (!d) return;
        for (const auto& dep : d->dependencies) {
            visit(dep);
        }
        result.push_back(n);
    };

    visit(name);
    return result;
}

bool DriverManager::hasCircularDependency(const std::string& name) const {
    std::unordered_set<std::string> visiting;
    std::unordered_set<std::string> visited;

    std::function<bool(const std::string&)> visit = [&](const std::string& n) -> bool {
        if (visiting.count(n)) return true;
        if (visited.count(n)) return false;

        visiting.insert(n);
        const auto* d = findDriver(n);
        if (d) {
            for (const auto& dep : d->dependencies) {
                if (visit(dep)) return true;
            }
        }
        visiting.erase(n);
        visited.insert(n);
        return false;
    };

    return visit(name);
}

std::vector<std::string> DriverManager::getLoadOrder() const {
    std::vector<std::string> result;
    std::unordered_set<std::string> visited;
    std::unordered_set<std::string> visiting;

    std::vector<DriverInfo> sorted = drivers_;
    std::sort(sorted.begin(), sorted.end(), [](const DriverInfo& a, const DriverInfo& b) {
        return a.initOrder < b.initOrder;
    });

    std::function<void(const std::string&)> visit = [&](const std::string& name) {
        if (visited.count(name) || visiting.count(name)) return;
        visiting.insert(name);
        const auto* d = findDriver(name);
        if (d) {
            for (const auto& dep : d->dependencies) {
                visit(dep);
            }
        }
        visiting.erase(name);
        visited.insert(name);
        result.push_back(name);
    };

    for (const auto& d : sorted) {
        visit(d.name);
    }

    return result;
}

// ============================================================
// Error Handling
// ============================================================

std::string DriverManager::getLastError(const std::string& driverName) const {
    const auto* d = findDriver(driverName);
    if (d) return d->lastError;
    return "";
}

uint32_t DriverManager::getErrorCount(const std::string& driverName) const {
    const auto* d = findDriver(driverName);
    if (d) return d->errorCount;
    return 0;
}

void DriverManager::clearErrors(const std::string& driverName) {
    DriverInfo* d = findDriver(driverName);
    if (d) {
        d->errorCount = 0;
        d->lastError.clear();
    }
}

void DriverManager::setError(const std::string& driverName, const std::string& error) {
    DriverInfo* d = findDriver(driverName);
    if (d) {
        d->errorCount++;
        d->lastError = error;
        setDriverState(*d, DriverState::ERROR_STATE);
        logEvent("Driver error: " + driverName + " - " + error, d->id, 0, DriverState::ERROR_STATE, DeviceStatus::ABSENT, true);
    }
}

// ============================================================
// Events
// ============================================================

std::vector<DriverEvent> DriverManager::getEvents() const {
    return events_;
}

size_t DriverManager::getEventCount() const {
    return events_.size();
}

void DriverManager::clearEvents() {
    events_.clear();
}

// ============================================================
// Stats
// ============================================================

DriverStats DriverManager::getStats() const {
    DriverStats stats;
    stats.totalDrivers = static_cast<uint32_t>(drivers_.size());
    stats.totalDevices = static_cast<uint32_t>(devices_.size());

    for (const auto& d : drivers_) {
        if (d.state != DriverState::UNLOADED) stats.loadedDrivers++;
        if (d.state == DriverState::ACTIVE) stats.activeDrivers++;
        if (d.state == DriverState::ERROR_STATE) stats.errorDrivers++;
        stats.totalErrors += d.errorCount;
        if (d.state == DriverState::ACTIVE && d.loadTime > 0) {
            stats.totalUptime += (getCurrentTimeMs() - d.loadTime);
        }
    }

    for (const auto& d : devices_) {
        if (d.status == DeviceStatus::ACTIVE) stats.activeDevices++;
        if (d.status == DeviceStatus::ERROR_STATE) stats.errorDevices++;
    }

    return stats;
}

void DriverManager::resetStats() {
    for (auto& d : drivers_) {
        d.errorCount = 0;
    }
}

// ============================================================
// Default Drivers and Devices
// ============================================================

void DriverManager::buildDefaultDrivers() {
    defaultDrivers_.clear();

    DriverInfo display;
    display.name = "display_driver";
    display.description = "OLED display driver (A11 SoC)";
    display.version = "1.0.0";
    display.author = "Phantom OS Team";
    display.type = DriverType::DISPLAY;
    display.priority = DriverPriority::CRITICAL;
    display.initOrder = 0;
    display.supportedDevices = {"oled_display"};
    display.path = "/system/drivers/display.ko";
    defaultDrivers_.push_back(display);

    DriverInfo power;
    power.name = "power_driver";
    power.description = "Battery and power management driver";
    power.version = "1.0.0";
    power.type = DriverType::POWER;
    power.priority = DriverPriority::CRITICAL;
    power.initOrder = 1;
    power.supportedDevices = {"battery", "charger"};
    power.path = "/system/drivers/power.ko";
    defaultDrivers_.push_back(power);

    DriverInfo input;
    input.name = "input_driver";
    input.description = "Touchscreen input driver";
    input.version = "1.0.0";
    input.type = DriverType::INPUT;
    input.priority = DriverPriority::HIGH;
    input.initOrder = 5;
    input.dependencies = {"display_driver"};
    input.supportedDevices = {"touchscreen"};
    input.path = "/system/drivers/input.ko";
    defaultDrivers_.push_back(input);

    DriverInfo storage;
    storage.name = "storage_driver";
    storage.description = "NVMe storage driver";
    storage.version = "1.0.0";
    storage.type = DriverType::STORAGE;
    storage.priority = DriverPriority::HIGH;
    storage.initOrder = 10;
    storage.supportedDevices = {"nvme_storage"};
    storage.path = "/system/drivers/storage.ko";
    defaultDrivers_.push_back(storage);

    DriverInfo gpu;
    gpu.name = "gpu_driver";
    gpu.description = "GPU driver (Apple A11 GPU)";
    gpu.version = "1.0.0";
    gpu.type = DriverType::GPU;
    gpu.priority = DriverPriority::HIGH;
    gpu.initOrder = 15;
    gpu.dependencies = {"display_driver"};
    gpu.supportedDevices = {"gpu"};
    gpu.path = "/system/drivers/gpu.ko";
    defaultDrivers_.push_back(gpu);

    DriverInfo network;
    network.name = "network_driver";
    network.description = "Wi-Fi 6 network driver";
    network.version = "1.0.0";
    network.type = DriverType::NETWORK;
    network.priority = DriverPriority::NORMAL;
    network.initOrder = 20;
    network.supportedDevices = {"wifi_adapter"};
    network.path = "/system/drivers/network.ko";
    defaultDrivers_.push_back(network);

    DriverInfo bluetooth;
    bluetooth.name = "bluetooth_driver";
    bluetooth.description = "Bluetooth 5.0 driver";
    bluetooth.version = "1.0.0";
    bluetooth.type = DriverType::BLUETOOTH;
    bluetooth.priority = DriverPriority::NORMAL;
    bluetooth.initOrder = 25;
    bluetooth.supportedDevices = {"bluetooth_adapter"};
    bluetooth.path = "/system/drivers/bluetooth.ko";
    defaultDrivers_.push_back(bluetooth);

    DriverInfo audio;
    audio.name = "audio_driver";
    audio.description = "Audio codec driver";
    audio.version = "1.0.0";
    audio.type = DriverType::AUDIO;
    audio.priority = DriverPriority::NORMAL;
    audio.initOrder = 30;
    audio.supportedDevices = {"speaker", "microphone"};
    audio.path = "/system/drivers/audio.ko";
    defaultDrivers_.push_back(audio);

    DriverInfo camera;
    camera.name = "camera_driver";
    camera.description = "Dual camera sensor driver";
    camera.version = "1.0.0";
    camera.type = DriverType::CAMERA;
    camera.priority = DriverPriority::LOW;
    camera.initOrder = 40;
    camera.dependencies = {"gpu_driver"};
    camera.supportedDevices = {"front_camera", "rear_camera"};
    camera.path = "/system/drivers/camera.ko";
    defaultDrivers_.push_back(camera);

    DriverInfo sensor;
    sensor.name = "sensor_driver";
    sensor.description = "Motion sensor driver (accelerometer, gyroscope)";
    sensor.version = "1.0.0";
    sensor.type = DriverType::SENSOR;
    sensor.priority = DriverPriority::LOW;
    sensor.initOrder = 45;
    sensor.supportedDevices = {"accelerometer", "gyroscope", "proximity_sensor"};
    sensor.path = "/system/drivers/sensor.ko";
    defaultDrivers_.push_back(sensor);

    DriverInfo usb;
    usb.name = "usb_driver";
    usb.description = "USB-C controller driver";
    usb.version = "1.0.0";
    usb.type = DriverType::USB;
    usb.priority = DriverPriority::NORMAL;
    usb.initOrder = 35;
    usb.supportedDevices = {"usb_controller"};
    usb.path = "/system/drivers/usb.ko";
    defaultDrivers_.push_back(usb);

    DriverInfo thermal;
    thermal.name = "thermal_driver";
    thermal.description = "Thermal management driver";
    thermal.version = "1.0.0";
    thermal.type = DriverType::THERMAL;
    thermal.priority = DriverPriority::OPTIONAL;
    thermal.initOrder = 50;
    thermal.supportedDevices = {"thermal_sensor"};
    thermal.path = "/system/drivers/thermal.ko";
    defaultDrivers_.push_back(thermal);
}

void DriverManager::buildDefaultDevices() {
    defaultDevices_.clear();

    DeviceInfo oled;
    oled.name = "oled_display";
    oled.description = "2436x1125 OLED display";
    oled.vendor = "Apple";
    oled.model = "A11 OLED";
    oled.type = DriverType::DISPLAY;
    oled.bus = DeviceBus::INTERNAL;
    oled.capabilities = {"2436x1125", "458dpi", "hdr"};
    defaultDevices_.push_back(oled);

    DeviceInfo battery;
    battery.name = "battery";
    battery.description = "Lithium-ion battery";
    battery.vendor = "Apple";
    battery.type = DriverType::POWER;
    battery.bus = DeviceBus::I2C;
    battery.capabilities = {"fast_charge", "wireless_charge"};
    defaultDevices_.push_back(battery);

    DeviceInfo charger;
    charger.name = "charger";
    charger.description = "Charging controller";
    charger.type = DriverType::POWER;
    charger.bus = DeviceBus::I2C;
    defaultDevices_.push_back(charger);

    DeviceInfo touchscreen;
    touchscreen.name = "touchscreen";
    touchscreen.description = "Multi-touch capacitive touchscreen";
    touchscreen.vendor = "Apple";
    touchscreen.type = DriverType::INPUT;
    touchscreen.bus = DeviceBus::SPI;
    touchscreen.capabilities = {"multitouch", "pressure_sensitive"};
    defaultDevices_.push_back(touchscreen);

    DeviceInfo nvme;
    nvme.name = "nvme_storage";
    nvme.description = "64GB NVMe storage";
    nvme.vendor = "Apple";
    nvme.type = DriverType::STORAGE;
    nvme.bus = DeviceBus::PCIE;
    nvme.capabilities = {"encrypted", "64gb"};
    defaultDevices_.push_back(nvme);

    DeviceInfo gpu;
    gpu.name = "gpu";
    gpu.description = "Apple A11 GPU (3-core)";
    gpu.vendor = "Apple";
    gpu.type = DriverType::GPU;
    gpu.bus = DeviceBus::INTERNAL;
    defaultDevices_.push_back(gpu);

    DeviceInfo wifi;
    wifi.name = "wifi_adapter";
    wifi.description = "Wi-Fi 6 (802.11ax) adapter";
    wifi.type = DriverType::NETWORK;
    wifi.bus = DeviceBus::SDIO;
    wifi.hotplug = false;
    defaultDevices_.push_back(wifi);

    DeviceInfo bt;
    bt.name = "bluetooth_adapter";
    bt.description = "Bluetooth 5.0 adapter";
    bt.type = DriverType::BLUETOOTH;
    bt.bus = DeviceBus::UART;
    defaultDevices_.push_back(bt);

    DeviceInfo speaker;
    speaker.name = "speaker";
    speaker.description = "Stereo speaker";
    speaker.type = DriverType::AUDIO;
    speaker.bus = DeviceBus::I2C;
    defaultDevices_.push_back(speaker);

    DeviceInfo mic;
    mic.name = "microphone";
    mic.description = "Dual microphone array";
    mic.type = DriverType::AUDIO;
    mic.bus = DeviceBus::I2C;
    defaultDevices_.push_back(mic);

    DeviceInfo frontCam;
    frontCam.name = "front_camera";
    frontCam.description = "7MP TrueDepth front camera";
    frontCam.type = DriverType::CAMERA;
    frontCam.bus = DeviceBus::I2C;
    defaultDevices_.push_back(frontCam);

    DeviceInfo rearCam;
    rearCam.name = "rear_camera";
    rearCam.description = "Dual 12MP rear camera";
    rearCam.type = DriverType::CAMERA;
    rearCam.bus = DeviceBus::I2C;
    defaultDevices_.push_back(rearCam);

    DeviceInfo accel;
    accel.name = "accelerometer";
    accel.description = "3-axis accelerometer";
    accel.type = DriverType::SENSOR;
    accel.bus = DeviceBus::I2C;
    defaultDevices_.push_back(accel);

    DeviceInfo gyro;
    gyro.name = "gyroscope";
    gyro.description = "3-axis gyroscope";
    gyro.type = DriverType::SENSOR;
    gyro.bus = DeviceBus::I2C;
    defaultDevices_.push_back(gyro);

    DeviceInfo prox;
    prox.name = "proximity_sensor";
    prox.description = "Proximity sensor";
    prox.type = DriverType::SENSOR;
    prox.bus = DeviceBus::I2C;
    defaultDevices_.push_back(prox);

    DeviceInfo usbc;
    usbc.name = "usb_controller";
    usbc.description = "USB-C / Lightning controller";
    usbc.type = DriverType::USB;
    usbc.bus = DeviceBus::USB;
    usbc.hotplug = true;
    usbc.removable = true;
    defaultDevices_.push_back(usbc);

    DeviceInfo thermalSensor;
    thermalSensor.name = "thermal_sensor";
    thermalSensor.description = "SoC thermal sensor";
    thermalSensor.type = DriverType::THERMAL;
    thermalSensor.bus = DeviceBus::INTERNAL;
    defaultDevices_.push_back(thermalSensor);
}

void DriverManager::registerDefaultDrivers() {
    for (const auto& d : defaultDrivers_) {
        registerDriver(d);
    }
}

void DriverManager::registerDefaultDevices() {
    for (const auto& d : defaultDevices_) {
        registerDevice(d);
    }
}

// ============================================================
// Private Helpers
// ============================================================

DriverInfo* DriverManager::findDriver(const std::string& name) {
    for (auto& d : drivers_) {
        if (d.name == name) return &d;
    }
    return nullptr;
}

const DriverInfo* DriverManager::findDriver(const std::string& name) const {
    for (const auto& d : drivers_) {
        if (d.name == name) return &d;
    }
    return nullptr;
}

DriverInfo* DriverManager::findDriverById(uint32_t id) {
    for (auto& d : drivers_) {
        if (d.id == id) return &d;
    }
    return nullptr;
}

const DriverInfo* DriverManager::findDriverById(uint32_t id) const {
    for (const auto& d : drivers_) {
        if (d.id == id) return &d;
    }
    return nullptr;
}

DeviceInfo* DriverManager::findDevice(const std::string& name) {
    for (auto& d : devices_) {
        if (d.name == name) return &d;
    }
    return nullptr;
}

const DeviceInfo* DriverManager::findDevice(const std::string& name) const {
    for (const auto& d : devices_) {
        if (d.name == name) return &d;
    }
    return nullptr;
}

DeviceInfo* DriverManager::findDeviceById(uint32_t id) {
    for (auto& d : devices_) {
        if (d.id == id) return &d;
    }
    return nullptr;
}

const DeviceInfo* DriverManager::findDeviceById(uint32_t id) const {
    for (const auto& d : devices_) {
        if (d.id == id) return &d;
    }
    return nullptr;
}

void DriverManager::setDriverState(DriverInfo& driver, DriverState state) {
    driver.state = state;
}

void DriverManager::setDeviceStatus(DeviceInfo& device, DeviceStatus status) {
    device.status = status;
}

void DriverManager::logEvent(const std::string& message, uint32_t driverId, uint32_t deviceId,
                              DriverState driverState, DeviceStatus deviceStatus, bool isError) {
    DriverEvent event;
    event.id = nextEventId_++;
    event.message = message;
    event.driverId = driverId;
    event.deviceId = deviceId;
    event.driverState = driverState;
    event.deviceStatus = deviceStatus;
    event.timestamp = getCurrentTimeMs();
    event.isError = isError;
    events_.push_back(event);

    if (eventCb_) eventCb_(event);
}

bool DriverManager::checkDriverDependencies(const std::string& name) const {
    const auto* d = findDriver(name);
    if (!d) return false;
    for (const auto& dep : d->dependencies) {
        if (findDriver(dep) == nullptr) return false;
    }
    return true;
}

bool DriverManager::areDependenciesLoaded(const std::string& name) const {
    const auto* d = findDriver(name);
    if (!d) return false;

    for (const auto& dep : d->dependencies) {
        const auto* depDriver = findDriver(dep);
        if (!depDriver) return false;
        if (depDriver->state == DriverState::UNLOADED || depDriver->state == DriverState::ERROR_STATE) {
            return false;
        }
    }
    return true;
}

uint64_t DriverManager::getCurrentTimeMs() const {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

}  // namespace phantom::drivers
