/*
 * Phantom OS - Permission Manager Tests
 * Tests for the central permission manager
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/permission_manager.h"
#include <cassert>
#include <cstdio>

using namespace phantom::privacy;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

bool test_register_and_check() {
    TEST("Register app and check default deny");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appA");

    auto result = pm.checkPermission("com.test.appA", Permission::CAMERA);
    ASSERT(result == PermissionCheckResult::NOT_REQUESTED || result == PermissionCheckResult::DENIED,
           "New app should have denied or not-requested permissions");
    PASS();
    return true;
}

bool test_grant_and_check() {
    TEST("Grant permission and verify");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appB");
    pm.grantPermission("com.test.appB", Permission::CAMERA, GrantType::ALLOW_WHILE_USING);

    auto result = pm.checkPermission("com.test.appB", Permission::CAMERA);
    ASSERT(result == PermissionCheckResult::GRANTED, "Camera should be granted");
    PASS();
    return true;
}

bool test_revoke_permission() {
    TEST("Revoke permission");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appC");
    pm.grantPermission("com.test.appC", Permission::LOCATION, GrantType::ALLOW_ALWAYS,
                        LocationAccuracy::PRECISE);
    pm.revokePermission("com.test.appC", Permission::LOCATION);

    auto result = pm.checkPermission("com.test.appC", Permission::LOCATION);
    ASSERT(result == PermissionCheckResult::DENIED, "Location should be denied after revoke");
    PASS();
    return true;
}

bool test_revoke_all() {
    TEST("Revoke all permissions for app");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appD");
    pm.grantPermission("com.test.appD", Permission::CAMERA, GrantType::ALLOW_ALWAYS);
    pm.grantPermission("com.test.appD", Permission::MICROPHONE, GrantType::ALLOW_ALWAYS);
    pm.grantPermission("com.test.appD", Permission::LOCATION, GrantType::ALLOW_ALWAYS);

    pm.revokeAllPermissions("com.test.appD");

    ASSERT(pm.checkPermission("com.test.appD", Permission::CAMERA) != PermissionCheckResult::GRANTED,
           "Camera should not be granted after revoke all");
    ASSERT(pm.checkPermission("com.test.appD", Permission::MICROPHONE) != PermissionCheckResult::GRANTED,
           "Mic should not be granted after revoke all");
    PASS();
    return true;
}

bool test_privacy_profile_max() {
    TEST("Maximum Privacy profile restricts location");
    auto& pm = PermissionManager::getInstance();
    pm.setPrivacyProfile(PrivacyProfile::MAXIMUM_PRIVACY);
    pm.registerApp("com.test.appE");
    pm.grantPermission("com.test.appE", Permission::LOCATION, GrantType::ALLOW_ALWAYS,
                        LocationAccuracy::PRECISE);

    LocationAccuracy acc = pm.getEffectiveLocationAccuracy("com.test.appE");
    // In Maximum Privacy, location should be downgraded to CITY
    ASSERT(acc == LocationAccuracy::CITY, "Location should be downgraded to CITY in Max Privacy");
    PASS();

    // Reset profile
    pm.setPrivacyProfile(PrivacyProfile::NORMAL);
    return true;
}

bool test_privacy_profile_privacy() {
    TEST("Privacy profile restricts location to approximate");
    auto& pm = PermissionManager::getInstance();
    pm.setPrivacyProfile(PrivacyProfile::PRIVACY);
    pm.registerApp("com.test.appF");
    pm.grantPermission("com.test.appF", Permission::LOCATION, GrantType::ALLOW_ALWAYS,
                        LocationAccuracy::PRECISE);

    LocationAccuracy acc = pm.getEffectiveLocationAccuracy("com.test.appF");
    ASSERT(acc == LocationAccuracy::APPROXIMATE, "Location should be downgraded to APPROXIMATE in Privacy mode");
    PASS();

    pm.setPrivacyProfile(PrivacyProfile::NORMAL);
    return true;
}

bool test_access_log() {
    TEST("Access logging");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appG");
    pm.logAccess("com.test.appG", Permission::CAMERA, 5000, "Photo capture");

    auto log = pm.getAccessLogForApp("com.test.appG");
    ASSERT(!log.empty(), "Access log should not be empty");
    ASSERT(log.back().app_id == "com.test.appG", "Log entry should be for correct app");
    ASSERT(log.back().permission == Permission::CAMERA, "Log entry should be for CAMERA");
    PASS();
    return true;
}

bool test_get_app_permissions() {
    TEST("Get app permissions list");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appH");
    pm.grantPermission("com.test.appH", Permission::CAMERA, GrantType::ALLOW_ALWAYS);

    auto perms = pm.getAppPermissions("com.test.appH");
    ASSERT(perms.size() == static_cast<size_t>(Permission::PERMISSION_COUNT),
           "Should have all permissions listed");
    PASS();
    return true;
}

bool test_registered_apps() {
    TEST("Get registered apps list");
    auto& pm = PermissionManager::getInstance();
    pm.registerApp("com.test.appI");
    auto apps = pm.getRegisteredApps();
    bool found = false;
    for (const auto& a : apps) {
        if (a == "com.test.appI") found = true;
    }
    ASSERT(found, "Registered app should be in the list");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Permission Manager Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_register_and_check();
    all_pass &= test_grant_and_check();
    all_pass &= test_revoke_permission();
    all_pass &= test_revoke_all();
    all_pass &= test_privacy_profile_max();
    all_pass &= test_privacy_profile_privacy();
    all_pass &= test_access_log();
    all_pass &= test_get_app_permissions();
    all_pass &= test_registered_apps();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
