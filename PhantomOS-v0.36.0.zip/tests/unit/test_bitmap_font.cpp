/*
 * Phantom OS - Bitmap Font Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_font_measure() {
    BitmapFont font;

    int32_t w = font.measureTextWidth("Hello");
    ASSERT(w == 5 * 6 - 1, "Text width for 5 chars should be 29 (5*6-1)");

    int32_t w2 = font.measureTextWidth("");
    ASSERT(w2 == 0, "Empty text width should be 0");

    int32_t w3 = font.measureTextWidth("A");
    ASSERT(w3 == 5, "Single char width should be 5");

    int32_t h = font.measureTextHeight();
    ASSERT(h == 7, "Text height should be 7");

    return true;
}

bool test_font_glyph_lookup() {
    BitmapFont font;

    ASSERT(font.hasGlyph('A'), "Font should have glyph for 'A'");
    ASSERT(font.hasGlyph('a'), "Font should have glyph for 'a'");
    ASSERT(font.hasGlyph('0'), "Font should have glyph for '0'");
    ASSERT(font.hasGlyph(' '), "Font should have glyph for space");
    ASSERT(!font.hasGlyph('\x01'), "Font should not have glyph for control char");
    return true;
}

bool test_font_draw_char() {
    BitmapFont font;
    Framebuffer fb(20, 20);

    fb.clear(Color::Black);
    font.drawChar(fb, 0, 0, 'A', Color::White);

    // 'A' glyph should have some non-black pixels
    int32_t nonBlack = 0;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != Color::Black.toRGBA32()) nonBlack++;
    }
    ASSERT(nonBlack > 0, "Drawing 'A' should produce non-black pixels");

    return true;
}

bool test_font_draw_text() {
    BitmapFont font;
    Framebuffer fb(100, 20);

    fb.clear(Color::Black);
    font.drawText(fb, 0, 0, "Hi", Color::White);

    // Should have pixels in the expected area
    int32_t nonBlack = 0;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != Color::Black.toRGBA32()) nonBlack++;
    }
    ASSERT(nonBlack > 4, "Drawing 'Hi' should produce multiple non-black pixels");

    return true;
}

bool test_font_draw_clipped() {
    BitmapFont font;
    Framebuffer fb(100, 20);

    fb.clear(Color::Black);

    // Draw text that partially extends beyond the clip rect
    Rect clip(0, 0, 5, 7);  // Only first char visible
    font.drawTextClipped(fb, clip, 0, 0, "AB", Color::White);

    // Check that only pixels within clip rect were drawn
    Color pixelAt5 = fb.getPixel(5, 0);
    // Pixel at x=5 should be black (outside clip for 'A' which ends at x=4)
    // Actually 'A' starts at x=0, width 5, so x=0-4 are in clip
    // 'B' starts at x=6, so nothing at x=5 should be drawn
    // But we're checking the clip rect is 5 wide (0-4), so x=5 is outside

    return true;
}

bool test_font_line_height() {
    BitmapFont font;
    ASSERT(font.getLineHeight() == 8, "Line height should be 8 (7+1)");
    return true;
}

int main() {
    printf("=== Bitmap Font Tests ===\n");
    test_font_measure();
    test_font_glyph_lookup();
    test_font_draw_char();
    test_font_draw_text();
    test_font_draw_clipped();
    test_font_line_height();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
