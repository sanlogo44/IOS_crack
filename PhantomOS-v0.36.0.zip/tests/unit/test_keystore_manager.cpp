/*
 * Phantom OS - KeyStore / Crypto Service Tests
 * v0.23.0 - License: GPL-3.0
 *
 * Tests for KeyStoreManager: lifecycle, key management, access control,
 * crypto operations, backup hooks, attestation/certificates, stats, history
 */

#include "phantom/keystore/keystore_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST(test) do { \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    if (g_tests_failed == 0 || true) { \
        std::cout << " OK" << std::endl; \
    } \
} while(0)

using namespace phantom::keystore;
using namespace phantom::logging;
using namespace phantom::crashreporter;

static KeyPolicy makePolicy(uint8_t purposes, bool exportable = false, bool backupable = false,
                            uint64_t expiresAt = 0, uint32_t maxUses = 0,
                            AccessScope scope = AccessScope::APP_PRIVATE) {
    KeyPolicy p;
    p.allowedPurposes = purposes;
    p.exportable = exportable;
    p.backupable = backupable;
    p.expiresAt = expiresAt;
    p.maxUses = maxUses;
    p.accessScope = scope;
    return p;
}

// ============================================================
// Lifecycle tests
// ============================================================

void test_initialize() {
    KeyStoreManager ks;
    KeyStoreResult r = ks.initialize();
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    ASSERT_TRUE(ks.isInitialized());
}

void test_initialize_already_initialized() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.initialize();
    ASSERT_TRUE(r == KeyStoreResult::ALREADY_INITIALIZED);
}

void test_shutdown() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.shutdown();
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    ASSERT_FALSE(ks.isInitialized());
}

void test_shutdown_not_initialized() {
    KeyStoreManager ks;
    KeyStoreResult r = ks.shutdown();
    ASSERT_TRUE(r == KeyStoreResult::NOT_INITIALIZED);
}

void test_shutdown_clears_keys() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT) |
                       KeyStoreManager::purposeToBit(KeyPurpose::DECRYPT);
    ks.generateKey("test1", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.shutdown();
    auto keys = ks.listKeys();
    ASSERT_EQ(keys.size(), 0u);
}

void test_shutdown_clears_history() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "hello";
    ks.encrypt(req);
    ks.shutdown();
    auto hist = ks.getHistory();
    ASSERT_EQ(hist.size(), 0u);
}

void test_set_max_keys() {
    KeyStoreManager ks;
    ks.initialize(10, 100, 50);
    ASSERT_EQ(ks.getMaxKeys(), 10u);
    ks.setMaxKeys(20);
    ASSERT_EQ(ks.getMaxKeys(), 20u);
}

void test_set_max_certificates() {
    KeyStoreManager ks;
    ks.initialize();
    ASSERT_EQ(ks.getMaxCertificates(), 128u);
    ks.setMaxCertificates(64);
    ASSERT_EQ(ks.getMaxCertificates(), 64u);
}

void test_set_max_history() {
    KeyStoreManager ks;
    ks.initialize();
    ASSERT_EQ(ks.getMaxHistory(), 500u);
    ks.setMaxHistory(100);
    ASSERT_EQ(ks.getMaxHistory(), 100u);
}

// ============================================================
// Key generation tests
// ============================================================

void test_generate_key_basic() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("aes_key", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_TRUE(id > 0);
    KeyMetadata meta = ks.getKeyMetadata(id);
    ASSERT_EQ(meta.type, KeyType::AES_256);
    ASSERT_EQ(meta.state, KeyState::ACTIVE);
    ASSERT_STREQ(meta.alias.c_str(), "aes_key");
    ASSERT_STREQ(meta.ownerAppId.c_str(), "app1");
    ASSERT_EQ(meta.version, 1u);
    ASSERT_TRUE(meta.createdAt > 0);
}

void test_generate_key_not_initialized() {
    KeyStoreManager ks;
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_EQ(id, 0u);
}

void test_generate_key_empty_alias() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("", KeyType::AES_256, makePolicy(0xFF), "app1");
    ASSERT_EQ(id, 0u);
}

void test_generate_key_duplicate_alias() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id1 = ks.generateKey("dup", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_TRUE(id1 > 0);
    uint64_t id2 = ks.generateKey("dup", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_EQ(id2, 0u);
}

void test_generate_key_same_alias_different_owner() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id1 = ks.generateKey("shared", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t id2 = ks.generateKey("shared", KeyType::AES_256, makePolicy(purposes), "app2");
    ASSERT_TRUE(id1 > 0);
    ASSERT_TRUE(id2 > 0);
    ASSERT_TRUE(id1 != id2);
}

void test_generate_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.generateKey("k2", KeyType::RSA_2048, makePolicy(purposes), "app1");
    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.totalKeys, 2u);
    ASSERT_EQ(s.keysGenerated, 2u);
    ASSERT_EQ(s.totalByType[static_cast<int>(KeyType::AES_256)], 1u);
    ASSERT_EQ(s.totalByType[static_cast<int>(KeyType::RSA_2048)], 1u);
}

void test_generate_key_all_types() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    KeyType types[] = {KeyType::AES_128, KeyType::AES_256, KeyType::RSA_2048, KeyType::RSA_4096,
                      KeyType::ECDSA_P256, KeyType::HMAC_SHA256, KeyType::DERIVED_SECRET, KeyType::RAW_SECRET};
    for (int i = 0; i < 8; ++i) {
        uint64_t id = ks.generateKey("key_" + std::to_string(i), types[i], makePolicy(purposes), "app1");
        ASSERT_TRUE(id > 0);
    }
    ASSERT_EQ(ks.getStats().totalKeys, 8u);
}

void test_generate_key_different_backends() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    uint64_t id1 = ks.generateKey("mem", KeyType::AES_256, makePolicy(purposes), "app1",
                                   StorageBackend::MEMORY);
    uint64_t id2 = ks.generateKey("hw", KeyType::AES_256, makePolicy(purposes), "app1",
                                   StorageBackend::HARDWARE_BACKED_STUB);
    ASSERT_TRUE(id1 > 0);
    ASSERT_TRUE(id2 > 0);
    KeyMetadata m1 = ks.getKeyMetadata(id1);
    KeyMetadata m2 = ks.getKeyMetadata(id2);
    ASSERT_EQ(m1.backend, StorageBackend::MEMORY);
    ASSERT_EQ(m2.backend, StorageBackend::HARDWARE_BACKED_STUB);
    ASSERT_EQ(m1.securityLevel, SecurityLevel::SOFTWARE);
    ASSERT_EQ(m2.securityLevel, SecurityLevel::HARDWARE_BACKED_STUB);
}

void test_generate_key_max_keys_exceeded() {
    KeyStoreManager ks;
    ks.initialize(2, 100, 50);
    uint8_t purposes = 0xFF;
    uint64_t id1 = ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t id2 = ks.generateKey("k2", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t id3 = ks.generateKey("k3", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_TRUE(id1 > 0);
    ASSERT_TRUE(id2 > 0);
    ASSERT_EQ(id3, 0u);
}

// ============================================================
// Key import tests
// ============================================================

void test_import_key_basic() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.importKey("imported", KeyType::AES_256, "secret_material",
                                    makePolicy(0xFF, true), "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    uint64_t id = ks.getKeyByAlias("imported", "app1");
    ASSERT_TRUE(id > 0);
}

void test_import_key_not_initialized() {
    KeyStoreManager ks;
    KeyStoreResult r = ks.importKey("imp", KeyType::AES_256, "mat", makePolicy(0xFF), "app1");
    ASSERT_TRUE(r == KeyStoreResult::NOT_INITIALIZED);
}

void test_import_key_empty_alias() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.importKey("", KeyType::AES_256, "mat", makePolicy(0xFF), "app1");
    ASSERT_TRUE(r == KeyStoreResult::INVALID_ALIAS);
}

void test_import_key_empty_material() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.importKey("imp", KeyType::AES_256, "", makePolicy(0xFF), "app1");
    ASSERT_TRUE(r == KeyStoreResult::INVALID_PARAMETER);
}

void test_import_key_duplicate_alias() {
    KeyStoreManager ks;
    ks.initialize();
    ks.importKey("dup", KeyType::AES_256, "mat1", makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.importKey("dup", KeyType::AES_256, "mat2", makePolicy(0xFF), "app1");
    ASSERT_TRUE(r == KeyStoreResult::KEY_EXISTS);
}

void test_import_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    ks.importKey("imp1", KeyType::AES_256, "mat1", makePolicy(0xFF), "app1");
    ks.importKey("imp2", KeyType::RSA_2048, "mat2", makePolicy(0xFF), "app1");
    ASSERT_EQ(ks.getStats().keysImported, 2u);
}

// ============================================================
// Key derivation tests
// ============================================================

void test_derive_key_pbkdf2() {
    KeyStoreManager ks;
    ks.initialize();
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    params.password = "password";
    params.salt = "salt123";
    params.iterations = 100;
    uint64_t id = ks.deriveKey("derived1", params, makePolicy(0xFF), "app1");
    ASSERT_TRUE(id > 0);
    KeyMetadata meta = ks.getKeyMetadata(id);
    ASSERT_EQ(meta.type, KeyType::DERIVED_SECRET);
}

void test_derive_key_hkdf() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t sourceId = ks.generateKey("source", KeyType::AES_256, makePolicy(0xFF), "app1");
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::HKDF_SHA256_STUB;
    params.sourceKeyId = sourceId;
    params.salt = "hkdf_salt";
    params.info = "context_info";
    uint64_t id = ks.deriveKey("derived_hkdf", params, makePolicy(0xFF), "app1");
    ASSERT_TRUE(id > 0);
}

void test_derive_key_not_initialized() {
    KeyStoreManager ks;
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    uint64_t id = ks.deriveKey("d", params, makePolicy(0xFF), "app1");
    ASSERT_EQ(id, 0u);
}

void test_derive_key_empty_alias() {
    KeyStoreManager ks;
    ks.initialize();
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    uint64_t id = ks.deriveKey("", params, makePolicy(0xFF), "app1");
    ASSERT_EQ(id, 0u);
}

void test_derive_key_invalid_source_key() {
    KeyStoreManager ks;
    ks.initialize();
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::HKDF_SHA256_STUB;
    params.sourceKeyId = 999;
    uint64_t id = ks.deriveKey("d", params, makePolicy(0xFF), "app1");
    ASSERT_EQ(id, 0u);
}

void test_derive_key_deterministic_pbkdf2() {
    KeyStoreManager ks;
    ks.initialize();
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    params.password = "test_pass";
    params.salt = "test_salt";
    params.iterations = 50;
    uint64_t id1 = ks.deriveKey("d1", params, makePolicy(0xFF), "app1");
    uint64_t id2 = ks.deriveKey("d2", params, makePolicy(0xFF), "app1");
    KeyMetadata m1 = ks.getKeyMetadata(id1);
    KeyMetadata m2 = ks.getKeyMetadata(id2);
    ASSERT_EQ(m1.keyMaterial, m2.keyMaterial);
}

void test_derive_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    DerivationParams params;
    params.algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    params.password = "p";
    params.salt = "s";
    ks.deriveKey("d1", params, makePolicy(0xFF), "app1");
    ks.deriveKey("d2", params, makePolicy(0xFF), "app1");
    ASSERT_EQ(ks.getStats().keysDerived, 2u);
}

// ============================================================
// Key metadata and listing tests
// ============================================================

void test_get_key_metadata_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    KeyMetadata m = ks.getKeyMetadata(999);
    ASSERT_EQ(m.id, 0u);
}

void test_get_key_by_alias() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("findme", KeyType::AES_256, makePolicy(0xFF), "app1");
    uint64_t found = ks.getKeyByAlias("findme", "app1");
    ASSERT_EQ(found, id);
}

void test_get_key_by_alias_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t found = ks.getKeyByAlias("nonexistent", "app1");
    ASSERT_EQ(found, 0u);
}

void test_list_keys() {
    KeyStoreManager ks;
    ks.initialize();
    ks.generateKey("k1", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.generateKey("k2", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    auto keys = ks.listKeys();
    ASSERT_EQ(keys.size(), 2u);
}

void test_get_keys_by_owner() {
    KeyStoreManager ks;
    ks.initialize();
    ks.generateKey("k1", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.generateKey("k2", KeyType::AES_256, makePolicy(0xFF), "app2");
    ks.generateKey("k3", KeyType::AES_256, makePolicy(0xFF), "app1");
    auto app1Keys = ks.getKeysByOwner("app1");
    ASSERT_EQ(app1Keys.size(), 2u);
}

void test_get_keys_by_type() {
    KeyStoreManager ks;
    ks.initialize();
    ks.generateKey("k1", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.generateKey("k2", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    ks.generateKey("k3", KeyType::AES_256, makePolicy(0xFF), "app1");
    auto aesKeys = ks.getKeysByType(KeyType::AES_256);
    ASSERT_EQ(aesKeys.size(), 2u);
}

void test_get_keys_by_state() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id1 = ks.generateKey("k1", KeyType::AES_256, makePolicy(0xFF), "app1");
    uint64_t id2 = ks.generateKey("k2", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.disableKey(id2, "app1");
    auto activeKeys = ks.getKeysByState(KeyState::ACTIVE);
    auto disabledKeys = ks.getKeysByState(KeyState::DISABLED);
    ASSERT_EQ(activeKeys.size(), 1u);
    ASSERT_EQ(disabledKeys.size(), 1u);
}

// ============================================================
// Key deletion tests
// ============================================================

void test_delete_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("del", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.deleteKey(id, "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    ASSERT_EQ(ks.getStats().totalKeys, 0u);
}

void test_delete_key_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.deleteKey(999, "app1");
    ASSERT_TRUE(r == KeyStoreResult::KEY_NOT_FOUND);
}

void test_delete_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.deleteKey(id, "app2");
    ASSERT_TRUE(r == KeyStoreResult::PERMISSION_DENIED);
}

void test_delete_key_system_can_delete_any() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.deleteKey(id, "system");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
}

void test_delete_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.deleteKey(id, "app1");
    ASSERT_EQ(ks.getStats().keysDeleted, 1u);
}

void test_delete_key_clears_access_grants() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF, false, false, 0, 0,
                        AccessScope::SHARED_APPS), "app1");
    ks.grantAccess(id, "app2", 0xFF);
    ks.deleteKey(id, "app1");
    auto grants = ks.getAccessGrants(id);
    ASSERT_EQ(grants.size(), 0u);
}

// ============================================================
// Key disable/enable tests
// ============================================================

void test_disable_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.disableKey(id, "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    KeyMetadata m = ks.getKeyMetadata(id);
    ASSERT_EQ(m.state, KeyState::DISABLED);
}

void test_enable_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.disableKey(id, "app1");
    KeyStoreResult r = ks.enableKey(id, "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    KeyMetadata m = ks.getKeyMetadata(id);
    ASSERT_EQ(m.state, KeyState::ACTIVE);
}

void test_enable_key_not_disabled() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.enableKey(id, "app1");
    ASSERT_TRUE(r == KeyStoreResult::BAD_STATE);
}

void test_disable_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.disableKey(id, "app2");
    ASSERT_TRUE(r == KeyStoreResult::PERMISSION_DENIED);
}

// ============================================================
// Key revocation tests
// ============================================================

void test_revoke_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.revokeKey(id, "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    KeyMetadata m = ks.getKeyMetadata(id);
    ASSERT_EQ(m.state, KeyState::REVOKED);
}

void test_revoke_key_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.revokeKey(999, "app1");
    ASSERT_TRUE(r == KeyStoreResult::KEY_NOT_FOUND);
}

void test_revoke_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.revokeKey(id, "app2");
    ASSERT_TRUE(r == KeyStoreResult::PERMISSION_DENIED);
}

// ============================================================
// Key rotation tests
// ============================================================

void test_rotate_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("rot", KeyType::AES_256, makePolicy(0xFF), "app1");
    uint64_t newId = ks.rotateKey(id, "app1");
    ASSERT_TRUE(newId > 0);
    ASSERT_TRUE(newId != id);
    KeyMetadata oldKey = ks.getKeyMetadata(id);
    KeyMetadata newKey = ks.getKeyMetadata(newId);
    ASSERT_EQ(oldKey.state, KeyState::ROTATED);
    ASSERT_EQ(newKey.state, KeyState::ACTIVE);
    ASSERT_EQ(newKey.version, 2u);
    ASSERT_STREQ(newKey.alias.c_str(), "rot");
}

void test_rotate_key_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t r = ks.rotateKey(999, "app1");
    ASSERT_EQ(r, 0u);
}

void test_rotate_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    uint64_t r = ks.rotateKey(id, "app2");
    ASSERT_EQ(r, 0u);
}

void test_rotate_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.rotateKey(id, "app1");
    ASSERT_EQ(ks.getStats().keysRotated, 1u);
}

// ============================================================
// Access control tests
// ============================================================

void test_grant_access() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF, false, false, 0, 0,
                        AccessScope::SHARED_APPS), "app1");
    KeyStoreResult r = ks.grantAccess(id, "app2", 0xFF);
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    auto grants = ks.getAccessGrants(id);
    ASSERT_EQ(grants.size(), 1u);
}

void test_revoke_access() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF, false, false, 0, 0,
                        AccessScope::SHARED_APPS), "app1");
    ks.grantAccess(id, "app2", 0xFF);
    KeyStoreResult r = ks.revokeAccess(id, "app2");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    auto grants = ks.getAccessGrants(id);
    ASSERT_EQ(grants.size(), 0u);
}

void test_check_access_owner() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_TRUE(ks.checkAccess(id, "app1", KeyPurpose::ENCRYPT));
    ASSERT_FALSE(ks.checkAccess(id, "app1", KeyPurpose::DECRYPT));
}

void test_check_access_system() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0), "app1");
    ASSERT_TRUE(ks.checkAccess(id, "system", KeyPurpose::ENCRYPT));
    ASSERT_TRUE(ks.checkAccess(id, "system", KeyPurpose::DECRYPT));
}

void test_check_access_shared_scope() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                        AccessScope::SHARED_APPS), "app1");
    ks.grantAccess(id, "app2", purposes);
    ASSERT_TRUE(ks.checkAccess(id, "app2", KeyPurpose::ENCRYPT));
    ASSERT_FALSE(ks.checkAccess(id, "app2", KeyPurpose::DECRYPT));
}

void test_check_access_system_only_scope() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                        AccessScope::SYSTEM_ONLY), "app1");
    ASSERT_FALSE(ks.checkAccess(id, "app2", KeyPurpose::ENCRYPT));
    ASSERT_TRUE(ks.checkAccess(id, "system", KeyPurpose::ENCRYPT));
}

void test_check_access_expired_grant() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                        AccessScope::SHARED_APPS), "app1");
    uint64_t expiredAt = 1;
    ks.grantAccess(id, "app2", purposes, expiredAt);
    ASSERT_FALSE(ks.checkAccess(id, "app2", KeyPurpose::ENCRYPT));
}

// ============================================================
// Encrypt/decrypt tests
// ============================================================

void test_encrypt_basic() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("enc", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "hello world";
    req.algorithm = CryptoAlgorithm::AES_GCM_STUB;
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::SUCCESS);
    ASSERT_FALSE(r.output.empty());
    ASSERT_FALSE(r.iv.empty());
    ASSERT_FALSE(r.tag.empty());
    ASSERT_EQ(r.bytesProcessed, 11u);
}

void test_encrypt_decrypt_roundtrip() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT) |
                       KeyStoreManager::purposeToBit(KeyPurpose::DECRYPT);
    uint64_t id = ks.generateKey("enc_dec", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest encReq;
    encReq.keyId = id;
    encReq.appId = "app1";
    encReq.input = "secret data 12345";
    encReq.algorithm = CryptoAlgorithm::AES_GCM_STUB;
    CryptoResult encRes = ks.encrypt(encReq);

    CryptoRequest decReq;
    decReq.keyId = id;
    decReq.appId = "app1";
    decReq.input = encRes.output;
    decReq.iv = encRes.iv;
    decReq.algorithm = CryptoAlgorithm::AES_GCM_STUB;
    CryptoResult decRes = ks.decrypt(decReq);
    ASSERT_TRUE(decRes.result == KeyStoreResult::SUCCESS);
    ASSERT_EQ(decRes.output, encReq.input);
}

void test_encrypt_key_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    CryptoRequest req;
    req.keyId = 999;
    req.appId = "app1";
    req.input = "test";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::KEY_NOT_FOUND);
}

void test_encrypt_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app2";
    req.input = "test";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::PERMISSION_DENIED);
}

void test_encrypt_disabled_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.disableKey(id, "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::KEY_DISABLED);
}

void test_encrypt_revoked_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.revokeKey(id, "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::KEY_REVOKED);
}

void test_encrypt_by_alias() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    ks.generateKey("byalias", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.alias = "byalias";
    req.appId = "app1";
    req.input = "test data";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::SUCCESS);
}

void test_encrypt_updates_use_count() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    ks.encrypt(req);
    KeyMetadata m = ks.getKeyMetadata(id);
    ASSERT_EQ(m.useCount, 2u);
    ASSERT_TRUE(m.lastUsedAt > 0);
}

void test_encrypt_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    ASSERT_EQ(ks.getStats().encryptOps, 1u);
}

// ============================================================
// Sign/verify tests
// ============================================================

void test_sign_basic() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::SIGN);
    uint64_t id = ks.generateKey("sign_key", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "message to sign";
    req.algorithm = CryptoAlgorithm::ECDSA_P256_STUB;
    CryptoResult r = ks.sign(req);
    ASSERT_TRUE(r.result == KeyStoreResult::SUCCESS);
    ASSERT_FALSE(r.tag.empty());
}

void test_sign_verify_roundtrip() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::SIGN) |
                       KeyStoreManager::purposeToBit(KeyPurpose::VERIFY);
    uint64_t id = ks.generateKey("sv_key", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    CryptoRequest signReq;
    signReq.keyId = id;
    signReq.appId = "app1";
    signReq.input = "message";
    signReq.algorithm = CryptoAlgorithm::ECDSA_P256_STUB;
    CryptoResult signRes = ks.sign(signReq);

    CryptoRequest verifyReq;
    verifyReq.keyId = id;
    verifyReq.appId = "app1";
    verifyReq.input = "message";
    verifyReq.algorithm = CryptoAlgorithm::ECDSA_P256_STUB;
    KeyStoreResult verifyRes = ks.verify(verifyReq, signRes.tag);
    ASSERT_TRUE(verifyRes == KeyStoreResult::SUCCESS);
}

void test_verify_wrong_signature() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::SIGN) |
                       KeyStoreManager::purposeToBit(KeyPurpose::VERIFY);
    uint64_t id = ks.generateKey("k", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    CryptoRequest verifyReq;
    verifyReq.keyId = id;
    verifyReq.appId = "app1";
    verifyReq.input = "message";
    KeyStoreResult r = ks.verify(verifyReq, "wrong_signature");
    ASSERT_TRUE(r == KeyStoreResult::VERIFICATION_FAILED);
}

void test_sign_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::SIGN);
    uint64_t id = ks.generateKey("k", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app2";
    req.input = "test";
    CryptoResult r = ks.sign(req);
    ASSERT_TRUE(r.result == KeyStoreResult::PERMISSION_DENIED);
}

void test_verify_revoked_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::SIGN) |
                       KeyStoreManager::purposeToBit(KeyPurpose::VERIFY);
    uint64_t id = ks.generateKey("k", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    ks.revokeKey(id, "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    KeyStoreResult r = ks.verify(req, "sig");
    ASSERT_TRUE(r == KeyStoreResult::KEY_REVOKED);
}

// ============================================================
// Wrap/unwrap tests
// ============================================================

void test_wrap_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::WRAP);
    uint64_t wrapId = ks.generateKey("wrap", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t targetId = ks.generateKey("target", KeyType::AES_256, makePolicy(0xFF), "app1");
    CryptoResult r = ks.wrapKey(wrapId, targetId, "app1");
    ASSERT_TRUE(r.result == KeyStoreResult::SUCCESS);
    ASSERT_FALSE(r.output.empty());
}

void test_wrap_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::WRAP);
    uint64_t wrapId = ks.generateKey("wrap", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t targetId = ks.generateKey("target", KeyType::AES_256, makePolicy(0xFF), "app1");
    CryptoResult r = ks.wrapKey(wrapId, targetId, "app2");
    ASSERT_TRUE(r.result == KeyStoreResult::PERMISSION_DENIED);
}

void test_unwrap_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t wrapPurposes = KeyStoreManager::purposeToBit(KeyPurpose::WRAP) |
                           KeyStoreManager::purposeToBit(KeyPurpose::UNWRAP);
    uint64_t wrapId = ks.generateKey("wrap", KeyType::AES_256, makePolicy(wrapPurposes), "app1");
    uint64_t targetId = ks.generateKey("target", KeyType::AES_256, makePolicy(0xFF), "app1");
    CryptoResult wrapRes = ks.wrapKey(wrapId, targetId, "app1");

    uint64_t unwrappedId = ks.unwrapKey(wrapId, wrapRes.output, "unwrapped",
                                        makePolicy(0xFF), "app1");
    ASSERT_TRUE(unwrappedId > 0);
}

void test_wrap_unwrap_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t wrapPurposes = KeyStoreManager::purposeToBit(KeyPurpose::WRAP) |
                           KeyStoreManager::purposeToBit(KeyPurpose::UNWRAP);
    uint64_t wrapId = ks.generateKey("w", KeyType::AES_256, makePolicy(wrapPurposes), "app1");
    uint64_t targetId = ks.generateKey("t", KeyType::AES_256, makePolicy(0xFF), "app1");
    CryptoResult wr = ks.wrapKey(wrapId, targetId, "app1");
    ks.unwrapKey(wrapId, wr.output, "uw", makePolicy(0xFF), "app1");
    ASSERT_EQ(ks.getStats().wrapOps, 1u);
    ASSERT_EQ(ks.getStats().unwrapOps, 1u);
}

// ============================================================
// Backup hooks tests
// ============================================================

void test_export_key_blob() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("exp", KeyType::AES_256, makePolicy(0xFF, true), "app1");
    std::string blob = ks.exportKeyBlob(id, "app1");
    ASSERT_FALSE(blob.empty());
}

void test_export_key_blob_not_exportable() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("exp", KeyType::AES_256, makePolicy(0xFF, false), "app1");
    std::string blob = ks.exportKeyBlob(id, "app1");
    ASSERT_TRUE(blob.empty());
}

void test_export_key_blob_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("exp", KeyType::AES_256, makePolicy(0xFF, true), "app1");
    std::string blob = ks.exportKeyBlob(id, "app2");
    ASSERT_TRUE(blob.empty());
}

void test_import_key_blob() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t id = ks.generateKey("exp", KeyType::AES_256, makePolicy(0xFF, true), "app1");
    std::string blob = ks.exportKeyBlob(id, "app1");
    uint64_t newId = ks.importKeyBlob(blob, "imported_blob", makePolicy(0xFF), "app1");
    ASSERT_TRUE(newId > 0);
}

void test_import_key_blob_empty() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t r = ks.importKeyBlob("", "test", makePolicy(0xFF), "app1");
    ASSERT_EQ(r, 0u);
}

void test_get_recovery_keys() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    ks.generateKey("normal", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                     AccessScope::APP_PRIVATE), "app1");
    ks.generateKey("recovery", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                     AccessScope::RECOVERY_ONLY), "app1");
    auto recoveryKeys = ks.getRecoveryKeys();
    ASSERT_EQ(recoveryKeys.size(), 1u);
}

void test_get_keys_by_scope() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                     AccessScope::APP_PRIVATE), "app1");
    ks.generateKey("k2", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                     AccessScope::SHARED_APPS), "app1");
    ks.generateKey("k3", KeyType::AES_256, makePolicy(purposes, false, false, 0, 0,
                     AccessScope::SYSTEM_ONLY), "app1");
    auto sharedKeys = ks.getKeysByScope(AccessScope::SHARED_APPS);
    auto systemKeys = ks.getKeysByScope(AccessScope::SYSTEM_ONLY);
    ASSERT_EQ(sharedKeys.size(), 1u);
    ASSERT_EQ(systemKeys.size(), 1u);
}

// ============================================================
// Attestation tests
// ============================================================

void test_attest_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ATTEST);
    uint64_t id = ks.generateKey("attest", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    AttestationReport report = ks.attestKey(id, "challenge123", "app1");
    ASSERT_TRUE(report.verified);
    ASSERT_FALSE(report.certificateChainStub.empty());
    ASSERT_TRUE(report.timestamp > 0);
}

void test_attest_key_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    AttestationReport report = ks.attestKey(999, "challenge", "app1");
    ASSERT_FALSE(report.verified);
}

void test_attest_key_permission_denied() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ATTEST);
    uint64_t id = ks.generateKey("k", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    AttestationReport report = ks.attestKey(id, "challenge", "app2");
    ASSERT_FALSE(report.verified);
}

void test_attest_key_updates_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ATTEST);
    uint64_t id = ks.generateKey("k", KeyType::ECDSA_P256, makePolicy(purposes), "app1");
    ks.attestKey(id, "challenge", "app1");
    ASSERT_EQ(ks.getStats().attestations, 1u);
}

// ============================================================
// Certificate tests
// ============================================================

void test_create_self_signed_certificate() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t keyId = ks.generateKey("cert_key", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    uint64_t certId = ks.createSelfSignedCertificate(keyId, "CN=test", "app1");
    ASSERT_TRUE(certId > 0);
    CertificateEntry cert = ks.getCertificate(certId);
    ASSERT_STREQ(cert.subject.c_str(), "CN=test");
    ASSERT_STREQ(cert.issuer.c_str(), "CN=test");
    ASSERT_EQ(cert.state, CertificateState::VALID);
    ASSERT_FALSE(cert.serial.empty());
    ASSERT_FALSE(cert.fingerprint.empty());
}

void test_get_certificates_for_key() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t keyId = ks.generateKey("k", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    ks.createSelfSignedCertificate(keyId, "CN=cert1", "app1");
    ks.createSelfSignedCertificate(keyId, "CN=cert2", "app1");
    auto certs = ks.getCertificatesForKey(keyId);
    ASSERT_EQ(certs.size(), 2u);
}

void test_revoke_certificate() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t keyId = ks.generateKey("k", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    uint64_t certId = ks.createSelfSignedCertificate(keyId, "CN=test", "app1");
    KeyStoreResult r = ks.revokeCertificate(certId, "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
    CertificateEntry cert = ks.getCertificate(certId);
    ASSERT_EQ(cert.state, CertificateState::REVOKED);
}

void test_revoke_certificate_not_found() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreResult r = ks.revokeCertificate(999, "app1");
    ASSERT_TRUE(r == KeyStoreResult::CERTIFICATE_NOT_FOUND);
}

void test_import_certificate() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t keyId = ks.generateKey("k", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.importCertificate(keyId, "-----BEGIN CERTIFICATE----- data", "app1");
    ASSERT_TRUE(r == KeyStoreResult::SUCCESS);
}

void test_import_certificate_empty_data() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t keyId = ks.generateKey("k", KeyType::RSA_2048, makePolicy(0xFF), "app1");
    KeyStoreResult r = ks.importCertificate(keyId, "", "app1");
    ASSERT_TRUE(r == KeyStoreResult::INVALID_PARAMETER);
}

// ============================================================
// Stats tests
// ============================================================

void test_stats_initial() {
    KeyStoreManager ks;
    ks.initialize();
    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.totalKeys, 0u);
    ASSERT_EQ(s.keysGenerated, 0u);
    ASSERT_EQ(s.encryptOps, 0u);
    ASSERT_EQ(s.certificates, 0u);
}

void test_reset_stats() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    ks.resetStats();
    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.encryptOps, 0u);
    ASSERT_EQ(s.keysGenerated, 0u);
}

void test_stats_by_type() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.generateKey("k2", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.generateKey("k3", KeyType::RSA_2048, makePolicy(purposes), "app1");
    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.totalByType[static_cast<int>(KeyType::AES_256)], 2u);
    ASSERT_EQ(s.totalByType[static_cast<int>(KeyType::RSA_2048)], 1u);
}

void test_stats_by_backend() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes), "app1", StorageBackend::MEMORY);
    ks.generateKey("k2", KeyType::AES_256, makePolicy(purposes), "app1", StorageBackend::HARDWARE_BACKED_STUB);
    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.totalByBackend[static_cast<int>(StorageBackend::MEMORY)], 1u);
    ASSERT_EQ(s.totalByBackend[static_cast<int>(StorageBackend::HARDWARE_BACKED_STUB)], 1u);
}

void test_stats_by_state() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = 0xFF;
    uint64_t id1 = ks.generateKey("k1", KeyType::AES_256, makePolicy(purposes), "app1");
    uint64_t id2 = ks.generateKey("k2", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.disableKey(id2, "app1");
    KeyStoreStats s = ks.getStats();
    // totalByState tracks creation state, not current state
    ASSERT_EQ(s.totalByState[static_cast<int>(KeyState::ACTIVE)], 2u);
}

// ============================================================
// History tests
// ============================================================

void test_history_records_operations() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    auto hist = ks.getHistory();
    ASSERT_TRUE(hist.size() >= 1);
}

void test_clear_history() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    ks.clearHistory();
    ASSERT_EQ(ks.getHistory().size(), 0u);
}

void test_history_max_limit() {
    KeyStoreManager ks;
    ks.initialize(100, 100, 3);
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    for (int i = 0; i < 5; ++i) {
        ks.encrypt(req);
    }
    auto hist = ks.getHistory();
    ASSERT_EQ(hist.size(), 3u);
}

// ============================================================
// Callback tests
// ============================================================

void test_key_state_callback() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t callbackId = 0;
    KeyState oldState = KeyState::ACTIVE;
    KeyState newState = KeyState::ACTIVE;
    ks.setKeyStateCallback([&](uint64_t id, KeyState old_s, KeyState new_s) {
        callbackId = id;
        oldState = old_s;
        newState = new_s;
    });
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(0xFF), "app1");
    ks.disableKey(id, "app1");
    ASSERT_EQ(callbackId, id);
    ASSERT_EQ(oldState, KeyState::ACTIVE);
    ASSERT_EQ(newState, KeyState::DISABLED);
}

void test_crypto_callback() {
    KeyStoreManager ks;
    ks.initialize();
    uint64_t callbackKeyId = 0;
    std::string callbackOp;
    ks.setCryptoCallback([&](const KeyOperationRecord& rec) {
        callbackKeyId = rec.keyId;
        callbackOp = rec.operation;
    });
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    ks.encrypt(req);
    ASSERT_EQ(callbackKeyId, id);
    ASSERT_STREQ(callbackOp.c_str(), "encrypt");
}

// ============================================================
// Integration with LogServer and CrashReporter
// ============================================================

void test_set_log_server() {
    KeyStoreManager ks;
    ks.initialize();
    LogServer logServer;
    logServer.initialize();
    ks.setLogServer(&logServer);
    ASSERT_TRUE(ks.getLogServer() != nullptr);
}

void test_set_crash_reporter() {
    KeyStoreManager ks;
    ks.initialize();
    CrashReporter reporter;
    reporter.initialize();
    ks.setCrashReporter(&reporter);
    ASSERT_TRUE(ks.getCrashReporter() != nullptr);
}

void test_log_server_on_failure() {
    KeyStoreManager ks;
    ks.initialize();
    LogServer logServer;
    logServer.initialize();
    ks.setLogServer(&logServer);
    ks.setFailNextOperation(true);
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_EQ(id, 0u);
    auto entries = logServer.getRecentLogs(10);
    ASSERT_TRUE(entries.size() > 0);
}

void test_crash_reporter_on_failure() {
    KeyStoreManager ks;
    ks.initialize();
    CrashReporter reporter;
    reporter.initialize();
    ks.setCrashReporter(&reporter);
    ks.setFailNextOperation(true);
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    auto anrs = reporter.getRecent(10);
    ASSERT_TRUE(anrs.size() > 0);
}

// ============================================================
// Failure simulation tests
// ============================================================

void test_fail_next_operation_flag() {
    KeyStoreManager ks;
    ks.initialize();
    ks.setFailNextOperation(true);
    ASSERT_TRUE(ks.getFailNextOperation());
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_EQ(id, 0u);
    ASSERT_FALSE(ks.getFailNextOperation());
}

void test_fail_encrypt() {
    KeyStoreManager ks;
    ks.initialize();
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    uint64_t id = ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ks.setFailNextOperation(true);
    CryptoRequest req;
    req.keyId = id;
    req.appId = "app1";
    req.input = "test";
    CryptoResult r = ks.encrypt(req);
    ASSERT_TRUE(r.result == KeyStoreResult::CRYPTO_FAILED);
}

void test_fail_updates_failure_stats() {
    KeyStoreManager ks;
    ks.initialize();
    ks.setFailNextOperation(true);
    uint8_t purposes = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT);
    ks.generateKey("k", KeyType::AES_256, makePolicy(purposes), "app1");
    ASSERT_EQ(ks.getStats().totalFailures, 1u);
}

// ============================================================
// String helpers tests
// ============================================================

void test_key_type_to_string() {
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::AES_128), "AES_128");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::AES_256), "AES_256");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::RSA_2048), "RSA_2048");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::RSA_4096), "RSA_4096");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::ECDSA_P256), "ECDSA_P256");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::HMAC_SHA256), "HMAC_SHA256");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::DERIVED_SECRET), "DERIVED_SECRET");
    ASSERT_STREQ(KeyStoreManager::keyTypeToString(KeyType::RAW_SECRET), "RAW_SECRET");
}

void test_key_purpose_to_string() {
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::ENCRYPT), "ENCRYPT");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::DECRYPT), "DECRYPT");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::SIGN), "SIGN");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::VERIFY), "VERIFY");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::WRAP), "WRAP");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::UNWRAP), "UNWRAP");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::DERIVE), "DERIVE");
    ASSERT_STREQ(KeyStoreManager::keyPurposeToString(KeyPurpose::ATTEST), "ATTEST");
}

void test_key_state_to_string() {
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::DISABLED), "DISABLED");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::REVOKED), "REVOKED");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::ROTATED), "ROTATED");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::DESTROYED), "DESTROYED");
    ASSERT_STREQ(KeyStoreManager::keyStateToString(KeyState::COMPROMISED), "COMPROMISED");
}

void test_storage_backend_to_string() {
    ASSERT_STREQ(KeyStoreManager::storageBackendToString(StorageBackend::MEMORY), "MEMORY");
    ASSERT_STREQ(KeyStoreManager::storageBackendToString(StorageBackend::SECURE_STORAGE_STUB), "SECURE_STORAGE_STUB");
    ASSERT_STREQ(KeyStoreManager::storageBackendToString(StorageBackend::HARDWARE_BACKED_STUB), "HARDWARE_BACKED_STUB");
    ASSERT_STREQ(KeyStoreManager::storageBackendToString(StorageBackend::BACKUP_BLOB), "BACKUP_BLOB");
}

void test_crypto_algorithm_to_string() {
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::AES_GCM_STUB), "AES_GCM_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::AES_CBC_STUB), "AES_CBC_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::RSA_OAEP_STUB), "RSA_OAEP_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::ECDSA_P256_STUB), "ECDSA_P256_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::HMAC_SHA256_STUB), "HMAC_SHA256_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::PBKDF2_SHA256_STUB), "PBKDF2_SHA256_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::HKDF_SHA256_STUB), "HKDF_SHA256_STUB");
    ASSERT_STREQ(KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm::FNV1A_MAC_STUB), "FNV1A_MAC_STUB");
}

void test_security_level_to_string() {
    ASSERT_STREQ(KeyStoreManager::securityLevelToString(SecurityLevel::SOFTWARE), "SOFTWARE");
    ASSERT_STREQ(KeyStoreManager::securityLevelToString(SecurityLevel::SECURE_STORAGE), "SECURE_STORAGE");
    ASSERT_STREQ(KeyStoreManager::securityLevelToString(SecurityLevel::HARDWARE_BACKED_STUB), "HARDWARE_BACKED_STUB");
    ASSERT_STREQ(KeyStoreManager::securityLevelToString(SecurityLevel::SECURE_ENCLAVE_STUB), "SECURE_ENCLAVE_STUB");
}

void test_access_scope_to_string() {
    ASSERT_STREQ(KeyStoreManager::accessScopeToString(AccessScope::SYSTEM_ONLY), "SYSTEM_ONLY");
    ASSERT_STREQ(KeyStoreManager::accessScopeToString(AccessScope::APP_PRIVATE), "APP_PRIVATE");
    ASSERT_STREQ(KeyStoreManager::accessScopeToString(AccessScope::SHARED_APPS), "SHARED_APPS");
    ASSERT_STREQ(KeyStoreManager::accessScopeToString(AccessScope::RECOVERY_ONLY), "RECOVERY_ONLY");
}

void test_certificate_state_to_string() {
    ASSERT_STREQ(KeyStoreManager::certificateStateToString(CertificateState::VALID), "VALID");
    ASSERT_STREQ(KeyStoreManager::certificateStateToString(CertificateState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(KeyStoreManager::certificateStateToString(CertificateState::REVOKED), "REVOKED");
    ASSERT_STREQ(KeyStoreManager::certificateStateToString(CertificateState::UNTRUSTED), "UNTRUSTED");
}

void test_keystore_result_to_string() {
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::KEY_NOT_FOUND), "KEY_NOT_FOUND");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::CRYPTO_FAILED), "CRYPTO_FAILED");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::VERIFICATION_FAILED), "VERIFICATION_FAILED");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::STORAGE_FULL), "STORAGE_FULL");
    ASSERT_STREQ(KeyStoreManager::keyStoreResultToString(KeyStoreResult::KEY_EXPIRED), "KEY_EXPIRED");
}

void test_string_to_key_type() {
    ASSERT_EQ(KeyStoreManager::stringToKeyType("AES_128"), KeyType::AES_128);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("AES_256"), KeyType::AES_256);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("RSA_2048"), KeyType::RSA_2048);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("RSA_4096"), KeyType::RSA_4096);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("ECDSA_P256"), KeyType::ECDSA_P256);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("HMAC_SHA256"), KeyType::HMAC_SHA256);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("DERIVED_SECRET"), KeyType::DERIVED_SECRET);
    ASSERT_EQ(KeyStoreManager::stringToKeyType("RAW_SECRET"), KeyType::RAW_SECRET);
}

void test_string_to_key_purpose() {
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("ENCRYPT"), KeyPurpose::ENCRYPT);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("DECRYPT"), KeyPurpose::DECRYPT);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("SIGN"), KeyPurpose::SIGN);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("VERIFY"), KeyPurpose::VERIFY);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("WRAP"), KeyPurpose::WRAP);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("UNWRAP"), KeyPurpose::UNWRAP);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("DERIVE"), KeyPurpose::DERIVE);
    ASSERT_EQ(KeyStoreManager::stringToKeyPurpose("ATTEST"), KeyPurpose::ATTEST);
}

void test_string_to_key_state() {
    ASSERT_EQ(KeyStoreManager::stringToKeyState("ACTIVE"), KeyState::ACTIVE);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("DISABLED"), KeyState::DISABLED);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("EXPIRED"), KeyState::EXPIRED);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("REVOKED"), KeyState::REVOKED);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("ROTATED"), KeyState::ROTATED);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("DESTROYED"), KeyState::DESTROYED);
    ASSERT_EQ(KeyStoreManager::stringToKeyState("COMPROMISED"), KeyState::COMPROMISED);
}

void test_purpose_bitmask_helpers() {
    uint8_t mask = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT) |
                   KeyStoreManager::purposeToBit(KeyPurpose::DECRYPT);
    ASSERT_TRUE(KeyStoreManager::hasPurpose(mask, KeyPurpose::ENCRYPT));
    ASSERT_TRUE(KeyStoreManager::hasPurpose(mask, KeyPurpose::DECRYPT));
    ASSERT_FALSE(KeyStoreManager::hasPurpose(mask, KeyPurpose::SIGN));
}

void test_purpose_bitmask_to_string() {
    uint8_t mask = KeyStoreManager::purposeToBit(KeyPurpose::ENCRYPT) |
                   KeyStoreManager::purposeToBit(KeyPurpose::SIGN);
    std::string s = KeyStoreManager::purposeBitmaskToString(mask);
    ASSERT_FALSE(s.empty());
    ASSERT_TRUE(s.find("ENCRYPT") != std::string::npos);
    ASSERT_TRUE(s.find("SIGN") != std::string::npos);
}

void test_purpose_bitmask_empty() {
    std::string s = KeyStoreManager::purposeBitmaskToString(0);
    ASSERT_TRUE(s.empty());
}

// ============================================================
// Comprehensive integration test
// ============================================================

void test_full_workflow() {
    KeyStoreManager ks;
    ks.initialize();

    uint8_t allPurposes = 0xFF; // All purposes including ATTEST
    uint64_t encKey = ks.generateKey("master_enc", KeyType::AES_256, makePolicy(allPurposes), "app1");
    ASSERT_TRUE(encKey > 0);

    CryptoRequest encReq;
    encReq.keyId = encKey;
    encReq.appId = "app1";
    encReq.input = "top secret data";
    encReq.algorithm = CryptoAlgorithm::AES_GCM_STUB;
    CryptoResult encRes = ks.encrypt(encReq);
    ASSERT_TRUE(encRes.result == KeyStoreResult::SUCCESS);

    CryptoRequest decReq;
    decReq.keyId = encKey;
    decReq.appId = "app1";
    decReq.input = encRes.output;
    decReq.iv = encRes.iv;
    decReq.algorithm = CryptoAlgorithm::AES_GCM_STUB;
    CryptoResult decRes = ks.decrypt(decReq);
    ASSERT_TRUE(decRes.result == KeyStoreResult::SUCCESS);
    ASSERT_EQ(decRes.output, encReq.input);

    uint64_t newKey = ks.rotateKey(encKey, "app1");
    ASSERT_TRUE(newKey > 0);
    ASSERT_TRUE(newKey != encKey);

    AttestationReport report = ks.attestKey(encKey, "challenge", "system");
    ASSERT_TRUE(report.verified);

    KeyStoreStats s = ks.getStats();
    ASSERT_EQ(s.keysGenerated, 1u);
    ASSERT_EQ(s.keysRotated, 1u);
    ASSERT_EQ(s.encryptOps, 1u);
    ASSERT_EQ(s.decryptOps, 1u);
    ASSERT_EQ(s.attestations, 1u);
}

int main() {
    std::cout << "=== KeyStore Manager Tests ===" << std::endl;

    // Lifecycle
    RUN_TEST(test_initialize);
    RUN_TEST(test_initialize_already_initialized);
    RUN_TEST(test_shutdown);
    RUN_TEST(test_shutdown_not_initialized);
    RUN_TEST(test_shutdown_clears_keys);
    RUN_TEST(test_shutdown_clears_history);
    RUN_TEST(test_set_max_keys);
    RUN_TEST(test_set_max_certificates);
    RUN_TEST(test_set_max_history);

    // Key generation
    RUN_TEST(test_generate_key_basic);
    RUN_TEST(test_generate_key_not_initialized);
    RUN_TEST(test_generate_key_empty_alias);
    RUN_TEST(test_generate_key_duplicate_alias);
    RUN_TEST(test_generate_key_same_alias_different_owner);
    RUN_TEST(test_generate_key_updates_stats);
    RUN_TEST(test_generate_key_all_types);
    RUN_TEST(test_generate_key_different_backends);
    RUN_TEST(test_generate_key_max_keys_exceeded);

    // Key import
    RUN_TEST(test_import_key_basic);
    RUN_TEST(test_import_key_not_initialized);
    RUN_TEST(test_import_key_empty_alias);
    RUN_TEST(test_import_key_empty_material);
    RUN_TEST(test_import_key_duplicate_alias);
    RUN_TEST(test_import_key_updates_stats);

    // Key derivation
    RUN_TEST(test_derive_key_pbkdf2);
    RUN_TEST(test_derive_key_hkdf);
    RUN_TEST(test_derive_key_not_initialized);
    RUN_TEST(test_derive_key_empty_alias);
    RUN_TEST(test_derive_key_invalid_source_key);
    RUN_TEST(test_derive_key_deterministic_pbkdf2);
    RUN_TEST(test_derive_key_updates_stats);

    // Key metadata and listing
    RUN_TEST(test_get_key_metadata_not_found);
    RUN_TEST(test_get_key_by_alias);
    RUN_TEST(test_get_key_by_alias_not_found);
    RUN_TEST(test_list_keys);
    RUN_TEST(test_get_keys_by_owner);
    RUN_TEST(test_get_keys_by_type);
    RUN_TEST(test_get_keys_by_state);

    // Key deletion
    RUN_TEST(test_delete_key);
    RUN_TEST(test_delete_key_not_found);
    RUN_TEST(test_delete_key_permission_denied);
    RUN_TEST(test_delete_key_system_can_delete_any);
    RUN_TEST(test_delete_key_updates_stats);
    RUN_TEST(test_delete_key_clears_access_grants);

    // Key disable/enable
    RUN_TEST(test_disable_key);
    RUN_TEST(test_enable_key);
    RUN_TEST(test_enable_key_not_disabled);
    RUN_TEST(test_disable_key_permission_denied);

    // Key revocation
    RUN_TEST(test_revoke_key);
    RUN_TEST(test_revoke_key_not_found);
    RUN_TEST(test_revoke_key_permission_denied);

    // Key rotation
    RUN_TEST(test_rotate_key);
    RUN_TEST(test_rotate_key_not_found);
    RUN_TEST(test_rotate_key_permission_denied);
    RUN_TEST(test_rotate_key_updates_stats);

    // Access control
    RUN_TEST(test_grant_access);
    RUN_TEST(test_revoke_access);
    RUN_TEST(test_check_access_owner);
    RUN_TEST(test_check_access_system);
    RUN_TEST(test_check_access_shared_scope);
    RUN_TEST(test_check_access_system_only_scope);
    RUN_TEST(test_check_access_expired_grant);

    // Encrypt/decrypt
    RUN_TEST(test_encrypt_basic);
    RUN_TEST(test_encrypt_decrypt_roundtrip);
    RUN_TEST(test_encrypt_key_not_found);
    RUN_TEST(test_encrypt_permission_denied);
    RUN_TEST(test_encrypt_disabled_key);
    RUN_TEST(test_encrypt_revoked_key);
    RUN_TEST(test_encrypt_by_alias);
    RUN_TEST(test_encrypt_updates_use_count);
    RUN_TEST(test_encrypt_updates_stats);

    // Sign/verify
    RUN_TEST(test_sign_basic);
    RUN_TEST(test_sign_verify_roundtrip);
    RUN_TEST(test_verify_wrong_signature);
    RUN_TEST(test_sign_permission_denied);
    RUN_TEST(test_verify_revoked_key);

    // Wrap/unwrap
    RUN_TEST(test_wrap_key);
    RUN_TEST(test_wrap_key_permission_denied);
    RUN_TEST(test_unwrap_key);
    RUN_TEST(test_wrap_unwrap_updates_stats);

    // Backup hooks
    RUN_TEST(test_export_key_blob);
    RUN_TEST(test_export_key_blob_not_exportable);
    RUN_TEST(test_export_key_blob_permission_denied);
    RUN_TEST(test_import_key_blob);
    RUN_TEST(test_import_key_blob_empty);
    RUN_TEST(test_get_recovery_keys);
    RUN_TEST(test_get_keys_by_scope);

    // Attestation
    RUN_TEST(test_attest_key);
    RUN_TEST(test_attest_key_not_found);
    RUN_TEST(test_attest_key_permission_denied);
    RUN_TEST(test_attest_key_updates_stats);

    // Certificates
    RUN_TEST(test_create_self_signed_certificate);
    RUN_TEST(test_get_certificates_for_key);
    RUN_TEST(test_revoke_certificate);
    RUN_TEST(test_revoke_certificate_not_found);
    RUN_TEST(test_import_certificate);
    RUN_TEST(test_import_certificate_empty_data);

    // Stats
    RUN_TEST(test_stats_initial);
    RUN_TEST(test_reset_stats);
    RUN_TEST(test_stats_by_type);
    RUN_TEST(test_stats_by_backend);
    RUN_TEST(test_stats_by_state);

    // History
    RUN_TEST(test_history_records_operations);
    RUN_TEST(test_clear_history);
    RUN_TEST(test_history_max_limit);

    // Callbacks
    RUN_TEST(test_key_state_callback);
    RUN_TEST(test_crypto_callback);

    // Integration
    RUN_TEST(test_set_log_server);
    RUN_TEST(test_set_crash_reporter);
    RUN_TEST(test_log_server_on_failure);
    RUN_TEST(test_crash_reporter_on_failure);

    // Failure simulation
    RUN_TEST(test_fail_next_operation_flag);
    RUN_TEST(test_fail_encrypt);
    RUN_TEST(test_fail_updates_failure_stats);

    // String helpers
    RUN_TEST(test_key_type_to_string);
    RUN_TEST(test_key_purpose_to_string);
    RUN_TEST(test_key_state_to_string);
    RUN_TEST(test_storage_backend_to_string);
    RUN_TEST(test_crypto_algorithm_to_string);
    RUN_TEST(test_security_level_to_string);
    RUN_TEST(test_access_scope_to_string);
    RUN_TEST(test_certificate_state_to_string);
    RUN_TEST(test_keystore_result_to_string);
    RUN_TEST(test_string_to_key_type);
    RUN_TEST(test_string_to_key_purpose);
    RUN_TEST(test_string_to_key_state);
    RUN_TEST(test_purpose_bitmask_helpers);
    RUN_TEST(test_purpose_bitmask_to_string);
    RUN_TEST(test_purpose_bitmask_empty);

    // Integration
    RUN_TEST(test_full_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run << " passed ===" << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
