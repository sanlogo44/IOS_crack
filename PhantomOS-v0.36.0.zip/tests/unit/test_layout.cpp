/*
 * Phantom OS - Layout System Tests
 * Tests for LinearLayout and FrameLayout
 *
 * License: GPL-3.0
 */

#include "phantom/gui/layout.h"
#include "phantom/gui/widget.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_linear_layout_vertical() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 200));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(80, 40);
    container.addChild(std::move(child1));
    container.addChild(std::move(child2));

    LinearLayout layout(LayoutOrientation::VERTICAL);
    layout.setSpacing(5);

    Size measured = layout.measure(container);
    // Major = 30 + 5 + 40 = 75, Minor = max(50, 80) = 80
    ASSERT(measured.height == 75, "Vertical layout height should be 75");
    ASSERT(measured.width == 80, "Vertical layout width should be 80");

    layout.layout(container);

    auto* c1 = container.getChild(0);
    auto* c2 = container.getChild(1);
    ASSERT(c1->getBounds().y == 0, "First child y should be 0");
    ASSERT(c1->getBounds().height == 30, "First child height should be 30");
    ASSERT(c2->getBounds().y == 35, "Second child y should be 35 (30+5 spacing)");
    ASSERT(c2->getBounds().height == 40, "Second child height should be 40");

    return true;
}

bool test_linear_layout_horizontal() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 100));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(80, 40);
    container.addChild(std::move(child1));
    container.addChild(std::move(child2));

    LinearLayout layout(LayoutOrientation::HORIZONTAL);
    layout.setSpacing(10);

    Size measured = layout.measure(container);
    // Major = 50 + 10 + 80 = 140, Minor = max(30, 40) = 40
    ASSERT(measured.width == 140, "Horizontal layout width should be 140");
    ASSERT(measured.height == 40, "Horizontal layout height should be 40");

    layout.layout(container);

    auto* c1 = container.getChild(0);
    auto* c2 = container.getChild(1);
    ASSERT(c1->getBounds().x == 0, "First child x should be 0");
    ASSERT(c1->getBounds().width == 50, "First child width should be 50");
    ASSERT(c2->getBounds().x == 60, "Second child x should be 60 (50+10 spacing)");
    ASSERT(c2->getBounds().width == 80, "Second child width should be 80");

    return true;
}

bool test_linear_layout_padding() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));
    container.setPadding(10);

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 20);
    container.addChild(std::move(child1));

    LinearLayout layout(LayoutOrientation::VERTICAL);

    Size measured = layout.measure(container);
    // 20 + 10 + 10 = 40 height, 50 + 10 + 10 = 70 width
    ASSERT(measured.height == 40, "Layout with padding height should be 40");
    ASSERT(measured.width == 70, "Layout with padding width should be 70");

    layout.layout(container);

    auto* c1 = container.getChild(0);
    ASSERT(c1->getBounds().x == 10, "Child x should be 10 (padding)");
    ASSERT(c1->getBounds().y == 10, "Child y should be 10 (padding)");

    return true;
}

bool test_linear_layout_gone() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 200));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(50, 40);
    child2->setVisibility(WidgetVisibility::GONE);
    auto child3 = std::make_unique<Widget>(4, "child3");
    child3->setPreferredSize(50, 20);
    container.addChild(std::move(child1));
    container.addChild(std::move(child2));
    container.addChild(std::move(child3));

    LinearLayout layout(LayoutOrientation::VERTICAL);
    layout.setSpacing(5);

    Size measured = layout.measure(container);
    // Only child1 + child3: 30 + 5 + 20 = 55
    ASSERT(measured.height == 55, "Layout with GONE child height should be 55");
    ASSERT(measured.width == 50, "Layout with GONE child width should be 50");

    layout.layout(container);

    auto* c1 = container.getChild(0);
    auto* c3 = container.getChild(2);
    ASSERT(c1->getBounds().y == 0, "First child y should be 0");
    ASSERT(c3->getBounds().y == 35, "Third child y should be 35 (30+5)");

    return true;
}

bool test_frame_layout_basic() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(40, 20);
    container.addChild(std::move(child1));
    container.addChild(std::move(child2));

    FrameLayout layout;

    Size measured = layout.measure(container);
    // max(50, 40) = 50, max(30, 20) = 30
    ASSERT(measured.width == 50, "Frame layout width should be 50");
    ASSERT(measured.height == 30, "Frame layout height should be 30");

    layout.layout(container);

    auto* c1 = container.getChild(0);
    auto* c2 = container.getChild(1);
    // Both should be at top-left by default
    ASSERT(c1->getBounds().x == 0, "First child x should be 0");
    ASSERT(c1->getBounds().y == 0, "First child y should be 0");
    ASSERT(c2->getBounds().x == 0, "Second child x should be 0");
    ASSERT(c2->getBounds().y == 0, "Second child y should be 0");

    return true;
}

bool test_frame_layout_center() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    container.addChild(std::move(child1));

    FrameLayout layout;
    layout.setGravity(LayoutGravity::CENTER);

    layout.layout(container);

    auto* c1 = container.getChild(0);
    // Centered: x = (100-50)/2 = 25, y = (100-30)/2 = 35
    ASSERT(c1->getBounds().x == 25, "Centered child x should be 25");
    ASSERT(c1->getBounds().y == 35, "Centered child y should be 35");

    return true;
}

bool test_frame_layout_fill() {
    Widget container(1, "container");
    container.setBounds(Rect(10, 10, 80, 60));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    container.addChild(std::move(child1));

    FrameLayout layout;
    layout.setGravity(LayoutGravity::FILL);

    layout.layout(container);

    auto* c1 = container.getChild(0);
    ASSERT(c1->getBounds().x == 10, "FILL child x should be 10");
    ASSERT(c1->getBounds().y == 10, "FILL child y should be 10");
    ASSERT(c1->getBounds().width == 80, "FILL child width should be 80");
    ASSERT(c1->getBounds().height == 60, "FILL child height should be 60");

    return true;
}

bool test_linear_layout_center_gravity() {
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 20);
    container.addChild(std::move(child1));

    LinearLayout layout(LayoutOrientation::VERTICAL);
    layout.setGravity(LayoutGravity::CENTER);

    layout.layout(container);

    auto* c1 = container.getChild(0);
    // Centered vertically: y = (100-20)/2 = 40
    ASSERT(c1->getBounds().y == 40, "Center gravity child y should be 40");

    return true;
}

int main() {
    printf("=== Layout Tests ===\n");
    test_linear_layout_vertical();
    test_linear_layout_horizontal();
    test_linear_layout_padding();
    test_linear_layout_gone();
    test_frame_layout_basic();
    test_frame_layout_center();
    test_frame_layout_fill();
    test_linear_layout_center_gravity();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
