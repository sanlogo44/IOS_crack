// Test: Camera Manager
// v0.30.0 - License: GPL-3.0
//
// Unit tests for CameraManager lifecycle, camera control, permission/policy,
// session lifecycle, capture (single/burst), history/privacy, mock, privacy
// transform, events, stats, callbacks, failure simulation, LogServer/CrashReporter
// integration, string helpers and full workflow.

#include "phantom/camera/camera_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <cstring>
#include <iostream>
#include <vector>

using namespace phantom;
using namespace phantom::camera;

// ============================================================
// Test framework
// ============================================================

static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (cond) { g_tests_passed++; } \
    else { g_tests_failed++; \
        std::cout << "  [FAIL] " << #cond << " at " << __FILE__ << ":" << __LINE__ << std::endl; } \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))
#define ASSERT_EQ(a, b) ASSERT_TRUE((a) == (b))
#define ASSERT_STREQ(a, b) ASSERT_TRUE(std::string(a) == std::string(b))

// ============================================================
// Lifecycle tests
// ============================================================

void test_lifecycle() {
    CameraManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4, 10), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(0, 64, 4, 10), CameraResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 0, 4, 10), CameraResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 64, 0, 10), CameraResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 64, 4, 0), CameraResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4, 10), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(64, 64, 4, 10), CameraResult::ALREADY_INITIALIZED);
    ASSERT_EQ(mgr.shutdown(), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.shutdown(), CameraResult::NOT_INITIALIZED);
}

// ============================================================
// Camera control tests
// ============================================================

void test_camera_control() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);

    // Default: front and rear enabled
    ASSERT_TRUE(mgr.isCameraEnabled(CameraId::FRONT));
    ASSERT_TRUE(mgr.isCameraEnabled(CameraId::REAR));
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::DEPTH));
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::IR));
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::MOCK));

    // Enable depth
    ASSERT_EQ(mgr.setCameraEnabled(CameraId::DEPTH, true, "system"), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.isCameraEnabled(CameraId::DEPTH));

    // Non-system owner denied
    ASSERT_EQ(mgr.setCameraEnabled(CameraId::IR, true, "app"), CameraResult::PERMISSION_DENIED);
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::IR));

    // Disable front
    ASSERT_EQ(mgr.setCameraEnabled(CameraId::FRONT, false, "system"), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::FRONT));

    // Camera info
    auto info = mgr.getCameraInfo(CameraId::FRONT);
    ASSERT_FALSE(info.enabled);
    ASSERT_EQ(info.facing, CameraFacing::FRONT);

    // Get all cameras
    auto cameras = mgr.getCameras();
    ASSERT_EQ(cameras.size(), static_cast<size_t>(5));

    // Available cameras
    auto available = mgr.getAvailableCameras();
    ASSERT_TRUE(available.size() >= 2);
    mgr.shutdown();
}

void test_camera_control_failure_simulation() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setCameraEnabled(CameraId::DEPTH, true, "system"), CameraResult::SIMULATED_FAILURE);
    ASSERT_FALSE(mgr.isCameraEnabled(CameraId::DEPTH));
    mgr.shutdown();
}

// ============================================================
// Permission / policy tests
// ============================================================

void test_permission_deny() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    auto policy = mgr.getAppCameraPolicy("app.test");
    ASSERT_EQ(policy.permission, CameraPermission::DENY);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    mgr.shutdown();
}

void test_permission_allow_foreground() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_FOREGROUND,
                                     CameraPrivacyMode::FULL, CAMERA_PRIVACY_NONE, 0), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_EQ(mgr.setAppForeground("app.test", true), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_EQ(mgr.setAppForeground("app.test", false), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    mgr.shutdown();
}

void test_permission_allow_always() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                                     CameraPrivacyMode::FULL), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::REAR));
    mgr.shutdown();
}

void test_permission_allow_once() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ONCE,
                                     CameraPrivacyMode::FULL), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    // Consume via session
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    mgr.shutdown();
}

void test_permission_depth_disabled() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                                     CameraPrivacyMode::FULL,
                                     CAMERA_PRIVACY_DISABLE_DEPTH), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::DEPTH));
    mgr.shutdown();
}

void test_permission_ir_disabled() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                                     CameraPrivacyMode::FULL,
                                     CAMERA_PRIVACY_DISABLE_IR), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", CameraId::FRONT));
    ASSERT_FALSE(mgr.checkAppAccess("app.test", CameraId::IR));
    mgr.shutdown();
}

void test_permission_system_access() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_TRUE(mgr.checkAppAccess("system", CameraId::FRONT));
    ASSERT_TRUE(mgr.checkAppAccess("android", CameraId::REAR));
    ASSERT_TRUE(mgr.checkAppAccess("com.android.system", CameraId::DEPTH));
    mgr.shutdown();
}

void test_clear_app_policy() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_EQ(mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                                     CameraPrivacyMode::FULL), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.clearAppCameraPolicy("app.test", "system"), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getAppCameraPolicy("app.test").permission, CameraPermission::DENY);
    mgr.shutdown();
}

// ============================================================
// Session lifecycle tests
// ============================================================

void test_session_open_close() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_TRUE(sessionId > 0);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(1));

    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_session_permission_denied() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId),
              CameraResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_session_camera_busy() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    // Same camera by another session
    uint64_t sessionId2 = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId2),
              CameraResult::CAMERA_BUSY);
    mgr.shutdown();
}

void test_session_capacity() {
    CameraManager mgr;
    mgr.initialize(64, 64, 2, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    mgr.setCameraEnabled(CameraId::DEPTH, true, "system");

    uint64_t s1 = 0, s2 = 0, s3 = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &s1), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.openSession("app.test", CameraId::REAR, 0, &s2), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.openSession("app.test", CameraId::DEPTH, 0, &s3),
              CameraResult::CAPACITY_EXCEEDED);
    mgr.shutdown();
}

void test_session_camera_disabled() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    mgr.setCameraEnabled(CameraId::FRONT, false, "system");

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId),
              CameraResult::CAMERA_NOT_AVAILABLE);
    mgr.shutdown();
}

void test_session_owner_check() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.closeSession(sessionId, "other.app"), CameraResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), CameraResult::SUCCESS);
    mgr.shutdown();
}

void test_session_expiry() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    mgr.setCurrentTimeForTesting(100);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 50, &sessionId), CameraResult::SUCCESS);
    mgr.setCurrentTimeForTesting(200);
    ASSERT_EQ(mgr.processSessions(), CameraResult::SUCCESS);

    auto sessions = mgr.getActiveSessions();
    ASSERT_TRUE(sessions.empty());
    mgr.shutdown();
}

void test_session_failure_simulation() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    mgr.setFailNextOperation(true);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId),
              CameraResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Capture tests
// ============================================================

void test_capture_single() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(1));

    auto sessions = mgr.getActiveSessions();
    ASSERT_EQ(sessions.size(), static_cast<size_t>(1));
    ASSERT_EQ(sessions[0].captureCount, static_cast<uint32_t>(1));
    mgr.shutdown();
}

void test_capture_burst() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::BURST, 5), CameraResult::SUCCESS);

    auto sessions = mgr.getActiveSessions();
    ASSERT_EQ(sessions[0].captureCount, static_cast<uint32_t>(5));
    mgr.shutdown();
}

void test_capture_burst_limit() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 5);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::BURST, 100), CameraResult::SUCCESS);

    auto sessions = mgr.getActiveSessions();
    ASSERT_EQ(sessions[0].captureCount, static_cast<uint32_t>(5));
    mgr.shutdown();
}

void test_capture_permission_denied() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId),
              CameraResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_capture_bad_state() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1),
              CameraResult::BAD_STATE);
    mgr.shutdown();
}

void test_capture_rate_limited() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL, CAMERA_PRIVACY_NONE, 1);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1), CameraResult::SUCCESS);
    // Immediately another capture should be rate limited (1 fps)
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1),
              CameraResult::RATE_LIMITED);
    mgr.shutdown();
}

void test_capture_failure_simulation() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1),
              CameraResult::CAPTURE_FAILED);
    mgr.shutdown();
}

// ============================================================
// getLastFrame tests
// ============================================================

void test_get_last_frame() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1), CameraResult::SUCCESS);

    CameraFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", CameraId::FRONT, frame), CameraResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);
    mgr.shutdown();
}

void test_get_last_frame_permission_denied() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    CameraFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", CameraId::FRONT, frame),
              CameraResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_get_last_frame_unavailable() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    CameraFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", CameraId::FRONT, frame),
              CameraResult::CAMERA_NOT_AVAILABLE);
    mgr.shutdown();
}

void test_request_single_capture() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    ASSERT_EQ(mgr.requestSingleCapture("app.test", CameraId::FRONT, 0),
              CameraResult::SUCCESS);

    CameraFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", CameraId::FRONT, frame), CameraResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);
    mgr.shutdown();
}

// ============================================================
// History / privacy tests
// ============================================================

void test_history() {
    CameraManager mgr;
    mgr.initialize(128, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1), CameraResult::SUCCESS);

    auto history = mgr.getHistory("app.test");
    ASSERT_TRUE(history.size() >= 1);
    mgr.shutdown();
}

void test_history_capacity() {
    CameraManager mgr;
    mgr.initialize(5, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    for (int i = 0; i < 20; ++i) {
        mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    }
    ASSERT_TRUE(mgr.getHistoryCount() <= 5);
    mgr.shutdown();
}

void test_history_clear() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    ASSERT_TRUE(mgr.getHistoryCount() > 0);
    ASSERT_EQ(mgr.clearHistory("system"), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_history_no_history_flag() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL, CAMERA_PRIVACY_NO_HISTORY);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

// ============================================================
// Mock tests
// ============================================================

void test_mock_frame() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL, CAMERA_PRIVACY_MOCK_ALLOWED);
    mgr.setCameraEnabled(CameraId::MOCK, true, "system");

    CameraFrame frame;
    frame.width = 640;
    frame.height = 480;
    frame.format = 2;

    ASSERT_EQ(mgr.setMockFrame(CameraId::MOCK, frame, "app.test"), CameraResult::SUCCESS);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::MOCK, 0, &sessionId), CameraResult::SUCCESS);
    mgr.setMockEnabled(true, "system");
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    ASSERT_TRUE(mgr.getStats().capturesCompleted >= 1);
    mgr.shutdown();
}

void test_mock_not_allowed() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    CameraFrame frame;
    frame.width = 640;
    frame.height = 480;
    ASSERT_EQ(mgr.setMockFrame(CameraId::MOCK, frame, "app.test"),
              CameraResult::MOCK_NOT_ALLOWED);
    mgr.shutdown();
}

void test_mock_enabled() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    ASSERT_FALSE(mgr.isMockEnabled());
    ASSERT_EQ(mgr.setMockEnabled(true, "system"), CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.isMockEnabled());
    mgr.shutdown();
}

// ============================================================
// Privacy transform tests
// ============================================================

void test_privacy_transform_full() {
    CameraFrame frame;
    frame.width = 1920;
    frame.height = 1080;
    frame.format = 1;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = CameraManager::applyPrivacyTransform(frame, CameraPrivacyMode::FULL,
                                                       CAMERA_PRIVACY_NONE);
    ASSERT_EQ(result.width, static_cast<uint32_t>(1920));
    ASSERT_EQ(result.height, static_cast<uint32_t>(1080));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0xFF));
}

void test_privacy_transform_redacted() {
    CameraFrame frame;
    frame.width = 1920;
    frame.height = 1080;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = CameraManager::applyPrivacyTransform(frame, CameraPrivacyMode::REDACTED,
                                                       CAMERA_PRIVACY_NONE);
    ASSERT_EQ(result.width, static_cast<uint32_t>(1920 / 8));
    ASSERT_EQ(result.height, static_cast<uint32_t>(1080 / 8));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0));
}

void test_privacy_transform_metadata_only() {
    CameraFrame frame;
    frame.width = 1920;
    frame.height = 1080;
    frame.format = 1;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = CameraManager::applyPrivacyTransform(frame, CameraPrivacyMode::METADATA_ONLY,
                                                       CAMERA_PRIVACY_NONE);
    ASSERT_EQ(result.width, static_cast<uint32_t>(0));
    ASSERT_EQ(result.height, static_cast<uint32_t>(0));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0));
}

void test_privacy_transform_low_res() {
    CameraFrame frame;
    frame.width = 1920;
    frame.height = 1080;

    auto result = CameraManager::applyPrivacyTransform(frame, CameraPrivacyMode::FULL,
                                                       CAMERA_PRIVACY_LOW_RES_STUB);
    ASSERT_EQ(result.width, static_cast<uint32_t>(1920 / 4));
    ASSERT_EQ(result.height, static_cast<uint32_t>(1080 / 4));
}

void test_privacy_transform_redact_metadata() {
    CameraFrame frame;
    frame.format = 42;

    auto result = CameraManager::applyPrivacyTransform(frame, CameraPrivacyMode::FULL,
                                                       CAMERA_PRIVACY_REDACT_METADATA);
    ASSERT_EQ(result.format, static_cast<uint32_t>(0));
}

// ============================================================
// Privacy indicator tests
// ============================================================

void test_privacy_indicator() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    ASSERT_TRUE(mgr.getActiveCameraUsers().empty());

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);

    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());
    ASSERT_EQ(mgr.getActiveCameraUsers().size(), static_cast<size_t>(1));
    ASSERT_TRUE(mgr.getLastAccessTime() > 0);

    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    ASSERT_TRUE(mgr.getActiveCameraUsers().empty());
    mgr.shutdown();
}

// ============================================================
// Events tests
// ============================================================

void test_events() {
    CameraManager mgr;
    mgr.initialize(64, 256, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    mgr.closeSession(sessionId, "app.test");

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 3);

    auto byType = mgr.getEventsByType(CameraEventType::SESSION_STARTED);
    ASSERT_TRUE(byType.size() >= 1);

    ASSERT_EQ(mgr.clearEvents(), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_events_capacity() {
    CameraManager mgr;
    mgr.initialize(64, 5, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId), CameraResult::SUCCESS);
    for (int i = 0; i < 20; ++i) {
        mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    }
    ASSERT_TRUE(mgr.getEventCount() <= 5);
    mgr.shutdown();
}

void test_event_fields() {
    CameraManager mgr;
    mgr.initialize(64, 256, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);

    auto events = mgr.getEventsByType(CameraEventType::SESSION_STARTED);
    if (!events.empty()) {
        ASSERT_TRUE(events[0].timestamp > 0);
        ASSERT_STREQ(events[0].appId.c_str(), "app.test");
        ASSERT_EQ(events[0].camera, CameraId::FRONT);
        ASSERT_EQ(events[0].sessionId, sessionId);
    }
    mgr.shutdown();
}

// ============================================================
// Stats tests
// ============================================================

void test_stats() {
    CameraManager mgr;
    mgr.initialize(64, 256, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    mgr.closeSession(sessionId, "app.test");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.sessionsStarted >= 1);
    ASSERT_TRUE(stats.capturesCompleted >= 1);
    ASSERT_TRUE(stats.byCamera[0] >= 1);
    mgr.shutdown();
}

void test_stats_reset() {
    CameraManager mgr;
    mgr.initialize(64, 256, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.sessionsStarted > 0);

    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.sessionsStarted, static_cast<uint64_t>(0));
    mgr.shutdown();
}

// ============================================================
// Callbacks tests
// ============================================================

void test_frame_callback() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    std::string receivedApp;
    uint32_t receivedWidth = 0;
    mgr.setFrameCallback([&](const CameraFrame& frame, const std::string& appId) {
        receivedApp = appId;
        receivedWidth = frame.width;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1);
    ASSERT_EQ(receivedApp, "app.test");
    ASSERT_TRUE(receivedWidth > 0);
    mgr.shutdown();
}

void test_access_callback() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);

    std::string receivedApp;
    CameraResult receivedResult = CameraResult::SUCCESS;
    mgr.setAccessCallback([&](const std::string& appId, CameraResult result) {
        receivedApp = appId;
        receivedResult = result;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    ASSERT_EQ(receivedApp, "app.test");
    ASSERT_EQ(receivedResult, CameraResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_event_callback() {
    CameraManager mgr;
    mgr.initialize(64, 256, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    CameraEventType receivedType = CameraEventType::CAMERA_OPENED;
    uint64_t receivedId = 0;
    mgr.setEventCallback([&](const CameraEvent& event) {
        receivedType = event.type;
        receivedId = event.id;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    ASSERT_EQ(receivedType, CameraEventType::SESSION_STARTED);
    ASSERT_TRUE(receivedId > 0);
    mgr.shutdown();
}

// ============================================================
// Failure simulation tests
// ============================================================

void test_failure_set_camera_enabled() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setCameraEnabled(CameraId::DEPTH, true, "system"),
              CameraResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

void test_failure_capture() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", CameraId::FRONT, 0, &sessionId);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.capture(sessionId, "app.test", CaptureMode::SINGLE, 1),
              CameraResult::CAPTURE_FAILED);
    mgr.shutdown();
}

// ============================================================
// LogServer / CrashReporter integration tests
// ============================================================

void test_logserver_integration() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    logging::LogServer logServer;
    logServer.initialize(256);
    mgr.setLogServer(&logServer);

    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    ASSERT_TRUE(logServer.getLogCount() > 0);

    // Verify no raw frame data is logged
    auto logs = logServer.getLogs();
    bool foundRawData = false;
    for (const auto& entry : logs) {
        if (entry.message.find("stubData") != std::string::npos ||
            entry.message.find("rawFrame") != std::string::npos) {
            foundRawData = true;
        }
    }
    ASSERT_FALSE(foundRawData);
    mgr.shutdown();
}

void test_crashreporter_integration() {
    CameraManager mgr;
    mgr.initialize(64, 64, 4, 10);
    crashreporter::CrashReporter reporter;
    mgr.setCrashReporter(&reporter);
    mgr.setAppCameraPolicy("app.test", CameraPermission::ALLOW_ALWAYS,
                            CameraPrivacyMode::FULL);
    // CrashReporter is called for ANR-like conditions; just verify it's set
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    mgr.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

void test_string_helpers() {
    ASSERT_STREQ(CameraManager::cameraIdToString(CameraId::FRONT), "FRONT");
    ASSERT_STREQ(CameraManager::cameraIdToString(CameraId::REAR), "REAR");
    ASSERT_STREQ(CameraManager::cameraIdToString(CameraId::DEPTH), "DEPTH");
    ASSERT_STREQ(CameraManager::cameraIdToString(CameraId::IR), "IR");
    ASSERT_STREQ(CameraManager::cameraIdToString(CameraId::MOCK), "MOCK");

    ASSERT_STREQ(CameraManager::cameraStateToString(CameraState::CLOSED), "CLOSED");
    ASSERT_STREQ(CameraManager::cameraStateToString(CameraState::OPEN), "OPEN");
    ASSERT_STREQ(CameraManager::cameraStateToString(CameraState::CAPTURING), "CAPTURING");

    ASSERT_STREQ(CameraManager::cameraFacingToString(CameraFacing::FRONT), "FRONT");
    ASSERT_STREQ(CameraManager::cameraFacingToString(CameraFacing::BACK), "BACK");

    ASSERT_STREQ(CameraManager::cameraPermissionToString(CameraPermission::DENY), "DENY");
    ASSERT_STREQ(CameraManager::cameraPermissionToString(CameraPermission::ALLOW_FOREGROUND), "ALLOW_FOREGROUND");
    ASSERT_STREQ(CameraManager::cameraPermissionToString(CameraPermission::ALLOW_ALWAYS), "ALLOW_ALWAYS");
    ASSERT_STREQ(CameraManager::cameraPermissionToString(CameraPermission::ALLOW_ONCE), "ALLOW_ONCE");

    ASSERT_STREQ(CameraManager::requestStateToString(CameraRequestState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(CameraManager::requestStateToString(CameraRequestState::EXPIRED), "EXPIRED");

    ASSERT_STREQ(CameraManager::cameraPrivacyModeToString(CameraPrivacyMode::FULL), "FULL");
    ASSERT_STREQ(CameraManager::cameraPrivacyModeToString(CameraPrivacyMode::REDACTED), "REDACTED");
    ASSERT_STREQ(CameraManager::cameraPrivacyModeToString(CameraPrivacyMode::METADATA_ONLY), "METADATA_ONLY");

    ASSERT_STREQ(CameraManager::captureModeToString(CaptureMode::SINGLE), "SINGLE");
    ASSERT_STREQ(CameraManager::captureModeToString(CaptureMode::BURST), "BURST");

    ASSERT_STREQ(CameraManager::cameraResultToString(CameraResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(CameraManager::cameraResultToString(CameraResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(CameraManager::cameraResultToString(CameraResult::CAMERA_BUSY), "CAMERA_BUSY");

    ASSERT_STREQ(CameraManager::cameraEventTypeToString(CameraEventType::CAMERA_OPENED), "CAMERA_OPENED");
    ASSERT_STREQ(CameraManager::cameraEventTypeToString(CameraEventType::SESSION_STARTED), "SESSION_STARTED");
    ASSERT_STREQ(CameraManager::cameraEventTypeToString(CameraEventType::CAPTURE_COMPLETED), "CAPTURE_COMPLETED");

    ASSERT_EQ(CameraManager::stringToCameraId("FRONT"), CameraId::FRONT);
    ASSERT_EQ(CameraManager::stringToCameraId("REAR"), CameraId::REAR);
    ASSERT_EQ(CameraManager::stringToCameraId("MOCK"), CameraId::MOCK);

    ASSERT_EQ(CameraManager::stringToCameraResult("SUCCESS"), CameraResult::SUCCESS);
    ASSERT_EQ(CameraManager::stringToCameraResult("PERMISSION_DENIED"), CameraResult::PERMISSION_DENIED);
}

// ============================================================
// Full workflow test
// ============================================================

void test_full_workflow() {
    CameraManager mgr;
    mgr.initialize(256, 256, 4, 10);

    // 1. Setup app policy
    ASSERT_EQ(mgr.setAppCameraPolicy("com.test.app", CameraPermission::ALLOW_FOREGROUND,
                                     CameraPrivacyMode::FULL,
                                     CAMERA_PRIVACY_REQUIRE_FOREGROUND), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.setAppForeground("com.test.app", true), CameraResult::SUCCESS);

    // 2. Open session
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("com.test.app", CameraId::FRONT, 100, &sessionId),
              CameraResult::SUCCESS);
    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());

    // 3. Single capture
    ASSERT_EQ(mgr.capture(sessionId, "com.test.app", CaptureMode::SINGLE, 1),
              CameraResult::SUCCESS);

    // 4. Burst capture
    ASSERT_EQ(mgr.capture(sessionId, "com.test.app", CaptureMode::BURST, 3),
              CameraResult::SUCCESS);

    // 5. Get last frame
    CameraFrame frame;
    ASSERT_EQ(mgr.getLastFrame("com.test.app", CameraId::FRONT, frame),
              CameraResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);

    // 6. Check history
    auto history = mgr.getHistory("com.test.app");
    ASSERT_TRUE(history.size() >= 4);

    // 7. Check events
    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 4);

    // 8. Check stats
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.capturesCompleted >= 2);
    ASSERT_TRUE(stats.burstCaptures >= 1);

    // 9. Close session
    ASSERT_EQ(mgr.closeSession(sessionId, "com.test.app"), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());

    // 10. System access
    ASSERT_TRUE(mgr.checkAppAccess("system", CameraId::FRONT));

    // 11. Clear history
    ASSERT_EQ(mgr.clearHistory("system"), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));

    // 12. Clear events
    ASSERT_EQ(mgr.clearEvents(), CameraResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));

    // 13. Reset stats
    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.capturesCompleted, static_cast<uint64_t>(0));

    // 14. Shutdown
    ASSERT_EQ(mgr.shutdown(), CameraResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Camera Manager Tests ===" << std::endl;

    // Lifecycle
    std::cout << "Testing lifecycle..." << std::endl;
    test_lifecycle();

    // Camera control
    std::cout << "Testing camera control..." << std::endl;
    test_camera_control();
    test_camera_control_failure_simulation();

    // Permission / policy
    std::cout << "Testing permission/policy..." << std::endl;
    test_permission_deny();
    test_permission_allow_foreground();
    test_permission_allow_always();
    test_permission_allow_once();
    test_permission_depth_disabled();
    test_permission_ir_disabled();
    test_permission_system_access();
    test_clear_app_policy();

    // Session lifecycle
    std::cout << "Testing session lifecycle..." << std::endl;
    test_session_open_close();
    test_session_permission_denied();
    test_session_camera_busy();
    test_session_capacity();
    test_session_camera_disabled();
    test_session_owner_check();
    test_session_expiry();
    test_session_failure_simulation();

    // Capture
    std::cout << "Testing capture..." << std::endl;
    test_capture_single();
    test_capture_burst();
    test_capture_burst_limit();
    test_capture_permission_denied();
    test_capture_bad_state();
    test_capture_rate_limited();
    test_capture_failure_simulation();

    // getLastFrame
    std::cout << "Testing getLastFrame..." << std::endl;
    test_get_last_frame();
    test_get_last_frame_permission_denied();
    test_get_last_frame_unavailable();
    test_request_single_capture();

    // History / privacy
    std::cout << "Testing history/privacy..." << std::endl;
    test_history();
    test_history_capacity();
    test_history_clear();
    test_history_no_history_flag();

    // Mock
    std::cout << "Testing mock..." << std::endl;
    test_mock_frame();
    test_mock_not_allowed();
    test_mock_enabled();

    // Privacy transform
    std::cout << "Testing privacy transform..." << std::endl;
    test_privacy_transform_full();
    test_privacy_transform_redacted();
    test_privacy_transform_metadata_only();
    test_privacy_transform_low_res();
    test_privacy_transform_redact_metadata();

    // Privacy indicator
    std::cout << "Testing privacy indicator..." << std::endl;
    test_privacy_indicator();

    // Events
    std::cout << "Testing events..." << std::endl;
    test_events();
    test_events_capacity();
    test_event_fields();

    // Stats
    std::cout << "Testing stats..." << std::endl;
    test_stats();
    test_stats_reset();

    // Callbacks
    std::cout << "Testing callbacks..." << std::endl;
    test_frame_callback();
    test_access_callback();
    test_event_callback();

    // Failure simulation
    std::cout << "Testing failure simulation..." << std::endl;
    test_failure_set_camera_enabled();
    test_failure_capture();

    // LogServer / CrashReporter
    std::cout << "Testing LogServer/CrashReporter integration..." << std::endl;
    test_logserver_integration();
    test_crashreporter_integration();

    // String helpers
    std::cout << "Testing string helpers..." << std::endl;
    test_string_helpers();

    // Full workflow
    std::cout << "Testing full workflow..." << std::endl;
    test_full_workflow();

    std::cout << std::endl;
    std::cout << "=== Results ===" << std::endl;
    std::cout << "Total: " << g_tests_run << ", Passed: " << g_tests_passed
              << ", Failed: " << g_tests_failed << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
