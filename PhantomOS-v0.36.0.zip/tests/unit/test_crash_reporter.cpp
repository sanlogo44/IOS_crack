/*
 * Phantom OS - Crash Reporter Unit Tests
 * v0.19.0
 * License: GPL-3.0
 */

#include "phantom/crashreporter/crash_reporter.h"
#include "phantom/logging/log_server.h"
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>

using namespace phantom::crashreporter;
using namespace phantom::logging;

static int tests_passed = 0;
static int tests_failed = 0;

#define ASSERT_TRUE(expr) do { \
    if (!(expr)) { printf("FAIL: %s:%d: %s\n", __FILE__, __LINE__, #expr); tests_failed++; return; } \
    tests_passed++; \
} while(0)

#define ASSERT_EQ(a, b) do { \
    if (!((a) == (b))) { printf("FAIL: %s:%d: %s != %s\n", __FILE__, __LINE__, #a, #b); tests_failed++; return; } \
    tests_passed++; \
} while(0)

#define ASSERT_FALSE(expr) ASSERT_TRUE(!(expr))
#define ASSERT_STREQ(a, b) ASSERT_TRUE(std::string(a) == std::string(b))

#define RUN_TEST(test) do { \
    printf("  Running %s\n", #test); \
    test(); \
} while(0)

// ============================================================
// Helper: create a stack trace
// ============================================================

static std::vector<StackFrame> makeStackTrace(const std::string& func1, const std::string& lib1) {
    std::vector<StackFrame> trace;
    StackFrame f1;
    f1.function = func1;
    f1.library = lib1;
    f1.address = 0x4000;
    f1.filename = "/data/app/test.cpp";
    f1.line = 42;
    trace.push_back(f1);

    StackFrame f2;
    f2.function = "main";
    f2.library = "app";
    f2.address = 0x5000;
    f2.filename = "/data/app/main.cpp";
    f2.line = 10;
    trace.push_back(f2);

    return trace;
}

static CrashReport makeReport(const std::string& appId = "com.app",
                              CrashType type = CrashType::SIGSEGV) {
    CrashReport report;
    report.appId = appId;
    report.processName = "test_process";
    report.appVersion = "1.0.0";
    report.pid = 1234;
    report.threadId = 5678;
    report.type = type;
    report.severity = CrashSeverity::MAJOR;
    report.signal = 11;
    report.signalCode = 1;
    report.crashReason = "Null pointer dereference";
    report.stackTrace = makeStackTrace("crash_function", "libtest.so");
    report.memoryUsage = 1024 * 1024;
    report.deviceState = "Screen on, Battery 85%";
    return report;
}

// ============================================================
// Lifecycle tests
// ============================================================

static void testInitialize() {
    CrashReporter mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), CrashResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), CrashResult::ALREADY_INITIALIZED);
}

static void testShutdown() {
    CrashReporter mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.shutdown(), CrashResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), CrashResult::NOT_INITIALIZED);
}

static void testReinitialize() {
    CrashReporter mgr;
    mgr.initialize(100, 200);
    mgr.captureCrash(makeReport());
    mgr.shutdown();
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(50, 100), CrashResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
}

static void testMaxQueueSize() {
    CrashReporter mgr;
    mgr.initialize(3, 100);
    for (int i = 0; i < 5; ++i) {
        CrashReport r = makeReport();
        r.appId = "com.app" + std::to_string(i);
        mgr.captureCrash(r);
    }
    // Queue should be capped at 3, oldest ones archived
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(3));
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(2));
}

// ============================================================
// Capture tests
// ============================================================

static void testCaptureCrash() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_TRUE(id > 0);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));

    auto report = mgr.getById(id);
    ASSERT_EQ(report.id, id);
    ASSERT_STREQ(report.appId.c_str(), "com.app");
    ASSERT_EQ(report.type, CrashType::SIGSEGV);
    ASSERT_EQ(report.state, CrashState::CAPTURED);
}

static void testCaptureSignalCrash() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureSignalCrash("com.app", "test", 1234, 11, 1,
                                          "SIGSEGV", makeStackTrace("func", "lib"));
    ASSERT_TRUE(id > 0);
    auto report = mgr.getById(id);
    ASSERT_EQ(report.type, CrashType::SIGSEGV);
    ASSERT_EQ(report.signal, 11);
    ASSERT_EQ(report.severity, CrashSeverity::FATAL);
}

static void testCaptureAnr() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureAnr("com.app", "test", 1234, "UI thread blocked");
    ASSERT_TRUE(id > 0);
    auto report = mgr.getById(id);
    ASSERT_EQ(report.type, CrashType::ANR);
    ASSERT_EQ(report.severity, CrashSeverity::MAJOR);
}

static void testCaptureOom() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::FULL);
    uint64_t id = mgr.captureOom("com.app", "test", 1234, 500 * 1024 * 1024);
    ASSERT_TRUE(id > 0);
    auto report = mgr.getById(id);
    ASSERT_EQ(report.type, CrashType::OOM);
    ASSERT_EQ(report.severity, CrashSeverity::CRITICAL);
    ASSERT_EQ(report.memoryUsage, static_cast<uint64_t>(500 * 1024 * 1024));
}

static void testCaptureInvalidReport() {
    CrashReporter mgr;
    mgr.initialize();
    // Empty appId should be rejected
    CrashReport r = makeReport();
    r.appId = "";
    uint64_t id = mgr.captureCrash(r);
    ASSERT_EQ(id, static_cast<uint64_t>(0));
}

static void testCaptureWhenDisabled() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::DISABLED);
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(id, static_cast<uint64_t>(0));
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
}

static void testCaptureAssignsId() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id1 = mgr.captureCrash(makeReport("com.app1"));
    uint64_t id2 = mgr.captureCrash(makeReport("com.app2"));
    ASSERT_TRUE(id2 > id1);
}

// ============================================================
// Deduplication tests
// ============================================================

static void testDeduplicateSameStack() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport();
    r1.appId = "com.app";
    uint64_t id1 = mgr.captureCrash(r1);

    CrashReport r2 = makeReport();
    r2.appId = "com.app";  // Same app, same crash
    uint64_t id2 = mgr.captureCrash(r2);

    // First should be captured, second should be deduplicated
    ASSERT_TRUE(id1 > 0);
    ASSERT_EQ(id2, static_cast<uint64_t>(0));  // Duplicate
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalDeduplicated > 0);
}

static void testDifferentStackDifferentGroup() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport();
    r1.crashReason = "Null pointer";
    mgr.captureCrash(r1);

    CrashReport r2 = makeReport();
    r2.crashReason = "Buffer overflow";  // Different reason
    r2.stackTrace = makeStackTrace("other_func", "other.so");
    mgr.captureCrash(r2);

    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getGroupCount(), static_cast<size_t>(2));
}

static void testCrashHashDeterministic() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport();
    CrashReport r2 = makeReport();

    std::string hash1 = mgr.computeCrashHash(r1);
    std::string hash2 = mgr.computeCrashHash(r2);
    ASSERT_STREQ(hash1.c_str(), hash2.c_str());
}

static void testGroupCount() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1"));
    mgr.captureCrash(makeReport("com.app2"));
    mgr.captureCrash(makeReport("com.app3"));
    ASSERT_EQ(mgr.getGroupCount(), static_cast<size_t>(3));
}

static void testGetGroup() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r = makeReport();
    mgr.captureCrash(r);

    auto groups = mgr.getGroups();
    ASSERT_EQ(groups.size(), static_cast<size_t>(1));
    ASSERT_EQ(groups[0].count, static_cast<uint32_t>(1));
    ASSERT_STREQ(groups[0].appId.c_str(), "com.app");
}

static void testGroupCrashCount() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r = makeReport();
    uint64_t id = mgr.captureCrash(r);
    std::string hash = mgr.getById(id).crashHash;
    ASSERT_EQ(mgr.getGroupCrashCount(hash), static_cast<size_t>(1));
}

// ============================================================
// Rate limiting tests
// ============================================================

static void testRateLimiting() {
    CrashReporter mgr;
    mgr.initialize(500, 1000);
    mgr.setMaxCrashesPerHour(3);

    for (int i = 0; i < 3; ++i) {
        CrashReport r = makeReport();
        r.appId = "com.app" + std::to_string(i);
        mgr.captureCrash(r);
    }
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(3));

    // 4th should be rate limited
    CrashReport r4 = makeReport();
    r4.appId = "com.app4";
    uint64_t id = mgr.captureCrash(r4);
    ASSERT_EQ(id, static_cast<uint64_t>(0));
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(3));
}

// ============================================================
// Privacy scrubbing tests
// ============================================================

static void testScrubEmail() {
    CrashReporter mgr;
    std::string result = mgr.scrubEmail("Contact admin@example.com for help");
    ASSERT_TRUE(result.find("admin@example.com") == std::string::npos);
    ASSERT_TRUE(result.find("<email>") != std::string::npos);
}

static void testScrubPath() {
    CrashReporter mgr;
    std::string result = mgr.scrubPath("File at /data/app/test.cpp line 42");
    ASSERT_TRUE(result.find("/data/app/test.cpp") == std::string::npos);
    ASSERT_TRUE(result.find("<path>") != std::string::npos);
}

static void testScrubIpAddress() {
    CrashReporter mgr;
    std::string result = mgr.scrubIpAddress("Connected to 192.168.1.100");
    ASSERT_TRUE(result.find("192.168.1.100") == std::string::npos);
    ASSERT_TRUE(result.find("<ip>") != std::string::npos);
}

static void testScrubMemoryAddress() {
    CrashReporter mgr;
    std::string result = mgr.scrubMemoryAddress("Access at 0x7fff12345678");
    ASSERT_TRUE(result.find("0x7fff12345678") == std::string::npos);
    ASSERT_TRUE(result.find("<addr>") != std::string::npos);
}

static void testScrubDeviceId() {
    CrashReporter mgr;
    std::string result = mgr.scrubDeviceId("Device: 550e8400-e29b-41d4-a716-446655440000");
    ASSERT_TRUE(result.find("550e8400-e29b-41d4-a716-446655440000") == std::string::npos);
    ASSERT_TRUE(result.find("<uuid>") != std::string::npos);
}

static void testScrubUsername() {
    CrashReporter mgr;
    std::string result = mgr.scrubUsername("Log at /home/johndoe/app.log");
    ASSERT_TRUE(result.find("johndoe") == std::string::npos);
    ASSERT_TRUE(result.find("<user>") != std::string::npos);
}

static void testScrubAll() {
    CrashReporter mgr;
    std::string input = "User admin@test.com at /home/user/app, IP 10.0.0.1, addr 0xdeadbeef";
    std::string result = mgr.scrubAll(input);
    ASSERT_TRUE(result.find("admin@test.com") == std::string::npos);
    ASSERT_TRUE(result.find("/home/user/app") == std::string::npos);
    ASSERT_TRUE(result.find("10.0.0.1") == std::string::npos);
    ASSERT_TRUE(result.find("0xdeadbeef") == std::string::npos);
}

static void testPrivacyFull() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::FULL);
    CrashReport r = makeReport();
    r.crashLog = "Log output with /home/user info";
    uint64_t id = mgr.captureCrash(r);
    auto report = mgr.getById(id);
    // Full privacy: crash reason should be preserved
    ASSERT_TRUE(!report.crashReason.empty());
    ASSERT_TRUE(!report.crashLog.empty());
}

static void testPrivacyAnonymized() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::ANONYMIZED);
    CrashReport r = makeReport();
    r.crashReason = "Error at /data/app/file.txt with admin@test.com";
    uint64_t id = mgr.captureCrash(r);
    auto report = mgr.getById(id);
    // Anonymized: paths and emails should be scrubbed
    ASSERT_TRUE(report.crashReason.find("/data/app") == std::string::npos);
    ASSERT_TRUE(report.crashReason.find("admin@test.com") == std::string::npos);
    ASSERT_EQ(report.memoryUsage, static_cast<uint64_t>(0));
}

static void testPrivacyMinimal() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::MINIMAL);
    uint64_t id = mgr.captureCrash(makeReport());
    auto report = mgr.getById(id);
    // Minimal: only crash type, app, stack trace hash
    ASSERT_TRUE(report.crashReason.empty());
    ASSERT_TRUE(report.crashLog.empty());
    ASSERT_TRUE(report.processName.empty());
    ASSERT_EQ(report.memoryUsage, static_cast<uint64_t>(0));
    for (const auto& frame : report.stackTrace) {
        ASSERT_TRUE(frame.filename.empty());
        ASSERT_EQ(frame.address, static_cast<uint64_t>(0));
    }
}

static void testPrivacyDisabled() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setPrivacyLevel(CrashPrivacyLevel::DISABLED);
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(id, static_cast<uint64_t>(0));
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
}

// ============================================================
// Upload tests
// ============================================================

static void testQueueForUpload() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(mgr.queueForUpload(id), CrashResult::SUCCESS);
    auto report = mgr.getById(id);
    ASSERT_EQ(report.state, CrashState::QUEUED);
}

static void testQueueForUploadDisabled() {
    CrashReporter mgr;
    mgr.initialize();
    // Default policy is NEVER
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(mgr.queueForUpload(id), CrashResult::PRIVACY_DISABLED);
}

static void testMarkUploaded() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);
    ASSERT_EQ(mgr.markUploaded(id), CrashResult::SUCCESS);
    // Uploaded crashes are moved to archive
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalUploaded > 0);
}

static void testMarkUploadFailed() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    mgr.setMaxRetries(2);
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);

    // First failure
    ASSERT_EQ(mgr.markUploadFailed(id), CrashResult::SUCCESS);
    auto report = mgr.getById(id);
    ASSERT_EQ(report.state, CrashState::RETRYING);
    ASSERT_EQ(report.retryCount, static_cast<uint32_t>(1));

    // Second failure
    mgr.markUploadFailed(id);
    report = mgr.getById(id);
    ASSERT_EQ(report.retryCount, static_cast<uint32_t>(2));
    // After max retries, should be FAILED
    ASSERT_EQ(report.state, CrashState::FAILED);
}

static void testProcessUploadQueue() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    uint64_t id1 = mgr.captureCrash(makeReport("com.app1"));
    uint64_t id2 = mgr.captureCrash(makeReport("com.app2"));
    mgr.queueForUpload(id1);
    mgr.queueForUpload(id2);
    mgr.processUploadQueue();
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalUploaded >= 2);
}

// ============================================================
// Archive tests
// ============================================================

static void testArchive() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(mgr.archive(id), CrashResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(1));
}

static void testDismiss() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(mgr.dismiss(id), CrashResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
}

static void testClearArchive() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.archive(id);
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(1));
    mgr.clearArchive();
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(0));
}

static void testClearAll() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1"));
    mgr.captureCrash(makeReport("com.app2"));
    mgr.archive(1);
    mgr.clearAll();
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getGroupCount(), static_cast<size_t>(0));
}

// ============================================================
// Query tests
// ============================================================

static void testGetActive() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1"));
    mgr.captureCrash(makeReport("com.app2"));
    ASSERT_EQ(mgr.getActive().size(), static_cast<size_t>(2));
}

static void testGetArchive() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.archive(id);
    ASSERT_EQ(mgr.getArchive().size(), static_cast<size_t>(1));
}

static void testGetRecent() {
    CrashReporter mgr;
    mgr.initialize();
    for (int i = 0; i < 5; ++i) {
        mgr.captureCrash(makeReport("com.app" + std::to_string(i)));
    }
    auto recent = mgr.getRecent(3);
    ASSERT_EQ(recent.size(), static_cast<size_t>(3));
}

static void testGetByApp() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Null pointer";
    mgr.captureCrash(r1);
    mgr.captureCrash(makeReport("com.app2"));
    CrashReport r3 = makeReport("com.app1");
    r3.crashReason = "Buffer overflow";
    r3.stackTrace = makeStackTrace("other_func", "other.so");
    mgr.captureCrash(r3);
    ASSERT_EQ(mgr.getByApp("com.app1").size(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getByApp("com.app2").size(), static_cast<size_t>(1));
}

static void testGetByType() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1", CrashType::SIGSEGV));
    mgr.captureCrash(makeReport("com.app2", CrashType::SIGABRT));
    mgr.captureCrash(makeReport("com.app3", CrashType::SIGSEGV));
    ASSERT_EQ(mgr.getByType(CrashType::SIGSEGV).size(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getByType(CrashType::SIGABRT).size(), static_cast<size_t>(1));
}

static void testGetBySeverity() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport();
    r1.severity = CrashSeverity::FATAL;
    r1.crashReason = "Fatal error";
    mgr.captureCrash(r1);

    CrashReport r2 = makeReport();
    r2.severity = CrashSeverity::MINOR;
    r2.crashReason = "Minor issue";
    r2.stackTrace = makeStackTrace("minor_func", "minor.so");
    mgr.captureCrash(r2);

    ASSERT_EQ(mgr.getBySeverity(CrashSeverity::FATAL).size(), static_cast<size_t>(1));
    ASSERT_EQ(mgr.getBySeverity(CrashSeverity::MINOR).size(), static_cast<size_t>(1));
}

static void testGetByState() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);
    ASSERT_EQ(mgr.getByState(CrashState::QUEUED).size(), static_cast<size_t>(1));
}

static void testGetByGroup() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    std::string hash = mgr.getById(id).crashHash;
    auto groupCrashes = mgr.getByGroup(hash);
    ASSERT_EQ(groupCrashes.size(), static_cast<size_t>(1));
}

static void testGetById() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    auto report = mgr.getById(id);
    ASSERT_EQ(report.id, id);
}

static void testGetByIdNotFound() {
    CrashReporter mgr;
    mgr.initialize();
    auto report = mgr.getById(99999);
    ASSERT_EQ(report.id, static_cast<uint64_t>(0));
}

static void testGetCountByApp() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Error 1";
    mgr.captureCrash(r1);
    CrashReport r2 = makeReport("com.app1");
    r2.crashReason = "Error 2";
    r2.stackTrace = makeStackTrace("func2", "lib2.so");
    mgr.captureCrash(r2);
    mgr.captureCrash(makeReport("com.app2"));
    ASSERT_EQ(mgr.getCountByApp("com.app1"), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getCountByApp("com.app2"), static_cast<size_t>(1));
}

static void testGetCountByType() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1", CrashType::SIGSEGV));
    mgr.captureCrash(makeReport("com.app2", CrashType::SIGSEGV));
    ASSERT_EQ(mgr.getCountByType(CrashType::SIGSEGV), static_cast<size_t>(2));
}

static void testGetCountBySeverity() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r = makeReport();
    r.severity = CrashSeverity::CRITICAL;
    mgr.captureCrash(r);
    ASSERT_EQ(mgr.getCountBySeverity(CrashSeverity::CRITICAL), static_cast<size_t>(1));
}

// ============================================================
// Processing tests
// ============================================================

static void testProcessPending() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.processPending();
    auto report = mgr.getById(id);
    ASSERT_EQ(report.state, CrashState::QUEUED);
}

static void testProcessRetries() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    mgr.setMaxRetries(3);
    mgr.setRetryBaseDelayMs(1);  // 1ms for fast testing

    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);
    mgr.markUploadFailed(id);

    auto report = mgr.getById(id);
    ASSERT_EQ(report.state, CrashState::RETRYING);

    // Wait for retry time to pass, then process
    mgr.processRetries(999999999);
}

static void testMaxRetriesExceeded() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    mgr.setMaxRetries(1);

    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);

    mgr.markUploadFailed(id);  // retry 1
    mgr.markUploadFailed(id);  // exceeds max
    auto report = mgr.getById(id);
    ASSERT_EQ(report.state, CrashState::FAILED);
}

// ============================================================
// Callback tests
// ============================================================

static void testCapturedCallback() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport captured;
    mgr.setCapturedCallback([&](const CrashReport& r) { captured = r; });
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_EQ(captured.id, id);
}

static void testUploadedCallback() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    CrashReport uploaded;
    mgr.setUploadedCallback([&](const CrashReport& r) { uploaded = r; });
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);
    mgr.markUploaded(id);
    ASSERT_EQ(uploaded.id, id);
}

static void testFailedCallback() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    mgr.setMaxRetries(0);  // No retries

    CrashReport failed;
    mgr.setFailedCallback([&](const CrashReport& r) { failed = r; });
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.queueForUpload(id);
    mgr.markUploadFailed(id);
    ASSERT_EQ(failed.id, id);
}

static void testArchivedCallback() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t archivedId = 0;
    mgr.setArchivedCallback([&](const CrashReport& r) { archivedId = r.id; });
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.archive(id);
    ASSERT_EQ(archivedId, id);
}

// ============================================================
// Stats tests
// ============================================================

static void testStats() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1", CrashType::SIGSEGV));
    mgr.captureCrash(makeReport("com.app2", CrashType::SIGABRT));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalCaptured, static_cast<uint64_t>(2));
    ASSERT_EQ(stats.activeQueueSize, static_cast<uint64_t>(2));
    ASSERT_TRUE(stats.totalGroups >= 2);
}

static void testStatsByType() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1", CrashType::SIGSEGV));
    mgr.captureCrash(makeReport("com.app2", CrashType::SIGSEGV));
    mgr.captureCrash(makeReport("com.app3", CrashType::SIGABRT));

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalByType[static_cast<int>(CrashType::SIGSEGV)] >= 2);
    ASSERT_TRUE(stats.totalByType[static_cast<int>(CrashType::SIGABRT)] >= 1);
}

static void testStatsByApp() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Error 1";
    mgr.captureCrash(r1);
    CrashReport r2 = makeReport("com.app1");
    r2.crashReason = "Error 2";
    r2.stackTrace = makeStackTrace("func2", "lib2.so");
    mgr.captureCrash(r2);
    mgr.captureCrash(makeReport("com.app2"));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.perAppCounts.at("com.app1"), static_cast<uint64_t>(2));
    ASSERT_EQ(stats.perAppCounts.at("com.app2"), static_cast<uint64_t>(1));
}

static void testResetStats() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport());
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalCaptured > 0);

    mgr.resetStats();
    stats = mgr.getStats();
    ASSERT_EQ(stats.totalCaptured, static_cast<uint64_t>(0));
}

// ============================================================
// Export tests
// ============================================================

static void testExportText() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    std::string exported = mgr.exportReport(id, "text");
    ASSERT_TRUE(exported.find("Crash Report") != std::string::npos);
    ASSERT_TRUE(exported.find("com.app") != std::string::npos);
    ASSERT_TRUE(exported.find("SIGSEGV") != std::string::npos);
}

static void testExportCsv() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    std::string exported = mgr.exportReport(id, "csv");
    ASSERT_TRUE(exported.find("id,appId,processName") != std::string::npos);
    ASSERT_TRUE(exported.find("com.app") != std::string::npos);
}

static void testProcessUploadQueueMultiple() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.setUploadPolicy(CrashUploadPolicy::ALWAYS);
    uint64_t id1 = mgr.captureCrash(makeReport("com.app1"));
    uint64_t id2 = mgr.captureCrash(makeReport("com.app2"));
    uint64_t id3 = mgr.captureCrash(makeReport("com.app3"));
    mgr.queueForUpload(id1);
    mgr.queueForUpload(id2);
    mgr.queueForUpload(id3);
    mgr.processUploadQueue();
    // All should be uploaded and moved to archive
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getArchiveCount(), static_cast<size_t>(3));
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalUploaded >= 3);
}

static void testGetByStateAfterArchive() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    mgr.archive(id);
    // Should find archived crash by state
    auto archived = mgr.getByState(CrashState::ARCHIVED);
    ASSERT_EQ(archived.size(), static_cast<size_t>(1));
}

static void testGetByAppAfterArchive() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Error 1";
    mgr.captureCrash(r1);
    CrashReport r2 = makeReport("com.app1");
    r2.crashReason = "Error 2";
    r2.stackTrace = makeStackTrace("func2", "lib2.so");
    mgr.captureCrash(r2);
    mgr.archive(1);
    // Should find both: one in archive, one in active
    auto all = mgr.getByApp("com.app1");
    ASSERT_EQ(all.size(), static_cast<size_t>(2));
}

static void testGetByTypeAfterArchive() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport("com.app", CrashType::SIGSEGV));
    mgr.archive(id);
    auto sigsegvs = mgr.getByType(CrashType::SIGSEGV);
    ASSERT_EQ(sigsegvs.size(), static_cast<size_t>(1));
}

static void testGetCountByAppAfterArchive() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Error 1";
    mgr.captureCrash(r1);
    CrashReport r2 = makeReport("com.app1");
    r2.crashReason = "Error 2";
    r2.stackTrace = makeStackTrace("func2", "lib2.so");
    mgr.captureCrash(r2);
    mgr.archive(1);
    // Count should include archived
    ASSERT_EQ(mgr.getCountByApp("com.app1"), static_cast<size_t>(2));
}

static void testStatsPerAppAfterArchive() {
    CrashReporter mgr;
    mgr.initialize();
    CrashReport r1 = makeReport("com.app1");
    r1.crashReason = "Error 1";
    mgr.captureCrash(r1);
    mgr.archive(r1.id);
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.perAppCounts.at("com.app1"), static_cast<uint64_t>(1));
}

static void testExportNotFound() {
    CrashReporter mgr;
    mgr.initialize();
    std::string exported = mgr.exportReport(99999, "text");
    ASSERT_STREQ(exported.c_str(), "Report not found");
}

static void testExportAll() {
    CrashReporter mgr;
    mgr.initialize();
    mgr.captureCrash(makeReport("com.app1"));
    mgr.captureCrash(makeReport("com.app2"));
    std::string exported = mgr.exportAll("text");
    ASSERT_TRUE(exported.find("com.app1") != std::string::npos);
    ASSERT_TRUE(exported.find("com.app2") != std::string::npos);
}

// ============================================================
// File save tests
// ============================================================

static void testSaveReportToFile() {
    CrashReporter mgr;
    mgr.initialize();
    uint64_t id = mgr.captureCrash(makeReport());
    bool result = mgr.saveReportToFile(id, "/tmp/test_crash_report.txt");
    ASSERT_TRUE(result);

    FILE* f = fopen("/tmp/test_crash_report.txt", "r");
    ASSERT_TRUE(f != nullptr);
    char buf[256];
    if (fgets(buf, sizeof(buf), f)) { /* read line */ }
    fclose(f);
    ASSERT_TRUE(std::string(buf).find("Crash Report") != std::string::npos);
}

// ============================================================
// LogServer integration tests
// ============================================================

static void testLogServerIntegration() {
    CrashReporter mgr;
    LogServer logger;
    logger.initialize(100);

    mgr.initialize();
    mgr.setLogServer(&logger);
    mgr.captureCrash(makeReport());

    // Verify the crash was logged
    auto errors = logger.getLogsByLevel(LogLevel::ERROR);
    ASSERT_TRUE(errors.size() > 0);
}

static void testNoLoggerBehavior() {
    CrashReporter mgr;
    mgr.initialize();
    // No log server set - should still work
    uint64_t id = mgr.captureCrash(makeReport());
    ASSERT_TRUE(id > 0);
}

// ============================================================
// String helper tests
// ============================================================

static void testCrashTypeToString() {
    ASSERT_STREQ(CrashReporter::crashTypeToString(CrashType::SIGSEGV), "SIGSEGV");
    ASSERT_STREQ(CrashReporter::crashTypeToString(CrashType::OOM), "OOM");
    ASSERT_STREQ(CrashReporter::crashTypeToString(CrashType::ANR), "ANR");
    ASSERT_STREQ(CrashReporter::crashTypeToString(CrashType::UNKNOWN), "UNKNOWN");
}

static void testCrashSeverityToString() {
    ASSERT_STREQ(CrashReporter::crashSeverityToString(CrashSeverity::FATAL), "FATAL");
    ASSERT_STREQ(CrashReporter::crashSeverityToString(CrashSeverity::CRITICAL), "CRITICAL");
    ASSERT_STREQ(CrashReporter::crashSeverityToString(CrashSeverity::MAJOR), "MAJOR");
    ASSERT_STREQ(CrashReporter::crashSeverityToString(CrashSeverity::MINOR), "MINOR");
}

static void testCrashStateToString() {
    ASSERT_STREQ(CrashReporter::crashStateToString(CrashState::CAPTURED), "CAPTURED");
    ASSERT_STREQ(CrashReporter::crashStateToString(CrashState::QUEUED), "QUEUED");
    ASSERT_STREQ(CrashReporter::crashStateToString(CrashState::FAILED), "FAILED");
}

static void testPrivacyLevelToString() {
    ASSERT_STREQ(CrashReporter::privacyLevelToString(CrashPrivacyLevel::FULL), "FULL");
    ASSERT_STREQ(CrashReporter::privacyLevelToString(CrashPrivacyLevel::ANONYMIZED), "ANONYMIZED");
    ASSERT_STREQ(CrashReporter::privacyLevelToString(CrashPrivacyLevel::MINIMAL), "MINIMAL");
    ASSERT_STREQ(CrashReporter::privacyLevelToString(CrashPrivacyLevel::DISABLED), "DISABLED");
}

static void testStringToCrashType() {
    ASSERT_EQ(CrashReporter::stringToCrashType("SIGSEGV"), CrashType::SIGSEGV);
    ASSERT_EQ(CrashReporter::stringToCrashType("OOM"), CrashType::OOM);
    ASSERT_EQ(CrashReporter::stringToCrashType("ANR"), CrashType::ANR);
    ASSERT_EQ(CrashReporter::stringToCrashType("UNKNOWN"), CrashType::UNKNOWN);
    ASSERT_EQ(CrashReporter::stringToCrashType("INVALID"), CrashType::UNKNOWN);
}

static void testStringToCrashSeverity() {
    ASSERT_EQ(CrashReporter::stringToCrashSeverity("FATAL"), CrashSeverity::FATAL);
    ASSERT_EQ(CrashReporter::stringToCrashSeverity("CRITICAL"), CrashSeverity::CRITICAL);
    ASSERT_EQ(CrashReporter::stringToCrashSeverity("INVALID"), CrashSeverity::MAJOR);
}

static void testStringToCrashState() {
    ASSERT_EQ(CrashReporter::stringToCrashState("CAPTURED"), CrashState::CAPTURED);
    ASSERT_EQ(CrashReporter::stringToCrashState("QUEUED"), CrashState::QUEUED);
    ASSERT_EQ(CrashReporter::stringToCrashState("FAILED"), CrashState::FAILED);
    ASSERT_EQ(CrashReporter::stringToCrashState("INVALID"), CrashState::CAPTURED);
}

static void testStringToPrivacyLevel() {
    ASSERT_EQ(CrashReporter::stringToPrivacyLevel("FULL"), CrashPrivacyLevel::FULL);
    ASSERT_EQ(CrashReporter::stringToPrivacyLevel("ANONYMIZED"), CrashPrivacyLevel::ANONYMIZED);
    ASSERT_EQ(CrashReporter::stringToPrivacyLevel("MINIMAL"), CrashPrivacyLevel::MINIMAL);
    ASSERT_EQ(CrashReporter::stringToPrivacyLevel("DISABLED"), CrashPrivacyLevel::DISABLED);
    ASSERT_EQ(CrashReporter::stringToPrivacyLevel("INVALID"), CrashPrivacyLevel::MINIMAL);
}

static void testSignalToCrashType() {
    ASSERT_EQ(CrashReporter::signalToCrashType(11), CrashType::SIGSEGV);
    ASSERT_EQ(CrashReporter::signalToCrashType(6), CrashType::SIGABRT);
    ASSERT_EQ(CrashReporter::signalToCrashType(8), CrashType::SIGFPE);
    ASSERT_EQ(CrashReporter::signalToCrashType(4), CrashType::SIGILL);
    ASSERT_EQ(CrashReporter::signalToCrashType(7), CrashType::SIGBUS);
    ASSERT_EQ(CrashReporter::signalToCrashType(13), CrashType::SIGPIPE);
    ASSERT_EQ(CrashReporter::signalToCrashType(15), CrashType::SIGTERM);
    ASSERT_EQ(CrashReporter::signalToCrashType(9), CrashType::SIGKILL);
    ASSERT_EQ(CrashReporter::signalToCrashType(999), CrashType::UNKNOWN);
}

static void testCrashResultToString() {
    ASSERT_STREQ(CrashReporter::crashResultToString(CrashResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(CrashReporter::crashResultToString(CrashResult::NOT_FOUND), "NOT_FOUND");
    ASSERT_STREQ(CrashReporter::crashResultToString(CrashResult::DUPLICATE_CRASH), "DUPLICATE_CRASH");
    ASSERT_STREQ(CrashReporter::crashResultToString(CrashResult::RATE_LIMITED), "RATE_LIMITED");
}

static void testUploadPolicyToString() {
    ASSERT_STREQ(CrashReporter::uploadPolicyToString(CrashUploadPolicy::NEVER), "NEVER");
    ASSERT_STREQ(CrashReporter::uploadPolicyToString(CrashUploadPolicy::WIFI_ONLY), "WIFI_ONLY");
    ASSERT_STREQ(CrashReporter::uploadPolicyToString(CrashUploadPolicy::ALWAYS), "ALWAYS");
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("=== Crash Reporter Unit Tests ===\n\n");

    printf("Lifecycle tests:\n");
    RUN_TEST(testInitialize);
    RUN_TEST(testShutdown);
    RUN_TEST(testReinitialize);
    RUN_TEST(testMaxQueueSize);

    printf("\nCapture tests:\n");
    RUN_TEST(testCaptureCrash);
    RUN_TEST(testCaptureSignalCrash);
    RUN_TEST(testCaptureAnr);
    RUN_TEST(testCaptureOom);
    RUN_TEST(testCaptureInvalidReport);
    RUN_TEST(testCaptureWhenDisabled);
    RUN_TEST(testCaptureAssignsId);

    printf("\nDeduplication tests:\n");
    RUN_TEST(testDeduplicateSameStack);
    RUN_TEST(testDifferentStackDifferentGroup);
    RUN_TEST(testCrashHashDeterministic);
    RUN_TEST(testGroupCount);
    RUN_TEST(testGetGroup);
    RUN_TEST(testGroupCrashCount);

    printf("\nRate limiting tests:\n");
    RUN_TEST(testRateLimiting);

    printf("\nPrivacy scrubbing tests:\n");
    RUN_TEST(testScrubEmail);
    RUN_TEST(testScrubPath);
    RUN_TEST(testScrubIpAddress);
    RUN_TEST(testScrubMemoryAddress);
    RUN_TEST(testScrubDeviceId);
    RUN_TEST(testScrubUsername);
    RUN_TEST(testScrubAll);

    printf("\nPrivacy level tests:\n");
    RUN_TEST(testPrivacyFull);
    RUN_TEST(testPrivacyAnonymized);
    RUN_TEST(testPrivacyMinimal);
    RUN_TEST(testPrivacyDisabled);

    printf("\nUpload tests:\n");
    RUN_TEST(testQueueForUpload);
    RUN_TEST(testQueueForUploadDisabled);
    RUN_TEST(testMarkUploaded);
    RUN_TEST(testMarkUploadFailed);
    RUN_TEST(testProcessUploadQueue);
    RUN_TEST(testProcessUploadQueueMultiple);
    RUN_TEST(testGetByStateAfterArchive);
    RUN_TEST(testGetByAppAfterArchive);
    RUN_TEST(testGetByTypeAfterArchive);
    RUN_TEST(testGetCountByAppAfterArchive);
    RUN_TEST(testStatsPerAppAfterArchive);

    printf("\nArchive tests:\n");
    RUN_TEST(testArchive);
    RUN_TEST(testDismiss);
    RUN_TEST(testClearArchive);
    RUN_TEST(testClearAll);

    printf("\nQuery tests:\n");
    RUN_TEST(testGetActive);
    RUN_TEST(testGetArchive);
    RUN_TEST(testGetRecent);
    RUN_TEST(testGetByApp);
    RUN_TEST(testGetByType);
    RUN_TEST(testGetBySeverity);
    RUN_TEST(testGetByState);
    RUN_TEST(testGetByGroup);
    RUN_TEST(testGetById);
    RUN_TEST(testGetByIdNotFound);
    RUN_TEST(testGetCountByApp);
    RUN_TEST(testGetCountByType);
    RUN_TEST(testGetCountBySeverity);

    printf("\nProcessing tests:\n");
    RUN_TEST(testProcessPending);
    RUN_TEST(testProcessRetries);
    RUN_TEST(testMaxRetriesExceeded);

    printf("\nCallback tests:\n");
    RUN_TEST(testCapturedCallback);
    RUN_TEST(testUploadedCallback);
    RUN_TEST(testFailedCallback);
    RUN_TEST(testArchivedCallback);

    printf("\nStats tests:\n");
    RUN_TEST(testStats);
    RUN_TEST(testStatsByType);
    RUN_TEST(testStatsByApp);
    RUN_TEST(testResetStats);

    printf("\nExport tests:\n");
    RUN_TEST(testExportText);
    RUN_TEST(testExportCsv);
    RUN_TEST(testExportNotFound);
    RUN_TEST(testExportAll);

    printf("\nFile save tests:\n");
    RUN_TEST(testSaveReportToFile);

    printf("\nLogServer integration tests:\n");
    RUN_TEST(testLogServerIntegration);
    RUN_TEST(testNoLoggerBehavior);

    printf("\nString helper tests:\n");
    RUN_TEST(testCrashTypeToString);
    RUN_TEST(testCrashSeverityToString);
    RUN_TEST(testCrashStateToString);
    RUN_TEST(testPrivacyLevelToString);
    RUN_TEST(testStringToCrashType);
    RUN_TEST(testStringToCrashSeverity);
    RUN_TEST(testStringToCrashState);
    RUN_TEST(testStringToPrivacyLevel);
    RUN_TEST(testSignalToCrashType);
    RUN_TEST(testCrashResultToString);
    RUN_TEST(testUploadPolicyToString);

    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);

    return tests_failed > 0 ? 1 : 0;
}
