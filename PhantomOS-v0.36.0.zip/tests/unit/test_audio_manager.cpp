// Test: Audio / Microphone Manager
// v0.31.0 - License: GPL-3.0
//
// Unit tests for AudioManager lifecycle, device control, routing, permission/policy,
// session lifecycle (open/close/pause/resume), capture, history/privacy, mock,
// privacy transform, privacy indicator, events, stats, callbacks, failure
// simulation, LogServer/CrashReporter integration, string helpers, full workflow.

#include "phantom/audio/audio_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <cstring>
#include <iostream>
#include <vector>

using namespace phantom;
using namespace phantom::audio;

// ============================================================
// Test framework
// ============================================================

static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (cond) { g_tests_passed++; } \
    else { g_tests_failed++; \
        std::cout << "  [FAIL] " << #cond << " at " << __FILE__ << ":" << __LINE__ << std::endl; } \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))
#define ASSERT_EQ(a, b) ASSERT_TRUE((a) == (b))
#define ASSERT_STREQ(a, b) ASSERT_TRUE(std::string(a) == std::string(b))

// ============================================================
// Lifecycle tests
// ============================================================

void test_lifecycle() {
    AudioManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(0, 64, 4), AudioResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 0, 4), AudioResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 64, 0), AudioResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(64, 64, 4), AudioResult::ALREADY_INITIALIZED);
    ASSERT_EQ(mgr.shutdown(), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.shutdown(), AudioResult::NOT_INITIALIZED);
}

// ============================================================
// Device control tests
// ============================================================

void test_device_control() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);

    // Default: built-in mic, speaker, receiver enabled
    ASSERT_TRUE(mgr.isDeviceEnabled(AudioDevice::BUILT_IN_MIC));
    ASSERT_TRUE(mgr.isDeviceEnabled(AudioDevice::SPEAKER));
    ASSERT_TRUE(mgr.isDeviceEnabled(AudioDevice::RECEIVER));
    ASSERT_FALSE(mgr.isDeviceEnabled(AudioDevice::WIRED_HEADSET));
    ASSERT_FALSE(mgr.isDeviceEnabled(AudioDevice::BLUETOOTH));
    ASSERT_FALSE(mgr.isDeviceEnabled(AudioDevice::MOCK));

    // Enable wired headset
    ASSERT_EQ(mgr.setDeviceEnabled(AudioDevice::WIRED_HEADSET, true, "system"), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.isDeviceEnabled(AudioDevice::WIRED_HEADSET));

    // Non-system owner denied
    ASSERT_EQ(mgr.setDeviceEnabled(AudioDevice::BLUETOOTH, true, "app"), AudioResult::PERMISSION_DENIED);
    ASSERT_FALSE(mgr.isDeviceEnabled(AudioDevice::BLUETOOTH));

    // Disable mic
    ASSERT_EQ(mgr.setDeviceEnabled(AudioDevice::BUILT_IN_MIC, false, "system"), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isDeviceEnabled(AudioDevice::BUILT_IN_MIC));

    // Device info
    auto info = mgr.getDeviceInfo(AudioDevice::BUILT_IN_MIC);
    ASSERT_FALSE(info.enabled);
    ASSERT_TRUE(info.isInput);
    ASSERT_FALSE(info.isOutput);

    auto speakerInfo = mgr.getDeviceInfo(AudioDevice::SPEAKER);
    ASSERT_TRUE(speakerInfo.isOutput);
    ASSERT_FALSE(speakerInfo.isInput);

    // Get all devices
    auto devices = mgr.getDevices();
    ASSERT_EQ(devices.size(), static_cast<size_t>(6));

    // Available devices
    auto available = mgr.getAvailableDevices();
    ASSERT_TRUE(available.size() >= 2);
    mgr.shutdown();
}

void test_device_control_failure() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setDeviceEnabled(AudioDevice::BLUETOOTH, true, "system"),
              AudioResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Routing tests
// ============================================================

void test_routing() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);

    ASSERT_EQ(mgr.getCurrentRoute(), AudioRoute::SPEAKER);
    ASSERT_EQ(mgr.setRoute(AudioRoute::RECEIVER, "system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getCurrentRoute(), AudioRoute::RECEIVER);
    ASSERT_EQ(mgr.setRoute(AudioRoute::BLUETOOTH, "system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getCurrentRoute(), AudioRoute::BLUETOOTH);

    // Non-system denied
    ASSERT_EQ(mgr.setRoute(AudioRoute::SPEAKER, "app"), AudioResult::PERMISSION_DENIED);

    // Mute/volume
    ASSERT_EQ(mgr.setMuted(true, "system"), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.isMuted());
    ASSERT_EQ(mgr.setMuted(false, "system"), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isMuted());

    ASSERT_EQ(mgr.setVolume(75, "system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getVolume(), static_cast<uint8_t>(75));
    ASSERT_EQ(mgr.setVolume(200, "system"), AudioResult::INVALID_PARAMETER);
    mgr.shutdown();
}

void test_routing_failure() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setRoute(AudioRoute::BLUETOOTH, "system"),
              AudioResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Permission / policy tests
// ============================================================

void test_permission_deny() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    auto policy = mgr.getAppAudioPolicy("app.test");
    ASSERT_EQ(policy.permission, AudioPermission::DENY);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    mgr.shutdown();
}

void test_permission_allow_foreground() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_FOREGROUND,
                                     AudioPrivacyMode::FULL), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    ASSERT_EQ(mgr.setAppForeground("app.test", true), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    ASSERT_EQ(mgr.setAppForeground("app.test", false), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    mgr.shutdown();
}

void test_permission_allow_always() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                                     AudioPrivacyMode::FULL), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::SPEAKER));
    mgr.shutdown();
}

void test_permission_allow_once() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ONCE,
                                     AudioPrivacyMode::FULL), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    // Consume via session
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    mgr.shutdown();
}

void test_permission_bluetooth_disabled() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setDeviceEnabled(AudioDevice::BLUETOOTH, true, "system");
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                                     AudioPrivacyMode::FULL,
                                     AUDIO_PRIVACY_DISABLE_BLUETOOTH), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test", AudioDevice::BUILT_IN_MIC));
    ASSERT_FALSE(mgr.checkAppAccess("app.test", AudioDevice::BLUETOOTH));
    mgr.shutdown();
}

void test_permission_system_access() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_TRUE(mgr.checkAppAccess("system", AudioDevice::BUILT_IN_MIC));
    ASSERT_TRUE(mgr.checkAppAccess("android", AudioDevice::SPEAKER));
    ASSERT_TRUE(mgr.checkAppAccess("com.android.system", AudioDevice::RECEIVER));
    mgr.shutdown();
}

void test_clear_app_policy() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                                     AudioPrivacyMode::FULL), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.clearAppAudioPolicy("app.test", "system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getAppAudioPolicy("app.test").permission, AudioPermission::DENY);
    mgr.shutdown();
}

void test_policy_failure() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                                     AudioPrivacyMode::FULL), AudioResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Session lifecycle tests
// ============================================================

void test_session_open_close() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_TRUE(sessionId > 0);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(1));

    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_session_permission_denied() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId),
              AudioResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_session_device_busy() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    uint64_t sessionId2 = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId2),
              AudioResult::DEVICE_BUSY);
    mgr.shutdown();
}

void test_session_capacity() {
    AudioManager mgr;
    mgr.initialize(64, 64, 2);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);
    mgr.setDeviceEnabled(AudioDevice::WIRED_HEADSET, true, "system");

    uint64_t s1 = 0, s2 = 0, s3 = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &s1), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::SPEAKER,
                              AudioCaptureMode::RECORD, 0, &s2), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::WIRED_HEADSET,
                              AudioCaptureMode::RECORD, 0, &s3),
              AudioResult::CAPACITY_EXCEEDED);
    mgr.shutdown();
}

void test_session_device_disabled() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);
    mgr.setDeviceEnabled(AudioDevice::BUILT_IN_MIC, false, "system");

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId),
              AudioResult::DEVICE_NOT_AVAILABLE);
    mgr.shutdown();
}

void test_session_owner_check() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.closeSession(sessionId, "other.app"), AudioResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), AudioResult::SUCCESS);
    mgr.shutdown();
}

void test_session_expiry() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    mgr.setCurrentTimeForTesting(100);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 50, &sessionId), AudioResult::SUCCESS);
    mgr.setCurrentTimeForTesting(200);
    ASSERT_EQ(mgr.processSessions(), AudioResult::SUCCESS);

    auto sessions = mgr.getActiveSessions();
    ASSERT_TRUE(sessions.empty());
    mgr.shutdown();
}

void test_session_pause_resume() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.pauseSession(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(0));
    // Capture should fail while paused
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::BAD_STATE);
    ASSERT_EQ(mgr.resumeSession(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveSessionCount(), static_cast<size_t>(1));
    // Capture should work after resume
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);
    mgr.shutdown();
}

void test_session_failure() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);
    mgr.setFailNextOperation(true);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId),
              AudioResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Capture tests
// ============================================================

void test_capture_frame() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);

    auto sessions = mgr.getActiveSessions();
    ASSERT_EQ(sessions[0].captureCount, static_cast<uint32_t>(1));
    mgr.shutdown();
}

void test_capture_permission_denied() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId),
              AudioResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_capture_bad_state() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::BAD_STATE);
    mgr.shutdown();
}

void test_capture_rate_limited() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL, AUDIO_PRIVACY_NONE, 1);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::RATE_LIMITED);
    mgr.shutdown();
}

void test_capture_failure() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::CAPTURE_FAILED);
    mgr.shutdown();
}

// ============================================================
// getLastFrame tests
// ============================================================

void test_get_last_frame() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);

    AudioFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", AudioDevice::BUILT_IN_MIC, frame), AudioResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);
    mgr.shutdown();
}

void test_get_last_frame_denied() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    AudioFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", AudioDevice::BUILT_IN_MIC, frame),
              AudioResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_get_last_frame_unavailable() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);
    AudioFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", AudioDevice::BUILT_IN_MIC, frame),
              AudioResult::DEVICE_NOT_AVAILABLE);
    mgr.shutdown();
}

void test_request_single_capture() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    ASSERT_EQ(mgr.requestSingleCapture("app.test", AudioDevice::BUILT_IN_MIC, 0),
              AudioResult::SUCCESS);

    AudioFrame frame;
    ASSERT_EQ(mgr.getLastFrame("app.test", AudioDevice::BUILT_IN_MIC, frame), AudioResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);
    mgr.shutdown();
}

// ============================================================
// History / privacy tests
// ============================================================

void test_history() {
    AudioManager mgr;
    mgr.initialize(128, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::SUCCESS);

    auto history = mgr.getHistory("app.test");
    ASSERT_TRUE(history.size() >= 1);
    mgr.shutdown();
}

void test_history_capacity() {
    AudioManager mgr;
    mgr.initialize(5, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    for (int i = 0; i < 20; ++i) {
        mgr.captureFrame(sessionId, "app.test");
    }
    ASSERT_TRUE(mgr.getHistoryCount() <= 5);
    mgr.shutdown();
}

void test_history_clear() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    mgr.captureFrame(sessionId, "app.test");
    ASSERT_TRUE(mgr.getHistoryCount() > 0);
    ASSERT_EQ(mgr.clearHistory("system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_history_no_history_flag() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL, AUDIO_PRIVACY_NO_HISTORY);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    mgr.captureFrame(sessionId, "app.test");
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

// ============================================================
// Mock tests
// ============================================================

void test_mock_frame() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL, AUDIO_PRIVACY_MOCK_ALLOWED);
    mgr.setDeviceEnabled(AudioDevice::MOCK, true, "system");

    AudioFrame frame;
    frame.sampleRate = 44100;
    frame.channels = 2;
    frame.frameSize = 512;

    ASSERT_EQ(mgr.setMockFrame(AudioDevice::MOCK, frame, "app.test"), AudioResult::SUCCESS);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::MOCK,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    mgr.setMockEnabled(true, "system");
    mgr.captureFrame(sessionId, "app.test");
    ASSERT_TRUE(mgr.getStats().capturesCompleted >= 1);
    mgr.shutdown();
}

void test_mock_not_allowed() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    AudioFrame frame;
    frame.sampleRate = 44100;
    frame.channels = 2;
    ASSERT_EQ(mgr.setMockFrame(AudioDevice::MOCK, frame, "app.test"),
              AudioResult::MOCK_NOT_ALLOWED);
    mgr.shutdown();
}

void test_mock_enabled() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    ASSERT_FALSE(mgr.isMockEnabled());
    ASSERT_EQ(mgr.setMockEnabled(true, "system"), AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.isMockEnabled());
    mgr.shutdown();
}

// ============================================================
// Privacy transform tests
// ============================================================

void test_privacy_transform_full() {
    AudioFrame frame;
    frame.sampleRate = 48000;
    frame.channels = 2;
    frame.frameSize = 1024;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::FULL,
                                                      AUDIO_PRIVACY_NONE);
    ASSERT_EQ(result.sampleRate, static_cast<uint32_t>(48000));
    ASSERT_EQ(result.channels, static_cast<uint32_t>(2));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0xFF));
}

void test_privacy_transform_redacted() {
    AudioFrame frame;
    frame.sampleRate = 48000;
    frame.channels = 2;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::REDACTED,
                                                      AUDIO_PRIVACY_NONE);
    ASSERT_EQ(result.sampleRate, static_cast<uint32_t>(48000));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0));
}

void test_privacy_transform_metadata_only() {
    AudioFrame frame;
    frame.sampleRate = 48000;
    frame.channels = 2;
    frame.frameSize = 1024;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::METADATA_ONLY,
                                                      AUDIO_PRIVACY_NONE);
    ASSERT_EQ(result.sampleRate, static_cast<uint32_t>(0));
    ASSERT_EQ(result.channels, static_cast<uint32_t>(0));
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0));
}

void test_privacy_transform_low_sample_rate() {
    AudioFrame frame;
    frame.sampleRate = 48000;
    frame.channels = 2;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::FULL,
                                                      AUDIO_PRIVACY_LOW_SAMPLE_RATE);
    ASSERT_EQ(result.sampleRate, static_cast<uint32_t>(48000 / 4));
}

void test_privacy_transform_mute() {
    AudioFrame frame;
    for (int i = 0; i < 16; ++i) frame.stubData[i] = 0xFF;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::FULL,
                                                      AUDIO_PRIVACY_MUTE_STUB);
    ASSERT_EQ(result.stubData[0], static_cast<uint8_t>(0));
}

void test_privacy_transform_redact_metadata() {
    AudioFrame frame;
    frame.channels = 2;

    auto result = AudioManager::applyPrivacyTransform(frame, AudioPrivacyMode::FULL,
                                                      AUDIO_PRIVACY_REDACT_METADATA);
    ASSERT_EQ(result.channels, static_cast<uint32_t>(0));
}

// ============================================================
// Privacy indicator tests
// ============================================================

void test_privacy_indicator() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    ASSERT_TRUE(mgr.getActiveMicUsers().empty());

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);

    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());
    ASSERT_EQ(mgr.getActiveMicUsers().size(), static_cast<size_t>(1));
    ASSERT_TRUE(mgr.getLastAccessTime() > 0);

    ASSERT_EQ(mgr.closeSession(sessionId, "app.test"), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    ASSERT_TRUE(mgr.getActiveMicUsers().empty());
    mgr.shutdown();
}

void test_privacy_indicator_speaker_not_tracked() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    // Speaker is output-only, should not trigger mic indicator
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::SPEAKER,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    mgr.shutdown();
}

// ============================================================
// Events tests
// ============================================================

void test_events() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    mgr.captureFrame(sessionId, "app.test");
    mgr.closeSession(sessionId, "app.test");

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 3);

    auto byType = mgr.getEventsByType(AudioEventType::SESSION_STARTED);
    ASSERT_TRUE(byType.size() >= 1);

    ASSERT_EQ(mgr.clearEvents(), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_events_capacity() {
    AudioManager mgr;
    mgr.initialize(64, 5, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 0, &sessionId), AudioResult::SUCCESS);
    for (int i = 0; i < 20; ++i) {
        mgr.captureFrame(sessionId, "app.test");
    }
    ASSERT_TRUE(mgr.getEventCount() <= 5);
    mgr.shutdown();
}

void test_event_fields() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);

    auto events = mgr.getEventsByType(AudioEventType::SESSION_STARTED);
    if (!events.empty()) {
        ASSERT_TRUE(events[0].timestamp > 0);
        ASSERT_STREQ(events[0].appId.c_str(), "app.test");
        ASSERT_EQ(events[0].device, AudioDevice::BUILT_IN_MIC);
        ASSERT_EQ(events[0].sessionId, sessionId);
    }
    mgr.shutdown();
}

// ============================================================
// Stats tests
// ============================================================

void test_stats() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    mgr.captureFrame(sessionId, "app.test");
    mgr.closeSession(sessionId, "app.test");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.sessionsStarted >= 1);
    ASSERT_TRUE(stats.capturesCompleted >= 1);
    ASSERT_TRUE(stats.byDevice[0] >= 1);
    mgr.shutdown();
}

void test_stats_reset() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    mgr.captureFrame(sessionId, "app.test");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.sessionsStarted > 0);

    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.sessionsStarted, static_cast<uint64_t>(0));
    mgr.shutdown();
}

void test_stats_route_changes() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setRoute(AudioRoute::RECEIVER, "system");
    mgr.setRoute(AudioRoute::BLUETOOTH, "system");
    mgr.setRoute(AudioRoute::SPEAKER, "system");
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.routeChanges >= 3);
    mgr.shutdown();
}

// ============================================================
// Callbacks tests
// ============================================================

void test_frame_callback() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    std::string receivedApp;
    uint32_t receivedRate = 0;
    mgr.setFrameCallback([&](const AudioFrame& frame, const std::string& appId) {
        receivedApp = appId;
        receivedRate = frame.sampleRate;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    mgr.captureFrame(sessionId, "app.test");
    ASSERT_EQ(receivedApp, "app.test");
    ASSERT_TRUE(receivedRate > 0);
    mgr.shutdown();
}

void test_access_callback() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);

    std::string receivedApp;
    AudioResult receivedResult = AudioResult::SUCCESS;
    mgr.setAccessCallback([&](const std::string& appId, AudioResult result) {
        receivedApp = appId;
        receivedResult = result;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    ASSERT_EQ(receivedApp, "app.test");
    ASSERT_EQ(receivedResult, AudioResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_event_callback() {
    AudioManager mgr;
    mgr.initialize(64, 256, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    AudioEventType receivedType = AudioEventType::DEVICE_OPENED;
    uint64_t receivedId = 0;
    mgr.setEventCallback([&](const AudioEvent& event) {
        receivedType = event.type;
        receivedId = event.id;
    });

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    ASSERT_EQ(receivedType, AudioEventType::SESSION_STARTED);
    ASSERT_TRUE(receivedId > 0);
    mgr.shutdown();
}

// ============================================================
// Failure simulation tests
// ============================================================

void test_failure_set_device_enabled() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setDeviceEnabled(AudioDevice::BLUETOOTH, true, "system"),
              AudioResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

void test_failure_capture() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);

    uint64_t sessionId = 0;
    mgr.openSession("app.test", AudioDevice::BUILT_IN_MIC,
                    AudioCaptureMode::RECORD, 0, &sessionId);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.captureFrame(sessionId, "app.test"), AudioResult::CAPTURE_FAILED);
    mgr.shutdown();
}

// ============================================================
// LogServer / CrashReporter integration tests
// ============================================================

void test_logserver_integration() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    logging::LogServer logServer;
    logServer.initialize(256);
    mgr.setLogServer(&logServer);

    mgr.setAppAudioPolicy("app.test", AudioPermission::ALLOW_ALWAYS,
                            AudioPrivacyMode::FULL);
    ASSERT_TRUE(logServer.getLogCount() > 0);

    // Verify no raw audio data is logged
    auto logs = logServer.getLogs();
    bool foundRawData = false;
    for (const auto& entry : logs) {
        if (entry.message.find("stubData") != std::string::npos ||
            entry.message.find("rawFrame") != std::string::npos ||
            entry.message.find("samples") != std::string::npos) {
            foundRawData = true;
        }
    }
    ASSERT_FALSE(foundRawData);
    mgr.shutdown();
}

void test_crashreporter_integration() {
    AudioManager mgr;
    mgr.initialize(64, 64, 4);
    crashreporter::CrashReporter reporter;
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    mgr.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

void test_string_helpers() {
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::BUILT_IN_MIC), "BUILT_IN_MIC");
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::SPEAKER), "SPEAKER");
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::RECEIVER), "RECEIVER");
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::WIRED_HEADSET), "WIRED_HEADSET");
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::BLUETOOTH), "BLUETOOTH");
    ASSERT_STREQ(AudioManager::audioDeviceToString(AudioDevice::MOCK), "MOCK");

    ASSERT_STREQ(AudioManager::audioRouteToString(AudioRoute::SPEAKER), "SPEAKER");
    ASSERT_STREQ(AudioManager::audioRouteToString(AudioRoute::RECEIVER), "RECEIVER");
    ASSERT_STREQ(AudioManager::audioRouteToString(AudioRoute::BLUETOOTH), "BLUETOOTH");

    ASSERT_STREQ(AudioManager::audioStateToString(AudioState::IDLE), "IDLE");
    ASSERT_STREQ(AudioManager::audioStateToString(AudioState::RECORDING), "RECORDING");
    ASSERT_STREQ(AudioManager::audioStateToString(AudioState::PAUSED), "PAUSED");

    ASSERT_STREQ(AudioManager::audioPermissionToString(AudioPermission::DENY), "DENY");
    ASSERT_STREQ(AudioManager::audioPermissionToString(AudioPermission::ALLOW_FOREGROUND), "ALLOW_FOREGROUND");
    ASSERT_STREQ(AudioManager::audioPermissionToString(AudioPermission::ALLOW_ALWAYS), "ALLOW_ALWAYS");
    ASSERT_STREQ(AudioManager::audioPermissionToString(AudioPermission::ALLOW_ONCE), "ALLOW_ONCE");

    ASSERT_STREQ(AudioManager::requestStateToString(AudioRequestState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(AudioManager::requestStateToString(AudioRequestState::PAUSED), "PAUSED");
    ASSERT_STREQ(AudioManager::requestStateToString(AudioRequestState::EXPIRED), "EXPIRED");

    ASSERT_STREQ(AudioManager::audioPrivacyModeToString(AudioPrivacyMode::FULL), "FULL");
    ASSERT_STREQ(AudioManager::audioPrivacyModeToString(AudioPrivacyMode::REDACTED), "REDACTED");
    ASSERT_STREQ(AudioManager::audioPrivacyModeToString(AudioPrivacyMode::METADATA_ONLY), "METADATA_ONLY");

    ASSERT_STREQ(AudioManager::captureModeToString(AudioCaptureMode::RECORD), "RECORD");
    ASSERT_STREQ(AudioManager::captureModeToString(AudioCaptureMode::STREAM), "STREAM");
    ASSERT_STREQ(AudioManager::captureModeToString(AudioCaptureMode::VOICE_COMMUNICATION), "VOICE_COMMUNICATION");
    ASSERT_STREQ(AudioManager::captureModeToString(AudioCaptureMode::BACKGROUND_CAPTURE), "BACKGROUND_CAPTURE");

    ASSERT_STREQ(AudioManager::audioResultToString(AudioResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(AudioManager::audioResultToString(AudioResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(AudioManager::audioResultToString(AudioResult::DEVICE_BUSY), "DEVICE_BUSY");
    ASSERT_STREQ(AudioManager::audioResultToString(AudioResult::CAPTURE_FAILED), "CAPTURE_FAILED");

    ASSERT_STREQ(AudioManager::audioEventTypeToString(AudioEventType::DEVICE_OPENED), "DEVICE_OPENED");
    ASSERT_STREQ(AudioManager::audioEventTypeToString(AudioEventType::SESSION_STARTED), "SESSION_STARTED");
    ASSERT_STREQ(AudioManager::audioEventTypeToString(AudioEventType::CAPTURE_COMPLETED), "CAPTURE_COMPLETED");
    ASSERT_STREQ(AudioManager::audioEventTypeToString(AudioEventType::ROUTE_CHANGED), "ROUTE_CHANGED");

    ASSERT_EQ(AudioManager::stringToAudioDevice("BUILT_IN_MIC"), AudioDevice::BUILT_IN_MIC);
    ASSERT_EQ(AudioManager::stringToAudioDevice("BLUETOOTH"), AudioDevice::BLUETOOTH);
    ASSERT_EQ(AudioManager::stringToAudioDevice("MOCK"), AudioDevice::MOCK);

    ASSERT_EQ(AudioManager::stringToAudioResult("SUCCESS"), AudioResult::SUCCESS);
    ASSERT_EQ(AudioManager::stringToAudioResult("PERMISSION_DENIED"), AudioResult::PERMISSION_DENIED);
}

// ============================================================
// Full workflow test
// ============================================================

void test_full_workflow() {
    AudioManager mgr;
    mgr.initialize(256, 256, 4);

    // 1. Setup app policy
    ASSERT_EQ(mgr.setAppAudioPolicy("com.test.app", AudioPermission::ALLOW_FOREGROUND,
                                     AudioPrivacyMode::FULL,
                                     AUDIO_PRIVACY_REQUIRE_FOREGROUND), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.setAppForeground("com.test.app", true), AudioResult::SUCCESS);

    // 2. Set route
    ASSERT_EQ(mgr.setRoute(AudioRoute::RECEIVER, "system"), AudioResult::SUCCESS);

    // 3. Open session
    uint64_t sessionId = 0;
    ASSERT_EQ(mgr.openSession("com.test.app", AudioDevice::BUILT_IN_MIC,
                              AudioCaptureMode::RECORD, 100, &sessionId),
              AudioResult::SUCCESS);
    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());

    // 4. Capture frame
    ASSERT_EQ(mgr.captureFrame(sessionId, "com.test.app"), AudioResult::SUCCESS);

    // 5. Pause and resume
    ASSERT_EQ(mgr.pauseSession(sessionId, "com.test.app"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.captureFrame(sessionId, "com.test.app"), AudioResult::BAD_STATE);
    ASSERT_EQ(mgr.resumeSession(sessionId, "com.test.app"), AudioResult::SUCCESS);

    // 6. Capture again
    ASSERT_EQ(mgr.captureFrame(sessionId, "com.test.app"), AudioResult::SUCCESS);

    // 7. Get last frame
    AudioFrame frame;
    ASSERT_EQ(mgr.getLastFrame("com.test.app", AudioDevice::BUILT_IN_MIC, frame),
              AudioResult::SUCCESS);
    ASSERT_TRUE(frame.timestamp > 0);

    // 8. Check history
    auto history = mgr.getHistory("com.test.app");
    ASSERT_TRUE(history.size() >= 2);

    // 9. Check events
    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 4);

    // 10. Check stats
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.capturesCompleted >= 2);
    ASSERT_TRUE(stats.routeChanges >= 1);

    // 11. Close session
    ASSERT_EQ(mgr.closeSession(sessionId, "com.test.app"), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());

    // 12. System access
    ASSERT_TRUE(mgr.checkAppAccess("system", AudioDevice::BUILT_IN_MIC));

    // 13. Clear history
    ASSERT_EQ(mgr.clearHistory("system"), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));

    // 14. Clear events
    ASSERT_EQ(mgr.clearEvents(), AudioResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));

    // 15. Reset stats
    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.capturesCompleted, static_cast<uint64_t>(0));

    // 16. Shutdown
    ASSERT_EQ(mgr.shutdown(), AudioResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Audio Manager Tests ===" << std::endl;

    // Lifecycle
    std::cout << "Testing lifecycle..." << std::endl;
    test_lifecycle();

    // Device control
    std::cout << "Testing device control..." << std::endl;
    test_device_control();
    test_device_control_failure();

    // Routing
    std::cout << "Testing routing..." << std::endl;
    test_routing();
    test_routing_failure();

    // Permission / policy
    std::cout << "Testing permission/policy..." << std::endl;
    test_permission_deny();
    test_permission_allow_foreground();
    test_permission_allow_always();
    test_permission_allow_once();
    test_permission_bluetooth_disabled();
    test_permission_system_access();
    test_clear_app_policy();
    test_policy_failure();

    // Session lifecycle
    std::cout << "Testing session lifecycle..." << std::endl;
    test_session_open_close();
    test_session_permission_denied();
    test_session_device_busy();
    test_session_capacity();
    test_session_device_disabled();
    test_session_owner_check();
    test_session_expiry();
    test_session_pause_resume();
    test_session_failure();

    // Capture
    std::cout << "Testing capture..." << std::endl;
    test_capture_frame();
    test_capture_permission_denied();
    test_capture_bad_state();
    test_capture_rate_limited();
    test_capture_failure();

    // getLastFrame
    std::cout << "Testing getLastFrame..." << std::endl;
    test_get_last_frame();
    test_get_last_frame_denied();
    test_get_last_frame_unavailable();
    test_request_single_capture();

    // History / privacy
    std::cout << "Testing history/privacy..." << std::endl;
    test_history();
    test_history_capacity();
    test_history_clear();
    test_history_no_history_flag();

    // Mock
    std::cout << "Testing mock..." << std::endl;
    test_mock_frame();
    test_mock_not_allowed();
    test_mock_enabled();

    // Privacy transform
    std::cout << "Testing privacy transform..." << std::endl;
    test_privacy_transform_full();
    test_privacy_transform_redacted();
    test_privacy_transform_metadata_only();
    test_privacy_transform_low_sample_rate();
    test_privacy_transform_mute();
    test_privacy_transform_redact_metadata();

    // Privacy indicator
    std::cout << "Testing privacy indicator..." << std::endl;
    test_privacy_indicator();
    test_privacy_indicator_speaker_not_tracked();

    // Events
    std::cout << "Testing events..." << std::endl;
    test_events();
    test_events_capacity();
    test_event_fields();

    // Stats
    std::cout << "Testing stats..." << std::endl;
    test_stats();
    test_stats_reset();
    test_stats_route_changes();

    // Callbacks
    std::cout << "Testing callbacks..." << std::endl;
    test_frame_callback();
    test_access_callback();
    test_event_callback();

    // Failure simulation
    std::cout << "Testing failure simulation..." << std::endl;
    test_failure_set_device_enabled();
    test_failure_capture();

    // LogServer / CrashReporter
    std::cout << "Testing LogServer/CrashReporter integration..." << std::endl;
    test_logserver_integration();
    test_crashreporter_integration();

    // String helpers
    std::cout << "Testing string helpers..." << std::endl;
    test_string_helpers();

    // Full workflow
    std::cout << "Testing full workflow..." << std::endl;
    test_full_workflow();

    std::cout << std::endl;
    std::cout << "=== Results ===" << std::endl;
    std::cout << "Total: " << g_tests_run << ", Passed: " << g_tests_passed
              << ", Failed: " << g_tests_failed << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
