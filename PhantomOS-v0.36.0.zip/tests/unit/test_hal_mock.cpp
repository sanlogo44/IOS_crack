/*
 * Phantom OS - HAL Mock Tests
 * Tests for the mock HAL implementations
 *
 * License: GPL-3.0
 */

#include "phantom/hal/hal_interfaces.h"
#include "mock_hal_factory.h"
#include <cassert>
#include <cstdio>
#include <memory>

using namespace phantom::hal;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

bool test_display_hal() {
    TEST("Mock Display HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    IDisplayHal* display = nullptr;
    ASSERT(factory->createDisplay(&display) == HalResult::SUCCESS, "Should create display HAL");

    ASSERT(display->init() == HalResult::SUCCESS, "Display should init");

    DisplayInfo info;
    ASSERT(display->getInfo(&info) == HalResult::SUCCESS, "Should get display info");
    ASSERT(info.resolution.width == 2436, "Width should be 2436");
    ASSERT(info.resolution.height == 1125, "Height should be 1125");
    ASSERT(info.resolution.dpi == 458, "DPI should be 458");
    ASSERT(info.has_touch, "Should have touch");

    ASSERT(display->setBrightness(200) == HalResult::SUCCESS, "Should set brightness");
    uint8_t brightness = 0;
    ASSERT(display->getBrightness(&brightness) == HalResult::SUCCESS, "Should get brightness");
    ASSERT(brightness == 200, "Brightness should be 200");

    ASSERT(display->deinit() == HalResult::SUCCESS, "Display should deinit");
    factory->destroyDisplay(display);
    PASS();
    return true;
}

bool test_storage_hal() {
    TEST("Mock Storage HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    IStorageHal* storage = nullptr;
    factory->createStorage(&storage);
    storage->init();

    StorageInfo info;
    storage->getInfo(&info);
    ASSERT(info.total_bytes > 0, "Storage should have space");
    ASSERT(info.is_encrypted, "Storage should be encrypted");

    // Write test
    uint8_t write_data[] = {0x01, 0x02, 0x03, 0x04, 0x05};
    ASSERT(storage->write(0, write_data, 5) == HalResult::SUCCESS, "Should write data");

    // Read test
    uint8_t read_data[5] = {0};
    ASSERT(storage->read(0, read_data, 5) == HalResult::SUCCESS, "Should read data");
    ASSERT(read_data[0] == 0x01, "Read data should match written data");
    ASSERT(read_data[4] == 0x05, "Read data should match at end");

    storage->deinit();
    factory->destroyStorage(storage);
    PASS();
    return true;
}

bool test_network_hal() {
    TEST("Mock Network HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    INetworkHal* net = nullptr;
    factory->createNetwork(&net);
    net->init();

    // Get interfaces
    NetworkInterface interfaces[4];
    size_t actual_count = 0;
    ASSERT(net->getInterfaces(interfaces, 4, &actual_count) == HalResult::SUCCESS, "Should get interfaces");
    ASSERT(actual_count >= 1, "Should have at least 1 interface");

    // Wi-Fi connect
    ASSERT(net->wifiConnect("TestSSID", "password") == HalResult::SUCCESS, "Should connect WiFi");
    bool connected = false;
    net->wifiGetStatus(&connected);
    ASSERT(connected, "Should be connected after connect");

    // Wi-Fi disconnect
    net->wifiDisconnect();
    net->wifiGetStatus(&connected);
    ASSERT(!connected, "Should be disconnected");

    // Check MAC is zeroed (privacy)
    bool mac_zeroed = true;
    for (int i = 0; i < 6; ++i) {
        if (interfaces[0].mac_address[i] != 0) {
            mac_zeroed = false;
            break;
        }
    }
    ASSERT(mac_zeroed, "MAC address should be zeroed (privacy)");

    net->deinit();
    factory->destroyNetwork(net);
    PASS();
    return true;
}

bool test_sensor_hal() {
    TEST("Mock Sensor HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    ISensorHal* sensor = nullptr;
    factory->createSensor(&sensor);
    sensor->init();

    bool available = false;
    ASSERT(sensor->hasSensor(SensorType::ACCELEROMETER, &available) == HalResult::SUCCESS, "Should check accelerometer");
    ASSERT(available, "Accelerometer should be available");

    ASSERT(sensor->setAccuracy(SensorType::GPS, 1) == HalResult::SUCCESS, "Should set GPS accuracy");

    sensor->deinit();
    factory->destroySensor(sensor);
    PASS();
    return true;
}

bool test_camera_hal() {
    TEST("Mock Camera HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    ICameraHal* cam = nullptr;
    factory->createCamera(&cam);
    cam->init();

    ASSERT(cam->open(false) == HalResult::SUCCESS, "Should open rear camera");

    CameraFrame frame;
    ASSERT(cam->capturePhoto(&frame) == HalResult::SUCCESS, "Should capture photo");
    ASSERT(frame.width == 4032, "Photo width should be 4032");

    cam->close();
    cam->deinit();
    factory->destroyCamera(cam);
    PASS();
    return true;
}

bool test_power_hal() {
    TEST("Mock Power HAL");
    auto factory = std::unique_ptr<IHalFactory>(createMockHalFactory());
    IPowerHal* power = nullptr;
    factory->createPower(&power);
    power->init();

    PowerState state;
    ASSERT(power->getPowerState(&state) == HalResult::SUCCESS, "Should get power state");
    ASSERT(state == PowerState::ACTIVE, "Should be in ACTIVE state");

    BatteryInfo battery;
    ASSERT(power->getBatteryInfo(&battery) == HalResult::SUCCESS, "Should get battery info");
    ASSERT(battery.level <= 100, "Battery level should be <= 100");

    power->deinit();
    factory->destroyPower(power);
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - HAL Mock Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_display_hal();
    all_pass &= test_storage_hal();
    all_pass &= test_network_hal();
    all_pass &= test_sensor_hal();
    all_pass &= test_camera_hal();
    all_pass &= test_power_hal();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
