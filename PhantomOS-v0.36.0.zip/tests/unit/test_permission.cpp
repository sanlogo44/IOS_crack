/*
 * Phantom OS - Permission Tests
 * Tests for the permission system: default-deny, grants, expiration
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/permission.h"
#include <cassert>
#include <cstdio>
#include <thread>
#include <chrono>
#include <cstring>

using namespace phantom::privacy;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

bool test_default_deny() {
    TEST("Default deny - all permissions denied by default");
    AppPermissionState state("com.test.app1");
    for (int i = 0; i < static_cast<int>(Permission::PERMISSION_COUNT); ++i) {
        Permission p = static_cast<Permission>(i);
        ASSERT(state.isDenied(p), "Permission should be denied by default");
    }
    PASS();
    return true;
}

bool test_grant_permission() {
    TEST("Grant permission - ALLOW_WHILE_USING");
    AppPermissionState state("com.test.app2");
    state.setGrant(Permission::CAMERA, GrantType::ALLOW_WHILE_USING);
    ASSERT(state.isGranted(Permission::CAMERA), "Camera should be granted");
    ASSERT(!state.isDenied(Permission::CAMERA), "Camera should not be denied");
    PASS();
    return true;
}

bool test_deny_after_grant() {
    TEST("Deny after grant - revoke permission");
    AppPermissionState state("com.test.app3");
    state.setGrant(Permission::MICROPHONE, GrantType::ALLOW_ALWAYS);
    ASSERT(state.isGranted(Permission::MICROPHONE), "Mic should be granted");
    state.setGrant(Permission::MICROPHONE, GrantType::DENY);
    ASSERT(state.isDenied(Permission::MICROPHONE), "Mic should be denied after revoke");
    PASS();
    return true;
}

bool test_timed_grant_expiration() {
    TEST("Timed grant - ALLOW_10_MIN expires");
    AppPermissionState state("com.test.app4");
    state.setGrant(Permission::LOCATION, GrantType::ALLOW_10_MIN,
                    LocationAccuracy::APPROXIMATE);
    ASSERT(state.isGranted(Permission::LOCATION), "Location should be granted initially");

    // The grant duration for ALLOW_10_MIN is 600 seconds (10 minutes)
    // We can't wait 10 minutes in a test, so we verify the expiration logic
    // by checking that the grant has an expiration time set
    const auto& grant = state.getGrant(Permission::LOCATION);
    ASSERT(grant.expires_at > grant.granted_at, "Expiration should be after grant time");
    ASSERT(grant.type == GrantType::ALLOW_10_MIN, "Grant type should be ALLOW_10_MIN");
    PASS();
    return true;
}

bool test_allow_once() {
    TEST("Allow once - ALLOW_ONCE type");
    AppPermissionState state("com.test.app5");
    state.setGrant(Permission::CONTACTS, GrantType::ALLOW_ONCE);
    ASSERT(state.isGranted(Permission::CONTACTS), "Contacts should be granted");
    // ALLOW_ONCE has a 60 second expiration
    const auto& grant = state.getGrant(Permission::CONTACTS);
    ASSERT(grant.expires_at > grant.granted_at, "Allow once should have expiration");
    PASS();
    return true;
}

bool test_reset_all() {
    TEST("Reset all - all permissions back to deny");
    AppPermissionState state("com.test.app6");
    state.setGrant(Permission::CAMERA, GrantType::ALLOW_ALWAYS);
    state.setGrant(Permission::LOCATION, GrantType::ALLOW_WHILE_USING);
    state.setGrant(Permission::CONTACTS, GrantType::ALLOW_ALWAYS);

    state.resetAll();

    ASSERT(state.isDenied(Permission::CAMERA), "Camera should be denied after reset");
    ASSERT(state.isDenied(Permission::LOCATION), "Location should be denied after reset");
    ASSERT(state.isDenied(Permission::CONTACTS), "Contacts should be denied after reset");
    PASS();
    return true;
}

bool test_location_accuracy() {
    TEST("Location accuracy - stored correctly");
    AppPermissionState state("com.test.app7");
    state.setGrant(Permission::LOCATION, GrantType::ALLOW_WHILE_USING,
                    LocationAccuracy::CITY);
    const auto& grant = state.getGrant(Permission::LOCATION);
    ASSERT(grant.location_accuracy == LocationAccuracy::CITY, "Location accuracy should be CITY");
    PASS();
    return true;
}

bool test_permission_to_string() {
    TEST("Permission to string conversion");
    ASSERT(strcmp(permissionToString(Permission::CAMERA), "CAMERA") == 0, "Camera string mismatch");
    ASSERT(strcmp(permissionToString(Permission::MICROPHONE), "MICROPHONE") == 0, "Mic string mismatch");
    ASSERT(strcmp(permissionToString(Permission::LOCATION), "LOCATION") == 0, "Location string mismatch");
    ASSERT(strcmp(grantTypeToString(GrantType::DENY), "DENY") == 0, "Deny string mismatch");
    ASSERT(strcmp(grantTypeToString(GrantType::ALLOW_ALWAYS), "ALLOW_ALWAYS") == 0, "Allow always string mismatch");
    PASS();
    return true;
}

bool test_default_location_accuracy() {
    TEST("Default location accuracy by profile");
    ASSERT(defaultLocationAccuracy(0) == LocationAccuracy::PRECISE, "Normal should be precise");
    ASSERT(defaultLocationAccuracy(1) == LocationAccuracy::APPROXIMATE, "Privacy should be approximate");
    ASSERT(defaultLocationAccuracy(2) == LocationAccuracy::CITY, "Max privacy should be city");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Permission Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_default_deny();
    all_pass &= test_grant_permission();
    all_pass &= test_deny_after_grant();
    all_pass &= test_timed_grant_expiration();
    all_pass &= test_allow_once();
    all_pass &= test_reset_all();
    all_pass &= test_location_accuracy();
    all_pass &= test_permission_to_string();
    all_pass &= test_default_location_accuracy();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
