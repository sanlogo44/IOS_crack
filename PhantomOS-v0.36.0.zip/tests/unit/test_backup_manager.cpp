/*
 * Phantom OS - Backup & Restore Manager Tests
 * v0.21.0
 */

#include "phantom/backup/backup_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <iostream>
#include <sstream>
#include <cstring>

static int tests_passed = 0;
static int tests_failed = 0;

static void ASSERT_TRUE(bool cond, const char* msg) {
    if (!cond) {
        std::cerr << "  FAIL: " << msg << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void ASSERT_FALSE(bool cond, const char* msg) {
    ASSERT_TRUE(!cond, msg);
}

static void ASSERT_EQ(int a, int b, const char* msg) {
    if (a != b) {
        std::cerr << "  FAIL: " << msg << " (expected " << b << ", got " << a << ")" << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void ASSERT_STREQ(const char* a, const char* b, const char* msg) {
    if (a == nullptr) a = "";
    if (b == nullptr) b = "";
    if (strcmp(a, b) != 0) {
        std::cerr << "  FAIL: " << msg << " (expected '" << b << "', got '" << a << "')" << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void RUN_TEST(const char* name, void (*func)()) {
    std::cout << "  Running " << name << std::endl;
    func();
}

using namespace phantom::backup;

static BackupEntry makeEntry(const std::string& name,
                             BackupType type = BackupType::FULL_SYSTEM,
                             BackupDestination dest = BackupDestination::LOCAL) {
    BackupEntry entry;
    entry.name = name;
    entry.type = type;
    entry.destination = dest;
    entry.sizeBytes = 1024 * 1024 * 50;  // 50MB
    entry.itemCount = 500;
    entry.version = "0.21.0";
    entry.includedPaths.push_back("/home/user/docs");
    entry.includedApps.push_back("com.phantom.settings");
    return entry;
}

void runAllTests() {

    // ============================================================
    // Lifecycle tests
    // ============================================================

    RUN_TEST("testInitialize", []() {
        BackupManager bm;
        ASSERT_TRUE(bm.initialize() == BackupResult::SUCCESS, "initialize should succeed");
        ASSERT_TRUE(bm.isInitialized(), "should be initialized");
    });

    RUN_TEST("testDoubleInitialize", []() {
        BackupManager bm;
        bm.initialize();
        ASSERT_EQ(static_cast<int>(bm.initialize()), static_cast<int>(BackupResult::ALREADY_INITIALIZED),
                  "double init should fail");
    });

    RUN_TEST("testShutdown", []() {
        BackupManager bm;
        bm.initialize();
        BackupEntry entry = makeEntry("test_backup");
        bm.createBackup(entry);
        ASSERT_TRUE(bm.shutdown() == BackupResult::SUCCESS, "shutdown should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 0, "should clear backups");
        ASSERT_FALSE(bm.isInitialized(), "should not be initialized after shutdown");
    });

    RUN_TEST("testReinitialize", []() {
        BackupManager bm;
        bm.initialize();
        bm.shutdown();
        ASSERT_TRUE(bm.initialize() == BackupResult::SUCCESS, "reinitialize should succeed");
        ASSERT_TRUE(bm.isInitialized(), "should be initialized after reinit");
    });

    RUN_TEST("testShutdownNotInitialized", []() {
        BackupManager bm;
        ASSERT_EQ(static_cast<int>(bm.shutdown()), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "shutdown without init should fail");
    });

    RUN_TEST("testMaxBackups", []() {
        BackupManager bm;
        bm.initialize(10, 100);
        ASSERT_EQ(static_cast<int>(bm.getMaxBackups()), 10, "max backups should be 10");
        ASSERT_EQ(static_cast<int>(bm.getMaxHistorySize()), 100, "max history should be 100");
    });

    // ============================================================
    // Backup creation tests
    // ============================================================

    RUN_TEST("testCreateBackup", []() {
        BackupManager bm;
        bm.initialize();
        BackupEntry entry = makeEntry("backup1");
        ASSERT_TRUE(bm.createBackup(entry) == BackupResult::SUCCESS, "createBackup should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 1, "should have 1 backup");
    });

    RUN_TEST("testCreateBackupNotInitialized", []() {
        BackupManager bm;
        BackupEntry entry = makeEntry("backup1");
        ASSERT_EQ(static_cast<int>(bm.createBackup(entry)), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "createBackup without init should fail");
    });

    RUN_TEST("testCreateBackupInvalidName", []() {
        BackupManager bm;
        bm.initialize();
        BackupEntry entry;
        entry.name = "";
        ASSERT_EQ(static_cast<int>(bm.createBackup(entry)), static_cast<int>(BackupResult::INVALID_BACKUP),
                  "createBackup with empty name should fail");
    });

    RUN_TEST("testCreateBackupWithFailNext", []() {
        BackupManager bm;
        bm.initialize();
        bm.setFailNextBackup(true);
        BackupEntry entry = makeEntry("failing_backup");
        ASSERT_EQ(static_cast<int>(bm.createBackup(entry)), static_cast<int>(BackupResult::BACKUP_FAILED),
                  "createBackup with failNext should fail");
        ASSERT_FALSE(bm.getFailNextBackup(), "failNextBackup should be reset");
    });

    RUN_TEST("testCreateMultipleBackups", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        bm.createBackup(makeEntry("backup2"));
        bm.createBackup(makeEntry("backup3"));
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 3, "should have 3 backups");
    });

    RUN_TEST("testCreateBackupDifferentTypes", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("full", BackupType::FULL_SYSTEM));
        bm.createBackup(makeEntry("app", BackupType::APP_DATA));
        bm.createBackup(makeEntry("settings", BackupType::SETTINGS));
        bm.createBackup(makeEntry("media", BackupType::MEDIA));
        bm.createBackup(makeEntry("config", BackupType::CONFIG));
        bm.createBackup(makeEntry("keys", BackupType::SECURITY_KEYS));
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::FULL_SYSTEM)), 1, "should have 1 FULL_SYSTEM");
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::APP_DATA)), 1, "should have 1 APP_DATA");
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::SETTINGS)), 1, "should have 1 SETTINGS");
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::MEDIA)), 1, "should have 1 MEDIA");
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::CONFIG)), 1, "should have 1 CONFIG");
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::SECURITY_KEYS)), 1, "should have 1 SECURITY_KEYS");
    });

    RUN_TEST("testCreateBackupDifferentDestinations", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("local", BackupType::FULL_SYSTEM, BackupDestination::LOCAL));
        bm.createBackup(makeEntry("external", BackupType::FULL_SYSTEM, BackupDestination::EXTERNAL));
        bm.createBackup(makeEntry("encrypted", BackupType::FULL_SYSTEM, BackupDestination::ENCRYPTED_ARCHIVE));
        bm.createBackup(makeEntry("cloud", BackupType::FULL_SYSTEM, BackupDestination::CLOUD_STUB));
        ASSERT_EQ(static_cast<int>(bm.getCountByDestination(BackupDestination::LOCAL)), 1, "should have 1 LOCAL");
        ASSERT_EQ(static_cast<int>(bm.getCountByDestination(BackupDestination::EXTERNAL)), 1, "should have 1 EXTERNAL");
        ASSERT_EQ(static_cast<int>(bm.getCountByDestination(BackupDestination::ENCRYPTED_ARCHIVE)), 1, "should have 1 ENCRYPTED_ARCHIVE");
        ASSERT_EQ(static_cast<int>(bm.getCountByDestination(BackupDestination::CLOUD_STUB)), 1, "should have 1 CLOUD_STUB");
    });

    // ============================================================
    // Backup query tests
    // ============================================================

    RUN_TEST("testGetBackupById", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        uint64_t id = backups[0].id;
        BackupEntry retrieved = bm.getBackupById(id);
        ASSERT_STREQ(retrieved.name.c_str(), "backup1", "retrieved backup name should match");
    });

    RUN_TEST("testGetBackupByIdNotFound", []() {
        BackupManager bm;
        bm.initialize();
        BackupEntry entry = bm.getBackupById(999);
        ASSERT_EQ(static_cast<int>(entry.id), 0, "non-existent backup should have id 0");
    });

    RUN_TEST("testGetBackupsByState", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto completed = bm.getBackupsByState(BackupState::COMPLETED);
        ASSERT_EQ(static_cast<int>(completed.size()), 1, "should have 1 completed backup");
    });

    RUN_TEST("testGetBackupsByType", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("full1", BackupType::FULL_SYSTEM));
        bm.createBackup(makeEntry("app1", BackupType::APP_DATA));
        bm.createBackup(makeEntry("full2", BackupType::FULL_SYSTEM));
        auto fullBackups = bm.getBackupsByType(BackupType::FULL_SYSTEM);
        ASSERT_EQ(static_cast<int>(fullBackups.size()), 2, "should have 2 FULL_SYSTEM backups");
    });

    // ============================================================
    // Cancel backup tests
    // ============================================================

    RUN_TEST("testCancelBackup", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        // Manually set state to BACKING_UP to test cancel
        // Since createBackup completes synchronously, we test with a created backup
        // that we then try to cancel (should fail with BAD_STATE)
        ASSERT_EQ(static_cast<int>(bm.cancelBackup(backups[0].id)), static_cast<int>(BackupResult::BAD_STATE),
                  "cancelling a completed backup should fail with BAD_STATE");
    });

    RUN_TEST("testCancelBackupNotFound", []() {
        BackupManager bm;
        bm.initialize();
        ASSERT_EQ(static_cast<int>(bm.cancelBackup(999)), static_cast<int>(BackupResult::NOT_FOUND),
                  "cancelling non-existent backup should fail");
    });

    // ============================================================
    // Delete backup tests
    // ============================================================

    RUN_TEST("testDeleteBackup", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        ASSERT_TRUE(bm.deleteBackup(backups[0].id) == BackupResult::SUCCESS, "deleteBackup should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 0, "should have 0 backups after delete");
    });

    RUN_TEST("testDeleteBackupNotFound", []() {
        BackupManager bm;
        bm.initialize();
        ASSERT_EQ(static_cast<int>(bm.deleteBackup(999)), static_cast<int>(BackupResult::NOT_FOUND),
                  "deleting non-existent backup should fail");
    });

    RUN_TEST("testDeleteAllBackups", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        bm.createBackup(makeEntry("backup2"));
        bm.createBackup(makeEntry("backup3"));
        ASSERT_TRUE(bm.deleteAllBackups() == BackupResult::SUCCESS, "deleteAllBackups should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 0, "should have 0 backups");
    });

    // ============================================================
    // Incremental backup tests
    // ============================================================

    RUN_TEST("testCreateIncrementalBackup", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("base_backup"));
        auto backups = bm.getBackups();
        uint64_t baseId = backups[0].id;

        BackupEntry incrEntry = makeEntry("incremental1");
        ASSERT_TRUE(bm.createIncrementalBackup(baseId, incrEntry) == BackupResult::SUCCESS,
                    "incremental backup should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 2, "should have 2 backups");
        auto lastBackup = bm.getBackups().back();
        ASSERT_TRUE(lastBackup.incremental, "should be marked incremental");
        ASSERT_EQ(static_cast<int>(lastBackup.baseBackupId), static_cast<int>(baseId),
                  "base backup ID should match");
    });

    RUN_TEST("testCreateIncrementalBackupBaseNotFound", []() {
        BackupManager bm;
        bm.initialize();
        BackupEntry entry = makeEntry("incremental1");
        ASSERT_EQ(static_cast<int>(bm.createIncrementalBackup(999, entry)), static_cast<int>(BackupResult::NOT_FOUND),
                  "incremental with non-existent base should fail");
    });

    // ============================================================
    // Verification tests
    // ============================================================

    RUN_TEST("testVerifyBackup", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        ASSERT_TRUE(bm.verifyBackup(backups[0].id) == BackupResult::SUCCESS, "verifyBackup should succeed");
        auto verified = bm.getBackupById(backups[0].id);
        ASSERT_TRUE(verified.verified, "backup should be marked verified");
    });

    RUN_TEST("testVerifyBackupNotFound", []() {
        BackupManager bm;
        bm.initialize();
        ASSERT_EQ(static_cast<int>(bm.verifyBackup(999)), static_cast<int>(BackupResult::NOT_FOUND),
                  "verifying non-existent backup should fail");
    });

    RUN_TEST("testVerifyBackupBadState", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        // Set bad checksum to trigger verification failure
        bm.setChecksum(backups[0].id, "invalid_checksum");
        ASSERT_EQ(static_cast<int>(bm.verifyBackup(backups[0].id)), static_cast<int>(BackupResult::CHECKSUM_FAILED),
                  "verifyBackup with bad checksum should fail");
    });

    RUN_TEST("testComputeChecksum", []() {
        BackupManager bm;
        bm.initialize();
        std::string data = "test_data_for_checksum";
        std::string checksum = bm.computeChecksum(data);
        ASSERT_FALSE(checksum.empty(), "checksum should not be empty");
        // Verify determinism
        ASSERT_STREQ(bm.computeChecksum(data).c_str(), checksum.c_str(),
                     "checksum should be deterministic");
    });

    RUN_TEST("testVerifyChecksum", []() {
        BackupManager bm;
        bm.initialize();
        std::string data = "test_data";
        std::string checksum = bm.computeChecksum(data);
        ASSERT_TRUE(bm.verifyChecksum(data, checksum), "verifyChecksum should return true for matching");
        ASSERT_FALSE(bm.verifyChecksum(data, "wrong"), "verifyChecksum should return false for mismatch");
        ASSERT_FALSE(bm.verifyChecksum(data, ""), "verifyChecksum should return false for empty expected");
    });

    // ============================================================
    // Restore tests
    // ============================================================

    RUN_TEST("testPlanRestore", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        RestorePlan plan = bm.planRestore(backups[0].id, RestoreMode::FULL);
        ASSERT_EQ(static_cast<int>(plan.backupId), static_cast<int>(backups[0].id), "plan backup ID should match");
        ASSERT_FALSE(plan.planSummary.empty(), "plan summary should not be empty");
    });

    RUN_TEST("testPlanRestoreNotFound", []() {
        BackupManager bm;
        bm.initialize();
        RestorePlan plan = bm.planRestore(999);
        ASSERT_STREQ(plan.planSummary.c_str(), "Backup not found", "plan for non-existent should say not found");
    });

    RUN_TEST("testExecuteRestore", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        // Verify first (restore requires verified backup)
        bm.verifyBackup(backups[0].id);
        ASSERT_TRUE(bm.executeRestore(backups[0].id) == BackupResult::SUCCESS, "executeRestore should succeed");
        auto entry = bm.getBackupById(backups[0].id);
        ASSERT_EQ(static_cast<int>(entry.state), static_cast<int>(BackupState::RESTORED),
                  "backup state should be RESTORED");
    });

    RUN_TEST("testExecuteRestoreNotFound", []() {
        BackupManager bm;
        bm.initialize();
        ASSERT_EQ(static_cast<int>(bm.executeRestore(999)), static_cast<int>(BackupResult::NOT_FOUND),
                  "restore non-existent should fail");
    });

    RUN_TEST("testExecuteRestoreBadState", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        // Don't verify - should auto-verify then succeed
        // Actually, executeRestore auto-verifies, so this should succeed
        auto backups = bm.getBackups();
        ASSERT_TRUE(bm.executeRestore(backups[0].id) == BackupResult::SUCCESS,
                    "restore should auto-verify and succeed");
    });

    RUN_TEST("testExecuteRestoreWithFailNext", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        bm.setFailNextRestore(true);
        ASSERT_EQ(static_cast<int>(bm.executeRestore(backups[0].id)), static_cast<int>(BackupResult::RESTORE_FAILED),
                  "restore with failNext should fail");
        ASSERT_FALSE(bm.getFailNextRestore(), "failNextRestore should be reset");
    });

    RUN_TEST("testExecuteRestoreDryRun", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        ASSERT_TRUE(bm.executeRestore(backups[0].id, RestoreMode::DRY_RUN) == BackupResult::SUCCESS,
                    "dry-run restore should succeed");
    });

    RUN_TEST("testExecuteRestoreFromPlan", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        RestorePlan plan = bm.planRestore(backups[0].id, RestoreMode::SELECTIVE);
        ASSERT_TRUE(bm.executeRestoreFromPlan(plan) == BackupResult::SUCCESS,
                    "executeRestoreFromPlan should succeed");
    });

    RUN_TEST("testCancelRestore", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        // After restore, state is RESTORED, so cancel should fail with BAD_STATE
        bm.executeRestore(backups[0].id);
        ASSERT_EQ(static_cast<int>(bm.cancelRestore(backups[0].id)), static_cast<int>(BackupResult::BAD_STATE),
                  "cancelling a non-restoring backup should fail");
    });

    // ============================================================
    // Retention tests
    // ============================================================

    RUN_TEST("testRetentionPolicy", []() {
        BackupManager bm;
        bm.initialize();
        RetentionPolicy policy;
        policy.maxBackups = 5;
        policy.maxAgeDays = 30;
        policy.autoPrune = true;
        policy.keepLatestPerType = true;
        bm.setRetentionPolicy(policy);
        auto retrieved = bm.getRetentionPolicy();
        ASSERT_EQ(static_cast<int>(retrieved.maxBackups), 5, "maxBackups should be 5");
        ASSERT_EQ(static_cast<int>(retrieved.maxAgeDays), 30, "maxAgeDays should be 30");
        ASSERT_TRUE(retrieved.autoPrune, "autoPrune should be true");
        ASSERT_TRUE(retrieved.keepLatestPerType, "keepLatestPerType should be true");
    });

    RUN_TEST("testGetExpiredBackups", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        // With default maxAgeDays=90, a just-created backup shouldn't be expired
        auto expired = bm.getExpiredBackups();
        ASSERT_EQ(static_cast<int>(expired.size()), 0, "recent backup should not be expired");
    });

    RUN_TEST("testPruneBackups", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        bm.createBackup(makeEntry("backup2"));
        ASSERT_TRUE(bm.pruneBackups() == BackupResult::SUCCESS, "pruneBackups should succeed");
    });

    RUN_TEST("testQuotaExceeded", []() {
        BackupManager bm;
        bm.initialize(3, 100);
        bm.createBackup(makeEntry("backup1"));
        bm.createBackup(makeEntry("backup2"));
        bm.createBackup(makeEntry("backup3"));
        // With maxBackups=3 and autoPrune, creating more should trigger pruning
        // But since all are recent, pruning won't remove them, so it should return QUOTA_EXCEEDED
        BackupResult result = bm.createBackup(makeEntry("backup4"));
        // It might succeed if pruning removes something, or fail with QUOTA_EXCEEDED
        ASSERT_TRUE(result == BackupResult::SUCCESS || result == BackupResult::QUOTA_EXCEEDED,
                    "4th backup with max 3 should either prune or fail with quota");
    });

    // ============================================================
    // Progress tests
    // ============================================================

    RUN_TEST("testGetBackupProgress", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        BackupProgress prog = bm.getBackupProgress(backups[0].id);
        ASSERT_EQ(static_cast<int>(prog.backupId), static_cast<int>(backups[0].id), "progress backup ID should match");
    });

    RUN_TEST("testGetActiveBackups", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        // After createBackup completes synchronously, no active backups
        auto active = bm.getActiveBackups();
        ASSERT_EQ(static_cast<int>(active.size()), 0, "should have 0 active backups after completion");
    });

    RUN_TEST("testUpdateBackupProgress", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        // Update progress
        bm.updateBackupProgress(backups[0].id, 1024 * 1024 * 25, 250, 1024 * 1024);
        BackupProgress prog = bm.getBackupProgress(backups[0].id);
        ASSERT_EQ(static_cast<int>(prog.processedBytes), 25 * 1024 * 1024, "processed bytes should match");
        ASSERT_EQ(static_cast<int>(prog.processedItems), 250, "processed items should match");
    });

    // ============================================================
    // History tests
    // ============================================================

    RUN_TEST("testGetHistory", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.deleteBackup(backups[0].id);
        auto history = bm.getHistory();
        ASSERT_EQ(static_cast<int>(history.size()), 1, "should have 1 history entry");
    });

    RUN_TEST("testClearHistory", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.deleteBackup(backups[0].id);
        ASSERT_TRUE(bm.clearHistory() == BackupResult::SUCCESS, "clearHistory should succeed");
        ASSERT_EQ(static_cast<int>(bm.getHistory().size()), 0, "history should be empty");
    });

    // ============================================================
    // Stats tests
    // ============================================================

    RUN_TEST("testInitialStats", []() {
        BackupManager bm;
        bm.initialize();
        BackupStats stats = bm.getStats();
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCreated), 0, "initial totalBackupsCreated should be 0");
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCompleted), 0, "initial totalBackupsCompleted should be 0");
        ASSERT_EQ(static_cast<int>(stats.totalRestoresAttempted), 0, "initial totalRestoresAttempted should be 0");
    });

    RUN_TEST("testStatsAfterBackup", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        BackupStats stats = bm.getStats();
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCreated), 1, "totalBackupsCreated should be 1");
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCompleted), 1, "totalBackupsCompleted should be 1");
        ASSERT_EQ(static_cast<int>(stats.totalByType[static_cast<int>(BackupType::FULL_SYSTEM)]), 1,
                  "totalByType[FULL_SYSTEM] should be 1");
    });

    RUN_TEST("testStatsAfterRestore", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        bm.executeRestore(backups[0].id);
        BackupStats stats = bm.getStats();
        ASSERT_EQ(static_cast<int>(stats.totalRestoresAttempted), 1, "totalRestoresAttempted should be 1");
        ASSERT_EQ(static_cast<int>(stats.totalRestoresSucceeded), 1, "totalRestoresSucceeded should be 1");
    });

    RUN_TEST("testResetStats", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        bm.resetStats();
        BackupStats stats = bm.getStats();
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCreated), 0, "stats should be reset");
    });

    // ============================================================
    // Privacy tests
    // ============================================================

    RUN_TEST("testBackupPrivacy", []() {
        BackupManager bm;
        bm.initialize();
        bm.setBackupPrivacy(BackupPrivacy::ANONYMIZED);
        ASSERT_EQ(static_cast<int>(bm.getBackupPrivacy()), static_cast<int>(BackupPrivacy::ANONYMIZED),
                  "backup privacy should be ANONYMIZED");
    });

    RUN_TEST("testRequireEncryption", []() {
        BackupManager bm;
        bm.initialize();
        bm.setRequireEncryption(true);
        BackupEntry entry = makeEntry("unencrypted");
        entry.encrypted = false;
        ASSERT_EQ(static_cast<int>(bm.createBackup(entry)), static_cast<int>(BackupResult::ENCRYPTION_REQUIRED),
                  "unencrypted backup with requireEncryption should fail");
    });

    RUN_TEST("testRequireEncryptionWithEncrypted", []() {
        BackupManager bm;
        bm.initialize();
        bm.setRequireEncryption(true);
        BackupEntry entry = makeEntry("encrypted");
        entry.encrypted = true;
        entry.encryptionKey = "key_ref_123";
        ASSERT_TRUE(bm.createBackup(entry) == BackupResult::SUCCESS,
                    "encrypted backup with requireEncryption should succeed");
    });

    RUN_TEST("testPrivacyScrubbing", []() {
        BackupManager bm;
        bm.initialize();
        bm.setBackupPrivacy(BackupPrivacy::MINIMAL);
        BackupEntry entry = makeEntry("scrubbed");
        bm.createBackup(entry);
        auto backups = bm.getBackups();
        // With MINIMAL privacy, PII fields should be cleared
        ASSERT_TRUE(backups[0].deviceId.empty(), "deviceId should be scrubbed with MINIMAL privacy");
        ASSERT_TRUE(backups[0].includedApps.empty(), "includedApps should be scrubbed with MINIMAL privacy");
    });

    RUN_TEST("testPrivacyAnonymized", []() {
        BackupManager bm;
        bm.initialize();
        bm.setBackupPrivacy(BackupPrivacy::ANONYMIZED);
        BackupEntry entry = makeEntry("anon");
        entry.deviceId = "device123";
        entry.includedPaths.push_back("/home/user/secret");
        bm.createBackup(entry);
        auto backups = bm.getBackups();
        ASSERT_STREQ(backups[0].deviceId.c_str(), "anonymized", "deviceId should be anonymized");
        // Check that /home/user was replaced
        bool found = false;
        for (const auto& path : backups[0].includedPaths) {
            if (path.find("/home/USER") != std::string::npos) {
                found = true;
                break;
            }
        }
        ASSERT_TRUE(found, "paths should be anonymized");
    });

    // ============================================================
    // Callback tests
    // ============================================================

    RUN_TEST("testBackupCompleteCallback", []() {
        BackupManager bm;
        bm.initialize();
        bool callbackCalled = false;
        bm.setBackupCompleteCallback([&callbackCalled](const BackupEntry&) {
            callbackCalled = true;
        });
        bm.createBackup(makeEntry("backup1"));
        ASSERT_TRUE(callbackCalled, "backup complete callback should be called");
    });

    RUN_TEST("testBackupFailedCallback", []() {
        BackupManager bm;
        bm.initialize();
        bool callbackCalled = false;
        bm.setBackupFailedCallback([&callbackCalled](const BackupEntry&) {
            callbackCalled = true;
        });
        bm.setFailNextBackup(true);
        bm.createBackup(makeEntry("failing"));
        ASSERT_TRUE(callbackCalled, "backup failed callback should be called");
    });

    RUN_TEST("testRestoreCompleteCallback", []() {
        BackupManager bm;
        bm.initialize();
        bool callbackCalled = false;
        bm.setRestoreCompleteCallback([&callbackCalled](const BackupEntry&) {
            callbackCalled = true;
        });
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        bm.executeRestore(backups[0].id);
        ASSERT_TRUE(callbackCalled, "restore complete callback should be called");
    });

    RUN_TEST("testRestoreFailedCallback", []() {
        BackupManager bm;
        bm.initialize();
        bool callbackCalled = false;
        bm.setRestoreFailedCallback([&callbackCalled](const BackupEntry&) {
            callbackCalled = true;
        });
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.verifyBackup(backups[0].id);
        bm.setFailNextRestore(true);
        bm.executeRestore(backups[0].id);
        ASSERT_TRUE(callbackCalled, "restore failed callback should be called");
    });

    RUN_TEST("testProgressCallback", []() {
        BackupManager bm;
        bm.initialize();
        bool callbackCalled = false;
        bm.setProgressCallback([&callbackCalled](const BackupProgress&) {
            callbackCalled = true;
        });
        bm.createBackup(makeEntry("backup1"));
        auto backups = bm.getBackups();
        bm.updateBackupProgress(backups[0].id, 1024, 10, 0);
        ASSERT_TRUE(callbackCalled, "progress callback should be called");
    });

    // ============================================================
    // Schedule tests
    // ============================================================

    RUN_TEST("testSchedule", []() {
        BackupManager bm;
        bm.initialize();
        BackupSchedule schedule;
        schedule.autoBackupEnabled = true;
        schedule.intervalHours = 12;
        bm.setSchedule(schedule);
        auto retrieved = bm.getSchedule();
        ASSERT_TRUE(retrieved.autoBackupEnabled, "autoBackupEnabled should be true");
        ASSERT_EQ(static_cast<int>(retrieved.intervalHours), 12, "intervalHours should be 12");
    });

    RUN_TEST("testShouldAutoBackup", []() {
        BackupManager bm;
        bm.initialize();
        BackupSchedule schedule;
        schedule.autoBackupEnabled = true;
        schedule.nextBackupTime = 0;  // Never backed up
        bm.setSchedule(schedule);
        ASSERT_TRUE(bm.shouldAutoBackup(1000), "should auto-backup when never backed up before");
    });

    RUN_TEST("testShouldAutoBackupDisabled", []() {
        BackupManager bm;
        bm.initialize();
        BackupSchedule schedule;
        schedule.autoBackupEnabled = false;
        bm.setSchedule(schedule);
        ASSERT_FALSE(bm.shouldAutoBackup(1000), "should not auto-backup when disabled");
    });

    RUN_TEST("testShouldAutoBackupNotDue", []() {
        BackupManager bm;
        bm.initialize();
        BackupSchedule schedule;
        schedule.autoBackupEnabled = true;
        schedule.nextBackupTime = 100000;
        bm.setSchedule(schedule);
        ASSERT_FALSE(bm.shouldAutoBackup(50000), "should not auto-backup when not due yet");
    });

    // ============================================================
    // Integration tests
    // ============================================================

    RUN_TEST("testLogServerIntegration", []() {
        BackupManager bm;
        bm.initialize();
        phantom::logging::LogServer logServer;
        logServer.initialize();
        bm.setLogServer(&logServer);
        ASSERT_EQ(static_cast<int>(bm.getLogServer() != nullptr ? 1 : 0), 1, "log server should be set");
        bm.createBackup(makeEntry("backup1"));
        // LogServer should have received log entries
        auto logs = logServer.getRecentLogs(10);
        ASSERT_TRUE(!logs.empty(), "log server should have entries");
        bm.shutdown();
        logServer.shutdown();
    });

    RUN_TEST("testCrashReporterIntegration", []() {
        BackupManager bm;
        bm.initialize();
        phantom::crashreporter::CrashReporter crashReporter;
        crashReporter.initialize();
        bm.setCrashReporter(&crashReporter);
        ASSERT_EQ(static_cast<int>(bm.getCrashReporter() != nullptr ? 1 : 0), 1, "crash reporter should be set");
        bm.shutdown();
        crashReporter.shutdown();
    });

    RUN_TEST("testFullLifecycle", []() {
        BackupManager bm;
        bm.initialize();

        // Create backup
        bm.createBackup(makeEntry("full_backup", BackupType::FULL_SYSTEM));
        auto backups = bm.getBackups();
        ASSERT_EQ(static_cast<int>(backups.size()), 1, "should have 1 backup");

        // Verify
        ASSERT_TRUE(bm.verifyBackup(backups[0].id) == BackupResult::SUCCESS, "verification should succeed");

        // Plan restore
        RestorePlan plan = bm.planRestore(backups[0].id, RestoreMode::FULL);
        ASSERT_FALSE(plan.planSummary.empty(), "restore plan should have summary");

        // Execute restore
        ASSERT_TRUE(bm.executeRestoreFromPlan(plan) == BackupResult::SUCCESS, "restore should succeed");

        // Delete backup
        // State is RESTORED, not active, so delete should work
        ASSERT_TRUE(bm.deleteBackup(backups[0].id) == BackupResult::SUCCESS, "delete should succeed");
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 0, "should have 0 backups after delete");
    });

    RUN_TEST("testMultipleBackupsSameType", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("full1", BackupType::FULL_SYSTEM));
        bm.createBackup(makeEntry("full2", BackupType::FULL_SYSTEM));
        bm.createBackup(makeEntry("full3", BackupType::FULL_SYSTEM));
        ASSERT_EQ(static_cast<int>(bm.getCountByType(BackupType::FULL_SYSTEM)), 3,
                  "should have 3 FULL_SYSTEM backups");
    });

    // ============================================================
    // String helper tests
    // ============================================================

    RUN_TEST("testBackupTypeToString", []() {
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::FULL_SYSTEM), "FULL_SYSTEM", "FULL_SYSTEM string");
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::APP_DATA), "APP_DATA", "APP_DATA string");
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::SETTINGS), "SETTINGS", "SETTINGS string");
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::MEDIA), "MEDIA", "MEDIA string");
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::CONFIG), "CONFIG", "CONFIG string");
        ASSERT_STREQ(BackupManager::backupTypeToString(BackupType::SECURITY_KEYS), "SECURITY_KEYS", "SECURITY_KEYS string");
    });

    RUN_TEST("testBackupStateToString", []() {
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::IDLE), "IDLE", "IDLE string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::SCANNING), "SCANNING", "SCANNING string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::BACKING_UP), "BACKING_UP", "BACKING_UP string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::VERIFYING), "VERIFYING", "VERIFYING string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::COMPLETED), "COMPLETED", "COMPLETED string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::FAILED), "FAILED", "FAILED string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::CANCELLED), "CANCELLED", "CANCELLED string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::RESTORING), "RESTORING", "RESTORING string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::RESTORED), "RESTORED", "RESTORED string");
        ASSERT_STREQ(BackupManager::backupStateToString(BackupState::RESTORE_FAILED), "RESTORE_FAILED", "RESTORE_FAILED string");
    });

    RUN_TEST("testBackupDestinationToString", []() {
        ASSERT_STREQ(BackupManager::backupDestinationToString(BackupDestination::LOCAL), "LOCAL", "LOCAL string");
        ASSERT_STREQ(BackupManager::backupDestinationToString(BackupDestination::EXTERNAL), "EXTERNAL", "EXTERNAL string");
        ASSERT_STREQ(BackupManager::backupDestinationToString(BackupDestination::ENCRYPTED_ARCHIVE), "ENCRYPTED_ARCHIVE", "ENCRYPTED_ARCHIVE string");
        ASSERT_STREQ(BackupManager::backupDestinationToString(BackupDestination::CLOUD_STUB), "CLOUD_STUB", "CLOUD_STUB string");
    });

    RUN_TEST("testBackupPrivacyToString", []() {
        ASSERT_STREQ(BackupManager::backupPrivacyToString(BackupPrivacy::FULL), "FULL", "FULL string");
        ASSERT_STREQ(BackupManager::backupPrivacyToString(BackupPrivacy::ANONYMIZED), "ANONYMIZED", "ANONYMIZED string");
        ASSERT_STREQ(BackupManager::backupPrivacyToString(BackupPrivacy::MINIMAL), "MINIMAL", "MINIMAL string");
        ASSERT_STREQ(BackupManager::backupPrivacyToString(BackupPrivacy::DISABLED), "DISABLED", "DISABLED string");
    });

    RUN_TEST("testRestoreModeToString", []() {
        ASSERT_STREQ(BackupManager::restoreModeToString(RestoreMode::FULL), "FULL", "FULL string");
        ASSERT_STREQ(BackupManager::restoreModeToString(RestoreMode::SELECTIVE), "SELECTIVE", "SELECTIVE string");
        ASSERT_STREQ(BackupManager::restoreModeToString(RestoreMode::MERGE), "MERGE", "MERGE string");
        ASSERT_STREQ(BackupManager::restoreModeToString(RestoreMode::DRY_RUN), "DRY_RUN", "DRY_RUN string");
    });

    RUN_TEST("testBackupResultToString", []() {
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::SUCCESS), "SUCCESS", "SUCCESS string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::NOT_INITIALIZED), "NOT_INITIALIZED", "NOT_INITIALIZED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::ALREADY_INITIALIZED), "ALREADY_INITIALIZED", "ALREADY_INITIALIZED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::INVALID_BACKUP), "INVALID_BACKUP", "INVALID_BACKUP string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::NOT_FOUND), "NOT_FOUND", "NOT_FOUND string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::BAD_STATE), "BAD_STATE", "BAD_STATE string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::CHECKSUM_FAILED), "CHECKSUM_FAILED", "CHECKSUM_FAILED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::VERIFICATION_FAILED), "VERIFICATION_FAILED", "VERIFICATION_FAILED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::BACKUP_FAILED), "BACKUP_FAILED", "BACKUP_FAILED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::RESTORE_FAILED), "RESTORE_FAILED", "RESTORE_FAILED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::POLICY_BLOCKED), "POLICY_BLOCKED", "POLICY_BLOCKED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::QUOTA_EXCEEDED), "QUOTA_EXCEEDED", "QUOTA_EXCEEDED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::ALREADY_EXISTS), "ALREADY_EXISTS", "ALREADY_EXISTS string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::CANCELLED), "CANCELLED", "CANCELLED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::INVALID_PARAMETER), "INVALID_PARAMETER", "INVALID_PARAMETER string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::ENCRYPTION_REQUIRED), "ENCRYPTION_REQUIRED", "ENCRYPTION_REQUIRED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::RETENTION_EXCEEDED), "RETENTION_EXCEEDED", "RETENTION_EXCEEDED string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::IN_PROGRESS), "IN_PROGRESS", "IN_PROGRESS string");
        ASSERT_STREQ(BackupManager::backupResultToString(BackupResult::NO_BACKUP_AVAILABLE), "NO_BACKUP_AVAILABLE", "NO_BACKUP_AVAILABLE string");
    });

    RUN_TEST("testStringToBackupType", []() {
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("FULL_SYSTEM")), static_cast<int>(BackupType::FULL_SYSTEM), "parse FULL_SYSTEM");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("APP_DATA")), static_cast<int>(BackupType::APP_DATA), "parse APP_DATA");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("SETTINGS")), static_cast<int>(BackupType::SETTINGS), "parse SETTINGS");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("MEDIA")), static_cast<int>(BackupType::MEDIA), "parse MEDIA");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("CONFIG")), static_cast<int>(BackupType::CONFIG), "parse CONFIG");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("SECURITY_KEYS")), static_cast<int>(BackupType::SECURITY_KEYS), "parse SECURITY_KEYS");
        // Default
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupType("UNKNOWN")), static_cast<int>(BackupType::FULL_SYSTEM), "default to FULL_SYSTEM");
    });

    RUN_TEST("testStringToBackupDestination", []() {
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupDestination("LOCAL")), static_cast<int>(BackupDestination::LOCAL), "parse LOCAL");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupDestination("EXTERNAL")), static_cast<int>(BackupDestination::EXTERNAL), "parse EXTERNAL");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupDestination("ENCRYPTED_ARCHIVE")), static_cast<int>(BackupDestination::ENCRYPTED_ARCHIVE), "parse ENCRYPTED_ARCHIVE");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupDestination("CLOUD_STUB")), static_cast<int>(BackupDestination::CLOUD_STUB), "parse CLOUD_STUB");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupDestination("UNKNOWN")), static_cast<int>(BackupDestination::LOCAL), "default to LOCAL");
    });

    RUN_TEST("testStringToBackupPrivacy", []() {
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupPrivacy("FULL")), static_cast<int>(BackupPrivacy::FULL), "parse FULL");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupPrivacy("ANONYMIZED")), static_cast<int>(BackupPrivacy::ANONYMIZED), "parse ANONYMIZED");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupPrivacy("MINIMAL")), static_cast<int>(BackupPrivacy::MINIMAL), "parse MINIMAL");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupPrivacy("DISABLED")), static_cast<int>(BackupPrivacy::DISABLED), "parse DISABLED");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToBackupPrivacy("UNKNOWN")), static_cast<int>(BackupPrivacy::ANONYMIZED), "default to ANONYMIZED");
    });

    RUN_TEST("testStringToRestoreMode", []() {
        ASSERT_EQ(static_cast<int>(BackupManager::stringToRestoreMode("FULL")), static_cast<int>(RestoreMode::FULL), "parse FULL");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToRestoreMode("SELECTIVE")), static_cast<int>(RestoreMode::SELECTIVE), "parse SELECTIVE");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToRestoreMode("MERGE")), static_cast<int>(RestoreMode::MERGE), "parse MERGE");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToRestoreMode("DRY_RUN")), static_cast<int>(RestoreMode::DRY_RUN), "parse DRY_RUN");
        ASSERT_EQ(static_cast<int>(BackupManager::stringToRestoreMode("UNKNOWN")), static_cast<int>(RestoreMode::FULL), "default to FULL");
    });

    // ============================================================
    // Edge cases
    // ============================================================

    RUN_TEST("testOperationsNotInitialized", []() {
        BackupManager bm;
        ASSERT_EQ(static_cast<int>(bm.createBackup(makeEntry("test"))), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "createBackup not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.cancelBackup(1)), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "cancelBackup not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.deleteBackup(1)), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "deleteBackup not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.verifyBackup(1)), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "verifyBackup not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.executeRestore(1)), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "executeRestore not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.deleteAllBackups()), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "deleteAllBackups not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.pruneBackups()), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "pruneBackups not initialized should fail");
        ASSERT_EQ(static_cast<int>(bm.clearHistory()), static_cast<int>(BackupResult::NOT_INITIALIZED),
                  "clearHistory not initialized should fail");
    });

    RUN_TEST("testShutdownClearsAll", []() {
        BackupManager bm;
        bm.initialize();
        bm.createBackup(makeEntry("backup1"));
        bm.createBackup(makeEntry("backup2"));
        bm.createBackup(makeEntry("backup3"));
        bm.shutdown();
        ASSERT_EQ(static_cast<int>(bm.getBackupCount()), 0, "backups should be cleared");
        ASSERT_EQ(static_cast<int>(bm.getHistory().size()), 0, "history should be cleared");
        BackupStats stats = bm.getStats();
        ASSERT_EQ(static_cast<int>(stats.totalBackupsCreated), 0, "stats should be cleared");
    });

    std::cout << "\n=== Summary ===" << std::endl;
    std::cout << "Tests passed: " << tests_passed << std::endl;
    std::cout << "Tests failed: " << tests_failed << std::endl;
    std::cout << "Total: " << (tests_passed + tests_failed) << std::endl;
}

int main() {
    std::cout << "=== Backup Manager Tests ===" << std::endl;
    runAllTests();
    return tests_failed > 0 ? 1 : 0;
}
