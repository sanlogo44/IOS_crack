/*
 * Phantom OS - App Lifecycle Manager Tests
 * Tests for the app lifecycle manager (Start, Stop, Pause, Resume)
 *
 * License: GPL-3.0
 */

#include "phantom/app_lifecycle.h"
#include <cassert>
#include <cstdio>
#include <memory>
#include <string>

using namespace phantom::framework;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

// Test callback tracker
class TestAppCallbacks : public IAppLifecycleCallbacks {
public:
    int create_count = 0;
    int start_count = 0;
    int resume_count = 0;
    int pause_count = 0;
    int stop_count = 0;
    int destroy_count = 0;
    std::string last_app_id;

    void onCreate(const std::string& appId) override { create_count++; last_app_id = appId; }
    void onStart(const std::string& appId) override { start_count++; last_app_id = appId; }
    void onResume(const std::string& appId) override { resume_count++; last_app_id = appId; }
    void onPause(const std::string& appId) override { pause_count++; last_app_id = appId; }
    void onStop(const std::string& appId) override { stop_count++; last_app_id = appId; }
    void onDestroy(const std::string& appId) override { destroy_count++; last_app_id = appId; }
};

// Helper to create app info
AppInfo makeAppInfo(const std::string& id, const std::string& name = "TestApp",
                    AppPriority priority = AppPriority::NORMAL) {
    AppInfo info;
    info.app_id = id;
    info.name = name;
    info.version = "1.0.0";
    info.priority = priority;
    return info;
}

bool test_register_app() {
    TEST("Register app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    auto result = alm.registerApp(makeAppInfo("com.test.app1"));
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should register successfully");
    ASSERT(alm.isAppRegistered("com.test.app1"), "App should be registered");
    ASSERT(alm.getRegisteredCount() == 1, "Should have 1 registered app");
    PASS();
    return true;
}

bool test_duplicate_register() {
    TEST("Duplicate registration fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.dup"));
    auto result = alm.registerApp(makeAppInfo("com.test.dup"));
    ASSERT(result == AppLifecycleResult::ALREADY_REGISTERED, "Should fail on duplicate");
    PASS();
    return true;
}

bool test_start_app() {
    TEST("Start app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.start"));
    auto result = alm.startApp("com.test.start");
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should start successfully");
    ASSERT(alm.isAppRunning("com.test.start"), "App should be running");
    ASSERT(alm.getAppState("com.test.start") == AppState::RUNNING, "State should be RUNNING");
    PASS();
    return true;
}

bool test_pause_resume() {
    TEST("Pause and resume app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.pause"));
    alm.startApp("com.test.pause");

    auto pauseResult = alm.pauseApp("com.test.pause");
    ASSERT(pauseResult == AppLifecycleResult::SUCCESS, "Should pause successfully");
    ASSERT(alm.getAppState("com.test.pause") == AppState::PAUSED, "State should be PAUSED");

    auto resumeResult = alm.resumeApp("com.test.pause");
    ASSERT(resumeResult == AppLifecycleResult::SUCCESS, "Should resume successfully");
    ASSERT(alm.getAppState("com.test.pause") == AppState::RUNNING, "State should be RUNNING");
    PASS();
    return true;
}

bool test_stop_app() {
    TEST("Stop app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.stop"));
    alm.startApp("com.test.stop");
    auto result = alm.stopApp("com.test.stop");
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should stop successfully");
    ASSERT(alm.getAppState("com.test.stop") == AppState::STOPPED, "State should be STOPPED");
    ASSERT(!alm.isAppRunning("com.test.stop"), "App should not be running");
    PASS();
    return true;
}

bool test_destroy_app() {
    TEST("Destroy app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.destroy"));
    alm.startApp("com.test.destroy");
    auto result = alm.destroyApp("com.test.destroy");
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should destroy successfully");
    ASSERT(!alm.isAppRegistered("com.test.destroy"), "App should not be registered");
    ASSERT(alm.getRegisteredCount() == 0, "Should have 0 registered apps");
    PASS();
    return true;
}

bool test_callbacks_fire() {
    TEST("Lifecycle callbacks fire");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    auto callbacks = std::make_shared<TestAppCallbacks>();
    alm.registerApp(makeAppInfo("com.test.callbacks"), callbacks);
    alm.startApp("com.test.callbacks");
    ASSERT(callbacks->create_count == 1, "onCreate should be called once");
    ASSERT(callbacks->start_count == 1, "onStart should be called once");
    ASSERT(callbacks->resume_count == 1, "onResume should be called once");

    alm.pauseApp("com.test.callbacks");
    ASSERT(callbacks->pause_count == 1, "onPause should be called once");

    alm.resumeApp("com.test.callbacks");
    ASSERT(callbacks->resume_count == 2, "onResume should be called twice");

    alm.stopApp("com.test.callbacks");
    ASSERT(callbacks->stop_count == 1, "onStop should be called once");
    ASSERT(callbacks->destroy_count == 1, "onDestroy should be called once");
    PASS();
    return true;
}

bool test_start_nonexistent() {
    TEST("Start non-existent app fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    auto result = alm.startApp("com.test.nonexistent");
    ASSERT(result == AppLifecycleResult::APP_NOT_FOUND, "Should return APP_NOT_FOUND");
    PASS();
    return true;
}

bool test_pause_not_running() {
    TEST("Pause non-running app fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.pauser"));
    auto result = alm.pauseApp("com.test.pauser");
    ASSERT(result == AppLifecycleResult::NOT_RUNNING, "Should return NOT_RUNNING");
    PASS();
    return true;
}

bool test_resume_not_paused() {
    TEST("Resume non-paused app fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.resumer"));
    alm.startApp("com.test.resumer");
    auto result = alm.resumeApp("com.test.resumer");
    ASSERT(result == AppLifecycleResult::NOT_PAUSED, "Should return NOT_PAUSED");
    PASS();
    return true;
}

bool test_start_already_running() {
    TEST("Start already running app fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.alreadyrunning"));
    alm.startApp("com.test.alreadyrunning");
    auto result = alm.startApp("com.test.alreadyrunning");
    ASSERT(result == AppLifecycleResult::ALREADY_RUNNING, "Should return ALREADY_RUNNING");
    PASS();
    return true;
}

bool test_state_history() {
    TEST("State history tracking");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.history"));
    alm.startApp("com.test.history");
    alm.pauseApp("com.test.history");
    alm.resumeApp("com.test.history");
    alm.stopApp("com.test.history");

    auto history = alm.getStateHistory("com.test.history");
    // REGISTERED->STARTING, STARTING->RUNNING, RUNNING->PAUSED, PAUSED->RUNNING, RUNNING->STOPPING, STOPPING->STOPPED
    ASSERT(history.size() >= 6, "Should have at least 6 state transitions");
    PASS();
    return true;
}

bool test_start_count() {
    TEST("Start count tracking");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.startcount"));
    alm.startApp("com.test.startcount");
    alm.stopApp("com.test.startcount");
    alm.startApp("com.test.startcount");
    ASSERT(alm.getStartCount("com.test.startcount") == 2, "Should have been started 2 times");
    PASS();
    return true;
}

bool test_pause_count() {
    TEST("Pause count tracking");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.pausecount"));
    alm.startApp("com.test.pausecount");
    alm.pauseApp("com.test.pausecount");
    alm.resumeApp("com.test.pausecount");
    alm.pauseApp("com.test.pausecount");
    alm.resumeApp("com.test.pausecount");
    ASSERT(alm.getPauseCount("com.test.pausecount") == 2, "Should have been paused 2 times");
    PASS();
    return true;
}

bool test_stop_all() {
    TEST("Stop all apps");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.stopall1", "App1", AppPriority::HIGH));
    alm.registerApp(makeAppInfo("com.test.stopall2", "App2", AppPriority::LOW));
    alm.startApp("com.test.stopall1");
    alm.startApp("com.test.stopall2");
    auto result = alm.stopAll();
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should stop all successfully");
    ASSERT(alm.getRunningCount() == 0, "Should have 0 running apps");
    PASS();
    return true;
}

bool test_get_running_apps() {
    TEST("Get running apps list");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.run1"));
    alm.registerApp(makeAppInfo("com.test.run2"));
    alm.registerApp(makeAppInfo("com.test.run3"));
    alm.startApp("com.test.run1");
    alm.startApp("com.test.run2");
    auto running = alm.getRunningApps();
    ASSERT(running.size() == 2, "Should have 2 running apps");
    PASS();
    return true;
}

bool test_get_paused_apps() {
    TEST("Get paused apps list");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.p1"));
    alm.registerApp(makeAppInfo("com.test.p2"));
    alm.startApp("com.test.p1");
    alm.startApp("com.test.p2");
    alm.pauseApp("com.test.p1");
    auto paused = alm.getPausedApps();
    ASSERT(paused.size() == 1, "Should have 1 paused app");
    PASS();
    return true;
}

bool test_unregister_app() {
    TEST("Unregister app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.unreg"));
    auto result = alm.unregisterApp("com.test.unreg");
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should unregister successfully");
    ASSERT(!alm.isAppRegistered("com.test.unreg"), "App should not be registered");
    PASS();
    return true;
}

bool test_unregister_running_fails() {
    TEST("Unregister running app fails");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.unregrun"));
    alm.startApp("com.test.unregrun");
    auto result = alm.unregisterApp("com.test.unregrun");
    ASSERT(result == AppLifecycleResult::ALREADY_RUNNING, "Should fail to unregister running app");
    PASS();
    return true;
}

bool test_invalid_app() {
    TEST("Register invalid app (empty ID)");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    AppInfo empty;
    empty.app_id = "";
    auto result = alm.registerApp(empty);
    ASSERT(result == AppLifecycleResult::INVALID_APP, "Should return INVALID_APP");
    PASS();
    return true;
}

bool test_state_change_callback() {
    TEST("State change callback");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    std::string callback_app;
    AppState callback_old = AppState::REGISTERED;
    AppState callback_new = AppState::REGISTERED;
    int callback_count = 0;

    alm.setStateChangeCallback([&](const std::string& appId, AppState oldState, AppState newState) {
        callback_app = appId;
        callback_old = oldState;
        callback_new = newState;
        callback_count++;
    });

    alm.registerApp(makeAppInfo("com.test.callback"));
    alm.startApp("com.test.callback");

    ASSERT(callback_count > 0, "Callback should have been called");
    ASSERT(callback_app == "com.test.callback", "Callback should have correct app ID");
    PASS();
    return true;
}

bool test_restart_stopped_app() {
    TEST("Restart a stopped app");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.restart"));
    alm.startApp("com.test.restart");
    alm.stopApp("com.test.restart");
    auto result = alm.startApp("com.test.restart");
    ASSERT(result == AppLifecycleResult::SUCCESS, "Should restart successfully");
    ASSERT(alm.isAppRunning("com.test.restart"), "App should be running again");
    PASS();
    return true;
}

bool test_start_all_auto() {
    TEST("Start all auto-start apps");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    auto info1 = makeAppInfo("com.test.auto1");
    info1.auto_start = true;
    auto info2 = makeAppInfo("com.test.auto2");
    info2.auto_start = false;
    auto info3 = makeAppInfo("com.test.auto3");
    info3.auto_start = true;
    alm.registerApp(info1);
    alm.registerApp(info2);
    alm.registerApp(info3);
    alm.startAllAuto();
    ASSERT(alm.isAppRunning("com.test.auto1"), "Auto-start app 1 should be running");
    ASSERT(!alm.isAppRunning("com.test.auto2"), "Non-auto-start app should not be running");
    ASSERT(alm.isAppRunning("com.test.auto3"), "Auto-start app 3 should be running");
    PASS();
    return true;
}

bool test_double_pause() {
    TEST("Double pause returns ALREADY_PAUSED");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    alm.registerApp(makeAppInfo("com.test.doublepause"));
    alm.startApp("com.test.doublepause");
    alm.pauseApp("com.test.doublepause");
    auto result = alm.pauseApp("com.test.doublepause");
    ASSERT(result == AppLifecycleResult::ALREADY_PAUSED, "Should return ALREADY_PAUSED");
    PASS();
    return true;
}

bool test_valid_transitions() {
    TEST("Valid state transitions");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::REGISTERED, AppState::STARTING), "REGISTERED->STARTING should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::STARTING, AppState::RUNNING), "STARTING->RUNNING should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::RUNNING, AppState::PAUSED), "RUNNING->PAUSED should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::PAUSED, AppState::RUNNING), "PAUSED->RUNNING should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::RUNNING, AppState::STOPPING), "RUNNING->STOPPING should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::STOPPING, AppState::STOPPED), "STOPPING->STOPPED should be valid");
    ASSERT(AppLifecycleManager::isValidTransition(AppState::STOPPED, AppState::STARTING), "STOPPED->STARTING should be valid");
    ASSERT(!AppLifecycleManager::isValidTransition(AppState::REGISTERED, AppState::RUNNING), "REGISTERED->RUNNING should be invalid");
    ASSERT(!AppLifecycleManager::isValidTransition(AppState::STOPPED, AppState::PAUSED), "STOPPED->PAUSED should be invalid");
    PASS();
    return true;
}

bool test_get_app_info() {
    TEST("Get app info");
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();
    auto info = makeAppInfo("com.test.info", "TestApp", AppPriority::HIGH);
    info.version = "2.1.0";
    info.target_sdk = 30;
    info.required_permissions = {"camera", "location"};
    alm.registerApp(info);

    auto retrieved = alm.getAppInfo("com.test.info");
    ASSERT(retrieved.app_id == "com.test.info", "App ID should match");
    ASSERT(retrieved.name == "TestApp", "Name should match");
    ASSERT(retrieved.version == "2.1.0", "Version should match");
    ASSERT(retrieved.priority == AppPriority::HIGH, "Priority should match");
    ASSERT(retrieved.target_sdk == 30, "Target SDK should match");
    ASSERT(retrieved.required_permissions.size() == 2, "Should have 2 permissions");
    PASS();
    return true;
}

bool test_state_to_string() {
    TEST("State to string conversion");
    ASSERT(std::string(AppLifecycleManager::stateToString(AppState::REGISTERED)) == "REGISTERED", "REGISTERED string");
    ASSERT(std::string(AppLifecycleManager::stateToString(AppState::RUNNING)) == "RUNNING", "RUNNING string");
    ASSERT(std::string(AppLifecycleManager::stateToString(AppState::PAUSED)) == "PAUSED", "PAUSED string");
    ASSERT(std::string(AppLifecycleManager::stateToString(AppState::STOPPED)) == "STOPPED", "STOPPED string");
    ASSERT(std::string(AppLifecycleManager::stateToString(AppState::CRASHED)) == "CRASHED", "CRASHED string");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - App Lifecycle Manager Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_register_app();
    all_pass &= test_duplicate_register();
    all_pass &= test_start_app();
    all_pass &= test_pause_resume();
    all_pass &= test_stop_app();
    all_pass &= test_destroy_app();
    all_pass &= test_callbacks_fire();
    all_pass &= test_start_nonexistent();
    all_pass &= test_pause_not_running();
    all_pass &= test_resume_not_paused();
    all_pass &= test_start_already_running();
    all_pass &= test_state_history();
    all_pass &= test_start_count();
    all_pass &= test_pause_count();
    all_pass &= test_stop_all();
    all_pass &= test_get_running_apps();
    all_pass &= test_get_paused_apps();
    all_pass &= test_unregister_app();
    all_pass &= test_unregister_running_fails();
    all_pass &= test_invalid_app();
    all_pass &= test_state_change_callback();
    all_pass &= test_restart_stopped_app();
    all_pass &= test_start_all_auto();
    all_pass &= test_double_pause();
    all_pass &= test_valid_transitions();
    all_pass &= test_get_app_info();
    all_pass &= test_state_to_string();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
