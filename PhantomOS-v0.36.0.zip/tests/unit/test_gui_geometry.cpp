/*
 * Phantom OS - GUI Geometry Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/geometry.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_point_construction() {
    Point p1;
    ASSERT(p1.x == 0 && p1.y == 0, "Default point should be (0,0)");

    Point p2(10, 20);
    ASSERT(p2.x == 10 && p2.y == 20, "Point(10,20) should have x=10,y=20");

    ASSERT(p1 != p2, "Different points should not be equal");
    ASSERT(Point(10, 20) == p2, "Equal points should be equal");

    return true;
}

bool test_size() {
    Size s1;
    ASSERT(s1.isEmpty(), "Default size should be empty");
    ASSERT(s1.area() == 0, "Empty size area should be 0");

    Size s2(100, 200);
    ASSERT(!s2.isEmpty(), "100x200 should not be empty");
    ASSERT(s2.area() == 20000, "100x200 area should be 20000");

    return true;
}

bool test_rect_contains() {
    Rect r(10, 10, 100, 100);

    ASSERT(r.contains(Point(50, 50)), "Point inside rect should be contained");
    ASSERT(r.contains(10, 10), "Top-left corner should be contained (inclusive)");
    ASSERT(!r.contains(110, 110), "Point at right/bottom edge should not be contained (exclusive)");
    ASSERT(!r.contains(5, 5), "Point outside should not be contained");
    ASSERT(!r.contains(110, 50), "Point at right edge should not be contained (exclusive)");

    return true;
}

bool test_rect_intersection() {
    Rect r1(0, 0, 100, 100);
    Rect r2(50, 50, 100, 100);

    ASSERT(r1.intersects(r2), "Overlapping rects should intersect");

    Rect inter = r1.intersection(r2);
    ASSERT(inter.x == 50 && inter.y == 50, "Intersection origin should be (50,50)");
    ASSERT(inter.width == 50 && inter.height == 50, "Intersection size should be 50x50");

    Rect r3(200, 200, 50, 50);
    ASSERT(!r1.intersects(r3), "Non-overlapping rects should not intersect");
    ASSERT(r1.intersection(r3).isEmpty(), "Non-overlapping intersection should be empty");

    return true;
}

bool test_rect_clamp() {
    Rect bounds(0, 0, 100, 100);

    Rect inside(10, 10, 50, 50);
    Rect clamped = inside.clampTo(bounds);
    ASSERT(clamped == inside, "Inside rect should not change when clamped");

    Rect outside(-10, -10, 50, 50);
    Rect clamped2 = outside.clampTo(bounds);
    ASSERT(clamped2.x == 0 && clamped2.y == 0, "Negative origin should clamp to 0");
    ASSERT(clamped2.width == 40 && clamped2.height == 40, "Clamped size should shrink");

    Rect beyond(80, 80, 50, 50);
    Rect clamped3 = beyond.clampTo(bounds);
    ASSERT(clamped3.right() <= 100, "Clamped right should not exceed bounds");
    ASSERT(clamped3.bottom() <= 100, "Clamped bottom should not exceed bounds");

    return true;
}

bool test_rect_edge_methods() {
    Rect r(10, 20, 30, 40);
    ASSERT(r.left() == 10, "Left should be x");
    ASSERT(r.top() == 20, "Top should be y");
    ASSERT(r.right() == 40, "Right should be x+width");
    ASSERT(r.bottom() == 60, "Bottom should be y+height");
    ASSERT(r.origin() == Point(10, 20), "Origin should be (x,y)");
    ASSERT(r.size() == Size(30, 40), "Size should be (width,height)");

    return true;
}

int main() {
    printf("=== GUI Geometry Tests ===\n");
    test_point_construction();
    test_size();
    test_rect_contains();
    test_rect_intersection();
    test_rect_clamp();
    test_rect_edge_methods();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
