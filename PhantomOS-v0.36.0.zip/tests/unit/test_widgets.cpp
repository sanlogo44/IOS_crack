/*
 * Phantom OS - Widget Tests
 * Tests for Button, Label, TextField, ListView
 *
 * License: GPL-3.0
 */

#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_label_construction() {
    Label label(1, "Hello");
    ASSERT(label.getId() == 1, "Label ID should be 1");
    ASSERT(label.getText() == "Hello", "Label text should be 'Hello'");
    ASSERT(label.isVisible(), "Label should be visible by default");
    ASSERT(label.isEnabled(), "Label should be enabled by default");

    return true;
}

bool test_label_set_text() {
    Label label(1, "Test");
    label.setText("New Text");
    ASSERT(label.getText() == "New Text", "Label text should be 'New Text'");

    return true;
}

bool test_label_measure() {
    Label label(1, "Hello");
    Size s = label.onMeasure();
    // 5 chars * 6px = 30, + padding (0) = 30
    ASSERT(s.width == 30, "Label measure width should be 30 for 'Hello'");
    ASSERT(s.height == 7, "Label measure height should be 7");

    label.setPadding(4);
    Size s2 = label.onMeasure();
    ASSERT(s2.width == 38, "Label with padding should be 38 wide");
    ASSERT(s2.height == 15, "Label with padding should be 15 tall");

    return true;
}

bool test_label_render() {
    Label label(1, "Hi");
    label.setBounds(Rect(0, 0, 50, 20));
    label.setTextColor(Color::White);

    Framebuffer fb(50, 20);
    fb.clear(Color::Black);

    BitmapFont font;
    label.onRender(fb, font);

    // Check some pixels are white
    int32_t nonBlack = 0;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != Color::Black.toRGBA32()) nonBlack++;
    }
    ASSERT(nonBlack > 0, "Label render should produce non-black pixels");

    return true;
}

bool test_button_construction() {
    Button btn(1, "Click Me");
    ASSERT(btn.getId() == 1, "Button ID should be 1");
    ASSERT(btn.getText() == "Click Me", "Button text should be 'Click Me'");
    ASSERT(btn.isClickable(), "Button should be clickable");
    ASSERT(btn.isFocusable(), "Button should be focusable");
    ASSERT(btn.isEnabled(), "Button should be enabled");

    return true;
}

bool test_button_click_callback() {
    Button btn(1, "OK");
    bool clicked = false;
    btn.setOnClick([&clicked](Widget* w) {
        clicked = true;
    });

    // Simulate touch down then up
    btn.onTouchDown(5, 5);
    ASSERT(!clicked, "Should not fire on touch down");

    btn.onTouchUp(5, 5);
    ASSERT(clicked, "Should fire on touch up");

    return true;
}

bool test_button_disabled() {
    Button btn(1, "OK");
    btn.setEnabled(false);

    bool clicked = false;
    btn.setOnClick([&clicked](Widget* w) {
        clicked = true;
    });

    btn.onTouchDown(5, 5);
    btn.onTouchUp(5, 5);
    ASSERT(!clicked, "Disabled button should not fire click");

    return true;
}

bool test_button_measure() {
    Button btn(1, "OK");
    Size s = btn.onMeasure();
    // "OK" = 2 chars * 6 = 12px text + 4 padding = 16
    // Height = 7 + 4 = 11
    ASSERT(s.width > 12, "Button width should be > 12");
    ASSERT(s.height > 7, "Button height should be > 7");

    return true;
}

bool test_textfield_construction() {
    TextField tf(1, "Hello");
    ASSERT(tf.getText() == "Hello", "TextField text should be 'Hello'");
    ASSERT(tf.getCursorPosition() == 5, "Cursor should be at end");

    return true;
}

bool test_textfield_insert_delete() {
    TextField tf(1, "Hi");
    ASSERT(tf.getText() == "Hi", "Initial text should be 'Hi'");

    tf.setCursorPosition(1);
    tf.insertChar('X');
    ASSERT(tf.getText() == "HXi", "After inserting X at pos 1: 'HXi'");
    ASSERT(tf.getCursorPosition() == 2, "Cursor should be at position 2");

    tf.deleteChar();
    ASSERT(tf.getText() == "Hi", "After deleting at pos 2: 'Hi'");
    ASSERT(tf.getCursorPosition() == 1, "Cursor should be at position 1");

    return true;
}

bool test_textfield_clear() {
    TextField tf(1, "Hello");
    tf.clear();
    ASSERT(tf.getText().empty(), "After clear, text should be empty");
    ASSERT(tf.getCursorPosition() == 0, "After clear, cursor should be at 0");

    return true;
}

bool test_listview_construction() {
    ListView lv(1, 10);
    ASSERT(lv.getItemCount() == 10, "ListView should have 10 items");
    ASSERT(lv.getSelectedIndex() == -1, "No item selected initially");

    return true;
}

bool test_listview_selection() {
    ListView lv(1, 10);
    lv.setSelectedIndex(3);
    ASSERT(lv.getSelectedIndex() == 3, "Selected index should be 3");

    lv.setSelectedIndex(-1);
    ASSERT(lv.getSelectedIndex() == -1, "Selected index should be -1 after deselect");

    lv.setSelectedIndex(15);  // Out of bounds
    ASSERT(lv.getSelectedIndex() == -1, "Out of bounds selection should be ignored");

    return true;
}

bool test_listview_scroll() {
    ListView lv(1, 20);
    lv.setBounds(Rect(0, 0, 200, 60));
    lv.setItemHeight(12);

    ASSERT(lv.getVisibleItemCount() == 5, "60px height / 12px items = 5 visible");

    lv.scrollBy(24);
    ASSERT(lv.getScrollOffset() == 24, "Scroll offset should be 24");

    lv.scrollTo(5);
    ASSERT(lv.getScrollOffset() == 60, "Scroll to item 5 should be offset 60");

    // Scroll past end
    lv.scrollTo(100);
    // Should be clamped to maxOffset = 20*12 - 60 = 180
    ASSERT(lv.getScrollOffset() == 180, "Scroll past end should be clamped to 180");

    // Scroll before start
    lv.scrollBy(-1000);
    ASSERT(lv.getScrollOffset() == 0, "Scroll before start should be clamped to 0");

    return true;
}

bool test_listview_item_callback() {
    ListView lv(1, 5);
    lv.setItemTextCallback([](size_t index) -> std::string {
        return "Item " + std::to_string(index);
    });

    bool clicked = false;
    size_t clickedIndex = 0;
    lv.setItemClickCallback([&clicked, &clickedIndex](size_t index) {
        clicked = true;
        clickedIndex = index;
    });

    lv.setBounds(Rect(0, 0, 200, 60));
    lv.setItemHeight(12);

    // Tap on second item (y = 12-23)
    lv.onTouchDown(5, 15);
    ASSERT(clicked, "Item click callback should fire");
    ASSERT(clickedIndex == 1, "Should have clicked item 1");
    ASSERT(lv.getSelectedIndex() == 1, "Selected index should be 1");

    return true;
}

int main() {
    printf("=== Widget Tests ===\n");
    test_label_construction();
    test_label_set_text();
    test_label_measure();
    test_label_render();
    test_button_construction();
    test_button_click_callback();
    test_button_disabled();
    test_button_measure();
    test_textfield_construction();
    test_textfield_insert_delete();
    test_textfield_clear();
    test_listview_construction();
    test_listview_selection();
    test_listview_scroll();
    test_listview_item_callback();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
