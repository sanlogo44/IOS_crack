/*
 * Phantom OS - Animation System Tests
 * Tests for Easing, ValueAnimator, PropertyAnimator, Transition, AnimationManager
 *
 * License: GPL-3.0
 */

#include "phantom/gui/animation.h"
#include "phantom/gui/widget.h"
#include "phantom/gui/framebuffer.h"
#include <cassert>
#include <cstdio>
#include <cmath>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

// ============================================================
// Easing Function Tests
// ============================================================

bool test_easing_linear_endpoints() {
    ASSERT(fabs(Easing::apply(EasingType::LINEAR, 0.0f) - 0.0f) < 0.001f, "Linear(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::LINEAR, 1.0f) - 1.0f) < 0.001f, "Linear(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::LINEAR, 0.5f) - 0.5f) < 0.001f, "Linear(0.5) should be 0.5");
    return true;
}

bool test_easing_ease_in_quad() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_QUAD, 0.0f) - 0.0f) < 0.001f, "EaseInQuad(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_QUAD, 1.0f) - 1.0f) < 0.001f, "EaseInQuad(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_QUAD, 0.5f) - 0.25f) < 0.001f, "EaseInQuad(0.5) should be 0.25");
    return true;
}

bool test_easing_ease_out_quad() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_QUAD, 0.0f) - 0.0f) < 0.001f, "EaseOutQuad(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_QUAD, 1.0f) - 1.0f) < 0.001f, "EaseOutQuad(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_QUAD, 0.5f) - 0.75f) < 0.001f, "EaseOutQuad(0.5) should be 0.75");
    return true;
}

bool test_easing_ease_in_out_quad() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_OUT_QUAD, 0.0f) - 0.0f) < 0.001f, "EaseInOutQuad(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_OUT_QUAD, 1.0f) - 1.0f) < 0.001f, "EaseInOutQuad(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_OUT_QUAD, 0.5f) - 0.5f) < 0.001f, "EaseInOutQuad(0.5) should be 0.5");
    return true;
}

bool test_easing_ease_in_cubic() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_CUBIC, 0.0f) - 0.0f) < 0.001f, "EaseInCubic(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_CUBIC, 1.0f) - 1.0f) < 0.001f, "EaseInCubic(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_CUBIC, 0.5f) - 0.125f) < 0.001f, "EaseInCubic(0.5) should be 0.125");
    return true;
}

bool test_easing_ease_out_cubic() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_CUBIC, 0.0f) - 0.0f) < 0.001f, "EaseOutCubic(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_CUBIC, 1.0f) - 1.0f) < 0.001f, "EaseOutCubic(1) should be 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_CUBIC, 0.5f) - 0.875f) < 0.001f, "EaseOutCubic(0.5) should be 0.875");
    return true;
}

bool test_easing_ease_out_bounce_endpoints() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_BOUNCE, 0.0f) - 0.0f) < 0.001f, "EaseOutBounce(0) should be 0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_BOUNCE, 1.0f) - 1.0f) < 0.001f, "EaseOutBounce(1) should be 1");
    // Bounce should stay in [0, 1] range
    for (float t = 0.0f; t <= 1.0f; t += 0.01f) {
        float v = Easing::apply(EasingType::EASE_OUT_BOUNCE, t);
        ASSERT(v >= -0.001f && v <= 1.001f, "EaseOutBounce should stay in [0,1]");
    }
    return true;
}

bool test_easing_ease_out_back_endpoints() {
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_BACK, 0.0f) - 0.0f) < 0.01f, "EaseOutBack(0) should be ~0");
    ASSERT(fabs(Easing::apply(EasingType::EASE_OUT_BACK, 1.0f) - 1.0f) < 0.01f, "EaseOutBack(1) should be ~1");
    return true;
}

bool test_easing_clamped_input() {
    ASSERT(fabs(Easing::apply(EasingType::LINEAR, -0.5f) - 0.0f) < 0.001f, "Linear(-0.5) clamped to 0");
    ASSERT(fabs(Easing::apply(EasingType::LINEAR, 1.5f) - 1.0f) < 0.001f, "Linear(1.5) clamped to 1");
    ASSERT(fabs(Easing::apply(EasingType::EASE_IN_QUAD, -1.0f) - 0.0f) < 0.001f, "EaseInQuad(-1) clamped to 0");
    return true;
}

// ============================================================
// ValueAnimator Tests
// ============================================================

bool test_value_animator_construction() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    ASSERT(anim.getStartValue() == 0.0f, "Start value should be 0");
    ASSERT(anim.getEndValue() == 100.0f, "End value should be 100");
    ASSERT(anim.getDuration() == 1000, "Duration should be 1000ms");
    ASSERT(anim.getState() == AnimationState::IDLE, "Should be IDLE");
    return true;
}

bool test_value_animator_start_and_update() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    anim.start();
    ASSERT(anim.getState() == AnimationState::RUNNING, "Should be RUNNING after start");
    ASSERT(anim.getCurrentValue() == 0.0f, "Current value should be 0 at start");

    anim.update(500);
    ASSERT(fabs(anim.getCurrentValue() - 50.0f) < 0.1f, "After 500ms, value should be ~50");
    ASSERT(fabs(anim.getProgress() - 0.5f) < 0.001f, "Progress should be 0.5");

    anim.update(500);
    ASSERT(fabs(anim.getCurrentValue() - 100.0f) < 0.1f, "After 1000ms total, value should be ~100");
    ASSERT(anim.getState() == AnimationState::COMPLETED, "Should be COMPLETED");
    return true;
}

bool test_value_animator_completion_callback() {
    ValueAnimator anim(0.0f, 10.0f, 100, EasingType::LINEAR);
    int callbackCount = 0;
    anim.setCompleteCallback([&]() { callbackCount++; });

    anim.start();
    anim.update(100);
    ASSERT(callbackCount == 1, "Completion callback should fire once");

    // Update again — callback should NOT fire again
    anim.update(100);
    ASSERT(callbackCount == 1, "Completion callback should not fire again");
    return true;
}

bool test_value_animator_zero_duration() {
    ValueAnimator anim(0.0f, 42.0f, 0, EasingType::LINEAR);
    int callbackCount = 0;
    anim.setCompleteCallback([&]() { callbackCount++; });

    anim.start();
    anim.update(0);
    ASSERT(fabs(anim.getCurrentValue() - 42.0f) < 0.001f, "Zero-duration should set end value immediately");
    ASSERT(anim.getState() == AnimationState::COMPLETED, "Zero-duration should complete immediately");
    ASSERT(callbackCount == 1, "Completion callback should fire once for zero-duration");
    return true;
}

bool test_value_animator_pause_resume() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(250);
    ASSERT(fabs(anim.getCurrentValue() - 25.0f) < 0.1f, "After 250ms, value should be ~25");

    anim.pause();
    ASSERT(anim.getState() == AnimationState::PAUSED, "Should be PAUSED");

    anim.update(500);  // Should not advance while paused
    ASSERT(fabs(anim.getCurrentValue() - 25.0f) < 0.1f, "Value should not change while paused");
    ASSERT(fabs(anim.getProgress() - 0.25f) < 0.001f, "Progress should not change while paused");

    anim.resume();
    ASSERT(anim.getState() == AnimationState::RUNNING, "Should be RUNNING after resume");

    anim.update(750);
    ASSERT(anim.getState() == AnimationState::COMPLETED, "Should complete after remaining time");
    return true;
}

bool test_value_animator_cancel() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);
    ASSERT(anim.getState() == AnimationState::RUNNING, "Should be running");

    anim.cancel();
    ASSERT(anim.getState() == AnimationState::CANCELLED, "Should be CANCELLED");

    anim.update(500);  // Should not advance after cancel
    ASSERT(anim.getState() == AnimationState::CANCELLED, "Should remain CANCELLED");
    return true;
}

bool test_value_animator_loop() {
    ValueAnimator anim(0.0f, 10.0f, 100, EasingType::LINEAR);
    anim.setLoop(true);
    anim.start();

    anim.update(100);
    // After first loop, should restart
    ASSERT(anim.getState() == AnimationState::RUNNING, "Looping anim should still be running");

    anim.update(50);
    ASSERT(fabs(anim.getProgress() - 0.5f) < 0.001f, "Second loop should be at 50% progress");
    return true;
}

bool test_value_animator_update_callback() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    float lastValue = -1.0f;
    anim.setUpdateCallback([&](float v) { lastValue = v; });

    anim.start();
    anim.update(500);
    ASSERT(fabs(lastValue - 50.0f) < 0.1f, "Update callback should receive ~50");
    return true;
}

bool test_value_animator_reset() {
    ValueAnimator anim(0.0f, 100.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);
    ASSERT(anim.getState() == AnimationState::RUNNING, "Should be running");

    anim.reset();
    ASSERT(anim.getState() == AnimationState::IDLE, "Should be IDLE after reset");
    ASSERT(anim.getProgress() == 0.0f, "Progress should be 0 after reset");
    return true;
}

// ============================================================
// PropertyAnimator Tests
// ============================================================

bool test_property_animator_x() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    PropertyAnimator anim(&w, PropertyAnimator::Property::X, 0.0f, 100.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);

    ASSERT(w.getBounds().x == 50, "Widget X should be 50 after half animation");
    ASSERT(w.getBounds().y == 0, "Widget Y should be unchanged");
    ASSERT(w.getBounds().width == 50, "Widget width should be unchanged");
    return true;
}

bool test_property_animator_y() {
    Widget w(1, "test");
    w.setBounds(Rect(10, 0, 50, 30));

    PropertyAnimator anim(&w, PropertyAnimator::Property::Y, 0.0f, 200.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);

    ASSERT(w.getBounds().y == 100, "Widget Y should be 100 after half animation");
    ASSERT(w.getBounds().x == 10, "Widget X should be unchanged");
    return true;
}

bool test_property_animator_width() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    PropertyAnimator anim(&w, PropertyAnimator::Property::WIDTH, 50.0f, 150.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);

    ASSERT(w.getBounds().width == 100, "Widget width should be 100 after half animation");
    ASSERT(w.getBounds().height == 30, "Widget height should be unchanged");
    return true;
}

bool test_property_animator_height() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    PropertyAnimator anim(&w, PropertyAnimator::Property::HEIGHT, 30.0f, 90.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);

    ASSERT(w.getBounds().height == 60, "Widget height should be 60 after half animation");
    ASSERT(w.getBounds().width == 50, "Widget width should be unchanged");
    return true;
}

bool test_property_animator_alpha() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    PropertyAnimator anim(&w, PropertyAnimator::Property::ALPHA, 1.0f, 0.0f, 1000, EasingType::LINEAR);
    anim.start();
    anim.update(500);

    ASSERT(fabs(w.getAlpha() - 0.5f) < 0.01f, "Widget alpha should be ~0.5 after half animation");
    return true;
}

bool test_property_animator_alpha_clamping() {
    Widget w(1, "test");

    PropertyAnimator anim(&w, PropertyAnimator::Property::ALPHA, -0.5f, 1.5f, 100, EasingType::LINEAR);
    anim.start();
    anim.update(100);

    // Alpha should be clamped to [0, 1]
    ASSERT(w.getAlpha() >= 0.0f, "Alpha should not be negative");
    ASSERT(w.getAlpha() <= 1.0f, "Alpha should not exceed 1.0");
    return true;
}

bool test_property_animator_complete_callback() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    int callbackCount = 0;
    PropertyAnimator anim(&w, PropertyAnimator::Property::X, 0.0f, 100.0f, 500, EasingType::LINEAR);
    anim.setCompleteCallback([&]() { callbackCount++; });

    anim.start();
    anim.update(500);
    ASSERT(callbackCount == 1, "Complete callback should fire once");

    anim.update(100);
    ASSERT(callbackCount == 1, "Complete callback should not fire again");
    return true;
}

bool test_property_animator_fade_factory() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    auto anim = PropertyAnimator::animateFade(&w, 1.0f, 0.0f, 500);
    anim->start();
    anim->update(250);

    ASSERT(fabs(w.getAlpha() - 0.5f) < 0.01f, "Fade should set alpha to ~0.5 at midpoint");
    return true;
}

// ============================================================
// Transition Tests
// ============================================================

bool test_transition_fade_in() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    Transition trans(TransitionType::FADE_IN, 300);
    trans.setWidget(&w);
    trans.start();

    ASSERT(fabs(w.getAlpha() - 0.0f) < 0.01f, "FadeIn should set alpha to 0 at start");

    trans.update(150);
    ASSERT(fabs(w.getAlpha() - 0.5f) < 0.01f, "FadeIn should set alpha to ~0.5 at midpoint");

    trans.update(150);
    ASSERT(trans.getState() == AnimationState::COMPLETED, "FadeIn should complete after duration");
    return true;
}

bool test_transition_fade_out() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    Transition trans(TransitionType::FADE_OUT, 300);
    trans.setWidget(&w);
    trans.start();

    ASSERT(fabs(w.getAlpha() - 1.0f) < 0.01f, "FadeOut should start at alpha 1");

    trans.update(300);
    ASSERT(fabs(w.getAlpha() - 0.0f) < 0.01f, "FadeOut should end at alpha 0");
    return true;
}

bool test_transition_slide_in_left() {
    Widget w(1, "test");
    w.setBounds(Rect(100, 50, 80, 40));

    Transition trans(TransitionType::SLIDE_IN_LEFT, 250);
    trans.setWidget(&w);
    trans.start();

    // Widget should start off-screen to the left
    ASSERT(w.getBounds().x == 20, "SlideInLeft should start at x=100-80=20");

    trans.update(250);
    ASSERT(w.getBounds().x == 100, "SlideInLeft should end at original x=100");
    return true;
}

bool test_transition_slide_out_right() {
    Widget w(1, "test");
    w.setBounds(Rect(100, 50, 80, 40));

    Transition trans(TransitionType::SLIDE_OUT_RIGHT, 250);
    trans.setWidget(&w);
    trans.start();

    trans.update(250);
    ASSERT(w.getBounds().x == 180, "SlideOutRight should end at x=100+80=180");
    return true;
}

bool test_transition_scale_in() {
    Widget w(1, "test");
    w.setBounds(Rect(50, 50, 100, 100));

    Transition trans(TransitionType::SCALE_IN, 200);
    trans.setWidget(&w);
    trans.start();

    ASSERT(w.getBounds().width == 0, "ScaleIn should start at width 0");
    ASSERT(w.getBounds().height == 0, "ScaleIn should start at height 0");

    trans.update(200);
    ASSERT(w.getBounds().width == 100, "ScaleIn should end at original width 100");
    ASSERT(w.getBounds().height == 100, "ScaleIn should end at original height 100");
    return true;
}

bool test_transition_default_duration() {
    ASSERT(Transition::getDefaultDuration(TransitionType::FADE_IN) == 300, "FadeIn default should be 300ms");
    ASSERT(Transition::getDefaultDuration(TransitionType::SLIDE_IN_LEFT) == 250, "SlideInLeft default should be 250ms");
    ASSERT(Transition::getDefaultDuration(TransitionType::SCALE_IN) == 200, "ScaleIn default should be 200ms");
    return true;
}

bool test_transition_complete_callback() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    int callbackCount = 0;
    Transition trans(TransitionType::FADE_IN, 100);
    trans.setWidget(&w);
    trans.setCompleteCallback([&]() { callbackCount++; });

    trans.start();
    trans.update(100);
    ASSERT(callbackCount == 1, "Transition complete callback should fire once");

    trans.update(100);
    ASSERT(callbackCount == 1, "Transition complete callback should not fire again");
    return true;
}

bool test_transition_type() {
    Transition trans(TransitionType::SLIDE_IN_TOP);
    ASSERT(trans.getType() == TransitionType::SLIDE_IN_TOP, "Type should be SLIDE_IN_TOP");
    return true;
}

// ============================================================
// AnimationManager Tests
// ============================================================

bool test_manager_add_and_update() {
    AnimationManager& mgr = AnimationManager::getInstance();
    mgr.clear();

    auto anim = std::make_shared<ValueAnimator>(0.0f, 100.0f, 1000, EasingType::LINEAR);
    mgr.add(anim);
    ASSERT(mgr.getTotalCount() == 1, "Should have 1 animation");
    ASSERT(mgr.getActiveCount() == 0, "Should have 0 active (IDLE)");

    anim->start();
    ASSERT(mgr.getActiveCount() == 1, "Should have 1 active (RUNNING)");

    mgr.update(500);
    ASSERT(mgr.getActiveCount() == 1, "Should still be active");

    mgr.update(500);
    ASSERT(mgr.getActiveCount() == 0, "Should have 0 active after completion");

    mgr.cleanup();
    ASSERT(mgr.getTotalCount() == 0, "Should have 0 total after cleanup");
    return true;
}

bool test_manager_clear() {
    AnimationManager& mgr = AnimationManager::getInstance();
    mgr.clear();

    mgr.add(std::make_shared<ValueAnimator>(0.0f, 10.0f, 100));
    mgr.add(std::make_shared<ValueAnimator>(0.0f, 20.0f, 200));
    ASSERT(mgr.getTotalCount() == 2, "Should have 2 animations");

    mgr.clear();
    ASSERT(mgr.getTotalCount() == 0, "Should have 0 after clear");
    return true;
}

bool test_manager_cancel_for_widget() {
    AnimationManager& mgr = AnimationManager::getInstance();
    mgr.clear();

    Widget w1(1, "w1");
    w1.setBounds(Rect(0, 0, 50, 30));
    Widget w2(2, "w2");
    w2.setBounds(Rect(0, 0, 50, 30));

    auto anim1 = std::make_shared<PropertyAnimator>(&w1, PropertyAnimator::Property::X,
                                                      0.0f, 100.0f, 1000);
    auto anim2 = std::make_shared<PropertyAnimator>(&w2, PropertyAnimator::Property::X,
                                                      0.0f, 200.0f, 1000);

    mgr.add(anim1);
    mgr.add(anim2);
    anim1->start();
    anim2->start();

    ASSERT(mgr.getActiveCount() == 2, "Should have 2 active");

    mgr.cancelForWidget(&w1);
    ASSERT(mgr.getActiveCount() == 1, "Should have 1 active after canceling w1's animation");
    ASSERT(mgr.getTotalCount() == 1, "Should have 1 total after cleanup (w2's anim remains)");
    return true;
}

bool test_manager_cancel_for_widget_with_transition() {
    AnimationManager& mgr = AnimationManager::getInstance();
    mgr.clear();

    Widget w(1, "test");
    w.setBounds(Rect(50, 50, 80, 40));
    w.setAlpha(1.0f);

    auto trans = std::make_shared<Transition>(TransitionType::FADE_IN, 300);
    trans->setWidget(&w);

    mgr.add(trans);
    trans->start();

    ASSERT(mgr.getActiveCount() == 1, "Should have 1 active transition");

    mgr.cancelForWidget(&w);
    ASSERT(mgr.getActiveCount() == 0, "Should have 0 active after cancelForWidget");
    return true;
}

bool test_manager_cleanup_removes_completed() {
    AnimationManager& mgr = AnimationManager::getInstance();
    mgr.clear();

    auto anim = std::make_shared<ValueAnimator>(0.0f, 10.0f, 100);
    mgr.add(anim);
    anim->start();
    mgr.update(100);

    ASSERT(mgr.getTotalCount() == 1, "Should have 1 before cleanup");
    ASSERT(mgr.getActiveCount() == 0, "Should have 0 active (completed)");

    mgr.cleanup();
    ASSERT(mgr.getTotalCount() == 0, "Should have 0 after cleanup");
    return true;
}

bool test_widget_alpha_property() {
    Widget w(1, "test");
    ASSERT(fabs(w.getAlpha() - 1.0f) < 0.001f, "Default alpha should be 1.0");

    w.setAlpha(0.5f);
    ASSERT(fabs(w.getAlpha() - 0.5f) < 0.001f, "Alpha should be 0.5");

    w.setAlpha(-1.0f);
    ASSERT(fabs(w.getAlpha() - 0.0f) < 0.001f, "Alpha should be clamped to 0");

    w.setAlpha(2.0f);
    ASSERT(fabs(w.getAlpha() - 1.0f) < 0.001f, "Alpha should be clamped to 1");
    return true;
}

bool test_property_animator_complete_reaches_end_x() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    PropertyAnimator anim(&w, PropertyAnimator::Property::X, 0.0f, 100.0f, 500, EasingType::LINEAR);
    anim.start();
    anim.update(500);
    ASSERT(w.getBounds().x == 100, "Completed X animation should reach end value 100");
    return true;
}

bool test_property_animator_complete_reaches_end_alpha() {
    Widget w(1, "test");
    w.setAlpha(1.0f);

    PropertyAnimator anim(&w, PropertyAnimator::Property::ALPHA, 1.0f, 0.0f, 500, EasingType::LINEAR);
    anim.start();
    anim.update(500);
    ASSERT(fabs(w.getAlpha() - 0.0f) < 0.01f, "Completed alpha animation should reach end value 0");
    return true;
}

bool test_property_animator_negative_width_clamped() {
    Widget w(1, "test");
    w.setBounds(Rect(0, 0, 50, 30));

    // Animate width from 50 to -100 (should be clamped to 0)
    PropertyAnimator anim(&w, PropertyAnimator::Property::WIDTH, 50.0f, -100.0f, 100, EasingType::LINEAR);
    anim.start();
    anim.update(100);
    ASSERT(w.getBounds().width == 0, "Width should be clamped to 0 for negative values");
    return true;
}

int main() {
    printf("=== Animation System Tests ===\n");

    // Easing
    test_easing_linear_endpoints();
    test_easing_ease_in_quad();
    test_easing_ease_out_quad();
    test_easing_ease_in_out_quad();
    test_easing_ease_in_cubic();
    test_easing_ease_out_cubic();
    test_easing_ease_out_bounce_endpoints();
    test_easing_ease_out_back_endpoints();
    test_easing_clamped_input();

    // ValueAnimator
    test_value_animator_construction();
    test_value_animator_start_and_update();
    test_value_animator_completion_callback();
    test_value_animator_zero_duration();
    test_value_animator_pause_resume();
    test_value_animator_cancel();
    test_value_animator_loop();
    test_value_animator_update_callback();
    test_value_animator_reset();

    // PropertyAnimator
    test_property_animator_x();
    test_property_animator_y();
    test_property_animator_width();
    test_property_animator_height();
    test_property_animator_alpha();
    test_property_animator_alpha_clamping();
    test_property_animator_complete_callback();
    test_property_animator_fade_factory();
    test_property_animator_complete_reaches_end_x();
    test_property_animator_complete_reaches_end_alpha();
    test_property_animator_negative_width_clamped();

    // Transition
    test_transition_fade_in();
    test_transition_fade_out();
    test_transition_slide_in_left();
    test_transition_slide_out_right();
    test_transition_scale_in();
    test_transition_default_duration();
    test_transition_complete_callback();
    test_transition_type();

    // AnimationManager
    test_manager_add_and_update();
    test_manager_clear();
    test_manager_cancel_for_widget();
    test_manager_cancel_for_widget_with_transition();
    test_manager_cleanup_removes_completed();

    // Widget alpha
    test_widget_alpha_property();

    printf("\nResults: %d/%d passed (%d tests)\n", pass_count, test_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
