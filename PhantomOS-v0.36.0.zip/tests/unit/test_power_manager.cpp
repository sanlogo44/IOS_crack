/*
 * Phantom OS - Power Manager Tests
 * v0.26.0 - License: GPL-3.0
 *
 * Tests for PowerManager: lifecycle, battery simulation, states,
 * thresholds, auto power saver with hysteresis, manual override,
 * wake locks (acquire/release/duplicate/capacity/expiry), system power
 * state (suspend/resume/hibernate/shutdown/reboot), thermal management,
 * policy queries, events, stats, callbacks, failure simulation,
 * integrations, string helpers
 */

#include "phantom/power/power_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST(test) do { \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    std::cout << " OK" << std::endl; \
} while(0)

using namespace phantom::power;
using namespace phantom::logging;
using namespace phantom::crashreporter;

// ============================================================
// Lifecycle tests
// ============================================================

static void test_lifecycle() {
    PowerManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 500, 500), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), PowerResult::ALREADY_INITIALIZED);
    ASSERT_EQ(mgr.getMaxWakeLocks(), (size_t)64);
    ASSERT_EQ(mgr.getMaxEvents(), (size_t)500);
    ASSERT_EQ(mgr.getMaxHistory(), (size_t)500);
    ASSERT_EQ(mgr.shutdown(), PowerResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), PowerResult::NOT_INITIALIZED);
}

static void test_initialize_invalid_params() {
    PowerManager mgr;
    ASSERT_EQ(mgr.initialize(0), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 0), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 500, 0), PowerResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_not_initialized_operations() {
    PowerManager mgr;
    ASSERT_EQ(mgr.setBatteryLevelForTesting(50), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::USB), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setChargingForTesting(true, ChargingType::FAST_STUB),
              PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setBatteryPresentForTesting(false), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.simulateDrain(10), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.simulateCharge(10), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setBatteryThresholds(20, 5, 15, "system"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setPowerMode(PowerMode::PERFORMANCE, "com.app"),
              PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL), (uint64_t)0);
    ASSERT_EQ(mgr.releaseWakeLock(1, "com.app"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.releaseWakeLocksByOwner("com.app"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.processExpiredWakeLocks(), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::POWER_BUTTON), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.resume(WakeReason::TOUCH), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.requestShutdown("system"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.requestReboot("system"), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::HOT), PowerResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearEvents(), PowerResult::NOT_INITIALIZED);
}

static void test_shutdown_clears_state() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setBatteryLevelForTesting(10);
    mgr.setPowerMode(PowerMode::PERFORMANCE, "com.app");
    mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL);
    mgr.setThermalStateForTesting(ThermalState::HOT);
    mgr.shutdown();
    // All state reset to defaults
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)75);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::DISCHARGING);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);
    ASSERT_FALSE(mgr.isManualModeOverride());
    ASSERT_TRUE(mgr.isAutoPowerSaverEnabled());
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    ASSERT_TRUE(mgr.isPoweredOn());
    ASSERT_EQ(mgr.getThermalState(), ThermalState::NORMAL);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)0);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_EQ(mgr.getLowThreshold(), (uint8_t)20);
    ASSERT_EQ(mgr.getCriticalThreshold(), (uint8_t)5);
    ASSERT_EQ(mgr.getAutoSaverThreshold(), (uint8_t)15);
}

// ============================================================
// Battery simulation tests
// ============================================================

static void test_battery_defaults() {
    PowerManager mgr;
    mgr.initialize();
    BatteryStatus battery = mgr.getBatteryStatus();
    ASSERT_EQ(battery.level, (uint8_t)75);
    ASSERT_EQ(battery.state, BatteryState::DISCHARGING);
    ASSERT_EQ(battery.source, PowerSource::BATTERY);
    ASSERT_FALSE(battery.charging);
    ASSERT_EQ(battery.chargingType, ChargingType::NONE);
    ASSERT_EQ(battery.voltageMv, (uint32_t)3810);
    ASSERT_EQ(battery.temperatureCelsius, (int32_t)25);
    ASSERT_TRUE(mgr.isPoweredOn());
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
}

static void test_battery_level_changes() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setBatteryLevelForTesting(50), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)50);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::DISCHARGING);
    // Invalid level
    ASSERT_EQ(mgr.setBatteryLevelForTesting(101), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)50);
    // Stats and events
    ASSERT_EQ(mgr.getStats().batteryLevelChanges, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::BATTERY_CHANGED).size(), (size_t)1);
    // Same level: no change event
    ASSERT_EQ(mgr.setBatteryLevelForTesting(50), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().batteryLevelChanges, (uint64_t)1);
}

static void test_battery_low_and_critical() {
    PowerManager mgr;
    mgr.initialize();
    // 20% or below is LOW
    mgr.setBatteryLevelForTesting(20);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::LOW);
    ASSERT_EQ(mgr.getStats().lowWarnings, (uint64_t)1);
    // 5% or below is CRITICAL
    mgr.setBatteryLevelForTesting(5);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::CRITICAL);
    ASSERT_EQ(mgr.getStats().criticalWarnings, (uint64_t)1);
    // LOW_POWER_WARNING events
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::LOW_POWER_WARNING).size(), (size_t)2);
    // Recovery: CRITICAL -> LOW does not re-warn
    mgr.setBatteryLevelForTesting(10);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::LOW);
    ASSERT_EQ(mgr.getStats().lowWarnings, (uint64_t)1);
    ASSERT_EQ(mgr.getStats().criticalWarnings, (uint64_t)1);
    // Full recovery
    mgr.setBatteryLevelForTesting(80);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::DISCHARGING);
}

static void test_battery_full_and_not_present() {
    PowerManager mgr;
    mgr.initialize();
    // Charging at 100% is FULL
    mgr.setChargingForTesting(true, ChargingType::STANDARD);
    mgr.setBatteryLevelForTesting(100);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::FULL);
    ASSERT_TRUE(mgr.getBatteryStatus().charging);
    // Battery removed
    ASSERT_EQ(mgr.setBatteryPresentForTesting(false), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::NOT_PRESENT);
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)0);
    ASSERT_EQ(mgr.setBatteryPresentForTesting(true), PowerResult::SUCCESS);
    // Re-inserted battery discharges (charging was cleared on removal)
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::DISCHARGING);
}

static void test_battery_drain_and_charge() {
    PowerManager mgr;
    mgr.initialize();
    // Drain
    ASSERT_EQ(mgr.simulateDrain(10), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)65);
    ASSERT_EQ(mgr.simulateDrain(0), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.simulateDrain(101), PowerResult::INVALID_PARAMETER);
    // Clamp at 0
    mgr.simulateDrain(80);  // 65 -> 0
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)0);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::CRITICAL);
    // Charge
    ASSERT_EQ(mgr.simulateCharge(30), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)30);
    ASSERT_EQ(mgr.simulateCharge(0), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.simulateCharge(101), PowerResult::INVALID_PARAMETER);
    // Clamp at 100
    mgr.simulateCharge(90);  // 30 -> 100
    ASSERT_EQ(mgr.getBatteryStatus().level, (uint8_t)100);
}

static void test_power_source_transitions() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::USB), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().source, PowerSource::USB);
    ASSERT_TRUE(mgr.getBatteryStatus().charging);  // Non-battery source implies charging
    ASSERT_EQ(mgr.getBatteryStatus().chargingType, ChargingType::STANDARD);
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::AC_ADAPTER), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().source, PowerSource::AC_ADAPTER);
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::WIRELESS_STUB), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr.getBatteryStatus().charging);
    // Back to battery: charging stops
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::BATTERY), PowerResult::SUCCESS);
    ASSERT_FALSE(mgr.getBatteryStatus().charging);
    ASSERT_EQ(mgr.getBatteryStatus().chargingType, ChargingType::NONE);
    // Invalid
    ASSERT_EQ(mgr.setPowerSourceForTesting(PowerSource::UNKNOWN),
              PowerResult::INVALID_PARAMETER);
    // SOURCE_CHANGED events (4 changes)
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::SOURCE_CHANGED).size(), (size_t)4);
}

static void test_charging_type_transitions() {
    PowerManager mgr;
    mgr.initialize();
    // Charging on battery source switches source to USB
    ASSERT_EQ(mgr.setChargingForTesting(true, ChargingType::FAST_STUB), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr.getBatteryStatus().charging);
    ASSERT_EQ(mgr.getBatteryStatus().chargingType, ChargingType::FAST_STUB);
    ASSERT_EQ(mgr.getBatteryStatus().source, PowerSource::USB);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::CHARGING);
    // Stop charging
    ASSERT_EQ(mgr.setChargingForTesting(false, ChargingType::NONE), PowerResult::SUCCESS);
    ASSERT_FALSE(mgr.getBatteryStatus().charging);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::DISCHARGING);
    // Events
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::SOURCE_CHANGED).size(), (size_t)2);
}

static void test_remaining_minutes_estimate() {
    PowerManager mgr;
    mgr.initialize();
    // 75% balanced: 3 min per percent
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)225);
    mgr.setPowerMode(PowerMode::BATTERY_SAVER, "com.app");
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)375);
    mgr.setPowerMode(PowerMode::EXTREME_SAVER, "com.app");
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)525);
    mgr.setPowerMode(PowerMode::PERFORMANCE, "com.app");
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)225);
    // Charging: time to full = (100 - level) * 2
    mgr.setChargingForTesting(true, ChargingType::STANDARD);
    ASSERT_EQ(mgr.estimateRemainingMinutes(), (uint32_t)50);
}

// ============================================================
// Threshold tests
// ============================================================

static void test_thresholds() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getLowThreshold(), (uint8_t)20);
    ASSERT_EQ(mgr.getCriticalThreshold(), (uint8_t)5);
    ASSERT_EQ(mgr.getAutoSaverThreshold(), (uint8_t)15);
    // System-only
    ASSERT_EQ(mgr.setBatteryThresholds(30, 10, 20, "com.app"), PowerResult::PERMISSION_DENIED);
    // Invalid ordering: critical must be < autoSaver <= low
    ASSERT_EQ(mgr.setBatteryThresholds(20, 25, 15, "system"), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.setBatteryThresholds(20, 10, 25, "system"), PowerResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.setBatteryThresholds(101, 5, 15, "system"), PowerResult::INVALID_PARAMETER);
    // Valid
    ASSERT_EQ(mgr.setBatteryThresholds(30, 10, 25, "system"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getLowThreshold(), (uint8_t)30);
    ASSERT_EQ(mgr.getCriticalThreshold(), (uint8_t)10);
    ASSERT_EQ(mgr.getAutoSaverThreshold(), (uint8_t)25);
    // New thresholds take effect immediately
    mgr.setBatteryLevelForTesting(28);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::LOW);
}

// ============================================================
// Power mode tests
// ============================================================

static void test_auto_battery_saver() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);
    ASSERT_TRUE(mgr.isAutoPowerSaverEnabled());
    // Drain to 15% (auto saver threshold): saver engages
    mgr.setBatteryLevelForTesting(15);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BATTERY_SAVER);
    ASSERT_FALSE(mgr.isManualModeOverride());
    // Drain to critical: extreme saver
    mgr.setBatteryLevelForTesting(4);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::EXTREME_SAVER);
    // MODE_CHANGED events (2 transitions)
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::MODE_CHANGED).size(), (size_t)2);
    ASSERT_EQ(mgr.getStats().modeChanges, (uint64_t)2);
}

static void test_auto_saver_hysteresis() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setBatteryLevelForTesting(15);  // Saver engages
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BATTERY_SAVER);
    // Start charging: at 15% the level is not above threshold+hysteresis (20)
    mgr.setPowerSourceForTesting(PowerSource::USB);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BATTERY_SAVER);
    // Charge to 21%: above 20 -> balanced restores
    mgr.simulateCharge(6);  // 15 -> 21
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);
}

static void test_extreme_saver_at_critical() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setBatteryLevelForTesting(5);  // Critical threshold
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::CRITICAL);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::EXTREME_SAVER);
    // Charging at critical still keeps extreme saver until above hysteresis
    mgr.setChargingForTesting(true, ChargingType::STANDARD);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::EXTREME_SAVER);
    mgr.simulateCharge(30);  // 5 -> 35
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);
}

static void test_manual_mode_override() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPowerMode(PowerMode::PERFORMANCE, "com.app"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::PERFORMANCE);
    ASSERT_TRUE(mgr.isManualModeOverride());
    // Auto saver respects manual mode: draining does not switch
    mgr.setBatteryLevelForTesting(10);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::PERFORMANCE);
    mgr.setBatteryLevelForTesting(3);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::PERFORMANCE);
    // Empty owner rejected
    ASSERT_EQ(mgr.setPowerMode(PowerMode::BALANCED, ""), PowerResult::INVALID_PARAMETER);
    // Same mode with manual flag also marks manual
    PowerManager mgr2;
    mgr2.initialize();
    ASSERT_EQ(mgr2.setPowerMode(PowerMode::BALANCED, "com.app"), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr2.isManualModeOverride());
}

static void test_auto_saver_disable() {
    PowerManager mgr;
    mgr.initialize();
    // Disabled auto saver never engages
    mgr.setAutoPowerSaverEnabled(false);
    ASSERT_FALSE(mgr.isAutoPowerSaverEnabled());
    mgr.setBatteryLevelForTesting(5);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);
    // Manual mode stays manual even when auto saver re-enabled
    PowerManager mgr2;
    mgr2.initialize();
    mgr2.setPowerMode(PowerMode::PERFORMANCE, "com.app");
    mgr2.setAutoPowerSaverEnabled(false);
    mgr2.setAutoPowerSaverEnabled(true);  // Re-enable resets manual override
    ASSERT_FALSE(mgr2.isManualModeOverride());
    mgr2.setBatteryLevelForTesting(5);
    ASSERT_EQ(mgr2.getPowerMode(), PowerMode::EXTREME_SAVER);
}

// ============================================================
// Wake lock tests
// ============================================================

static void test_wake_lock_acquire_release() {
    PowerManager mgr;
    mgr.initialize();
    uint64_t id = mgr.acquireWakeLock("com.music", "playback", WakeLockType::PARTIAL);
    ASSERT_TRUE(id != 0);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)1);
    ASSERT_TRUE(mgr.hasWakeLocks());
    // Fields
    std::vector<WakeLock> locks = mgr.getActiveWakeLocks();
    ASSERT_EQ(locks.size(), (size_t)1);
    ASSERT_STREQ(locks[0].owner.c_str(), "com.music");
    ASSERT_STREQ(locks[0].tag.c_str(), "playback");
    ASSERT_EQ(locks[0].type, WakeLockType::PARTIAL);
    ASSERT_EQ(locks[0].timeoutMs, (uint64_t)0);  // No timeout
    // Invalid owner/tag
    ASSERT_EQ(mgr.acquireWakeLock("", "tag", WakeLockType::PARTIAL), (uint64_t)0);
    ASSERT_EQ(mgr.acquireWakeLock("owner", "", WakeLockType::PARTIAL), (uint64_t)0);
    // Events and stats
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::WAKE_LOCK_ACQUIRED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().wakeLocksAcquired, (uint64_t)1);
    // Release
    ASSERT_EQ(mgr.releaseWakeLock(id, "com.music"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)0);
    ASSERT_EQ(mgr.getStats().wakeLocksReleased, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::WAKE_LOCK_RELEASED).size(), (size_t)1);
}

static void test_wake_lock_duplicate_and_types() {
    PowerManager mgr;
    mgr.initialize();
    uint64_t id1 = mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL);
    ASSERT_TRUE(id1 != 0);
    // Same owner+tag+type rejected
    ASSERT_EQ(mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL), (uint64_t)0);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(PowerResult::WAKE_LOCK_EXISTS)],
              (uint64_t)1);
    // Different type is a new lock
    uint64_t id2 = mgr.acquireWakeLock("com.app", "tag", WakeLockType::DISPLAY);
    ASSERT_TRUE(id2 != 0);
    // Different owner is a new lock
    uint64_t id3 = mgr.acquireWakeLock("com.other", "tag", WakeLockType::PARTIAL);
    ASSERT_TRUE(id3 != 0);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)3);
    // Unique ids
    ASSERT_TRUE(id1 != id2);
    ASSERT_TRUE(id2 != id3);
}

static void test_wake_lock_capacity() {
    PowerManager mgr;
    mgr.initialize(2);
    ASSERT_TRUE(mgr.acquireWakeLock("a", "1", WakeLockType::PARTIAL) != 0);
    ASSERT_TRUE(mgr.acquireWakeLock("a", "2", WakeLockType::PARTIAL) != 0);
    ASSERT_EQ(mgr.acquireWakeLock("a", "3", WakeLockType::PARTIAL), (uint64_t)0);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(PowerResult::CAPACITY_EXCEEDED)],
              (uint64_t)1);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)2);
}

static void test_wake_lock_owner_checks() {
    PowerManager mgr;
    mgr.initialize();
    uint64_t id = mgr.acquireWakeLock("com.music", "playback", WakeLockType::PARTIAL);
    // Foreign owner cannot release
    ASSERT_EQ(mgr.releaseWakeLock(id, "com.other"), PowerResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)1);
    // System can release any lock
    ASSERT_EQ(mgr.releaseWakeLock(id, "system"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)0);
    // Not found
    ASSERT_EQ(mgr.releaseWakeLock(9999, "system"), PowerResult::WAKE_LOCK_NOT_FOUND);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(PowerResult::WAKE_LOCK_NOT_FOUND)],
              (uint64_t)1);
}

static void test_wake_lock_release_by_owner() {
    PowerManager mgr;
    mgr.initialize();
    mgr.acquireWakeLock("com.app", "1", WakeLockType::PARTIAL);
    mgr.acquireWakeLock("com.app", "2", WakeLockType::NETWORK);
    mgr.acquireWakeLock("com.other", "3", WakeLockType::CPU);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)3);
    ASSERT_EQ(mgr.releaseWakeLocksByOwner("com.app"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)1);
    ASSERT_STREQ(mgr.getActiveWakeLocks()[0].owner.c_str(), "com.other");
    // System releases all remaining
    ASSERT_EQ(mgr.releaseWakeLocksByOwner("system"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)0);
    // No locks for owner
    ASSERT_EQ(mgr.releaseWakeLocksByOwner("com.app"), PowerResult::WAKE_LOCK_NOT_FOUND);
    ASSERT_EQ(mgr.releaseWakeLocksByOwner(""), PowerResult::INVALID_PARAMETER);
}

static void test_wake_lock_expiry() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setCurrentTimeForTesting(1000000);
    uint64_t id = mgr.acquireWakeLock("com.app", "sync", WakeLockType::NETWORK, 5000);
    ASSERT_TRUE(id != 0);
    uint64_t forever = mgr.acquireWakeLock("com.app", "keep", WakeLockType::PARTIAL, 0);
    ASSERT_TRUE(forever != 0);
    // Before timeout: nothing expires
    ASSERT_EQ(mgr.processExpiredWakeLocks(), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)2);
    // Advance past the timeout
    mgr.setCurrentTimeForTesting(1005000);
    ASSERT_EQ(mgr.processExpiredWakeLocks(), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getWakeLockCount(), (size_t)1);  // No-timeout lock survives
    ASSERT_EQ(mgr.getStats().wakeLocksExpired, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::WAKE_LOCK_EXPIRED).size(), (size_t)1);
    // Forever lock still holds
    ASSERT_STREQ(mgr.getActiveWakeLocks()[0].tag.c_str(), "keep");
    mgr.clearTimeOverride();
}

// ============================================================
// System power state tests
// ============================================================

static void test_suspend_resume() {
    PowerManager mgr;
    mgr.initialize();
    // System-only
    ASSERT_EQ(mgr.requestSuspend("com.app", WakeReason::TIMER), PowerResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::SUSPENDED);
    ASSERT_EQ(mgr.getStats().suspends, (uint64_t)1);
    // Double suspend rejected
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::BAD_STATE);
    // Resume
    ASSERT_EQ(mgr.resume(WakeReason::POWER_BUTTON), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    ASSERT_EQ(mgr.getStats().resumes, (uint64_t)1);
    // Resume when awake rejected
    ASSERT_EQ(mgr.resume(WakeReason::TOUCH), PowerResult::BAD_STATE);
    // phantos.system owner also accepted
    ASSERT_EQ(mgr.requestSuspend("phantos.system", WakeReason::ALARM), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.resume(WakeReason::NETWORK), PowerResult::SUCCESS);
    // Events carry wake reasons
    std::vector<PowerEvent> suspends = mgr.getEventsByType(PowerEventType::SUSPEND);
    ASSERT_EQ(suspends.size(), (size_t)2);
    ASSERT_TRUE(suspends[0].detail.find("ALARM") != std::string::npos ||
                suspends[1].detail.find("ALARM") != std::string::npos);
}

static void test_suspend_blocked_by_wake_lock() {
    PowerManager mgr;
    mgr.initialize();
    mgr.acquireWakeLock("com.music", "playback", WakeLockType::PARTIAL);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::BAD_STATE);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    // Blocked suspend recorded as event
    std::vector<PowerEvent> events = mgr.getEventsByType(PowerEventType::SUSPEND);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_EQ(events[0].result, PowerResult::BAD_STATE);
    // Force overrides the wake lock
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER, true), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::SUSPENDED);
    ASSERT_EQ(mgr.resume(WakeReason::TOUCH), PowerResult::SUCCESS);
}

static void test_hibernate() {
    PowerManager mgr;
    mgr.initialize();
    // System-only
    ASSERT_EQ(mgr.requestHibernate("com.app"), PowerResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::HIBERNATING);
    ASSERT_EQ(mgr.getStats().hibernateRequests, (uint64_t)1);
    // Wake up from hibernation
    ASSERT_EQ(mgr.resume(WakeReason::ALARM), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    // Wake locks block hibernation
    mgr.acquireWakeLock("com.app", "work", WakeLockType::FULL);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::BAD_STATE);
    ASSERT_EQ(mgr.requestHibernate("system", true), PowerResult::SUCCESS);
    mgr.resume(WakeReason::SYSTEM);
}

static void test_hibernate_battery_too_low() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setBatteryLevelForTesting(5);  // Critical
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::BATTERY_TOO_LOW);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    // Above critical: works
    mgr.setBatteryLevelForTesting(20);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::SUCCESS);
}

static void test_shutdown() {
    PowerManager mgr;
    mgr.initialize();
    // System-only
    ASSERT_EQ(mgr.requestShutdown("com.app"), PowerResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.requestShutdown("system"), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::SHUTTING_DOWN);
    ASSERT_FALSE(mgr.isPoweredOn());
    ASSERT_EQ(mgr.getStats().shutdownRequests, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::SHUTDOWN_REQUESTED).size(), (size_t)1);
    // Further critical operations rejected
    ASSERT_EQ(mgr.requestReboot("system"), PowerResult::BAD_STATE);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::BAD_STATE);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::BAD_STATE);
}

static void test_reboot() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.requestReboot("com.app"), PowerResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.requestReboot("system"), PowerResult::SUCCESS);
    // Reboot completes instantly: system awake and powered
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    ASSERT_TRUE(mgr.isPoweredOn());
    ASSERT_EQ(mgr.getStats().rebootRequests, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::REBOOT_REQUESTED).size(), (size_t)1);
    // Wake locks block reboot unless forced
    mgr.acquireWakeLock("com.app", "update", WakeLockType::PARTIAL);
    ASSERT_EQ(mgr.requestReboot("system"), PowerResult::BAD_STATE);
    ASSERT_EQ(mgr.requestReboot("system", true), PowerResult::SUCCESS);
}

// ============================================================
// Thermal tests
// ============================================================

static void test_thermal_states_and_throttle() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getThermalState(), ThermalState::NORMAL);
    ASSERT_EQ(mgr.getThermalThrottlePercent(), (uint32_t)0);
    ASSERT_FALSE(mgr.isThermalThrottled());
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::WARM), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getThermalThrottlePercent(), (uint32_t)15);
    ASSERT_TRUE(mgr.isThermalThrottled());
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::HOT), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getThermalThrottlePercent(), (uint32_t)40);
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::CRITICAL), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getThermalThrottlePercent(), (uint32_t)75);
    // Same state: no transition
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::CRITICAL), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().thermalTransitions, (uint64_t)3);
    // Back to normal
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::NORMAL), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().thermalTransitions, (uint64_t)4);
    ASSERT_FALSE(mgr.isThermalThrottled());
    // Events
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::THERMAL_CHANGED).size(), (size_t)4);
}

static void test_thermal_blocks_suspend() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setThermalStateForTesting(ThermalState::CRITICAL);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::THERMAL_CRITICAL);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::THERMAL_CRITICAL);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(PowerResult::THERMAL_CRITICAL)],
              (uint64_t)2);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
}

static void test_thermal_shutdown_forces_power_off() {
    PowerManager mgr;
    mgr.initialize();
    // Active wake lock cannot prevent thermal protection
    mgr.acquireWakeLock("com.app", "work", WakeLockType::FULL);
    mgr.setThermalStateForTesting(ThermalState::SHUTDOWN);
    ASSERT_FALSE(mgr.isPoweredOn());
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::SHUTTING_DOWN);
    // Thermal shutdown counted
    ASSERT_EQ(mgr.getStats().shutdownRequests, (uint64_t)1);
    std::vector<PowerEvent> events = mgr.getEventsByType(PowerEventType::SHUTDOWN_REQUESTED);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_TRUE(events[0].detail.find("Thermal") != std::string::npos);
}

// ============================================================
// Policy query tests
// ============================================================

static void test_policy_queries() {
    PowerManager mgr;
    mgr.initialize();
    // Balanced: no restrictions
    ASSERT_FALSE(mgr.shouldRestrictBackgroundActivity());
    ASSERT_FALSE(mgr.shouldRestrictNetwork());
    ASSERT_FALSE(mgr.shouldDimDisplay());
    ASSERT_EQ(mgr.getCpuThrottlePercent(), (uint32_t)0);
    // Battery saver: background restricted, network still allowed
    mgr.setPowerMode(PowerMode::BATTERY_SAVER, "com.app");
    ASSERT_TRUE(mgr.shouldRestrictBackgroundActivity());
    ASSERT_FALSE(mgr.shouldRestrictNetwork());
    ASSERT_TRUE(mgr.shouldDimDisplay());
    ASSERT_EQ(mgr.getCpuThrottlePercent(), (uint32_t)30);
    // Extreme saver: everything restricted
    mgr.setPowerMode(PowerMode::EXTREME_SAVER, "com.app");
    ASSERT_TRUE(mgr.shouldRestrictNetwork());
    ASSERT_EQ(mgr.getCpuThrottlePercent(), (uint32_t)60);
    // Thermal and mode penalties combine (capped at 100)
    mgr.setThermalStateForTesting(ThermalState::WARM);  // 15 + 60 = 75
    ASSERT_EQ(mgr.getCpuThrottlePercent(), (uint32_t)75);
    mgr.setThermalStateForTesting(ThermalState::HOT);   // 40 + 60 = 100
    ASSERT_EQ(mgr.getCpuThrottlePercent(), (uint32_t)100);
}

// ============================================================
// Event tests
// ============================================================

static void test_events() {
    PowerManager mgr;
    mgr.initialize(64, 10, 500);
    // 8 battery changes -> 8 BATTERY_CHANGED events, ring caps at 10
    for (int i = 0; i < 8; i++) {
        mgr.setBatteryLevelForTesting(static_cast<uint8_t>(50 + i));
    }
    std::vector<PowerEvent> events = mgr.getEvents();
    ASSERT_EQ(events.size(), (size_t)8);
    // IDs strictly increasing
    for (size_t i = 1; i < events.size(); i++) {
        ASSERT_TRUE(events[i].id > events[i - 1].id);
    }
    ASSERT_TRUE(events[0].timestamp > 0);
    // Limit
    ASSERT_EQ(mgr.getEvents(3).size(), (size_t)3);
    // Clear moves to history
    ASSERT_EQ(mgr.clearEvents(), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_EQ(mgr.getEventsByType(PowerEventType::BATTERY_CHANGED).size(), (size_t)0);
}

static void test_event_capacity() {
    PowerManager mgr;
    mgr.initialize(64, 10, 500);
    for (int i = 0; i < 15; i++) {
        mgr.setBatteryLevelForTesting(static_cast<uint8_t>(50 + i));
    }
    // Ring buffer capped at maxEvents
    ASSERT_EQ(mgr.getEvents().size(), (size_t)10);
}

static void test_event_fields() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setPowerMode(PowerMode::BATTERY_SAVER, "com.app");
    std::vector<PowerEvent> events = mgr.getEventsByType(PowerEventType::MODE_CHANGED);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_STREQ(events[0].owner.c_str(), "com.app");
    ASSERT_EQ(events[0].result, PowerResult::SUCCESS);
    ASSERT_TRUE(events[0].detail.find("BALANCED") != std::string::npos);
    ASSERT_TRUE(events[0].detail.find("BATTERY_SAVER") != std::string::npos);
}

// ============================================================
// Stats tests
// ============================================================

static void test_stats() {
    PowerManager mgr;
    mgr.initialize();
    mgr.setBatteryLevelForTesting(15);  // LOW + auto saver
    mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL);
    mgr.releaseWakeLock(mgr.getActiveWakeLocks()[0].id, "com.app");
    mgr.requestSuspend("system", WakeReason::TIMER);
    mgr.resume(WakeReason::TOUCH);
    PowerManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.batteryLevelChanges, (uint64_t)1);
    ASSERT_EQ(stats.lowWarnings, (uint64_t)1);
    ASSERT_EQ(stats.modeChanges, (uint64_t)1);
    ASSERT_EQ(stats.wakeLocksAcquired, (uint64_t)1);
    ASSERT_EQ(stats.wakeLocksReleased, (uint64_t)1);
    ASSERT_EQ(stats.suspends, (uint64_t)1);
    ASSERT_EQ(stats.resumes, (uint64_t)1);
    ASSERT_EQ(stats.byBatteryState[static_cast<size_t>(BatteryState::LOW)], (uint64_t)1);
    ASSERT_EQ(stats.byPowerMode[static_cast<size_t>(PowerMode::BATTERY_SAVER)], (uint64_t)1);
    // Reset
    mgr.resetStats();
    stats = mgr.getStats();
    ASSERT_EQ(stats.batteryLevelChanges, (uint64_t)0);
    ASSERT_EQ(stats.modeChanges, (uint64_t)0);
    ASSERT_EQ(stats.byBatteryState[static_cast<size_t>(BatteryState::LOW)], (uint64_t)0);
    // Events survive stats reset
    ASSERT_FALSE(mgr.getEvents().empty());
}

// ============================================================
// Callback tests
// ============================================================

static void test_battery_callback() {
    PowerManager mgr;
    mgr.initialize();
    int calls = 0;
    uint8_t oldLevel = 0;
    uint8_t newLevel = 0;
    BatteryState state = BatteryState::UNKNOWN;
    mgr.setBatteryCallback([&](uint8_t o, uint8_t n, BatteryState s) {
        calls++;
        oldLevel = o;
        newLevel = n;
        state = s;
    });
    mgr.setBatteryLevelForTesting(50);
    ASSERT_EQ(calls, 1);
    ASSERT_EQ(oldLevel, (uint8_t)75);
    ASSERT_EQ(newLevel, (uint8_t)50);
    ASSERT_EQ(state, BatteryState::DISCHARGING);
    // Same level: no callback
    mgr.setBatteryLevelForTesting(50);
    ASSERT_EQ(calls, 1);
    // Drain fires callback with new state
    mgr.setBatteryLevelForTesting(10);
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(newLevel, (uint8_t)10);
    ASSERT_EQ(state, BatteryState::LOW);
}

static void test_power_mode_callback() {
    PowerManager mgr;
    mgr.initialize();
    int calls = 0;
    PowerMode oldMode = PowerMode::BALANCED;
    PowerMode newMode = PowerMode::BALANCED;
    mgr.setPowerModeCallback([&](PowerMode o, PowerMode n) {
        calls++;
        oldMode = o;
        newMode = n;
    });
    mgr.setPowerMode(PowerMode::PERFORMANCE, "com.app");
    ASSERT_EQ(calls, 1);
    ASSERT_EQ(oldMode, PowerMode::BALANCED);
    ASSERT_EQ(newMode, PowerMode::PERFORMANCE);
    // Auto saver changes fire the callback too
    mgr.setAutoPowerSaverEnabled(true);  // Resets manual override
    mgr.setBatteryLevelForTesting(10);
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(newMode, PowerMode::BATTERY_SAVER);
}

static void test_power_event_callback() {
    PowerManager mgr;
    mgr.initialize();
    int calls = 0;
    PowerEventType lastType = PowerEventType::BATTERY_CHANGED;
    mgr.setPowerEventCallback([&](const PowerEvent& event) {
        calls++;
        lastType = event.type;
    });
    mgr.setBatteryLevelForTesting(50);
    ASSERT_EQ(calls, 1);
    ASSERT_EQ(lastType, PowerEventType::BATTERY_CHANGED);
    mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL);
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(lastType, PowerEventType::WAKE_LOCK_ACQUIRED);
}

// ============================================================
// Failure simulation tests
// ============================================================

static void test_failure_simulation() {
    PowerManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.getFailNextOperation());
    mgr.setFailNextOperation(true);
    ASSERT_TRUE(mgr.getFailNextOperation());
    // Suspend fails
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::SIMULATED_FAILURE);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::AWAKE);
    // One-shot: next attempt succeeds
    ASSERT_FALSE(mgr.getFailNextOperation());
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::SUCCESS);
    mgr.resume(WakeReason::TOUCH);
    // Also applies to hibernate/shutdown/reboot
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.requestHibernate("system"), PowerResult::SIMULATED_FAILURE);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.requestShutdown("system"), PowerResult::SIMULATED_FAILURE);
    ASSERT_TRUE(mgr.isPoweredOn());
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.requestReboot("system"), PowerResult::SIMULATED_FAILURE);
    ASSERT_EQ(mgr.getStats().totalFailures, (uint64_t)4);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(PowerResult::SIMULATED_FAILURE)],
              (uint64_t)4);
}

// ============================================================
// Integration tests
// ============================================================

static void test_log_server_integration() {
    PowerManager mgr;
    LogServer logs;
    logs.initialize(100);
    mgr.initialize();
    mgr.setLogServer(&logs);
    ASSERT_EQ(mgr.getLogServer(), &logs);
    mgr.setBatteryLevelForTesting(10);  // Low warning logs
    mgr.setPowerMode(PowerMode::BATTERY_SAVER, "com.app");
    mgr.acquireWakeLock("com.app", "tag", WakeLockType::PARTIAL);
    // Release the lock so suspend is not blocked
    mgr.releaseWakeLock(mgr.getActiveWakeLocks()[0].id, "com.app");
    mgr.requestSuspend("system", WakeReason::TIMER);
    mgr.resume(WakeReason::TOUCH);
    ASSERT_TRUE(logs.getLogCount() >= 4);
    logs.shutdown();
}

static void test_crash_reporter_integration() {
    PowerManager mgr;
    CrashReporter reporter;
    reporter.initialize(100);
    mgr.initialize();
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    // Thermal critical notifies the crash reporter
    mgr.setThermalStateForTesting(ThermalState::CRITICAL);
    ASSERT_TRUE(reporter.getRecent(10).size() >= 1);
    // Failed critical operation notifies too
    mgr.setThermalStateForTesting(ThermalState::NORMAL);
    mgr.setFailNextOperation(true);
    mgr.requestShutdown("system");
    ASSERT_TRUE(reporter.getRecent(10).size() >= 2);
    reporter.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

static void test_string_helpers_battery_and_source() {
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::UNKNOWN), "UNKNOWN");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::DISCHARGING), "DISCHARGING");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::CHARGING), "CHARGING");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::FULL), "FULL");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::LOW), "LOW");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::CRITICAL), "CRITICAL");
    ASSERT_STREQ(PowerManager::batteryStateToString(BatteryState::NOT_PRESENT), "NOT_PRESENT");
    ASSERT_STREQ(PowerManager::powerSourceToString(PowerSource::BATTERY), "BATTERY");
    ASSERT_STREQ(PowerManager::powerSourceToString(PowerSource::USB), "USB");
    ASSERT_STREQ(PowerManager::powerSourceToString(PowerSource::AC_ADAPTER), "AC_ADAPTER");
    ASSERT_STREQ(PowerManager::powerSourceToString(PowerSource::WIRELESS_STUB), "WIRELESS_STUB");
    ASSERT_STREQ(PowerManager::powerSourceToString(PowerSource::UNKNOWN), "UNKNOWN");
    // Parser
    ASSERT_EQ(PowerManager::stringToBatteryState("CHARGING"), BatteryState::CHARGING);
    ASSERT_EQ(PowerManager::stringToBatteryState("NOT_PRESENT"), BatteryState::NOT_PRESENT);
    ASSERT_EQ(PowerManager::stringToBatteryState("bogus"), BatteryState::UNKNOWN);
}

static void test_string_helpers_mode_and_state() {
    ASSERT_STREQ(PowerManager::powerModeToString(PowerMode::PERFORMANCE), "PERFORMANCE");
    ASSERT_STREQ(PowerManager::powerModeToString(PowerMode::BALANCED), "BALANCED");
    ASSERT_STREQ(PowerManager::powerModeToString(PowerMode::BATTERY_SAVER), "BATTERY_SAVER");
    ASSERT_STREQ(PowerManager::powerModeToString(PowerMode::EXTREME_SAVER), "EXTREME_SAVER");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::AWAKE), "AWAKE");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::IDLE), "IDLE");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::SUSPENDING), "SUSPENDING");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::SUSPENDED), "SUSPENDED");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::HIBERNATING), "HIBERNATING");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::SHUTTING_DOWN), "SHUTTING_DOWN");
    ASSERT_STREQ(PowerManager::systemPowerStateToString(SystemPowerState::REBOOTING), "REBOOTING");
    // Parser
    ASSERT_EQ(PowerManager::stringToPowerMode("EXTREME_SAVER"), PowerMode::EXTREME_SAVER);
    ASSERT_EQ(PowerManager::stringToPowerMode("bogus"), PowerMode::BALANCED);
}

static void test_string_helpers_thermal_and_locks() {
    ASSERT_STREQ(PowerManager::thermalStateToString(ThermalState::NORMAL), "NORMAL");
    ASSERT_STREQ(PowerManager::thermalStateToString(ThermalState::WARM), "WARM");
    ASSERT_STREQ(PowerManager::thermalStateToString(ThermalState::HOT), "HOT");
    ASSERT_STREQ(PowerManager::thermalStateToString(ThermalState::CRITICAL), "CRITICAL");
    ASSERT_STREQ(PowerManager::thermalStateToString(ThermalState::SHUTDOWN), "SHUTDOWN");
    ASSERT_STREQ(PowerManager::wakeLockTypeToString(WakeLockType::PARTIAL), "PARTIAL");
    ASSERT_STREQ(PowerManager::wakeLockTypeToString(WakeLockType::DISPLAY), "DISPLAY");
    ASSERT_STREQ(PowerManager::wakeLockTypeToString(WakeLockType::NETWORK), "NETWORK");
    ASSERT_STREQ(PowerManager::wakeLockTypeToString(WakeLockType::CPU), "CPU");
    ASSERT_STREQ(PowerManager::wakeLockTypeToString(WakeLockType::FULL), "FULL");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::POWER_BUTTON), "POWER_BUTTON");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::TOUCH), "TOUCH");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::TIMER), "TIMER");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::NETWORK), "NETWORK");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::CHARGER), "CHARGER");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::ALARM), "ALARM");
    ASSERT_STREQ(PowerManager::wakeReasonToString(WakeReason::SYSTEM), "SYSTEM");
    ASSERT_STREQ(PowerManager::chargingTypeToString(ChargingType::NONE), "NONE");
    ASSERT_STREQ(PowerManager::chargingTypeToString(ChargingType::TRICKLE), "TRICKLE");
    ASSERT_STREQ(PowerManager::chargingTypeToString(ChargingType::STANDARD), "STANDARD");
    ASSERT_STREQ(PowerManager::chargingTypeToString(ChargingType::FAST_STUB), "FAST_STUB");
    ASSERT_STREQ(PowerManager::chargingTypeToString(ChargingType::WIRELESS_STUB), "WIRELESS_STUB");
}

static void test_string_helpers_result_and_event() {
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::ALREADY_INITIALIZED), "ALREADY_INITIALIZED");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::INVALID_PARAMETER), "INVALID_PARAMETER");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::WAKE_LOCK_NOT_FOUND), "WAKE_LOCK_NOT_FOUND");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::WAKE_LOCK_EXISTS), "WAKE_LOCK_EXISTS");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::CAPACITY_EXCEEDED), "CAPACITY_EXCEEDED");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::BAD_STATE), "BAD_STATE");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::OPERATION_FAILED), "OPERATION_FAILED");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::BATTERY_TOO_LOW), "BATTERY_TOO_LOW");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::THERMAL_CRITICAL), "THERMAL_CRITICAL");
    ASSERT_STREQ(PowerManager::powerResultToString(PowerResult::SIMULATED_FAILURE), "SIMULATED_FAILURE");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::BATTERY_CHANGED), "BATTERY_CHANGED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::SOURCE_CHANGED), "SOURCE_CHANGED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::MODE_CHANGED), "MODE_CHANGED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::WAKE_LOCK_ACQUIRED), "WAKE_LOCK_ACQUIRED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::WAKE_LOCK_RELEASED), "WAKE_LOCK_RELEASED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::WAKE_LOCK_EXPIRED), "WAKE_LOCK_EXPIRED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::THERMAL_CHANGED), "THERMAL_CHANGED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::SUSPEND), "SUSPEND");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::RESUME), "RESUME");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::SHUTDOWN_REQUESTED), "SHUTDOWN_REQUESTED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::REBOOT_REQUESTED), "REBOOT_REQUESTED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::HIBERNATE_REQUESTED), "HIBERNATE_REQUESTED");
    ASSERT_STREQ(PowerManager::powerEventTypeToString(PowerEventType::LOW_POWER_WARNING), "LOW_POWER_WARNING");
    // Parser
    ASSERT_EQ(PowerManager::stringToPowerResult("BATTERY_TOO_LOW"), PowerResult::BATTERY_TOO_LOW);
    ASSERT_EQ(PowerManager::stringToPowerResult("WAKE_LOCK_EXISTS"), PowerResult::WAKE_LOCK_EXISTS);
    ASSERT_EQ(PowerManager::stringToPowerResult("bogus"), PowerResult::SUCCESS);
}

// ============================================================
// Full workflow test
// ============================================================

static void test_full_workflow() {
    PowerManager mgr;
    LogServer logs;
    logs.initialize(200);
    mgr.initialize(16, 100, 100);
    mgr.setLogServer(&logs);

    // 1. Battery drains into low territory: auto saver engages
    ASSERT_EQ(mgr.simulateDrain(65), PowerResult::SUCCESS);  // 75 -> 10
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::LOW);
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BATTERY_SAVER);

    // 2. App holds a wake lock: suspend is blocked
    mgr.setCurrentTimeForTesting(1700000000000ULL);  // Deterministic simulated clock
    uint64_t lock = mgr.acquireWakeLock("com.music", "playback", WakeLockType::PARTIAL, 60000);
    ASSERT_TRUE(lock != 0);
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::BAD_STATE);

    // 3. Wake lock expires after its timeout
    mgr.setCurrentTimeForTesting(1700000061000ULL);  // +61 s
    ASSERT_EQ(mgr.processExpiredWakeLocks(), PowerResult::SUCCESS);
    ASSERT_FALSE(mgr.hasWakeLocks());
    mgr.clearTimeOverride();

    // 4. Suspend now succeeds, then the device wakes up
    ASSERT_EQ(mgr.requestSuspend("system", WakeReason::TIMER), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getSystemPowerState(), SystemPowerState::SUSPENDED);
    ASSERT_EQ(mgr.resume(WakeReason::POWER_BUTTON), PowerResult::SUCCESS);

    // 5. Charger connected: balanced mode returns after hysteresis
    ASSERT_EQ(mgr.setChargingForTesting(true, ChargingType::FAST_STUB), PowerResult::SUCCESS);
    ASSERT_EQ(mgr.getBatteryStatus().state, BatteryState::CHARGING);
    ASSERT_EQ(mgr.simulateCharge(15), PowerResult::SUCCESS);  // 10 -> 25
    ASSERT_EQ(mgr.getPowerMode(), PowerMode::BALANCED);

    // 6. Thermal warning throttles the CPU
    ASSERT_EQ(mgr.setThermalStateForTesting(ThermalState::HOT), PowerResult::SUCCESS);
    ASSERT_TRUE(mgr.isThermalThrottled());
    ASSERT_EQ(mgr.getThermalThrottlePercent(), (uint32_t)40);

    // 7. Thermal protection forces power-off despite wake locks
    uint64_t lock2 = mgr.acquireWakeLock("com.app", "work", WakeLockType::FULL);
    ASSERT_TRUE(lock2 != 0);
    mgr.setThermalStateForTesting(ThermalState::SHUTDOWN);
    ASSERT_FALSE(mgr.isPoweredOn());

    // 8. Final stats
    PowerManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.suspends, (uint64_t)1);
    ASSERT_EQ(stats.resumes, (uint64_t)1);
    ASSERT_EQ(stats.shutdownRequests, (uint64_t)1);
    ASSERT_EQ(stats.wakeLocksExpired, (uint64_t)1);
    ASSERT_EQ(stats.wakeLocksAcquired, (uint64_t)2);
    ASSERT_TRUE(stats.lowWarnings >= 1);
    ASSERT_TRUE(stats.modeChanges >= 2);

    mgr.shutdown();
    logs.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Phantom OS Power Manager Tests (v0.26.0) ===" << std::endl;

    RUN_TEST(test_lifecycle);
    RUN_TEST(test_initialize_invalid_params);
    RUN_TEST(test_not_initialized_operations);
    RUN_TEST(test_shutdown_clears_state);
    RUN_TEST(test_battery_defaults);
    RUN_TEST(test_battery_level_changes);
    RUN_TEST(test_battery_low_and_critical);
    RUN_TEST(test_battery_full_and_not_present);
    RUN_TEST(test_battery_drain_and_charge);
    RUN_TEST(test_power_source_transitions);
    RUN_TEST(test_charging_type_transitions);
    RUN_TEST(test_remaining_minutes_estimate);
    RUN_TEST(test_thresholds);
    RUN_TEST(test_auto_battery_saver);
    RUN_TEST(test_auto_saver_hysteresis);
    RUN_TEST(test_extreme_saver_at_critical);
    RUN_TEST(test_manual_mode_override);
    RUN_TEST(test_auto_saver_disable);
    RUN_TEST(test_wake_lock_acquire_release);
    RUN_TEST(test_wake_lock_duplicate_and_types);
    RUN_TEST(test_wake_lock_capacity);
    RUN_TEST(test_wake_lock_owner_checks);
    RUN_TEST(test_wake_lock_release_by_owner);
    RUN_TEST(test_wake_lock_expiry);
    RUN_TEST(test_suspend_resume);
    RUN_TEST(test_suspend_blocked_by_wake_lock);
    RUN_TEST(test_hibernate);
    RUN_TEST(test_hibernate_battery_too_low);
    RUN_TEST(test_shutdown);
    RUN_TEST(test_reboot);
    RUN_TEST(test_thermal_states_and_throttle);
    RUN_TEST(test_thermal_blocks_suspend);
    RUN_TEST(test_thermal_shutdown_forces_power_off);
    RUN_TEST(test_policy_queries);
    RUN_TEST(test_events);
    RUN_TEST(test_event_capacity);
    RUN_TEST(test_event_fields);
    RUN_TEST(test_stats);
    RUN_TEST(test_battery_callback);
    RUN_TEST(test_power_mode_callback);
    RUN_TEST(test_power_event_callback);
    RUN_TEST(test_failure_simulation);
    RUN_TEST(test_log_server_integration);
    RUN_TEST(test_crash_reporter_integration);
    RUN_TEST(test_string_helpers_battery_and_source);
    RUN_TEST(test_string_helpers_mode_and_state);
    RUN_TEST(test_string_helpers_thermal_and_locks);
    RUN_TEST(test_string_helpers_result_and_event);
    RUN_TEST(test_full_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run
              << " passed ===" << std::endl;
    return g_tests_failed == 0 ? 0 : 1;
}
