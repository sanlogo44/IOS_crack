/*
 * Phantom OS - Theme System Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/theme.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/widgets/extended_widgets.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <cstdio>
#include <cmath>

using namespace phantom::gui;

// ============================================================
// Test framework
// ============================================================

static int test_count = 0;
static int pass_count = 0;

static void ASSERT(bool cond, const char* msg) {
    test_count++;
    if (cond) {
        pass_count++;
    } else {
        printf("  FAIL: %s\n", msg);
    }
}

// ============================================================
// Theme Colors Tests
// ============================================================

bool test_light_theme_colors() {
    Theme t = Theme::createLight();

    ASSERT(t.getType() == ThemeType::LIGHT, "Light theme type");
    ASSERT(t.getName() == "Light", "Light theme name");

    const auto& c = t.getColors();
    // Light theme should have light background
    ASSERT(c.background.r > 200, "Light bg r > 200");
    ASSERT(c.background.g > 200, "Light bg g > 200");
    ASSERT(c.background.b > 200, "Light bg b > 200");
    // Text should be dark on light theme
    ASSERT(c.textPrimary.r < 100, "Light text r < 100");
    ASSERT(c.textPrimary.g < 100, "Light text g < 100");
    ASSERT(c.textPrimary.b < 100, "Light text b < 100");

    return true;
}

bool test_dark_theme_colors() {
    Theme t = Theme::createDark();

    ASSERT(t.getType() == ThemeType::DARK, "Dark theme type");
    ASSERT(t.getName() == "Dark", "Dark theme name");

    const auto& c = t.getColors();
    // Dark theme should have dark background
    ASSERT(c.background.r < 50, "Dark bg r < 50");
    ASSERT(c.background.g < 50, "Dark bg g < 50");
    ASSERT(c.background.b < 50, "Dark bg b < 50");
    // Text should be light on dark theme
    ASSERT(c.textPrimary.r > 200, "Dark text r > 200");
    ASSERT(c.textPrimary.g > 200, "Dark text g > 200");
    ASSERT(c.textPrimary.b > 200, "Dark text b > 200");

    return true;
}

bool test_custom_theme() {
    ThemeColors colors;
    colors.background = Color(100, 50, 200);
    colors.surface = Color(60, 60, 60);
    colors.textPrimary = Color(255, 255, 0);

    Theme custom(ThemeType::CUSTOM, "MyTheme", colors);

    ASSERT(custom.getType() == ThemeType::CUSTOM, "Custom type");
    ASSERT(custom.getName() == "MyTheme", "Custom name");
    ASSERT(custom.getColors().background.r == 100, "Custom bg r");
    ASSERT(custom.getColors().background.g == 50, "Custom bg g");
    ASSERT(custom.getColors().background.b == 200, "Custom bg b");

    return true;
}

bool test_color_role_lookup() {
    Theme t = Theme::createDark();
    const auto& c = t.getColors();

    // Valid role
    const Color& bg = t.getColor("background");
    ASSERT(bg.r == c.background.r, "Role lookup background r");
    ASSERT(bg.g == c.background.g, "Role lookup background g");
    ASSERT(bg.b == c.background.b, "Role lookup background b");

    const Color& primary = t.getColor("primary");
    ASSERT(primary.r == c.primary.r, "Role lookup primary r");

    const Color& border = t.getColor("border");
    ASSERT(border.r == c.border.r, "Role lookup border r");

    // Invalid role returns fallback (black)
    const Color& invalid = t.getColor("nonexistent");
    ASSERT(invalid.r == 0 && invalid.g == 0 && invalid.b == 0, "Invalid role returns black");

    return true;
}

// ============================================================
// ThemeManager Tests
// ============================================================

bool test_theme_manager_default() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    ASSERT(tm.getCurrentType() == ThemeType::DARK, "Default theme is dark");
    ASSERT(tm.getCurrentTheme().getName() == "Dark", "Default theme name");

    return true;
}

bool test_theme_manager_set_light() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(tm.getCurrentType() == ThemeType::LIGHT, "Set to light");

    return true;
}

bool test_theme_manager_set_dark() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    tm.setThemeType(ThemeType::LIGHT);
    tm.setThemeType(ThemeType::DARK);
    ASSERT(tm.getCurrentType() == ThemeType::DARK, "Set back to dark");

    return true;
}

bool test_theme_manager_toggle() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    // Dark -> Light
    tm.toggleTheme();
    ASSERT(tm.getCurrentType() == ThemeType::LIGHT, "Toggle dark to light");

    // Light -> Dark
    tm.toggleTheme();
    ASSERT(tm.getCurrentType() == ThemeType::DARK, "Toggle light to dark");

    return true;
}

bool test_theme_manager_set_custom() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    ThemeColors colors;
    colors.background = Color::Red;
    colors.textPrimary = Color::White;
    Theme custom(ThemeType::CUSTOM, "CustomTheme", colors);

    tm.setTheme(custom);
    ASSERT(tm.getCurrentType() == ThemeType::CUSTOM, "Set custom type");
    ASSERT(tm.getCurrentTheme().getName() == "CustomTheme", "Custom theme name");
    ASSERT(tm.getCurrentTheme().getColors().background.r == 255, "Custom bg r");

    return true;
}

bool test_theme_manager_listener_add() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    int callCount = 0;
    auto id = tm.addListener([&callCount](const Theme&) {
        callCount++;
    });

    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(callCount == 1, "Listener called once on theme change");

    tm.removeListener(id);

    return true;
}

bool test_theme_manager_listener_remove() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    int callCount = 0;
    auto id = tm.addListener([&callCount](const Theme&) {
        callCount++;
    });

    tm.removeListener(id);
    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(callCount == 0, "Removed listener not called");

    return true;
}

bool test_theme_manager_multiple_listeners() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    int count1 = 0, count2 = 0;
    auto id1 = tm.addListener([&count1](const Theme&) { count1++; });
    auto id2 = tm.addListener([&count2](const Theme&) { count2++; });

    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(count1 == 1, "Listener 1 called");
    ASSERT(count2 == 1, "Listener 2 called");

    tm.removeListener(id1);
    tm.setThemeType(ThemeType::DARK);
    ASSERT(count1 == 1, "Listener 1 not called after removal");
    ASSERT(count2 == 2, "Listener 2 still called");

    tm.removeListener(id2);

    return true;
}

bool test_theme_manager_clear_listeners() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    int count = 0;
    tm.addListener([&count](const Theme&) { count++; });
    tm.addListener([&count](const Theme&) { count++; });
    tm.addListener([&count](const Theme&) { count++; });

    tm.clearListeners();
    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(count == 0, "No listeners after clear");

    return true;
}

bool test_theme_manager_custom_same_name_different_colors() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    ThemeColors c1;
    c1.background = Color(50, 50, 50);
    c1.surface = Color(60, 60, 60);
    c1.primary = Color(100, 100, 100);
    c1.textPrimary = Color::White;
    c1.buttonBg = Color(80, 80, 80);
    Theme custom1(ThemeType::CUSTOM, "MyTheme", c1);
    tm.setTheme(custom1);

    int callCount = 0;
    tm.addListener([&callCount](const Theme&) { callCount++; });

    // Same name, different colors
    ThemeColors c2;
    c2.background = Color(200, 200, 200);
    c2.surface = Color(60, 60, 60);
    c2.primary = Color(100, 100, 100);
    c2.textPrimary = Color::White;
    c2.buttonBg = Color(80, 80, 80);
    Theme custom2(ThemeType::CUSTOM, "MyTheme", c2);
    tm.setTheme(custom2);

    ASSERT(callCount == 1, "Listener fires when same-name custom theme has different colors");
    ASSERT(tm.getCurrentTheme().getColors().background.r == 200, "Custom theme bg updated");

    return true;
}

bool test_theme_manager_same_theme_no_callback() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    int callCount = 0;
    tm.addListener([&callCount](const Theme&) { callCount++; });

    // Set to dark (same as default) - should NOT fire
    tm.setThemeType(ThemeType::DARK);
    ASSERT(callCount == 0, "No callback when setting same theme");

    // Set to light - should fire
    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(callCount == 1, "Callback fires on actual change");

    return true;
}

// ============================================================
// Widget applyTheme Tests
// ============================================================

bool test_label_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    Label label(1, "Hello");
    label.setTextColor(Color::Red);

    label.applyTheme(dark);
    const auto& dc = dark.getColors();
    ASSERT(label.getTextColor().r == dc.textPrimary.r, "Label text color from dark theme");
    ASSERT(label.getTextColor().g == dc.textPrimary.g, "Label text color g from dark theme");

    Theme light = Theme::createLight();
    label.applyTheme(light);
    const auto& lc = light.getColors();
    ASSERT(label.getTextColor().r == lc.textPrimary.r, "Label text color from light theme");

    return true;
}

bool test_button_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    Button btn(1, "OK");
    btn.setBackgroundColor(Color::Red);
    btn.setTextColor(Color::Green);

    btn.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(btn.getBackgroundColor().r == c.buttonBg.r, "Button bg from theme");
    ASSERT(btn.getTextColor().r == c.buttonText.r, "Button text from theme");

    return true;
}

bool test_textfield_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    TextField tf(1);
    tf.setBackgroundColor(Color::Red);
    tf.setTextColor(Color::Green);

    tf.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(tf.getBackgroundColor().r == c.inputBg.r, "TextField bg from theme");
    ASSERT(tf.getTextColor().r == c.textPrimary.r, "TextField text from theme");

    return true;
}

bool test_listview_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    ListView lv(1, 3);

    lv.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(lv.getBgColor().r == c.listBg.r, "ListView bg from theme");
    ASSERT(lv.getSelectedBgColor().r == c.listSelectedBg.r, "ListView selected bg from theme");
    ASSERT(lv.getItemTextColor().r == c.listText.r, "ListView item text from theme");
    ASSERT(lv.getSelectedTextColor().r == c.listSelectedText.r, "ListView selected text from theme");

    return true;
}

bool test_checkbox_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    CheckBox cb(1, "Check");
    cb.setTextColor(Color::Red);
    cb.setBoxColor(Color::Green);
    cb.setCheckColor(Color::Blue);

    cb.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(cb.getTextColor().r == c.textPrimary.r, "CheckBox text from theme");
    ASSERT(cb.getBoxColor().r == c.checkBoxBox.r, "CheckBox box from theme");
    ASSERT(cb.getCheckColor().r == c.checkBoxCheck.r, "CheckBox check from theme");

    return true;
}

bool test_radiobutton_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    RadioButton rb(1, "Radio");
    rb.setTextColor(Color::Red);
    rb.setCircleColor(Color::Green);
    rb.setDotColor(Color::Blue);

    rb.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(rb.getTextColor().r == c.textPrimary.r, "RadioButton text from theme");
    ASSERT(rb.getCircleColor().r == c.radioCircle.r, "RadioButton circle from theme");
    ASSERT(rb.getDotColor().r == c.radioDot.r, "RadioButton dot from theme");

    return true;
}

bool test_progressbar_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    ProgressBar pb(1);
    pb.setBackgroundColor(Color::Red);
    pb.setFillColor(Color::Green);
    pb.setBorderColor(Color::Blue);

    pb.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(pb.getBackgroundColor().r == c.progressBarBg.r, "ProgressBar bg from theme");
    ASSERT(pb.getFillColor().r == c.progressBarFill.r, "ProgressBar fill from theme");
    ASSERT(pb.getBorderColor().r == c.border.r, "ProgressBar border from theme");

    return true;
}

bool test_slider_apply_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    Slider s(1);
    s.setTrackColor(Color::Red);
    s.setThumbColor(Color::Green);
    s.setFillColor(Color::Blue);

    s.applyTheme(dark);
    const auto& c = dark.getColors();
    ASSERT(s.getTrackColor().r == c.sliderTrack.r, "Slider track from theme");
    ASSERT(s.getThumbColor().r == c.sliderThumb.r, "Slider thumb from theme");
    ASSERT(s.getFillColor().r == c.sliderFill.r, "Slider fill from theme");

    return true;
}

bool test_apply_theme_recursive() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    // Create a parent container with children
    auto container = std::make_unique<Widget>(10, "Container");
    auto label = std::make_unique<Label>(1, "Child Label");
    auto btn = std::make_unique<Button>(2, "Child Button");

    Label* labelPtr = label.get();
    Button* btnPtr = btn.get();

    container->addChild(std::move(label));
    container->addChild(std::move(btn));

    // Apply theme to parent - should recurse to children
    container->applyTheme(dark);

    const auto& c = dark.getColors();
    ASSERT(labelPtr->getTextColor().r == c.textPrimary.r, "Recursive: label text colored");
    ASSERT(btnPtr->getBackgroundColor().r == c.buttonBg.r, "Recursive: button bg colored");

    return true;
}

bool test_apply_theme_via_manager() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.reset();

    Label label(1, "Test");
    label.setTextColor(Color::Red);

    // Apply via manager
    tm.applyTheme(label);

    const auto& c = tm.getCurrentTheme().getColors();
    ASSERT(label.getTextColor().r == c.textPrimary.r, "Manager applyTheme works");

    // Switch to light and apply
    tm.setThemeType(ThemeType::LIGHT);
    tm.applyTheme(label);

    const auto& lc = tm.getCurrentTheme().getColors();
    ASSERT(label.getTextColor().r == lc.textPrimary.r, "Manager applyTheme after switch");

    return true;
}

bool test_apply_theme_different_themes() {
    ThemeManager::getInstance().reset();
    Theme light = Theme::createLight();
    Theme dark = Theme::createDark();

    Button btn(1, "OK");
    btn.applyTheme(light);
    const auto& lc = light.getColors();
    ASSERT(btn.getBackgroundColor().r == lc.buttonBg.r, "Button bg from light theme");
    ASSERT(btn.getBackgroundColor().g == lc.buttonBg.g, "Button bg g from light theme");

    btn.applyTheme(dark);
    const auto& dc = dark.getColors();
    ASSERT(btn.getBackgroundColor().r == dc.buttonBg.r, "Button bg from dark theme");
    ASSERT(btn.getBackgroundColor().g == dc.buttonBg.g, "Button bg g from dark theme");

    // Light and dark should have different button bg
    ASSERT(lc.buttonBg.r != dc.buttonBg.r || lc.buttonBg.g != dc.buttonBg.g,
           "Light and dark have different button bg");

    return true;
}

bool test_listview_render_with_theme() {
    ThemeManager::getInstance().reset();
    Theme dark = Theme::createDark();

    ListView lv(1, 2);
    lv.setSelectedIndex(0);
    lv.setItemTextCallback([](size_t i) {
        return i == 0 ? "First" : "Second";
    });

    lv.applyTheme(dark);
    const auto& c = dark.getColors();

    // Render and verify theme colors are used
    Framebuffer fb(50, 30);
    BitmapFont font;
    Rect bounds(0, 0, 50, 30);
    lv.setBounds(bounds);
    lv.onRender(fb, font);

    // Item 0 is selected, so pixel (0,0) should be selectedBgColor
    Color pixel = fb.getPixel(0, 0);
    ASSERT(pixel.r == c.listSelectedBg.r, "Rendered selected bg matches theme r");
    ASSERT(pixel.g == c.listSelectedBg.g, "Rendered selected bg matches theme g");
    ASSERT(pixel.b == c.listSelectedBg.b, "Rendered selected bg matches theme b");

    return true;
}

bool test_theme_manager_reset() {
    ThemeManager& tm = ThemeManager::getInstance();
    tm.setThemeType(ThemeType::LIGHT);

    int callCount = 0;
    tm.addListener([&callCount](const Theme&) { callCount++; });

    tm.reset();
    ASSERT(tm.getCurrentType() == ThemeType::DARK, "Reset to dark");
    ASSERT(callCount == 0, "Listeners cleared on reset");

    // After reset, setting theme should work normally
    tm.setThemeType(ThemeType::LIGHT);
    ASSERT(tm.getCurrentType() == ThemeType::LIGHT, "Works after reset");

    return true;
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("=== Theme System Tests ===\n\n");

    test_light_theme_colors();
    test_dark_theme_colors();
    test_custom_theme();
    test_color_role_lookup();
    test_theme_manager_default();
    test_theme_manager_set_light();
    test_theme_manager_set_dark();
    test_theme_manager_toggle();
    test_theme_manager_set_custom();
    test_theme_manager_custom_same_name_different_colors();
    test_theme_manager_listener_add();
    test_theme_manager_listener_remove();
    test_theme_manager_multiple_listeners();
    test_theme_manager_clear_listeners();
    test_theme_manager_same_theme_no_callback();
    test_label_apply_theme();
    test_button_apply_theme();
    test_textfield_apply_theme();
    test_listview_apply_theme();
    test_checkbox_apply_theme();
    test_radiobutton_apply_theme();
    test_progressbar_apply_theme();
    test_slider_apply_theme();
    test_apply_theme_recursive();
    test_apply_theme_via_manager();
    test_apply_theme_different_themes();
    test_listview_render_with_theme();
    test_theme_manager_reset();

    printf("\nResults: %d/%d passed (%d tests)\n", pass_count, test_count, test_count);

    return (pass_count == test_count) ? 0 : 1;
}
