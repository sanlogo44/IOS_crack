/*
 * Phantom OS - File Manager App Unit Tests
 * Tests for the File Manager with simulated filesystem
 *
 * License: GPL-3.0
 */

#include "phantom/filemanager/file_manager.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include <cstdio>
#include <cstring>

using namespace phantom::filemanager;
using namespace phantom::gui;

static int tests_passed = 0;
static int tests_failed = 0;

static void check(bool condition, const char* testName) {
    if (condition) {
        printf("  [PASS] %s\n", testName);
        tests_passed++;
    } else {
        printf("  [FAIL] %s\n", testName);
        tests_failed++;
    }
}

// ============================================================
// Test: Initialization
// ============================================================
static void testInitialization() {
    printf("\n=== Initialization Tests ===\n");

    FileManagerApp app;
    check(!app.isInitialized(), "Not initialized before init");
    check(app.getState() == FileManagerState::IDLE, "State is IDLE before init");

    app.initialize();
    check(app.isInitialized(), "Initialized after init");
    check(app.getState() == FileManagerState::INITIALIZED, "State is INITIALIZED after init");

    app.shutdown();
    check(!app.isInitialized(), "Not initialized after shutdown");
    check(app.getState() == FileManagerState::SHUTDOWN, "State is SHUTDOWN after shutdown");
}

// ============================================================
// Test: Widget Tree
// ============================================================
static void testWidgetTree() {
    printf("\n=== Widget Tree Tests ===\n");

    FileManagerApp app;
    app.initialize();

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists");
    check(root->getChildCount() == 4, "Root has 4 children (pathbar + toolbar + list + status)");

    // Path bar
    auto* pathBar = root->getChild(0);
    check(pathBar != nullptr, "Path bar exists");

    // Toolbar
    auto* toolbar = root->getChild(1);
    check(toolbar != nullptr, "Toolbar exists");
    check(toolbar->getChildCount() == 4, "Toolbar has 4 buttons");

    // File list
    auto* fileList = root->getChild(2);
    check(fileList != nullptr, "File list exists");

    // Status bar
    auto* statusBar = root->getChild(3);
    check(statusBar != nullptr, "Status bar exists");

    app.shutdown();
}

// ============================================================
// Test: Navigation
// ============================================================
static void testNavigation() {
    printf("\n=== Navigation Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Start at root
    check(app.getCurrentPath() == "/", "Starts at root path");

    // Navigate into /home
    auto result = app.navigateInto("home");
    check(result == OperationResult::SUCCESS, "Navigate into /home succeeded");
    check(app.getCurrentPath() == "/home", "Current path is /home");

    // Navigate into /home/user
    result = app.navigateInto("user");
    check(result == OperationResult::SUCCESS, "Navigate into /user succeeded");
    check(app.getCurrentPath() == "/home/user", "Current path is /home/user");

    // Navigate up
    result = app.navigateUp();
    check(result == OperationResult::SUCCESS, "Navigate up succeeded");
    check(app.getCurrentPath() == "/home", "Current path is /home after up");

    // Navigate to absolute path
    result = app.navigateTo("/System/config");
    check(result == OperationResult::SUCCESS, "Navigate to /System/config succeeded");
    check(app.getCurrentPath() == "/System/config", "Current path is /System/config");

    // Navigate to non-existent path
    result = app.navigateTo("/nonexistent");
    check(result == OperationResult::NOT_FOUND, "Navigate to nonexistent returns NOT_FOUND");

    // Navigate into non-existent directory
    result = app.navigateInto("nonexistent");
    check(result == OperationResult::NOT_FOUND, "Navigate into nonexistent returns NOT_FOUND");

    // Navigate up from root
    app.navigateTo("/");
    result = app.navigateUp();
    check(result == OperationResult::INVALID_PATH, "Navigate up from root returns INVALID_PATH");

    app.shutdown();
}

// ============================================================
// Test: Directory Listing
// ============================================================
static void testDirectoryListing() {
    printf("\n=== Directory Listing Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Root should have entries
    auto entries = app.listCurrentDirectory();
    check(entries.size() > 0, "Root has entries");
    check(app.getDirectoryCount() > 0, "Root has directories");
    check(app.getFileCount() > 0, "Root has files");

    // Check specific entries exist
    check(app.entryExists("home"), "Root has 'home' directory");
    check(app.entryExists("System"), "Root has 'System' directory");
    check(app.entryExists("README.txt"), "Root has 'README.txt' file");
    check(app.entryExists("LICENSE"), "Root has 'LICENSE' file");
    check(!app.entryExists("nonexistent"), "Root does not have 'nonexistent'");

    // Navigate to /home/user/Documents
    app.navigateTo("/home/user/Documents");
    entries = app.listCurrentDirectory();
    check(entries.size() == 3, "Documents has 3 entries");
    check(app.entryExists("manual.txt"), "Documents has 'manual.txt'");
    check(app.entryExists("changelog.md"), "Documents has 'changelog.md'");
    check(app.entryExists("config.conf"), "Documents has 'config.conf'");

    app.shutdown();
}

// ============================================================
// Test: File Operations
// ============================================================
static void testFileOperations() {
    printf("\n=== File Operations Tests ===\n");

    FileManagerApp app;
    app.initialize();
    app.navigateTo("/home/user");

    // Create folder
    auto result = app.createFolder("TestDir");
    check(result == OperationResult::SUCCESS, "Create folder succeeded");
    check(app.entryExists("TestDir"), "TestDir exists after creation");
    check(app.getDirectoryCount() > 0, "Directory count increased");

    // Create duplicate folder
    result = app.createFolder("TestDir");
    check(result == OperationResult::ALREADY_EXISTS, "Duplicate folder returns ALREADY_EXISTS");

    // Create folder with empty name
    result = app.createFolder("");
    check(result == OperationResult::INVALID_NAME, "Empty name returns INVALID_NAME");

    // Delete folder
    result = app.deleteEntry("TestDir");
    check(result == OperationResult::SUCCESS, "Delete folder succeeded");
    check(!app.entryExists("TestDir"), "TestDir removed after deletion");

    // Delete non-existent
    result = app.deleteEntry("nonexistent");
    check(result == OperationResult::NOT_FOUND, "Delete nonexistent returns NOT_FOUND");

    // Rename entry
    app.navigateTo("/home/user");
    result = app.renameEntry("notes.txt", "renamed.txt");
    check(result == OperationResult::SUCCESS, "Rename succeeded");
    check(app.entryExists("renamed.txt"), "Renamed file exists");
    check(!app.entryExists("notes.txt"), "Old name removed");

    // Rename to existing name
    result = app.renameEntry("renamed.txt", "profile.cfg");
    check(result == OperationResult::ALREADY_EXISTS, "Rename to existing returns ALREADY_EXISTS");

    // Rename non-existent
    result = app.renameEntry("nonexistent", "newname");
    check(result == OperationResult::NOT_FOUND, "Rename nonexistent returns NOT_FOUND");

    app.shutdown();
}

// ============================================================
// Test: Delete Non-Empty Directory
// ============================================================
static void testDeleteNonEmptyDir() {
    printf("\n=== Delete Non-Empty Directory Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Try to delete /home which has children
    app.navigateTo("/");
    auto result = app.deleteEntry("home");
    check(result == OperationResult::NOT_EMPTY, "Delete non-empty dir returns NOT_EMPTY");

    // Delete empty directory
    app.navigateTo("/home/user");
    app.createFolder("EmptyDir");
    result = app.deleteEntry("EmptyDir");
    check(result == OperationResult::SUCCESS, "Delete empty dir succeeded");

    app.shutdown();
}

// ============================================================
// Test: Selection
// ============================================================
static void testSelection() {
    printf("\n=== Selection Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Select first entry
    app.setSelectedIndex(0);
    check(app.getSelectedIndex() == 0, "Selected index is 0");

    auto entry = app.getSelectedEntry();
    check(!entry.name.empty(), "Selected entry has name");

    std::string path = app.getSelectedPath();
    check(!path.empty(), "Selected path is not empty");
    check(path.find("/") == 0, "Selected path starts with /");

    // Select invalid index
    app.setSelectedIndex(-1);
    check(app.getSelectedIndex() == -1, "Selected index is -1");

    entry = app.getSelectedEntry();
    check(entry.name.empty(), "No selected entry when index is -1");

    app.shutdown();
}

// ============================================================
// Test: File Type Detection
// ============================================================
static void testFileTypeDetection() {
    printf("\n=== File Type Detection Tests ===\n");

    check(FileManagerApp::detectFileType("test.txt") == FileType::TEXT, ".txt is TEXT");
    check(FileManagerApp::detectFileType("notes.md") == FileType::TEXT, ".md is TEXT");
    check(FileManagerApp::detectFileType("app.log") == FileType::TEXT, ".log is TEXT");
    check(FileManagerApp::detectFileType("config.cfg") == FileType::CONFIG, ".cfg is CONFIG");
    check(FileManagerApp::detectFileType("network.conf") == FileType::CONFIG, ".conf is CONFIG");
    check(FileManagerApp::detectFileType("image.png") == FileType::IMAGE, ".png is IMAGE");
    check(FileManagerApp::detectFileType("photo.jpg") == FileType::IMAGE, ".jpg is IMAGE");
    check(FileManagerApp::detectFileType("data.bin") == FileType::BINARY, ".bin is BINARY");
    check(FileManagerApp::detectFileType("libphantom.so") == FileType::BINARY, ".so is BINARY");
    check(FileManagerApp::detectFileType("script.sh") == FileType::EXECUTABLE, ".sh is EXECUTABLE");
    check(FileManagerApp::detectFileType("noextension") == FileType::UNKNOWN, "No extension is UNKNOWN");
}

// ============================================================
// Test: File Type Helpers
// ============================================================
static void testFileTypeHelpers() {
    printf("\n=== File Type Helpers Tests ===\n");

    check(std::string(FileManagerApp::fileTypeToString(FileType::DIRECTORY)) == "DIR", "DIR type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::EXECUTABLE)) == "EXE", "EXE type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::CONFIG)) == "CFG", "CFG type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::TEXT)) == "TXT", "TXT type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::IMAGE)) == "IMG", "IMG type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::BINARY)) == "BIN", "BIN type string");
    check(std::string(FileManagerApp::fileTypeToString(FileType::UNKNOWN)) == "???", "??? type string");

    check(std::string(FileManagerApp::fileTypeToIcon(FileType::DIRECTORY)) == "[D]", "DIR icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::EXECUTABLE)) == "[X]", "EXE icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::CONFIG)) == "[C]", "CFG icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::TEXT)) == "[T]", "TXT icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::IMAGE)) == "[I]", "IMG icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::BINARY)) == "[B]", "BIN icon");
    check(std::string(FileManagerApp::fileTypeToIcon(FileType::UNKNOWN)) == "[?]", "UNKNOWN icon");
}

// ============================================================
// Test: Path Bar and Status Bar
// ============================================================
static void testPathAndStatus() {
    printf("\n=== Path/Status Bar Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Path bar
    std::string pathText = app.getPathBarText();
    check(pathText.find("/") != std::string::npos, "Path bar contains path");
    check(pathText.find("Path") != std::string::npos, "Path bar contains 'Path' label");

    // Status bar
    std::string statusText = app.getStatusBarText();
    check(statusText.find("dirs") != std::string::npos, "Status bar shows dir count");
    check(statusText.find("files") != std::string::npos, "Status bar shows file count");

    // Navigate and check path updates
    app.navigateInto("home");
    pathText = app.getPathBarText();
    check(pathText.find("/home") != std::string::npos, "Path bar updates after navigation");

    // Select an item and check status
    app.setSelectedIndex(0);
    statusText = app.getStatusBarText();
    check(statusText.find("Selected") != std::string::npos, "Status bar shows selection");

    app.shutdown();
}

// ============================================================
// Test: Breadcrumbs
// ============================================================
static void testBreadcrumbs() {
    printf("\n=== Breadcrumbs Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Root has 0 breadcrumbs
    check(app.getBreadcrumbCount() == 0, "Root has 0 breadcrumbs");

    // Navigate to /home/user/Documents
    app.navigateTo("/home/user/Documents");
    auto crumbs = app.getBreadcrumbs();
    check(crumbs.size() == 3, "3 breadcrumbs for /home/user/Documents");
    check(crumbs[0] == "home", "First breadcrumb is 'home'");
    check(crumbs[1] == "user", "Second breadcrumb is 'user'");
    check(crumbs[2] == "Documents", "Third breadcrumb is 'Documents'");

    app.shutdown();
}

// ============================================================
// Test: Navigation History
// ============================================================
static void testNavigationHistory() {
    printf("\n=== Navigation History Tests ===\n");

    FileManagerApp app;
    app.initialize();

    check(app.getHistoryCount() == 1, "History has 1 entry after init");

    app.navigateInto("home");
    check(app.getHistoryCount() == 2, "History has 2 entries after navigate");

    app.navigateInto("user");
    check(app.getHistoryCount() == 3, "History has 3 entries after navigate");

    // Navigate back
    auto result = app.navigateBack();
    check(result == OperationResult::SUCCESS, "Navigate back succeeded");
    check(app.getCurrentPath() == "/home", "Current path is /home after back");

    // Navigate back to root
    result = app.navigateBack();
    check(result == OperationResult::SUCCESS, "Navigate back to root succeeded");
    check(app.getCurrentPath() == "/", "Current path is / after back");

    // Can't go back further
    result = app.navigateBack();
    check(result == OperationResult::INVALID_PATH, "Can't go back from root");

    app.shutdown();
}

// ============================================================
// Test: Sandbox
// ============================================================
static void testSandbox() {
    printf("\n=== Sandbox Tests ===\n");

    FileManagerApp app;
    app.initialize("default");

    check(app.isPathAllowed("/home/user"), "Default: /home/user allowed");
    check(app.isPathAllowed("/tmp"), "Default: /tmp allowed");
    check(app.isPathAllowed("/"), "Default: / allowed");
    check(!app.isPathAllowed("/System"), "Default: /System not allowed");

    app.shutdown();

    // Restricted sandbox
    app.initialize("restricted");
    check(app.isPathAllowed("/home/user"), "Restricted: /home/user allowed");
    check(!app.isPathAllowed("/tmp"), "Restricted: /tmp not allowed");
    check(!app.isPathAllowed("/System"), "Restricted: /System not allowed");

    app.shutdown();

    // Full access
    app.initialize("full");
    check(app.isPathAllowed("/home/user"), "Full: /home/user allowed");
    check(app.isPathAllowed("/tmp"), "Full: /tmp allowed");
    check(app.isPathAllowed("/System"), "Full: /System allowed");

    app.shutdown();
}

// ============================================================
// Test: Copy Entry
// ============================================================
static void testCopyEntry() {
    printf("\n=== Copy Entry Tests ===\n");

    FileManagerApp app;
    app.initialize();

    // Navigate to /home/user which has notes.txt
    app.navigateTo("/home/user");

    // Copy notes.txt to /tmp
    auto result = app.copyEntry("notes.txt", "/tmp");
    check(result == OperationResult::SUCCESS, "Copy to /tmp succeeded");

    // Verify it exists at destination
    app.navigateTo("/tmp");
    check(app.entryExists("notes.txt"), "Copied file exists at destination");

    // Copy to same location (should fail - already exists)
    app.navigateTo("/home/user");
    result = app.copyEntry("notes.txt", "/tmp");
    check(result == OperationResult::ALREADY_EXISTS, "Copy to existing returns ALREADY_EXISTS");

    // Copy non-existent
    result = app.copyEntry("nonexistent", "/tmp");
    check(result == OperationResult::NOT_FOUND, "Copy non-existent returns NOT_FOUND");

    // Copy to invalid path
    result = app.copyEntry("notes.txt", "/nonexistent");
    check(result == OperationResult::INVALID_PATH, "Copy to invalid path returns INVALID_PATH");

    app.shutdown();
}

// ============================================================
// Test: Rendering
// ============================================================
static void testRendering() {
    printf("\n=== Rendering Tests ===\n");

    FileManagerApp app;
    app.initialize();
    app.layout(300, 200);

    Framebuffer fb(300, 200);
    app.render(fb);

    check(fb.getWidth() == 300, "Framebuffer width is 300");
    check(fb.getHeight() == 200, "Framebuffer height is 200");

    // Check some pixels are non-zero
    bool hasContent = false;
    for (int32_t y = 0; y < 200 && !hasContent; y += 10) {
        for (int32_t x = 0; x < 300 && !hasContent; x += 10) {
            if (fb.getPixel(x, y) != Color::Black) {
                hasContent = true;
            }
        }
    }
    check(hasContent, "Framebuffer has rendered content");

    app.shutdown();
}

// ============================================================
// Test: Layout
// ============================================================
static void testLayout() {
    printf("\n=== Layout Tests ===\n");

    FileManagerApp app;
    app.initialize();
    app.layout(300, 200);

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists after layout");
    check(root->getBounds().width == 300, "Root width is 300");
    check(root->getBounds().height == 200, "Root height is 200");

    // Path bar should have bounds
    auto* pathBar = root->getChild(0);
    check(pathBar->getBounds().width > 0, "Path bar has nonzero width");
    check(pathBar->getBounds().height > 0, "Path bar has nonzero height");

    // Toolbar should have bounds
    auto* toolbar = root->getChild(1);
    check(toolbar->getBounds().width > 0, "Toolbar has nonzero width");
    check(toolbar->getBounds().height > 0, "Toolbar has nonzero height");

    // File list should have bounds
    auto* fileList = root->getChild(2);
    check(fileList->getBounds().width > 0, "File list has nonzero width");
    check(fileList->getBounds().height > 0, "File list has nonzero height");

    // Status bar should have bounds
    auto* statusBar = root->getChild(3);
    check(statusBar->getBounds().width > 0, "Status bar has nonzero width");
    check(statusBar->getBounds().height > 0, "Status bar has nonzero height");

    // Toolbar buttons should be positioned
    auto* btn0 = toolbar->getChild(0);
    auto* btn1 = toolbar->getChild(1);
    check(btn0->getBounds().width > 0, "Back button has nonzero width");
    check(btn1->getBounds().width > 0, "Up button has nonzero width");
    check(btn0->getBounds().x != btn1->getBounds().x, "Buttons have different x positions");

    app.shutdown();
}

// ============================================================
// Test: Touch Handling
// ============================================================
static void testTouchHandling() {
    printf("\n=== Touch Handling Tests ===\n");

    FileManagerApp app;
    app.initialize();
    app.layout(300, 200);

    // Touch should not crash
    bool handled = app.handleTouchDown(10, 10);
    check(true, "Touch down does not crash");

    handled = app.handleTouchUp(10, 10);
    check(true, "Touch up does not crash");

    // Touch outside bounds
    handled = app.handleTouchDown(-10, -10);
    check(!handled, "Touch outside bounds not handled");

    app.shutdown();
}

// ============================================================
// Test: Re-initialization
// ============================================================
static void testReinit() {
    printf("\n=== Re-initialization Tests ===\n");

    FileManagerApp app;
    app.initialize();
    check(app.isInitialized(), "Initialized after first init");

    app.shutdown();
    check(!app.isInitialized(), "Not initialized after shutdown");

    app.initialize();
    check(app.isInitialized(), "Initialized after re-init");
    check(app.getRootWidget() != nullptr, "Root widget exists after re-init");
    check(app.getCurrentPath() == "/", "Current path is / after re-init");

    app.shutdown();
}

// ============================================================
// Test: Operation Callback
// ============================================================
static void testOperationCallback() {
    printf("\n=== Operation Callback Tests ===\n");

    FileManagerApp app;
    app.initialize();

    int callbackCount = 0;
    FileOperation lastOp = FileOperation::NONE;
    OperationResult lastResult = OperationResult::SUCCESS;
    std::string lastName;

    app.setOperationCallback([&](FileOperation op, OperationResult result, const std::string& name) {
        callbackCount++;
        lastOp = op;
        lastResult = result;
        lastName = name;
    });

    // Navigate into home
    int before = callbackCount;
    app.navigateInto("home");
    check(callbackCount > before, "Callback fired for navigation");
    check(lastOp == FileOperation::NAVIGATE_INTO, "Callback has NAVIGATE_INTO op");
    check(lastResult == OperationResult::SUCCESS, "Callback has SUCCESS result");

    // Create folder
    app.navigateTo("/home/user");
    before = callbackCount;
    app.createFolder("CallbackTest");
    check(callbackCount > before, "Callback fired for create folder");
    check(lastOp == FileOperation::CREATE_FOLDER, "Callback has CREATE_FOLDER op");

    // Delete
    before = callbackCount;
    app.deleteEntry("CallbackTest");
    check(callbackCount > before, "Callback fired for delete");
    check(lastOp == FileOperation::DELETE, "Callback has DELETE op");

    app.shutdown();
}

// ============================================================
// Test: Sorting
// ============================================================
static void testSorting() {
    printf("\n=== Sorting Tests ===\n");

    FileManagerApp app;
    app.initialize();

    auto entries = app.listCurrentDirectory();

    // Directories should come before files
    bool foundDir = false;
    bool foundFileAfterDir = false;
    for (const auto& e : entries) {
        if (e.isDirectory) {
            foundDir = true;
        } else if (foundDir) {
            foundFileAfterDir = true;
        }
    }
    check(foundDir, "Entries contain directories");
    check(foundFileAfterDir, "Files appear after directories");

    // Check alphabetical order within directories
    bool firstDir = true;
    std::string prevName;
    for (const auto& e : entries) {
        if (e.isDirectory) {
            if (!firstDir) {
                check(e.name >= prevName, "Directories are alphabetically sorted");
            }
            prevName = e.name;
            firstDir = false;
        }
    }

    app.shutdown();
}

// ============================================================
// Main
// ============================================================
int main() {
    printf("\n");
    printf("==============================================\n");
    printf("  Phantom OS v0.12.0 - File Manager Tests    \n");
    printf("==============================================\n");

    testInitialization();
    testWidgetTree();
    testNavigation();
    testDirectoryListing();
    testFileOperations();
    testDeleteNonEmptyDir();
    testSelection();
    testFileTypeDetection();
    testFileTypeHelpers();
    testPathAndStatus();
    testBreadcrumbs();
    testNavigationHistory();
    testSandbox();
    testCopyEntry();
    testRendering();
    testLayout();
    testTouchHandling();
    testReinit();
    testOperationCallback();
    testSorting();

    printf("\n==============================================\n");
    printf("  File Manager Tests: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("==============================================\n");

    return tests_failed > 0 ? 1 : 0;
}
