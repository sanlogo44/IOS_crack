/*
 * Phantom OS - Identity Manager Tests
 * Tests for app-specific identifiers and hardware ID protection
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/identity_manager.h"
#include <cassert>
#include <cstdio>

using namespace phantom::privacy;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

bool test_generate_identifier() {
    TEST("Generate app-specific identifier");
    auto& im = IdentityManager::getInstance();
    std::string id = im.getAppIdentifier("com.test.appX");
    ASSERT(!id.empty(), "Identifier should not be empty");
    ASSERT(id.length() == 33, "Identifier should be 33 chars (16-16 hex)");
    PASS();
    return true;
}

bool test_stable_identifier() {
    TEST("Identifier is stable across calls");
    auto& im = IdentityManager::getInstance();
    std::string id1 = im.getAppIdentifier("com.test.appY");
    std::string id2 = im.getAppIdentifier("com.test.appY");
    ASSERT(id1 == id2, "Identifier should be the same on repeated calls");
    PASS();
    return true;
}

bool test_different_apps_different_ids() {
    TEST("Different apps get different identifiers");
    auto& im = IdentityManager::getInstance();
    std::string id1 = im.getAppIdentifier("com.test.appZ1");
    std::string id2 = im.getAppIdentifier("com.test.appZ2");
    ASSERT(id1 != id2, "Different apps should have different identifiers");
    PASS();
    return true;
}

bool test_rotate_identifier() {
    TEST("Rotate identifier produces new ID");
    auto& im = IdentityManager::getInstance();
    std::string id1 = im.getAppIdentifier("com.test.appRot");
    std::string id2 = im.rotateAppIdentifier("com.test.appRot");
    ASSERT(id1 != id2, "Rotated identifier should be different");
    // New identifier should be stable
    std::string id3 = im.getAppIdentifier("com.test.appRot");
    ASSERT(id2 == id3, "Identifier should be stable after rotation");
    PASS();
    return true;
}

bool test_remove_identifier() {
    TEST("Remove identifier");
    auto& im = IdentityManager::getInstance();
    im.getAppIdentifier("com.test.appRem");
    ASSERT(im.hasIdentifier("com.test.appRem"), "Should have identifier");
    im.removeAppIdentifier("com.test.appRem");
    ASSERT(!im.hasIdentifier("com.test.appRem"), "Should not have identifier after removal");
    PASS();
    return true;
}

bool test_hardware_id_denied() {
    TEST("Hardware IDs are denied by default");
    ASSERT(IdentityManager::shouldDenyHardwareId("IMEI"), "IMEI should be denied");
    ASSERT(IdentityManager::shouldDenyHardwareId("imsi"), "IMSI should be denied (case insensitive)");
    ASSERT(IdentityManager::shouldDenyHardwareId("SERIAL_NUMBER"), "Serial should be denied");
    ASSERT(IdentityManager::shouldDenyHardwareId("WIFI_MAC"), "WiFi MAC should be denied");
    ASSERT(IdentityManager::shouldDenyHardwareId("BLUETOOTH_MAC"), "BT MAC should be denied");
    ASSERT(IdentityManager::shouldDenyHardwareId("ANDROID_ID"), "Android ID should be denied");
    ASSERT(IdentityManager::shouldDenyHardwareId("ADVERTISING_ID"), "Ad ID should be denied");
    PASS();
    return true;
}

bool test_non_hardware_id_allowed() {
    TEST("Non-hardware IDs are not denied");
    ASSERT(!IdentityManager::shouldDenyHardwareId("app_session_token"), "Session token should not be denied");
    ASSERT(!IdentityManager::shouldDenyHardwareId("user_preference"), "User preference should not be denied");
    PASS();
    return true;
}

bool test_protected_ids_list() {
    TEST("Protected hardware IDs list");
    auto ids = IdentityManager::protectedHardwareIds();
    ASSERT(!ids.empty(), "Protected IDs list should not be empty");
    ASSERT(ids.size() >= 9, "Should have at least 9 protected IDs");

    bool found_imei = false;
    for (const auto& id : ids) {
        if (id == "IMEI") found_imei = true;
    }
    ASSERT(found_imei, "IMEI should be in protected list");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Identity Manager Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_generate_identifier();
    all_pass &= test_stable_identifier();
    all_pass &= test_different_apps_different_ids();
    all_pass &= test_rotate_identifier();
    all_pass &= test_remove_identifier();
    all_pass &= test_hardware_id_denied();
    all_pass &= test_non_hardware_id_allowed();
    all_pass &= test_protected_ids_list();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
