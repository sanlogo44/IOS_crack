/*
 * Phantom OS - Terminal App Unit Tests
 * Tests for the Terminal App with Linux Compatibility Layer integration
 *
 * License: GPL-3.0
 */

#include "phantom/terminal/terminal_app.h"
#include "phantom/linux_compat/program_executor.h"
#include "phantom/linux_compat/linux_program.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include <cstdio>
#include <cstring>

using namespace phantom::terminal;
using namespace phantom::linux_compat;
using namespace phantom::gui;

static int tests_passed = 0;
static int tests_failed = 0;

static void check(bool condition, const char* testName) {
    if (condition) {
        printf("  [PASS] %s\n", testName);
        tests_passed++;
    } else {
        printf("  [FAIL] %s\n", testName);
        tests_failed++;
    }
}

// ============================================================
// Test: Initialization
// ============================================================
static void testInitialization() {
    printf("\n=== Initialization Tests ===\n");

    TerminalApp app;
    check(!app.isInitialized(), "Not initialized before init");
    check(app.getState() == TerminalState::IDLE, "State is IDLE before init");

    app.initialize();
    check(app.isInitialized(), "Initialized after init");
    check(app.getState() == TerminalState::INITIALIZED, "State is INITIALIZED after init");

    app.shutdown();
    check(!app.isInitialized(), "Not initialized after shutdown");
    check(app.getState() == TerminalState::SHUTDOWN, "State is SHUTDOWN after shutdown");
}

// ============================================================
// Test: Widget Tree
// ============================================================
static void testWidgetTree() {
    printf("\n=== Widget Tree Tests ===\n");

    TerminalApp app;
    app.initialize();

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists");
    check(root->getChildCount() == 2, "Root has 2 children (output + input)");

    // Output area
    auto* outputArea = root->getChild(0);
    check(outputArea != nullptr, "Output area exists");
    check(outputArea->getChildCount() >= 1, "Output area has children");

    // Input area
    auto* inputArea = root->getChild(1);
    check(inputArea != nullptr, "Input area exists");
    check(inputArea->getChildCount() >= 2, "Input area has prompt + field");

    app.shutdown();
}

// ============================================================
// Test: Output Buffer
// ============================================================
static void testOutputBuffer() {
    printf("\n=== Output Buffer Tests ===\n");

    TerminalApp app;
    app.initialize();

    // Should have welcome message + initial prompt
    check(app.getOutputLineCount() > 0, "Output has content after init");

    // Add output
    size_t beforeCount = app.getOutputLineCount();
    app.executeCommand("echo hello world");
    size_t afterCount = app.getOutputLineCount();
    check(afterCount > beforeCount, "Output grew after command");

    // Clear output
    app.clearOutput();
    check(app.getOutputLineCount() == 0, "Output empty after clear");

    app.shutdown();
}

// ============================================================
// Test: Max Output Lines
// ============================================================
static void testMaxOutputLines() {
    printf("\n=== Max Output Lines Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.setMaxOutputLines(10);
    app.clearOutput();

    // Add more than 10 lines
    for (int i = 0; i < 20; ++i) {
        app.executeCommand("echo line" + std::to_string(i));
    }

    check(app.getOutputLineCount() <= 10, "Output trimmed to max lines");
    check(app.getMaxOutputLines() == 10, "Max output lines is 10");

    app.shutdown();
}

// ============================================================
// Test: Built-in Commands
// ============================================================
static void testBuiltinCommands() {
    printf("\n=== Built-in Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    check(app.getBuiltinCommandCount() == 14, "14 built-in commands registered");
    check(app.hasBuiltinCommand("help"), "Has 'help' command");
    check(app.hasBuiltinCommand("ls"), "Has 'ls' command");
    check(app.hasBuiltinCommand("ps"), "Has 'ps' command");
    check(app.hasBuiltinCommand("kill"), "Has 'kill' command");
    check(app.hasBuiltinCommand("run"), "Has 'run' command");
    check(app.hasBuiltinCommand("clear"), "Has 'clear' command");
    check(app.hasBuiltinCommand("version"), "Has 'version' command");
    check(app.hasBuiltinCommand("uname"), "Has 'uname' command");
    check(app.hasBuiltinCommand("echo"), "Has 'echo' command");
    check(app.hasBuiltinCommand("whoami"), "Has 'whoami' command");
    check(app.hasBuiltinCommand("pwd"), "Has 'pwd' command");
    check(app.hasBuiltinCommand("cd"), "Has 'cd' command");
    check(app.hasBuiltinCommand("date"), "Has 'date' command");
    check(app.hasBuiltinCommand("history"), "Has 'history' command");
    check(!app.hasBuiltinCommand("nonexistent"), "Does not have 'nonexistent' command");

    app.shutdown();
}

// ============================================================
// Test: Echo Command
// ============================================================
static void testEchoCommand() {
    printf("\n=== Echo Command Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.clearOutput();

    std::string output;
    auto result = app.executeCommand("echo Hello World", output);
    check(result == CommandResult::SUCCESS, "Echo command succeeded");
    check(output == "Hello World", "Echo output is 'Hello World'");

    result = app.executeCommand("echo test123", output);
    check(result == CommandResult::SUCCESS, "Echo test123 succeeded");
    check(output == "test123", "Echo output is 'test123'");

    result = app.executeCommand("echo", output);
    check(result == CommandResult::SUCCESS, "Echo with no args succeeded");
    check(output.empty(), "Echo with no args returns empty");

    app.shutdown();
}

// ============================================================
// Test: Help Command
// ============================================================
static void testHelpCommand() {
    printf("\n=== Help Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("help", output);
    check(result == CommandResult::SUCCESS, "Help command succeeded");
    check(output.find("Available commands") != std::string::npos, "Help lists available commands");
    check(output.find("echo") != std::string::npos, "Help includes echo");
    check(output.find("help") != std::string::npos, "Help includes help");
    check(output.find("ls") != std::string::npos, "Help includes ls");
    check(output.find("ps") != std::string::npos, "Help includes ps");

    app.shutdown();
}

// ============================================================
// Test: Version and Uname
// ============================================================
static void testVersionUname() {
    printf("\n=== Version/Uname Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("version", output);
    check(result == CommandResult::SUCCESS, "Version command succeeded");
    check(output.find("0.11.0") != std::string::npos, "Version output contains 0.11.0");

    result = app.executeCommand("uname", output);
    check(result == CommandResult::SUCCESS, "Uname command succeeded");
    check(output == "PhantomOS", "Uname returns PhantomOS");

    result = app.executeCommand("uname -a", output);
    check(result == CommandResult::SUCCESS, "Uname -a succeeded");
    check(output.find("aarch64") != std::string::npos, "Uname -a shows aarch64");

    app.shutdown();
}

// ============================================================
// Test: Whoami and Pwd
// ============================================================
static void testWhoamiPwd() {
    printf("\n=== Whoami/Pwd Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("whoami", output);
    check(result == CommandResult::SUCCESS, "Whoami succeeded");
    check(output == "user", "Whoami returns 'user'");

    result = app.executeCommand("pwd", output);
    check(result == CommandResult::SUCCESS, "Pwd succeeded");
    check(output == "/home/user", "Pwd returns /home/user");

    app.shutdown();
}

// ============================================================
// Test: Cd Command
// ============================================================
static void testCdCommand() {
    printf("\n=== Cd Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("cd /tmp", output);
    check(result == CommandResult::SUCCESS, "Cd /tmp succeeded");
    check(app.getWorkingDirectory() == "/tmp", "Working dir changed to /tmp");

    result = app.executeCommand("pwd", output);
    check(output == "/tmp", "Pwd returns /tmp after cd");

    result = app.executeCommand("cd ..", output);
    check(result == CommandResult::SUCCESS, "Cd .. succeeded");
    check(app.getWorkingDirectory() == "/", "Working dir changed to /");

    result = app.executeCommand("cd", output);
    check(app.getWorkingDirectory() == "/home/user", "Cd with no args goes home");

    app.shutdown();
}

// ============================================================
// Test: Ls Command
// ============================================================
static void testLsCommand() {
    printf("\n=== Ls Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("ls", output);
    check(result == CommandResult::SUCCESS, "Ls succeeded");
    check(!output.empty(), "Ls produces output");
    check(output.find("Applications") != std::string::npos, "Ls shows Applications");
    check(output.find("Documents") != std::string::npos, "Ls shows Documents");

    app.shutdown();
}

// ============================================================
// Test: Date Command
// ============================================================
static void testDateCommand() {
    printf("\n=== Date Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("date", output);
    check(result == CommandResult::SUCCESS, "Date succeeded");
    check(!output.empty(), "Date produces output");
    // Should contain "2026" or current year
    check(output.find("2026") != std::string::npos || output.find("2025") != std::string::npos,
          "Date contains current year");

    app.shutdown();
}

// ============================================================
// Test: Clear Command
// ============================================================
static void testClearCommand() {
    printf("\n=== Clear Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    // Execute a few commands
    app.executeCommand("echo test1");
    app.executeCommand("echo test2");
    check(app.getOutputLineCount() > 0, "Output has content before clear");

    std::string output;
    auto result = app.executeCommand("clear", output);
    check(result == CommandResult::SUCCESS, "Clear succeeded");
    check(app.getOutputLineCount() == 0, "Output empty after clear");

    app.shutdown();
}

// ============================================================
// Test: Command Not Found
// ============================================================
static void testCommandNotFound() {
    printf("\n=== Command Not Found Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.clearOutput();

    std::string output;
    auto result = app.executeCommand("nonexistent_command", output);
    check(result == CommandResult::NOT_FOUND, "Nonexistent command returns NOT_FOUND");
    check(output.find("not found") != std::string::npos, "Error message contains 'not found'");

    app.shutdown();
}

// ============================================================
// Test: Command History
// ============================================================
static void testCommandHistory() {
    printf("\n=== Command History Tests ===\n");

    TerminalApp app;
    app.initialize();

    check(app.getHistoryCount() == 0, "History empty initially");

    app.executeCommand("echo one");
    check(app.getHistoryCount() == 1, "History has 1 entry");
    check(app.getHistory()[0].command == "echo one", "First history entry is 'echo one'");

    app.executeCommand("echo two");
    check(app.getHistoryCount() == 2, "History has 2 entries");
    check(app.getHistory()[1].command == "echo two", "Second history entry is 'echo two'");

    // Navigate history up
    app.navigateHistoryUp();
    check(app.getInputText() == "echo two", "Navigate up shows 'echo two'");

    app.navigateHistoryUp();
    check(app.getInputText() == "echo one", "Navigate up again shows 'echo one'");

    // Navigate history down
    app.navigateHistoryDown();
    check(app.getInputText() == "echo two", "Navigate down shows 'echo two'");

    // Navigate to end
    app.navigateHistoryDown();
    check(app.getInputText().empty(), "Navigate down past end clears input");

    app.shutdown();
}

// ============================================================
// Test: History Command
// ============================================================
static void testHistoryCommand() {
    printf("\n=== History Command Tests ===\n");

    TerminalApp app;
    app.initialize();

    app.executeCommand("echo first");
    app.executeCommand("echo second");
    app.executeCommand("echo third");

    std::string output;
    auto result = app.executeCommand("history", output);
    check(result == CommandResult::SUCCESS, "History command succeeded");
    check(output.find("echo first") != std::string::npos, "History shows 'echo first'");
    check(output.find("echo second") != std::string::npos, "History shows 'echo second'");
    check(output.find("echo third") != std::string::npos, "History shows 'echo third'");
    check(output.find("1") != std::string::npos, "History shows entry numbers");

    app.shutdown();
}

// ============================================================
// Test: Submit Input
// ============================================================
static void testSubmitInput() {
    printf("\n=== Submit Input Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.clearOutput();

    // Type a command
    for (char c : std::string("echo hello")) {
        app.insertChar(c);
    }
    check(app.getInputText() == "echo hello", "Input text matches typed chars");

    // Submit
    app.submitInput();

    // Output should contain "hello" and a prompt
    bool foundHello = false;
    bool foundPrompt = false;
    for (const auto& line : app.getOutputLines()) {
        if (line.text.find("hello") != std::string::npos) foundHello = true;
        if (line.isPrompt) foundPrompt = true;
    }
    check(foundHello, "Output contains 'hello' after submit");
    check(foundPrompt, "Output has prompt after submit");
    check(app.getInputText().empty(), "Input cleared after submit");

    app.shutdown();
}

// ============================================================
// Test: Text Input
// ============================================================
static void testTextInput() {
    printf("\n=== Text Input Tests ===\n");

    TerminalApp app;
    app.initialize();

    // Insert chars
    for (char c : std::string("test")) {
        app.insertChar(c);
    }
    check(app.getInputText() == "test", "Input text is 'test'");

    // Delete char
    app.deleteChar();
    check(app.getInputText() == "tes", "Input text is 'tes' after delete");

    // Clear input
    app.clearInput();
    check(app.getInputText().empty(), "Input cleared");

    // Set input text
    app.setInputText("custom text");
    check(app.getInputText() == "custom text", "Input text set to 'custom text'");

    app.shutdown();
}

// ============================================================
// Test: Prompt
// ============================================================
static void testPrompt() {
    printf("\n=== Prompt Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string prompt = app.getPromptString();
    check(prompt.find("phantom") != std::string::npos, "Prompt contains 'phantom'");
    check(prompt.find("/home/user") != std::string::npos, "Prompt contains working dir");
    check(prompt.find("$") != std::string::npos, "Prompt contains $");

    // Change working directory
    app.setWorkingDirectory("/etc");
    prompt = app.getPromptString();
    check(prompt.find("/etc") != std::string::npos, "Prompt updates with new dir");

    // Change prefix
    app.setPromptPrefix("root");
    prompt = app.getPromptString();
    check(prompt.find("root") != std::string::npos, "Prompt updates with new prefix");

    app.shutdown();
}

// ============================================================
// Test: Scrolling
// ============================================================
static void testScrolling() {
    printf("\n=== Scrolling Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.clearOutput();

    check(app.getScrollOffset() == 0, "Scroll offset is 0 initially");

    // Add some output
    for (int i = 0; i < 10; ++i) {
        app.executeCommand("echo line" + std::to_string(i));
    }

    // Scroll up
    app.scrollUp(3);
    check(app.getScrollOffset() == 3, "Scroll offset is 3 after scrollUp(3)");

    // Scroll down
    app.scrollDown(2);
    check(app.getScrollOffset() == 1, "Scroll offset is 1 after scrollDown(2)");

    // Scroll to bottom
    app.scrollToBottom();
    check(app.getScrollOffset() == 0, "Scroll offset is 0 after scrollToBottom");

    app.shutdown();
}

// ============================================================
// Test: Arg Parsing
// ============================================================
static void testArgParsing() {
    printf("\n=== Arg Parsing Tests ===\n");

    TerminalApp app;
    app.initialize();

    // Simple command
    std::string output;
    auto result = app.executeCommand("echo hello", output);
    check(result == CommandResult::SUCCESS, "Simple echo succeeded");
    check(output == "hello", "Simple echo output is 'hello'");

    // Quoted args
    result = app.executeCommand("echo \"hello world\"", output);
    check(result == CommandResult::SUCCESS, "Quoted echo succeeded");
    check(output == "hello world", "Quoted echo output is 'hello world'");

    // Single quoted args
    result = app.executeCommand("echo 'test value'", output);
    check(result == CommandResult::SUCCESS, "Single-quoted echo succeeded");
    check(output == "test value", "Single-quoted echo output is 'test value'");

    // Multiple args
    result = app.executeCommand("echo a b c d", output);
    check(result == CommandResult::SUCCESS, "Multi-arg echo succeeded");
    check(output == "a b c d", "Multi-arg echo output is 'a b c d'");

    app.shutdown();
}

// ============================================================
// Test: ProgramExecutor Integration
// ============================================================
static void testProgramExecutorIntegration() {
    printf("\n=== ProgramExecutor Integration Tests ===\n");

    // Register a test program
    auto& executor = ProgramExecutor::getInstance();
    executor.clear();

    LinuxProgramInfo info;
    info.program_id = "test_program";
    info.name = "Test Program";
    info.version = "1.0";
    info.distro = LinuxDistro::GENERIC_LINUX;
    info.arch = CpuArchitecture::ARM64;
    info.executable_path = "/usr/bin/test_program";
    info.type = ProgramType::CLI;
    info.description = "A test program";

    auto regResult = executor.registerProgram(info);
    check(regResult == ProgramExecutorResult::SUCCESS, "Test program registered");

    // Create terminal with executor
    TerminalApp app;
    app.initialize(&executor);
    app.clearOutput();

    // Run the program
    std::string output;
    auto result = app.executeCommand("run test_program", output);
    check(result == CommandResult::SUCCESS, "Run command succeeded");
    check(output.find("Started") != std::string::npos, "Run output contains 'Started'");
    check(output.find("test_program") != std::string::npos, "Run output contains program name");

    // Check ps shows the running process
    result = app.executeCommand("ps", output);
    check(result == CommandResult::SUCCESS, "Ps command succeeded");
    check(output.find("test_program") != std::string::npos, "Ps shows test_program");

    // Get the PID and kill it
    auto pids = executor.getRunningProcesses();
    if (!pids.empty()) {
        std::string killCmd = "kill " + std::to_string(pids[0]);
        result = app.executeCommand(killCmd, output);
        check(result == CommandResult::SUCCESS, "Kill command succeeded");
        check(output.find("terminated") != std::string::npos, "Kill output contains 'terminated'");
    }

    // Help should show registered programs
    result = app.executeCommand("help", output);
    check(result == CommandResult::SUCCESS, "Help command succeeded");
    check(output.find("test_program") != std::string::npos, "Help shows registered program");

    app.shutdown();
    executor.clear();
}

// ============================================================
// Test: Rendering
// ============================================================
static void testRendering() {
    printf("\n=== Rendering Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.layout(300, 200);

    Framebuffer fb(300, 200);
    app.render(fb);

    check(fb.getWidth() == 300, "Framebuffer width is 300");
    check(fb.getHeight() == 200, "Framebuffer height is 200");

    // Check some pixels are non-zero (content was rendered)
    bool hasContent = false;
    for (int32_t y = 0; y < 200 && !hasContent; y += 10) {
        for (int32_t x = 0; x < 300 && !hasContent; x += 10) {
            if (fb.getPixel(x, y) != Color::Black) {
                hasContent = true;
            }
        }
    }
    check(hasContent, "Framebuffer has rendered content");

    app.shutdown();
}

// ============================================================
// Test: Layout
// ============================================================
static void testLayout() {
    printf("\n=== Layout Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.layout(300, 200);

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists after layout");
    check(root->getBounds().width == 300, "Root width is 300");
    check(root->getBounds().height == 200, "Root height is 200");

    // Output area should have nonzero bounds
    auto* outputArea = root->getChild(0);
    check(outputArea != nullptr, "Output area exists");
    check(outputArea->getBounds().width > 0, "Output area has nonzero width");
    check(outputArea->getBounds().height > 0, "Output area has nonzero height");

    // Input area should have nonzero bounds
    auto* inputArea = root->getChild(1);
    check(inputArea != nullptr, "Input area exists");
    check(inputArea->getBounds().width > 0, "Input area has nonzero width");
    check(inputArea->getBounds().height > 0, "Input area has nonzero height");

    // Input area children should be positioned
    auto* prompt = inputArea->getChild(0);
    auto* field = inputArea->getChild(1);
    check(prompt != nullptr, "Prompt widget exists");
    check(field != nullptr, "Input field exists");
    check(prompt->getBounds().width > 0, "Prompt has nonzero width");
    check(field->getBounds().width > 0, "Input field has nonzero width");

    app.shutdown();
}

// ============================================================
// Test: Touch Handling
// ============================================================
static void testTouchHandling() {
    printf("\n=== Touch Handling Tests ===\n");

    TerminalApp app;
    app.initialize();
    app.layout(300, 200);

    // Touch in output area (should not crash)
    bool handled = app.handleTouchDown(10, 10);
    check(true, "Touch down does not crash");

    handled = app.handleTouchUp(10, 10);
    check(true, "Touch up does not crash");

    // Touch outside bounds
    handled = app.handleTouchDown(-10, -10);
    check(!handled, "Touch outside bounds not handled");

    app.shutdown();
}

// ============================================================
// Test: Re-initialization
// ============================================================
static void testReinit() {
    printf("\n=== Re-initialization Tests ===\n");

    TerminalApp app;
    app.initialize();
    check(app.isInitialized(), "Initialized after first init");

    app.shutdown();
    check(!app.isInitialized(), "Not initialized after shutdown");

    // Re-initialize
    app.initialize();
    check(app.isInitialized(), "Initialized after re-init");
    check(app.getRootWidget() != nullptr, "Root widget exists after re-init");

    app.shutdown();
}

// ============================================================
// Test: Output Callback
// ============================================================
static void testOutputCallback() {
    printf("\n=== Output Callback Tests ===\n");

    TerminalApp app;
    app.initialize();

    int callbackCount = 0;
    std::string lastText;
    app.setOutputCallback([&](const TerminalLine& line) {
        callbackCount++;
        lastText = line.text;
    });

    int before = callbackCount;
    app.executeCommand("echo callback test");
    check(callbackCount > before, "Output callback fired");

    app.shutdown();
}

// ============================================================
// Test: Invalid Args
// ============================================================
static void testInvalidArgs() {
    printf("\n=== Invalid Args Tests ===\n");

    TerminalApp app;
    app.initialize();

    std::string output;
    auto result = app.executeCommand("kill", output);
    check(result == CommandResult::INVALID_ARGS, "Kill with no args returns INVALID_ARGS");
    check(output.find("Usage") != std::string::npos, "Kill shows usage message");

    result = app.executeCommand("run", output);
    check(result == CommandResult::INVALID_ARGS, "Run with no args returns INVALID_ARGS");
    check(output.find("Usage") != std::string::npos, "Run shows usage message");

    app.shutdown();
}

// ============================================================
// Main
// ============================================================
int main() {
    printf("\n");
    printf("==============================================\n");
    printf("  Phantom OS v0.11.0 - Terminal App Tests    \n");
    printf("==============================================\n");

    testInitialization();
    testWidgetTree();
    testOutputBuffer();
    testMaxOutputLines();
    testBuiltinCommands();
    testEchoCommand();
    testHelpCommand();
    testVersionUname();
    testWhoamiPwd();
    testCdCommand();
    testLsCommand();
    testDateCommand();
    testClearCommand();
    testCommandNotFound();
    testCommandHistory();
    testHistoryCommand();
    testSubmitInput();
    testTextInput();
    testPrompt();
    testScrolling();
    testArgParsing();
    testProgramExecutorIntegration();
    testRendering();
    testLayout();
    testTouchHandling();
    testReinit();
    testOutputCallback();
    testInvalidArgs();

    printf("\n==============================================\n");
    printf("  Terminal App Tests: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("==============================================\n");

    return tests_failed > 0 ? 1 : 0;
}
