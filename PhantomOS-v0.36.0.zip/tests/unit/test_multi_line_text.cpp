/*
 * Phantom OS - Multi-Line Text Tests
 * Tests for text wrapping and multi-line rendering
 *
 * License: GPL-3.0
 */

#include "phantom/gui/multi_line_text.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

// ============================================================
// Text Wrapping Tests
// ============================================================

bool test_wrap_short_text() {
    BitmapFont font;
    MultiLineText mlt;

    auto lines = mlt.wrapText("Hello", 200, font);
    ASSERT(lines.size() == 1, "Short text should produce 1 line");
    ASSERT(lines[0].text == "Hello", "Line text should be 'Hello'");
    return true;
}

bool test_wrap_long_text() {
    BitmapFont font;
    MultiLineText mlt;

    // Each char is 6px, so 5 chars = 30px. With max 30px, should wrap
    auto lines = mlt.wrapText("ABCDE FGHIJ", 30, font);
    ASSERT(lines.size() >= 2, "Long text should produce 2+ lines");
    return true;
}

bool test_wrap_multiple_words() {
    BitmapFont font;
    MultiLineText mlt;

    // "AAA BBB CCC" with max width for ~4 chars
    auto lines = mlt.wrapText("AAA BBB CCC DDD EEE", 24, font);
    ASSERT(lines.size() >= 3, "Multiple words should wrap to 3+ lines");
    return true;
}

bool test_wrap_empty_text() {
    BitmapFont font;
    MultiLineText mlt;

    auto lines = mlt.wrapText("", 100, font);
    // Empty text should produce one empty line (from splitByNewlines)
    ASSERT(lines.size() == 1, "Empty text should produce 1 line");
    return true;
}

bool test_wrap_single_word_too_long() {
    BitmapFont font;
    MultiLineText mlt;

    // A single word longer than maxWidth should still be on one line
    auto lines = mlt.wrapText("AAAAAAAAAAAA", 30, font);
    ASSERT(lines.size() == 1, "Single long word should be 1 line");
    return true;
}

bool test_split_by_newlines() {
    MultiLineText mlt;

    auto segments = mlt.splitByNewlines("Line1\nLine2\nLine3");
    ASSERT(segments.size() == 3, "Should split into 3 segments");
    ASSERT(segments[0] == "Line1", "First segment should be 'Line1'");
    ASSERT(segments[1] == "Line2", "Second segment should be 'Line2'");
    ASSERT(segments[2] == "Line3", "Third segment should be 'Line3'");
    return true;
}

bool test_wrap_with_explicit_newlines() {
    BitmapFont font;
    MultiLineText mlt;

    auto lines = mlt.wrapText("Hello\nWorld", 200, font);
    ASSERT(lines.size() == 2, "Text with newline should produce 2 lines");
    ASSERT(lines[0].text == "Hello", "First line should be 'Hello'");
    ASSERT(lines[1].text == "World", "Second line should be 'World'");
    return true;
}

bool test_measure_height() {
    BitmapFont font;
    MultiLineText mlt;

    auto lines = mlt.wrapText("Hello\nWorld\nTest", 200, font);
    int32_t lineHeight = font.getLineHeight();
    int32_t height = mlt.measureHeight(lines, lineHeight);
    ASSERT(height == 3 * lineHeight, "Height should be 3 * lineHeight");
    return true;
}

bool test_get_line_count() {
    BitmapFont font;
    MultiLineText mlt;

    int32_t count = mlt.getLineCount("Hello World Test", 30, font);
    ASSERT(count >= 2, "Line count should be >= 2 for long text");
    return true;
}

bool test_is_word_boundary() {
    ASSERT(MultiLineText::isWordBoundary(' '), "Space should be word boundary");
    ASSERT(MultiLineText::isWordBoundary('-'), "Dash should be word boundary");
    ASSERT(MultiLineText::isWordBoundary('/'), "Slash should be word boundary");
    ASSERT(!MultiLineText::isWordBoundary('A'), "Letter should not be word boundary");
    ASSERT(!MultiLineText::isWordBoundary('1'), "Digit should not be word boundary");
    return true;
}

// ============================================================
// Rendering Tests
// ============================================================

bool test_draw_wrapped_text() {
    Framebuffer fb(100, 50);
    BitmapFont font;
    MultiLineText mlt;

    fb.clear(Color::Black);
    mlt.drawWrapped(fb, "Hello World This Is A Test", Rect(0, 0, 60, 50), font, Color::White);

    // Check that some pixels were drawn (non-black pixels exist)
    bool hasWhite = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) {
            hasWhite = true;
            break;
        }
    }
    ASSERT(hasWhite, "Drawn text should produce non-black pixels");
    return true;
}

bool test_draw_lines_alignment() {
    Framebuffer fb(100, 30);
    BitmapFont font;
    MultiLineText mlt;

    std::vector<TextLine> lines = {{"Hi", 12}, {"World", 30}};
    fb.clear(Color::Black);
    mlt.drawLines(fb, lines, Rect(0, 0, 100, 30), font, Color::White, TextAlignment::CENTER);

    // Check that pixels were drawn
    bool hasWhite = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) {
            hasWhite = true;
            break;
        }
    }
    ASSERT(hasWhite, "Centered text should produce pixels");
    return true;
}

bool test_text_alignment_enum() {
    ASSERT(static_cast<int>(TextAlignment::LEFT) == 0, "LEFT should be 0");
    ASSERT(static_cast<int>(TextAlignment::CENTER) == 1, "CENTER should be 1");
    ASSERT(static_cast<int>(TextAlignment::RIGHT) == 2, "RIGHT should be 2");
    return true;
}

int main() {
    printf("=== Multi-Line Text Tests ===\n");

    test_wrap_short_text();
    test_wrap_long_text();
    test_wrap_multiple_words();
    test_wrap_empty_text();
    test_wrap_single_word_too_long();
    test_split_by_newlines();
    test_wrap_with_explicit_newlines();
    test_measure_height();
    test_get_line_count();
    test_is_word_boundary();
    test_draw_wrapped_text();
    test_draw_lines_alignment();
    test_text_alignment_enum();

    printf("\nResults: %d/%d passed (%d tests)\n", pass_count, test_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
