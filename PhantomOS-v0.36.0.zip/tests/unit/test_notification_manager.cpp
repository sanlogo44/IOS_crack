/*
 * Phantom OS - Notification Manager Tests
 * v0.18.0 — Notification lifecycle, channels, DND, grouping, privacy, badges
 *
 * License: GPL-3.0
 */

#include "phantom/notifications/notification_manager.h"
#include <cstdio>
#include <cstring>

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %s\n", #name); \
    tests_passed++; \
    name(); \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

using namespace phantom::notifications;

// ============================================================
// Lifecycle tests
// ============================================================

static void testInitialization() {
    NotificationManager mgr;
    ASSERT_FALSE(mgr.isInitialized());

    auto result = mgr.initialize(500);
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.getMaxQueueSize(), static_cast<size_t>(500));
}

static void testReinitialization() {
    NotificationManager mgr;
    mgr.initialize();
    auto result = mgr.initialize();
    ASSERT_EQ(result, NotificationResult::ALREADY_INITIALIZED);
}

static void testShutdown() {
    NotificationManager mgr;
    mgr.initialize();
    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Test";
    mgr.post(notif);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));

    mgr.shutdown();
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
}

// ============================================================
// App permission tests
// ============================================================

static void testAppAllowedByDefault() {
    NotificationManager mgr;
    mgr.initialize();
    ASSERT_TRUE(mgr.isAppAllowed("com.test.app"));
}

static void testBlockApp() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setAppAllowed("com.bad.app", false);
    ASSERT_FALSE(mgr.isAppAllowed("com.bad.app"));
    ASSERT_TRUE(mgr.isAppAllowed("com.good.app"));
}

static void testAllowList() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setAppAllowed("com.allowed.app", true);
    ASSERT_TRUE(mgr.isAppAllowed("com.allowed.app"));
    // Other apps still allowed if allow-list is not exclusive
    ASSERT_TRUE(mgr.isAppAllowed("com.other.app"));
}

static void testBlockedAppNotification() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setAppAllowed("com.bad.app", false);

    Notification notif;
    notif.appId = "com.bad.app";
    notif.title = "Spam";
    uint64_t id = mgr.post(notif);
    ASSERT_EQ(id, static_cast<uint64_t>(0));
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalBlocked, static_cast<uint64_t>(1));
}

// ============================================================
// Channel tests
// ============================================================

static void testCreateChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "messages";
    channel.appId = "com.test.app";
    channel.name = "Messages";
    channel.importance = ChannelImportance::HIGH;

    auto result = mgr.createChannel(channel);
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_EQ(mgr.getChannelCount(), static_cast<size_t>(1));
    ASSERT_TRUE(mgr.channelExists("com.test.app", "messages"));
}

static void testDuplicateChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "alerts";
    channel.appId = "com.test.app";
    channel.name = "Alerts";

    mgr.createChannel(channel);
    auto result = mgr.createChannel(channel);
    ASSERT_EQ(result, NotificationResult::CHANNEL_ALREADY_EXISTS);
}

static void testDeleteChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "temp";
    channel.appId = "com.test.app";
    mgr.createChannel(channel);

    auto result = mgr.deleteChannel("com.test.app", "temp");
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_FALSE(mgr.channelExists("com.test.app", "temp"));
}

static void testDeleteNonExistentChannel() {
    NotificationManager mgr;
    mgr.initialize();
    auto result = mgr.deleteChannel("com.test.app", "nonexistent");
    ASSERT_EQ(result, NotificationResult::CHANNEL_NOT_FOUND);
}

static void testGetChannelsForApp() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel ch1;
    ch1.id = "msg";
    ch1.appId = "com.app1";
    ch1.name = "Messages";
    mgr.createChannel(ch1);

    NotificationChannel ch2;
    ch2.id = "alerts";
    ch2.appId = "com.app1";
    ch2.name = "Alerts";
    mgr.createChannel(ch2);

    NotificationChannel ch3;
    ch3.id = "msg";
    ch3.appId = "com.app2";
    ch3.name = "Messages";
    mgr.createChannel(ch3);

    auto app1Channels = mgr.getChannels("com.app1");
    ASSERT_EQ(app1Channels.size(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getChannelCountForApp("com.app1"), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getChannelCountForApp("com.app2"), static_cast<size_t>(1));
}

static void testEnableDisableChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "test";
    channel.appId = "com.test.app";
    channel.enabled = true;
    mgr.createChannel(channel);

    auto result = mgr.enableChannel("com.test.app", "test", false);
    ASSERT_EQ(result, NotificationResult::SUCCESS);

    auto ch = mgr.getChannel("com.test.app", "test");
    ASSERT_FALSE(ch.enabled);

    mgr.enableChannel("com.test.app", "test", true);
    ch = mgr.getChannel("com.test.app", "test");
    ASSERT_TRUE(ch.enabled);
}

static void testDisabledChannelBlocksNotification() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "muted";
    channel.appId = "com.test.app";
    channel.enabled = false;
    mgr.createChannel(channel);

    Notification notif;
    notif.appId = "com.test.app";
    notif.channel = "muted";
    notif.title = "Test";

    uint64_t id = mgr.post(notif);
    ASSERT_EQ(id, static_cast<uint64_t>(0));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalBlocked, static_cast<uint64_t>(1));
}

// ============================================================
// Post / Update / Cancel tests
// ============================================================

static void testPostBasic() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Hello";
    notif.body = "World";
    notif.priority = NotificationPriority::HIGH;

    uint64_t id = mgr.post(notif);
    ASSERT_GT(id, static_cast<uint64_t>(0));
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));

    auto active = mgr.getActive();
    ASSERT_EQ(active.size(), static_cast<size_t>(1));
    ASSERT_EQ(active[0].title, "Hello");
    ASSERT_EQ(active[0].body, "World");
    ASSERT_EQ(active[0].priority, NotificationPriority::HIGH);
    ASSERT_EQ(active[0].state, NotificationState::ACTIVE);
}

static void testPostMultiple() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 5; ++i) {
        Notification notif;
        notif.appId = "com.test.app";
        notif.title = "Notif " + std::to_string(i);
        mgr.post(notif);
    }

    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(5));
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalPosted, static_cast<uint64_t>(5));
}

static void testUpdateNotification() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Original";
    uint64_t id = mgr.post(notif);

    Notification updated;
    updated.appId = "com.test.app";
    updated.title = "Updated";
    bool success = mgr.update(id, updated);
    ASSERT_TRUE(success);

    auto notifById = mgr.getById(id);
    ASSERT_EQ(notifById.title, "Updated");
}

static void testCancelNotification() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Cancel me";
    uint64_t id = mgr.post(notif);

    bool success = mgr.cancel(id);
    ASSERT_TRUE(success);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalCancelled, static_cast<uint64_t>(1));
}

static void testCancelAllForApp() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 3; ++i) {
        Notification notif;
        notif.appId = "com.app1";
        notif.title = "App1 Notif";
        mgr.post(notif);
    }
    for (int i = 0; i < 2; ++i) {
        Notification notif;
        notif.appId = "com.app2";
        notif.title = "App2 Notif";
        mgr.post(notif);
    }

    bool success = mgr.cancelAll("com.app1");
    ASSERT_TRUE(success);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getCountByApp("com.app1"), static_cast<size_t>(0));
}

static void testCancelTagged() {
    NotificationManager mgr;
    mgr.initialize();

    Notification n1;
    n1.appId = "com.test.app";
    n1.tag = "chat";
    n1.title = "Message 1";
    mgr.post(n1);

    Notification n2;
    n2.appId = "com.test.app";
    n2.tag = "chat";
    n2.title = "Message 2";
    mgr.post(n2);

    Notification n3;
    n3.appId = "com.test.app";
    n3.tag = "update";
    n3.title = "Update";
    mgr.post(n3);

    bool success = mgr.cancelTagged("com.test.app", "chat");
    ASSERT_TRUE(success);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));
}

static void testDismissNotification() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Dismiss me";
    uint64_t id = mgr.post(notif);

    bool success = mgr.dismiss(id);
    ASSERT_TRUE(success);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalDismissed, static_cast<uint64_t>(1));
}

static void testSnoozeAutoReactivate() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Snoozed";
    uint64_t id = mgr.post(notif);
    mgr.snooze(id, 1000);  // Snooze for 1 second

    // Verify snoozed
    auto snoozed = mgr.getSnoozed();
    ASSERT_EQ(snoozed.size(), static_cast<size_t>(1));

    // Process expiry with a future time - should auto-reactivate
    mgr.processExpiry(999999999);

    auto after = mgr.getById(id);
    ASSERT_EQ(after.state, NotificationState::ACTIVE);
    auto stillSnoozed = mgr.getSnoozed();
    ASSERT_EQ(stillSnoozed.size(), static_cast<size_t>(0));
}

static void testSnoozeAndUnsnooze() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Snooze me";
    uint64_t id = mgr.post(notif);

    bool success = mgr.snooze(id, 60000);
    ASSERT_TRUE(success);

    auto snoozed = mgr.getSnoozed();
    ASSERT_EQ(snoozed.size(), static_cast<size_t>(1));

    success = mgr.unsnooze(id);
    ASSERT_TRUE(success);

    snoozed = mgr.getSnoozed();
    ASSERT_EQ(snoozed.size(), static_cast<size_t>(0));
}

static void testGetById() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.test.app";
    notif.title = "Find me";
    notif.body = "Content";
    uint64_t id = mgr.post(notif);

    auto retrieved = mgr.getById(id);
    ASSERT_EQ(retrieved.id, id);
    ASSERT_EQ(retrieved.title, "Find me");
}

static void testGetByIdNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    auto retrieved = mgr.getById(99999);
    ASSERT_EQ(retrieved.id, static_cast<uint64_t>(0));
}

// ============================================================
// Query tests
// ============================================================

static void testGetByApp() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 3; ++i) {
        Notification notif;
        notif.appId = "com.app1";
        notif.title = "App1";
        mgr.post(notif);
    }
    for (int i = 0; i < 2; ++i) {
        Notification notif;
        notif.appId = "com.app2";
        notif.title = "App2";
        mgr.post(notif);
    }

    auto app1Notifs = mgr.getByApp("com.app1");
    ASSERT_EQ(app1Notifs.size(), static_cast<size_t>(3));
}

static void testGetByCategory() {
    NotificationManager mgr;
    mgr.initialize();

    Notification n1;
    n1.appId = "com.app";
    n1.category = NotificationCategory::MESSAGE;
    mgr.post(n1);

    Notification n2;
    n2.appId = "com.app";
    n2.category = NotificationCategory::CALL;
    mgr.post(n2);

    Notification n3;
    n3.appId = "com.app";
    n3.category = NotificationCategory::MESSAGE;
    mgr.post(n3);

    auto msgNotifs = mgr.getByCategory(NotificationCategory::MESSAGE);
    ASSERT_EQ(msgNotifs.size(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getCountByCategory(NotificationCategory::CALL), static_cast<size_t>(1));
}

static void testGetByPriority() {
    NotificationManager mgr;
    mgr.initialize();

    Notification n1;
    n1.appId = "com.app";
    n1.priority = NotificationPriority::HIGH;
    mgr.post(n1);

    Notification n2;
    n2.appId = "com.app";
    n2.priority = NotificationPriority::LOW;
    mgr.post(n2);

    Notification n3;
    n3.appId = "com.app";
    n3.priority = NotificationPriority::HIGH;
    mgr.post(n3);

    auto highNotifs = mgr.getByPriority(NotificationPriority::HIGH);
    ASSERT_EQ(highNotifs.size(), static_cast<size_t>(2));
    ASSERT_EQ(mgr.getCountByPriority(NotificationPriority::LOW), static_cast<size_t>(1));
}

static void testGetRecent() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 10; ++i) {
        Notification notif;
        notif.appId = "com.app";
        notif.title = "Notif " + std::to_string(i);
        mgr.post(notif);
    }

    auto recent = mgr.getRecent(3);
    ASSERT_EQ(recent.size(), static_cast<size_t>(3));
}

static void testGetHistory() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "History test";
    uint64_t id = mgr.post(notif);
    mgr.dismiss(id);

    auto history = mgr.getHistory();
    ASSERT_GE(history.size(), static_cast<size_t>(1));
    ASSERT_EQ(history[0].state, NotificationState::DISMISSED);
}

// ============================================================
// Expiry tests
// ============================================================

static void testExpireNotifications() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Old";
    notif.expiryTime = 1;  // Already expired (1ms)
    uint64_t id = mgr.post(notif);

    // Use processExpiry with a future time
    mgr.processExpiry(999999999);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));

    auto stats = mgr.getStats();
    ASSERT_GE(stats.totalExpired, static_cast<uint64_t>(1));
}

static void testOngoingNotExpired() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Ongoing";
    notif.ongoing = true;
    notif.expiryTime = 1;  // Already expired
    uint64_t id = mgr.post(notif);

    // processExpiry should NOT expire ongoing notifications
    mgr.processExpiry(999999999);
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(1));
    auto retrieved = mgr.getById(id);
    ASSERT_EQ(retrieved.state, NotificationState::ACTIVE);
}

static void testExpireByAge() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Old notif";
    notif.ongoing = false;
    mgr.post(notif);

    // Expire all notifications older than 0ms (everything)
    size_t count = mgr.expireNotifications(0);
    ASSERT_GE(count, static_cast<size_t>(1));
}

// ============================================================
// Group tests
// ============================================================

static void testCreateGroup() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "messages_group";
    group.appId = "com.test.app";
    group.summaryTitle = "3 Messages";

    auto result = mgr.createGroup(group);
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_EQ(mgr.getGroupCount(), static_cast<size_t>(1));
}

static void testAddToGroup() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "test_group";
    group.appId = "com.app";
    mgr.createGroup(group);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Grouped";
    notif.groupKey = "test_group";
    uint64_t id = mgr.post(notif);

    auto result = mgr.addToGroup(id, "test_group");
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_EQ(mgr.getGroupChildCount("test_group"), static_cast<size_t>(1));
}

static void testRemoveFromGroup() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "test_group";
    group.appId = "com.app";
    mgr.createGroup(group);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Grouped";
    notif.groupKey = "test_group";
    uint64_t id = mgr.post(notif);
    mgr.addToGroup(id, "test_group");

    auto result = mgr.removeFromGroup(id, "test_group");
    ASSERT_EQ(result, NotificationResult::SUCCESS);
    ASSERT_EQ(mgr.getGroupChildCount("test_group"), static_cast<size_t>(0));
}

static void testGroupNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    auto group = mgr.getGroup("nonexistent");
    ASSERT_TRUE(group.key.empty());
}

static void testDuplicateGroup() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "dup_group";
    group.appId = "com.app";
    mgr.createGroup(group);

    auto result = mgr.createGroup(group);
    ASSERT_EQ(result, NotificationResult::CHANNEL_ALREADY_EXISTS);
}

// ============================================================
// DND tests
// ============================================================

static void testDndOff() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    uint64_t id = mgr.post(notif);
    ASSERT_GT(id, static_cast<uint64_t>(0));
}

static void testDndTotalSilence() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setDndMode(DndMode::TOTAL_SILENCE);

    ASSERT_TRUE(mgr.isDndActive());

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    uint64_t id = mgr.post(notif);
    ASSERT_EQ(id, static_cast<uint64_t>(0));

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalBlocked, static_cast<uint64_t>(1));
}

static void testDndPriorityOnly() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setDndMode(DndMode::PRIORITY_ONLY);

    // High priority should pass
    Notification highNotif;
    highNotif.appId = "com.app";
    highNotif.title = "Important";
    highNotif.priority = NotificationPriority::HIGH;
    uint64_t highId = mgr.post(highNotif);
    ASSERT_GT(highId, static_cast<uint64_t>(0));

    // Low priority should be blocked
    Notification lowNotif;
    lowNotif.appId = "com.app";
    lowNotif.title = "Low priority";
    lowNotif.priority = NotificationPriority::LOW;
    uint64_t lowId = mgr.post(lowNotif);
    ASSERT_EQ(lowId, static_cast<uint64_t>(0));
}

static void testDndAlarmsOnly() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setDndMode(DndMode::ALARMS_ONLY);

    // Alarm should pass
    Notification alarmNotif;
    alarmNotif.appId = "com.clock";
    alarmNotif.title = "Wake up";
    alarmNotif.category = NotificationCategory::ALARM;
    uint64_t alarmId = mgr.post(alarmNotif);
    ASSERT_GT(alarmId, static_cast<uint64_t>(0));

    // Non-alarm should be blocked
    Notification msgNotif;
    msgNotif.appId = "com.chat";
    msgNotif.title = "Hello";
    msgNotif.category = NotificationCategory::MESSAGE;
    uint64_t msgId = mgr.post(msgNotif);
    ASSERT_EQ(msgId, static_cast<uint64_t>(0));
}

static void testDndSchedule() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setDndStart(22, 0);
    mgr.setDndEnd(7, 0);
    mgr.setDndScheduled(true);

    ASSERT_TRUE(mgr.isDndScheduled());
    ASSERT_EQ(mgr.getDndStartHour(), static_cast<uint32_t>(22));
    ASSERT_EQ(mgr.getDndEndHour(), static_cast<uint32_t>(7));
}

// ============================================================
// Privacy tests
// ============================================================

static void testPrivacyShowAll() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setPrivacyMode(PrivacyMode::SHOW_ALL);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Secret Title";
    notif.body = "Secret Body";

    auto redacted = mgr.redactNotification(notif);
    ASSERT_EQ(redacted.title, "Secret Title");
    ASSERT_EQ(redacted.body, "Secret Body");
}

static void testPrivacyHideContent() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setPrivacyMode(PrivacyMode::HIDE_CONTENT);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Secret Title";
    notif.body = "Secret Body";

    auto redacted = mgr.redactNotification(notif);
    ASSERT_EQ(redacted.title, "Benachrichtigung");
    ASSERT_TRUE(redacted.body.empty());
}

static void testPrivacyRedact() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setPrivacyMode(PrivacyMode::REDACT);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Secret Title";
    notif.body = "Secret Body Text";

    auto redacted = mgr.redactNotification(notif);
    ASSERT_TRUE(redacted.title != "Secret Title");
    ASSERT_TRUE(redacted.body != "Secret Body Text");
}

static void testPrivacyHideAll() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setPrivacyMode(PrivacyMode::HIDE_ALL);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Secret Title";
    notif.body = "Secret Body";

    auto redacted = mgr.redactNotification(notif);
    ASSERT_TRUE(redacted.title.empty());
    ASSERT_TRUE(redacted.body.empty());
}

static void testRedactText() {
    NotificationManager mgr;
    mgr.initialize();

    std::string short_text = "Hi";
    std::string result = mgr.redactText(short_text);
    ASSERT_EQ(result, "***");

    std::string long_text = "Hello World";
    result = mgr.redactText(long_text);
    // Should start with "He" and end with "ld"
    ASSERT_EQ(result.substr(0, 2), "He");
    ASSERT_EQ(result.substr(result.length() - 2), "ld");
}

static void testNotificationLevelPrivacy() {
    NotificationManager mgr;
    mgr.initialize();
    mgr.setPrivacyMode(PrivacyMode::SHOW_ALL);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Private";
    notif.body = "Content";
    notif.privacyMode = PrivacyMode::HIDE_CONTENT;

    auto redacted = mgr.redactNotification(notif);
    ASSERT_EQ(redacted.title, "Benachrichtigung");
    ASSERT_TRUE(redacted.body.empty());
}

// ============================================================
// Badge tests
// ============================================================

static void testBadgeIncrement() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    mgr.post(notif);
    mgr.post(notif);
    mgr.post(notif);

    ASSERT_EQ(mgr.getBadgeCount("com.app"), static_cast<int32_t>(3));
}

static void testBadgeDecrementOnDismiss() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    uint64_t id = mgr.post(notif);
    mgr.post(notif);

    ASSERT_EQ(mgr.getBadgeCount("com.app"), static_cast<int32_t>(2));

    mgr.dismiss(id);
    ASSERT_EQ(mgr.getBadgeCount("com.app"), static_cast<int32_t>(1));
}

static void testBadgeExplicit() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    notif.badgeCount = 42;
    mgr.post(notif);

    ASSERT_EQ(mgr.getBadgeCount("com.app"), static_cast<int32_t>(42));
}

static void testClearBadge() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    mgr.post(notif);
    mgr.post(notif);

    mgr.clearBadge("com.app");
    ASSERT_EQ(mgr.getBadgeCount("com.app"), static_cast<int32_t>(0));
}

static void testGetAllBadges() {
    NotificationManager mgr;
    mgr.initialize();

    Notification n1;
    n1.appId = "com.app1";
    mgr.post(n1);

    Notification n2;
    n2.appId = "com.app2";
    mgr.post(n2);
    mgr.post(n2);

    auto badges = mgr.getAllBadges();
    ASSERT_EQ(badges.size(), static_cast<size_t>(2));
    ASSERT_EQ(badges["com.app1"], static_cast<int32_t>(1));
    ASSERT_EQ(badges["com.app2"], static_cast<int32_t>(2));
}

// ============================================================
// Queue overflow tests
// ============================================================

static void testQueueOverflow() {
    NotificationManager mgr;
    mgr.initialize(3);  // Max 3 active

    for (int i = 0; i < 5; ++i) {
        Notification notif;
        notif.appId = "com.app";
        notif.title = "Notif " + std::to_string(i);
        mgr.post(notif);
    }

    // Should have at most 3 active
    ASSERT_TRUE(mgr.getActiveCount() <= static_cast<size_t>(3));
}

// ============================================================
// Callback tests
// ============================================================

static void testPostedCallback() {
    NotificationManager mgr;
    mgr.initialize();

    Notification captured;
    mgr.setPostedCallback([&captured](const Notification& n) { captured = n; });

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Callback test";
    mgr.post(notif);

    ASSERT_EQ(captured.title, "Callback test");
    ASSERT_EQ(captured.appId, "com.app");
}

static void testDismissedCallback() {
    NotificationManager mgr;
    mgr.initialize();

    Notification captured;
    mgr.setDismissedCallback([&captured](const Notification& n) { captured = n; });

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Dismiss test";
    uint64_t id = mgr.post(notif);
    mgr.dismiss(id);

    ASSERT_EQ(captured.title, "Dismiss test");
    ASSERT_EQ(captured.state, NotificationState::DISMISSED);
}

static void testCancelledCallback() {
    NotificationManager mgr;
    mgr.initialize();

    Notification captured;
    mgr.setCancelledCallback([&captured](const Notification& n) { captured = n; });

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Cancel test";
    uint64_t id = mgr.post(notif);
    mgr.cancel(id);

    ASSERT_EQ(captured.title, "Cancel test");
    ASSERT_EQ(captured.state, NotificationState::CANCELLED);
}

static void testBlockedCallback() {
    NotificationManager mgr;
    mgr.initialize();

    Notification captured;
    mgr.setBlockedCallback([&captured](const Notification& n) { captured = n; });

    mgr.setDndMode(DndMode::TOTAL_SILENCE);

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Blocked test";
    mgr.post(notif);

    ASSERT_EQ(captured.title, "Blocked test");
    ASSERT_EQ(captured.state, NotificationState::BLOCKED);
}

// ============================================================
// Stats tests
// ============================================================

static void testStats() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";

    mgr.post(notif);
    mgr.post(notif);
    uint64_t id = mgr.post(notif);
    mgr.dismiss(id);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalPosted, static_cast<uint64_t>(3));
    ASSERT_EQ(stats.totalDismissed, static_cast<uint64_t>(1));
    ASSERT_EQ(stats.totalActive, static_cast<uint64_t>(2));
    ASSERT_GE(stats.perAppCounts.size(), static_cast<size_t>(1));
}

static void testResetStats() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    mgr.post(notif);
    mgr.post(notif);

    mgr.resetStats();
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalPosted, static_cast<uint64_t>(0));
}

// ============================================================
// Management tests
// ============================================================

static void testClearHistory() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    uint64_t id = mgr.post(notif);
    mgr.dismiss(id);

    ASSERT_GE(mgr.getHistoryCount(), static_cast<size_t>(1));
    mgr.clearHistory();
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
}

static void testClearAll() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 5; ++i) {
        Notification notif;
        notif.appId = "com.app";
        mgr.post(notif);
    }

    mgr.clearAll();
    ASSERT_EQ(mgr.getActiveCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
}

static void testClearForApp() {
    NotificationManager mgr;
    mgr.initialize();

    for (int i = 0; i < 3; ++i) {
        Notification n1;
        n1.appId = "com.app1";
        mgr.post(n1);
    }
    for (int i = 0; i < 2; ++i) {
        Notification n2;
        n2.appId = "com.app2";
        mgr.post(n2);
    }

    mgr.clearForApp("com.app1");
    ASSERT_EQ(mgr.getCountByApp("com.app1"), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getCountByApp("com.app2"), static_cast<size_t>(2));
}

// ============================================================
// String helper tests
// ============================================================

static void testStringHelpers() {
    ASSERT_STREQ(NotificationManager::priorityToString(NotificationPriority::HIGH), "HIGH");
    ASSERT_STREQ(NotificationManager::priorityToString(NotificationPriority::MAX), "MAX");
    ASSERT_STREQ(NotificationManager::categoryToString(NotificationCategory::MESSAGE), "MESSAGE");
    ASSERT_STREQ(NotificationManager::categoryToString(NotificationCategory::ALARM), "ALARM");
    ASSERT_STREQ(NotificationManager::importanceToString(ChannelImportance::URGENT), "URGENT");
    ASSERT_STREQ(NotificationManager::stateToString(NotificationState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(NotificationManager::stateToString(NotificationState::DISMISSED), "DISMISSED");
    ASSERT_STREQ(NotificationManager::resultToString(NotificationResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(NotificationManager::resultToString(NotificationResult::NOT_FOUND), "NOT_FOUND");
    ASSERT_STREQ(NotificationManager::dndModeToString(DndMode::TOTAL_SILENCE), "TOTAL_SILENCE");
    ASSERT_STREQ(NotificationManager::dndModeToString(DndMode::OFF), "OFF");
    ASSERT_STREQ(NotificationManager::privacyModeToString(PrivacyMode::REDACT), "REDACT");
    ASSERT_STREQ(NotificationManager::groupAlertToString(GroupAlertBehavior::SUMMARY), "SUMMARY");
}

static void testStringToPriority() {
    ASSERT_EQ(NotificationManager::stringToPriority("HIGH"), NotificationPriority::HIGH);
    ASSERT_EQ(NotificationManager::stringToPriority("LOW"), NotificationPriority::LOW);
    ASSERT_EQ(NotificationManager::stringToPriority("MAX"), NotificationPriority::MAX);
    ASSERT_EQ(NotificationManager::stringToPriority("INVALID"), NotificationPriority::DEFAULT);
}

static void testStringToState() {
    ASSERT_EQ(NotificationManager::stringToState("ACTIVE"), NotificationState::ACTIVE);
    ASSERT_EQ(NotificationManager::stringToState("SNOOZED"), NotificationState::SNOOZED);
    ASSERT_EQ(NotificationManager::stringToState("INVALID"), NotificationState::PENDING);
}

// ============================================================
// Actions tests
// ============================================================

static void testNotificationActions() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Message";

    NotificationAction action1;
    action1.id = "reply";
    action1.label = "Reply";
    action1.remoteInput = true;
    notif.actions.push_back(action1);

    NotificationAction action2;
    action2.id = "delete";
    action2.label = "Delete";
    action2.destructive = true;
    notif.actions.push_back(action2);

    uint64_t id = mgr.post(notif);
    auto retrieved = mgr.getById(id);
    ASSERT_EQ(retrieved.actions.size(), static_cast<size_t>(2));
    ASSERT_EQ(retrieved.actions[0].id, "reply");
    ASSERT_TRUE(retrieved.actions[0].remoteInput);
    ASSERT_TRUE(retrieved.actions[1].destructive);
}

// ============================================================
// Extras tests
// ============================================================

static void testNotificationExtras() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Test";
    notif.extras["key1"] = "value1";
    notif.extras["key2"] = "value2";

    uint64_t id = mgr.post(notif);
    auto retrieved = mgr.getById(id);
    ASSERT_EQ(retrieved.extras.size(), static_cast<size_t>(2));
    ASSERT_EQ(retrieved.extras["key1"], "value1");
    ASSERT_EQ(retrieved.extras["key2"], "value2");
}

// ============================================================
// Edge case tests
// ============================================================

static void testPostNotInitialized() {
    NotificationManager mgr;
    Notification notif;
    notif.appId = "com.app";
    uint64_t id = mgr.post(notif);
    ASSERT_EQ(id, static_cast<uint64_t>(0));
}

static void testCancelNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    bool success = mgr.cancel(99999);
    ASSERT_FALSE(success);
}

static void testDismissNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    bool success = mgr.dismiss(99999);
    ASSERT_FALSE(success);
}

static void testSnoozeNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    bool success = mgr.snooze(99999, 60000);
    ASSERT_FALSE(success);
}

static void testUpdateNotFound() {
    NotificationManager mgr;
    mgr.initialize();
    Notification notif;
    notif.appId = "com.app";
    bool success = mgr.update(99999, notif);
    ASSERT_FALSE(success);
}

static void testCreateChannelInvalidParams() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "";  // Empty
    channel.appId = "com.app";
    auto result = mgr.createChannel(channel);
    ASSERT_EQ(result, NotificationResult::INVALID_PARAMETER);

    channel.id = "test";
    channel.appId = "";  // Empty
    result = mgr.createChannel(channel);
    ASSERT_EQ(result, NotificationResult::INVALID_PARAMETER);
}

static void testCreateGroupInvalidParams() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "";  // Empty
    auto result = mgr.createGroup(group);
    ASSERT_EQ(result, NotificationResult::INVALID_PARAMETER);
}

static void testGetByState() {
    NotificationManager mgr;
    mgr.initialize();

    Notification n1;
    n1.appId = "com.app";
    n1.title = "Active";
    uint64_t id1 = mgr.post(n1);

    Notification n2;
    n2.appId = "com.app";
    n2.title = "Snoozed";
    uint64_t id2 = mgr.post(n2);
    mgr.snooze(id2, 60000);

    auto active = mgr.getByState(NotificationState::ACTIVE);
    ASSERT_EQ(active.size(), static_cast<size_t>(1));

    auto snoozed = mgr.getByState(NotificationState::SNOOZED);
    ASSERT_EQ(snoozed.size(), static_cast<size_t>(1));
}

static void testGetByChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "messages";
    channel.appId = "com.app";
    mgr.createChannel(channel);

    Notification n1;
    n1.appId = "com.app";
    n1.channel = "messages";
    n1.title = "Msg 1";
    mgr.post(n1);

    Notification n2;
    n2.appId = "com.app";
    n2.channel = "alerts";
    n2.title = "Alert 1";
    mgr.post(n2);

    auto msgNotifs = mgr.getByChannel("com.app", "messages");
    ASSERT_EQ(msgNotifs.size(), static_cast<size_t>(1));
}

static void testGetAllChannels() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel ch1;
    ch1.id = "msg";
    ch1.appId = "com.app1";
    mgr.createChannel(ch1);

    NotificationChannel ch2;
    ch2.id = "alerts";
    ch2.appId = "com.app2";
    mgr.createChannel(ch2);

    auto allChannels = mgr.getAllChannels();
    ASSERT_EQ(allChannels.size(), static_cast<size_t>(2));
}

static void testUpdateChannel() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationChannel channel;
    channel.id = "test";
    channel.appId = "com.app";
    channel.name = "Original";
    channel.importance = ChannelImportance::LOW;
    mgr.createChannel(channel);

    NotificationChannel updated;
    updated.name = "Updated";
    updated.importance = ChannelImportance::HIGH;
    auto result = mgr.updateChannel("com.app", "test", updated);
    ASSERT_EQ(result, NotificationResult::SUCCESS);

    auto ch = mgr.getChannel("com.app", "test");
    ASSERT_EQ(ch.name, "Updated");
    ASSERT_EQ(ch.importance, ChannelImportance::HIGH);
}

static void testRemoveFromGroupNotFound() {
    NotificationManager mgr;
    mgr.initialize();

    NotificationGroup group;
    group.key = "test_group";
    group.appId = "com.app";
    mgr.createGroup(group);

    auto result = mgr.removeFromGroup(99999, "test_group");
    ASSERT_EQ(result, NotificationResult::NOT_FOUND);
}

static void testAddToGroupNotFound() {
    NotificationManager mgr;
    mgr.initialize();

    auto result = mgr.addToGroup(99999, "nonexistent_group");
    ASSERT_EQ(result, NotificationResult::NOT_FOUND);
}

static void testOngoingNotification() {
    NotificationManager mgr;
    mgr.initialize();

    Notification notif;
    notif.appId = "com.app";
    notif.title = "Download in progress";
    notif.ongoing = true;
    notif.autoCancel = false;
    uint64_t id = mgr.post(notif);

    auto retrieved = mgr.getById(id);
    ASSERT_TRUE(retrieved.ongoing);
    ASSERT_FALSE(retrieved.autoCancel);
}

int runAllTests() {
    printf("=== Notification Manager Tests ===\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testReinitialization);
    RUN_TEST(testShutdown);
    RUN_TEST(testAppAllowedByDefault);
    RUN_TEST(testBlockApp);
    RUN_TEST(testAllowList);
    RUN_TEST(testBlockedAppNotification);
    RUN_TEST(testCreateChannel);
    RUN_TEST(testDuplicateChannel);
    RUN_TEST(testDeleteChannel);
    RUN_TEST(testDeleteNonExistentChannel);
    RUN_TEST(testGetChannelsForApp);
    RUN_TEST(testEnableDisableChannel);
    RUN_TEST(testDisabledChannelBlocksNotification);
    RUN_TEST(testPostBasic);
    RUN_TEST(testPostMultiple);
    RUN_TEST(testUpdateNotification);
    RUN_TEST(testCancelNotification);
    RUN_TEST(testCancelAllForApp);
    RUN_TEST(testCancelTagged);
    RUN_TEST(testDismissNotification);
    RUN_TEST(testSnoozeAndUnsnooze);
    RUN_TEST(testSnoozeAutoReactivate);
    RUN_TEST(testGetById);
    RUN_TEST(testGetByIdNotFound);
    RUN_TEST(testGetByApp);
    RUN_TEST(testGetByCategory);
    RUN_TEST(testGetByPriority);
    RUN_TEST(testGetRecent);
    RUN_TEST(testGetHistory);
    RUN_TEST(testExpireNotifications);
    RUN_TEST(testOngoingNotExpired);
    RUN_TEST(testExpireByAge);
    RUN_TEST(testCreateGroup);
    RUN_TEST(testAddToGroup);
    RUN_TEST(testRemoveFromGroup);
    RUN_TEST(testGroupNotFound);
    RUN_TEST(testDuplicateGroup);
    RUN_TEST(testDndOff);
    RUN_TEST(testDndTotalSilence);
    RUN_TEST(testDndPriorityOnly);
    RUN_TEST(testDndAlarmsOnly);
    RUN_TEST(testDndSchedule);
    RUN_TEST(testPrivacyShowAll);
    RUN_TEST(testPrivacyHideContent);
    RUN_TEST(testPrivacyRedact);
    RUN_TEST(testPrivacyHideAll);
    RUN_TEST(testRedactText);
    RUN_TEST(testNotificationLevelPrivacy);
    RUN_TEST(testBadgeIncrement);
    RUN_TEST(testBadgeDecrementOnDismiss);
    RUN_TEST(testBadgeExplicit);
    RUN_TEST(testClearBadge);
    RUN_TEST(testGetAllBadges);
    RUN_TEST(testQueueOverflow);
    RUN_TEST(testPostedCallback);
    RUN_TEST(testDismissedCallback);
    RUN_TEST(testCancelledCallback);
    RUN_TEST(testBlockedCallback);
    RUN_TEST(testStats);
    RUN_TEST(testResetStats);
    RUN_TEST(testClearHistory);
    RUN_TEST(testClearAll);
    RUN_TEST(testClearForApp);
    RUN_TEST(testStringHelpers);
    RUN_TEST(testStringToPriority);
    RUN_TEST(testStringToState);
    RUN_TEST(testNotificationActions);
    RUN_TEST(testNotificationExtras);
    RUN_TEST(testPostNotInitialized);
    RUN_TEST(testCancelNotFound);
    RUN_TEST(testDismissNotFound);
    RUN_TEST(testSnoozeNotFound);
    RUN_TEST(testUpdateNotFound);
    RUN_TEST(testCreateChannelInvalidParams);
    RUN_TEST(testCreateGroupInvalidParams);
    RUN_TEST(testGetByState);
    RUN_TEST(testGetByChannel);
    RUN_TEST(testGetAllChannels);
    RUN_TEST(testUpdateChannel);
    RUN_TEST(testRemoveFromGroupNotFound);
    RUN_TEST(testAddToGroupNotFound);
    RUN_TEST(testOngoingNotification);
    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);
    return tests_failed > 0 ? 1 : 0;
}

int main() {
    return runAllTests();
}
