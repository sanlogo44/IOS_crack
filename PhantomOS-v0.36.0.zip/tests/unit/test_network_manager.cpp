/*
 * Phantom OS - Network / Connectivity Manager Tests
 * v0.25.0 - License: GPL-3.0
 *
 * Tests for NetworkManager: lifecycle, radio control, airplane mode,
 * scanning, profiles, connection handling, auth failures, captive portal,
 * limited networks, roaming, metered connections, policies, app access,
 * data usage, privacy (MAC randomization, DNS privacy), NIDS integration,
 * events, stats, callbacks, string helpers, failure simulation
 */

#include "phantom/network/network_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include "phantom/nids/nids_engine.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST(test) do { \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    std::cout << " OK" << std::endl; \
} while(0)

using namespace phantom::network;
using namespace phantom::logging;
using namespace phantom::crashreporter;
using namespace phantom::nids;

// ============================================================
// Lifecycle tests
// ============================================================

static void test_lifecycle() {
    NetworkManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(32, 500, 500, 256), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), NetworkResult::ALREADY_INITIALIZED);
    // Capacity getters
    ASSERT_EQ(mgr.getMaxProfiles(), (size_t)32);
    ASSERT_EQ(mgr.getMaxEvents(), (size_t)500);
    ASSERT_EQ(mgr.getMaxHistory(), (size_t)500);
    ASSERT_EQ(mgr.getMaxApps(), (size_t)256);
    ASSERT_EQ(mgr.shutdown(), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), NetworkResult::NOT_INITIALIZED);
}

static void test_initialize_invalid_params() {
    NetworkManager mgr;
    ASSERT_EQ(mgr.initialize(0), NetworkResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(32, 0), NetworkResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(32, 500, 0), NetworkResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(32, 500, 500, 0), NetworkResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_not_initialized_operations() {
    NetworkManager mgr;
    ASSERT_EQ(mgr.requestScan(NetworkType::WIFI), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.connect(1), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.reconnect(), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setRadioEnabled(NetworkType::WIFI, false), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setAirplaneMode(true, "system"), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.removeProfile(1), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.updateProfile(1), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::BLOCKED, "system"),
              NetworkResult::NOT_INITIALIZED);  // Init check before owner check
    ASSERT_EQ(mgr.updateDataUsage("com.app", 1, 1), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.resetDataUsage(), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearEvents(), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.addProfile("X", "p", NetworkType::WIFI, SecurityType::WPA2), (uint64_t)0);
}

static void test_shutdown_clears_state() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_TRUE(id != 0);
    mgr.requestScan(NetworkType::WIFI);
    ASSERT_TRUE(mgr.connect(id) == NetworkResult::SUCCESS);
    mgr.shutdown();
    ASSERT_EQ(mgr.getProfileCount(), (size_t)0);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::DISCONNECTED);
    ASSERT_FALSE(mgr.isConnected());
    ASSERT_EQ(mgr.getDataUsage().totalBytes, (uint64_t)0);
}

// ============================================================
// Radio control tests
// ============================================================

static void test_radio_enable_disable() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::WIFI));
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::CELLULAR));
    ASSERT_FALSE(mgr.isRadioEnabled(NetworkType::BLUETOOTH_PAN));  // Off by default
    ASSERT_FALSE(mgr.isRadioEnabled(NetworkType::USB_TETHER));     // Off by default
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::LOOPBACK));        // Always on
    ASSERT_EQ(mgr.setRadioEnabled(NetworkType::WIFI, false), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isRadioEnabled(NetworkType::WIFI));
    ASSERT_EQ(mgr.setRadioEnabled(NetworkType::WIFI, true), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::WIFI));
    // Loopback cannot be disabled
    ASSERT_EQ(mgr.setRadioEnabled(NetworkType::LOOPBACK, false), NetworkResult::INVALID_PARAMETER);
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::LOOPBACK));
    // Radio toggle generates event
    ASSERT_FALSE(mgr.getEventsByType(NetworkEventType::RADIO_CHANGED).empty());
}

static void test_airplane_mode() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.isAirplaneMode());
    // Non-system owner denied
    ASSERT_EQ(mgr.setAirplaneMode(true, "com.app.settings"), NetworkResult::PERMISSION_DENIED);
    ASSERT_FALSE(mgr.isAirplaneMode());
    ASSERT_EQ(mgr.setAirplaneMode(true, "system"), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isAirplaneMode());
    // Duplicate request
    ASSERT_EQ(mgr.setAirplaneMode(true, "system"), NetworkResult::BAD_STATE);
    // All radios (except loopback) report disabled
    ASSERT_FALSE(mgr.isRadioEnabled(NetworkType::WIFI));
    ASSERT_FALSE(mgr.isRadioEnabled(NetworkType::CELLULAR));
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::LOOPBACK));
    ASSERT_EQ(mgr.setAirplaneMode(false, "phantos.system"), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isAirplaneMode());
    ASSERT_TRUE(mgr.isRadioEnabled(NetworkType::WIFI));
}

static void test_airplane_mode_teardown() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_EQ(mgr.setAirplaneMode(true, "system"), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isConnected());
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::DISCONNECTED);
    // Connection after airplane on fails
    ASSERT_EQ(mgr.connect(id), NetworkResult::RADIO_DISABLED);
    ASSERT_EQ(mgr.setAirplaneMode(false, "system"), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
}

// ============================================================
// Scanning tests
// ============================================================

static void test_scan_wifi() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.requestScan(NetworkType::WIFI), NetworkResult::SUCCESS);
    std::vector<NetworkInfo> results = mgr.getScanResults(NetworkType::WIFI);
    ASSERT_EQ(results.size(), (size_t)6);
    ASSERT_TRUE(mgr.hasNetwork("PhantomNet", NetworkType::WIFI));
    ASSERT_TRUE(mgr.hasNetwork("HomeNet", NetworkType::WIFI));
    ASSERT_TRUE(mgr.hasNetwork("CoffeeShop_Free", NetworkType::WIFI));
    ASSERT_FALSE(mgr.hasNetwork("DoesNotExist", NetworkType::WIFI));
    // NETWORK_FOUND events for every discovered network
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::NETWORK_FOUND).size(), (size_t)6);
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::SCAN_STARTED).size(), (size_t)1);
    // Signal strength in valid range
    for (const auto& net : results) {
        ASSERT_TRUE(net.signalStrength >= 40 && net.signalStrength <= 100);
    }
    // Empty for other types
    ASSERT_TRUE(mgr.getScanResults(NetworkType::CELLULAR).empty());
}

static void test_scan_signal_and_bssid_deterministic() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.requestScan(NetworkType::WIFI);
    NetworkInfo first = mgr.getScanResults(NetworkType::WIFI)[0];
    mgr.requestScan(NetworkType::WIFI);
    NetworkInfo second = mgr.getScanResults(NetworkType::WIFI)[0];
    ASSERT_EQ(first.signalStrength, second.signalStrength);  // Deterministic
    ASSERT_STREQ(first.bssid.c_str(), second.bssid.c_str());
    ASSERT_EQ(first.bssid.size(), (size_t)17);  // "XX:XX:XX:XX:XX:XX"
    ASSERT_STREQ(first.ssid.c_str(), "PhantomNet");
    ASSERT_EQ(first.security, SecurityType::WPA3);
    ASSERT_EQ(first.frequencyMhz, (uint32_t)5180);
}

static void test_scan_cellular_and_others() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.requestScan(NetworkType::CELLULAR), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getScanResults(NetworkType::CELLULAR).size(), (size_t)2);
    ASSERT_TRUE(mgr.hasNetwork("PhantomTelecom", NetworkType::CELLULAR));
    ASSERT_TRUE(mgr.hasNetwork("RoamNet", NetworkType::CELLULAR));
    // Loopback cannot be scanned
    ASSERT_EQ(mgr.requestScan(NetworkType::LOOPBACK), NetworkResult::INVALID_PARAMETER);
    // Bluetooth PAN off by default
    ASSERT_EQ(mgr.requestScan(NetworkType::BLUETOOTH_PAN), NetworkResult::RADIO_DISABLED);
    mgr.setRadioEnabled(NetworkType::BLUETOOTH_PAN, true);
    ASSERT_EQ(mgr.requestScan(NetworkType::BLUETOOTH_PAN), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getScanResults(NetworkType::BLUETOOTH_PAN).size(), (size_t)1);
    // Stats
    ASSERT_EQ(mgr.getStats().scansRequested, (uint64_t)2);
    ASSERT_EQ(mgr.getStats().networksFound, (uint64_t)3);  // 2 cellular + 1 bluetooth
}

static void test_scan_radio_disabled() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setRadioEnabled(NetworkType::WIFI, false);
    ASSERT_EQ(mgr.requestScan(NetworkType::WIFI), NetworkResult::RADIO_DISABLED);
    mgr.setRadioEnabled(NetworkType::WIFI, true);
    mgr.setAirplaneMode(true, "system");
    ASSERT_EQ(mgr.requestScan(NetworkType::WIFI), NetworkResult::RADIO_DISABLED);
}

static void test_scan_age_filter() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setCurrentTimeForTesting(1000000);
    mgr.requestScan(NetworkType::WIFI);
    ASSERT_EQ(mgr.getScanResults(NetworkType::WIFI, 60000).size(), (size_t)6);
    mgr.setCurrentTimeForTesting(1080000);  // +80s
    ASSERT_EQ(mgr.getScanResults(NetworkType::WIFI, 60000).size(), (size_t)0);
    ASSERT_EQ(mgr.getScanResults(NetworkType::WIFI, 90000).size(), (size_t)6);
    mgr.clearTimeOverride();
}

// ============================================================
// Profile tests
// ============================================================

static void test_profile_add_and_get() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "secret123", NetworkType::WIFI,
                                 SecurityType::WPA2, true, 10, false);
    ASSERT_TRUE(id != 0);
    NetworkProfile p = mgr.getProfile(id);
    ASSERT_EQ(p.id, id);
    ASSERT_STREQ(p.ssid.c_str(), "PhantomNet");
    ASSERT_EQ(p.type, NetworkType::WIFI);
    ASSERT_EQ(p.security, SecurityType::WPA2);
    ASSERT_TRUE(p.autoConnect);
    ASSERT_EQ(p.priority, 10);
    ASSERT_FALSE(p.metered);
    ASSERT_TRUE(p.createdAt > 0);
    // Password never stored in plaintext: hash differs from plaintext-derived salt alone
    ASSERT_TRUE(p.passwordHash != 0);
    ASSERT_TRUE(p.passwordSalt != 0);
    // Not found
    NetworkProfile missing = mgr.getProfile(9999);
    ASSERT_EQ(missing.id, (uint64_t)0);
}

static void test_profile_duplicate_rejected() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id1 = mgr.addProfile("PhantomNet", "a", NetworkType::WIFI, SecurityType::WPA2);
    uint64_t id2 = mgr.addProfile("PhantomNet", "b", NetworkType::WIFI, SecurityType::WPA3);
    ASSERT_TRUE(id1 != 0);
    ASSERT_EQ(id2, (uint64_t)0);  // Same SSID + type rejected
    // Same SSID on different type is fine
    uint64_t id3 = mgr.addProfile("PhantomNet", "c", NetworkType::CELLULAR, SecurityType::OPEN);
    ASSERT_TRUE(id3 != 0);
    // Empty SSID rejected
    ASSERT_EQ(mgr.addProfile("", "x", NetworkType::WIFI, SecurityType::WPA2), (uint64_t)0);
    ASSERT_EQ(mgr.getProfileCount(), (size_t)2);
}

static void test_profile_capacity() {
    NetworkManager mgr;
    mgr.initialize(2);
    ASSERT_TRUE(mgr.addProfile("Net1", "a", NetworkType::WIFI, SecurityType::WPA2) != 0);
    ASSERT_TRUE(mgr.addProfile("Net2", "b", NetworkType::WIFI, SecurityType::WPA2) != 0);
    ASSERT_EQ(mgr.addProfile("Net3", "c", NetworkType::WIFI, SecurityType::WPA2), (uint64_t)0);
    ASSERT_EQ(mgr.getProfileCount(), (size_t)2);
}

static void test_profile_remove() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.removeProfile(9999), NetworkResult::PROFILE_NOT_FOUND);
    ASSERT_EQ(mgr.removeProfile(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getProfileCount(), (size_t)0);
    ASSERT_EQ(mgr.removeProfile(id), NetworkResult::PROFILE_NOT_FOUND);
    ASSERT_EQ(mgr.getStats().profilesRemoved, (uint64_t)1);
}

static void test_profile_remove_active_denied() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.removeProfile(id), NetworkResult::BAD_STATE);  // Active profile protected
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.removeProfile(id), NetworkResult::SUCCESS);
}

static void test_profile_update() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "old", NetworkType::WIFI,
                                 SecurityType::WPA2, false, 1, false);
    ASSERT_EQ(mgr.updateProfile(9999, "new"), NetworkResult::PROFILE_NOT_FOUND);
    ASSERT_EQ(mgr.updateProfile(id, "newpw", 5, true, true), NetworkResult::SUCCESS);
    NetworkProfile p = mgr.getProfile(id);
    ASSERT_EQ(p.priority, 5);
    ASSERT_TRUE(p.autoConnect);
    ASSERT_TRUE(p.metered);
    // Old password no longer valid
    ASSERT_EQ(mgr.connect(id, "", "old"), NetworkResult::AUTH_FAILED);
    // New password works
    ASSERT_EQ(mgr.connect(id, "", "newpw"), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    // Password unchanged when empty arg; priority -1 keeps old
    ASSERT_EQ(mgr.updateProfile(id, "", -1, false, false), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getProfile(id).priority, 5);
}

static void test_profile_by_ssid_and_list() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id1 = mgr.addProfile("NetA", "a", NetworkType::WIFI, SecurityType::WPA2);
    uint64_t id2 = mgr.addProfile("NetB", "b", NetworkType::WIFI, SecurityType::WPA2);
    uint64_t id3 = mgr.addProfile("NetC", "c", NetworkType::CELLULAR, SecurityType::OPEN);
    ASSERT_EQ(mgr.getProfileBySsid("NetA", NetworkType::WIFI), id1);
    ASSERT_EQ(mgr.getProfileBySsid("NetB", NetworkType::WIFI), id2);
    ASSERT_EQ(mgr.getProfileBySsid("NetC", NetworkType::CELLULAR), id3);
    ASSERT_EQ(mgr.getProfileBySsid("NetC", NetworkType::WIFI), (uint64_t)0);
    ASSERT_EQ(mgr.getProfileBySsid("Nope", NetworkType::WIFI), (uint64_t)0);
    ASSERT_EQ(mgr.getSavedProfiles().size(), (size_t)3);
    ASSERT_EQ(mgr.getStats().profilesSaved, (uint64_t)3);
}

// ============================================================
// Connection tests
// ============================================================

static void test_connect_success() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw123", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::CONNECTED);
    ConnectionInfo conn = mgr.getActiveConnection();
    ASSERT_STREQ(conn.ssid.c_str(), "PhantomNet");
    ASSERT_EQ(conn.type, NetworkType::WIFI);
    ASSERT_EQ(conn.profileId, id);
    ASSERT_FALSE(conn.metered);
    ASSERT_FALSE(conn.captivePortal);
    // Simulated network properties are populated
    ASSERT_TRUE(!conn.ipAddress.empty());
    ASSERT_TRUE(!conn.gateway.empty());
    ASSERT_TRUE(!conn.dnsPrimary.empty());
    ASSERT_TRUE(!conn.macAddress.empty());
    ASSERT_EQ(conn.macAddress.size(), (size_t)17);
    ASSERT_TRUE(conn.connectedAt > 0);
    ASSERT_TRUE(conn.signalStrength >= 40 && conn.signalStrength <= 100);
}

static void test_connect_already_connected() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.connect(id), NetworkResult::ALREADY_CONNECTED);
    uint64_t id2 = mgr.addProfile("HomeNet", "pw2", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id2), NetworkResult::ALREADY_CONNECTED);
    ASSERT_TRUE(mgr.isConnected());
}

static void test_connect_not_found() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.connect(9999), NetworkResult::PROFILE_NOT_FOUND);
    ASSERT_EQ(mgr.getStats().connectAttempts, (uint64_t)1);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(NetworkResult::PROFILE_NOT_FOUND)],
              (uint64_t)1);
}

static void test_connect_radio_disabled() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    mgr.setRadioEnabled(NetworkType::WIFI, false);
    ASSERT_EQ(mgr.connect(id), NetworkResult::RADIO_DISABLED);
    ASSERT_FALSE(mgr.isConnected());
    mgr.setRadioEnabled(NetworkType::WIFI, true);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
}

static void test_connect_auth_failure() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "right", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id, "", "wrong"), NetworkResult::AUTH_FAILED);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::FAILED);
    ASSERT_FALSE(mgr.isConnected());
    ASSERT_EQ(mgr.getStats().authFailures, (uint64_t)1);
    // Correct password connects
    ASSERT_EQ(mgr.connect(id, "", "right"), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::CONNECTED);
    // AUTH_FAILED result tracked
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(NetworkResult::AUTH_FAILED)],
              (uint64_t)1);
}

static void test_connect_open_network_no_password() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("HomeNet", "", NetworkType::WIFI, SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_STREQ(mgr.getActiveConnection().ssid.c_str(), "HomeNet");
}

static void test_disconnect() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // Disconnect without connection
    ASSERT_EQ(mgr.disconnect(), NetworkResult::NOT_CONNECTED);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isConnected());
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::DISCONNECTED);
    ASSERT_TRUE(mgr.getActiveConnection().ssid.empty());
    ASSERT_EQ(mgr.disconnect(), NetworkResult::NOT_CONNECTED);
    // DISCONNECTED event recorded
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::DISCONNECTED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().disconnects, (uint64_t)1);
}

static void test_reconnect() {
    NetworkManager mgr;
    mgr.initialize();
    // No connection history yet
    ASSERT_EQ(mgr.reconnect(), NetworkResult::NOT_CONNECTED);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id, "com.app"), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.reconnect(), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_STREQ(mgr.getActiveConnection().ssid.c_str(), "PhantomNet");
    ASSERT_EQ(mgr.getStats().reconnects, (uint64_t)1);
    // Reconnect while connected: implicit disconnect + connect
    ASSERT_EQ(mgr.reconnect(), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_EQ(mgr.getStats().reconnects, (uint64_t)2);
}

static void test_failure_simulation() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_FALSE(mgr.getFailNextConnection());
    mgr.setFailNextConnection(true);
    ASSERT_TRUE(mgr.getFailNextConnection());
    ASSERT_EQ(mgr.connect(id), NetworkResult::CONNECTION_FAILED);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::FAILED);
    ASSERT_FALSE(mgr.isConnected());
    // One-shot: next attempt succeeds
    ASSERT_FALSE(mgr.getFailNextConnection());
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().failedConnections, (uint64_t)1);
    ASSERT_EQ(mgr.getStats().successfulConnections, (uint64_t)1);
    ASSERT_EQ(mgr.getStats().totalFailures, (uint64_t)1);
}

// ============================================================
// Captive portal / limited / roaming tests
// ============================================================

static void test_captive_portal() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("CoffeeShop_Free", "", NetworkType::WIFI, SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::CAPTIVE_PORTAL);
    ASSERT_TRUE(mgr.isConnected());  // Still connected at link level
    ConnectionInfo conn = mgr.getActiveConnection();
    ASSERT_TRUE(conn.captivePortal);
    // Portal detected event
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::CAPTIVE_PORTAL_DETECTED).size(), (size_t)1);
    // Connectivity check reports portal sign-in required
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::AUTH_FAILED);
    ASSERT_EQ(mgr.getStats().captivePortals, (uint64_t)1);
}

static void test_limited_network() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("DeadEnd_NoInet", "", NetworkType::WIFI, SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::LIMITED);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::CONNECTION_FAILED);
}

static void test_roaming() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setRadioEnabled(NetworkType::CELLULAR, true);
    uint64_t id = mgr.addProfile("RoamNet", "", NetworkType::CELLULAR, SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::ROAMING);
    ASSERT_TRUE(mgr.getActiveConnection().roaming);
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::SUCCESS);
}

static void test_check_connectivity_states() {
    NetworkManager mgr;
    mgr.initialize();
    // Not connected
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::BAD_STATE);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::SUCCESS);
}

// ============================================================
// Metered / data usage tests
// ============================================================

static void test_cellular_metered_by_default() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setRadioEnabled(NetworkType::CELLULAR, true);
    uint64_t id = mgr.addProfile("PhantomTelecom", "", NetworkType::CELLULAR,
                                 SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isMeteredConnection());
    ASSERT_TRUE(mgr.getActiveConnection().metered);
    // Default Wi-Fi unmetered
    mgr.disconnect();
    uint64_t wifi = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(wifi), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isMeteredConnection());
}

static void test_profile_marked_metered() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI,
                                 SecurityType::WPA2, false, 0, true);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isMeteredConnection());
}

static void test_data_usage() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // No connection: rejected
    ASSERT_EQ(mgr.updateDataUsage("com.app", 100, 50), NetworkResult::NOT_CONNECTED);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.updateDataUsage("com.app", 100, 50), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.updateDataUsage("com.app", 30, 20), NetworkResult::SUCCESS);
    DataUsage usage = mgr.getDataUsage();
    ASSERT_EQ(usage.bytesRx, (uint64_t)130);
    ASSERT_EQ(usage.bytesTx, (uint64_t)70);
    ASSERT_EQ(usage.totalBytes, (uint64_t)200);
    ASSERT_EQ(usage.meteredBytes, (uint64_t)0);  // Unmetered Wi-Fi
    // Reset
    ASSERT_EQ(mgr.resetDataUsage(), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getDataUsage().totalBytes, (uint64_t)0);
}

static void test_data_usage_metered() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setRadioEnabled(NetworkType::CELLULAR, true);
    uint64_t id = mgr.addProfile("PhantomTelecom", "", NetworkType::CELLULAR,
                                 SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    // Metered default-deny: app needs explicit metered permission
    ASSERT_EQ(mgr.updateDataUsage("com.app", 500, 100), NetworkResult::PERMISSION_DENIED);
    mgr.setAppNetworkAccess("com.app", true, true);
    ASSERT_EQ(mgr.updateDataUsage("com.app", 500, 100), NetworkResult::SUCCESS);
    DataUsage usage = mgr.getDataUsage();
    ASSERT_EQ(usage.meteredBytes, (uint64_t)600);
    ASSERT_EQ(mgr.getStats().meteredBytes, (uint64_t)600);
}

static void test_app_blocked() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // Default: app allowed
    ASSERT_TRUE(mgr.isAppAllowed("com.app", false));
    ASSERT_EQ(mgr.connect(id, "com.app"), NetworkResult::SUCCESS);
    mgr.disconnect();
    // Block the app
    ASSERT_EQ(mgr.setAppNetworkAccess("com.app", false), NetworkResult::SUCCESS);
    AppNetworkAccess access = mgr.getAppNetworkAccess("com.app");
    ASSERT_FALSE(access.allowed);
    ASSERT_FALSE(access.allowMetered);
    ASSERT_FALSE(mgr.isAppAllowed("com.app", false));
    ASSERT_EQ(mgr.connect(id, "com.app"), NetworkResult::PERMISSION_DENIED);
    ASSERT_FALSE(mgr.isConnected());
    // APP_ACCESS_BLOCKED event
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::APP_ACCESS_BLOCKED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().appsBlocked, (uint64_t)1);
    // Re-allow
    ASSERT_EQ(mgr.setAppNetworkAccess("com.app", true), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.connect(id, "com.app"), NetworkResult::SUCCESS);
}

static void test_app_metered_default_deny() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.setRadioEnabled(NetworkType::CELLULAR, true);
    uint64_t id = mgr.addProfile("PhantomTelecom", "", NetworkType::CELLULAR,
                                 SecurityType::OPEN);
    // Default: apps are denied on metered networks (privacy default)
    ASSERT_FALSE(mgr.isAppAllowed("com.game", true));
    ASSERT_EQ(mgr.connect(id, "com.game"), NetworkResult::PERMISSION_DENIED);
    // Grant metered access
    ASSERT_EQ(mgr.setAppNetworkAccess("com.game", true, true), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isAppAllowed("com.game", true));
    ASSERT_EQ(mgr.connect(id, "com.game"), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    // Data usage from blocked-on-metered app rejected
    ASSERT_EQ(mgr.setAppNetworkAccess("com.other", true, false), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.updateDataUsage("com.other", 10, 10), NetworkResult::PERMISSION_DENIED);
}

static void test_app_access_capacity() {
    NetworkManager mgr;
    mgr.initialize(32, 500, 500, 2);
    ASSERT_EQ(mgr.setAppNetworkAccess("app1", true), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.setAppNetworkAccess("app2", true), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.setAppNetworkAccess("app3", true), NetworkResult::CAPACITY_EXCEEDED);
    // Updating existing entries is fine
    ASSERT_EQ(mgr.setAppNetworkAccess("app1", false), NetworkResult::SUCCESS);
    // Invalid parameter
    ASSERT_EQ(mgr.setAppNetworkAccess("", true), NetworkResult::INVALID_PARAMETER);
}

static void test_app_access_defaults() {
    NetworkManager mgr;
    mgr.initialize();
    AppNetworkAccess def = mgr.getAppNetworkAccess("unknown.app");
    ASSERT_STREQ(def.appId.c_str(), "unknown.app");
    ASSERT_TRUE(def.allowed);
    ASSERT_FALSE(def.allowMetered);
    // Empty appId (system-level access) permitted on unmetered networks
    ASSERT_TRUE(mgr.isAppAllowed("", false));
    // System owner is not subject to app restrictions in connect()
    ASSERT_EQ(mgr.getProfileCount(), (size_t)0);
}

// ============================================================
// Policy tests
// ============================================================

static void test_network_policy() {
    NetworkManager mgr;
    mgr.initialize();
    // Default policies
    ASSERT_EQ(mgr.getNetworkPolicy(NetworkType::WIFI), NetworkPolicy::NORMAL);
    ASSERT_EQ(mgr.getNetworkPolicy(NetworkType::CELLULAR), NetworkPolicy::METERED);
    // Non-system owner denied
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::BLOCKED, "com.app"),
              NetworkResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::BLOCKED, "phantos.system"),
              NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getNetworkPolicy(NetworkType::WIFI), NetworkPolicy::BLOCKED);
    // Policy change event
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::POLICY_CHANGED).size(), (size_t)1);
    // Blocked type prevents connection
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::PERMISSION_DENIED);
    // Un-block
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::NORMAL, "system"),
              NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
}

static void test_policy_data_saver() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::DATA_SAVER, "system"),
              NetworkResult::SUCCESS);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // DATA_SAVER counts as metered: default app denied
    ASSERT_EQ(mgr.connect(id, "com.game"), NetworkResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);  // No app: allowed
    ASSERT_TRUE(mgr.isMeteredConnection());
}

static void test_policy_privacy() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setNetworkPolicy(NetworkType::WIFI, NetworkPolicy::PRIVACY, "system"),
              NetworkResult::SUCCESS);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    // PRIVACY policy enables DNS privacy on this connection
    ASSERT_TRUE(mgr.getActiveConnection().dnsPrivacy);
}

// ============================================================
// Privacy tests
// ============================================================

static void test_mac_randomization() {
    NetworkManager mgr;
    mgr.initialize();
    // Default: enabled (privacy default)
    ASSERT_TRUE(mgr.isMacRandomizationEnabled());
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    std::string mac1 = mgr.getCurrentMacAddress();
    ASSERT_EQ(mac1.size(), (size_t)17);
    // Locally administered unicast MAC prefix
    ASSERT_TRUE(mac1.rfind("02:", 0) == 0);
    // New connection: different randomized MAC
    mgr.disconnect();
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    std::string mac2 = mgr.getCurrentMacAddress();
    ASSERT_TRUE(mac1 != mac2);
    // Disabling randomization exposes fixed device MAC
    mgr.disconnect();
    mgr.setMacRandomizationEnabled(false);
    ASSERT_FALSE(mgr.isMacRandomizationEnabled());
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    std::string mac3 = mgr.getCurrentMacAddress();
    ASSERT_EQ(mac3.size(), (size_t)17);
    ASSERT_TRUE(mac1 != mac3);
    ASSERT_TRUE(mac2 != mac3);
    mgr.setMacRandomizationEnabled(true);
}

static void test_dns_privacy() {
    NetworkManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.isDnsPrivacyEnabled());
    mgr.setDnsPrivacyEnabled(true);
    ASSERT_TRUE(mgr.isDnsPrivacyEnabled());
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.getActiveConnection().dnsPrivacy);
    mgr.setDnsPrivacyEnabled(false);
}

// ============================================================
// NIDS integration tests
// ============================================================

static void test_nids_connection_registration() {
    NetworkManager mgr;
    mgr.initialize();
    NidsEngine nids;
    nids.initialize();
    mgr.setNidsEngine(&nids);
    ASSERT_EQ(mgr.getNidsEngine(), &nids);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    // Connection registered with NIDS
    ASSERT_EQ(nids.getActiveConnectionCount(), (size_t)1);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    ASSERT_EQ(nids.getActiveConnectionCount(), (size_t)0);
    ASSERT_EQ(nids.getTotalConnectionCount(), (size_t)1);
    nids.shutdown();
}

static void test_nids_firewall_block() {
    NetworkManager mgr;
    mgr.initialize();
    NidsEngine nids;
    nids.initialize();
    mgr.setNidsEngine(&nids);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // First connect: learn the gateway
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    std::string gateway = mgr.getActiveConnection().gateway;
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    // Block the gateway
    uint32_t ruleId = nids.blockIp(gateway, "0-65535", "block gateway");
    ASSERT_TRUE(ruleId != 0);
    // Connection attempt now fails via firewall
    ASSERT_EQ(mgr.connect(id), NetworkResult::CONNECTION_FAILED);
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::FIREWALL_BLOCKED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().firewallBlocks, (uint64_t)1);
    // Unblocking allows connection again
    ASSERT_TRUE(nids.unblockIp(ruleId));
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    nids.shutdown();
}

static void test_nids_optional() {
    NetworkManager mgr;
    mgr.initialize();
    // Works fine without a NIDS engine attached
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
}

// ============================================================
// Event tests
// ============================================================

static void test_events() {
    NetworkManager mgr;
    mgr.initialize(32, 10, 500, 256);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    mgr.requestScan(NetworkType::WIFI);
    mgr.connect(id);
    mgr.disconnect();
    std::vector<NetworkEvent> events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 8);  // 6x NETWORK_FOUND + SCAN + CONNECTED + DISCONNECTED
    // Event IDs strictly increasing
    for (size_t i = 1; i < events.size(); i++) {
        ASSERT_TRUE(events[i].id > events[i - 1].id);
    }
    // Timestamps populated
    ASSERT_TRUE(events[0].timestamp > 0);
    // Limit
    ASSERT_EQ(mgr.getEvents(3).size(), (size_t)3);
    // Types populated
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::CONNECTED).size(), (size_t)1);
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::DISCONNECTED).size(), (size_t)1);
    // Clear
    ASSERT_EQ(mgr.clearEvents(), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_EQ(mgr.getEventsByType(NetworkEventType::CONNECTED).size(), (size_t)0);
}

static void test_event_capacity() {
    NetworkManager mgr;
    mgr.initialize(32, 10, 500, 256);
    for (int i = 0; i < 5; i++) {
        mgr.requestScan(NetworkType::WIFI);  // 7 events each
    }
    // Ring buffer capped at maxEvents
    ASSERT_EQ(mgr.getEvents().size(), (size_t)10);
    // Oldest events dropped: latest scan's marker kept
    ASSERT_TRUE(mgr.getEventsByType(NetworkEventType::SCAN_STARTED).size() >= (size_t)1);
    ASSERT_TRUE(mgr.getEventsByType(NetworkEventType::SCAN_STARTED).size() <= (size_t)5);
}

static void test_event_fields() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id, "com.app"), NetworkResult::SUCCESS);
    std::vector<NetworkEvent> events = mgr.getEventsByType(NetworkEventType::CONNECTED);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_STREQ(events[0].ssid.c_str(), "PhantomNet");
    ASSERT_STREQ(events[0].appId.c_str(), "com.app");
    ASSERT_EQ(events[0].result, NetworkResult::SUCCESS);
    ASSERT_TRUE(!events[0].detail.empty());
}

// ============================================================
// Stats tests
// ============================================================

static void test_stats() {
    NetworkManager mgr;
    mgr.initialize();
    mgr.requestScan(NetworkType::WIFI);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    mgr.connect(id);
    mgr.updateDataUsage("com.app", 100, 100);
    mgr.disconnect();
    NetworkManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.scansRequested, (uint64_t)1);
    ASSERT_EQ(stats.networksFound, (uint64_t)6);
    ASSERT_EQ(stats.connectAttempts, (uint64_t)1);
    ASSERT_EQ(stats.successfulConnections, (uint64_t)1);
    ASSERT_EQ(stats.disconnects, (uint64_t)1);
    ASSERT_EQ(stats.bytesRx, (uint64_t)100);
    ASSERT_EQ(stats.bytesTx, (uint64_t)100);
    ASSERT_EQ(stats.byNetworkType[static_cast<size_t>(NetworkType::WIFI)], (uint64_t)1);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(NetworkEventType::NETWORK_FOUND)],
              (uint64_t)6);
    // Reset
    mgr.resetStats();
    stats = mgr.getStats();
    ASSERT_EQ(stats.scansRequested, (uint64_t)0);
    ASSERT_EQ(stats.connectAttempts, (uint64_t)0);
    ASSERT_EQ(stats.byNetworkType[static_cast<size_t>(NetworkType::WIFI)], (uint64_t)0);
    // Stats survive but events cleared separately
    ASSERT_FALSE(mgr.getEvents().empty());
}

static void test_stats_auth_failures() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    mgr.connect(id, "", "wrong");
    mgr.connect(id, "", "wrong");
    NetworkManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.authFailures, (uint64_t)2);
    ASSERT_EQ(stats.failedConnections, (uint64_t)2);
    ASSERT_EQ(stats.connectAttempts, (uint64_t)2);
    ASSERT_EQ(stats.totalFailures, (uint64_t)2);
}

static void test_profile_connect_count() {
    NetworkManager mgr;
    mgr.initialize();
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.getProfile(id).connectCount, (uint32_t)0);
    mgr.connect(id);
    mgr.disconnect();
    mgr.connect(id);
    ASSERT_EQ(mgr.getProfile(id).connectCount, (uint32_t)2);
    ASSERT_TRUE(mgr.getProfile(id).lastConnectedAt >= mgr.getProfile(id).createdAt);
}

// ============================================================
// Callback tests
// ============================================================

static void test_connection_state_callback() {
    NetworkManager mgr;
    mgr.initialize();
    int calls = 0;
    NetworkState lastOld = NetworkState::DISCONNECTED;
    NetworkState lastNew = NetworkState::DISCONNECTED;
    mgr.setConnectionStateCallback([&](NetworkState oldState, NetworkState newState) {
        calls++;
        lastOld = oldState;
        lastNew = newState;
    });
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    // DISCONNECTED -> CONNECTING -> CONNECTED
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(lastOld, NetworkState::CONNECTING);
    ASSERT_EQ(lastNew, NetworkState::CONNECTED);
    // Disconnect fires another transition
    mgr.disconnect();
    ASSERT_EQ(calls, 3);
    ASSERT_EQ(lastOld, NetworkState::CONNECTED);
    ASSERT_EQ(lastNew, NetworkState::DISCONNECTED);
}

static void test_network_event_callback() {
    NetworkManager mgr;
    mgr.initialize();
    int calls = 0;
    NetworkEventType lastType = NetworkEventType::SCAN_STARTED;
    std::string lastSsid;
    mgr.setNetworkEventCallback([&](const NetworkEvent& event) {
        calls++;
        lastType = event.type;
        lastSsid = event.ssid;
    });
    mgr.requestScan(NetworkType::WIFI);
    // 6x NETWORK_FOUND + 1x SCAN_STARTED
    ASSERT_EQ(calls, 7);
    ASSERT_EQ(lastType, NetworkEventType::SCAN_STARTED);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    mgr.connect(id);
    // + CONNECTED
    ASSERT_EQ(calls, 8);
    ASSERT_EQ(lastType, NetworkEventType::CONNECTED);
    ASSERT_STREQ(lastSsid.c_str(), "PhantomNet");
}

// ============================================================
// String helper tests
// ============================================================

static void test_string_helpers_network_type() {
    ASSERT_STREQ(NetworkManager::networkTypeToString(NetworkType::WIFI), "WIFI");
    ASSERT_STREQ(NetworkManager::networkTypeToString(NetworkType::CELLULAR), "CELLULAR");
    ASSERT_STREQ(NetworkManager::networkTypeToString(NetworkType::BLUETOOTH_PAN), "BLUETOOTH_PAN");
    ASSERT_STREQ(NetworkManager::networkTypeToString(NetworkType::USB_TETHER), "USB_TETHER");
    ASSERT_STREQ(NetworkManager::networkTypeToString(NetworkType::LOOPBACK), "LOOPBACK");
    // Parser
    ASSERT_EQ(NetworkManager::stringToNetworkType("WIFI"), NetworkType::WIFI);
    ASSERT_EQ(NetworkManager::stringToNetworkType("CELLULAR"), NetworkType::CELLULAR);
    ASSERT_EQ(NetworkManager::stringToNetworkType("BLUETOOTH_PAN"), NetworkType::BLUETOOTH_PAN);
    ASSERT_EQ(NetworkManager::stringToNetworkType("USB_TETHER"), NetworkType::USB_TETHER);
    ASSERT_EQ(NetworkManager::stringToNetworkType("LOOPBACK"), NetworkType::LOOPBACK);
    ASSERT_EQ(NetworkManager::stringToNetworkType("bogus"), NetworkType::WIFI);  // Default
}

static void test_string_helpers_network_state() {
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::DISABLED), "DISABLED");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::DISCONNECTED), "DISCONNECTED");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::SCANNING), "SCANNING");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::CONNECTING), "CONNECTING");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::CONNECTED), "CONNECTED");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::CAPTIVE_PORTAL), "CAPTIVE_PORTAL");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::LIMITED), "LIMITED");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::ROAMING), "ROAMING");
    ASSERT_STREQ(NetworkManager::networkStateToString(NetworkState::FAILED), "FAILED");
    // Parser
    ASSERT_EQ(NetworkManager::stringToNetworkState("CONNECTED"), NetworkState::CONNECTED);
    ASSERT_EQ(NetworkManager::stringToNetworkState("ROAMING"), NetworkState::ROAMING);
    ASSERT_EQ(NetworkManager::stringToNetworkState("CAPTIVE_PORTAL"), NetworkState::CAPTIVE_PORTAL);
    ASSERT_EQ(NetworkManager::stringToNetworkState("bogus"), NetworkState::DISCONNECTED);
}

static void test_string_helpers_security_and_policy() {
    ASSERT_STREQ(NetworkManager::securityTypeToString(SecurityType::OPEN), "OPEN");
    ASSERT_STREQ(NetworkManager::securityTypeToString(SecurityType::WPA2), "WPA2");
    ASSERT_STREQ(NetworkManager::securityTypeToString(SecurityType::WPA3), "WPA3");
    ASSERT_STREQ(NetworkManager::securityTypeToString(SecurityType::ENTERPRISE_STUB), "ENTERPRISE_STUB");
    ASSERT_STREQ(NetworkManager::networkPolicyToString(NetworkPolicy::NORMAL), "NORMAL");
    ASSERT_STREQ(NetworkManager::networkPolicyToString(NetworkPolicy::METERED), "METERED");
    ASSERT_STREQ(NetworkManager::networkPolicyToString(NetworkPolicy::DATA_SAVER), "DATA_SAVER");
    ASSERT_STREQ(NetworkManager::networkPolicyToString(NetworkPolicy::PRIVACY), "PRIVACY");
    ASSERT_STREQ(NetworkManager::networkPolicyToString(NetworkPolicy::BLOCKED), "BLOCKED");
}

static void test_string_helpers_result_and_event() {
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::ALREADY_INITIALIZED), "ALREADY_INITIALIZED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::INVALID_PARAMETER), "INVALID_PARAMETER");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::PROFILE_NOT_FOUND), "PROFILE_NOT_FOUND");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::NETWORK_NOT_FOUND), "NETWORK_NOT_FOUND");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::PROFILE_EXISTS), "PROFILE_EXISTS");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::CAPACITY_EXCEEDED), "CAPACITY_EXCEEDED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::ALREADY_CONNECTED), "ALREADY_CONNECTED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::NOT_CONNECTED), "NOT_CONNECTED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::CONNECTION_FAILED), "CONNECTION_FAILED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::AUTH_FAILED), "AUTH_FAILED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::RADIO_DISABLED), "RADIO_DISABLED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::BAD_STATE), "BAD_STATE");
    ASSERT_STREQ(NetworkManager::networkResultToString(NetworkResult::OPERATION_FAILED), "OPERATION_FAILED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::SCAN_STARTED), "SCAN_STARTED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::NETWORK_FOUND), "NETWORK_FOUND");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::CONNECTED), "CONNECTED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::DISCONNECTED), "DISCONNECTED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::POLICY_CHANGED), "POLICY_CHANGED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::APP_ACCESS_BLOCKED), "APP_ACCESS_BLOCKED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::CAPTIVE_PORTAL_DETECTED), "CAPTIVE_PORTAL_DETECTED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::FIREWALL_BLOCKED), "FIREWALL_BLOCKED");
    ASSERT_STREQ(NetworkManager::networkEventTypeToString(NetworkEventType::RADIO_CHANGED), "RADIO_CHANGED");
    // Result parser
    ASSERT_EQ(NetworkManager::stringToNetworkResult("SUCCESS"), NetworkResult::SUCCESS);
    ASSERT_EQ(NetworkManager::stringToNetworkResult("AUTH_FAILED"), NetworkResult::AUTH_FAILED);
    ASSERT_EQ(NetworkManager::stringToNetworkResult("PERMISSION_DENIED"), NetworkResult::PERMISSION_DENIED);
    ASSERT_EQ(NetworkManager::stringToNetworkResult("bogus"), NetworkResult::SUCCESS);  // Default
}

// ============================================================
// Integration tests
// ============================================================

static void test_log_server_integration() {
    NetworkManager mgr;
    LogServer logs;
    logs.initialize(100);
    mgr.initialize();
    mgr.setLogServer(&logs);
    ASSERT_EQ(mgr.getLogServer(), &logs);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    ASSERT_EQ(mgr.connect(id), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    // Connection activity was logged
    ASSERT_TRUE(logs.getLogCount() >= 2);
    logs.shutdown();
}

static void test_crash_reporter_integration() {
    NetworkManager mgr;
    CrashReporter reporter;
    reporter.initialize(100);
    mgr.initialize();
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    uint64_t id = mgr.addProfile("PhantomNet", "pw", NetworkType::WIFI, SecurityType::WPA2);
    // Auth failure triggers ANR capture
    ASSERT_EQ(mgr.connect(id, "com.app", "wrong"), NetworkResult::AUTH_FAILED);
    ASSERT_TRUE(reporter.getRecent(10).size() >= 1);
    reporter.shutdown();
}

// ============================================================
// Full workflow test
// ============================================================

static void test_full_workflow() {
    NetworkManager mgr;
    LogServer logs;
    logs.initialize(200);
    NidsEngine nids;
    nids.initialize();
    mgr.initialize(16, 100, 100, 32);
    mgr.setLogServer(&logs);
    mgr.setNidsEngine(&nids);

    // 1. Scan for networks
    ASSERT_EQ(mgr.requestScan(NetworkType::WIFI), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.hasNetwork("PhantomNet", NetworkType::WIFI));

    // 2. Save a profile
    uint64_t id = mgr.addProfile("PhantomNet", "hunter2", NetworkType::WIFI,
                                 SecurityType::WPA3, true, 5, false);
    ASSERT_TRUE(id != 0);

    // 3. Block an unrelated app
    ASSERT_EQ(mgr.setAppNetworkAccess("com.tracker", false), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.connect(id, "com.tracker"), NetworkResult::PERMISSION_DENIED);

    // 4. Connect as system
    ASSERT_EQ(mgr.connect(id, "system"), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());
    ASSERT_EQ(nids.getActiveConnectionCount(), (size_t)1);

    // 5. Data flows
    ASSERT_EQ(mgr.updateDataUsage("system", 1024, 512), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getDataUsage().totalBytes, (uint64_t)1536);

    // 6. Connectivity check
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::SUCCESS);

    // 7. Wrong-password reconnect fails, correct one works
    ASSERT_EQ(mgr.disconnect(), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.reconnect(), NetworkResult::SUCCESS);
    ASSERT_TRUE(mgr.isConnected());

    // 8. Airplane mode teardown
    ASSERT_EQ(mgr.setAirplaneMode(true, "system"), NetworkResult::SUCCESS);
    ASSERT_FALSE(mgr.isConnected());
    ASSERT_EQ(mgr.setAirplaneMode(false, "system"), NetworkResult::SUCCESS);

    // 9. Captive portal detection on another network
    uint64_t portal = mgr.addProfile("CoffeeShop_Free", "", NetworkType::WIFI, SecurityType::OPEN);
    ASSERT_EQ(mgr.connect(portal), NetworkResult::SUCCESS);
    ASSERT_EQ(mgr.getConnectionState(), NetworkState::CAPTIVE_PORTAL);
    ASSERT_EQ(mgr.checkConnectivity(), NetworkResult::AUTH_FAILED);

    // 10. Final stats
    NetworkManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.scansRequested, (uint64_t)1);
    ASSERT_TRUE(stats.connectAttempts >= 4);
    ASSERT_TRUE(stats.successfulConnections >= 3);
    ASSERT_EQ(stats.appsBlocked, (uint64_t)1);
    ASSERT_EQ(stats.captivePortals, (uint64_t)1);
    ASSERT_EQ(stats.disconnects, (uint64_t)2);

    mgr.shutdown();
    nids.shutdown();
    logs.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Phantom OS Network Manager Tests (v0.25.0) ===" << std::endl;

    RUN_TEST(test_lifecycle);
    RUN_TEST(test_initialize_invalid_params);
    RUN_TEST(test_not_initialized_operations);
    RUN_TEST(test_shutdown_clears_state);
    RUN_TEST(test_radio_enable_disable);
    RUN_TEST(test_airplane_mode);
    RUN_TEST(test_airplane_mode_teardown);
    RUN_TEST(test_scan_wifi);
    RUN_TEST(test_scan_signal_and_bssid_deterministic);
    RUN_TEST(test_scan_cellular_and_others);
    RUN_TEST(test_scan_radio_disabled);
    RUN_TEST(test_scan_age_filter);
    RUN_TEST(test_profile_add_and_get);
    RUN_TEST(test_profile_duplicate_rejected);
    RUN_TEST(test_profile_capacity);
    RUN_TEST(test_profile_remove);
    RUN_TEST(test_profile_remove_active_denied);
    RUN_TEST(test_profile_update);
    RUN_TEST(test_profile_by_ssid_and_list);
    RUN_TEST(test_connect_success);
    RUN_TEST(test_connect_already_connected);
    RUN_TEST(test_connect_not_found);
    RUN_TEST(test_connect_radio_disabled);
    RUN_TEST(test_connect_auth_failure);
    RUN_TEST(test_connect_open_network_no_password);
    RUN_TEST(test_disconnect);
    RUN_TEST(test_reconnect);
    RUN_TEST(test_failure_simulation);
    RUN_TEST(test_captive_portal);
    RUN_TEST(test_limited_network);
    RUN_TEST(test_roaming);
    RUN_TEST(test_check_connectivity_states);
    RUN_TEST(test_cellular_metered_by_default);
    RUN_TEST(test_profile_marked_metered);
    RUN_TEST(test_data_usage);
    RUN_TEST(test_data_usage_metered);
    RUN_TEST(test_app_blocked);
    RUN_TEST(test_app_metered_default_deny);
    RUN_TEST(test_app_access_capacity);
    RUN_TEST(test_app_access_defaults);
    RUN_TEST(test_network_policy);
    RUN_TEST(test_policy_data_saver);
    RUN_TEST(test_policy_privacy);
    RUN_TEST(test_mac_randomization);
    RUN_TEST(test_dns_privacy);
    RUN_TEST(test_nids_connection_registration);
    RUN_TEST(test_nids_firewall_block);
    RUN_TEST(test_nids_optional);
    RUN_TEST(test_events);
    RUN_TEST(test_event_capacity);
    RUN_TEST(test_event_fields);
    RUN_TEST(test_stats);
    RUN_TEST(test_stats_auth_failures);
    RUN_TEST(test_profile_connect_count);
    RUN_TEST(test_connection_state_callback);
    RUN_TEST(test_network_event_callback);
    RUN_TEST(test_string_helpers_network_type);
    RUN_TEST(test_string_helpers_network_state);
    RUN_TEST(test_string_helpers_security_and_policy);
    RUN_TEST(test_string_helpers_result_and_event);
    RUN_TEST(test_log_server_integration);
    RUN_TEST(test_crash_reporter_integration);
    RUN_TEST(test_full_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run
              << " passed ===" << std::endl;
    return g_tests_failed == 0 ? 0 : 1;
}
