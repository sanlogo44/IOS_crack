/*
 * Phantom OS - Vibrator Manager Tests
 * v0.36.0
 *
 * Comprehensive unit tests for the Vibrator Manager.
 */

#include "phantom/vibrator/vibrator_manager.h"
#include <cassert>
#include <cstdio>
#include <algorithm>

using namespace phantom::vibrator;

static int tests_run = 0;
static int tests_passed = 0;
static int tests_failed = 0;

#define test(name, condition) do { \
    tests_run++; \
    if (condition) { tests_passed++; printf("  [PASS] %s\n", name); } \
    else { tests_failed++; printf("  [FAIL] %s\n", name); } \
} while (0)

static void testLifecycle() {
    printf("\n=== Test 1: Lifecycle ===\n");
    VibratorManager mgr;
    test("not initialized", !mgr.isInitialized());
    test("initialize SUCCESS", mgr.initialize() == VibratorResult::SUCCESS);
    test("initialized", mgr.isInitialized());
    test("initialize again ALREADY", mgr.initialize() == VibratorResult::ALREADY_INITIALIZED);
    test("shutdown SUCCESS", mgr.shutdown() == VibratorResult::SUCCESS);
    test("not initialized after shutdown", !mgr.isInitialized());
    test("shutdown again NOT_INITIALIZED", mgr.shutdown() == VibratorResult::NOT_INITIALIZED);
}

static void testVibratorState() {
    printf("\n=== Test 2: Vibrator State ===\n");
    VibratorManager mgr;
    mgr.initialize();
    test("initial state OFF", mgr.getVibratorState() == VibratorState::OFF);
    test("enable SUCCESS", mgr.enableVibrator() == VibratorResult::SUCCESS);
    test("state ON", mgr.getVibratorState() == VibratorState::ON);
    test("enable again BAD_STATE", mgr.enableVibrator() == VibratorResult::BAD_STATE);
    test("disable SUCCESS", mgr.disableVibrator() == VibratorResult::SUCCESS);
    test("state OFF", mgr.getVibratorState() == VibratorState::OFF);
    test("disable again BAD_STATE", mgr.disableVibrator() == VibratorResult::BAD_STATE);
    test("stats stateChanges >= 2", mgr.getStats().stateChanges >= 2);
    test("enable with non-system PERMISSION_DENIED",
         mgr.enableVibrator("app1") == VibratorResult::PERMISSION_DENIED);
}

static void testIntensity() {
    printf("\n=== Test 3: Intensity ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    test("default intensity 128", mgr.getIntensity() == 128);
    test("setIntensity 255 SUCCESS", mgr.setIntensity(255) == VibratorResult::SUCCESS);
    test("intensity 255", mgr.getIntensity() == 255);
    test("setIntensity 1 SUCCESS", mgr.setIntensity(1) == VibratorResult::SUCCESS);
    test("intensity 1", mgr.getIntensity() == 1);
    test("setIntensity 0 INTENSITY_OUT_OF_RANGE",
         mgr.setIntensity(0) == VibratorResult::INTENSITY_OUT_OF_RANGE);
    test("setIntensity 256 INTENSITY_OUT_OF_RANGE",
         mgr.setIntensity(256) == VibratorResult::INTENSITY_OUT_OF_RANGE);
    test("stats intensityChanges >= 2", mgr.getStats().intensityChanges >= 2);
    test("setIntensity non-system PERMISSION_DENIED",
         mgr.setIntensity(100, "app1") == VibratorResult::PERMISSION_DENIED);
}

static void testVibrationControl() {
    printf("\n=== Test 4: Vibration Control ===\n");
    VibratorManager mgr;
    mgr.initialize();

    test("vibrate when OFF VIBRATOR_OFF",
         mgr.vibrate(100) == VibratorResult::VIBRATOR_OFF);

    mgr.enableVibrator();
    test("vibrate SUCCESS", mgr.vibrate(100) == VibratorResult::SUCCESS);
    test("isVibrating", mgr.isVibrating());
    test("currentDuration 100", mgr.getCurrentVibrationDuration() == 100);
    test("stats vibrationsStarted >= 1", mgr.getStats().vibrationsStarted >= 1);

    test("stopVibration SUCCESS", mgr.stopVibration() == VibratorResult::SUCCESS);
    test("not vibrating", !mgr.isVibrating());
    test("stats vibrationsStopped >= 1", mgr.getStats().vibrationsStopped >= 1);

    test("stop again BAD_STATE", mgr.stopVibration() == VibratorResult::BAD_STATE);

    test("vibrate 0 INVALID_PARAMETER",
         mgr.vibrate(0) == VibratorResult::INVALID_PARAMETER);
    test("vibrate too long PATTERN_TOO_LONG",
         mgr.vibrate(VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS + 1) == VibratorResult::PATTERN_TOO_LONG);

    test("vibrate app1 PERMISSION_DENIED",
         mgr.vibrate(100, "app1") == VibratorResult::PERMISSION_DENIED);

    test("lastAccessTime > 0", mgr.getLastAccessTime() > 0);
}

static void testHapticFeedback() {
    printf("\n=== Test 5: Haptic Feedback ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    // Set up app with permission and system haptics allowed
    mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL, 0, 128, false, true);

    test("haptic CLICK SUCCESS",
         mgr.vibrateHaptic(HapticType::CLICK, "app1") == VibratorResult::SUCCESS);
    test("haptic TICK SUCCESS",
         mgr.vibrateHaptic(HapticType::TICK, "app1") == VibratorResult::SUCCESS);
    test("haptic LONG_PRESS SUCCESS",
         mgr.vibrateHaptic(HapticType::LONG_PRESS, "app1") == VibratorResult::SUCCESS);
    test("haptic SELECTION SUCCESS",
         mgr.vibrateHaptic(HapticType::SELECTION, "app1") == VibratorResult::SUCCESS);
    test("stats hapticFeedbacks >= 4", mgr.getStats().hapticFeedbacks >= 4);

    // App with system haptics disabled
    mgr.setAppVibrationPolicy("app2", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL, 0, 128, false, false);
    test("haptic app2 system haptics disabled PERMISSION_DENIED",
         mgr.vibrateHaptic(HapticType::CLICK, "app2") == VibratorResult::PERMISSION_DENIED);

    // System can always use haptics
    test("haptic system SUCCESS",
         mgr.vibrateHaptic(HapticType::HEAVY_CLICK) == VibratorResult::SUCCESS);
}

static void testPatternManagement() {
    printf("\n=== Test 6: Pattern Management ===\n");
    VibratorManager mgr;
    mgr.initialize();

    test("3 default patterns", mgr.getRegisteredPatterns().size() >= 3);

    VibrationPattern shortPulse;
    shortPulse.name = "short_pulse";
    VibrationPattern out;
    test("getPattern short_pulse", mgr.getPattern("short_pulse", out));
    test("short_pulse has timings", !out.timings.empty());

    VibrationPattern custom;
    custom.name = "custom1";
    custom.timings = {0, 100, 200, 100};
    custom.amplitudes = {150, 255};
    test("registerPattern SUCCESS", mgr.registerPattern(custom) == VibratorResult::SUCCESS);
    test("getPattern custom1", mgr.getPattern("custom1", out));
    test("custom1 correct name", out.name == "custom1");

    test("unregisterPattern SUCCESS", mgr.unregisterPattern("custom1") == VibratorResult::SUCCESS);
    test("getPattern custom1 gone", !mgr.getPattern("custom1", out));

    test("unregisterPattern not found INVALID_PARAMETER",
         mgr.unregisterPattern("nonexistent") == VibratorResult::INVALID_PARAMETER);

    // Invalid pattern
    VibrationPattern invalid;
    invalid.name = "invalid";
    invalid.timings = {};
    test("registerPattern empty PATTERN_EMPTY",
         mgr.registerPattern(invalid) == VibratorResult::PATTERN_EMPTY);

    // Pattern too long
    VibrationPattern tooLong;
    tooLong.name = "tooLong";
    tooLong.timings = {0, VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS + 1};
    tooLong.amplitudes = {200};
    test("registerPattern too long PATTERN_TOO_LONG",
         mgr.registerPattern(tooLong) == VibratorResult::PATTERN_TOO_LONG);
}

static void testPatternVibration() {
    printf("\n=== Test 7: Pattern Vibration ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    // System can play patterns directly
    VibrationPattern pattern;
    pattern.name = "test_pattern";
    pattern.timings = {0, 100, 50, 100};
    pattern.amplitudes = {200, 255};

    test("vibratePattern system SUCCESS",
         mgr.vibratePattern(pattern) == VibratorResult::SUCCESS);
    test("isVibrating", mgr.isVibrating());
    test("stats patternsPlayed >= 1", mgr.getStats().patternsPlayed >= 1);
    mgr.stopVibration();

    // App without custom pattern permission
    mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL, 0, 128, false, false);
    test("vibratePattern app1 no custom PERMISSION_DENIED",
         mgr.vibratePattern(pattern, "app1") == VibratorResult::PERMISSION_DENIED);

    // App with custom pattern permission
    mgr.setAppVibrationPolicy("app2", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL, 0, 128, true, false);
    test("vibratePattern app2 SUCCESS",
         mgr.vibratePattern(pattern, "app2") == VibratorResult::SUCCESS);
}

static void testPermissions() {
    printf("\n=== Test 8: Permissions / Policy ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    // DENY
    mgr.setAppVibrationPolicy("app1", VibrationPermission::DENY,
                                VibrationPrivacyMode::FULL);
    test("DENY vibrate PERMISSION_DENIED",
         mgr.vibrate(100, "app1") == VibratorResult::PERMISSION_DENIED);

    // ALLOW_FOREGROUND without foreground
    mgr.setAppVibrationPolicy("app2", VibrationPermission::ALLOW_FOREGROUND,
                                VibrationPrivacyMode::FULL);
    test("ALLOW_FOREGROUND without fg PERMISSION_DENIED",
         mgr.vibrate(100, "app2") == VibratorResult::PERMISSION_DENIED);

    // Set foreground
    mgr.setAppForeground("app2", true);
    test("ALLOW_FOREGROUND with fg SUCCESS",
         mgr.vibrate(100, "app2") == VibratorResult::SUCCESS);

    // Clear foreground
    mgr.setAppForeground("app2", false);
    test("ALLOW_FOREGROUND after fg clear PERMISSION_DENIED",
         mgr.vibrate(100, "app2") == VibratorResult::PERMISSION_DENIED);

    // ALLOW_ALWAYS
    mgr.setAppVibrationPolicy("app3", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL);
    test("ALLOW_ALWAYS SUCCESS",
         mgr.vibrate(100, "app3") == VibratorResult::SUCCESS);

    // ALLOW_ONCE
    mgr.setAppVibrationPolicy("app4", VibrationPermission::ALLOW_ONCE,
                                VibrationPrivacyMode::FULL);
    test("ALLOW_ONCE first SUCCESS",
         mgr.vibrate(100, "app4") == VibratorResult::SUCCESS);
    test("ALLOW_ONCE second PERMISSION_DENIED",
         mgr.vibrate(100, "app4") == VibratorResult::PERMISSION_DENIED);

    // Clear policy
    test("clearAppVibrationPolicy SUCCESS",
         mgr.clearAppVibrationPolicy("app3") == VibratorResult::SUCCESS);
    test("vibrate after clear PERMISSION_DENIED",
         mgr.vibrate(100, "app3") == VibratorResult::PERMISSION_DENIED);

    // Non-system set policy
    test("setPolicy non-system PERMISSION_DENIED",
         mgr.setAppVibrationPolicy("app5", VibrationPermission::ALLOW_ALWAYS,
                                     VibrationPrivacyMode::FULL, 0, 128, false, false, "hacker")
         == VibratorResult::PERMISSION_DENIED);

    test("stats permissionsChanged >= 5", mgr.getStats().permissionsChanged >= 5);
}

static void testHistory() {
    printf("\n=== Test 9: History ===\n");
    VibratorManager mgr;
    mgr.initialize(8, 16);
    mgr.enableVibrator();

    mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL);
    mgr.vibrate(100, "app1");
    mgr.vibrate(200, "app1");
    mgr.vibrateHaptic(HapticType::CLICK, "app1");

    auto history = mgr.getHistory("app1");
    test("history has entries", history.size() >= 3);

    history = mgr.getHistory("app1", 2);
    test("history limit works", history.size() == 2);

    // System sees all
    history = mgr.getHistory("system");
    test("system sees all history", history.size() >= 5);

    // App-specific history
    test("clearAppHistory SUCCESS",
         mgr.clearAppHistory("app1", "system") == VibratorResult::SUCCESS);
    test("history cleared for app1",
         mgr.getHistory("app1").empty());

    // Non-owner clear denied
    mgr.vibrate(100, "app1");
    test("clearAppHistory non-owner PERMISSION_DENIED",
         mgr.clearAppHistory("app1", "app2") == VibratorResult::PERMISSION_DENIED);

    // Clear all
    mgr.vibrate(100, "system");
    test("clearHistory SUCCESS", mgr.clearHistory() == VibratorResult::SUCCESS);
    test("all history cleared", mgr.getHistory("system").empty());

    test("stats historyClears >= 1", mgr.getStats().historyClears >= 1);
}

static void testMockAndTesting() {
    printf("\n=== Test 10: Mock / Testing ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    test("mock not enabled", !mgr.isMockEnabled());
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == VibratorResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    test("setMockDuration SUCCESS",
         mgr.setMockDuration(500) == VibratorResult::SUCCESS);

    test("stats mockVibrations >= 1", mgr.getStats().mockVibrations >= 1);

    test("mock event recorded",
         mgr.getEventsByType(VibratorEventType::MOCK_VIBRATION_SET).size() >= 1);

    // Non-system mock denied
    test("setMockEnabled non-system PERMISSION_DENIED",
         mgr.setMockEnabled(false, "app1") == VibratorResult::PERMISSION_DENIED);
}

static void testPrivacyIndicator() {
    printf("\n=== Test 11: Privacy Indicator ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL);
    test("indicator off initially", !mgr.isPrivacyIndicatorOn());

    mgr.vibrate(100, "app1");
    test("indicator on after vibrate", mgr.isPrivacyIndicatorOn());

    auto users = mgr.getActiveVibrationUsers();
    test("active users contains app1",
         std::find(users.begin(), users.end(), "app1") != users.end());

    mgr.stopVibration("app1");
    test("indicator off after stop", !mgr.isPrivacyIndicatorOn());

    auto events = mgr.getEventsByType(VibratorEventType::INDICATOR_ON);
    test("indicator on events", events.size() >= 1);

    events = mgr.getEventsByType(VibratorEventType::INDICATOR_OFF);
    test("indicator off events", events.size() >= 1);
}

static void testEvents() {
    printf("\n=== Test 12: Events ===\n");
    VibratorManager mgr;
    mgr.initialize(64, 16);
    mgr.enableVibrator();

    for (int i = 0; i < 20; i++) {
        mgr.vibrate(50);
        mgr.stopVibration();
    }

    test("events ring buffer max 16", mgr.getEventCount() <= 16);

    auto events = mgr.getEvents(5);
    test("getEvents limit works", events.size() == 5);

    auto started = mgr.getEventsByType(VibratorEventType::VIBRATION_STARTED);
    auto stopped = mgr.getEventsByType(VibratorEventType::VIBRATION_STOPPED);
    test("started events exist", started.size() > 0);
    test("stopped events exist", stopped.size() > 0);

    test("clearEvents SUCCESS", mgr.clearEvents() == VibratorResult::SUCCESS);
    test("events cleared", mgr.getEventCount() == 0);

    test("history archived from events",
         mgr.getHistoryCount() > 0);
}

static void testStats() {
    printf("\n=== Test 13: Stats ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    mgr.vibrate(100);
    mgr.stopVibration();
    mgr.setIntensity(200);
    mgr.vibrateHaptic(HapticType::CLICK);

    auto stats = mgr.getStats();
    test("vibrationsStarted >= 1", stats.vibrationsStarted >= 1);
    test("vibrationsStopped >= 1", stats.vibrationsStopped >= 1);
    test("hapticFeedbacks >= 1", stats.hapticFeedbacks >= 1);
    test("intensityChanges >= 1", stats.intensityChanges >= 1);

    test("byEventType VIBRATION_STARTED > 0",
         stats.byEventType[static_cast<uint8_t>(VibratorEventType::VIBRATION_STARTED)] > 0);

    test("byResult SUCCESS > 0",
         stats.byResult[static_cast<uint8_t>(VibratorResult::SUCCESS)] > 0);

    mgr.resetStats();
    auto stats2 = mgr.getStats();
    test("stats reset", stats2.vibrationsStarted == 0);
}

static void testCallbacks() {
    printf("\n=== Test 14: Callbacks ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    int eventCount = 0;
    bool sawVibrationStarted = false;

    mgr.setEventCallback([&eventCount, &sawVibrationStarted](const VibratorEvent& event) {
        eventCount++;
        if (event.type == VibratorEventType::VIBRATION_STARTED) {
            sawVibrationStarted = true;
        }
    });

    std::string accessApp;
    VibratorResult accessResult = VibratorResult::SUCCESS;

    mgr.setAccessCallback([&accessApp, &accessResult](const std::string& app, VibratorResult result) {
        accessApp = app;
        accessResult = result;
    });

    mgr.vibrate(100);
    test("event callback fired", eventCount > 0);
    test("event callback saw VIBRATION_STARTED", sawVibrationStarted);

    mgr.stopVibration();
    test("event callback for stop", eventCount >= 2);
}

static void testFailureSimulation() {
    printf("\n=== Test 15: Failure Simulation ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    test("failNextOperation disabled initially", !mgr.getFailNextOperation());

    // Enable adapter is ON, disable first without fail flag
    mgr.disableVibrator();  // vibrator OFF, no fail flag
    mgr.setFailNextOperation(true);
    test("enableVibrator SIMULATED_FAILURE",
         mgr.enableVibrator() == VibratorResult::SIMULATED_FAILURE);
    test("failNextOperation consumed", !mgr.getFailNextOperation());

    // Vibrator is OFF now, enable should succeed
    test("enableVibrator SUCCESS after failure consumed",
         mgr.enableVibrator() == VibratorResult::SUCCESS);

    // Test vibrate failure
    mgr.setFailNextOperation(true);
    test("vibrate SIMULATED_FAILURE",
         mgr.vibrate(100) == VibratorResult::SIMULATED_FAILURE);

    // Test setIntensity failure
    mgr.setFailNextOperation(true);
    test("setIntensity SIMULATED_FAILURE",
         mgr.setIntensity(200) == VibratorResult::SIMULATED_FAILURE);
}

static void testTimeInjection() {
    printf("\n=== Test 16: Time Injection ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();
    mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                VibrationPrivacyMode::FULL);

    mgr.setCurrentTimeForTesting(1000000);
    mgr.vibrate(100, "app1");
    test("lastAccessTime 1000000", mgr.getLastAccessTime() == 1000000);

    mgr.setCurrentTimeForTesting(2000000);
    mgr.vibrate(200, "app1");
    test("lastAccessTime 2000000", mgr.getLastAccessTime() == 2000000);

    mgr.clearTimeOverride();
    test("time override cleared",
         mgr.getLastAccessTime() != 2000000 || mgr.getLastAccessTime() == 2000000);
}

static void testStringHelpers() {
    printf("\n=== Test 17: String Helpers ===\n");

    test("vibratorState OFF", std::string(VibratorManager::vibratorStateToString(VibratorState::OFF)) == "OFF");
    test("vibratorState ON", std::string(VibratorManager::vibratorStateToString(VibratorState::ON)) == "ON");

    test("haptic CLICK", std::string(VibratorManager::hapticTypeToString(HapticType::CLICK)) == "CLICK");
    test("haptic DOUBLE_CLICK", std::string(VibratorManager::hapticTypeToString(HapticType::DOUBLE_CLICK)) == "DOUBLE_CLICK");
    test("haptic HEAVY_CLICK", std::string(VibratorManager::hapticTypeToString(HapticType::HEAVY_CLICK)) == "HEAVY_CLICK");
    test("haptic TICK", std::string(VibratorManager::hapticTypeToString(HapticType::TICK)) == "TICK");
    test("haptic SELECTION", std::string(VibratorManager::hapticTypeToString(HapticType::SELECTION)) == "SELECTION");

    test("waveform SINE", std::string(VibratorManager::waveformTypeToString(WaveformType::SINE)) == "SINE");
    test("waveform SQUARE", std::string(VibratorManager::waveformTypeToString(WaveformType::SQUARE)) == "SQUARE");

    test("permission DENY", std::string(VibratorManager::permissionToString(VibrationPermission::DENY)) == "DENY");
    test("permission ALLOW_FOREGROUND", std::string(VibratorManager::permissionToString(VibrationPermission::ALLOW_FOREGROUND)) == "ALLOW_FOREGROUND");
    test("permission ALLOW_ALWAYS", std::string(VibratorManager::permissionToString(VibrationPermission::ALLOW_ALWAYS)) == "ALLOW_ALWAYS");
    test("permission ALLOW_ONCE", std::string(VibratorManager::permissionToString(VibrationPermission::ALLOW_ONCE)) == "ALLOW_ONCE");

    test("privacyMode FULL", std::string(VibratorManager::privacyModeToString(VibrationPrivacyMode::FULL)) == "FULL");
    test("privacyMode REDACTED", std::string(VibratorManager::privacyModeToString(VibrationPrivacyMode::REDACTED)) == "REDACTED");
    test("privacyMode METADATA_ONLY", std::string(VibratorManager::privacyModeToString(VibrationPrivacyMode::METADATA_ONLY)) == "METADATA_ONLY");

    test("result SUCCESS", std::string(VibratorManager::resultToString(VibratorResult::SUCCESS)) == "SUCCESS");
    test("result NOT_INITIALIZED", std::string(VibratorManager::resultToString(VibratorResult::NOT_INITIALIZED)) == "NOT_INITIALIZED");
    test("result PERMISSION_DENIED", std::string(VibratorManager::resultToString(VibratorResult::PERMISSION_DENIED)) == "PERMISSION_DENIED");
    test("result VIBRATOR_OFF", std::string(VibratorManager::resultToString(VibratorResult::VIBRATOR_OFF)) == "VIBRATOR_OFF");
    test("result PATTERN_TOO_LONG", std::string(VibratorManager::resultToString(VibratorResult::PATTERN_TOO_LONG)) == "PATTERN_TOO_LONG");

    test("event VIBRATION_STARTED", std::string(VibratorManager::eventTypeToString(VibratorEventType::VIBRATION_STARTED)) == "VIBRATION_STARTED");
    test("event HAPTIC_FEEDBACK", std::string(VibratorManager::eventTypeToString(VibratorEventType::HAPTIC_FEEDBACK)) == "HAPTIC_FEEDBACK");

    // Parser
    test("stringToResult SUCCESS", VibratorManager::stringToResult("SUCCESS") == VibratorResult::SUCCESS);
    test("stringToResult VIBRATOR_OFF", VibratorManager::stringToResult("VIBRATOR_OFF") == VibratorResult::VIBRATOR_OFF);
    test("stringToHapticType CLICK", VibratorManager::stringToHapticType("CLICK") == HapticType::CLICK);
    test("stringToHapticType SELECTION", VibratorManager::stringToHapticType("SELECTION") == HapticType::SELECTION);
}

static void testLogServerCrashReporter() {
    printf("\n=== Test 18: LogServer / CrashReporter ===\n");
    VibratorManager mgr;
    mgr.initialize();
    mgr.enableVibrator();

    // These should not crash even with null log server / crash reporter
    test("logServer null initially", mgr.getLogServer() == nullptr);
    test("crashReporter null initially", mgr.getCrashReporter() == nullptr);

    mgr.vibrate(100);
    test("vibrate with null log server SUCCESS",
         mgr.getStats().vibrationsStarted >= 1);

    // Set null pointers explicitly
    mgr.setLogServer(nullptr);
    mgr.setCrashReporter(nullptr);
    test("setLogServer null OK", mgr.getLogServer() == nullptr);
    test("setCrashReporter null OK", mgr.getCrashReporter() == nullptr);
}

static void testFullWorkflow() {
    printf("\n=== Test 19: Full Workflow ===\n");
    VibratorManager mgr;
    mgr.initialize(32, 64);

    // 1. Enable vibrator
    test("1. enable SUCCESS", mgr.enableVibrator() == VibratorResult::SUCCESS);
    test("2. state ON", mgr.isVibratorEnabled());

    // 2. Set intensity
    test("3. setIntensity SUCCESS", mgr.setIntensity(200) == VibratorResult::SUCCESS);
    test("4. intensity 200", mgr.getIntensity() == 200);

    // 3. Register custom pattern
    VibrationPattern custom;
    custom.name = "workflow_pattern";
    custom.timings = {0, 200, 100, 200, 100, 100};
    custom.amplitudes = {150, 255, 100};
    test("5. registerPattern SUCCESS", mgr.registerPattern(custom) == VibratorResult::SUCCESS);

    // 4. Play pattern
    test("6. vibratePattern SUCCESS", mgr.vibratePattern(custom) == VibratorResult::SUCCESS);
    test("7. isVibrating", mgr.isVibrating());

    // 5. Stop vibration
    test("8. stopVibration SUCCESS", mgr.stopVibration() == VibratorResult::SUCCESS);
    test("9. not vibrating", !mgr.isVibrating());

    // 6. Vibrate with haptic
    test("10. vibrateHaptic SUCCESS",
         mgr.vibrateHaptic(HapticType::CLICK) == VibratorResult::SUCCESS);
    mgr.stopVibration();

    // 7. Set app policy
    test("11. setAppPolicy SUCCESS",
         mgr.setAppVibrationPolicy("app1", VibrationPermission::ALLOW_ALWAYS,
                                     VibrationPrivacyMode::FULL, 0, 128, true, true)
         == VibratorResult::SUCCESS);

    // 8. App vibrates
    test("12. app vibrate SUCCESS",
         mgr.vibrate(100, "app1") == VibratorResult::SUCCESS);
    test("13. indicator on", mgr.isPrivacyIndicatorOn());

    // 9. App plays custom pattern
    test("14. app pattern SUCCESS",
         mgr.vibratePattern(custom, "app1") == VibratorResult::SUCCESS);
    mgr.stopVibration("app1");

    // 10. Check stats
    auto stats = mgr.getStats();
    test("15. vibrationsStarted > 0", stats.vibrationsStarted > 0);
    test("16. patternsPlayed > 0", stats.patternsPlayed > 0);
    test("17. hapticFeedbacks > 0", stats.hapticFeedbacks > 0);
    test("18. permissionsChanged > 0", stats.permissionsChanged > 0);

    // 11. Check events
    test("19. events exist", mgr.getEventCount() > 0);

    // 12. Clear history
    test("20. clearHistory SUCCESS", mgr.clearHistory() == VibratorResult::SUCCESS);
    test("21. history cleared", mgr.getHistoryCount() == 0);

    // 13. Disable vibrator
    test("22. disable SUCCESS", mgr.disableVibrator() == VibratorResult::SUCCESS);
    test("23. state OFF", !mgr.isVibratorEnabled());

    // 14. Shutdown
    test("24. shutdown SUCCESS", mgr.shutdown() == VibratorResult::SUCCESS);
    test("25. not initialized", !mgr.isInitialized());

    printf("\n========================================\n");
    printf("Results: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("========================================\n");
}

int main() {
    printf("=== PhantomOS Vibrator Manager Tests v0.36.0 ===\n");

    testLifecycle();
    testVibratorState();
    testIntensity();
    testVibrationControl();
    testHapticFeedback();
    testPatternManagement();
    testPatternVibration();
    testPermissions();
    testHistory();
    testMockAndTesting();
    testPrivacyIndicator();
    testEvents();
    testStats();
    testCallbacks();
    testFailureSimulation();
    testTimeInjection();
    testStringHelpers();
    testLogServerCrashReporter();
    testFullWorkflow();

    printf("\n=== Summary: %d passed, %d failed ===\n", tests_passed, tests_failed);
    return tests_failed > 0 ? 1 : 0;
}
