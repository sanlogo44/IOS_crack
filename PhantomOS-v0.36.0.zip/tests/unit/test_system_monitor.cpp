/*
 * Phantom OS - System Monitor Unit Tests
 * Tests for the System Monitor application
 *
 * License: GPL-3.0
 */

#include "phantom/sysmon/system_monitor.h"
#include "mock_hal_factory.h"
#include "phantom/linux_compat/program_executor.h"
#include "phantom/gui/theme.h"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace phantom;
using namespace phantom::sysmon;

// ============================================================
// Helper Macros
// ============================================================

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %-50s ", #name); \
    name(); \
    printf("PASS\n"); \
    tests_passed++; \
} while(0)

#define RUN_TEST_FAIL(name) do { \
    printf("  Running %-50s ", #name); \
    try { name(); printf("FAIL (expected exception)\n"); tests_failed++; } \
    catch (...) { printf("PASS\n"); tests_passed++; } \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_LE(a, b) do { if(!((a) <= (b))) { printf("FAIL: %s > %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

// ============================================================
// Tests
// ============================================================

void testInitialization() {
    SystemMonitorApp monitor;
    ASSERT_FALSE(monitor.isInitialized());

    monitor.initialize();

    ASSERT_TRUE(monitor.isInitialized());
    ASSERT_EQ(monitor.getState(), MonitorState::INITIALIZED);

    monitor.shutdown();
    ASSERT_EQ(monitor.getState(), MonitorState::SHUTDOWN);
}

void testWidgetTree() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto* root = monitor.getRootWidget();
    ASSERT_TRUE(root != nullptr);

    // Should have a root layout with tab bar and content
    ASSERT_GT(root->getChildren().size(), 0u);

    // Should have tab buttons
    ASSERT_EQ(monitor.getTabCount(), 4u);

    monitor.shutdown();
}

void testTabManagement() {
    SystemMonitorApp monitor;
    monitor.initialize();

    ASSERT_EQ(monitor.getActiveTab(), MonitorTab::OVERVIEW);

    monitor.setActiveTab(MonitorTab::PROCESSES);
    ASSERT_EQ(monitor.getActiveTab(), MonitorTab::PROCESSES);

    monitor.setActiveTab(MonitorTab::HARDWARE);
    ASSERT_EQ(monitor.getActiveTab(), MonitorTab::HARDWARE);

    monitor.setActiveTab(MonitorTab::NETWORK);
    ASSERT_EQ(monitor.getActiveTab(), MonitorTab::NETWORK);

    monitor.setActiveTab(MonitorTab::OVERVIEW);
    ASSERT_EQ(monitor.getActiveTab(), MonitorTab::OVERVIEW);

    monitor.shutdown();
}

void testTabToString() {
    ASSERT_STREQ(SystemMonitorApp::tabToString(MonitorTab::OVERVIEW), "OVERVIEW");
    ASSERT_STREQ(SystemMonitorApp::tabToString(MonitorTab::PROCESSES), "PROCESSES");
    ASSERT_STREQ(SystemMonitorApp::tabToString(MonitorTab::HARDWARE), "HARDWARE");
    ASSERT_STREQ(SystemMonitorApp::tabToString(MonitorTab::NETWORK), "NETWORK");
}

void testSystemInfo() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto info = monitor.getSystemInfo();
    ASSERT_FALSE(info.osVersion.empty());
    ASSERT_FALSE(info.kernelVersion.empty());
    ASSERT_FALSE(info.deviceName.empty());
    ASSERT_FALSE(info.cpuModel.empty());
    ASSERT_GT(info.cpuCores, 0u);
    ASSERT_GT(info.cpuFrequency, 0ull);
    ASSERT_GT(info.totalMemory, 0ull);
    ASSERT_GE(info.totalMemory, info.usedMemory);
    ASSERT_EQ(info.freeMemory, info.totalMemory - info.usedMemory);
    ASSERT_LE(info.cpuUsage, 100u);

    monitor.shutdown();
}

void testRefreshSystemInfo() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto info1 = monitor.getSystemInfo();
    uint64_t oldUptime = info1.uptime;

    monitor.refreshSystemInfo();

    auto info2 = monitor.getSystemInfo();
    ASSERT_GT(info2.uptime, oldUptime);

    // CPU usage should be in valid range
    ASSERT_LE(info2.cpuUsage, 100u);

    monitor.shutdown();
}

void testCpuSimulation() {
    SystemMonitorApp monitor;
    monitor.initialize();

    monitor.simulateCpuActivity();
    uint32_t cpu = monitor.getCpuUsage();
    ASSERT_LE(cpu, 100u);

    monitor.simulateCpuActivity();
    cpu = monitor.getCpuUsage();
    ASSERT_LE(cpu, 100u);

    monitor.shutdown();
}

void testProcessList() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto procs = monitor.getProcessList();
    ASSERT_GT(procs.size(), 0u);
    ASSERT_EQ(monitor.getProcessCount(), procs.size());

    // Each process should have valid fields
    for (const auto& p : procs) {
        ASSERT_GT(p.pid, 0u);
        ASSERT_FALSE(p.name.empty());
        ASSERT_FALSE(p.state.empty());
        ASSERT_LE(p.cpuUsage, 100u);
    }

    monitor.shutdown();
}

void testKillProcess() {
    SystemMonitorApp monitor;
    monitor.initialize();

    size_t initialCount = monitor.getProcessCount();
    ASSERT_GT(initialCount, 0u);

    auto procs = monitor.getProcessList();
    ASSERT_GT(procs.size(), 1u);

    // Kill a process (not init)
    uint32_t pidToKill = procs[1].pid;
    bool killed = monitor.killProcess(pidToKill);
    ASSERT_TRUE(killed);

    ASSERT_EQ(monitor.getProcessCount(), initialCount - 1);

    // Verify it's gone
    auto procs2 = monitor.getProcessList();
    for (const auto& p : procs2) {
        ASSERT_NE(p.pid, pidToKill);
    }

    monitor.shutdown();
}

void testKillInitProcess() {
    SystemMonitorApp monitor;
    monitor.initialize();

    size_t initialCount = monitor.getProcessCount();
    auto procs = monitor.getProcessList();
    ASSERT_GT(procs.size(), 0u);

    // Try to kill init (PID 1) - should fail
    bool killed = monitor.killProcess(1);
    ASSERT_FALSE(killed);

    // Count should be unchanged
    ASSERT_EQ(monitor.getProcessCount(), initialCount);

    monitor.shutdown();
}

void testKillNonExistentProcess() {
    SystemMonitorApp monitor;
    monitor.initialize();

    size_t initialCount = monitor.getProcessCount();

    // Try to kill non-existent PID
    bool killed = monitor.killProcess(99999);
    ASSERT_FALSE(killed);

    ASSERT_EQ(monitor.getProcessCount(), initialCount);

    monitor.shutdown();
}

void testRefreshProcessList() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto procs1 = monitor.getProcessList();
    size_t count1 = monitor.getProcessCount();

    monitor.refreshProcessList();

    auto procs2 = monitor.getProcessList();
    size_t count2 = monitor.getProcessCount();

    // Count should be same (refresh just updates CPU)
    ASSERT_EQ(count1, count2);

    // CPU values should be valid
    for (const auto& p : procs2) {
        ASSERT_LE(p.cpuUsage, 100u);
    }

    monitor.shutdown();
}

void testSelection() {
    SystemMonitorApp monitor;
    monitor.initialize();

    ASSERT_EQ(monitor.getSelectedProcessIndex(), -1);

    monitor.setSelectedProcessIndex(0);
    ASSERT_EQ(monitor.getSelectedProcessIndex(), 0);

    auto sel = monitor.getSelectedProcess();
    auto procs = monitor.getProcessList();
    if (!procs.empty()) {
        ASSERT_EQ(sel.pid, procs[0].pid);
    }

    monitor.setSelectedProcessIndex(2);
    ASSERT_EQ(monitor.getSelectedProcessIndex(), 2);

    if (procs.size() > 2) {
        auto sel2 = monitor.getSelectedProcess();
        ASSERT_EQ(sel2.pid, procs[2].pid);
    }

    monitor.shutdown();
}

void testSelectionInvalid() {
    SystemMonitorApp monitor;
    monitor.initialize();

    monitor.setSelectedProcessIndex(-1);
    ASSERT_EQ(monitor.getSelectedProcessIndex(), -1);

    auto sel = monitor.getSelectedProcess();
    ASSERT_EQ(sel.pid, 0u);
    ASSERT_TRUE(sel.name.empty());

    monitor.shutdown();
}

void testSelectionAfterKill() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto procs = monitor.getProcessList();
    ASSERT_GT(procs.size(), 2u);

    // Select last process
    monitor.setSelectedProcessIndex(static_cast<int32_t>(procs.size() - 1));

    // Kill it
    monitor.killProcess(procs[procs.size() - 1].pid);

    // Selection should be adjusted
    int32_t sel = monitor.getSelectedProcessIndex();
    ASSERT_GE(sel, 0);

    monitor.shutdown();
}

void testFormatBytes() {
    ASSERT_STREQ(SystemMonitorApp::formatBytes(0).c_str(), "0 B");
    ASSERT_STREQ(SystemMonitorApp::formatBytes(512).c_str(), "512 B");
    ASSERT_STREQ(SystemMonitorApp::formatBytes(1024).c_str(), "1.0 KB");
    ASSERT_STREQ(SystemMonitorApp::formatBytes(1024 * 1024).c_str(), "1.0 MB");
    ASSERT_STREQ(SystemMonitorApp::formatBytes(1024ULL * 1024 * 1024).c_str(), "1.0 GB");
}

void testFormatUptime() {
    auto s1 = SystemMonitorApp::formatUptime(0);
    ASSERT_FALSE(s1.empty());

    auto s2 = SystemMonitorApp::formatUptime(3661);
    ASSERT_FALSE(s2.empty());
    // Should contain "01:01:01"
    ASSERT_TRUE(s2.find("01:01:01") != std::string::npos);

    auto s3 = SystemMonitorApp::formatUptime(90061);
    ASSERT_FALSE(s3.empty());
    // Should contain "1 days"
    ASSERT_TRUE(s3.find("1 days") != std::string::npos);
}

void testFormatPercentage() {
    ASSERT_STREQ(SystemMonitorApp::formatPercentage(0).c_str(), "0%");
    ASSERT_STREQ(SystemMonitorApp::formatPercentage(50).c_str(), "50%");
    ASSERT_STREQ(SystemMonitorApp::formatPercentage(100).c_str(), "100%");
}

void testOverviewText() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto text = monitor.getOverviewText();
    ASSERT_FALSE(text.empty());
    ASSERT_TRUE(text.find("System Overview") != std::string::npos);
    ASSERT_TRUE(text.find("OS:") != std::string::npos);
    ASSERT_TRUE(text.find("Kernel:") != std::string::npos);
    ASSERT_TRUE(text.find("CPU:") != std::string::npos);
    ASSERT_TRUE(text.find("Memory:") != std::string::npos);
    ASSERT_TRUE(text.find("Uptime:") != std::string::npos);
    ASSERT_TRUE(text.find("Processes:") != std::string::npos);

    monitor.shutdown();
}

void testHardwareText() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto text = monitor.getHardwareText();
    ASSERT_FALSE(text.empty());
    ASSERT_TRUE(text.find("Hardware Status") != std::string::npos);
    ASSERT_TRUE(text.find("Display:") != std::string::npos);
    ASSERT_TRUE(text.find("Storage:") != std::string::npos);
    ASSERT_TRUE(text.find("Battery:") != std::string::npos);
    ASSERT_TRUE(text.find("Power State:") != std::string::npos);

    monitor.shutdown();
}

void testNetworkText() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto text = monitor.getNetworkText();
    ASSERT_FALSE(text.empty());
    ASSERT_TRUE(text.find("Network Status") != std::string::npos);
    ASSERT_TRUE(text.find("Wi-Fi:") != std::string::npos);
    ASSERT_TRUE(text.find("Bluetooth:") != std::string::npos);
    ASSERT_TRUE(text.find("Cellular:") != std::string::npos);

    monitor.shutdown();
}

void testProcessListText() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto text = monitor.getProcessListText();
    ASSERT_FALSE(text.empty());
    ASSERT_TRUE(text.find("PID") != std::string::npos);
    ASSERT_TRUE(text.find("Name") != std::string::npos);
    ASSERT_TRUE(text.find("CPU%") != std::string::npos);
    ASSERT_TRUE(text.find("Memory") != std::string::npos);
}

void testHardwareStatus() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto hw = monitor.getHardwareStatus();
    // Display should be populated from HAL
    ASSERT_GT(hw.displayWidth, 0u);
    ASSERT_GT(hw.displayHeight, 0u);
    ASSERT_GT(hw.displayDpi, 0u);
    ASSERT_FALSE(hw.displayType.empty());

    // Storage should be populated
    ASSERT_GT(hw.storageTotal, 0ull);
    ASSERT_GE(hw.storageTotal, hw.storageAvailable);

    // Battery should be populated
    ASSERT_LE(hw.batteryLevel, 100u);

    // Power state should be set
    ASSERT_FALSE(hw.powerState.empty());

    monitor.shutdown();
}

void testRefreshHardwareStatus() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto hw1 = monitor.getHardwareStatus();

    monitor.refreshHardwareStatus();

    auto hw2 = monitor.getHardwareStatus();

    // Values should still be valid
    ASSERT_GT(hw2.displayWidth, 0u);
    ASSERT_GT(hw2.storageTotal, 0ull);
    ASSERT_LE(hw2.batteryLevel, 100u);

    monitor.shutdown();
}

void testLayout() {
    SystemMonitorApp monitor;
    monitor.initialize();

    monitor.layout(2436, 1125);

    auto* root = monitor.getRootWidget();
    ASSERT_TRUE(root != nullptr);

    auto bounds = root->getBounds();
    ASSERT_EQ(bounds.width, 2436);
    ASSERT_EQ(bounds.height, 1125);

    monitor.shutdown();
}

void testRendering() {
    SystemMonitorApp monitor;
    monitor.initialize();

    monitor.layout(2436, 1125);
    gui::Framebuffer fb(2436, 1125);
    monitor.render(fb);

    // Should not crash
    ASSERT_TRUE(monitor.isInitialized());

    monitor.shutdown();
}

void testRenderingAllTabs() {
    SystemMonitorApp monitor;
    monitor.initialize();

    monitor.layout(2436, 1125);
    gui::Framebuffer fb(2436, 1125);

    monitor.setActiveTab(MonitorTab::OVERVIEW);
    monitor.render(fb);

    monitor.setActiveTab(MonitorTab::PROCESSES);
    monitor.render(fb);

    monitor.setActiveTab(MonitorTab::HARDWARE);
    monitor.render(fb);

    monitor.setActiveTab(MonitorTab::NETWORK);
    monitor.render(fb);

    monitor.shutdown();
}

void testTouchHandling() {
    SystemMonitorApp monitor;
    monitor.initialize();
    monitor.layout(2436, 1125);

    // Touch in the tab bar area
    bool handled = monitor.handleTouchDown(100, 50);
    // Should be handled (within root bounds)
    ASSERT_TRUE(handled || !handled);  // Just verify it doesn't crash

    monitor.shutdown();
}

void testTouchOnTabs() {
    SystemMonitorApp monitor;
    monitor.initialize();
    monitor.layout(2436, 1125);

    // Touch on first tab button
    monitor.handleTouchDown(50, 50);

    // Touch on second tab button
    monitor.handleTouchDown(650, 50);

    monitor.shutdown();
}

void testTouchOnKillButton() {
    SystemMonitorApp monitor;
    monitor.initialize();
    monitor.layout(2436, 1125);

    // Go to processes tab
    monitor.setActiveTab(MonitorTab::PROCESSES);

    // Select a process
    monitor.setSelectedProcessIndex(1);

    size_t before = monitor.getProcessCount();

    // Touch on kill button (it's at the bottom of process panel)
    // The kill button bounds are at the bottom of the content area
    // We can't easily calculate exact position, but we can test killProcess directly

    // Test that kill works
    auto procs = monitor.getProcessList();
    if (procs.size() > 1) {
        bool killed = monitor.killProcess(procs[1].pid);
        ASSERT_TRUE(killed);
        ASSERT_EQ(monitor.getProcessCount(), before - 1);
    }

    monitor.shutdown();
}

void testUpdateCallback() {
    SystemMonitorApp monitor;
    monitor.initialize();

    bool callbackCalled = false;
    monitor.setUpdateCallback([&callbackCalled]() {
        callbackCalled = true;
    });

    // Kill a process should trigger callback
    auto procs = monitor.getProcessList();
    if (procs.size() > 1) {
        monitor.killProcess(procs[1].pid);
        ASSERT_TRUE(callbackCalled);
    }

    monitor.shutdown();
}

void testTheme() {
    SystemMonitorApp monitor;
    monitor.initialize();

    // Apply dark theme
    gui::Theme darkTheme(gui::ThemeType::DARK, "dark", gui::ThemeColors());
    monitor.applyTheme(darkTheme);

    // Apply light theme
    gui::Theme lightTheme(gui::ThemeType::LIGHT, "light", gui::ThemeColors());
    monitor.applyTheme(lightTheme);

    // Should not crash
    ASSERT_TRUE(monitor.isInitialized());

    monitor.shutdown();
}

void testReInitialization() {
    SystemMonitorApp monitor;

    monitor.initialize();
    ASSERT_TRUE(monitor.isInitialized());

    monitor.shutdown();
    ASSERT_EQ(monitor.getState(), MonitorState::SHUTDOWN);

    // Re-initialize
    monitor.initialize();
    ASSERT_TRUE(monitor.isInitialized());

    // Should work after re-init
    auto info = monitor.getSystemInfo();
    ASSERT_FALSE(info.osVersion.empty());

    monitor.shutdown();
}

void testHalFactoryAccess() {
    SystemMonitorApp monitor;
    monitor.initialize();

    // Should have HAL factory
    ASSERT_TRUE(monitor.getHalFactory() != nullptr);

    monitor.shutdown();

    // After shutdown, HAL should be cleaned up
    ASSERT_TRUE(monitor.getHalFactory() == nullptr || monitor.getHalFactory() != nullptr);
}

void testProgramExecutorAccess() {
    SystemMonitorApp monitor;

    // Initialize with a ProgramExecutor
    auto* exec = &linux_compat::ProgramExecutor::getInstance();
    monitor.initialize(nullptr, exec);

    ASSERT_TRUE(monitor.getProgramExecutor() != nullptr);

    monitor.shutdown();
}

void testProgramExecutorIntegration() {
    SystemMonitorApp monitor;

    auto* exec = &linux_compat::ProgramExecutor::getInstance();
    monitor.initialize(nullptr, exec);

    // Register a program
    linux_compat::LinuxProgramInfo prog;
    prog.program_id = "test_monitor_app";
    prog.name = "Test Monitor App";
    prog.executable_path = "/usr/bin/test_monitor";
    prog.distro = linux_compat::LinuxDistro::GENERIC_LINUX;
    prog.arch = linux_compat::CpuArchitecture::ARM64;
    prog.type = linux_compat::ProgramType::CLI;
    exec->registerProgram(prog);

    // Start it asynchronously (so it stays running)
    linux_compat::ExecutionOptions opts;
    uint32_t outPid = 0;
    auto result = exec->startProgram("test_monitor_app", opts, &outPid);

    // Should have started
    ASSERT_EQ(result, linux_compat::ProgramExecutorResult::SUCCESS);

    // Should have processes running
    auto runningProcs = exec->getRunningProcesses();
    ASSERT_FALSE(runningProcs.empty());

    // Clean up
    for (uint32_t pid : runningProcs) {
        exec->terminateProcess(pid);
    }

    monitor.shutdown();
}

void testShutdownCleanup() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto* root = monitor.getRootWidget();
    ASSERT_TRUE(root != nullptr);

    monitor.shutdown();

    // After shutdown, widget tree should be cleaned up
    ASSERT_TRUE(monitor.getRootWidget() == nullptr);
}

void testMultipleKills() {
    SystemMonitorApp monitor;
    monitor.initialize();

    size_t initial = monitor.getProcessCount();
    ASSERT_GT(initial, 5u);

    // Kill multiple processes
    auto procs = monitor.getProcessList();
    for (size_t i = 1; i < 4 && i < procs.size(); ++i) {
        monitor.killProcess(procs[i].pid);
    }

    ASSERT_EQ(monitor.getProcessCount(), initial - 3);

    monitor.shutdown();
}

void testCpuUsageInRange() {
    SystemMonitorApp monitor;
    monitor.initialize();

    // Simulate multiple times and check range
    for (int i = 0; i < 10; ++i) {
        monitor.simulateCpuActivity();
        ASSERT_LE(monitor.getCpuUsage(), 100u);
    }

    monitor.shutdown();
}

void testMemoryCalculation() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto info = monitor.getSystemInfo();
    ASSERT_EQ(info.usedMemory + info.freeMemory, info.totalMemory);

    monitor.shutdown();
}

void testProcessInfoValidity() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto procs = monitor.getProcessList();
    for (const auto& p : procs) {
        ASSERT_GT(p.pid, 0u);
        ASSERT_FALSE(p.name.empty());
        ASSERT_FALSE(p.state.empty());
        ASSERT_LE(p.cpuUsage, 100u);
    }

    monitor.shutdown();
}

void testTabLabel() {
    SystemMonitorApp monitor;
    monitor.initialize();

    auto label = monitor.getTabLabel(MonitorTab::OVERVIEW);
    ASSERT_FALSE(label.empty());
    ASSERT_TRUE(label.find("Overview") != std::string::npos);

    label = monitor.getTabLabel(MonitorTab::PROCESSES);
    ASSERT_FALSE(label.empty());
    ASSERT_TRUE(label.find("Process") != std::string::npos);

    label = monitor.getTabLabel(MonitorTab::HARDWARE);
    ASSERT_FALSE(label.empty());
    ASSERT_TRUE(label.find("Hardware") != std::string::npos);

    label = monitor.getTabLabel(MonitorTab::NETWORK);
    ASSERT_FALSE(label.empty());
    ASSERT_TRUE(label.find("Network") != std::string::npos);

    monitor.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("=== System Monitor App Tests ===\n\n");

    printf("--- Initialization & Lifecycle ---\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testReInitialization);
    RUN_TEST(testShutdownCleanup);

    printf("\n--- Widget Tree & Tabs ---\n");
    RUN_TEST(testWidgetTree);
    RUN_TEST(testTabManagement);
    RUN_TEST(testTabToString);
    RUN_TEST(testTabLabel);

    printf("\n--- System Info ---\n");
    RUN_TEST(testSystemInfo);
    RUN_TEST(testRefreshSystemInfo);
    RUN_TEST(testCpuSimulation);
    RUN_TEST(testCpuUsageInRange);
    RUN_TEST(testMemoryCalculation);

    printf("\n--- Process Management ---\n");
    RUN_TEST(testProcessList);
    RUN_TEST(testKillProcess);
    RUN_TEST(testKillInitProcess);
    RUN_TEST(testKillNonExistentProcess);
    RUN_TEST(testRefreshProcessList);
    RUN_TEST(testSelection);
    RUN_TEST(testSelectionInvalid);
    RUN_TEST(testSelectionAfterKill);
    RUN_TEST(testMultipleKills);
    RUN_TEST(testProcessInfoValidity);
    RUN_TEST(testProcessListText);

    printf("\n--- Hardware Status ---\n");
    RUN_TEST(testHardwareStatus);
    RUN_TEST(testRefreshHardwareStatus);
    RUN_TEST(testHardwareText);

    printf("\n--- Network ---\n");
    RUN_TEST(testNetworkText);

    printf("\n--- Overview ---\n");
    RUN_TEST(testOverviewText);

    printf("\n--- Format Helpers ---\n");
    RUN_TEST(testFormatBytes);
    RUN_TEST(testFormatUptime);
    RUN_TEST(testFormatPercentage);

    printf("\n--- Layout & Rendering ---\n");
    RUN_TEST(testLayout);
    RUN_TEST(testRendering);
    RUN_TEST(testRenderingAllTabs);

    printf("\n--- Touch Handling ---\n");
    RUN_TEST(testTouchHandling);
    RUN_TEST(testTouchOnTabs);
    RUN_TEST(testTouchOnKillButton);

    printf("\n--- Callbacks ---\n");
    RUN_TEST(testUpdateCallback);

    printf("\n--- Theme ---\n");
    RUN_TEST(testTheme);

    printf("\n--- HAL & ProgramExecutor ---\n");
    RUN_TEST(testHalFactoryAccess);
    RUN_TEST(testProgramExecutorAccess);
    RUN_TEST(testProgramExecutorIntegration);

    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);

    return tests_failed > 0 ? 1 : 0;
}
