/*
 * Phantom OS - Linux Compatibility Layer Tests
 * Tests for simulated Linux program execution
 *
 * License: GPL-3.0
 */

#include "phantom/linux_compat/program_executor.h"
#include "phantom/linux_compat/linux_program.h"
#include "phantom/package_manager/package_manager.h"
#include "phantom/package_manager/package.h"
#include <cassert>
#include <cstdio>
#include <string>

using namespace phantom::linux_compat;
using namespace phantom::package;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

// Helper to create a valid program info
LinuxProgramInfo makeProgramInfo(const std::string& id, const std::string& name = "TestProg",
                                   LinuxDistro distro = LinuxDistro::GENERIC_LINUX,
                                   CpuArchitecture arch = CpuArchitecture::ARM64) {
    LinuxProgramInfo info;
    info.program_id = id;
    info.name = name;
    info.version = "1.0.0";
    info.distro = distro;
    info.arch = arch;
    info.executable_path = "/usr/bin/" + id;
    info.type = ProgramType::CLI;
    info.description = "Test program";
    info.sandbox_profile = "normal";
    return info;
}

ExecutionOptions makeOptions() {
    ExecutionOptions opts;
    opts.capture_stdout = true;
    opts.capture_stderr = true;
    return opts;
}

// ============================================================
// String conversion tests
// ============================================================

bool test_distro_strings() {
    TEST("Distro string conversions");
    ASSERT(std::string(distroToString(LinuxDistro::KALI_LINUX)) == "KALI_LINUX", "KALI_LINUX");
    ASSERT(std::string(distroToString(LinuxDistro::ARCH_LINUX)) == "ARCH_LINUX", "ARCH_LINUX");
    ASSERT(std::string(distroToString(LinuxDistro::CSI_LINUX)) == "CSI_LINUX", "CSI_LINUX");
    ASSERT(std::string(distroToString(LinuxDistro::GENERIC_LINUX)) == "GENERIC_LINUX", "GENERIC_LINUX");
    ASSERT(std::string(distroToString(LinuxDistro::UNKNOWN_DISTRO)) == "UNKNOWN_DISTRO", "UNKNOWN_DISTRO");
    PASS();
    return true;
}

bool test_format_strings() {
    TEST("Package format string conversions");
    ASSERT(std::string(packageFormatToString(PackageFormat::DEB)) == "DEB", "DEB");
    ASSERT(std::string(packageFormatToString(PackageFormat::PACMAN)) == "PACMAN", "PACMAN");
    ASSERT(std::string(packageFormatToString(PackageFormat::TAR_ARCHIVE)) == "TAR_ARCHIVE", "TAR_ARCHIVE");
    ASSERT(std::string(packageFormatToString(PackageFormat::APPIMAGE)) == "APPIMAGE", "APPIMAGE");
    PASS();
    return true;
}

bool test_arch_strings() {
    TEST("Architecture string conversions");
    ASSERT(std::string(archToString(CpuArchitecture::ARM64)) == "ARM64", "ARM64");
    ASSERT(std::string(archToString(CpuArchitecture::X86_64)) == "X86_64", "X86_64");
    ASSERT(std::string(archToString(CpuArchitecture::ARMV7)) == "ARMV7", "ARMV7");
    PASS();
    return true;
}

bool test_state_strings() {
    TEST("Program state string conversions");
    ASSERT(std::string(programStateToString(ProgramState::REGISTERED)) == "REGISTERED", "REGISTERED");
    ASSERT(std::string(programStateToString(ProgramState::RUNNING)) == "RUNNING", "RUNNING");
    ASSERT(std::string(programStateToString(ProgramState::EXITED)) == "EXITED", "EXITED");
    ASSERT(std::string(programStateToString(ProgramState::TERMINATED)) == "TERMINATED", "TERMINATED");
    ASSERT(std::string(programStateToString(ProgramState::TIMEOUT)) == "TIMEOUT", "TIMEOUT");
    ASSERT(std::string(programStateToString(ProgramState::FAILED)) == "FAILED", "FAILED");
    PASS();
    return true;
}

bool test_result_strings() {
    TEST("Result string conversions");
    ASSERT(std::string(resultToString(ProgramExecutorResult::SUCCESS)) == "SUCCESS", "SUCCESS");
    ASSERT(std::string(resultToString(ProgramExecutorResult::NOT_REGISTERED)) == "NOT_REGISTERED", "NOT_REGISTERED");
    ASSERT(std::string(resultToString(ProgramExecutorResult::ALREADY_RUNNING)) == "ALREADY_RUNNING", "ALREADY_RUNNING");
    ASSERT(std::string(resultToString(ProgramExecutorResult::PACKAGE_NOT_INSTALLED)) == "PACKAGE_NOT_INSTALLED", "PACKAGE_NOT_INSTALLED");
    PASS();
    return true;
}

bool test_distro_format_mapping() {
    TEST("Distro to package format mapping");
    ASSERT(distroToPackageFormat(LinuxDistro::KALI_LINUX) == PackageFormat::DEB, "Kali -> DEB");
    ASSERT(distroToPackageFormat(LinuxDistro::ARCH_LINUX) == PackageFormat::PACMAN, "Arch -> PACMAN");
    ASSERT(distroToPackageFormat(LinuxDistro::CSI_LINUX) == PackageFormat::TAR_ARCHIVE, "CSI -> TAR");
    ASSERT(distroToPackageFormat(LinuxDistro::GENERIC_LINUX) == PackageFormat::TAR_ARCHIVE, "Generic -> TAR");
    PASS();
    return true;
}

// ============================================================
// Registration tests
// ============================================================

bool test_register_program() {
    TEST("Register valid program");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto result = exec.registerProgram(makeProgramInfo("com.test.prog1"));
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should register successfully");
    ASSERT(exec.isProgramRegistered("com.test.prog1"), "Should be registered");
    ASSERT(exec.getRegisteredCount() == 1, "Should have 1 registered");
    PASS();
    return true;
}

bool test_register_invalid() {
    TEST("Register invalid program (empty ID)");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("");
    auto result = exec.registerProgram(info);
    ASSERT(result == ProgramExecutorResult::INVALID_PROGRAM, "Should fail - empty ID");
    PASS();
    return true;
}

bool test_register_empty_path() {
    TEST("Register program with empty path");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("com.test.nopath");
    info.executable_path = "";
    auto result = exec.registerProgram(info);
    ASSERT(result == ProgramExecutorResult::INVALID_PATH, "Should fail - empty path");
    PASS();
    return true;
}

bool test_register_empty_name() {
    TEST("Register program with empty name");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("com.test.noname");
    info.name = "";
    auto result = exec.registerProgram(info);
    ASSERT(result == ProgramExecutorResult::INVALID_PROGRAM, "Should fail - empty name");
    PASS();
    return true;
}

bool test_register_duplicate() {
    TEST("Register duplicate fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.test.dup"));
    auto result = exec.registerProgram(makeProgramInfo("com.test.dup"));
    ASSERT(result == ProgramExecutorResult::ALREADY_REGISTERED, "Should fail - duplicate");
    PASS();
    return true;
}

bool test_unregister_program() {
    TEST("Unregister program");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.test.unregister"));
    auto result = exec.unregisterProgram("com.test.unregister");
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should unregister successfully");
    ASSERT(!exec.isProgramRegistered("com.test.unregister"), "Should not be registered");
    PASS();
    return true;
}

bool test_unregister_not_registered() {
    TEST("Unregister non-registered fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto result = exec.unregisterProgram("com.test.notreg");
    ASSERT(result == ProgramExecutorResult::NOT_REGISTERED, "Should fail - not registered");
    PASS();
    return true;
}

bool test_unregister_running_blocked() {
    TEST("Unregister running program blocked");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.test.rununreg"));
    uint32_t pid = 0;
    exec.startProgram("com.test.rununreg", makeOptions(), &pid);
    auto result = exec.unregisterProgram("com.test.rununreg");
    ASSERT(result == ProgramExecutorResult::ALREADY_RUNNING, "Should fail - running");
    PASS();
    return true;
}

bool test_force_unregister_running() {
    TEST("Force unregister running program");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.test.forcereg"));
    uint32_t pid = 0;
    exec.startProgram("com.test.forcereg", makeOptions(), &pid);
    auto result = exec.unregisterProgram("com.test.forcereg", true);
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should succeed with force");
    ASSERT(!exec.isProgramRegistered("com.test.forcereg"), "Should be unregistered");
    PASS();
    return true;
}

// ============================================================
// Query tests
// ============================================================

bool test_get_program_info() {
    TEST("Get program info");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("com.test.info", "MyProgram", LinuxDistro::KALI_LINUX);
    info.version = "2.1.0";
    exec.registerProgram(info);
    auto retrieved = exec.getProgramInfo("com.test.info");
    ASSERT(retrieved.program_id == "com.test.info", "Program ID should match");
    ASSERT(retrieved.name == "MyProgram", "Name should match");
    ASSERT(retrieved.version == "2.1.0", "Version should match");
    ASSERT(retrieved.distro == LinuxDistro::KALI_LINUX, "Distro should be KALI_LINUX");
    PASS();
    return true;
}

bool test_get_registered_programs() {
    TEST("Get registered programs list");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.list.a"));
    exec.registerProgram(makeProgramInfo("com.list.b"));
    exec.registerProgram(makeProgramInfo("com.list.c"));
    auto list = exec.getRegisteredPrograms();
    ASSERT(list.size() == 3, "Should have 3 registered");
    PASS();
    return true;
}

bool test_get_programs_by_distro() {
    TEST("Get programs by distro");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.distro.kali1", "K1", LinuxDistro::KALI_LINUX));
    exec.registerProgram(makeProgramInfo("com.distro.arch1", "A1", LinuxDistro::ARCH_LINUX));
    exec.registerProgram(makeProgramInfo("com.distro.kali2", "K2", LinuxDistro::KALI_LINUX));
    exec.registerProgram(makeProgramInfo("com.distro.csi1", "C1", LinuxDistro::CSI_LINUX));

    auto kaliProgs = exec.getProgramsByDistro(LinuxDistro::KALI_LINUX);
    ASSERT(kaliProgs.size() == 2, "Should have 2 Kali programs");

    auto archProgs = exec.getProgramsByDistro(LinuxDistro::ARCH_LINUX);
    ASSERT(archProgs.size() == 1, "Should have 1 Arch program");

    auto csiProgs = exec.getProgramsByDistro(LinuxDistro::CSI_LINUX);
    ASSERT(csiProgs.size() == 1, "Should have 1 CSI program");
    PASS();
    return true;
}

// ============================================================
// Execution tests
// ============================================================

bool test_execute_program() {
    TEST("Execute program (synchronous)");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.exec.test1"));
    ProcessInfo proc;
    auto result = exec.executeProgram("com.exec.test1", makeOptions(), &proc);
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should execute successfully");
    ASSERT(proc.state == ProgramState::EXITED, "Should be EXITED");
    ASSERT(proc.exit_code == 0, "Exit code should be 0");
    ASSERT(!proc.stdout_output.empty(), "Should have stdout");
    PASS();
    return true;
}

bool test_execute_unknown() {
    TEST("Execute unknown program fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto result = exec.executeProgram("com.exec.unknown", makeOptions());
    ASSERT(result == ProgramExecutorResult::NOT_REGISTERED, "Should fail - not registered");
    PASS();
    return true;
}

bool test_execute_capture_stdout() {
    TEST("Execute captures stdout");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.exec.stdout", "MyTool"));
    ProcessInfo proc;
    exec.executeProgram("com.exec.stdout", makeOptions(), &proc);
    ASSERT(proc.stdout_output.find("Executing:") != std::string::npos, "Should contain Executing:");
    ASSERT(proc.stdout_output.find("MyTool") != std::string::npos, "Should contain program name");
    PASS();
    return true;
}

bool test_execute_with_args() {
    TEST("Execute with arguments");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.exec.args", "ArgTool"));
    ExecutionOptions opts = makeOptions();
    opts.args = {"--verbose", "--output=/tmp/test"};
    ProcessInfo proc;
    exec.executeProgram("com.exec.args", opts, &proc);
    ASSERT(proc.args.size() == 2, "Should have 2 args");
    ASSERT(proc.args[0] == "--verbose", "First arg should match");
    ASSERT(proc.args[1] == "--output=/tmp/test", "Second arg should match");
    PASS();
    return true;
}

bool test_execute_with_env() {
    TEST("Execute with environment variables");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.exec.env", "EnvTool"));
    ExecutionOptions opts = makeOptions();
    opts.env = {{"PATH", "/usr/bin:/bin"}, {"HOME", "/root"}};
    ProcessInfo proc;
    exec.executeProgram("com.exec.env", opts, &proc);
    ASSERT(proc.env.size() == 2, "Should have 2 env vars");
    ASSERT(proc.env[0].first == "PATH", "First env key should be PATH");
    ASSERT(proc.env[1].second == "/root", "Second env value should be /root");
    PASS();
    return true;
}

bool test_execute_with_working_dir() {
    TEST("Execute with working directory");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.exec.workdir", "DirTool"));
    ExecutionOptions opts = makeOptions();
    opts.working_dir = "/tmp/work";
    ProcessInfo proc;
    exec.executeProgram("com.exec.workdir", opts, &proc);
    ASSERT(proc.working_dir == "/tmp/work", "Working dir should match");
    ASSERT(proc.stdout_output.find("/tmp/work") != std::string::npos, "stdout should mention workdir");
    PASS();
    return true;
}

// ============================================================
// Start/terminate tests
// ============================================================

bool test_start_program() {
    TEST("Start program (async)");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.start.test"));
    uint32_t pid = 0;
    auto result = exec.startProgram("com.start.test", makeOptions(), &pid);
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should start successfully");
    ASSERT(pid > 0, "Should have valid PID");
    ASSERT(exec.isProcessRunning(pid), "Should be running");
    ASSERT(exec.getRunningCount() == 1, "Should have 1 running");
    PASS();
    return true;
}

bool test_start_unknown() {
    TEST("Start unknown program fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    uint32_t pid = 0;
    auto result = exec.startProgram("com.start.unknown", makeOptions(), &pid);
    ASSERT(result == ProgramExecutorResult::NOT_REGISTERED, "Should fail - not registered");
    PASS();
    return true;
}

bool test_start_already_running() {
    TEST("Start already running blocked");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.start.duprun"));
    uint32_t pid1 = 0;
    exec.startProgram("com.start.duprun", makeOptions(), &pid1);
    uint32_t pid2 = 0;
    auto result = exec.startProgram("com.start.duprun", makeOptions(), &pid2);
    ASSERT(result == ProgramExecutorResult::ALREADY_RUNNING, "Should fail - already running");
    PASS();
    return true;
}

bool test_start_multiple_instances() {
    TEST("Start with multiple instances allowed");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.start.multi"));
    ExecutionOptions opts = makeOptions();
    opts.allow_multiple_instances = true;
    uint32_t pid1 = 0, pid2 = 0;
    exec.startProgram("com.start.multi", opts, &pid1);
    auto result = exec.startProgram("com.start.multi", opts, &pid2);
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should allow multiple instances");
    ASSERT(pid1 != pid2, "PIDs should be different");
    ASSERT(exec.getRunningCount() == 2, "Should have 2 running");
    PASS();
    return true;
}

bool test_terminate_process() {
    TEST("Terminate running process");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.term.test"));
    uint32_t pid = 0;
    exec.startProgram("com.term.test", makeOptions(), &pid);
    auto result = exec.terminateProcess(pid);
    ASSERT(result == ProgramExecutorResult::TERMINATED_OK, "Should terminate successfully");
    auto proc = exec.getProcessInfo(pid);
    ASSERT(proc.state == ProgramState::TERMINATED, "Should be TERMINATED");
    ASSERT(proc.exit_code == 1, "Exit code should be 1");
    ASSERT(!exec.isProcessRunning(pid), "Should not be running");
    PASS();
    return true;
}

bool test_terminate_unknown() {
    TEST("Terminate unknown process fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto result = exec.terminateProcess(9999);
    ASSERT(result == ProgramExecutorResult::NOT_FOUND, "Should fail - not found");
    PASS();
    return true;
}

bool test_terminate_not_running() {
    TEST("Terminate already exited process fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.term.exited"));
    ProcessInfo proc;
    exec.executeProgram("com.term.exited", makeOptions(), &proc);
    auto result = exec.terminateProcess(proc.pid);
    ASSERT(result == ProgramExecutorResult::ALREADY_EXITED, "Should fail - already exited");
    PASS();
    return true;
}

bool test_timeout_process() {
    TEST("Timeout process");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.timeout.test"));
    uint32_t pid = 0;
    exec.startProgram("com.timeout.test", makeOptions(), &pid);
    auto result = exec.timeoutProcess(pid);
    ASSERT(result == ProgramExecutorResult::TIMEOUT, "Should timeout successfully");
    auto proc = exec.getProcessInfo(pid);
    ASSERT(proc.state == ProgramState::TIMEOUT, "Should be TIMEOUT");
    ASSERT(proc.exit_code == 124, "Exit code should be 124");
    PASS();
    return true;
}

bool test_timeout_unknown() {
    TEST("Timeout unknown process fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto result = exec.timeoutProcess(9999);
    ASSERT(result == ProgramExecutorResult::NOT_FOUND, "Should fail - not found");
    PASS();
    return true;
}

// ============================================================
// Process query tests
// ============================================================

bool test_get_process_info() {
    TEST("Get process info");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.proc.info"));
    uint32_t pid = 0;
    exec.startProgram("com.proc.info", makeOptions(), &pid);
    auto proc = exec.getProcessInfo(pid);
    ASSERT(proc.pid == pid, "PID should match");
    ASSERT(proc.program_id == "com.proc.info", "Program ID should match");
    ASSERT(proc.state == ProgramState::RUNNING, "Should be RUNNING");
    PASS();
    return true;
}

bool test_get_running_processes() {
    TEST("Get running processes");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.proc.run1"));
    exec.registerProgram(makeProgramInfo("com.proc.run2"));
    exec.registerProgram(makeProgramInfo("com.proc.run3"));
    uint32_t pid1 = 0, pid2 = 0;
    exec.startProgram("com.proc.run1", makeOptions(), &pid1);
    exec.startProgram("com.proc.run2", makeOptions(), &pid2);
    auto running = exec.getRunningProcesses();
    ASSERT(running.size() == 2, "Should have 2 running");
    PASS();
    return true;
}

bool test_get_all_processes() {
    TEST("Get all processes");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.proc.all1"));
    exec.registerProgram(makeProgramInfo("com.proc.all2"));
    exec.executeProgram("com.proc.all1", makeOptions());
    uint32_t pid = 0;
    exec.startProgram("com.proc.all2", makeOptions(), &pid);
    auto all = exec.getAllProcesses();
    ASSERT(all.size() == 2, "Should have 2 processes");
    PASS();
    return true;
}

// ============================================================
// State callback test
// ============================================================

bool test_state_change_callback() {
    TEST("State change callback");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();

    uint32_t callback_pid = 0;
    std::string callback_prog;
    ProgramState callback_old = ProgramState::REGISTERED;
    ProgramState callback_new = ProgramState::REGISTERED;
    int callback_count = 0;

    exec.setStateChangeCallback([&](uint32_t pid, const std::string& progId,
                                     ProgramState oldState, ProgramState newState) {
        callback_pid = pid;
        callback_prog = progId;
        callback_old = oldState;
        callback_new = newState;
        callback_count++;
    });

    exec.registerProgram(makeProgramInfo("com.callback.test"));
    uint32_t pid = 0;
    exec.startProgram("com.callback.test", makeOptions(), &pid);
    ASSERT(callback_count > 0, "Callback should have been called");
    ASSERT(callback_prog == "com.callback.test", "Program ID should match");
    ASSERT(callback_new == ProgramState::RUNNING, "New state should be RUNNING");
    PASS();
    return true;
}

// ============================================================
// Package integration tests
// ============================================================

bool test_register_from_package() {
    TEST("Register program from installed package");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto& pm = PackageManager::getInstance();
    pm.clear();

    // Install a package first
    PackageManifest manifest;
    manifest.info.package_id = "com.pkg.linuxtool";
    manifest.info.app_id = "com.app.linuxtool";
    manifest.info.name = "LinuxTool";
    manifest.info.version_str = "1.2.0";
    manifest.info.version = PackageVersion::parse("1.2.0");
    manifest.info.description = "A Linux tool";
    manifest.info.vendor = "TestCorp";
    manifest.info.entry_point = "linuxtool";
    manifest.info.install_path = "/usr/bin";
    manifest.sandbox_profile = SandboxProfile::NORMAL;
    pm.installPackage(manifest);

    auto result = exec.registerProgramFromPackage("com.pkg.linuxtool",
                                                     LinuxDistro::KALI_LINUX,
                                                     CpuArchitecture::ARM64);
    ASSERT(result == ProgramExecutorResult::SUCCESS, "Should register from package");
    ASSERT(exec.isProgramRegistered("linux.com.pkg.linuxtool"), "Should be registered");

    auto info = exec.getProgramInfo("linux.com.pkg.linuxtool");
    ASSERT(info.name == "LinuxTool", "Name should match package");
    ASSERT(info.distro == LinuxDistro::KALI_LINUX, "Distro should be Kali");
    ASSERT(info.package_id == "com.pkg.linuxtool", "Package ID should match");
    PASS();
    return true;
}

bool test_register_from_uninstalled_package() {
    TEST("Register from uninstalled package fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto& pm = PackageManager::getInstance();
    pm.clear();

    auto result = exec.registerProgramFromPackage("com.pkg.notinstalled",
                                                     LinuxDistro::ARCH_LINUX,
                                                     CpuArchitecture::X86_64);
    ASSERT(result == ProgramExecutorResult::PACKAGE_NOT_INSTALLED, "Should fail - not installed");
    PASS();
    return true;
}

// ============================================================
// Utility tests
// ============================================================

bool test_supported_distro() {
    TEST("Is supported distro");
    ASSERT(ProgramExecutor::isSupportedDistro(LinuxDistro::KALI_LINUX), "Kali should be supported");
    ASSERT(ProgramExecutor::isSupportedDistro(LinuxDistro::ARCH_LINUX), "Arch should be supported");
    ASSERT(ProgramExecutor::isSupportedDistro(LinuxDistro::CSI_LINUX), "CSI should be supported");
    ASSERT(ProgramExecutor::isSupportedDistro(LinuxDistro::GENERIC_LINUX), "Generic should be supported");
    ASSERT(!ProgramExecutor::isSupportedDistro(LinuxDistro::UNKNOWN_DISTRO), "Unknown should not be supported");
    PASS();
    return true;
}

bool test_supported_arch() {
    TEST("Is supported architecture");
    ASSERT(ProgramExecutor::isSupportedArch(CpuArchitecture::ARM64), "ARM64 should be supported");
    ASSERT(ProgramExecutor::isSupportedArch(CpuArchitecture::X86_64), "X86_64 should be supported");
    ASSERT(ProgramExecutor::isSupportedArch(CpuArchitecture::ARMV7), "ARMV7 should be supported");
    ASSERT(!ProgramExecutor::isSupportedArch(CpuArchitecture::UNKNOWN_ARCH), "Unknown should not be supported");
    PASS();
    return true;
}

bool test_distro_package_format() {
    TEST("Get distro package format");
    ASSERT(ProgramExecutor::getDistroPackageFormat(LinuxDistro::KALI_LINUX) == PackageFormat::DEB, "Kali -> DEB");
    ASSERT(ProgramExecutor::getDistroPackageFormat(LinuxDistro::ARCH_LINUX) == PackageFormat::PACMAN, "Arch -> PACMAN");
    ASSERT(ProgramExecutor::getDistroPackageFormat(LinuxDistro::CSI_LINUX) == PackageFormat::TAR_ARCHIVE, "CSI -> TAR");
    PASS();
    return true;
}

bool test_register_unsupported_distro() {
    TEST("Register program with unsupported distro fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("com.test.baddistro", "BadDistro", LinuxDistro::UNKNOWN_DISTRO);
    auto result = exec.registerProgram(info);
    ASSERT(result == ProgramExecutorResult::UNSUPPORTED_DISTRO, "Should fail - unsupported distro");
    PASS();
    return true;
}

bool test_register_unsupported_arch() {
    TEST("Register program with unsupported arch fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto info = makeProgramInfo("com.test.badarch", "BadArch");
    info.arch = CpuArchitecture::UNKNOWN_ARCH;
    auto result = exec.registerProgram(info);
    ASSERT(result == ProgramExecutorResult::UNSUPPORTED_ARCH, "Should fail - unsupported arch");
    PASS();
    return true;
}

bool test_register_from_package_unsupported_distro() {
    TEST("Register from package with unsupported distro fails");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    auto& pm = PackageManager::getInstance();
    pm.clear();
    // Install a package first
    PackageManifest manifest;
    manifest.info.package_id = "com.pkg.distrotest";
    manifest.info.name = "DistroTest";
    manifest.info.version_str = "1.0.0";
    manifest.info.version = PackageVersion::parse("1.0.0");
    manifest.info.entry_point = "tool";
    manifest.info.install_path = "/usr/bin";
    manifest.sandbox_profile = SandboxProfile::NORMAL;
    pm.installPackage(manifest);

    auto result = exec.registerProgramFromPackage("com.pkg.distrotest",
                                                     LinuxDistro::UNKNOWN_DISTRO,
                                                     CpuArchitecture::ARM64);
    ASSERT(result == ProgramExecutorResult::UNSUPPORTED_DISTRO, "Should fail - unsupported distro");
    PASS();
    return true;
}

bool test_multiple_instance_terminate_one() {
    TEST("Terminate one of multiple instances keeps other running");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.multi.term"));
    ExecutionOptions opts = makeOptions();
    opts.allow_multiple_instances = true;
    uint32_t pid1 = 0, pid2 = 0;
    exec.startProgram("com.multi.term", opts, &pid1);
    exec.startProgram("com.multi.term", opts, &pid2);
    ASSERT(exec.getRunningCount() == 2, "Should have 2 running");

    // Terminate one
    exec.terminateProcess(pid1);
    ASSERT(exec.getRunningCount() == 1, "Should have 1 running after terminate");
    ASSERT(exec.isProcessRunning(pid2), "Second process should still be running");

    // Unregister should still be blocked because pid2 is running
    auto result = exec.unregisterProgram("com.multi.term");
    ASSERT(result == ProgramExecutorResult::ALREADY_RUNNING, "Unregister should be blocked");
    PASS();
    return true;
}

bool test_clear_all() {
    TEST("Clear all programs and processes");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.clear.1"));
    exec.registerProgram(makeProgramInfo("com.clear.2"));
    uint32_t pid = 0;
    exec.startProgram("com.clear.1", makeOptions(), &pid);

    exec.clear();
    ASSERT(exec.getRegisteredCount() == 0, "Registered should be 0");
    ASSERT(exec.getRunningCount() == 0, "Running should be 0");
    ASSERT(exec.getAllProcesses().size() == 0, "Processes should be 0");
    PASS();
    return true;
}

bool test_pid_increment() {
    TEST("PID increments");
    auto& exec = ProgramExecutor::getInstance();
    exec.clear();
    exec.registerProgram(makeProgramInfo("com.pid.1"));
    exec.registerProgram(makeProgramInfo("com.pid.2"));
    uint32_t pid1 = 0, pid2 = 0;
    exec.executeProgram("com.pid.1", makeOptions(), nullptr);
    exec.startProgram("com.pid.1", makeOptions(), &pid1);
    exec.startProgram("com.pid.2", makeOptions(), &pid2);
    ASSERT(pid1 != pid2, "PIDs should be different");
    ASSERT(pid2 > pid1, "Second PID should be higher");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Linux Compatibility Layer Tests ===\n\n");

    bool all_pass = true;
    // String conversion tests
    all_pass &= test_distro_strings();
    all_pass &= test_format_strings();
    all_pass &= test_arch_strings();
    all_pass &= test_state_strings();
    all_pass &= test_result_strings();
    all_pass &= test_distro_format_mapping();
    // Registration tests
    all_pass &= test_register_program();
    all_pass &= test_register_invalid();
    all_pass &= test_register_empty_path();
    all_pass &= test_register_empty_name();
    all_pass &= test_register_duplicate();
    all_pass &= test_register_unsupported_distro();
    all_pass &= test_register_unsupported_arch();
    all_pass &= test_register_from_package_unsupported_distro();
    all_pass &= test_unregister_program();
    all_pass &= test_unregister_not_registered();
    all_pass &= test_unregister_running_blocked();
    all_pass &= test_force_unregister_running();
    // Query tests
    all_pass &= test_get_program_info();
    all_pass &= test_get_registered_programs();
    all_pass &= test_get_programs_by_distro();
    // Execution tests
    all_pass &= test_execute_program();
    all_pass &= test_execute_unknown();
    all_pass &= test_execute_capture_stdout();
    all_pass &= test_execute_with_args();
    all_pass &= test_execute_with_env();
    all_pass &= test_execute_with_working_dir();
    // Start/terminate tests
    all_pass &= test_start_program();
    all_pass &= test_start_unknown();
    all_pass &= test_start_already_running();
    all_pass &= test_start_multiple_instances();
    all_pass &= test_multiple_instance_terminate_one();
    all_pass &= test_terminate_process();
    all_pass &= test_terminate_unknown();
    all_pass &= test_terminate_not_running();
    all_pass &= test_timeout_process();
    all_pass &= test_timeout_unknown();
    // Process query tests
    all_pass &= test_get_process_info();
    all_pass &= test_get_running_processes();
    all_pass &= test_get_all_processes();
    // State callback
    all_pass &= test_state_change_callback();
    // Package integration
    all_pass &= test_register_from_package();
    all_pass &= test_register_from_uninstalled_package();
    // Utility tests
    all_pass &= test_supported_distro();
    all_pass &= test_supported_arch();
    all_pass &= test_distro_package_format();
    all_pass &= test_clear_all();
    all_pass &= test_pid_increment();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
