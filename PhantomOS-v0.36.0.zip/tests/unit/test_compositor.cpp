/*
 * Phantom OS - Compositor Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/compositor.h"
#include "phantom/gui/window_manager.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_compositor_clear() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    wm.setScreenBounds(Rect(0, 0, 100, 100));

    Compositor compositor;
    compositor.setOutputSize(100, 100);
    compositor.setBackgroundColor(Color::Black);

    // Compose with no windows — should be all background
    compositor.compose();

    ASSERT(compositor.verifyPixel(0, 0, Color::Black), "Pixel should be background black");
    ASSERT(compositor.verifyPixel(50, 50, Color::Black), "Pixel should be background black");
    ASSERT(compositor.countNonBackgroundPixels() == 0, "No non-background pixels with no windows");
    ASSERT(compositor.getLastCompositedWindowCount() == 0, "0 windows composited");

    return true;
}

bool test_single_window_render() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    wm.setScreenBounds(Rect(0, 0, 100, 100));

    Compositor compositor;
    compositor.setOutputSize(100, 100);
    compositor.setBackgroundColor(Color::Black);

    // Create a window and fill it red
    Window::WindowId id = wm.createWindow("Red", "com.app", Rect(10, 10, 50, 50));
    Window* win = wm.getWindow(id);
    win->show();
    win->getSurface()->fill(Color::Red);

    compositor.compose();

    // Inside the window should be red
    ASSERT(compositor.verifyPixel(20, 20, Color::Red), "Pixel inside window should be Red");
    ASSERT(compositor.verifyPixel(10, 10, Color::Red), "Window top-left should be Red");
    ASSERT(compositor.verifyPixel(59, 59, Color::Red), "Window bottom-right should be Red");

    // Outside should be black
    ASSERT(compositor.verifyPixel(0, 0, Color::Black), "Pixel outside should be Black");
    ASSERT(compositor.verifyPixel(70, 70, Color::Black), "Pixel outside should be Black");

    ASSERT(compositor.countNonBackgroundPixels() == 2500, "Should have 2500 non-bg pixels (50x50)");
    ASSERT(compositor.getLastCompositedWindowCount() == 1, "1 window composited");

    return true;
}

bool test_z_order_rendering() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    wm.setScreenBounds(Rect(0, 0, 100, 100));

    Compositor compositor;
    compositor.setOutputSize(100, 100);
    compositor.setBackgroundColor(Color::Black);

    // Back window — fills with red
    Window::WindowId back = wm.createWindow("Back", "com.app1", Rect(0, 0, 80, 80));
    wm.getWindow(back)->show();
    wm.getWindow(back)->getSurface()->fill(Color::Red);
    wm.setZOrder(back, 1);

    // Front window — fills with blue, overlaps back
    Window::WindowId front = wm.createWindow("Front", "com.app2", Rect(40, 40, 80, 80));
    wm.getWindow(front)->show();
    wm.getWindow(front)->getSurface()->fill(Color::Blue);
    wm.setZOrder(front, 2);

    compositor.compose();

    // In the overlap area (40-79), the front (blue) should be visible
    ASSERT(compositor.verifyPixel(50, 50, Color::Blue), "Overlap area should show front (Blue)");

    // In the back-only area (0-39), red should be visible
    ASSERT(compositor.verifyPixel(10, 10, Color::Red), "Back-only area should show back (Red)");

    // In the front-only area (80-99 of front), blue should be visible
    ASSERT(compositor.verifyPixel(90, 90, Color::Blue), "Front-only area should show front (Blue)");

    return true;
}

bool test_hidden_window_not_rendered() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Compositor compositor;
    compositor.setOutputSize(100, 100);
    compositor.setBackgroundColor(Color::Black);

    // Create a visible red window
    Window::WindowId visible = wm.createWindow("Visible", "com.app1", Rect(0, 0, 50, 50));
    wm.getWindow(visible)->show();
    wm.getWindow(visible)->getSurface()->fill(Color::Red);

    // Create a hidden blue window that would overlap
    Window::WindowId hidden = wm.createWindow("Hidden", "com.app2", Rect(0, 0, 50, 50));
    wm.getWindow(hidden)->hide();  // Hidden
    wm.getWindow(hidden)->getSurface()->fill(Color::Blue);
    wm.setZOrder(hidden, 2);  // Higher z-order

    compositor.compose();

    // The visible (red) window should be shown, not the hidden (blue) one
    ASSERT(compositor.verifyPixel(25, 25, Color::Red), "Visible window should be Red, hidden should not render");
    ASSERT(compositor.getLastCompositedWindowCount() == 1, "Only 1 window (visible) should be composited");

    return true;
}

bool test_clipping_at_screen_edges() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Compositor compositor;
    compositor.setOutputSize(100, 100);
    compositor.setBackgroundColor(Color::Black);

    // Create a window that extends beyond the screen
    Window::WindowId id = wm.createWindow("Clip", "com.app", Rect(80, 80, 50, 50));
    wm.getWindow(id)->show();
    wm.getWindow(id)->getSurface()->fill(Color::Green);

    compositor.compose();

    // Only the visible part (80-99) should be rendered
    ASSERT(compositor.verifyPixel(90, 90, Color::Green), "Visible part should be Green");
    ASSERT(compositor.verifyPixel(80, 80, Color::Green), "Start of visible part should be Green");
    ASSERT(compositor.verifyPixel(99, 99, Color::Green), "Edge pixel should be Green");

    // Should NOT crash or write out of bounds — pixels outside are untouched (black)
    ASSERT(compositor.verifyPixel(0, 0, Color::Black), "Far corner should still be Black");

    // Non-background pixels should be 20x20 = 400 (clipped from 50x50)
    ASSERT(compositor.countNonBackgroundPixels() == 400, "Should have 400 non-bg pixels (20x20 clipped)");

    return true;
}

int main() {
    printf("=== Compositor Tests ===\n");
    test_compositor_clear();
    test_single_window_render();
    test_z_order_rendering();
    test_hidden_window_not_rendered();
    test_clipping_at_screen_edges();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
