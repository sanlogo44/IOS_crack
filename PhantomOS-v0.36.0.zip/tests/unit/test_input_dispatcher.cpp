/*
 * Phantom OS - Input Dispatcher Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/input_dispatcher.h"
#include "phantom/gui/window_manager.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_touch_down_routing() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    Window::WindowId winId = wm.createWindow("Test", "com.app", Rect(10, 10, 100, 100));
    wm.showWindow(winId);
    wm.focusWindow(winId);

    InputEvent event;
    event.type = InputEventType::TOUCH_DOWN;
    event.x = 50;
    event.y = 50;

    Window::WindowId target = id.dispatch(event);
    ASSERT(target == winId, "Touch inside window should route to that window");
    ASSERT(id.getActiveTouchWindow() == winId, "Active touch window should be set");

    return true;
}

bool test_touch_outside_window() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    Window::WindowId winId = wm.createWindow("Test", "com.app", Rect(10, 10, 100, 100));
    wm.showWindow(winId);

    InputEvent event;
    event.type = InputEventType::TOUCH_DOWN;
    event.x = 200;
    event.y = 200;

    Window::WindowId target = id.dispatch(event);
    ASSERT(target == 0, "Touch outside all windows should return 0");
    ASSERT(id.getActiveTouchWindow() == 0, "Active touch should not be set");

    return true;
}

bool test_touch_move_follows_active() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    Window::WindowId winId = wm.createWindow("Test", "com.app", Rect(0, 0, 200, 200));
    wm.showWindow(winId);
    wm.focusWindow(winId);

    // Touch down inside the window
    InputEvent down;
    down.type = InputEventType::TOUCH_DOWN;
    down.x = 50;
    down.y = 50;
    id.dispatch(down);

    // Touch move — even if it goes outside the window, should still route to active window
    InputEvent move;
    move.type = InputEventType::TOUCH_MOVE;
    move.x = 250;  // Outside window bounds
    move.y = 250;
    Window::WindowId target = id.dispatch(move);
    ASSERT(target == winId, "Touch move should follow active touch window");

    // Touch up
    InputEvent up;
    up.type = InputEventType::TOUCH_UP;
    up.x = 250;
    up.y = 250;
    id.dispatch(up);

    // After touch up, active touch should be cleared
    ASSERT(id.getActiveTouchWindow() == 0, "Active touch should be cleared after TOUCH_UP");

    return true;
}

bool test_event_queue() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    Window::WindowId winId = wm.createWindow("Test", "com.app", Rect(0, 0, 100, 100));
    wm.showWindow(winId);

    // Queue several events
    InputEvent e1;
    e1.type = InputEventType::TOUCH_DOWN;
    e1.x = 50;
    e1.y = 50;

    InputEvent e2;
    e2.type = InputEventType::TOUCH_UP;
    e2.x = 50;
    e2.y = 50;

    id.queueEvent(e1);
    id.queueEvent(e2);

    ASSERT(id.getPendingEventCount() == 2, "Should have 2 pending events");
    ASSERT(id.hasPendingEvents(), "Should have pending events");

    int callbackCount = 0;
    id.processQueue([&callbackCount](const GuiEvent&) { callbackCount++; });

    ASSERT(callbackCount == 2, "Callback should be called 2 times");
    ASSERT(id.getPendingEventCount() == 0, "Queue should be empty after processing");
    ASSERT(id.getTotalEventsDispatched() >= 2, "Total dispatched should be >= 2");

    return true;
}

bool test_gui_event_coordinates() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    Window::WindowId winId = wm.createWindow("Test", "com.app", Rect(20, 30, 100, 100));
    wm.showWindow(winId);

    InputEvent event;
    event.type = InputEventType::TOUCH_DOWN;
    event.x = 50;  // Screen coordinate
    event.y = 60;
    event.timestamp = 12345;

    GuiEvent capturedEvent;
    id.dispatch(event, [&capturedEvent](const GuiEvent& e) { capturedEvent = e; });

    ASSERT(capturedEvent.targetWindowId == winId, "Target window should be correct");
    ASSERT(capturedEvent.screenX == 50, "Screen X should be 50");
    ASSERT(capturedEvent.screenY == 60, "Screen Y should be 60");
    ASSERT(capturedEvent.x == 30, "Window-local X should be 50-20=30");
    ASSERT(capturedEvent.y == 30, "Window-local Y should be 60-30=30");
    ASSERT(capturedEvent.timestamp == 12345, "Timestamp should be preserved");

    return true;
}

bool test_non_touchable_window() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    auto& id = InputDispatcher::getInstance();
    id.clearQueue();
    id.clearActiveTouch();

    // Create a non-touchable window
    Window::WindowId winId = wm.createWindow("NoTouch", "com.app", Rect(0, 0, 100, 100),
                                             WindowFlags::FOCUSABLE);  // No TOUCHABLE flag
    wm.showWindow(winId);

    InputEvent event;
    event.type = InputEventType::TOUCH_DOWN;
    event.x = 50;
    event.y = 50;

    Window::WindowId target = id.dispatch(event);
    ASSERT(target == 0, "Touch on non-touchable window should not be dispatched");

    return true;
}

int main() {
    printf("=== Input Dispatcher Tests ===\n");
    test_touch_down_routing();
    test_touch_outside_window();
    test_touch_move_follows_active();
    test_event_queue();
    test_gui_event_coordinates();
    test_non_touchable_window();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
