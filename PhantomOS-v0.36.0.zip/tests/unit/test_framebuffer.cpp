/*
 * Phantom OS - Framebuffer Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/framebuffer.h"
#include "phantom/gui/color.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_framebuffer_creation() {
    Framebuffer fb(100, 50);
    ASSERT(fb.getWidth() == 100, "Width should be 100");
    ASSERT(fb.getHeight() == 50, "Height should be 50");
    ASSERT(fb.isValid(), "Should be valid");
    ASSERT(fb.getPixelCount() == 5000, "Pixel count should be 5000");

    Framebuffer empty(0, 0);
    ASSERT(!empty.isValid(), "0x0 framebuffer should be invalid");

    return true;
}

bool test_pixel_operations() {
    Framebuffer fb(10, 10);
    fb.clear(Color::Black);

    // Set a pixel
    fb.setPixel(5, 5, Color::Red);
    Color px = fb.getPixel(5, 5);
    ASSERT(px == Color::Red, "Pixel at (5,5) should be Red after set");

    // Out of bounds should return transparent / false
    ASSERT(!fb.setPixel(-1, 0, Color::White), "SetPixel out of bounds should return false");
    ASSERT(!fb.setPixel(10, 0, Color::White), "SetPixel at x=width should return false");
    ASSERT(fb.getPixel(-1, 0) == Color::Transparent, "GetPixel out of bounds should return transparent");

    return true;
}

bool test_clear() {
    Framebuffer fb(20, 20);
    fb.clear(Color::Blue);

    // All pixels should be blue
    for (int32_t y = 0; y < 20; ++y) {
        for (int32_t x = 0; x < 20; ++x) {
            ASSERT(fb.getPixel(x, y) == Color::Blue, "All pixels should be Blue after clear");
        }
    }

    return true;
}

bool test_fill_rect() {
    Framebuffer fb(100, 100);
    fb.clear(Color::Black);

    // Fill a rect
    fb.fillRect(Rect(10, 10, 20, 20), Color::Red);

    // Inside the rect should be red
    ASSERT(fb.getPixel(15, 15) == Color::Red, "Pixel inside fillRect should be Red");
    ASSERT(fb.getPixel(10, 10) == Color::Red, "Top-left of fillRect should be Red");

    // Outside should still be black
    ASSERT(fb.getPixel(5, 5) == Color::Black, "Pixel outside fillRect should be Black");
    ASSERT(fb.getPixel(35, 35) == Color::Black, "Pixel outside fillRect should be Black");

    return true;
}

bool test_fill_rect_clipping() {
    Framebuffer fb(50, 50);
    fb.clear(Color::Black);

    // Fill rect that extends beyond the framebuffer
    fb.fillRect(Rect(40, 40, 20, 20), Color::Green);

    // Should be clipped to framebuffer bounds
    ASSERT(fb.getPixel(45, 45) == Color::Green, "Clipped rect should still fill within bounds");
    ASSERT(fb.getPixel(49, 49) == Color::Green, "Corner pixel should be Green");

    // Fill rect entirely outside
    fb.fillRect(Rect(100, 100, 10, 10), Color::Red);
    // Nothing should change
    ASSERT(fb.getPixel(0, 0) == Color::Black, "Entirely outside rect should not affect pixels");

    return true;
}

bool test_blit() {
    Framebuffer src(10, 10);
    src.clear(Color::Blue);
    src.fillRect(Rect(2, 2, 6, 6), Color::Red);

    Framebuffer dst(50, 50);
    dst.clear(Color::Black);

    dst.blit(src, 10, 10);

    // Check that the source was copied
    ASSERT(dst.getPixel(10, 10) == Color::Blue, "Blitted pixel should be Blue");
    ASSERT(dst.getPixel(12, 12) == Color::Red, "Blitted center should be Red");
    ASSERT(dst.getPixel(19, 19) == Color::Blue, "Blitted corner should be Blue");

    // Outside the blitted area should be black
    ASSERT(dst.getPixel(5, 5) == Color::Black, "Pixel outside blit area should be Black");
    ASSERT(dst.getPixel(21, 21) == Color::Black, "Pixel outside blit area should be Black");

    return true;
}

bool test_alpha_blending() {
    Framebuffer fb(10, 10);
    fb.clear(Color::Black);

    // Blit with alpha blending — semi-transparent red over black
    Framebuffer src(5, 5);
    src.clear(Color(255, 0, 0, 128));  // Red at 50% alpha

    fb.blitBlended(src, 0, 0);

    // Result should be ~50% red over black = (128, 0, 0)
    Color result = fb.getPixel(2, 2);
    ASSERT(result.r >= 120 && result.r <= 136, "Alpha-blended red.r should be ~128");
    ASSERT(result.g == 0, "Alpha-blended red.g should be 0");
    ASSERT(result.b == 0, "Alpha-blended red.b should be 0");

    return true;
}

bool test_color_blend_function() {
    Color src(255, 0, 0, 128);  // 50% red
    Color dst(0, 0, 255, 255);  // opaque blue

    Color blended = blend(src, dst);
    // Should be roughly (128, 0, 127)
    ASSERT(blended.r >= 120 && blended.r <= 136, "Blend r should be ~128");
    ASSERT(blended.g == 0, "Blend g should be 0");
    ASSERT(blended.b >= 120 && blended.b <= 136, "Blend b should be ~127");

    // Full opacity src should return src
    Color opaque(255, 0, 0, 255);
    Color bg(0, 0, 255, 255);
    ASSERT(blend(opaque, bg) == opaque, "Opaque src should return src");

    // Zero alpha src should return dst
    Color transparent(255, 0, 0, 0);
    ASSERT(blend(transparent, bg) == bg, "Transparent src should return dst");

    return true;
}

int main() {
    printf("=== Framebuffer Tests ===\n");
    test_framebuffer_creation();
    test_pixel_operations();
    test_clear();
    test_fill_rect();
    test_fill_rect_clipping();
    test_blit();
    test_alpha_blending();
    test_color_blend_function();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
