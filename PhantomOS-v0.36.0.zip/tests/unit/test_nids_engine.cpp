/*
 * Phantom OS - NIDS Engine Unit Tests
 * Tests for the Network Intrusion Detection System
 *
 * License: GPL-3.0
 */

#include "phantom/nids/nids_engine.h"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace phantom::nids;

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %-50s ", #name); \
    name(); \
    printf("PASS\n"); \
    tests_passed++; \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

// ============================================================
// Tests
// ============================================================

void testInitialization() {
    NidsEngine nids;
    ASSERT_FALSE(nids.isInitialized());

    nids.initialize();
    ASSERT_TRUE(nids.isInitialized());
    ASSERT_EQ(nids.getState(), NidsState::INITIALIZED);

    nids.shutdown();
    ASSERT_EQ(nids.getState(), NidsState::SHUTDOWN);
}

void testStartMonitoring() {
    NidsEngine nids;
    nids.initialize();

    nids.startMonitoring();
    ASSERT_EQ(nids.getState(), NidsState::MONITORING);
    ASSERT_TRUE(nids.isMonitoring());

    nids.pauseMonitoring();
    ASSERT_EQ(nids.getState(), NidsState::PAUSED);
    ASSERT_FALSE(nids.isMonitoring());

    nids.startMonitoring();
    ASSERT_TRUE(nids.isMonitoring());

    nids.shutdown();
}

void testDefaultRules() {
    NidsEngine nids;
    nids.initialize();

    ASSERT_GT(nids.getRuleCount(), 0u);
    ASSERT_GT(nids.getActiveRuleCount(), 0u);

    auto rules = nids.getRules();
    ASSERT_GE(rules.size(), 5u);

    nids.shutdown();
}

void testAddRemoveRule() {
    NidsEngine nids;
    nids.initialize();

    size_t initial = nids.getRuleCount();

    DetectionRule rule;
    rule.name = "Custom Rule";
    rule.description = "Test rule";
    rule.type = DetectionRuleType::PORT_SCAN;
    rule.severity = AlertSeverity::MEDIUM;
    rule.threshold = 5;
    rule.timeWindowMs = 1000;

    uint32_t id = nids.addRule(rule);
    ASSERT_GT(id, 0u);
    ASSERT_EQ(nids.getRuleCount(), initial + 1);

    bool removed = nids.removeRule(id);
    ASSERT_TRUE(removed);
    ASSERT_EQ(nids.getRuleCount(), initial);

    nids.shutdown();
}

void testEnableDisableRule() {
    NidsEngine nids;
    nids.initialize();

    auto rules = nids.getRules();
    ASSERT_FALSE(rules.empty());

    uint32_t ruleId = rules[0].id;
    size_t activeBefore = nids.getActiveRuleCount();

    bool disabled = nids.disableRule(ruleId);
    ASSERT_TRUE(disabled);
    ASSERT_EQ(nids.getActiveRuleCount(), activeBefore - 1);

    bool enabled = nids.enableRule(ruleId);
    ASSERT_TRUE(enabled);
    ASSERT_EQ(nids.getActiveRuleCount(), activeBefore);

    // Disable non-existent rule
    bool result = nids.disableRule(99999);
    ASSERT_FALSE(result);

    nids.shutdown();
}

void testConnectionRegistration() {
    NidsEngine nids;
    nids.initialize();

    NetworkConnection conn;
    conn.sourceIp = "192.168.1.100";
    conn.destIp = "192.168.1.1";
    conn.sourcePort = 50000;
    conn.destPort = 80;
    conn.protocol = 6;
    conn.state = ConnectionState::NEW;
    conn.isInbound = true;
    conn.packetCount = 10;
    conn.byteCount = 640;

    uint32_t id = nids.registerConnection(conn);
    ASSERT_GT(id, 0u);
    ASSERT_EQ(nids.getActiveConnectionCount(), 1u);
    ASSERT_EQ(nids.getTotalConnectionCount(), 1u);

    nids.shutdown();
}

void testConnectionClose() {
    NidsEngine nids;
    nids.initialize();

    NetworkConnection conn;
    conn.sourceIp = "10.0.0.1";
    conn.destIp = "10.0.0.2";
    conn.destPort = 443;
    conn.state = ConnectionState::NEW;
    uint32_t id = nids.registerConnection(conn);

    ASSERT_EQ(nids.getActiveConnectionCount(), 1u);

    bool closed = nids.closeConnection(id);
    ASSERT_TRUE(closed);
    ASSERT_EQ(nids.getActiveConnectionCount(), 0u);

    nids.shutdown();
}

void testPortScanDetection() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.100", 1, 20);

    auto alerts = nids.getAlerts();
    ASSERT_FALSE(alerts.empty());

    bool foundPortScan = false;
    for (const auto& a : alerts) {
        if (a.type == AlertType::PORT_SCAN) {
            foundPortScan = true;
            ASSERT_GE(a.severity, AlertSeverity::HIGH);
            break;
        }
    }
    ASSERT_TRUE(foundPortScan);

    nids.shutdown();
}

void testDdosDetection() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulateDdosAttack("192.168.1.1", 60);

    auto alerts = nids.getAlerts();
    ASSERT_FALSE(alerts.empty());

    bool foundDdos = false;
    for (const auto& a : alerts) {
        if (a.type == AlertType::DDOS_ATTACK) {
            foundDdos = true;
            ASSERT_EQ(a.severity, AlertSeverity::CRITICAL);
            break;
        }
    }
    ASSERT_TRUE(foundDdos);

    nids.shutdown();
}

void testFloodDetection() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePacketFlood("10.0.0.50", 1500);

    auto alerts = nids.getAlerts();
    ASSERT_FALSE(alerts.empty());

    bool foundFlood = false;
    for (const auto& a : alerts) {
        if (a.type == AlertType::PACKET_FLOOD) {
            foundFlood = true;
            break;
        }
    }
    ASSERT_TRUE(foundFlood);

    nids.shutdown();
}

void testUnauthorizedAccessDetection() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulateUnauthorizedAccess("10.0.0.99", 22);

    auto alerts = nids.getAlerts();
    ASSERT_FALSE(alerts.empty());

    bool foundUnauthorized = false;
    for (const auto& a : alerts) {
        if (a.type == AlertType::UNAUTHORIZED_ACCESS) {
            foundUnauthorized = true;
            break;
        }
    }
    ASSERT_TRUE(foundUnauthorized);

    nids.shutdown();
}

void testNormalTrafficNoAlert() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulateNormalTraffic(10);

    auto alerts = nids.getAlerts();
    ASSERT_TRUE(alerts.empty());

    nids.shutdown();
}

void testAlertManagement() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.1", 1, 15);

    size_t alertCount = nids.getAlertCount();
    ASSERT_GT(alertCount, 0u);
    ASSERT_EQ(nids.getUnacknowledgedAlertCount(), alertCount);

    auto alerts = nids.getAlerts();
    uint32_t alertId = alerts[0].id;

    bool ack = nids.acknowledgeAlert(alertId);
    ASSERT_TRUE(ack);
    ASSERT_EQ(nids.getUnacknowledgedAlertCount(), alertCount - 1);

    nids.clearAlerts();
    ASSERT_EQ(nids.getAlertCount(), 0u);

    nids.shutdown();
}

void testAcknowledgeAllAlerts() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.1", 1, 15);
    nids.simulatePacketFlood("10.0.0.2", 2000);

    ASSERT_GT(nids.getUnacknowledgedAlertCount(), 0u);

    bool acked = nids.acknowledgeAllAlerts();
    ASSERT_TRUE(acked);
    ASSERT_EQ(nids.getUnacknowledgedAlertCount(), 0u);

    nids.shutdown();
}

void testAlertsBySeverity() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.1", 1, 15);
    nids.simulateDdosAttack("192.168.1.1", 60);

    auto criticalAlerts = nids.getAlertsBySeverity(AlertSeverity::CRITICAL);
    ASSERT_FALSE(criticalAlerts.empty());

    auto highAlerts = nids.getAlertsBySeverity(AlertSeverity::HIGH);
    ASSERT_FALSE(highAlerts.empty());

    nids.shutdown();
}

void testFirewallBlock() {
    NidsEngine nids;
    nids.initialize();

    uint32_t ruleId = nids.blockIp("10.0.0.666", "0-65535", "Test block");
    ASSERT_GT(ruleId, 0u);

    ASSERT_TRUE(nids.isIpBlocked("10.0.0.666"));

    auto rules = nids.getActiveFirewallRules();
    ASSERT_FALSE(rules.empty());

    nids.shutdown();
}

void testFirewallUnblock() {
    NidsEngine nids;
    nids.initialize();

    uint32_t ruleId = nids.blockIp("10.0.0.777", "0-65535", "Test block");
    ASSERT_TRUE(nids.isIpBlocked("10.0.0.777"));

    bool unblocked = nids.unblockIp(ruleId);
    ASSERT_TRUE(unblocked);
    ASSERT_FALSE(nids.isIpBlocked("10.0.0.777"));

    nids.shutdown();
}

void testFirewallUnblockByIp() {
    NidsEngine nids;
    nids.initialize();

    nids.blockIp("10.0.0.888", "0-65535", "Test block");
    ASSERT_TRUE(nids.isIpBlocked("10.0.0.888"));

    bool unblocked = nids.unblockIp("10.0.0.888");
    ASSERT_TRUE(unblocked);
    ASSERT_FALSE(nids.isIpBlocked("10.0.0.888"));

    nids.shutdown();
}

void testFirewallBlockDuplicate() {
    NidsEngine nids;
    nids.initialize();

    uint32_t id1 = nids.blockIp("10.0.0.999", "0-65535", "First block");
    uint32_t id2 = nids.blockIp("10.0.0.999", "0-65535", "Second block");

    // Should return same rule ID for duplicate
    ASSERT_EQ(id1, id2);

    nids.shutdown();
}

void testFirewallClearRules() {
    NidsEngine nids;
    nids.initialize();

    nids.blockIp("10.0.0.1", "0-65535", "Block 1");
    nids.blockIp("10.0.0.2", "0-65535", "Block 2");
    ASSERT_GT(nids.getFirewallRuleCount(), 0u);

    nids.clearFirewallRules();
    ASSERT_EQ(nids.getFirewallRuleCount(), 0u);

    nids.shutdown();
}

void testEventLogging() {
    NidsEngine nids;
    nids.initialize();

    nids.logEvent("Test event", AlertSeverity::INFO, "TEST");

    auto events = nids.getEvents();
    ASSERT_FALSE(events.empty());

    nids.clearEvents();
    ASSERT_EQ(nids.getEventCount(), 0u);

    nids.shutdown();
}

void testEventsBySeverity() {
    NidsEngine nids;
    nids.initialize();

    nids.logEvent("Info event", AlertSeverity::INFO);
    nids.logEvent("High event", AlertSeverity::HIGH);

    auto highEvents = nids.getEventsBySeverity(AlertSeverity::HIGH);
    ASSERT_FALSE(highEvents.empty());

    nids.shutdown();
}

void testTrafficStats() {
    NidsEngine nids;
    nids.initialize();

    nids.simulateNormalTraffic(5);

    auto stats = nids.getTrafficStats();
    ASSERT_GT(stats.totalPackets, 0ull);
    ASSERT_GT(stats.totalConnections, 0u);
    ASSERT_GT(stats.activeConnections, 0u);

    nids.resetTrafficStats();
    stats = nids.getTrafficStats();
    ASSERT_EQ(stats.totalPackets, 0ull);

    nids.shutdown();
}

void testBlockedPackets() {
    NidsEngine nids;
    nids.initialize();

    // Register a connection then block the IP
    NetworkConnection conn;
    conn.sourceIp = "10.0.0.555";
    conn.destIp = "192.168.1.1";
    conn.destPort = 80;
    conn.state = ConnectionState::NEW;
    conn.packetCount = 100;
    conn.byteCount = 6400;
    nids.registerConnection(conn);

    nids.blockIp("10.0.0.555");

    auto stats = nids.getTrafficStats();
    ASSERT_GT(stats.blockedPackets, 0ull);

    nids.shutdown();
}

void testAlertCallback() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    bool callbackCalled = false;
    AlertType receivedType = AlertType::CUSTOM;
    nids.setAlertCallback([&callbackCalled, &receivedType](const SecurityAlert& alert) {
        callbackCalled = true;
        receivedType = alert.type;
    });

    nids.simulatePortScan("10.0.0.1", 1, 15);

    ASSERT_TRUE(callbackCalled);
    ASSERT_EQ(receivedType, AlertType::PORT_SCAN);

    nids.shutdown();
}

void testEventCallback() {
    NidsEngine nids;
    nids.initialize();

    bool callbackCalled = false;
    nids.setEventCallback([&callbackCalled](const SecurityEvent&) {
        callbackCalled = true;
    });

    nids.logEvent("Test event", AlertSeverity::INFO);

    ASSERT_TRUE(callbackCalled);

    nids.shutdown();
}

void testStringHelpers() {
    ASSERT_STREQ(NidsEngine::alertTypeToString(AlertType::PORT_SCAN), "PORT_SCAN");
    ASSERT_STREQ(NidsEngine::alertTypeToString(AlertType::DDOS_ATTACK), "DDOS_ATTACK");
    ASSERT_STREQ(NidsEngine::alertTypeToString(AlertType::PACKET_FLOOD), "PACKET_FLOOD");
    ASSERT_STREQ(NidsEngine::alertTypeToString(AlertType::UNAUTHORIZED_ACCESS), "UNAUTHORIZED_ACCESS");

    ASSERT_STREQ(NidsEngine::alertSeverityToString(AlertSeverity::INFO), "INFO");
    ASSERT_STREQ(NidsEngine::alertSeverityToString(AlertSeverity::LOW), "LOW");
    ASSERT_STREQ(NidsEngine::alertSeverityToString(AlertSeverity::MEDIUM), "MEDIUM");
    ASSERT_STREQ(NidsEngine::alertSeverityToString(AlertSeverity::HIGH), "HIGH");
    ASSERT_STREQ(NidsEngine::alertSeverityToString(AlertSeverity::CRITICAL), "CRITICAL");

    ASSERT_STREQ(NidsEngine::detectionRuleTypeToString(DetectionRuleType::PORT_SCAN), "PORT_SCAN");
    ASSERT_STREQ(NidsEngine::detectionRuleTypeToString(DetectionRuleType::DDOS), "DDOS");
    ASSERT_STREQ(NidsEngine::detectionRuleTypeToString(DetectionRuleType::FLOOD), "FLOOD");

    ASSERT_STREQ(NidsEngine::firewallActionToString(FirewallAction::BLOCK), "BLOCK");
    ASSERT_STREQ(NidsEngine::firewallActionToString(FirewallAction::UNBLOCK), "UNBLOCK");

    ASSERT_STREQ(NidsEngine::connectionStateToString(ConnectionState::NEW), "NEW");
    ASSERT_STREQ(NidsEngine::connectionStateToString(ConnectionState::ESTABLISHED), "ESTABLISHED");
    ASSERT_STREQ(NidsEngine::connectionStateToString(ConnectionState::CLOSED), "CLOSED");
    ASSERT_STREQ(NidsEngine::connectionStateToString(ConnectionState::BLOCKED), "BLOCKED");

    ASSERT_STREQ(NidsEngine::nidsStateToString(NidsState::IDLE), "IDLE");
    ASSERT_STREQ(NidsEngine::nidsStateToString(NidsState::INITIALIZED), "INITIALIZED");
    ASSERT_STREQ(NidsEngine::nidsStateToString(NidsState::MONITORING), "MONITORING");
    ASSERT_STREQ(NidsEngine::nidsStateToString(NidsState::PAUSED), "PAUSED");
    ASSERT_STREQ(NidsEngine::nidsStateToString(NidsState::SHUTDOWN), "SHUTDOWN");
}

void testReinitialization() {
    NidsEngine nids;

    nids.initialize();
    ASSERT_TRUE(nids.isInitialized());

    nids.shutdown();
    ASSERT_EQ(nids.getState(), NidsState::SHUTDOWN);

    nids.initialize();
    ASSERT_TRUE(nids.isInitialized());

    nids.simulatePortScan("10.0.0.1", 1, 15);
    ASSERT_GT(nids.getAlertCount(), 0u);

    nids.shutdown();
}

void testClearConnections() {
    NidsEngine nids;
    nids.initialize();

    nids.simulateNormalTraffic(5);
    ASSERT_GT(nids.getActiveConnectionCount(), 0u);

    nids.clearConnections();
    ASSERT_EQ(nids.getActiveConnectionCount(), 0u);

    nids.shutdown();
}

void testGetAlert() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.1", 1, 15);

    auto alerts = nids.getAlerts();
    ASSERT_FALSE(alerts.empty());

    uint32_t alertId = alerts[0].id;
    auto alert = nids.getAlert(alertId);
    ASSERT_EQ(alert.id, alertId);

    // Non-existent alert
    auto notFound = nids.getAlert(99999);
    ASSERT_EQ(notFound.id, 0u);

    nids.shutdown();
}

void testMultipleSimulations() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    nids.simulatePortScan("10.0.0.1", 1, 15);
    nids.simulateDdosAttack("192.168.1.1", 60);
    nids.simulatePacketFlood("10.0.0.2", 2000);
    nids.simulateUnauthorizedAccess("10.0.0.3", 22);

    ASSERT_GT(nids.getAlertCount(), 3u);
    ASSERT_GT(nids.getEventCount(), 3u);

    nids.shutdown();
}

void testRunDetection() {
    NidsEngine nids;
    nids.initialize();
    nids.startMonitoring();

    // Add connections that would trigger detection
    for (int i = 0; i < 15; ++i) {
        NetworkConnection conn;
        conn.sourceIp = "10.0.0.1";
        conn.destIp = "192.168.1.1";
        conn.destPort = 80 + i;
        conn.state = ConnectionState::NEW;
        conn.isInbound = true;
        conn.packetCount = 1;
        nids.registerConnection(conn);
    }

    nids.runDetection();

    // Should detect port scan
    bool found = false;
    for (const auto& a : nids.getAlerts()) {
        if (a.type == AlertType::PORT_SCAN) {
            found = true;
            break;
        }
    }
    ASSERT_TRUE(found);

    nids.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("=== NIDS Engine Tests ===\n\n");

    printf("--- Lifecycle ---\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testStartMonitoring);
    RUN_TEST(testReinitialization);

    printf("\n--- Detection Rules ---\n");
    RUN_TEST(testDefaultRules);
    RUN_TEST(testAddRemoveRule);
    RUN_TEST(testEnableDisableRule);

    printf("\n--- Connection Monitoring ---\n");
    RUN_TEST(testConnectionRegistration);
    RUN_TEST(testConnectionClose);
    RUN_TEST(testClearConnections);

    printf("\n--- Attack Detection ---\n");
    RUN_TEST(testPortScanDetection);
    RUN_TEST(testDdosDetection);
    RUN_TEST(testFloodDetection);
    RUN_TEST(testUnauthorizedAccessDetection);
    RUN_TEST(testNormalTrafficNoAlert);
    RUN_TEST(testRunDetection);
    RUN_TEST(testMultipleSimulations);

    printf("\n--- Alert Management ---\n");
    RUN_TEST(testAlertManagement);
    RUN_TEST(testAcknowledgeAllAlerts);
    RUN_TEST(testAlertsBySeverity);
    RUN_TEST(testGetAlert);

    printf("\n--- Firewall ---\n");
    RUN_TEST(testFirewallBlock);
    RUN_TEST(testFirewallUnblock);
    RUN_TEST(testFirewallUnblockByIp);
    RUN_TEST(testFirewallBlockDuplicate);
    RUN_TEST(testFirewallClearRules);
    RUN_TEST(testBlockedPackets);

    printf("\n--- Event Logging ---\n");
    RUN_TEST(testEventLogging);
    RUN_TEST(testEventsBySeverity);

    printf("\n--- Traffic Stats ---\n");
    RUN_TEST(testTrafficStats);

    printf("\n--- Callbacks ---\n");
    RUN_TEST(testAlertCallback);
    RUN_TEST(testEventCallback);

    printf("\n--- String Helpers ---\n");
    RUN_TEST(testStringHelpers);

    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);

    return tests_failed > 0 ? 1 : 0;
}
