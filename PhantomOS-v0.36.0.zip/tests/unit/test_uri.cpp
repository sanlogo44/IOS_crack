/*
 * Phantom OS - URI Parser Tests
 *
 * License: GPL-3.0
 */

#include "phantom/uri/uri_parser.h"
#include <cassert>
#include <cstdio>

using namespace phantom::uri;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_valid_uri() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://settings", uri), "Should parse valid URI");
    ASSERT(uri.scheme == "phapp", "Scheme should be 'phapp'");
    ASSERT(uri.appId == "settings", "AppId should be 'settings'");
    ASSERT(uri.path.empty(), "Path should be empty");
    ASSERT(uri.isValid(), "URI should be valid");
    return true;
}

bool test_uri_with_path() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://settings/wifi", uri), "Should parse URI with path");
    ASSERT(uri.appId == "settings", "AppId should be 'settings'");
    ASSERT(uri.path == "wifi", "Path should be 'wifi'");
    return true;
}

bool test_uri_with_query() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://camera/photo?mode=burst&flash=auto", uri), "Should parse URI with query");
    ASSERT(uri.appId == "camera", "AppId should be 'camera'");
    ASSERT(uri.path == "photo", "Path should be 'photo'");
    ASSERT(uri.hasParam("mode"), "Should have 'mode' param");
    ASSERT(uri.getParam("mode") == "burst", "mode param should be 'burst'");
    ASSERT(uri.getParam("flash") == "auto", "flash param should be 'auto'");
    return true;
}

bool test_invalid_scheme() {
    PhAppUri uri;
    ASSERT(!UriParser::parse("http://settings", uri), "Should reject http scheme");
    ASSERT(!UriParser::parse("settings", uri), "Should reject missing scheme");
    ASSERT(!UriParser::parse("phapp://", uri), "Should reject empty appId");
    return true;
}

bool test_invalid_appid() {
    PhAppUri uri;
    ASSERT(!UriParser::parse("phapp://app@id", uri), "Should reject invalid chars in appId");
    ASSERT(!UriParser::parse("phapp://app id", uri), "Should reject spaces in appId");
    return true;
}

bool test_valid_appids() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://my-app", uri), "Should accept dash in appId");
    ASSERT(UriParser::parse("phapp://my_app", uri), "Should accept underscore in appId");
    ASSERT(UriParser::parse("phapp://my.app", uri), "Should accept dot in appId");
    ASSERT(UriParser::parse("phapp://App123", uri), "Should accept alphanumeric in appId");
    return true;
}

bool test_query_param_methods() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://test?key1=val1&key2=val2&key3=", uri), "Should parse multiple params");
    ASSERT(uri.getParam("key1") == "val1", "key1 should be 'val1'");
    ASSERT(uri.getParam("key2") == "val2", "key2 should be 'val2'");
    ASSERT(uri.getParam("key3") == "", "key3 should be empty");
    ASSERT(uri.getParam("nonexistent", "default") == "default", "Missing param should return default");

    auto keys = uri.getParamKeys();
    ASSERT(keys.size() == 3, "Should have 3 param keys");
    return true;
}

bool test_to_string() {
    PhAppUri uri;
    UriParser::parse("phapp://settings/wifi", uri);
    std::string str = uri.toString();
    ASSERT(str == "phapp://settings/wifi", "toString should reconstruct URI");

    PhAppUri uri2;
    UriParser::parse("phapp://camera?mode=auto", uri2);
    std::string str2 = uri2.toString();
    ASSERT(str2 == "phapp://camera?mode=auto", "toString should reconstruct URI with query");
    return true;
}

bool test_get_scheme() {
    ASSERT(UriParser::getScheme("phapp://test") == "phapp", "Scheme should be 'phapp'");
    ASSERT(UriParser::getScheme("http://test") == "http", "Scheme should be 'http'");
    ASSERT(UriParser::getScheme("invalid").empty(), "Scheme should be empty for invalid URI");
    return true;
}

bool test_is_valid() {
    ASSERT(UriParser::isValid("phapp://settings"), "Valid phapp URI should return true");
    ASSERT(!UriParser::isValid("http://settings"), "Non-phapp URI should return false");
    ASSERT(!UriParser::isValid("phapp://"), "Empty appId should return false");
    return true;
}

bool test_percent_decode() {
    ASSERT(UriParser::percentDecode("hello%20world") == "hello world", "Should decode %20 to space");
    ASSERT(UriParser::percentDecode("a+b") == "a b", "Should decode + to space");
    ASSERT(UriParser::percentDecode("100%25") == "100%", "Should decode %25 to %");
    return true;
}

bool test_percent_encode() {
    std::string encoded = UriParser::percentEncode("hello world");
    ASSERT(encoded == "hello%20world", "Should encode space to %20");

    std::string encoded2 = UriParser::percentEncode("test&123");
    ASSERT(encoded2.find("%26") != std::string::npos, "Should encode & character");
    return true;
}

bool test_query_with_encoded_values() {
    PhAppUri uri;
    ASSERT(UriParser::parse("phapp://search?q=hello%20world", uri), "Should parse encoded query");
    ASSERT(uri.getParam("q") == "hello world", "Should decode %20 in query value");
    return true;
}

int main() {
    printf("=== URI Parser Tests ===\n");
    test_valid_uri();
    test_uri_with_path();
    test_uri_with_query();
    test_invalid_scheme();
    test_invalid_appid();
    test_valid_appids();
    test_query_param_methods();
    test_to_string();
    test_get_scheme();
    test_is_valid();
    test_percent_decode();
    test_percent_encode();
    test_query_with_encoded_values();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
