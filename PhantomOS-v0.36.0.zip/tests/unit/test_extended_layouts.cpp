/*
 * Phantom OS - Extended Layout Tests
 * Tests for RelativeLayout and GridLayout
 *
 * License: GPL-3.0
 */

#include "phantom/gui/extended_layout.h"
#include "phantom/gui/widget.h"
#include "phantom/gui/bitmap_font.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

// ============================================================
// RelativeLayout Tests
// ============================================================

bool test_relativelayout_construction() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto label = std::make_unique<Widget>(2, "label1");
    container.addChild(std::move(label));

    Size s = rl.measure(container);
    ASSERT(s.width >= 0, "Measure should return non-negative width");
    ASSERT(s.height >= 0, "Measure should return non-negative height");
    return true;
}

bool test_relativelayout_align_parent() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(50, 30);
    container.addChild(std::move(child));

    RelativeLayout::LayoutParams params;
    params.alignParentLeft = 1;
    params.alignParentTop = 1;
    rl.setLayoutParams("child1", params);

    rl.layout(container);

    Widget* c = container.getChild(0);
    ASSERT(c->getBounds().x == 0, "Child should be at x=0 (alignParentLeft)");
    ASSERT(c->getBounds().y == 0, "Child should be at y=0 (alignParentTop)");
    return true;
}

bool test_relativelayout_align_parent_right() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(50, 30);
    container.addChild(std::move(child));

    RelativeLayout::LayoutParams params;
    params.alignParentRight = 1;
    params.alignParentBottom = 1;
    rl.setLayoutParams("child1", params);

    rl.layout(container);

    Widget* c = container.getChild(0);
    ASSERT(c->getBounds().right() == 200, "Child right edge should be at 200");
    ASSERT(c->getBounds().bottom() == 200, "Child bottom edge should be at 200");
    return true;
}

bool test_relativelayout_center_in_parent() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(50, 30);
    container.addChild(std::move(child));

    RelativeLayout::LayoutParams params;
    params.centerInParent = 1;
    rl.setLayoutParams("child1", params);

    rl.layout(container);

    Widget* c = container.getChild(0);
    ASSERT(c->getBounds().x == 75, "Centered child x should be (200-50)/2 = 75");
    ASSERT(c->getBounds().y == 85, "Centered child y should be (200-30)/2 = 85");
    return true;
}

bool test_relativelayout_below() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(50, 30);

    container.addChild(std::move(child1));
    container.addChild(std::move(child2));

    RelativeLayout::LayoutParams params1;
    params1.alignParentTop = 1;
    params1.alignParentLeft = 1;
    rl.setLayoutParams("child1", params1);

    RelativeLayout::LayoutParams params2;
    params2.below = "child1";
    params2.alignParentLeft = 1;
    rl.setLayoutParams("child2", params2);

    rl.layout(container);

    Widget* c2 = container.getChild(1);
    ASSERT(c2->getBounds().y == 30, "child2 should be below child1 at y=30");
    return true;
}

bool test_relativelayout_to_right_of() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child1 = std::make_unique<Widget>(2, "child1");
    child1->setPreferredSize(50, 30);
    auto child2 = std::make_unique<Widget>(3, "child2");
    child2->setPreferredSize(40, 30);

    container.addChild(std::move(child1));
    container.addChild(std::move(child2));

    RelativeLayout::LayoutParams params1;
    params1.alignParentLeft = 1;
    params1.alignParentTop = 1;
    rl.setLayoutParams("child1", params1);

    RelativeLayout::LayoutParams params2;
    params2.toRightOf = "child1";
    params2.alignParentTop = 1;
    rl.setLayoutParams("child2", params2);

    rl.layout(container);

    Widget* c2 = container.getChild(1);
    ASSERT(c2->getBounds().x == 50, "child2 should be at x=50 (right of child1)");
    return true;
}

bool test_relativelayout_margins() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 200, 200));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(50, 30);
    container.addChild(std::move(child));

    RelativeLayout::LayoutParams params;
    params.alignParentLeft = 1;
    params.alignParentTop = 1;
    params.marginLeft = 10;
    params.marginTop = 5;
    rl.setLayoutParams("child1", params);

    rl.layout(container);

    Widget* c = container.getChild(0);
    ASSERT(c->getBounds().x == 10, "Child x should be 10 (marginLeft)");
    ASSERT(c->getBounds().y == 5, "Child y should be 5 (marginTop)");
    return true;
}

bool test_relativelayout_default_position() {
    RelativeLayout rl;
    Widget container(1, "container");
    container.setBounds(Rect(10, 10, 200, 200));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(50, 30);
    container.addChild(std::move(child));

    // No params set — should default to top-left of container
    rl.layout(container);

    Widget* c = container.getChild(0);
    ASSERT(c->getBounds().x == 10, "Default child x should be container x (10)");
    ASSERT(c->getBounds().y == 10, "Default child y should be container y (10)");
    return true;
}

// ============================================================
// GridLayout Tests
// ============================================================

bool test_gridlayout_construction() {
    GridLayout gl(2, 3);
    ASSERT(gl.getRows() == 2, "Rows should be 2");
    ASSERT(gl.getColumns() == 3, "Columns should be 3");
    return true;
}

bool test_gridlayout_measure() {
    GridLayout gl(2, 2);
    Widget container(1, "container");

    for (int i = 0; i < 4; ++i) {
        auto child = std::make_unique<Widget>(i + 2, "child" + std::to_string(i));
        child->setPreferredSize(50, 30);
        container.addChild(std::move(child));
    }

    Size s = gl.measure(container);
    ASSERT(s.width > 0, "Grid width should be > 0");
    ASSERT(s.height > 0, "Grid height should be > 0");
    return true;
}

bool test_gridlayout_2x2() {
    GridLayout gl(2, 2);
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    for (int i = 0; i < 4; ++i) {
        auto child = std::make_unique<Widget>(i + 2, "child" + std::to_string(i));
        child->setPreferredSize(30, 20);
        container.addChild(std::move(child));
    }

    gl.layout(container);

    Widget* c0 = container.getChild(0);  // row 0, col 0
    Widget* c1 = container.getChild(1);  // row 0, col 1
    Widget* c2 = container.getChild(2);  // row 1, col 0
    Widget* c3 = container.getChild(3);  // row 1, col 1

    ASSERT(c0->getBounds().x <= c1->getBounds().x, "Col 0 should be left of col 1");
    ASSERT(c2->getBounds().x <= c3->getBounds().x, "Col 0 should be left of col 1 (row 2)");
    ASSERT(c0->getBounds().y <= c2->getBounds().y, "Row 0 should be above row 1");
    ASSERT(c1->getBounds().y <= c3->getBounds().y, "Row 0 should be above row 1 (col 2)");
    return true;
}

bool test_gridlayout_spacing() {
    GridLayout gl(1, 3);
    gl.setSpacing(5);
    ASSERT(gl.getSpacing() == 5, "Spacing should be 5");

    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 50));

    for (int i = 0; i < 3; ++i) {
        auto child = std::make_unique<Widget>(i + 2, "child" + std::to_string(i));
        child->setPreferredSize(20, 20);
        container.addChild(std::move(child));
    }

    gl.layout(container);

    Widget* c0 = container.getChild(0);
    Widget* c2 = container.getChild(2);
    // With spacing, c2 should be further right than c0 + width + spacing
    ASSERT(c2->getBounds().x > c0->getBounds().x + 20, "Spacing should create gap");
    return true;
}

bool test_gridlayout_cell_alignment() {
    GridLayout gl(1, 1);
    gl.setCellAlignment(GridLayout::CellAlignment::CENTER);

    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(20, 20);
    container.addChild(std::move(child));

    gl.layout(container);

    Widget* c = container.getChild(0);
    // Center alignment: x = (100-20)/2 = 40, y = (100-20)/2 = 40
    ASSERT(c->getBounds().x == 40, "Centered child x should be 40");
    ASSERT(c->getBounds().y == 40, "Centered child y should be 40");
    return true;
}

bool test_gridlayout_fill_alignment() {
    GridLayout gl(1, 1);
    gl.setCellAlignment(GridLayout::CellAlignment::FILL);

    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child = std::make_unique<Widget>(2, "child1");
    child->setPreferredSize(20, 20);
    container.addChild(std::move(child));

    gl.layout(container);

    Widget* c = container.getChild(0);
    // Fill: child should fill the cell
    ASSERT(c->getBounds().width == 100, "Fill width should be 100");
    ASSERT(c->getBounds().height == 100, "Fill height should be 100");
    return true;
}

bool test_gridlayout_autodetect() {
    GridLayout gl(0, 3);  // 3 columns, auto rows
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 300, 100));

    for (int i = 0; i < 7; ++i) {
        auto child = std::make_unique<Widget>(i + 2, "child" + std::to_string(i));
        child->setPreferredSize(30, 20);
        container.addChild(std::move(child));
    }

    gl.layout(container);

    // 7 items in 3 columns = 3 rows (3+3+1)
    Widget* c0 = container.getChild(0);   // row 0, col 0
    Widget* c6 = container.getChild(6);   // row 2, col 0
    ASSERT(c6->getBounds().y > c0->getBounds().y, "7th item should be in a lower row");
    return true;
}

bool test_gridlayout_span() {
    GridLayout gl(2, 2);
    gl.setCellAlignment(GridLayout::CellAlignment::FILL);

    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    auto child0 = std::make_unique<Widget>(2, "spanning");
    child0->setPreferredSize(30, 20);
    auto child1 = std::make_unique<Widget>(3, "normal");
    child1->setPreferredSize(30, 20);

    container.addChild(std::move(child0));
    container.addChild(std::move(child1));

    gl.setSpan("spanning", 1, 2);  // spans 2 columns

    gl.layout(container);

    Widget* c0 = container.getChild(0);
    // Spanning child should be wider than a single cell
    int32_t cellW = 100 / 2;  // ~50
    ASSERT(c0->getBounds().width > cellW, "Spanning child should be wider than single cell");
    return true;
}

bool test_gridlayout_empty_measure() {
    GridLayout gl;  // Default: 0 rows, 0 columns
    Widget container(1, "container");
    Size s = gl.measure(container);
    ASSERT(s.width == 0, "Empty GridLayout measure width should be 0");
    ASSERT(s.height == 0, "Empty GridLayout measure height should be 0");
    return true;
}

bool test_gridlayout_empty() {
    GridLayout gl(2, 2);
    Widget container(1, "container");
    container.setBounds(Rect(0, 0, 100, 100));

    // No children — should not crash
    gl.layout(container);
    ASSERT(true, "Empty GridLayout layout should not crash");
    return true;
}

int main() {
    printf("=== Extended Layout Tests ===\n");

    // RelativeLayout
    test_relativelayout_construction();
    test_relativelayout_align_parent();
    test_relativelayout_align_parent_right();
    test_relativelayout_center_in_parent();
    test_relativelayout_below();
    test_relativelayout_to_right_of();
    test_relativelayout_margins();
    test_relativelayout_default_position();

    // GridLayout
    test_gridlayout_construction();
    test_gridlayout_measure();
    test_gridlayout_2x2();
    test_gridlayout_spacing();
    test_gridlayout_cell_alignment();
    test_gridlayout_fill_alignment();
    test_gridlayout_autodetect();
    test_gridlayout_span();
    test_gridlayout_empty_measure();
    test_gridlayout_empty();

    printf("\nResults: %d/%d passed (%d tests)\n", pass_count, test_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
