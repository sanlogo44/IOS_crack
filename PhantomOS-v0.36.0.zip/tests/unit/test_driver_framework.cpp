/*
 * Phantom OS - Device Driver Framework Tests
 * v0.16.0 — Driver lifecycle, device management, dependency tests
 *
 * License: GPL-3.0
 */

#include "phantom/drivers/driver_manager.h"
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <functional>

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %s\n", #name); \
    tests_passed++; \
    name(); \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

static void testInitialization() {
    phantom::drivers::DriverManager mgr;
    ASSERT_FALSE(mgr.isInitialized());

    auto result = mgr.initialize();
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
}

static void testReinitialization() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.initialize();
    ASSERT_EQ(result, phantom::drivers::DriverResult::ALREADY_LOADED);
}

static void testShutdown() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.shutdown();
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.getDriverCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getDeviceCount(), static_cast<size_t>(0));
}

static void testDefaultDriversRegistered() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_TRUE(mgr.getDriverCount() >= 12);
    ASSERT_TRUE(mgr.getDefaultDriverCount() >= 12);
}

static void testDefaultDevicesRegistered() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_TRUE(mgr.getDeviceCount() >= 16);
    ASSERT_TRUE(mgr.getDefaultDeviceCount() >= 16);
}

static void testGetDriverByName() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto d = mgr.getDriver("display_driver");
    ASSERT_TRUE(d.id > 0);
    ASSERT_EQ(d.name, "display_driver");
    ASSERT_EQ(d.type, phantom::drivers::DriverType::DISPLAY);
    ASSERT_EQ(d.priority, phantom::drivers::DriverPriority::CRITICAL);
}

static void testGetDriverById() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto all = mgr.getDrivers();
    ASSERT_TRUE(!all.empty());
    auto d = mgr.getDriverById(all[0].id);
    ASSERT_EQ(d.name, all[0].name);
}

static void testGetDriverNotFound() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto d = mgr.getDriver("nonexistent");
    ASSERT_EQ(d.id, 0u);
}

static void testGetDriversByType() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto display = mgr.getDriversByType(phantom::drivers::DriverType::DISPLAY);
    ASSERT_TRUE(display.size() >= 1);
    auto sensors = mgr.getDriversByType(phantom::drivers::DriverType::SENSOR);
    ASSERT_TRUE(sensors.size() >= 1);
}

static void testGetDriversByPriority() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto critical = mgr.getDriversByPriority(phantom::drivers::DriverPriority::CRITICAL);
    ASSERT_TRUE(critical.size() >= 2);  // display + power
}

static void testLoadDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.loadDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::ACTIVE);
}

static void testLoadDriverNotFound() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.loadDriver("nonexistent");
    ASSERT_EQ(result, phantom::drivers::DriverResult::NOT_FOUND);
}

static void testLoadDriverAlreadyLoaded() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.loadDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::ALREADY_LOADED);
}

static void testLoadDriverDependencyFailed() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    // input_driver depends on display_driver, which is not loaded
    auto result = mgr.loadDriver("input_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::DEPENDENCY_FAILED);
    auto d = mgr.getDriver("input_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::ERROR_STATE);
    ASSERT_TRUE(d.errorCount > 0);
}

static void testLoadDriverWithDependencies() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.loadDriver("input_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
}

static void testUnloadDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.unloadDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::UNLOADED);
    ASSERT_EQ(d.boundDevices.size(), static_cast<size_t>(0));
}

static void testSuspendResumeDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.suspendDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::SUSPENDED);

    result = mgr.resumeDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::ACTIVE);
}

static void testSuspendInvalidState() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.suspendDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::INVALID_STATE);
}

static void testReloadDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.reloadDriver("display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::ACTIVE);
}

static void testRegisterCustomDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();

    phantom::drivers::DriverInfo custom;
    custom.name = "custom_driver";
    custom.description = "Custom test driver";
    custom.type = phantom::drivers::DriverType::UNKNOWN;
    custom.priority = phantom::drivers::DriverPriority::OPTIONAL;

    auto id = mgr.registerDriver(custom);
    ASSERT_TRUE(id > 0);
    auto d = mgr.getDriver("custom_driver");
    ASSERT_EQ(d.name, "custom_driver");
}

static void testRegisterDuplicateDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();

    phantom::drivers::DriverInfo dup;
    dup.name = "display_driver";

    auto id = mgr.registerDriver(dup);
    ASSERT_EQ(id, 0u);
}

static void testUnregisterDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();

    phantom::drivers::DriverInfo temp;
    temp.name = "temp_driver";
    mgr.registerDriver(temp);

    bool removed = mgr.unregisterDriver("temp_driver");
    ASSERT_TRUE(removed);
    auto d = mgr.getDriver("temp_driver");
    ASSERT_EQ(d.id, 0u);
}

static void testGetDeviceByName() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto dev = mgr.getDevice("oled_display");
    ASSERT_TRUE(dev.id > 0);
    ASSERT_EQ(dev.name, "oled_display");
    ASSERT_EQ(dev.type, phantom::drivers::DriverType::DISPLAY);
}

static void testGetDeviceById() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto all = mgr.getDevices();
    ASSERT_TRUE(!all.empty());
    auto d = mgr.getDeviceById(all[0].id);
    ASSERT_EQ(d.name, all[0].name);
}

static void testGetDevicesByType() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto display = mgr.getDevicesByType(phantom::drivers::DriverType::DISPLAY);
    ASSERT_TRUE(display.size() >= 1);
    auto power = mgr.getDevicesByType(phantom::drivers::DriverType::POWER);
    ASSERT_TRUE(power.size() >= 2);
}

static void testGetDevicesByStatus() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto detected = mgr.getDevicesByStatus(phantom::drivers::DeviceStatus::DETECTED);
    ASSERT_TRUE(detected.size() > 0);
}

static void testGetDevicesByBus() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto internal = mgr.getDevicesByBus(phantom::drivers::DeviceBus::INTERNAL);
    ASSERT_TRUE(internal.size() >= 1);
    auto i2c = mgr.getDevicesByBus(phantom::drivers::DeviceBus::I2C);
    ASSERT_TRUE(i2c.size() >= 5);
}

static void testBindDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    auto result = mgr.bindDevice("oled_display", "display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto dev = mgr.getDevice("oled_display");
    ASSERT_TRUE(dev.driverId > 0);
    ASSERT_EQ(dev.status, phantom::drivers::DeviceStatus::READY);
}

static void testBindDeviceDriverNotLoaded() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.bindDevice("oled_display", "display_driver");
    ASSERT_EQ(result, phantom::drivers::DriverResult::INVALID_STATE);
}

static void testUnbindDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    mgr.bindDevice("oled_display", "display_driver");
    auto result = mgr.unbindDevice("oled_display");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto dev = mgr.getDevice("oled_display");
    ASSERT_EQ(dev.driverId, 0u);
    ASSERT_EQ(dev.status, phantom::drivers::DeviceStatus::DETECTED);
}

static void testActivateDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    mgr.bindDevice("oled_display", "display_driver");
    auto result = mgr.activateDevice("oled_display");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto dev = mgr.getDevice("oled_display");
    ASSERT_EQ(dev.status, phantom::drivers::DeviceStatus::ACTIVE);
}

static void testActivateDeviceNoDriver() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto result = mgr.activateDevice("oled_display");
    ASSERT_EQ(result, phantom::drivers::DriverResult::DEPENDENCY_FAILED);
}

static void testSuspendDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    mgr.bindDevice("oled_display", "display_driver");
    mgr.activateDevice("oled_display");
    auto result = mgr.suspendDevice("oled_display");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto dev = mgr.getDevice("oled_display");
    ASSERT_EQ(dev.status, phantom::drivers::DeviceStatus::SUSPENDED);
}

static void testRemoveDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    // usb_controller is removable
    auto result = mgr.removeDevice("usb_controller");
    ASSERT_EQ(result, phantom::drivers::DriverResult::SUCCESS);
    auto dev = mgr.getDevice("usb_controller");
    ASSERT_EQ(dev.status, phantom::drivers::DeviceStatus::REMOVED);
}

static void testRemoveNonRemovableDevice() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    // oled_display is not removable
    auto result = mgr.removeDevice("oled_display");
    ASSERT_EQ(result, phantom::drivers::DriverResult::PERMISSION_DENIED);
}

static void testDeviceDiscovery() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.discoverDevices();
    // All devices should be detected
    auto detected = mgr.getDevicesByStatus(phantom::drivers::DeviceStatus::DETECTED);
    ASSERT_TRUE(detected.size() > 0);
}

static void testHotplugDetection() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto hotplug = mgr.detectHotplug();
    ASSERT_TRUE(hotplug.size() >= 1);  // usb_controller
    ASSERT_TRUE(mgr.isHotplugEnabled());
    mgr.setHotplugDetection(false);
    ASSERT_FALSE(mgr.isHotplugEnabled());
}

static void testDependencyResolution() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    // input_driver depends on display_driver
    auto deps = mgr.resolveDriverDependencies("input_driver");
    ASSERT_TRUE(deps.size() >= 2);
    // display_driver should come before input_driver
    auto displayIt = std::find(deps.begin(), deps.end(), "display_driver");
    auto inputIt = std::find(deps.begin(), deps.end(), "input_driver");
    ASSERT_TRUE(displayIt < inputIt);
}

static void testCircularDependency() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();

    phantom::drivers::DriverInfo a;
    a.name = "drv_a";
    a.dependencies = {"drv_b"};

    phantom::drivers::DriverInfo b;
    b.name = "drv_b";
    b.dependencies = {"drv_a"};

    mgr.registerDriver(a);
    mgr.registerDriver(b);

    ASSERT_TRUE(mgr.hasCircularDependency("drv_a"));
}

static void testNoCircularDependency() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.hasCircularDependency("display_driver"));
    ASSERT_FALSE(mgr.hasCircularDependency("camera_driver"));
}

static void testLoadOrder() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    auto order = mgr.getLoadOrder();
    ASSERT_EQ(order.size(), mgr.getDriverCount());

    // display_driver (initOrder=0) should come before input_driver (initOrder=5)
    auto displayIt = std::find(order.begin(), order.end(), "display_driver");
    auto inputIt = std::find(order.begin(), order.end(), "input_driver");
    ASSERT_TRUE(displayIt < inputIt);
}

static void testErrorHandling() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("input_driver");  // Will fail due to dependency

    auto errorCount = mgr.getErrorCount("input_driver");
    ASSERT_TRUE(errorCount > 0);

    mgr.clearErrors("input_driver");
    auto cleared = mgr.getErrorCount("input_driver");
    ASSERT_EQ(cleared, 0u);
}

static void testSetError() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");

    mgr.setError("display_driver", "Hardware failure");
    auto d = mgr.getDriver("display_driver");
    ASSERT_EQ(d.state, phantom::drivers::DriverState::ERROR_STATE);
    ASSERT_TRUE(d.errorCount > 0);
    ASSERT_EQ(d.lastError, "Hardware failure");
}

static void testEvents() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() > 0);
    auto count = mgr.getEventCount();
    ASSERT_EQ(count, events.size());
}

static void testClearEvents() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    mgr.clearEvents();
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));
}

static void testEventCallback() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();

    int callbackCount = 0;
    mgr.setEventCallback([&](const phantom::drivers::DriverEvent&) {
        callbackCount++;
    });

    mgr.loadDriver("display_driver");
    ASSERT_TRUE(callbackCount > 0);
}

static void testStats() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.totalDrivers > 0);
    ASSERT_TRUE(stats.loadedDrivers > 0);
    ASSERT_TRUE(stats.totalDevices > 0);
}

static void testResetStats() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("input_driver");  // Will fail
    mgr.resetStats();
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalErrors, 0u);
}

static void testLoadedDriverCount() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getLoadedDriverCount(), static_cast<size_t>(0));
    mgr.loadDriver("display_driver");
    ASSERT_TRUE(mgr.getLoadedDriverCount() > 0);
}

static void testActiveDriverCount() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getActiveDriverCount(), static_cast<size_t>(0));
    mgr.loadDriver("display_driver");
    ASSERT_TRUE(mgr.getActiveDriverCount() > 0);
}

static void testActiveDeviceCount() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getActiveDeviceCount(), static_cast<size_t>(0));
    mgr.loadDriver("display_driver");
    mgr.bindDevice("oled_display", "display_driver");
    mgr.activateDevice("oled_display");
    ASSERT_TRUE(mgr.getActiveDeviceCount() > 0);
}

static void testStringHelpers() {
    ASSERT_STREQ(phantom::drivers::DriverManager::driverTypeToString(phantom::drivers::DriverType::DISPLAY), "DISPLAY");
    ASSERT_STREQ(phantom::drivers::DriverManager::driverStateToString(phantom::drivers::DriverState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(phantom::drivers::DriverManager::deviceStatusToString(phantom::drivers::DeviceStatus::READY), "READY");
    ASSERT_STREQ(phantom::drivers::DriverManager::driverPriorityToString(phantom::drivers::DriverPriority::CRITICAL), "CRITICAL");
    ASSERT_STREQ(phantom::drivers::DriverManager::driverResultToString(phantom::drivers::DriverResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(phantom::drivers::DriverManager::deviceBusToString(phantom::drivers::DeviceBus::PCIE), "PCIE");
}

static void testShutdownClearsAll() {
    phantom::drivers::DriverManager mgr;
    mgr.initialize();
    mgr.loadDriver("display_driver");
    mgr.bindDevice("oled_display", "display_driver");
    mgr.activateDevice("oled_display");
    mgr.shutdown();
    ASSERT_EQ(mgr.getDriverCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getDeviceCount(), static_cast<size_t>(0));
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));
}

int runAllTests() {
    printf("=== Driver Framework Tests ===\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testReinitialization);
    RUN_TEST(testShutdown);
    RUN_TEST(testDefaultDriversRegistered);
    RUN_TEST(testDefaultDevicesRegistered);
    RUN_TEST(testGetDriverByName);
    RUN_TEST(testGetDriverById);
    RUN_TEST(testGetDriverNotFound);
    RUN_TEST(testGetDriversByType);
    RUN_TEST(testGetDriversByPriority);
    RUN_TEST(testLoadDriver);
    RUN_TEST(testLoadDriverNotFound);
    RUN_TEST(testLoadDriverAlreadyLoaded);
    RUN_TEST(testLoadDriverDependencyFailed);
    RUN_TEST(testLoadDriverWithDependencies);
    RUN_TEST(testUnloadDriver);
    RUN_TEST(testSuspendResumeDriver);
    RUN_TEST(testSuspendInvalidState);
    RUN_TEST(testReloadDriver);
    RUN_TEST(testRegisterCustomDriver);
    RUN_TEST(testRegisterDuplicateDriver);
    RUN_TEST(testUnregisterDriver);
    RUN_TEST(testGetDeviceByName);
    RUN_TEST(testGetDeviceById);
    RUN_TEST(testGetDevicesByType);
    RUN_TEST(testGetDevicesByStatus);
    RUN_TEST(testGetDevicesByBus);
    RUN_TEST(testBindDevice);
    RUN_TEST(testBindDeviceDriverNotLoaded);
    RUN_TEST(testUnbindDevice);
    RUN_TEST(testActivateDevice);
    RUN_TEST(testActivateDeviceNoDriver);
    RUN_TEST(testSuspendDevice);
    RUN_TEST(testRemoveDevice);
    RUN_TEST(testRemoveNonRemovableDevice);
    RUN_TEST(testDeviceDiscovery);
    RUN_TEST(testHotplugDetection);
    RUN_TEST(testDependencyResolution);
    RUN_TEST(testCircularDependency);
    RUN_TEST(testNoCircularDependency);
    RUN_TEST(testLoadOrder);
    RUN_TEST(testErrorHandling);
    RUN_TEST(testSetError);
    RUN_TEST(testEvents);
    RUN_TEST(testClearEvents);
    RUN_TEST(testEventCallback);
    RUN_TEST(testStats);
    RUN_TEST(testResetStats);
    RUN_TEST(testLoadedDriverCount);
    RUN_TEST(testActiveDriverCount);
    RUN_TEST(testActiveDeviceCount);
    RUN_TEST(testStringHelpers);
    RUN_TEST(testShutdownClearsAll);
    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);
    return tests_failed > 0 ? 1 : 0;
}

int main() {
    return runAllTests();
}
