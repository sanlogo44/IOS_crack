/*
 * Phantom OS - Update Manager Tests
 * v0.20.0
 */

#include "phantom/updatemanager/update_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <iostream>
#include <sstream>
#include <cstring>

static int tests_passed = 0;
static int tests_failed = 0;

static void ASSERT_TRUE(bool cond, const char* msg) {
    if (!cond) {
        std::cerr << "  FAIL: " << msg << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void ASSERT_FALSE(bool cond, const char* msg) {
    ASSERT_TRUE(!cond, msg);
}

static void ASSERT_EQ(int a, int b, const char* msg) {
    if (a != b) {
        std::cerr << "  FAIL: " << msg << " (expected " << b << ", got " << a << ")" << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void ASSERT_STREQ(const char* a, const char* b, const char* msg) {
    if (a == nullptr) a = "";
    if (b == nullptr) b = "";
    if (strcmp(a, b) != 0) {
        std::cerr << "  FAIL: " << msg << " (expected '" << b << "', got '" << a << "')" << std::endl;
        tests_failed++;
    } else {
        tests_passed++;
    }
}

static void RUN_TEST(const char* name, void (*func)()) {
    std::cout << "  Running " << name << std::endl;
    func();
}

using namespace phantom::updatemanager;

static UpdatePackage makePkg(const std::string& name, const std::string& version,
                            UpdateType type = UpdateType::OS,
                            UpdateChannel channel = UpdateChannel::STABLE,
                            UpdatePriority priority = UpdatePriority::NORMAL) {
    UpdatePackage pkg;
    pkg.name = name;
    pkg.version = version;
    pkg.type = type;
    pkg.channel = channel;
    pkg.priority = priority;
    pkg.sizeBytes = 1024 * 1024;
    pkg.currentVersion = "1.0.0";
    return pkg;
}

void runAllTests() {

    // ============================================================
    // Lifecycle tests
    // ============================================================

    RUN_TEST("testInitialize", []() {
        UpdateManager um;
        ASSERT_TRUE(um.initialize() == UpdateResult::SUCCESS, "initialize should succeed");
        ASSERT_TRUE(um.isInitialized(), "should be initialized");
    });

    RUN_TEST("testDoubleInitialize", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_EQ(static_cast<int>(um.initialize()), static_cast<int>(UpdateResult::ALREADY_INITIALIZED),
                  "double init should fail");
    });

    RUN_TEST("testShutdown", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        ASSERT_TRUE(um.shutdown() == UpdateResult::SUCCESS, "shutdown should succeed");
        ASSERT_EQ(static_cast<int>(um.getAvailableCount()), 0, "should clear available updates");
        ASSERT_FALSE(um.isInitialized(), "should not be initialized after shutdown");
    });

    RUN_TEST("testReinitialize", []() {
        UpdateManager um;
        um.initialize();
        um.shutdown();
        ASSERT_TRUE(um.initialize() == UpdateResult::SUCCESS, "reinitialize should succeed");
    });

    RUN_TEST("testNotInitialized", []() {
        UpdateManager um;
        ASSERT_EQ(static_cast<int>(um.checkForUpdates()), static_cast<int>(UpdateResult::NOT_INITIALIZED),
                  "checkForUpdates without init");
        ASSERT_EQ(static_cast<int>(um.addAvailableUpdate(makePkg("t", "1.0"))),
                  static_cast<int>(UpdateResult::NOT_INITIALIZED),
                  "addAvailableUpdate without init");
    });

    RUN_TEST("testMaxQueueSize", []() {
        UpdateManager um;
        um.initialize(5);
        ASSERT_EQ(um.getMaxQueueSize(), 5u, "max queue size should be 5");
    });

    // ============================================================
    // Add/Remove update tests
    // ============================================================

    RUN_TEST("testAddAvailableUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("OS Update", "1.1.0");
        auto result = um.addAvailableUpdate(pkg);
        ASSERT_EQ(static_cast<int>(result), static_cast<int>(UpdateResult::SUCCESS), "add should succeed");
        ASSERT_EQ(um.getAvailableCount(), 1u, "should have 1 update");
    });

    RUN_TEST("testAddInvalidUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg;
        pkg.version = "1.0.0";  // Empty name
        ASSERT_EQ(static_cast<int>(um.addAvailableUpdate(pkg)),
                  static_cast<int>(UpdateResult::INVALID_PACKAGE),
                  "empty name should fail");
        pkg.name = "test";
        pkg.version = "";  // Empty version
        ASSERT_EQ(static_cast<int>(um.addAvailableUpdate(pkg)),
                  static_cast<int>(UpdateResult::INVALID_PACKAGE),
                  "empty version should fail");
    });

    RUN_TEST("testRemoveAvailableUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_TRUE(um.removeAvailableUpdate(id) == UpdateResult::SUCCESS, "remove should succeed");
        ASSERT_EQ(um.getAvailableCount(), 0u, "should have 0 updates");
    });

    RUN_TEST("testRemoveNotFound", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_EQ(static_cast<int>(um.removeAvailableUpdate(999)),
                  static_cast<int>(UpdateResult::NOT_FOUND),
                  "remove non-existent should fail");
    });

    RUN_TEST("testGetUpdateById", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        UpdatePackage found = um.getUpdateById(id);
        ASSERT_STREQ(found.name.c_str(), "test", "should find update by id");
    });

    RUN_TEST("testGetUpdateByIdNotFound", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage found = um.getUpdateById(999);
        ASSERT_EQ(found.id, 0u, "not found should return empty package");
    });

    // ============================================================
    // Version comparison tests
    // ============================================================

    RUN_TEST("testCompareVersions", []() {
        ASSERT_EQ(UpdateManager::compareVersions("1.2.3", "1.2.3"), 0, "equal versions");
        ASSERT_EQ(UpdateManager::compareVersions("1.2.2", "1.2.3"), -1, "1.2.2 < 1.2.3");
        ASSERT_EQ(UpdateManager::compareVersions("1.2.3", "1.2.2"), 1, "1.2.3 > 1.2.2");
    });

    RUN_TEST("testCompareVersionsMultiDigit", []() {
        ASSERT_EQ(UpdateManager::compareVersions("1.2.10", "1.2.9"), 1, "1.2.10 > 1.2.9");
        ASSERT_EQ(UpdateManager::compareVersions("1.10.0", "1.9.9"), 1, "1.10.0 > 1.9.9");
    });

    RUN_TEST("testCompareVersionsDifferentLength", []() {
        ASSERT_EQ(UpdateManager::compareVersions("1.2.3.4", "1.2.3"), 1, "longer version wins");
        ASSERT_EQ(UpdateManager::compareVersions("1.2", "1.2.1"), -1, "shorter version loses");
    });

    RUN_TEST("testIsNewerVersion", []() {
        ASSERT_TRUE(UpdateManager::isNewerVersion("1.0.0", "1.1.0"), "1.1.0 is newer than 1.0.0");
        ASSERT_FALSE(UpdateManager::isNewerVersion("1.1.0", "1.0.0"), "1.0.0 is not newer");
        ASSERT_FALSE(UpdateManager::isNewerVersion("1.0.0", "1.0.0"), "same is not newer");
    });

    RUN_TEST("testIsNewerVersionPrerelease", []() {
        ASSERT_TRUE(UpdateManager::isNewerVersion("1.0.0", "1.1.0-beta"), "prerelease should compare OK");
    });

    // ============================================================
    // Update checking tests
    // ============================================================

    RUN_TEST("testCheckForUpdates", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_TRUE(um.checkForUpdates() == UpdateResult::SUCCESS, "check should succeed");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalChecks, 1u, "should increment check count");
    });

    RUN_TEST("testGetPendingUpdates", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("OS Update", "1.1.0");
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        auto pending = um.getPendingUpdates();
        ASSERT_EQ(pending.size(), 1u, "should have 1 pending update");
    });

    RUN_TEST("testGetPendingUpdatesOldVersion", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("OS Update", "0.9.0");
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        auto pending = um.getPendingUpdates();
        ASSERT_EQ(pending.size(), 0u, "older version should not be pending");
    });

    RUN_TEST("testGetPendingUpdatesChannelFilter", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("Beta", "2.0.0", UpdateType::OS, UpdateChannel::BETA);
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        // Default allowed channel is STABLE, so beta should be filtered out
        auto pending = um.getPendingUpdates();
        ASSERT_EQ(pending.size(), 0u, "beta should be filtered out by default");
        // SECURITY channel should always pass
        UpdatePackage sec = makePkg("Security", "1.0.1", UpdateType::OS, UpdateChannel::SECURITY);
        sec.currentVersion = "1.0.0";
        um.addAvailableUpdate(sec);
        pending = um.getPendingUpdates();
        ASSERT_EQ(pending.size(), 1u, "security should pass channel filter");
    });

    // ============================================================
    // Download tests
    // ============================================================

    RUN_TEST("testQueueForDownload", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_TRUE(um.queueForDownload(id) == UpdateResult::SUCCESS, "queue should succeed");
        ASSERT_EQ(um.getDownloadQueueSize(), 1u, "queue size should be 1");
    });

    RUN_TEST("testQueueFull", []() {
        UpdateManager um;
        um.initialize(2);
        UpdatePackage pkg1 = makePkg("test1", "1.1.0");
        UpdatePackage pkg2 = makePkg("test2", "1.2.0");
        UpdatePackage pkg3 = makePkg("test3", "1.3.0");
        um.addAvailableUpdate(pkg1);
        um.addAvailableUpdate(pkg2);
        um.addAvailableUpdate(pkg3);
        auto updates = um.getAvailableUpdates();
        um.queueForDownload(updates[0].id);
        um.queueForDownload(updates[1].id);
        ASSERT_EQ(static_cast<int>(um.queueForDownload(updates[2].id)),
                  static_cast<int>(UpdateResult::QUEUE_FULL),
                  "queue should be full");
    });

    RUN_TEST("testQueueNotFound", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_EQ(static_cast<int>(um.queueForDownload(999)),
                  static_cast<int>(UpdateResult::NOT_FOUND),
                  "queue non-existent should fail");
    });

    RUN_TEST("testStartDownload", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_TRUE(um.startDownload(id) == UpdateResult::SUCCESS, "start download should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::DOWNLOADING),
                  "state should be DOWNLOADING");
    });

    RUN_TEST("testStartDownloadNotFound", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_EQ(static_cast<int>(um.startDownload(999)),
                  static_cast<int>(UpdateResult::NOT_FOUND),
                  "download non-existent should fail");
    });

    RUN_TEST("testStartDownloadBadState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        // Try to start again
        ASSERT_EQ(static_cast<int>(um.startDownload(id)),
                  static_cast<int>(UpdateResult::BAD_STATE),
                  "starting already-downloading should fail");
    });

    RUN_TEST("testPauseDownload", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        ASSERT_TRUE(um.pauseDownload(id) == UpdateResult::SUCCESS, "pause should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::PAUSED),
                  "state should be PAUSED");
    });

    RUN_TEST("testPauseDownloadBadState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        // Can't pause when not downloading
        ASSERT_EQ(static_cast<int>(um.pauseDownload(id)),
                  static_cast<int>(UpdateResult::BAD_STATE),
                  "pause when not downloading should fail");
    });

    RUN_TEST("testResumeDownload", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.pauseDownload(id);
        ASSERT_TRUE(um.resumeDownload(id) == UpdateResult::SUCCESS, "resume should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::DOWNLOADING),
                  "state should be DOWNLOADING");
    });

    RUN_TEST("testResumeDownloadBadState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_EQ(static_cast<int>(um.resumeDownload(id)),
                  static_cast<int>(UpdateResult::BAD_STATE),
                  "resume when not paused should fail");
    });

    RUN_TEST("testCancelDownload", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        ASSERT_TRUE(um.cancelDownload(id) == UpdateResult::SUCCESS, "cancel should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::CANCELLED),
                  "state should be CANCELLED");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalCancelled, 1u, "should increment cancelled count");
    });

    RUN_TEST("testDownloadProgress", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        ASSERT_TRUE(um.updateDownloadProgress(id, 500, 100) == UpdateResult::SUCCESS,
                    "progress update should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(prog.downloadedBytes, 500u, "should have 500 bytes downloaded");
        ASSERT_EQ(prog.progressPercent, 50u, "should be 50% complete");
        ASSERT_EQ(prog.downloadSpeed, 100u, "should have speed 100");
    });

    RUN_TEST("testDownloadProgressClamp", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 2000, 0);  // Over total
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(prog.downloadedBytes, 1000u, "should clamp to total");
        ASSERT_EQ(prog.progressPercent, 100u, "should be 100%");
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::DOWNLOADED),
                  "should be DOWNLOADED when 100%");
    });

    RUN_TEST("testDownloadProgressBadState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.pauseDownload(id);
        ASSERT_EQ(static_cast<int>(um.updateDownloadProgress(id, 500, 0)),
                  static_cast<int>(UpdateResult::BAD_STATE),
                  "progress update when paused should fail");
    });

    RUN_TEST("testGetActiveDownloads", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg1 = makePkg("test1", "1.1.0");
        UpdatePackage pkg2 = makePkg("test2", "1.2.0");
        um.addAvailableUpdate(pkg1);
        um.addAvailableUpdate(pkg2);
        auto updates = um.getAvailableUpdates();
        um.startDownload(updates[0].id);
        um.startDownload(updates[1].id);
        um.pauseDownload(updates[1].id);
        auto active = um.getActiveDownloads();
        ASSERT_EQ(active.size(), 2u, "should have 2 active (downloading + paused)");
    });

    // ============================================================
    // Verification tests
    // ============================================================

    RUN_TEST("testComputeChecksum", []() {
        UpdateManager um;
        std::string cs1 = um.computeChecksum("hello");
        std::string cs2 = um.computeChecksum("hello");
        std::string cs3 = um.computeChecksum("world");
        ASSERT_STREQ(cs1.c_str(), cs2.c_str(), "same data should produce same checksum");
        ASSERT_TRUE(cs1 != cs3, "different data should produce different checksum");
    });

    RUN_TEST("testVerifyChecksum", []() {
        UpdateManager um;
        std::string cs = um.computeChecksum("testdata");
        ASSERT_TRUE(um.verifyChecksum("testdata", cs) == true, "should verify with correct checksum");
        ASSERT_FALSE(um.verifyChecksum("testdata", "wrong"), "should fail with wrong checksum");
        ASSERT_FALSE(um.verifyChecksum("testdata", ""), "should fail with empty checksum");
    });

    RUN_TEST("testVerifySignature", []() {
        UpdateManager um;
        UpdatePackage pkg = makePkg("test", "1.1.0");
        ASSERT_FALSE(um.verifySignature(pkg), "empty signature should fail");
        pkg.signature = "sig123";
        ASSERT_TRUE(um.verifySignature(pkg) == true, "non-empty signature should pass");
    });

    RUN_TEST("testVerifyUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "";
        pkg.signature = "sig123";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        ASSERT_TRUE(um.verifyUpdate(id) == UpdateResult::SUCCESS, "verify should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::VERIFIED),
                  "state should be VERIFIED");
    });

    RUN_TEST("testVerifyUpdateChecksumFail", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "wrongchecksum";
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        ASSERT_EQ(static_cast<int>(um.verifyUpdate(id)),
                  static_cast<int>(UpdateResult::CHECKSUM_FAILED),
                  "verify should fail with bad checksum");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::FAILED),
                  "state should be FAILED");
    });

    RUN_TEST("testVerifyUpdateSignatureFail", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "";
        pkg.signature = "";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        ASSERT_EQ(static_cast<int>(um.verifyUpdate(id)),
                  static_cast<int>(UpdateResult::SIGNATURE_FAILED),
                  "verify should fail with empty signature");
    });

    RUN_TEST("testVerifyUpdateBadState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_EQ(static_cast<int>(um.verifyUpdate(id)),
                  static_cast<int>(UpdateResult::BAD_STATE),
                  "verify without download should fail");
    });

    RUN_TEST("testSetChecksum", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_TRUE(um.setChecksum(id, "abc123") == UpdateResult::SUCCESS, "set checksum should succeed");
        ASSERT_STREQ(um.getUpdateById(id).checksum.c_str(), "abc123", "checksum should be set");
    });

    RUN_TEST("testSetSignature", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_TRUE(um.setSignature(id, "sig456") == UpdateResult::SUCCESS, "set signature should succeed");
        ASSERT_STREQ(um.getUpdateById(id).signature.c_str(), "sig456", "signature should be set");
    });

    // ============================================================
    // Installation tests
    // ============================================================

    RUN_TEST("testStageUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        ASSERT_TRUE(um.stageUpdate(id) == UpdateResult::SUCCESS, "stage should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::STAGED),
                  "state should be STAGED");
    });

    RUN_TEST("testStageUpdateNotVerified", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_EQ(static_cast<int>(um.stageUpdate(id)),
                  static_cast<int>(UpdateResult::VERIFICATION_REQUIRED),
                  "stage without verify should fail");
    });

    RUN_TEST("testInstallUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        ASSERT_TRUE(um.installUpdate(id) == UpdateResult::SUCCESS, "install should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::INSTALLED),
                  "state should be INSTALLED");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalInstallsSucceeded, 1u, "should increment install count");
    });

    RUN_TEST("testInstallNotVerified", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_EQ(static_cast<int>(um.installUpdate(id)),
                  static_cast<int>(UpdateResult::VERIFICATION_REQUIRED),
                  "install without verify should fail");
    });

    RUN_TEST("testCommitStagedUpdate", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.stageUpdate(id);
        ASSERT_TRUE(um.commitStagedUpdate(id) == UpdateResult::SUCCESS, "commit should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::INSTALLED),
                  "state should be INSTALLED after commit");
    });

    RUN_TEST("testCommitNotStaged", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        ASSERT_EQ(static_cast<int>(um.commitStagedUpdate(id)),
                  static_cast<int>(UpdateResult::STAGING_REQUIRED),
                  "commit without staging should fail");
    });

    // ============================================================
    // Rollback tests
    // ============================================================

    RUN_TEST("testRollback", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        ASSERT_TRUE(um.rollback(id) == UpdateResult::SUCCESS, "rollback should succeed");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::ROLLED_BACK),
                  "state should be ROLLED_BACK");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalRollbacks, 1u, "should increment rollback count");
    });

    RUN_TEST("testRollbackNotFound", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_EQ(static_cast<int>(um.rollback(999)),
                  static_cast<int>(UpdateResult::ROLLBACK_FAILED),
                  "rollback non-existent should fail");
    });

    RUN_TEST("testRollbackAlreadyRolledBack", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        um.rollback(id);
        ASSERT_EQ(static_cast<int>(um.rollback(id)),
                  static_cast<int>(UpdateResult::ROLLBACK_FAILED),
                  "double rollback should fail");
    });

    RUN_TEST("testGetRollbackPoints", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        auto points = um.getRollbackPoints();
        ASSERT_EQ(points.size(), 1u, "should have 1 rollback point");
        ASSERT_TRUE(points[0].committed, "rollback point should be committed");
    });

    RUN_TEST("testGetRollbackPoint", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        RollbackPoint rp = um.getRollbackPoint(id);
        ASSERT_STREQ(rp.previousVersion.c_str(), "1.0.0", "should have previous version");
        ASSERT_STREQ(rp.newVersion.c_str(), "1.1.0", "should have new version");
    });

    // ============================================================
    // Maintenance window tests
    // ============================================================

    RUN_TEST("testMaintenanceWindowDisabled", []() {
        UpdateManager um;
        um.initialize();
        // No maintenance window set (disabled) - should always allow
        ASSERT_TRUE(um.isWithinMaintenanceWindow(), "should allow when disabled");
    });

    RUN_TEST("testMaintenanceWindowEnabled", []() {
        UpdateManager um;
        um.initialize();
        MaintenanceWindow mw;
        mw.enabled = true;
        mw.startHour = 2;
        mw.startMinute = 0;
        mw.durationMinutes = 60;
        um.setMaintenanceWindow(mw);
        // 2:00 AM = 2 * 3600 * 1000 = 7200000 ms
        ASSERT_TRUE(um.isWithinMaintenanceWindow(7200000), "should be within window at 2:00 AM");
        // 3:00 AM = 3 * 3600 * 1000 = 10800000 ms - outside 1 hour window
        ASSERT_FALSE(um.isWithinMaintenanceWindow(10800000), "should be outside window at 3:00 AM");
    });

    RUN_TEST("testMaintenanceWindowBlocksInstall", []() {
        UpdateManager um;
        um.initialize();
        MaintenanceWindow mw;
        mw.enabled = true;
        mw.startHour = 2;
        mw.startMinute = 0;
        mw.durationMinutes = 60;
        mw.allowCriticalBypass = false;
        um.setMaintenanceWindow(mw);

        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);

        // Current time is not within window (steady_clock since boot, not 2 AM)
        ASSERT_EQ(static_cast<int>(um.installUpdate(id)),
                  static_cast<int>(UpdateResult::MAINTENANCE_BLOCKED),
                  "install should be blocked by maintenance window");
    });

    RUN_TEST("testMaintenanceWindowCriticalBypass", []() {
        UpdateManager um;
        um.initialize();
        MaintenanceWindow mw;
        mw.enabled = true;
        mw.startHour = 2;
        mw.startMinute = 0;
        mw.durationMinutes = 60;
        mw.allowCriticalBypass = true;
        um.setMaintenanceWindow(mw);

        UpdatePackage pkg = makePkg("Security Patch", "1.0.1");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        pkg.priority = UpdatePriority::CRITICAL;
        pkg.securityUpdate = true;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);

        ASSERT_TRUE(um.installUpdate(id) == UpdateResult::SUCCESS,
                    "critical security update should bypass maintenance window");
    });

    // ============================================================
    // Policy tests
    // ============================================================

    RUN_TEST("testSetUpdatePolicy", []() {
        UpdateManager um;
        um.initialize();
        um.setUpdatePolicy(UpdatePolicy::AUTO_INSTALL);
        ASSERT_EQ(static_cast<int>(um.getUpdatePolicy()), static_cast<int>(UpdatePolicy::AUTO_INSTALL),
                  "policy should be set");
    });

    RUN_TEST("testAutoRollback", []() {
        UpdateManager um;
        um.initialize();
        um.setAutoRollback(true);
        ASSERT_TRUE(um.isAutoRollback(), "auto rollback should be true");
        um.setAutoRollback(false);
        ASSERT_FALSE(um.isAutoRollback(), "auto rollback should be false");
    });

    RUN_TEST("testAnonymousChecks", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_TRUE(um.isAnonymousChecks(), "anonymous checks should default to true");
        um.setAnonymousChecks(false);
        ASSERT_FALSE(um.isAnonymousChecks(), "anonymous checks should be false");
    });

    RUN_TEST("testTelemetryDisabled", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_FALSE(um.isTelemetryEnabled(), "telemetry should be disabled by default");
        um.setTelemetryEnabled(true);
        ASSERT_TRUE(um.isTelemetryEnabled(), "telemetry should be enabled");
    });

    RUN_TEST("testSetAllowedChannel", []() {
        UpdateManager um;
        um.initialize();
        um.setAllowedChannel(UpdateChannel::BETA);
        ASSERT_EQ(static_cast<int>(um.getAllowedChannel()), static_cast<int>(UpdateChannel::BETA),
                  "channel should be BETA");
    });

    // ============================================================
    // Schedule tests
    // ============================================================

    RUN_TEST("testSetSchedule", []() {
        UpdateManager um;
        um.initialize();
        UpdateSchedule sched;
        sched.autoCheckEnabled = true;
        sched.checkIntervalHours = 12;
        um.setSchedule(sched);
        ASSERT_TRUE(um.getSchedule().autoCheckEnabled, "schedule should be set");
        ASSERT_EQ(um.getSchedule().checkIntervalHours, 12u, "interval should be 12");
    });

    RUN_TEST("testShouldAutoCheck", []() {
        UpdateManager um;
        um.initialize();
        UpdateSchedule sched;
        sched.autoCheckEnabled = true;
        sched.checkIntervalHours = 24;
        sched.nextCheckTime = 1000;  // Very old timestamp
        um.setSchedule(sched);
        ASSERT_TRUE(um.shouldAutoCheck(2000), "should auto-check when past next check time");
    });

    RUN_TEST("testShouldAutoCheckDisabled", []() {
        UpdateManager um;
        um.initialize();
        UpdateSchedule sched;
        sched.autoCheckEnabled = false;
        um.setSchedule(sched);
        ASSERT_FALSE(um.shouldAutoCheck(2000), "should not auto-check when disabled");
    });

    RUN_TEST("testShouldAutoCheckNotDue", []() {
        UpdateManager um;
        um.initialize();
        UpdateSchedule sched;
        sched.autoCheckEnabled = true;
        sched.checkIntervalHours = 24;
        sched.nextCheckTime = 10000;  // Future
        um.setSchedule(sched);
        ASSERT_FALSE(um.shouldAutoCheck(2000), "should not auto-check when not due");
    });

    // ============================================================
    // Query tests
    // ============================================================

    RUN_TEST("testGetUpdatesByType", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("OS", "1.1.0", UpdateType::OS));
        um.addAvailableUpdate(makePkg("App", "1.1.0", UpdateType::APP));
        auto osUpdates = um.getUpdatesByType(UpdateType::OS);
        ASSERT_EQ(osUpdates.size(), 1u, "should have 1 OS update");
    });

    RUN_TEST("testGetUpdatesByChannel", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("Stable", "1.1.0", UpdateType::OS, UpdateChannel::STABLE));
        um.addAvailableUpdate(makePkg("Beta", "1.1.0", UpdateType::OS, UpdateChannel::BETA));
        auto stable = um.getUpdatesByChannel(UpdateChannel::STABLE);
        ASSERT_EQ(stable.size(), 1u, "should have 1 stable update");
    });

    RUN_TEST("testGetUpdatesByPriority", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("Low", "1.1.0", UpdateType::OS, UpdateChannel::STABLE, UpdatePriority::LOW));
        um.addAvailableUpdate(makePkg("High", "1.1.0", UpdateType::OS, UpdateChannel::STABLE, UpdatePriority::HIGH));
        auto high = um.getUpdatesByPriority(UpdatePriority::HIGH);
        ASSERT_EQ(high.size(), 1u, "should have 1 high priority update");
    });

    RUN_TEST("testGetUpdatesByState", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        auto downloading = um.getUpdatesByState(UpdateState::DOWNLOADING);
        ASSERT_EQ(downloading.size(), 1u, "should have 1 downloading update");
    });

    RUN_TEST("testGetCountByType", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("OS1", "1.1.0", UpdateType::OS));
        um.addAvailableUpdate(makePkg("OS2", "1.2.0", UpdateType::OS));
        um.addAvailableUpdate(makePkg("App1", "1.1.0", UpdateType::APP));
        ASSERT_EQ(um.getCountByType(UpdateType::OS), 2u, "should have 2 OS updates");
        ASSERT_EQ(um.getCountByType(UpdateType::APP), 1u, "should have 1 APP update");
    });

    RUN_TEST("testGetCountByChannel", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("S1", "1.1.0", UpdateType::OS, UpdateChannel::STABLE));
        um.addAvailableUpdate(makePkg("S2", "1.2.0", UpdateType::OS, UpdateChannel::STABLE));
        ASSERT_EQ(um.getCountByChannel(UpdateChannel::STABLE), 2u, "should have 2 stable");
    });

    RUN_TEST("testGetCountByPriority", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("C1", "1.1.0", UpdateType::OS, UpdateChannel::STABLE, UpdatePriority::CRITICAL));
        um.addAvailableUpdate(makePkg("C2", "1.2.0", UpdateType::OS, UpdateChannel::STABLE, UpdatePriority::CRITICAL));
        ASSERT_EQ(um.getCountByPriority(UpdatePriority::CRITICAL), 2u, "should have 2 critical");
    });

    // ============================================================
    // Callback tests
    // ============================================================

    RUN_TEST("testAvailableCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setUpdateAvailableCallback([&called](const UpdatePackage&) { called = true; });
        um.addAvailableUpdate(makePkg("test", "1.1.0"));
        ASSERT_TRUE(called, "available callback should be called");
    });

    RUN_TEST("testProgressCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setDownloadProgressCallback([&called](const UpdateProgress&) { called = true; });
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 500, 0);
        ASSERT_TRUE(called, "progress callback should be called");
    });

    RUN_TEST("testVerifyCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setVerifyCompleteCallback([&called](const UpdatePackage&) { called = true; });
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        ASSERT_TRUE(called, "verify callback should be called");
    });

    RUN_TEST("testInstallCompleteCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setInstallCompleteCallback([&called](const UpdatePackage&) { called = true; });
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        ASSERT_TRUE(called, "install complete callback should be called");
    });

    RUN_TEST("testInstallFailedCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setInstallFailedCallback([&called](const UpdatePackage&) { called = true; });
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "wrong";
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);  // Will fail checksum
        ASSERT_TRUE(called, "install failed callback should be called on verify failure");
    });

    RUN_TEST("testRollbackCallback", []() {
        UpdateManager um;
        um.initialize();
        bool called = false;
        um.setRollbackCallback([&called](const RollbackPoint&) { called = true; });
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        um.rollback(id);
        ASSERT_TRUE(called, "rollback callback should be called");
    });

    // ============================================================
    // Stats tests
    // ============================================================

    RUN_TEST("testStats", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("test", "1.1.0", UpdateType::OS, UpdateChannel::STABLE, UpdatePriority::HIGH));
        um.checkForUpdates();
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalChecks, 1u, "should have 1 check");
        ASSERT_EQ(stats.totalAvailable, 1u, "should have 1 available");
        ASSERT_EQ(stats.totalByType[static_cast<int>(UpdateType::OS)], 1u, "should have 1 OS type");
        ASSERT_EQ(stats.totalByChannel[static_cast<int>(UpdateChannel::STABLE)], 1u, "should have 1 stable");
        ASSERT_EQ(stats.totalByPriority[static_cast<int>(UpdatePriority::HIGH)], 1u, "should have 1 high");
    });

    RUN_TEST("testStatsAfterInstall", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalDownloadsStarted, 1u, "should have 1 download started");
        ASSERT_EQ(stats.totalDownloadsCompleted, 1u, "should have 1 download completed");
        ASSERT_EQ(stats.totalInstallsAttempted, 1u, "should have 1 install attempted");
        ASSERT_EQ(stats.totalInstallsSucceeded, 1u, "should have 1 install succeeded");
        ASSERT_EQ(stats.historySize, 1u, "should have 1 in history");
    });

    RUN_TEST("testResetStats", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("test", "1.1.0"));
        um.checkForUpdates();
        um.resetStats();
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalChecks, 0u, "should have 0 checks after reset");
        ASSERT_EQ(stats.totalAvailable, 0u, "should have 0 available after reset");
    });

    // ============================================================
    // History tests
    // ============================================================

    RUN_TEST("testHistory", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        auto history = um.getHistory();
        ASSERT_EQ(history.size(), 1u, "should have 1 in history");
    });

    RUN_TEST("testClearHistory", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.installUpdate(id);
        um.clearHistory();
        auto history = um.getHistory();
        ASSERT_EQ(history.size(), 0u, "should have 0 in history after clear");
    });

    RUN_TEST("testHistoryMaxSize", []() {
        UpdateManager um;
        um.initialize(50, 3);
        for (int i = 0; i < 5; ++i) {
            UpdatePackage pkg = makePkg("test" + std::to_string(i), "1." + std::to_string(i) + ".0");
            pkg.sizeBytes = 1000;
            pkg.signature = "sig";
            um.addAvailableUpdate(pkg);
            uint64_t id = um.getAvailableUpdates().back().id;
            um.startDownload(id);
            um.updateDownloadProgress(id, 1000, 0);
            um.verifyUpdate(id);
            um.installUpdate(id);
        }
        auto history = um.getHistory();
        ASSERT_EQ(history.size(), 3u, "should cap at max history size");
    });

    // ============================================================
    // Integration tests
    // ============================================================

    RUN_TEST("testLogServerIntegration", []() {
        UpdateManager um;
        um.initialize();
        phantom::logging::LogServer ls;
        ls.initialize(100);
        um.setLogServer(&ls);
        ASSERT_TRUE(um.getLogServer() != nullptr, "log server should be set");
        um.addAvailableUpdate(makePkg("test", "1.1.0"));
        um.checkForUpdates();
        // Just verify it doesn't crash
    });

    RUN_TEST("testNoLogServer", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_TRUE(um.getLogServer() == nullptr, "log server should be null");
        um.addAvailableUpdate(makePkg("test", "1.1.0"));
        um.checkForUpdates();
        // Should not crash
    });

    RUN_TEST("testCrashReporterIntegration", []() {
        UpdateManager um;
        um.initialize();
        phantom::crashreporter::CrashReporter cr;
        cr.initialize(50);
        um.setCrashReporter(&cr);
        ASSERT_TRUE(um.getCrashReporter() != nullptr, "crash reporter should be set");
        // Install a failing update with auto-rollback would trigger crash reporter
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "wrong";
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);  // Fails checksum
        // Should not crash
    });

    RUN_TEST("testNoCrashReporter", []() {
        UpdateManager um;
        um.initialize();
        ASSERT_TRUE(um.getCrashReporter() == nullptr, "crash reporter should be null");
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.checksum = "wrong";
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        // Should not crash
    });

    // ============================================================
    // String helper tests
    // ============================================================

    RUN_TEST("testUpdateTypeToString", []() {
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::OS), "OS", "OS type");
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::APP), "APP", "APP type");
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::SECURITY_PATCH), "SECURITY_PATCH", "SECURITY_PATCH type");
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::DRIVER), "DRIVER", "DRIVER type");
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::CONFIG), "CONFIG", "CONFIG type");
        ASSERT_STREQ(UpdateManager::updateTypeToString(UpdateType::FIRMWARE), "FIRMWARE", "FIRMWARE type");
    });

    RUN_TEST("testUpdateStateToString", []() {
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::IDLE), "IDLE", "IDLE state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::CHECKING), "CHECKING", "CHECKING state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::AVAILABLE), "AVAILABLE", "AVAILABLE state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::QUEUED), "QUEUED", "QUEUED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::DOWNLOADING), "DOWNLOADING", "DOWNLOADING state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::PAUSED), "PAUSED", "PAUSED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::DOWNLOADED), "DOWNLOADED", "DOWNLOADED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::VERIFYING), "VERIFYING", "VERIFYING state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::VERIFIED), "VERIFIED", "VERIFIED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::STAGED), "STAGED", "STAGED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::INSTALLING), "INSTALLING", "INSTALLING state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::INSTALLED), "INSTALLED", "INSTALLED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::FAILED), "FAILED", "FAILED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::CANCELLED), "CANCELLED", "CANCELLED state");
        ASSERT_STREQ(UpdateManager::updateStateToString(UpdateState::ROLLED_BACK), "ROLLED_BACK", "ROLLED_BACK state");
    });

    RUN_TEST("testUpdateChannelToString", []() {
        ASSERT_STREQ(UpdateManager::updateChannelToString(UpdateChannel::STABLE), "STABLE", "STABLE channel");
        ASSERT_STREQ(UpdateManager::updateChannelToString(UpdateChannel::BETA), "BETA", "BETA channel");
        ASSERT_STREQ(UpdateManager::updateChannelToString(UpdateChannel::NIGHTLY), "NIGHTLY", "NIGHTLY channel");
        ASSERT_STREQ(UpdateManager::updateChannelToString(UpdateChannel::SECURITY), "SECURITY", "SECURITY channel");
    });

    RUN_TEST("testUpdatePriorityToString", []() {
        ASSERT_STREQ(UpdateManager::updatePriorityToString(UpdatePriority::LOW), "LOW", "LOW priority");
        ASSERT_STREQ(UpdateManager::updatePriorityToString(UpdatePriority::NORMAL), "NORMAL", "NORMAL priority");
        ASSERT_STREQ(UpdateManager::updatePriorityToString(UpdatePriority::HIGH), "HIGH", "HIGH priority");
        ASSERT_STREQ(UpdateManager::updatePriorityToString(UpdatePriority::CRITICAL), "CRITICAL", "CRITICAL priority");
    });

    RUN_TEST("testUpdatePolicyToString", []() {
        ASSERT_STREQ(UpdateManager::updatePolicyToString(UpdatePolicy::MANUAL), "MANUAL", "MANUAL policy");
        ASSERT_STREQ(UpdateManager::updatePolicyToString(UpdatePolicy::NOTIFY_ONLY), "NOTIFY_ONLY", "NOTIFY_ONLY policy");
        ASSERT_STREQ(UpdateManager::updatePolicyToString(UpdatePolicy::AUTO_DOWNLOAD), "AUTO_DOWNLOAD", "AUTO_DOWNLOAD policy");
        ASSERT_STREQ(UpdateManager::updatePolicyToString(UpdatePolicy::AUTO_INSTALL), "AUTO_INSTALL", "AUTO_INSTALL policy");
    });

    RUN_TEST("testUpdateResultToString", []() {
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::SUCCESS), "SUCCESS", "SUCCESS result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::NOT_INITIALIZED), "NOT_INITIALIZED", "NOT_INITIALIZED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::INVALID_PACKAGE), "INVALID_PACKAGE", "INVALID_PACKAGE result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::NOT_FOUND), "NOT_FOUND", "NOT_FOUND result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::BAD_STATE), "BAD_STATE", "BAD_STATE result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::CHECKSUM_FAILED), "CHECKSUM_FAILED", "CHECKSUM_FAILED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::SIGNATURE_FAILED), "SIGNATURE_FAILED", "SIGNATURE_FAILED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::INSTALL_FAILED), "INSTALL_FAILED", "INSTALL_FAILED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::ROLLBACK_FAILED), "ROLLBACK_FAILED", "ROLLBACK_FAILED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::MAINTENANCE_BLOCKED), "MAINTENANCE_BLOCKED", "MAINTENANCE_BLOCKED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::QUEUE_FULL), "QUEUE_FULL", "QUEUE_FULL result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::VERIFICATION_REQUIRED), "VERIFICATION_REQUIRED", "VERIFICATION_REQUIRED result");
        ASSERT_STREQ(UpdateManager::updateResultToString(UpdateResult::STAGING_REQUIRED), "STAGING_REQUIRED", "STAGING_REQUIRED result");
    });

    RUN_TEST("testStringToUpdateType", []() {
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("OS")),
                  static_cast<int>(UpdateType::OS), "string to OS");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("APP")),
                  static_cast<int>(UpdateType::APP), "string to APP");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("SECURITY_PATCH")),
                  static_cast<int>(UpdateType::SECURITY_PATCH), "string to SECURITY_PATCH");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("DRIVER")),
                  static_cast<int>(UpdateType::DRIVER), "string to DRIVER");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("CONFIG")),
                  static_cast<int>(UpdateType::CONFIG), "string to CONFIG");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateType("FIRMWARE")),
                  static_cast<int>(UpdateType::FIRMWARE), "string to FIRMWARE");
    });

    RUN_TEST("testStringToUpdateChannel", []() {
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateChannel("STABLE")),
                  static_cast<int>(UpdateChannel::STABLE), "string to STABLE");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateChannel("BETA")),
                  static_cast<int>(UpdateChannel::BETA), "string to BETA");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateChannel("NIGHTLY")),
                  static_cast<int>(UpdateChannel::NIGHTLY), "string to NIGHTLY");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdateChannel("SECURITY")),
                  static_cast<int>(UpdateChannel::SECURITY), "string to SECURITY");
    });

    RUN_TEST("testStringToUpdatePriority", []() {
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePriority("LOW")),
                  static_cast<int>(UpdatePriority::LOW), "string to LOW");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePriority("NORMAL")),
                  static_cast<int>(UpdatePriority::NORMAL), "string to NORMAL");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePriority("HIGH")),
                  static_cast<int>(UpdatePriority::HIGH), "string to HIGH");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePriority("CRITICAL")),
                  static_cast<int>(UpdatePriority::CRITICAL), "string to CRITICAL");
    });

    RUN_TEST("testStringToUpdatePolicy", []() {
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePolicy("MANUAL")),
                  static_cast<int>(UpdatePolicy::MANUAL), "string to MANUAL");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePolicy("NOTIFY_ONLY")),
                  static_cast<int>(UpdatePolicy::NOTIFY_ONLY), "string to NOTIFY_ONLY");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePolicy("AUTO_DOWNLOAD")),
                  static_cast<int>(UpdatePolicy::AUTO_DOWNLOAD), "string to AUTO_DOWNLOAD");
        ASSERT_EQ(static_cast<int>(UpdateManager::stringToUpdatePolicy("AUTO_INSTALL")),
                  static_cast<int>(UpdatePolicy::AUTO_INSTALL), "string to AUTO_INSTALL");
    });

    // ============================================================
    // Edge cases
    // ============================================================

    RUN_TEST("testFullUpdateLifecycle", []() {
        UpdateManager um;
        um.initialize();

        // Add update
        UpdatePackage pkg = makePkg("PhantomOS", "1.2.0");
        pkg.sizeBytes = 50000;
        pkg.signature = "valid_sig";
        pkg.currentVersion = "1.1.0";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;

        // Queue and start download
        um.queueForDownload(id);
        um.startDownload(id);
        um.updateDownloadProgress(id, 25000, 500);
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(prog.progressPercent, 50u, "should be 50% complete");

        // Complete download
        um.updateDownloadProgress(id, 50000, 0);
        prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::DOWNLOADED),
                  "should be DOWNLOADED");

        // Verify
        ASSERT_TRUE(um.verifyUpdate(id) == UpdateResult::SUCCESS, "verify should succeed");
        prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::VERIFIED),
                  "should be VERIFIED");

        // Stage
        ASSERT_TRUE(um.stageUpdate(id) == UpdateResult::SUCCESS, "stage should succeed");

        // Commit (install)
        ASSERT_TRUE(um.commitStagedUpdate(id) == UpdateResult::SUCCESS, "commit should succeed");
        prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::INSTALLED),
                  "should be INSTALLED");

        // Rollback
        ASSERT_TRUE(um.rollback(id) == UpdateResult::SUCCESS, "rollback should succeed");
        prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::ROLLED_BACK),
                  "should be ROLLED_BACK");

        // Verify stats
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalDownloadsStarted, 1u, "1 download started");
        ASSERT_EQ(stats.totalDownloadsCompleted, 1u, "1 download completed");
        ASSERT_EQ(stats.totalInstallsAttempted, 1u, "1 install attempted");
        ASSERT_EQ(stats.totalInstallsSucceeded, 1u, "1 install succeeded");
        ASSERT_EQ(stats.totalRollbacks, 1u, "1 rollback");
    });

    RUN_TEST("testMultipleUpdatesSameType", []() {
        UpdateManager um;
        um.initialize();
        um.addAvailableUpdate(makePkg("OS1", "1.1.0", UpdateType::OS));
        um.addAvailableUpdate(makePkg("OS2", "1.2.0", UpdateType::OS));
        um.addAvailableUpdate(makePkg("App1", "2.0.0", UpdateType::APP));
        auto osUpdates = um.getUpdatesByType(UpdateType::OS);
        ASSERT_EQ(osUpdates.size(), 2u, "should have 2 OS updates");
        auto appUpdates = um.getUpdatesByType(UpdateType::APP);
        ASSERT_EQ(appUpdates.size(), 1u, "should have 1 APP update");
        ASSERT_EQ(um.getCountByType(UpdateType::OS), 2u, "count should be 2");
    });

    RUN_TEST("testProgressClamping", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 100;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 50, 0);
        ASSERT_EQ(um.getDownloadProgress(id).progressPercent, 50u, "should be 50%");
        um.updateDownloadProgress(id, 150, 0);  // Over total
        ASSERT_EQ(um.getDownloadProgress(id).progressPercent, 100u, "should clamp to 100%");
    });

    RUN_TEST("testDownloadCompleteAutoTransition", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        ASSERT_EQ(static_cast<int>(um.getDownloadProgress(id).state),
                  static_cast<int>(UpdateState::DOWNLOADED),
                  "should auto-transition to DOWNLOADED at 100%");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalDownloadsCompleted, 1u, "should increment download completed");
    });

    RUN_TEST("testRemoveUpdateCleansQueue", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.queueForDownload(id);
        ASSERT_EQ(um.getDownloadQueueSize(), 1u, "queue should have 1");
        um.removeAvailableUpdate(id);
        ASSERT_EQ(um.getDownloadQueueSize(), 0u, "queue should be cleared");
    });

    RUN_TEST("testInstallFailureAutoRollback", []() {
        UpdateManager um;
        um.initialize();
        um.setAutoRollback(true);
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        pkg.currentVersion = "1.0.0";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.setFailNextInstall(true);
        ASSERT_EQ(static_cast<int>(um.installUpdate(id)),
                  static_cast<int>(UpdateResult::INSTALL_FAILED),
                  "install should fail");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::ROLLED_BACK),
                  "should auto-rollback after failure");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalInstallsFailed, 1u, "should have 1 failed install");
        ASSERT_EQ(stats.totalRollbacks, 1u, "should have 1 rollback");
        // Verify version was restored
        ASSERT_STREQ(um.getUpdateById(id).currentVersion.c_str(), "1.0.0",
                     "version should be restored to previous");
    });

    RUN_TEST("testInstallFailureNoAutoRollback", []() {
        UpdateManager um;
        um.initialize();
        um.setAutoRollback(false);
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.setFailNextInstall(true);
        ASSERT_EQ(static_cast<int>(um.installUpdate(id)),
                  static_cast<int>(UpdateResult::INSTALL_FAILED),
                  "install should fail");
        UpdateProgress prog = um.getDownloadProgress(id);
        ASSERT_EQ(static_cast<int>(prog.state), static_cast<int>(UpdateState::FAILED),
                  "should be FAILED without auto-rollback");
        UpdateStats stats = um.getStats();
        ASSERT_EQ(stats.totalRollbacks, 0u, "should have 0 rollbacks");
    });

    RUN_TEST("testFailNextInstallReset", []() {
        UpdateManager um;
        um.initialize();
        UpdatePackage pkg = makePkg("test", "1.1.0");
        pkg.sizeBytes = 1000;
        pkg.signature = "sig";
        um.addAvailableUpdate(pkg);
        uint64_t id = um.getAvailableUpdates()[0].id;
        um.startDownload(id);
        um.updateDownloadProgress(id, 1000, 0);
        um.verifyUpdate(id);
        um.setFailNextInstall(true);
        um.installUpdate(id);  // Fails
        // failNextInstall should be reset, so next install succeeds
        UpdatePackage pkg2 = makePkg("test2", "1.2.0");
        pkg2.sizeBytes = 1000;
        pkg2.signature = "sig";
        um.addAvailableUpdate(pkg2);
        uint64_t id2 = um.getAvailableUpdates()[0].id;
        // Actually need to find the new one
        auto updates = um.getAvailableUpdates();
        id2 = updates.back().id;
        um.startDownload(id2);
        um.updateDownloadProgress(id2, 1000, 0);
        um.verifyUpdate(id2);
        ASSERT_TRUE(um.installUpdate(id2) == UpdateResult::SUCCESS,
                    "second install should succeed (failNextInstall reset)");
    });

    std::cout << "\n=== Summary ===" << std::endl;
    std::cout << "Tests passed: " << tests_passed << std::endl;
    std::cout << "Tests failed: " << tests_failed << std::endl;
    std::cout << "Total: " << (tests_passed + tests_failed) << std::endl;
}

int main() {
    std::cout << "=== Update Manager Tests ===" << std::endl;
    runAllTests();
    return tests_failed > 0 ? 1 : 0;
}
