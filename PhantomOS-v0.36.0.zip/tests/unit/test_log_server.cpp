/*
 * Phantom OS - Logging & Telemetry Server Tests
 * v0.17.0 — Log lifecycle, filtering, telemetry, export tests
 *
 * License: GPL-3.0
 */

#include "phantom/logging/log_server.h"
#include <cstdio>
#include <cstring>
#include <algorithm>

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %s\n", #name); \
    tests_passed++; \
    name(); \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

static void testInitialization() {
    phantom::logging::LogServer server;
    ASSERT_FALSE(server.isInitialized());

    auto result = server.initialize(5000);
    ASSERT_EQ(result, phantom::logging::LogResult::SUCCESS);
    ASSERT_TRUE(server.isInitialized());
    ASSERT_EQ(server.getMaxBufferSize(), 5000u);
}

static void testReinitialization() {
    phantom::logging::LogServer server;
    server.initialize();
    auto result = server.initialize();
    ASSERT_EQ(result, phantom::logging::LogResult::ALREADY_INITIALIZED);
}

static void testShutdown() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Test message");
    server.shutdown();
    ASSERT_FALSE(server.isInitialized());
    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(0));
}

static void testLogBasic() {
    phantom::logging::LogServer server;
    server.initialize();

    auto id = server.logInfo(phantom::logging::LogSource::KERNEL, "Boot started");
    ASSERT_TRUE(id > 0);
    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(1));

    auto logs = server.getLogs();
    ASSERT_EQ(logs.size(), static_cast<size_t>(1));
    ASSERT_EQ(logs[0].level, phantom::logging::LogLevel::INFO);
    ASSERT_EQ(logs[0].source, phantom::logging::LogSource::KERNEL);
}

static void testLogLevels() {
    phantom::logging::LogServer server;
    server.initialize();

    server.logTrace(phantom::logging::LogSource::DRIVER, "Trace msg");
    server.logDebug(phantom::logging::LogSource::DRIVER, "Debug msg");
    server.logInfo(phantom::logging::LogSource::DRIVER, "Info msg");
    server.logWarn(phantom::logging::LogSource::DRIVER, "Warn msg");
    server.logError(phantom::logging::LogSource::DRIVER, "Error msg");
    server.logFatal(phantom::logging::LogSource::DRIVER, "Fatal msg");

    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(6));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::TRACE), static_cast<size_t>(1));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::DEBUG), static_cast<size_t>(1));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::INFO), static_cast<size_t>(1));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::WARN), static_cast<size_t>(1));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::ERROR), static_cast<size_t>(1));
    ASSERT_EQ(server.getLogCountByLevel(phantom::logging::LogLevel::FATAL), static_cast<size_t>(1));
}

static void testLogWithFullDetails() {
    phantom::logging::LogServer server;
    server.initialize();

    server.log(phantom::logging::LogLevel::ERROR, phantom::logging::LogSource::NIDS,
               phantom::logging::LogCategory::SECURITY_EVENT,
               "Port scan detected", "NIDS", "detector", 1234);

    auto logs = server.getLogs();
    ASSERT_EQ(logs.size(), static_cast<size_t>(1));
    ASSERT_EQ(logs[0].message, "Port scan detected");
    ASSERT_EQ(logs[0].tag, "NIDS");
    ASSERT_EQ(logs[0].component, "detector");
    ASSERT_EQ(logs[0].pid, 1234u);
    ASSERT_EQ(logs[0].category, phantom::logging::LogCategory::SECURITY_EVENT);
}

static void testMinLogLevel() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setMinLogLevel(phantom::logging::LogLevel::WARN);

    server.logInfo(phantom::logging::LogSource::KERNEL, "Should be filtered");
    server.logWarn(phantom::logging::LogSource::KERNEL, "Should pass");
    server.logError(phantom::logging::LogSource::KERNEL, "Should pass");

    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(2));
    ASSERT_EQ(server.getMinLogLevel(), phantom::logging::LogLevel::WARN);
}

static void testLogByLevel() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1");
    server.logWarn(phantom::logging::LogSource::KERNEL, "Msg 2");
    server.logError(phantom::logging::LogSource::KERNEL, "Msg 3");

    auto errors = server.getLogsByLevel(phantom::logging::LogLevel::ERROR);
    ASSERT_EQ(errors.size(), static_cast<size_t>(1));
    ASSERT_EQ(errors[0].message, "Msg 3");
}

static void testLogBySource() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Kernel msg");
    server.logInfo(phantom::logging::LogSource::DRIVER, "Driver msg");

    auto kernelLogs = server.getLogsBySource(phantom::logging::LogSource::KERNEL);
    ASSERT_EQ(kernelLogs.size(), static_cast<size_t>(1));
}

static void testLogByCategory() {
    phantom::logging::LogServer server;
    server.initialize();
    server.log(phantom::logging::LogLevel::INFO, phantom::logging::LogSource::SYSTEM_SERVER,
               phantom::logging::LogCategory::BOOT, "Boot started");
    server.log(phantom::logging::LogLevel::INFO, phantom::logging::LogSource::SYSTEM_SERVER,
               phantom::logging::LogCategory::SHUTDOWN, "Shutdown started");

    auto bootLogs = server.getLogsByCategory(phantom::logging::LogCategory::BOOT);
    ASSERT_EQ(bootLogs.size(), static_cast<size_t>(1));
}

static void testLogByTag() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1", "BOOT");
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 2", "DRIVER");

    auto tagged = server.getLogsByTag("BOOT");
    ASSERT_EQ(tagged.size(), static_cast<size_t>(1));
}

static void testLogByComponent() {
    phantom::logging::LogServer server;
    server.initialize();
    server.log(phantom::logging::LogLevel::INFO, phantom::logging::LogSource::APP,
               phantom::logging::LogCategory::APP_EVENT, "Msg", "", "settings_app");
    server.log(phantom::logging::LogLevel::INFO, phantom::logging::LogSource::APP,
               phantom::logging::LogCategory::APP_EVENT, "Msg", "", "terminal_app");

    auto component = server.getLogsByComponent("settings_app");
    ASSERT_EQ(component.size(), static_cast<size_t>(1));
}

static void testLogById() {
    phantom::logging::LogServer server;
    server.initialize();
    auto id = server.logInfo(phantom::logging::LogSource::KERNEL, "Test msg");

    auto entry = server.getLogById(id);
    ASSERT_EQ(entry.id, id);
    ASSERT_EQ(entry.message, "Test msg");
}

static void testLogByIdNotFound() {
    phantom::logging::LogServer server;
    server.initialize();
    auto entry = server.getLogById(99999);
    ASSERT_EQ(entry.id, 0u);
}

static void testRecentLogs() {
    phantom::logging::LogServer server;
    server.initialize();
    for (int i = 0; i < 10; i++) {
        server.logInfo(phantom::logging::LogSource::KERNEL, "Msg " + std::to_string(i));
    }

    auto recent = server.getRecentLogs(5);
    ASSERT_EQ(recent.size(), static_cast<size_t>(5));
    // Most recent 5 should be Msg 5-9
    ASSERT_EQ(recent[4].message, "Msg 9");
}

static void testClearLogs() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1");
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 2");
    server.clearLogs();
    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(0));
}

static void testBufferRotation() {
    phantom::logging::LogServer server;
    server.initialize(5);  // Small buffer

    for (int i = 0; i < 10; i++) {
        server.logInfo(phantom::logging::LogSource::KERNEL, "Msg " + std::to_string(i));
    }

    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(5));  // Only last 5 kept

    auto stats = server.getStats();
    ASSERT_TRUE(stats.entriesDropped > 0);
}

static void testFilters() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::LogFilter filter;
    filter.name = "Errors only";
    filter.minLevel = phantom::logging::LogLevel::ERROR;

    auto filterId = server.addFilter(filter);
    ASSERT_TRUE(filterId > 0);

    server.logInfo(phantom::logging::LogSource::KERNEL, "Info msg");
    server.logError(phantom::logging::LogSource::KERNEL, "Error msg");
    server.logFatal(phantom::logging::LogSource::KERNEL, "Fatal msg");

    auto filtered = server.getFilteredLogs(filter);
    ASSERT_EQ(filtered.size(), static_cast<size_t>(2));  // ERROR + FATAL
}

static void testFilterBySource() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::LogFilter filter;
    filter.name = "Kernel only";
    filter.source = phantom::logging::LogSource::KERNEL;

    server.addFilter(filter);
    server.logInfo(phantom::logging::LogSource::KERNEL, "Kernel msg");
    server.logInfo(phantom::logging::LogSource::DRIVER, "Driver msg");

    auto filtered = server.getFilteredLogs(filter);
    ASSERT_EQ(filtered.size(), static_cast<size_t>(1));
}

static void testFilterEnableDisable() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::LogFilter filter;
    filter.name = "Test filter";
    filter.minLevel = phantom::logging::LogLevel::ERROR;
    auto id = server.addFilter(filter);

    ASSERT_EQ(server.getActiveFilterCount(), static_cast<size_t>(1));
    server.disableFilter(id);
    ASSERT_EQ(server.getActiveFilterCount(), static_cast<size_t>(0));
    server.enableFilter(id);
    ASSERT_EQ(server.getActiveFilterCount(), static_cast<size_t>(1));
}

static void testRemoveFilter() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::LogFilter filter;
    filter.name = "Temp filter";
    auto id = server.addFilter(filter);
    ASSERT_TRUE(id > 0);

    bool removed = server.removeFilter(id);
    ASSERT_TRUE(removed);

    auto filters = server.getFilters();
    ASSERT_EQ(filters.size(), static_cast<size_t>(0));
}

static void testFilterNotFound() {
    phantom::logging::LogServer server;
    server.initialize();

    bool removed = server.removeFilter(999);
    ASSERT_FALSE(removed);

    auto filter = server.getFilter(999);
    ASSERT_EQ(filter.id, 0u);
}

static void testTelemetryPrivacy() {
    phantom::logging::LogServer server;
    server.initialize();

    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::FULL);
    ASSERT_EQ(server.getTelemetryPrivacy(), phantom::logging::TelemetryPrivacyLevel::FULL);

    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::DISABLED);
    ASSERT_EQ(server.getTelemetryPrivacy(), phantom::logging::TelemetryPrivacyLevel::DISABLED);
}

static void testTelemetryMetrics() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::TelemetryMetric metric;
    metric.type = phantom::logging::TelemetryType::CPU_USAGE;
    metric.name = "CPU";
    metric.unit = "%";
    metric.value = 45.0;
    metric.privacy = phantom::logging::TelemetryPrivacyLevel::MINIMAL;

    auto id = server.registerTelemetryMetric(metric);
    ASSERT_TRUE(id > 0);

    auto metrics = server.getTelemetryMetrics();
    ASSERT_EQ(metrics.size(), static_cast<size_t>(1));
    ASSERT_EQ(metrics[0].name, "CPU");
}

static void testUpdateTelemetryMetric() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::TelemetryMetric metric;
    metric.name = "Memory";
    metric.value = 50.0;
    auto id = server.registerTelemetryMetric(metric);

    bool updated = server.updateTelemetryMetric(id, 75.0);
    ASSERT_TRUE(updated);

    auto m = server.getTelemetryMetric(id);
    ASSERT_EQ(m.value, 75.0);
}

static void testTelemetrySnapshot() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::FULL);

    phantom::logging::TelemetrySnapshot snapshot;
    snapshot.cpuUsage = 30.0;
    snapshot.memoryUsage = 60.0;
    snapshot.processCount = 42;
    snapshot.uptime = 3600;

    server.collectTelemetrySnapshot(snapshot);
    ASSERT_EQ(server.getSnapshotCount(), static_cast<size_t>(1));

    auto snapshots = server.getTelemetrySnapshots();
    ASSERT_EQ(snapshots[0].cpuUsage, 30.0);
}

static void testTelemetryDisabledNoSnapshot() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::DISABLED);

    phantom::logging::TelemetrySnapshot snapshot;
    snapshot.cpuUsage = 30.0;

    server.collectTelemetrySnapshot(snapshot);
    ASSERT_EQ(server.getSnapshotCount(), static_cast<size_t>(0));
}

static void testTelemetryMinimalPrivacy() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::MINIMAL);

    phantom::logging::TelemetrySnapshot snapshot;
    snapshot.cpuUsage = 30.0;
    snapshot.processCount = 42;
    snapshot.networkBytesSent = 1024;

    server.collectTelemetrySnapshot(snapshot);
    auto snapshots = server.getTelemetrySnapshots();
    ASSERT_EQ(snapshots[0].processCount, 0u);  // Anonymized
    ASSERT_EQ(snapshots[0].networkBytesSent, 0u);  // Anonymized
    ASSERT_EQ(snapshots[0].cpuUsage, 30.0);  // Kept
}

static void testRecentSnapshots() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::FULL);

    for (int i = 0; i < 5; i++) {
        phantom::logging::TelemetrySnapshot snapshot;
        snapshot.cpuUsage = static_cast<double>(i);
        server.collectTelemetrySnapshot(snapshot);
    }

    auto recent = server.getRecentSnapshots(3);
    ASSERT_EQ(recent.size(), static_cast<size_t>(3));
    ASSERT_EQ(recent[2].cpuUsage, 4.0);
}

static void testClearSnapshots() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::FULL);

    phantom::logging::TelemetrySnapshot snapshot;
    server.collectTelemetrySnapshot(snapshot);
    server.clearSnapshots();
    ASSERT_EQ(server.getSnapshotCount(), static_cast<size_t>(0));
}

static void testExportText() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Test message");

    std::string exported = server.exportLogs("text");
    ASSERT_TRUE(exported.find("Test message") != std::string::npos);
    ASSERT_TRUE(exported.find("INFO") != std::string::npos);
}

static void testExportCsv() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Test message");

    std::string exported = server.exportLogs("csv");
    ASSERT_TRUE(exported.find("id,timestamp,level") != std::string::npos);
    ASSERT_TRUE(exported.find("KERNEL") != std::string::npos);
}

static void testExportFilteredLogs() {
    phantom::logging::LogServer server;
    server.initialize();

    server.logInfo(phantom::logging::LogSource::KERNEL, "Info msg");
    server.logError(phantom::logging::LogSource::KERNEL, "Error msg");

    phantom::logging::LogFilter filter;
    filter.minLevel = phantom::logging::LogLevel::ERROR;

    std::string exported = server.exportFilteredLogs(filter, "text");
    ASSERT_TRUE(exported.find("Error msg") != std::string::npos);
    ASSERT_TRUE(exported.find("Info msg") == std::string::npos);
}

static void testExportTelemetry() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::TelemetryMetric metric;
    metric.name = "CPU";
    metric.value = 45.0;
    metric.unit = "%";
    server.registerTelemetryMetric(metric);

    std::string exported = server.exportTelemetry("text");
    ASSERT_TRUE(exported.find("CPU") != std::string::npos);
    ASSERT_TRUE(exported.find("45") != std::string::npos);
}

static void testLogCallback() {
    phantom::logging::LogServer server;
    server.initialize();

    int callbackCount = 0;
    server.setLogCallback([&](const phantom::logging::LogEntry&) {
        callbackCount++;
    });

    server.logInfo(phantom::logging::LogSource::KERNEL, "Test msg");
    ASSERT_EQ(callbackCount, 1);
}

static void testTelemetryCallback() {
    phantom::logging::LogServer server;
    server.initialize();
    server.setTelemetryPrivacy(phantom::logging::TelemetryPrivacyLevel::FULL);

    int callbackCount = 0;
    server.setTelemetryCallback([&](const phantom::logging::TelemetrySnapshot&) {
        callbackCount++;
    });

    phantom::logging::TelemetrySnapshot snapshot;
    server.collectTelemetrySnapshot(snapshot);
    ASSERT_EQ(callbackCount, 1);
}

static void testStats() {
    phantom::logging::LogServer server;
    server.initialize(1000);

    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1");
    server.logError(phantom::logging::LogSource::KERNEL, "Msg 2");

    auto stats = server.getStats();
    ASSERT_TRUE(stats.totalEntries > 0);
    ASSERT_EQ(stats.bufferSize, static_cast<uint64_t>(2));
    ASSERT_EQ(stats.maxBufferSize, 1000u);
    ASSERT_TRUE(stats.entriesByLevel[static_cast<int>(phantom::logging::LogLevel::INFO)] > 0);
    ASSERT_TRUE(stats.entriesByLevel[static_cast<int>(phantom::logging::LogLevel::ERROR)] > 0);
}

static void testResetStats() {
    phantom::logging::LogServer server;
    server.initialize();
    server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1");
    server.resetStats();

    auto stats = server.getStats();
    ASSERT_EQ(stats.entriesByLevel[static_cast<int>(phantom::logging::LogLevel::INFO)], 0u);
}

static void testStringHelpers() {
    ASSERT_STREQ(phantom::logging::LogServer::logLevelToString(phantom::logging::LogLevel::INFO), "INFO");
    ASSERT_STREQ(phantom::logging::LogServer::logSourceToString(phantom::logging::LogSource::KERNEL), "KERNEL");
    ASSERT_STREQ(phantom::logging::LogServer::logCategoryToString(phantom::logging::LogCategory::BOOT), "BOOT");
    ASSERT_STREQ(phantom::logging::LogServer::telemetryTypeToString(phantom::logging::TelemetryType::CPU_USAGE), "CPU_USAGE");
    ASSERT_STREQ(phantom::logging::LogServer::telemetryPrivacyToString(phantom::logging::TelemetryPrivacyLevel::FULL), "FULL");
    ASSERT_STREQ(phantom::logging::LogServer::logResultToString(phantom::logging::LogResult::SUCCESS), "SUCCESS");
}

static void testStringToLogLevel() {
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("TRACE"), phantom::logging::LogLevel::TRACE);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("DEBUG"), phantom::logging::LogLevel::DEBUG);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("INFO"), phantom::logging::LogLevel::INFO);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("WARN"), phantom::logging::LogLevel::WARN);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("ERROR"), phantom::logging::LogLevel::ERROR);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("FATAL"), phantom::logging::LogLevel::FATAL);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("NONE"), phantom::logging::LogLevel::NONE);
    ASSERT_EQ(phantom::logging::LogServer::stringToLogLevel("UNKNOWN"), phantom::logging::LogLevel::INFO);
}

static void testTrimLogs() {
    phantom::logging::LogServer server;
    server.initialize(10000);

    for (int i = 0; i < 10; i++) {
        server.logInfo(phantom::logging::LogSource::KERNEL, "Msg");
    }

    ASSERT_EQ(server.getLogCount(), static_cast<size_t>(10));

    // Trim entries older than 1ms — should remove most
    server.trimLogs(1);
    // After trimming, there might be 0 or very few entries
    ASSERT_TRUE(server.getLogCount() <= 10);
}

static void testFilterByTagAndComponent() {
    phantom::logging::LogServer server;
    server.initialize();

    phantom::logging::LogFilter filter;
    filter.name = "NIDS security";
    filter.tagFilter = "NIDS";
    filter.componentFilter = "detector";

    server.addFilter(filter);

    server.log(phantom::logging::LogLevel::WARN, phantom::logging::LogSource::NIDS,
               phantom::logging::LogCategory::SECURITY_EVENT, "Alert", "NIDS", "detector");
    server.log(phantom::logging::LogLevel::WARN, phantom::logging::LogSource::NIDS,
               phantom::logging::LogCategory::SECURITY_EVENT, "Other", "NIDS", "firewall");
    server.log(phantom::logging::LogLevel::WARN, phantom::logging::LogSource::KERNEL,
               phantom::logging::LogCategory::GENERAL, "Different", "BOOT", "kernel");

    auto filtered = server.getFilteredLogs(filter);
    ASSERT_EQ(filtered.size(), static_cast<size_t>(1));
}

static void testLogsInRange() {
    phantom::logging::LogServer server;
    server.initialize();

    auto id1 = server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 1");
    auto id2 = server.logInfo(phantom::logging::LogSource::KERNEL, "Msg 2");

    auto entry1 = server.getLogById(id1);
    auto entry2 = server.getLogById(id2);

    auto inRange = server.getLogsInRange(entry1.timestamp, entry2.timestamp);
    ASSERT_TRUE(inRange.size() >= 2);
}

int runAllTests() {
    printf("=== Log Server Tests ===\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testReinitialization);
    RUN_TEST(testShutdown);
    RUN_TEST(testLogBasic);
    RUN_TEST(testLogLevels);
    RUN_TEST(testLogWithFullDetails);
    RUN_TEST(testMinLogLevel);
    RUN_TEST(testLogByLevel);
    RUN_TEST(testLogBySource);
    RUN_TEST(testLogByCategory);
    RUN_TEST(testLogByTag);
    RUN_TEST(testLogByComponent);
    RUN_TEST(testLogById);
    RUN_TEST(testLogByIdNotFound);
    RUN_TEST(testRecentLogs);
    RUN_TEST(testClearLogs);
    RUN_TEST(testBufferRotation);
    RUN_TEST(testFilters);
    RUN_TEST(testFilterBySource);
    RUN_TEST(testFilterEnableDisable);
    RUN_TEST(testRemoveFilter);
    RUN_TEST(testFilterNotFound);
    RUN_TEST(testTelemetryPrivacy);
    RUN_TEST(testTelemetryMetrics);
    RUN_TEST(testUpdateTelemetryMetric);
    RUN_TEST(testTelemetrySnapshot);
    RUN_TEST(testTelemetryDisabledNoSnapshot);
    RUN_TEST(testTelemetryMinimalPrivacy);
    RUN_TEST(testRecentSnapshots);
    RUN_TEST(testClearSnapshots);
    RUN_TEST(testExportText);
    RUN_TEST(testExportCsv);
    RUN_TEST(testExportFilteredLogs);
    RUN_TEST(testExportTelemetry);
    RUN_TEST(testLogCallback);
    RUN_TEST(testTelemetryCallback);
    RUN_TEST(testStats);
    RUN_TEST(testResetStats);
    RUN_TEST(testStringHelpers);
    RUN_TEST(testStringToLogLevel);
    RUN_TEST(testTrimLogs);
    RUN_TEST(testFilterByTagAndComponent);
    RUN_TEST(testLogsInRange);
    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);
    return tests_failed > 0 ? 1 : 0;
}

int main() {
    return runAllTests();
}
