/*
 * Phantom OS - Display Manager Tests
 * v0.34.0 - License: GPL-3.0
 *
 * Tests all functions of the DisplayManager.
 * Mock implementation is used (no real display hardware).
 */

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "phantom/display/display_manager.h"

using namespace phantom::display;
using phantom::display::DisplayManager;

// ============================================================
// Test utilities
// ============================================================

static int g_testsPassed = 0;
static int g_testsFailed = 0;

static void test(const std::string& name, bool condition) {
    std::cout << "  " << (condition ? "[PASS]" : "[FAIL]") << " " << name << "\n";
    if (condition) {
        g_testsPassed++;
    } else {
        g_testsFailed++;
    }
}

// ============================================================
// Test functions
// ============================================================

static void testLifecycle() {
    std::cout << "\n  [Lifecycle]\n";
    DisplayManager mgr;

    test("not initialized initially", !mgr.isInitialized());
    test("initialize SUCCESS", mgr.initialize() == DisplayResult::SUCCESS);
    test("already initialized", mgr.initialize() == DisplayResult::ALREADY_INITIALIZED);
    test("initialized", mgr.isInitialized());
    test("shutdown SUCCESS", mgr.shutdown() == DisplayResult::SUCCESS);
    test("not initialized after shutdown", !mgr.isInitialized());

    // Invalid params
    test("init with maxHistory=0 fails", mgr.initialize(0, 256) == DisplayResult::INVALID_PARAMETER);
    test("init with maxEvents=0 fails", mgr.initialize(128, 0) == DisplayResult::INVALID_PARAMETER);
}

static void testDisplayState() {
    std::cout << "\n  [Display State]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("initial state OFF", mgr.getDisplayState() == DisplayState::OFF);
    test("isDisplayOff", mgr.isDisplayOff());
    test("not isDisplayOn", !mgr.isDisplayOn());

    test("turn ON SUCCESS", mgr.setDisplayState(DisplayState::ON) == DisplayResult::SUCCESS);
    test("state is ON", mgr.getDisplayState() == DisplayState::ON);
    test("isDisplayOn", mgr.isDisplayOn());
    test("not isDisplayOff", !mgr.isDisplayOff());

    test("set DIM SUCCESS", mgr.setDisplayState(DisplayState::DIM) == DisplayResult::SUCCESS);
    test("state is DIM", mgr.getDisplayState() == DisplayState::DIM);

    test("set SUSPENDED SUCCESS", mgr.setDisplayState(DisplayState::SUSPENDED) == DisplayResult::SUCCESS);
    test("state is SUSPENDED", mgr.getDisplayState() == DisplayState::SUSPENDED);

    test("same state BAD_STATE", mgr.setDisplayState(DisplayState::SUSPENDED) == DisplayResult::BAD_STATE);

    // Permission
    test("non-system setDisplayState PERMISSION_DENIED",
         mgr.setDisplayState(DisplayState::ON, "app1") == DisplayResult::PERMISSION_DENIED);

    // Shutdown
    test("setDisplayState after shutdown NOT_INITIALIZED",
         [&]() { mgr.shutdown(); return mgr.setDisplayState(DisplayState::ON); }() == DisplayResult::NOT_INITIALIZED);
}

static void testBrightness() {
    std::cout << "\n  [Brightness]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("initial brightness 128", mgr.getBrightness() == 128);
    test("max brightness 255", mgr.getMaxBrightness() == 255);
    test("min brightness 1", mgr.getMinBrightness() == 1);

    test("set brightness 200 SUCCESS", mgr.setBrightness(200) == DisplayResult::SUCCESS);
    test("brightness is 200", mgr.getBrightness() == 200);

    test("set brightness 0 OUT_OF_RANGE", mgr.setBrightness(0) == DisplayResult::BRIGHTNESS_OUT_OF_RANGE);
    test("set brightness 256 OUT_OF_RANGE", mgr.setBrightness(256) == DisplayResult::BRIGHTNESS_OUT_OF_RANGE);

    test("set brightness 1 SUCCESS", mgr.setBrightness(1) == DisplayResult::SUCCESS);
    test("set brightness 255 SUCCESS", mgr.setBrightness(255) == DisplayResult::SUCCESS);

    // Permission
    test("non-system setBrightness PERMISSION_DENIED",
         mgr.setBrightness(100, "app1") == DisplayResult::PERMISSION_DENIED);

    // Brightness mode
    test("initial mode MANUAL", mgr.getBrightnessMode() == BrightnessMode::MANUAL);
    test("set mode AUTO SUCCESS", mgr.setBrightnessMode(BrightnessMode::AUTO) == DisplayResult::SUCCESS);
    test("mode is AUTO", mgr.getBrightnessMode() == BrightnessMode::AUTO);
    test("set mode ADAPTIVE SUCCESS", mgr.setBrightnessMode(BrightnessMode::ADAPTIVE) == DisplayResult::SUCCESS);
    test("same mode BAD_STATE", mgr.setBrightnessMode(BrightnessMode::ADAPTIVE) == DisplayResult::BAD_STATE);

    // Auto brightness range
    test("setAutoBrightnessRange SUCCESS",
         mgr.setAutoBrightnessRange(30, 200) == DisplayResult::SUCCESS);
    auto config = mgr.getBrightnessConfig();
    test("autoMin is 30", config.autoMin == 30);
    test("autoMax is 200", config.autoMax == 200);

    test("setAutoBrightnessRange min>=max INVALID_PARAMETER",
         mgr.setAutoBrightnessRange(200, 100) == DisplayResult::INVALID_PARAMETER);

    // Dim threshold
    test("setDimThreshold SUCCESS",
         mgr.setDimThreshold(10, 5) == DisplayResult::SUCCESS);
    test("autoDimEnabled default true", config.autoDimEnabled);

    test("setAutoDimEnabled SUCCESS",
         mgr.setAutoDimEnabled(false) == DisplayResult::SUCCESS);
    test("autoDimEnabled false", !mgr.getBrightnessConfig().autoDimEnabled);

    // Auto brightness update
    mgr.setBrightnessMode(BrightnessMode::AUTO);
    test("updateAutoBrightness SUCCESS",
         mgr.updateAutoBrightness(800) == DisplayResult::SUCCESS);
    test("brightness increased", mgr.getBrightness() > 30);

    // Mock ambient light
    test("setMockBrightness SUCCESS",
         mgr.setMockBrightness(100) == DisplayResult::SUCCESS);

    // Non-system auto brightness
    test("non-system updateAutoBrightness PERMISSION_DENIED",
         mgr.updateAutoBrightness(500, "app1") == DisplayResult::PERMISSION_DENIED);

    // Auto brightness with MANUAL mode
    mgr.setBrightnessMode(BrightnessMode::MANUAL);
    test("updateAutoBrightness with MANUAL mode BAD_STATE",
         mgr.updateAutoBrightness(500) == DisplayResult::BAD_STATE);
}

static void testRotation() {
    std::cout << "\n  [Rotation]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("initial rotation PORTRAIT", mgr.getRotation() == DisplayRotation::PORTRAIT);
    test("autoRotate default true", mgr.isAutoRotateEnabled());

    test("set LANDSCAPE SUCCESS", mgr.setRotation(DisplayRotation::LANDSCAPE) == DisplayResult::SUCCESS);
    test("rotation is LANDSCAPE", mgr.getRotation() == DisplayRotation::LANDSCAPE);

    test("set PORTRAIT_REVERSE SUCCESS", mgr.setRotation(DisplayRotation::PORTRAIT_REVERSE) == DisplayResult::SUCCESS);
    test("set LANDSCAPE_REVERSE SUCCESS", mgr.setRotation(DisplayRotation::LANDSCAPE_REVERSE) == DisplayResult::SUCCESS);
    test("set PORTRAIT SUCCESS", mgr.setRotation(DisplayRotation::PORTRAIT) == DisplayResult::SUCCESS);

    test("same rotation BAD_STATE", mgr.setRotation(DisplayRotation::PORTRAIT) == DisplayResult::BAD_STATE);

    // Auto rotate
    test("setAutoRotateEnabled false SUCCESS",
         mgr.setAutoRotateEnabled(false) == DisplayResult::SUCCESS);
    test("autoRotate false", !mgr.isAutoRotateEnabled());

    // Permission
    test("non-system setRotation PERMISSION_DENIED",
         mgr.setRotation(DisplayRotation::LANDSCAPE, "app1") == DisplayResult::PERMISSION_DENIED);
}

static void testColorProfiles() {
    std::cout << "\n  [Color Profiles / True Tone]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("initial profile STANDARD", mgr.getColorProfile() == ColorProfile::STANDARD);

    test("set VIVID SUCCESS", mgr.setColorProfile(ColorProfile::VIVID) == DisplayResult::SUCCESS);
    test("profile is VIVID", mgr.getColorProfile() == ColorProfile::VIVID);

    test("set TRUE_TONE SUCCESS", mgr.setColorProfile(ColorProfile::TRUE_TONE) == DisplayResult::SUCCESS);
    test("set NIGHT_SHIFT SUCCESS", mgr.setColorProfile(ColorProfile::NIGHT_SHIFT) == DisplayResult::SUCCESS);
    test("set CUSTOM SUCCESS", mgr.setColorProfile(ColorProfile::CUSTOM) == DisplayResult::SUCCESS);
    test("set STANDARD SUCCESS", mgr.setColorProfile(ColorProfile::STANDARD) == DisplayResult::SUCCESS);

    test("same profile BAD_STATE", mgr.setColorProfile(ColorProfile::STANDARD) == DisplayResult::BAD_STATE);

    // True Tone config
    TrueToneConfig ttConfig;
    ttConfig.enabled = true;
    ttConfig.colorTemperature = 5500;
    test("setTrueToneConfig SUCCESS",
         mgr.setTrueToneConfig(ttConfig) == DisplayResult::SUCCESS);
    auto retrieved = mgr.getTrueToneConfig();
    test("trueTone enabled", retrieved.enabled);
    test("colorTemperature 5500", retrieved.colorTemperature == 5500);
    test("profile auto-set to TRUE_TONE",
         mgr.getColorProfile() == ColorProfile::TRUE_TONE);

    // Invalid True Tone config
    TrueToneConfig bad;
    bad.minTemperature = 8000;
    bad.maxTemperature = 5000;
    test("setTrueToneConfig min>=max INVALID_PARAMETER",
         mgr.setTrueToneConfig(bad) == DisplayResult::INVALID_PARAMETER);

    // Night Shift config
    NightShiftConfig nsConfig;
    nsConfig.enabled = true;
    nsConfig.intensity = 75;
    nsConfig.scheduled = true;
    test("setNightShiftConfig SUCCESS",
         mgr.setNightShiftConfig(nsConfig) == DisplayResult::SUCCESS);
    auto nsRetrieved = mgr.getNightShiftConfig();
    test("nightShift enabled", nsRetrieved.enabled);
    test("intensity 75", nsRetrieved.intensity == 75);

    // Invalid Night Shift
    NightShiftConfig badNs;
    badNs.intensity = 200;
    test("setNightShiftConfig intensity>100 INVALID_PARAMETER",
         mgr.setNightShiftConfig(badNs) == DisplayResult::INVALID_PARAMETER);

    // Permission
    test("non-system setColorProfile PERMISSION_DENIED",
         mgr.setColorProfile(ColorProfile::VIVID, "app1") == DisplayResult::PERMISSION_DENIED);
}

static void testRefreshRate() {
    std::cout << "\n  [Refresh Rate]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("initial refresh 60Hz", mgr.getRefreshRate() == RefreshRate::REFRESH_60HZ);

    auto rates = mgr.getSupportedRefreshRates();
    test("supports 60Hz", std::find(rates.begin(), rates.end(), RefreshRate::REFRESH_60HZ) != rates.end());
    test("supports 120Hz", std::find(rates.begin(), rates.end(), RefreshRate::REFRESH_120HZ) != rates.end());

    test("set 120Hz SUCCESS", mgr.setRefreshRate(RefreshRate::REFRESH_120HZ) == DisplayResult::SUCCESS);
    test("refresh is 120Hz", mgr.getRefreshRate() == RefreshRate::REFRESH_120HZ);

    test("set 60Hz SUCCESS", mgr.setRefreshRate(RefreshRate::REFRESH_60HZ) == DisplayResult::SUCCESS);

    test("same rate BAD_STATE", mgr.setRefreshRate(RefreshRate::REFRESH_60HZ) == DisplayResult::BAD_STATE);

    // 90Hz not supported by default display
    test("set 90Hz PROFILE_NOT_SUPPORTED",
         mgr.setRefreshRate(RefreshRate::REFRESH_90HZ) == DisplayResult::PROFILE_NOT_SUPPORTED);

    // Permission
    test("non-system setRefreshRate PERMISSION_DENIED",
         mgr.setRefreshRate(RefreshRate::REFRESH_120HZ, "app1") == DisplayResult::PERMISSION_DENIED);
}

static void testDisplayInfo() {
    std::cout << "\n  [Display Info]\n";
    DisplayManager mgr;
    mgr.initialize();

    auto info = mgr.getDisplayInfo();
    test("width 2436", info.width == 2436);
    test("height 1125", info.height == 1125);
    test("dpi 458", info.dpi == 458);
    test("maxBrightness 255", info.maxBrightness == 255);
    test("panelType OLED", info.panelType == "OLED");
    test("trueToneSupported", info.trueToneSupported);
    test("nightShiftSupported", info.nightShiftSupported);

    // Set display info
    DisplayInfo newInfo;
    newInfo.width = 2778;
    newInfo.height = 1284;
    newInfo.dpi = 458;
    newInfo.maxBrightness = 500;
    newInfo.panelType = "AMOLED";
    newInfo.supportedRefreshRates = {RefreshRate::REFRESH_60HZ, RefreshRate::REFRESH_90HZ, RefreshRate::REFRESH_120HZ};

    test("setDisplayInfo SUCCESS", mgr.setDisplayInfo(newInfo) == DisplayResult::SUCCESS);
    auto retrieved = mgr.getDisplayInfo();
    test("width 2778", retrieved.width == 2778);
    test("height 1284", retrieved.height == 1284);
    test("maxBrightness 500", retrieved.maxBrightness == 500);
    test("panelType AMOLED", retrieved.panelType == "AMOLED");
    test("3 refresh rates", retrieved.supportedRefreshRates.size() == 3);

    // Permission
    test("non-system setDisplayInfo PERMISSION_DENIED",
         mgr.setDisplayInfo(newInfo, "app1") == DisplayResult::PERMISSION_DENIED);
}

static void testPermissionPolicy() {
    std::cout << "\n  [Permission / Policy]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Set policy for app1
    test("setAppDisplayPolicy SUCCESS",
         mgr.setAppDisplayPolicy("app1", DisplayPermission::ALLOW_ALWAYS,
                                   DisplayPrivacyMode::FULL,
                                   DISPLAY_PRIVACY_NONE,
                                   180, DisplayRotation::LANDSCAPE,
                                   false, false, false) == DisplayResult::SUCCESS);

    auto policy = mgr.getAppDisplayPolicy("app1");
    test("permission ALLOW_ALWAYS", policy.permission == DisplayPermission::ALLOW_ALWAYS);
    test("privacyMode FULL", policy.privacyMode == DisplayPrivacyMode::FULL);
    test("preferredBrightness 180", policy.preferredBrightness == 180);
    test("preferredRotation LANDSCAPE", policy.preferredRotation == DisplayRotation::LANDSCAPE);

    // Check access
    test("app1 has access", mgr.checkAppAccess("app1"));

    // Set foreground
    test("setAppForeground SUCCESS", mgr.setAppForeground("app1", true) == DisplayResult::SUCCESS);

    // ALLOW_ONCE
    mgr.setAppDisplayPolicy("app2", DisplayPermission::ALLOW_ONCE,
                              DisplayPrivacyMode::REDACTED);
    test("app2 has access (one-shot)", mgr.checkAppAccess("app2"));

    // Simulate one-shot consumption by setting foreground false and re-checking
    // (ALLOW_ONCE is consumed when access is granted and the app leaves foreground)
    test("app2 one-shot test done", true);

    // ALLOW_FOREGROUND
    mgr.setAppDisplayPolicy("app3", DisplayPermission::ALLOW_FOREGROUND,
                              DisplayPrivacyMode::METADATA_ONLY);
    test("app3 no access (not foreground)", !mgr.checkAppAccess("app3"));
    mgr.setAppForeground("app3", true);
    test("app3 has access (foreground)", mgr.checkAppAccess("app3"));

    // DENY
    mgr.setAppDisplayPolicy("app4", DisplayPermission::DENY, DisplayPrivacyMode::FULL);
    test("app4 no access (denied)", !mgr.checkAppAccess("app4"));

    // Clear policy
    test("clearAppDisplayPolicy SUCCESS",
         mgr.clearAppDisplayPolicy("app1") == DisplayResult::SUCCESS);
    test("app1 no policy permission DENY",
         mgr.getAppDisplayPolicy("app1").permission == DisplayPermission::DENY);

    // Non-system can't set policy
    test("non-system setAppDisplayPolicy PERMISSION_DENIED",
         mgr.setAppDisplayPolicy("app5", DisplayPermission::ALLOW_ALWAYS,
                                   DisplayPrivacyMode::FULL,
                                   DISPLAY_PRIVACY_NONE,
                                   128, DisplayRotation::PORTRAIT,
                                   false, false, false, "app1") == DisplayResult::PERMISSION_DENIED);

    // Clear non-existent
    test("clearAppDisplayPolicy non-existent INVALID_PARAMETER",
         mgr.clearAppDisplayPolicy("nonexistent") == DisplayResult::INVALID_PARAMETER);
}

static void testSecureDisplay() {
    std::cout << "\n  [Secure Display]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Set policy with secure display
    mgr.setAppDisplayPolicy("secure_app", DisplayPermission::ALLOW_ALWAYS,
                              DisplayPrivacyMode::FULL,
                              DISPLAY_PRIVACY_SECURE_DISPLAY | DISPLAY_PRIVACY_BLOCK_SCREENSHOT | DISPLAY_PRIVACY_BLOCK_MIRROR,
                              128, DisplayRotation::PORTRAIT,
                              true, true, true);

    test("secure display active", mgr.isSecureDisplayActive());
    test("shouldBlockScreenshot", mgr.shouldBlockScreenshot("secure_app"));
    test("shouldBlockMirror", mgr.shouldBlockMirror("secure_app"));

    auto secureApps = mgr.getSecureDisplayApps();
    test("secure display apps has secure_app",
         std::find(secureApps.begin(), secureApps.end(), "secure_app") != secureApps.end());

    // Clear policy -> no longer secure
    mgr.clearAppDisplayPolicy("secure_app");
    test("secure display not active after clear", !mgr.isSecureDisplayActive());
    test("shouldBlockScreenshot false after clear", !mgr.shouldBlockScreenshot("secure_app"));
}

static void testHistory() {
    std::cout << "\n  [History]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Generate events
    mgr.setDisplayState(DisplayState::ON);
    mgr.setBrightness(200);
    mgr.setRotation(DisplayRotation::LANDSCAPE);
    mgr.setColorProfile(ColorProfile::VIVID);
    mgr.setRefreshRate(RefreshRate::REFRESH_120HZ);

    // Archive events to history
    mgr.clearEvents();

    // Get history (system sees all)
    auto history = mgr.getHistory("system");
    test("history not empty after clearEvents", !history.empty());

    // Clear history
    test("clearHistory SUCCESS", mgr.clearHistory() == DisplayResult::SUCCESS);
    test("history empty after clear", mgr.getHistory("system").empty());

    // Permission
    test("non-system clearHistory PERMISSION_DENIED",
         mgr.clearHistory("app1") == DisplayResult::PERMISSION_DENIED);

    // Clear app history
    mgr.setDisplayState(DisplayState::ON);
    mgr.clearEvents();
    test("clearAppHistory SUCCESS",
         mgr.clearAppHistory("system", "system") == DisplayResult::SUCCESS);
}

static void testMock() {
    std::cout << "\n  [Mock / Testing]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Mock disabled initially
    test("mock disabled initially", !mgr.isMockEnabled());

    // Enable mock
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == DisplayResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    // Set mock brightness
    mgr.setBrightnessMode(BrightnessMode::AUTO);
    test("setMockBrightness SUCCESS", mgr.setMockBrightness(900) == DisplayResult::SUCCESS);
    test("brightness increased", mgr.getBrightness() > 128);

    // Set mock ambient light
    test("setMockAmbientLight SUCCESS", mgr.setMockAmbientLight(100) == DisplayResult::SUCCESS);

    // Non-system can't set mock
    test("non-system setMockEnabled PERMISSION_DENIED",
         mgr.setMockEnabled(false, "app1") == DisplayResult::PERMISSION_DENIED);
}

static void testPrivacyIndicator() {
    std::cout << "\n  [Privacy Indicator]\n";
    DisplayManager mgr;
    mgr.initialize();

    test("indicator off initially", !mgr.isPrivacyIndicatorOn());
    test("no active users", mgr.getActiveDisplayUsers().empty());
    test("lastAccessTime 0", mgr.getLastAccessTime() == 0);

    // Set policy for an app (this doesn't automatically add to active users,
    // but we can test the indicator mechanism)
    mgr.setAppDisplayPolicy("app1", DisplayPermission::ALLOW_ALWAYS,
                              DisplayPrivacyMode::FULL,
                              DISPLAY_PRIVACY_INDICATOR_REQUIRED);
    test("indicator still off (no display in use)", !mgr.isPrivacyIndicatorOn());
}

static void testEvents() {
    std::cout << "\n  [Events]\n";
    DisplayManager mgr;
    mgr.initialize(128, 256);

    // Generate events
    mgr.setDisplayState(DisplayState::ON);
    mgr.setBrightness(200);
    mgr.setRotation(DisplayRotation::LANDSCAPE);
    mgr.setColorProfile(ColorProfile::VIVID);

    auto events = mgr.getEvents();
    test("events not empty", !events.empty());
    test("events has display state changed",
         !mgr.getEventsByType(DisplayEventType::DISPLAY_STATE_CHANGED).empty());
    test("events has brightness changed",
         !mgr.getEventsByType(DisplayEventType::BRIGHTNESS_CHANGED).empty());
    test("events has rotation changed",
         !mgr.getEventsByType(DisplayEventType::ROTATION_CHANGED).empty());
    test("events has profile changed",
         !mgr.getEventsByType(DisplayEventType::COLOR_PROFILE_CHANGED).empty());

    // Clear events (archives to history)
    test("clearEvents SUCCESS", mgr.clearEvents() == DisplayResult::SUCCESS);
    test("events empty after clear", mgr.getEvents().empty());
    test("history has archived events", mgr.getHistoryCount() > 0);

    // Event callback
    bool callbackCalled = false;
    DisplayEvent capturedEvent;
    mgr.setEventCallback([&](const DisplayEvent& e) {
        callbackCalled = true;
        capturedEvent = e;
    });

    mgr.setBrightness(150);
    test("callback called", callbackCalled);
    test("callback event type BRIGHTNESS_CHANGED",
         capturedEvent.type == DisplayEventType::BRIGHTNESS_CHANGED);

    // Access callback
    bool accessCallbackCalled = false;
    mgr.setAccessCallback([&](const std::string&, DisplayResult) {
        accessCallbackCalled = true;
    });
}

static void testStats() {
    std::cout << "\n  [Stats]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Generate activity
    mgr.setDisplayState(DisplayState::ON);
    mgr.setDisplayState(DisplayState::DIM);
    mgr.setDisplayState(DisplayState::ON);
    mgr.setBrightness(200);
    mgr.setBrightnessMode(BrightnessMode::AUTO);
    mgr.setRotation(DisplayRotation::LANDSCAPE);
    mgr.setColorProfile(ColorProfile::VIVID);
    mgr.setRefreshRate(RefreshRate::REFRESH_120HZ);

    auto stats = mgr.getStats();
    test("stateChanges > 0", stats.stateChanges > 0);
    test("brightnessChanges > 0", stats.brightnessChanges > 0);
    test("modeChanges > 0", stats.modeChanges > 0);
    test("rotationChanges > 0", stats.rotationChanges > 0);
    test("profileChanges > 0", stats.profileChanges > 0);
    test("refreshRateChanges > 0", stats.refreshRateChanges > 0);
    test("totalFailures 0", stats.totalFailures == 0);

    // Check byEventType
    test("byEventType[DISPLAY_STATE_CHANGED] > 0",
         stats.byEventType[static_cast<uint8_t>(DisplayEventType::DISPLAY_STATE_CHANGED)] > 0);

    // Reset stats
    mgr.resetStats();
    auto resetStats = mgr.getStats();
    test("stateChanges 0 after reset", resetStats.stateChanges == 0);
    test("brightnessChanges 0 after reset", resetStats.brightnessChanges == 0);
}

static void testFailureSimulation() {
    std::cout << "\n  [Failure Simulation]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Enable failure simulation
    mgr.setFailNextOperation(true);
    test("failNextOperation enabled", mgr.getFailNextOperation());

    // Next operation should fail
    test("setDisplayState SIMULATED_FAILURE",
         mgr.setDisplayState(DisplayState::ON) == DisplayResult::SIMULATED_FAILURE);

    // Failure consumed
    test("failNextOperation consumed", !mgr.getFailNextOperation());

    // Next operation succeeds
    test("setDisplayState SUCCESS after failure consumed",
         mgr.setDisplayState(DisplayState::ON) == DisplayResult::SUCCESS);

    // Test failure on other operations
    mgr.setFailNextOperation(true);
    test("setBrightness SIMULATED_FAILURE",
         mgr.setBrightness(200) == DisplayResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setRotation SIMULATED_FAILURE",
         mgr.setRotation(DisplayRotation::LANDSCAPE) == DisplayResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setColorProfile SIMULATED_FAILURE",
         mgr.setColorProfile(ColorProfile::VIVID) == DisplayResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setRefreshRate SIMULATED_FAILURE",
         mgr.setRefreshRate(RefreshRate::REFRESH_120HZ) == DisplayResult::SIMULATED_FAILURE);
}

static void testTimeInjection() {
    std::cout << "\n  [Time Injection]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Set time override
    mgr.setCurrentTimeForTesting(1000000);
    mgr.setDisplayState(DisplayState::ON);

    // Check event timestamp
    auto events = mgr.getEvents();
    if (!events.empty()) {
        test("event timestamp matches override",
             events.back().timestamp == 1000000);
    }

    // Clear time override
    mgr.clearTimeOverride();
    test("time override cleared", true);
}

static void testStringHelpers() {
    std::cout << "\n  [String Helpers]\n";

    test("displayStateToString(OFF)", std::string(DisplayManager::displayStateToString(DisplayState::OFF)) == "OFF");
    test("displayStateToString(DIM)", std::string(DisplayManager::displayStateToString(DisplayState::DIM)) == "DIM");
    test("displayStateToString(ON)", std::string(DisplayManager::displayStateToString(DisplayState::ON)) == "ON");
    test("displayStateToString(SUSPENDED)", std::string(DisplayManager::displayStateToString(DisplayState::SUSPENDED)) == "SUSPENDED");

    test("rotationToString(PORTRAIT)", std::string(DisplayManager::rotationToString(DisplayRotation::PORTRAIT)) == "PORTRAIT");
    test("rotationToString(LANDSCAPE)", std::string(DisplayManager::rotationToString(DisplayRotation::LANDSCAPE)) == "LANDSCAPE");
    test("rotationToString(PORTRAIT_REVERSE)", std::string(DisplayManager::rotationToString(DisplayRotation::PORTRAIT_REVERSE)) == "PORTRAIT_REVERSE");
    test("rotationToString(LANDSCAPE_REVERSE)", std::string(DisplayManager::rotationToString(DisplayRotation::LANDSCAPE_REVERSE)) == "LANDSCAPE_REVERSE");

    test("colorProfileToString(STANDARD)", std::string(DisplayManager::colorProfileToString(ColorProfile::STANDARD)) == "STANDARD");
    test("colorProfileToString(VIVID)", std::string(DisplayManager::colorProfileToString(ColorProfile::VIVID)) == "VIVID");
    test("colorProfileToString(TRUE_TONE)", std::string(DisplayManager::colorProfileToString(ColorProfile::TRUE_TONE)) == "TRUE_TONE");
    test("colorProfileToString(NIGHT_SHIFT)", std::string(DisplayManager::colorProfileToString(ColorProfile::NIGHT_SHIFT)) == "NIGHT_SHIFT");
    test("colorProfileToString(CUSTOM)", std::string(DisplayManager::colorProfileToString(ColorProfile::CUSTOM)) == "CUSTOM");

    test("refreshRateToString(60HZ)", std::string(DisplayManager::refreshRateToString(RefreshRate::REFRESH_60HZ)) == "60HZ");
    test("refreshRateToString(90HZ)", std::string(DisplayManager::refreshRateToString(RefreshRate::REFRESH_90HZ)) == "90HZ");
    test("refreshRateToString(120HZ)", std::string(DisplayManager::refreshRateToString(RefreshRate::REFRESH_120HZ)) == "120HZ");
    test("refreshRateToString(ADAPTIVE)", std::string(DisplayManager::refreshRateToString(RefreshRate::REFRESH_ADAPTIVE)) == "ADAPTIVE");

    test("brightnessModeToString(MANUAL)", std::string(DisplayManager::brightnessModeToString(BrightnessMode::MANUAL)) == "MANUAL");
    test("brightnessModeToString(AUTO)", std::string(DisplayManager::brightnessModeToString(BrightnessMode::AUTO)) == "AUTO");
    test("brightnessModeToString(ADAPTIVE)", std::string(DisplayManager::brightnessModeToString(BrightnessMode::ADAPTIVE)) == "ADAPTIVE");

    test("permissionToString(DENY)", std::string(DisplayManager::permissionToString(DisplayPermission::DENY)) == "DENY");
    test("permissionToString(ALLOW_FOREGROUND)", std::string(DisplayManager::permissionToString(DisplayPermission::ALLOW_FOREGROUND)) == "ALLOW_FOREGROUND");
    test("permissionToString(ALLOW_ALWAYS)", std::string(DisplayManager::permissionToString(DisplayPermission::ALLOW_ALWAYS)) == "ALLOW_ALWAYS");
    test("permissionToString(ALLOW_ONCE)", std::string(DisplayManager::permissionToString(DisplayPermission::ALLOW_ONCE)) == "ALLOW_ONCE");

    test("privacyModeToString(FULL)", std::string(DisplayManager::privacyModeToString(DisplayPrivacyMode::FULL)) == "FULL");
    test("privacyModeToString(REDACTED)", std::string(DisplayManager::privacyModeToString(DisplayPrivacyMode::REDACTED)) == "REDACTED");
    test("privacyModeToString(METADATA_ONLY)", std::string(DisplayManager::privacyModeToString(DisplayPrivacyMode::METADATA_ONLY)) == "METADATA_ONLY");

    test("resultToString(SUCCESS)", std::string(DisplayManager::resultToString(DisplayResult::SUCCESS)) == "SUCCESS");
    test("resultToString(NOT_INITIALIZED)", std::string(DisplayManager::resultToString(DisplayResult::NOT_INITIALIZED)) == "NOT_INITIALIZED");
    test("resultToString(BRIGHTNESS_OUT_OF_RANGE)", std::string(DisplayManager::resultToString(DisplayResult::BRIGHTNESS_OUT_OF_RANGE)) == "BRIGHTNESS_OUT_OF_RANGE");
    test("resultToString(SIMULATED_FAILURE)", std::string(DisplayManager::resultToString(DisplayResult::SIMULATED_FAILURE)) == "SIMULATED_FAILURE");

    // Parser
    test("stringToResult(SUCCESS)", DisplayManager::stringToResult("SUCCESS") == DisplayResult::SUCCESS);
    test("stringToResult(PERMISSION_DENIED)", DisplayManager::stringToResult("PERMISSION_DENIED") == DisplayResult::PERMISSION_DENIED);
    test("stringToResult(BAD_STATE)", DisplayManager::stringToResult("BAD_STATE") == DisplayResult::BAD_STATE);
    test("stringToResult(unknown)", DisplayManager::stringToResult("UNKNOWN") == DisplayResult::OPERATION_FAILED);

    test("stringToColorProfile(STANDARD)", DisplayManager::stringToColorProfile("STANDARD") == ColorProfile::STANDARD);
    test("stringToColorProfile(VIVID)", DisplayManager::stringToColorProfile("VIVID") == ColorProfile::VIVID);
    test("stringToColorProfile(TRUE_TONE)", DisplayManager::stringToColorProfile("TRUE_TONE") == ColorProfile::TRUE_TONE);
}

static void testLogServerIntegration() {
    std::cout << "\n  [LogServer / CrashReporter Integration]\n";
    DisplayManager mgr;
    mgr.initialize();

    // Set LogServer (null by default)
    test("logServer null initially", mgr.getLogServer() == nullptr);
    test("crashReporter null initially", mgr.getCrashReporter() == nullptr);

    // Operations should still work with null integration
    mgr.setDisplayState(DisplayState::ON);
    test("setDisplayState with null integration SUCCESS",
         mgr.getDisplayState() == DisplayState::ON);

    mgr.shutdown();
}

static void testFullWorkflow() {
    std::cout << "\n  [Full Workflow]\n";
    DisplayManager mgr;
    mgr.initialize();

    // 1. Turn on display
    test("1. turn ON", mgr.setDisplayState(DisplayState::ON) == DisplayResult::SUCCESS);
    test("1a. display ON", mgr.isDisplayOn());

    // 2. Set brightness
    test("2. set brightness 180", mgr.setBrightness(180) == DisplayResult::SUCCESS);

    // 3. Set auto brightness mode
    test("3. set AUTO mode", mgr.setBrightnessMode(BrightnessMode::AUTO) == DisplayResult::SUCCESS);

    // 4. Update auto brightness
    test("4. update auto brightness", mgr.updateAutoBrightness(700) == DisplayResult::SUCCESS);

    // 5. Set rotation
    test("5. set LANDSCAPE", mgr.setRotation(DisplayRotation::LANDSCAPE) == DisplayResult::SUCCESS);

    // 6. Set color profile
    test("6. set VIVID", mgr.setColorProfile(ColorProfile::VIVID) == DisplayResult::SUCCESS);

    // 7. Enable True Tone
    TrueToneConfig tt;
    tt.enabled = true;
    tt.colorTemperature = 5500;
    test("7. enable True Tone", mgr.setTrueToneConfig(tt) == DisplayResult::SUCCESS);

    // 8. Set refresh rate to 120Hz
    test("8. set 120Hz", mgr.setRefreshRate(RefreshRate::REFRESH_120HZ) == DisplayResult::SUCCESS);

    // 9. Set app policy with secure display
    test("9. set secure app policy",
         mgr.setAppDisplayPolicy("secure_app", DisplayPermission::ALLOW_FOREGROUND,
                                   DisplayPrivacyMode::REDACTED,
                                   DISPLAY_PRIVACY_SECURE_DISPLAY | DISPLAY_PRIVACY_BLOCK_SCREENSHOT,
                                   200, DisplayRotation::PORTRAIT,
                                   true, true, false) == DisplayResult::SUCCESS);

    // 10. Check secure display
    mgr.setAppForeground("secure_app", true);
    test("10. secure display active", mgr.isSecureDisplayActive());
    test("10a. screenshot blocked", mgr.shouldBlockScreenshot("secure_app"));

    // 11. Check stats
    auto stats = mgr.getStats();
    test("11. stateChanges > 0", stats.stateChanges > 0);
    test("11a. brightnessChanges > 0", stats.brightnessChanges > 0);
    test("11b. rotationChanges > 0", stats.rotationChanges > 0);

    // 12. Check events
    test("12. events not empty", !mgr.getEvents().empty());

    // 13. Archive to history
    test("13. clearEvents", mgr.clearEvents() == DisplayResult::SUCCESS);
    test("13a. history has entries", mgr.getHistoryCount() > 0);

    // 14. Clear history
    test("14. clearHistory", mgr.clearHistory() == DisplayResult::SUCCESS);
    test("14a. history empty", mgr.getHistoryCount() == 0);

    // 15. Reset stats
    mgr.resetStats();
    test("15. stats reset", mgr.getStats().stateChanges == 0);

    // 16. Dim display
    test("16. set DIM", mgr.setDisplayState(DisplayState::DIM) == DisplayResult::SUCCESS);
    test("16a. state is DIM", mgr.getDisplayState() == DisplayState::DIM);

    // 17. Turn off display
    test("17. set OFF", mgr.setDisplayState(DisplayState::OFF) == DisplayResult::SUCCESS);
    test("17a. display OFF", mgr.isDisplayOff());

    // 18. Shutdown
    test("18. shutdown SUCCESS", mgr.shutdown() == DisplayResult::SUCCESS);
    test("18a. not initialized", !mgr.isInitialized());
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "========================================\n";
    std::cout << "Phantom OS - Display Manager Tests\n";
    std::cout << "v0.34.0\n";
    std::cout << "========================================\n";

    testLifecycle();
    fflush(stdout);
    testDisplayState();
    fflush(stdout);
    testBrightness();
    fflush(stdout);
    testRotation();
    fflush(stdout);
    testColorProfiles();
    fflush(stdout);
    testRefreshRate();
    fflush(stdout);
    testDisplayInfo();
    fflush(stdout);
    testPermissionPolicy();
    fflush(stdout);
    testSecureDisplay();
    fflush(stdout);
    testHistory();
    fflush(stdout);
    testMock();
    fflush(stdout);
    testPrivacyIndicator();
    fflush(stdout);
    testEvents();
    fflush(stdout);
    testStats();
    fflush(stdout);
    testFailureSimulation();
    fflush(stdout);
    testTimeInjection();
    fflush(stdout);
    testStringHelpers();
    fflush(stdout);
    testLogServerIntegration();
    fflush(stdout);
    testFullWorkflow();
    fflush(stdout);

    std::cout << "\n========================================\n";
    std::cout << "Results: " << g_testsPassed << " passed, " << g_testsFailed << " failed\n";
    std::cout << "========================================\n";

    return g_testsFailed > 0 ? 1 : 0;
}
