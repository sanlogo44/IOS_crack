/*
 * Phantom OS - Configuration System Tests
 *
 * License: GPL-3.0
 */

#include "phantom/config/config.h"
#include <cassert>
#include <cstdio>

using namespace phantom::config;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_define_and_get() {
    Config cfg;
    cfg.defineProperty("app.name", PropertyType::STRING, "PhantomOS", "Application name");
    cfg.defineProperty("app.version", PropertyType::INTEGER, "4", "App version");
    cfg.defineProperty("debug.enabled", PropertyType::BOOLEAN, "false", "Debug mode");

    ASSERT(cfg.isDefined("app.name"), "app.name should be defined");
    ASSERT(cfg.isDefined("app.version"), "app.version should be defined");
    ASSERT(!cfg.isDefined("unknown.key"), "unknown.key should not be defined");

    ASSERT(cfg.get("app.name") == "PhantomOS", "Default value for app.name should be PhantomOS");
    ASSERT(cfg.getInt("app.version") == 4, "Default int for app.version should be 4");
    ASSERT(cfg.getBool("debug.enabled") == false, "Default bool for debug.enabled should be false");

    return true;
}

bool test_set_and_override() {
    Config cfg;
    cfg.defineProperty("app.name", PropertyType::STRING, "Default", "");
    cfg.defineProperty("app.count", PropertyType::INTEGER, "0", "");

    ASSERT(!cfg.isOverridden("app.name"), "app.name should not be overridden initially");

    cfg.set("app.name", "Custom");
    ASSERT(cfg.isOverridden("app.name"), "app.name should be overridden after set");
    ASSERT(cfg.get("app.name") == "Custom", "Overridden value should be 'Custom'");

    cfg.setInt("app.count", 42);
    ASSERT(cfg.getInt("app.count") == 42, "Overridden int should be 42");

    return true;
}

bool test_typed_setters() {
    Config cfg;
    cfg.defineProperty("flag", PropertyType::BOOLEAN, "false", "");
    cfg.defineProperty("value", PropertyType::INTEGER, "0", "");
    cfg.defineProperty("ratio", PropertyType::FLOAT, "0.0", "");

    cfg.setBool("flag", true);
    cfg.setInt("value", -123);
    cfg.setFloat("ratio", 3.14);

    ASSERT(cfg.getBool("flag") == true, "Bool should be true");
    ASSERT(cfg.getInt("value") == -123, "Int should be -123");

    double f = cfg.getFloat("ratio");
    ASSERT(f > 3.13 && f < 3.15, "Float should be ~3.14");

    return true;
}

bool test_parse_properties() {
    Config cfg;
    std::string content =
        "# Comment line\n"
        "! Also a comment\n"
        "app.name=TestApp\n"
        "app.version = 5\n"
        "debug.enabled : true\n"
        "\n"
        "  spaced.key = spaced value  \n";

    int count = cfg.loadFromString(content);
    ASSERT(count == 4, "Should parse 4 properties");

    ASSERT(cfg.get("app.name") == "TestApp", "app.name should be TestApp");
    ASSERT(cfg.getInt("app.version") == 5, "app.version should be 5");
    ASSERT(cfg.getBool("debug.enabled") == true, "debug.enabled should be true");
    ASSERT(cfg.get("spaced.key") == "spaced value", "spaced.key should be 'spaced value'");

    return true;
}

bool test_clear_overrides() {
    Config cfg;
    cfg.defineProperty("key", PropertyType::STRING, "default", "");
    cfg.set("key", "overridden");
    ASSERT(cfg.get("key") == "overridden", "Should be overridden");

    cfg.clearOverrides();
    ASSERT(!cfg.isOverridden("key"), "Should not be overridden after clear");
    ASSERT(cfg.get("key") == "default", "Should revert to default after clear overrides");

    return true;
}

bool test_get_defined_keys() {
    Config cfg;
    cfg.defineProperty("a", PropertyType::STRING, "", "");
    cfg.defineProperty("b", PropertyType::STRING, "", "");
    cfg.defineProperty("c", PropertyType::STRING, "", "");

    auto keys = cfg.getDefinedKeys();
    ASSERT(keys.size() == 3, "Should have 3 defined keys");

    cfg.set("a", "val");
    auto overridden = cfg.getOverriddenKeys();
    ASSERT(overridden.size() == 1, "Should have 1 overridden key");

    return true;
}

bool test_undefined_key_returns_empty() {
    Config cfg;
    ASSERT(cfg.get("nonexistent") == "", "Undefined key should return empty string");
    ASSERT(cfg.getInt("nonexistent") == 0, "Undefined int key should return 0");
    ASSERT(cfg.getBool("nonexistent") == false, "Undefined bool key should return false");
    ASSERT(cfg.getFloat("nonexistent") == 0.0, "Undefined float key should return 0.0");

    return true;
}

bool test_property_info() {
    Config cfg;
    cfg.defineProperty("test.key", PropertyType::STRING, "default", "Test description");

    const PropertyInfo* info = cfg.getPropertyInfo("test.key");
    ASSERT(info != nullptr, "Property info should not be null");
    ASSERT(info->key == "test.key", "Property key should match");
    ASSERT(info->type == PropertyType::STRING, "Property type should be STRING");
    ASSERT(info->defaultValue == "default", "Default value should match");
    ASSERT(info->description == "Test description", "Description should match");

    ASSERT(cfg.getPropertyInfo("nonexistent") == nullptr, "Info for nonexistent key should be null");

    return true;
}

bool test_save_to_string() {
    Config cfg;
    cfg.defineProperty("app.name", PropertyType::STRING, "PhantomOS", "App name");
    cfg.defineProperty("app.version", PropertyType::INTEGER, "4", "App version");

    std::string saved = cfg.saveToString();
    ASSERT(saved.find("app.name=PhantomOS") != std::string::npos, "Saved string should contain app.name");
    ASSERT(saved.find("app.version=4") != std::string::npos, "Saved string should contain app.version");
    ASSERT(saved.find("App name") != std::string::npos, "Saved string should contain description");

    return true;
}

bool test_invalid_values() {
    Config cfg;
    cfg.defineProperty("num", PropertyType::INTEGER, "0", "");

    // Set invalid integer
    cfg.set("num", "not_a_number");
    ASSERT(cfg.getInt("num") == 0, "Invalid integer should return 0");

    cfg.defineProperty("ratio", PropertyType::FLOAT, "0.0", "");
    cfg.set("ratio", "invalid");
    ASSERT(cfg.getFloat("ratio") == 0.0, "Invalid float should return 0.0");

    return true;
}

int main() {
    printf("=== Config System Tests ===\n");
    test_define_and_get();
    test_set_and_override();
    test_typed_setters();
    test_parse_properties();
    test_clear_overrides();
    test_get_defined_keys();
    test_undefined_key_returns_empty();
    test_property_info();
    test_save_to_string();
    test_invalid_values();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
