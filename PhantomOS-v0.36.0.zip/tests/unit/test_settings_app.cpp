/*
 * Phantom OS - Settings App Unit Tests
 * Tests for the Settings App prototype
 *
 * License: GPL-3.0
 */

#include "phantom/settings/settings_app.h"
#include "mock_hal_factory.h"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace phantom;
using namespace phantom::settings;
using namespace phantom::gui;
using namespace phantom::privacy;
using namespace phantom::config;

// Simple test framework
static int tests_passed = 0;
static int tests_failed = 0;

static void check(bool condition, const char* testName) {
    if (condition) {
        tests_passed++;
        printf("  [PASS] %s\n", testName);
    } else {
        tests_failed++;
        printf("  [FAIL] %s\n", testName);
    }
}

static void checkEq(int actual, int expected, const char* testName) {
    if (actual == expected) {
        tests_passed++;
        printf("  [PASS] %s\n", testName);
    } else {
        tests_failed++;
        printf("  [FAIL] %s (expected %d, got %d)\n", testName, expected, actual);
    }
}

static void checkStr(const std::string& actual, const std::string& expected, const char* testName) {
    if (actual == expected) {
        tests_passed++;
        printf("  [PASS] %s\n", testName);
    } else {
        tests_failed++;
        printf("  [FAIL] %s (expected '%s', got '%s')\n", testName, expected.c_str(), actual.c_str());
    }
}

// ============================================================
// Test: Initialization
// ============================================================
static void testInitialization() {
    printf("\n=== Initialization Tests ===\n");

    SettingsApp app;
    check(!app.isInitialized(), "Not initialized before init");

    bool result = app.initialize();
    check(result, "Initialize succeeds");
    check(app.isInitialized(), "Initialized after init");

    app.shutdown();
    check(!app.isInitialized(), "Not initialized after shutdown");
}

// ============================================================
// Test: Widget Tree Creation
// ============================================================
static void testWidgetTree() {
    printf("\n=== Widget Tree Tests ===\n");

    SettingsApp app;
    app.initialize();

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists");
    check(root->getChildCount() == 6, "Root has 6 children (nav + 5 sections)");

    // Check navigation bar
    auto* nav = root->getChild(0);
    check(nav != nullptr, "Navigation bar exists");
    check(nav->getChildCount() == 5, "Navigation has 5 buttons");

    // Check sections exist
    check(root->getChild(1) != nullptr, "Display section exists");
    check(root->getChild(2) != nullptr, "Privacy section exists");
    check(root->getChild(3) != nullptr, "Network section exists");
    check(root->getChild(4) != nullptr, "Storage section exists");
    check(root->getChild(5) != nullptr, "About section exists");

    app.shutdown();
}

// ============================================================
// Test: Panel Navigation
// ============================================================
static void testPanelNavigation() {
    printf("\n=== Panel Navigation Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Default panel is DISPLAY
    check(app.getActivePanel() == SettingsPanel::DISPLAY, "Default panel is Display");

    // Check display section is visible, others are gone
    auto* root = app.getRootWidget();
    auto* displaySection = root->getChild(1);
    auto* privacySection = root->getChild(2);
    check(displaySection->isVisible(), "Display section visible by default");
    check(privacySection->isGone(), "Privacy section hidden by default");

    // Switch to privacy panel
    app.setActivePanel(SettingsPanel::PRIVACY);
    check(app.getActivePanel() == SettingsPanel::PRIVACY, "Active panel is Privacy");
    check(!displaySection->isVisible(), "Display section hidden after switch");
    check(privacySection->isVisible(), "Privacy section visible after switch");

    // Switch to network panel
    app.setActivePanel(SettingsPanel::NETWORK);
    check(app.getActivePanel() == SettingsPanel::NETWORK, "Active panel is Network");

    // Switch to storage panel
    app.setActivePanel(SettingsPanel::STORAGE);
    check(app.getActivePanel() == SettingsPanel::STORAGE, "Active panel is Storage");

    // Switch to about panel
    app.setActivePanel(SettingsPanel::ABOUT);
    check(app.getActivePanel() == SettingsPanel::ABOUT, "Active panel is About");

    app.shutdown();
}

// ============================================================
// Test: Config Properties
// ============================================================
static void testConfigProperties() {
    printf("\n=== Config Properties Tests ===\n");

    SettingsApp app;
    app.initialize();

    const auto& config = app.getConfig();

    // Check default config values
    check(config.isDefined("display.brightness"), "Brightness property defined");
    check(config.isDefined("display.theme"), "Theme property defined");
    check(config.isDefined("privacy.profile"), "Privacy profile property defined");
    check(config.isDefined("privacy.telemetry"), "Telemetry property defined");
    check(config.isDefined("system.os_version"), "OS version property defined");
    check(config.isDefined("system.device"), "Device property defined");

    // Check default values
    checkStr(config.get("display.theme"), "DARK", "Default theme is DARK");
    checkStr(config.get("privacy.profile"), "NORMAL", "Default profile is NORMAL");
    checkStr(config.get("system.os_version"), "0.10.0", "Default OS version is 0.10.0");

    app.shutdown();
}

// ============================================================
// Test: Brightness Control
// ============================================================
static void testBrightness() {
    printf("\n=== Brightness Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Default brightness
    checkEq(app.getBrightness(), 128, "Default brightness is 128");

    // Set brightness
    app.setBrightness(200);
    checkEq(app.getBrightness(), 200, "Brightness set to 200");

    // Check config updated
    check(app.getConfig().getInt("display.brightness") == 200, "Config brightness updated");

    // Set brightness to 0
    app.setBrightness(0);
    checkEq(app.getBrightness(), 0, "Brightness set to 0");

    // Set brightness beyond max (should clamp)
    app.setBrightness(300);
    checkEq(app.getBrightness(), 255, "Brightness clamped to 255");

    // Set brightness below min (should clamp)
    app.setBrightness(-10);
    checkEq(app.getBrightness(), 0, "Brightness clamped to 0");

    app.shutdown();
}

// ============================================================
// Test: Theme Control
// ============================================================
static void testTheme() {
    printf("\n=== Theme Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Default theme should be DARK
    check(app.getThemeType() == ThemeType::DARK, "Default theme is DARK");

    // Toggle theme
    app.toggleTheme();
    check(app.getThemeType() == ThemeType::LIGHT, "Theme toggled to LIGHT");

    // Toggle back
    app.toggleTheme();
    check(app.getThemeType() == ThemeType::DARK, "Theme toggled back to DARK");

    // Set theme type
    app.setThemeType(ThemeType::LIGHT);
    check(app.getThemeType() == ThemeType::LIGHT, "Theme set to LIGHT");

    app.setThemeType(ThemeType::DARK);
    check(app.getThemeType() == ThemeType::DARK, "Theme set to DARK");

    // Check config updated
    checkStr(app.getConfig().get("display.theme"), "DARK", "Config theme is DARK");

    app.shutdown();
}

// ============================================================
// Test: Privacy Profile
// ============================================================
static void testPrivacyProfile() {
    printf("\n=== Privacy Profile Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Default profile is NORMAL
    check(app.getPrivacyProfile() == PrivacyProfile::NORMAL, "Default profile is NORMAL");

    // Set to PRIVACY
    app.setPrivacyProfile(PrivacyProfile::PRIVACY);
    check(app.getPrivacyProfile() == PrivacyProfile::PRIVACY, "Profile set to PRIVACY");

    // Check config updated
    checkStr(app.getConfig().get("privacy.profile"), "PRIVACY", "Config profile is PRIVACY");

    // Set to MAXIMUM_PRIVACY
    app.setPrivacyProfile(PrivacyProfile::MAXIMUM_PRIVACY);
    check(app.getPrivacyProfile() == PrivacyProfile::MAXIMUM_PRIVACY, "Profile set to MAXIMUM_PRIVACY");

    // Check location accuracy updated
    check(app.getLocationAccuracy() == LocationAccuracy::CITY, "Location accuracy is CITY for max privacy");

    // Set to DEVELOPER
    app.setPrivacyProfile(PrivacyProfile::DEVELOPER);
    check(app.getPrivacyProfile() == PrivacyProfile::DEVELOPER, "Profile set to DEVELOPER");

    // Set back to NORMAL
    app.setPrivacyProfile(PrivacyProfile::NORMAL);
    check(app.getPrivacyProfile() == PrivacyProfile::NORMAL, "Profile set to NORMAL");

    app.shutdown();
}

// ============================================================
// Test: Telemetry Toggle
// ============================================================
static void testTelemetry() {
    printf("\n=== Telemetry Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Default telemetry is off
    check(!app.isTelemetryEnabled(), "Telemetry disabled by default");

    // Enable telemetry
    app.setTelemetryEnabled(true);
    check(app.isTelemetryEnabled(), "Telemetry enabled");

    // Check config updated
    check(app.getConfig().getBool("privacy.telemetry"), "Config telemetry is true");

    // Disable telemetry
    app.setTelemetryEnabled(false);
    check(!app.isTelemetryEnabled(), "Telemetry disabled");

    app.shutdown();
}

// ============================================================
// Test: Hardware Info
// ============================================================
static void testHardwareInfo() {
    printf("\n=== Hardware Info Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Refresh hardware info
    app.refreshHardwareInfo();

    // Check display info (mock HAL provides iPhone X values)
    std::string displayInfo = app.getDisplayInfoString();
    check(!displayInfo.empty(), "Display info not empty");
    check(displayInfo.find("2436") != std::string::npos, "Display info contains resolution width");

    // Check battery info
    std::string batteryInfo = app.getBatteryInfoString();
    check(!batteryInfo.empty(), "Battery info not empty");
    check(batteryInfo.find("%") != std::string::npos, "Battery info contains percentage");

    // Check storage info
    std::string storageInfo = app.getStorageInfoString();
    check(!storageInfo.empty(), "Storage info not empty");

    // Check network info
    std::string networkInfo = app.getNetworkInfoString();
    check(!networkInfo.empty(), "Network info not empty");
    check(networkInfo.find("Wi-Fi") != std::string::npos, "Network info contains Wi-Fi");

    app.shutdown();
}

// ============================================================
// Test: Rendering
// ============================================================
static void testRendering() {
    printf("\n=== Rendering Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Layout
    app.layout(300, 400);

    // Render to framebuffer
    Framebuffer fb(300, 400);
    fb.clear(Color::Black);
    app.render(fb);
    check(fb.isValid(), "Framebuffer valid after render");

    // Count non-black pixels (should have some content)
    int32_t nonBlack = 0;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) {
            nonBlack++;
        }
    }
    check(nonBlack > 0, "Framebuffer has rendered content");

    app.shutdown();
}

// ============================================================
// Test: Touch Handling
// ============================================================
static void testTouchHandling() {
    printf("\n=== Touch Handling Tests ===\n");

    SettingsApp app;
    app.initialize();
    app.layout(300, 400);

    // Touch the brightness slider area (should not crash)
    bool handled = app.handleTouchDown(10, 50);
    // May or may not hit a widget, but should not crash
    check(true, "Touch down does not crash");

    handled = app.handleTouchUp(10, 50);
    check(true, "Touch up does not crash");

    // Touch outside widget bounds
    handled = app.handleTouchDown(-10, -10);
    check(!handled, "Touch outside bounds not handled");

    app.shutdown();
}

// ============================================================
// Test: Layout Positioning
// ============================================================
static void testLayoutPositioning() {
    printf("\n=== Layout Positioning Tests ===\n");

    SettingsApp app;
    app.initialize();
    app.layout(300, 400);

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists after layout");
    check(root->getBounds().width == 300, "Root width is 300");
    check(root->getBounds().height == 400, "Root height is 400");

    // Nav bar should have nonzero bounds
    auto* nav = root->getChild(0);
    check(nav != nullptr, "Nav bar exists");
    check(nav->getBounds().width > 0, "Nav bar has nonzero width");
    check(nav->getBounds().height > 0, "Nav bar has nonzero height");

    // Nav buttons should have nonzero bounds and different x positions
    auto* btn0 = nav->getChild(0);
    auto* btn1 = nav->getChild(1);
    check(btn0 != nullptr, "Nav button 0 exists");
    check(btn1 != nullptr, "Nav button 1 exists");
    check(btn0->getBounds().width > 0, "Nav button 0 has nonzero width");
    check(btn1->getBounds().width > 0, "Nav button 1 has nonzero width");
    check(btn0->getBounds().x != btn1->getBounds().x, "Nav buttons have different x positions");

    // Display section should be visible and have nonzero bounds
    auto* displaySection = root->getChild(1);
    check(displaySection->isVisible(), "Display section is visible");
    check(displaySection->getBounds().width > 0, "Display section has nonzero width");
    check(displaySection->getBounds().height > 0, "Display section has nonzero height");

    // Section children should have nonzero bounds
    auto* title = displaySection->getChild(0);
    check(title != nullptr, "Display title exists");
    check(title->getBounds().width > 0 || title->getBounds().height > 0,
          "Display title has nonzero bounds");

    app.shutdown();
}

// ============================================================
// Test: Touch Panel Switching
// ============================================================
static void testTouchPanelSwitch() {
    printf("\n=== Touch Panel Switch Tests ===\n");

    SettingsApp app;
    app.initialize();
    app.layout(300, 400);

    // Default panel is DISPLAY
    check(app.getActivePanel() == SettingsPanel::DISPLAY, "Default panel is Display");

    // Find the Privacy nav button and touch it
    auto* root = app.getRootWidget();
    auto* nav = root->getChild(0);
    auto* privacyBtn = nav->getChild(1);  // Privacy is button index 1
    check(privacyBtn != nullptr, "Privacy nav button exists");

    // Get button bounds
    auto bounds = privacyBtn->getBounds();
    int32_t cx = bounds.x + bounds.width / 2;
    int32_t cy = bounds.y + bounds.height / 2;

    // Touch the Privacy button
    bool handled = app.handleTouchDown(cx, cy);
    check(handled, "Touch on Privacy button handled");
    app.handleTouchUp(cx, cy);

    // Panel should have switched to Privacy
    check(app.getActivePanel() == SettingsPanel::PRIVACY, "Panel switched to Privacy via touch");

    app.shutdown();
}

// ============================================================
// Test: Singleton Sync at Initialize
// ============================================================
static void testSingletonSync() {
    printf("\n=== Singleton Sync Tests ===\n");

    // Set singletons to non-default values before creating app
    auto& tm = gui::ThemeManager::getInstance();
    tm.setThemeType(gui::ThemeType::LIGHT);
    auto& pm = privacy::PermissionManager::getInstance();
    pm.setPrivacyProfile(privacy::PrivacyProfile::MAXIMUM_PRIVACY);

    SettingsApp app;
    app.initialize();

    // Config defaults say DARK and NORMAL, so initialize should sync singletons
    check(app.getThemeType() == gui::ThemeType::DARK,
          "Theme synced to DARK from config default");
    check(app.getPrivacyProfile() == privacy::PrivacyProfile::NORMAL,
          "Privacy profile synced to NORMAL from config default");

    app.shutdown();
}

// ============================================================
// Test: State Change Callback
// ============================================================
static void testStateChangeCallback() {
    printf("\n=== State Change Callback Tests ===\n");

    SettingsApp app;
    app.initialize();

    int callbackCount = 0;
    app.setStateChangeCallback([&callbackCount]() {
        callbackCount++;
    });

    // Trigger a state change
    app.setBrightness(100);
    check(callbackCount > 0, "State change callback fired for brightness");

    int prevCount = callbackCount;
    app.toggleTheme();
    check(callbackCount > prevCount, "State change callback fired for theme");

    prevCount = callbackCount;
    app.setPrivacyProfile(PrivacyProfile::PRIVACY);
    check(callbackCount > prevCount, "State change callback fired for privacy profile");

    app.shutdown();
}

// ============================================================
// Test: Section Visibility
// ============================================================
static void testSectionVisibility() {
    printf("\n=== Section Visibility Tests ===\n");

    SettingsApp app;
    app.initialize();

    auto* root = app.getRootWidget();

    // Initially display section is visible
    auto* displaySection = root->getChild(1);
    auto* privacySection = root->getChild(2);
    auto* networkSection = root->getChild(3);
    auto* storageSection = root->getChild(4);
    auto* aboutSection = root->getChild(5);

    check(displaySection->isVisible(), "Display visible initially");
    check(privacySection->isGone(), "Privacy hidden initially");
    check(networkSection->isGone(), "Network hidden initially");
    check(storageSection->isGone(), "Storage hidden initially");
    check(aboutSection->isGone(), "About hidden initially");

    // Switch to storage
    app.setActivePanel(SettingsPanel::STORAGE);
    check(displaySection->isGone(), "Display hidden after switch to storage");
    check(storageSection->isVisible(), "Storage visible after switch");

    app.shutdown();
}

// ============================================================
// Test: Reset
// ============================================================
static void testReset() {
    printf("\n=== Reset Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Make changes
    app.setBrightness(200);
    app.setThemeType(ThemeType::LIGHT);
    app.setPrivacyProfile(PrivacyProfile::MAXIMUM_PRIVACY);
    app.setActivePanel(SettingsPanel::ABOUT);

    // Reset
    app.reset();

    // Re-initialize
    app.initialize();

    // Should be back to defaults
    checkEq(app.getBrightness(), 128, "Brightness reset to default");
    check(app.getThemeType() == ThemeType::DARK, "Theme reset to DARK");
    check(app.getPrivacyProfile() == PrivacyProfile::NORMAL, "Profile reset to NORMAL");
    check(app.getActivePanel() == SettingsPanel::DISPLAY, "Panel reset to DISPLAY");

    app.shutdown();
}

// ============================================================
// Test: Panel Count
// ============================================================
static void testPanelCount() {
    printf("\n=== Panel Count Tests ===\n");

    SettingsApp app;
    app.initialize();

    checkEq(static_cast<int>(app.getPanelCount()), 5, "Panel count is 5");

    app.shutdown();
}

// ============================================================
// Test: Radio Button Group
// ============================================================
static void testRadioButtons() {
    printf("\n=== Radio Button Group Tests ===\n");

    SettingsApp app;
    app.initialize();

    // Switch to privacy panel
    app.setActivePanel(SettingsPanel::PRIVACY);

    // Check initial state - NORMAL should be selected
    check(app.getPrivacyProfile() == PrivacyProfile::NORMAL, "Normal profile selected initially");

    // Switch to PRIVACY profile
    app.setPrivacyProfile(PrivacyProfile::PRIVACY);
    check(app.getPrivacyProfile() == PrivacyProfile::PRIVACY, "Privacy profile selected");

    // Switch to MAXIMUM_PRIVACY
    app.setPrivacyProfile(PrivacyProfile::MAXIMUM_PRIVACY);
    check(app.getPrivacyProfile() == PrivacyProfile::MAXIMUM_PRIVACY, "Max privacy selected");

    // Switch to DEVELOPER
    app.setPrivacyProfile(PrivacyProfile::DEVELOPER);
    check(app.getPrivacyProfile() == PrivacyProfile::DEVELOPER, "Developer profile selected");

    // Switch back to NORMAL
    app.setPrivacyProfile(PrivacyProfile::NORMAL);
    check(app.getPrivacyProfile() == PrivacyProfile::NORMAL, "Normal profile re-selected");

    app.shutdown();
}

// ============================================================
// Test: Shutdown Cleanup
// ============================================================
static void testShutdownCleanup() {
    printf("\n=== Shutdown Cleanup Tests ===\n");

    SettingsApp app;
    app.initialize();

    auto* root = app.getRootWidget();
    check(root != nullptr, "Root widget exists before shutdown");

    app.shutdown();

    check(app.getRootWidget() == nullptr, "Root widget null after shutdown");
    check(!app.isInitialized(), "Not initialized after shutdown");

    // Should be able to re-initialize
    bool result = app.initialize();
    check(result, "Re-initialize succeeds after shutdown");
    check(app.isInitialized(), "Initialized after re-init");
    check(app.getRootWidget() != nullptr, "Root widget exists after re-init");

    app.shutdown();
}

// ============================================================
// Main
// ============================================================
int main() {
    printf("╔══════════════════════════════════════════════╗\n");
    printf("║  Phantom OS v0.10.0 — Settings App Tests    ║\n");
    printf("╚══════════════════════════════════════════════╝\n");

    testInitialization();
    testWidgetTree();
    testPanelNavigation();
    testConfigProperties();
    testBrightness();
    testTheme();
    testPrivacyProfile();
    testTelemetry();
    testHardwareInfo();
    testRendering();
    testTouchHandling();
    testLayoutPositioning();
    testTouchPanelSwitch();
    testSingletonSync();
    testStateChangeCallback();
    testSectionVisibility();
    testReset();
    testPanelCount();
    testRadioButtons();
    testShutdownCleanup();

    printf("\n══════════════════════════════════════════\n");
    printf("  Settings App Tests: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("══════════════════════════════════════════\n");

    return tests_failed > 0 ? 1 : 0;
}
