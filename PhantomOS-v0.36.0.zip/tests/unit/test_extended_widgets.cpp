/*
 * Phantom OS - Extended Widget Tests
 * Tests for CheckBox, RadioButton, ProgressBar, Slider
 *
 * License: GPL-3.0
 */

#include "phantom/gui/widgets/extended_widgets.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

// ============================================================
// CheckBox Tests
// ============================================================

bool test_checkbox_construction() {
    CheckBox cb(1, "Accept");
    ASSERT(cb.getId() == 1, "CheckBox ID should be 1");
    ASSERT(cb.getLabel() == "Accept", "CheckBox label should be 'Accept'");
    ASSERT(cb.isChecked() == false, "CheckBox should be unchecked by default");
    ASSERT(cb.isClickable(), "CheckBox should be clickable");
    ASSERT(cb.isEnabled(), "CheckBox should be enabled");
    return true;
}

bool test_checkbox_toggle() {
    CheckBox cb(1, "Test");
    cb.setChecked(true);
    ASSERT(cb.isChecked(), "CheckBox should be checked after setChecked(true)");
    cb.setChecked(false);
    ASSERT(!cb.isChecked(), "CheckBox should be unchecked after setChecked(false)");
    return true;
}

bool test_checkbox_change_callback() {
    CheckBox cb(1, "Test");
    bool callbackCalled = false;
    bool callbackValue = false;
    cb.setOnChange([&](bool checked) {
        callbackCalled = true;
        callbackValue = checked;
    });
    cb.setChecked(true);
    ASSERT(callbackCalled, "Change callback should be called");
    ASSERT(callbackValue == true, "Callback value should be true");
    return true;
}

bool test_checkbox_on_measure() {
    CheckBox cb(1, "Hello");
    Size s = cb.onMeasure();
    ASSERT(s.width > 0, "CheckBox width should be > 0");
    ASSERT(s.height > 0, "CheckBox height should be > 0");
    return true;
}

bool test_checkbox_render() {
    CheckBox cb(1, "Test");
    cb.setBounds(Rect(0, 0, 80, 20));
    Framebuffer fb(100, 30);
    BitmapFont font;
    fb.clear(Color::Black);
    cb.onRender(fb, font);
    // Check that some pixels were drawn
    bool hasPixels = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) { hasPixels = true; break; }
    }
    ASSERT(hasPixels, "Rendered CheckBox should produce pixels");
    return true;
}

bool test_checkbox_touch() {
    CheckBox cb(1, "Test");
    cb.setBounds(Rect(0, 0, 80, 20));
    ASSERT(cb.onTouchDown(10, 10), "TouchDown should return true");
    ASSERT(cb.isChecked() == false, "Should not be checked on touch down");
    ASSERT(cb.onTouchUp(10, 10), "TouchUp should return true");
    ASSERT(cb.isChecked(), "Should be checked after touch up");
    return true;
}

bool test_checkbox_disabled() {
    CheckBox cb(1, "Test");
    cb.setEnabled(false);
    ASSERT(!cb.onTouchDown(10, 10), "Disabled CheckBox should not respond to touch");
    return true;
}

// ============================================================
// RadioButton Tests
// ============================================================

bool test_radiobutton_construction() {
    RadioButton rb(1, "Option A", 1);
    ASSERT(rb.getId() == 1, "RadioButton ID should be 1");
    ASSERT(rb.getLabel() == "Option A", "RadioButton label should be 'Option A'");
    ASSERT(rb.getGroupId() == 1, "RadioButton group should be 1");
    ASSERT(rb.isSelected() == false, "RadioButton should be unselected by default");
    ASSERT(rb.isClickable(), "RadioButton should be clickable");
    return true;
}

bool test_radiobutton_selection() {
    RadioButton rb(1, "Test", 1);
    rb.setSelected(true);
    ASSERT(rb.isSelected(), "RadioButton should be selected after setSelected(true)");
    rb.setSelected(false);
    ASSERT(!rb.isSelected(), "RadioButton should be unselected after setSelected(false)");
    return true;
}

bool test_radiobutton_group() {
    RadioButton rb1(1, "A", 1);
    RadioButton rb2(2, "B", 1);
    RadioButton rb3(3, "C", 1);

    // Select rb1 in group 1
    RadioButton::selectInGroup(1, 1);
    ASSERT(rb1.isSelected(), "rb1 should be selected in group 1");
    ASSERT(!rb2.isSelected(), "rb2 should not be selected");
    ASSERT(!rb3.isSelected(), "rb3 should not be selected");

    // Select rb2 in group 1
    RadioButton::selectInGroup(1, 2);
    ASSERT(!rb1.isSelected(), "rb1 should now be unselected");
    ASSERT(rb2.isSelected(), "rb2 should now be selected");
    return true;
}

bool test_radiobutton_touch() {
    RadioButton rb(1, "Test", 1);
    rb.setBounds(Rect(0, 0, 80, 20));
    ASSERT(rb.onTouchDown(5, 5), "TouchDown should return true");
    ASSERT(rb.onTouchUp(5, 5), "TouchUp should return true");
    ASSERT(rb.isSelected(), "RadioButton should be selected after touch");
    return true;
}

bool test_radiobutton_on_measure() {
    RadioButton rb(1, "Hello", 1);
    Size s = rb.onMeasure();
    ASSERT(s.width > 0, "RadioButton width should be > 0");
    ASSERT(s.height > 0, "RadioButton height should be > 0");
    return true;
}

bool test_radiobutton_render() {
    RadioButton rb(1, "Test", 1);
    rb.setSelected(true);
    rb.setBounds(Rect(0, 0, 80, 20));
    Framebuffer fb(100, 30);
    BitmapFont font;
    fb.clear(Color::Black);
    rb.onRender(fb, font);
    bool hasPixels = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) { hasPixels = true; break; }
    }
    ASSERT(hasPixels, "Rendered RadioButton should produce pixels");
    return true;
}

// ============================================================
// ProgressBar Tests
// ============================================================

bool test_progressbar_construction() {
    ProgressBar pb(1, 0, 100, 50);
    ASSERT(pb.getId() == 1, "ProgressBar ID should be 1");
    ASSERT(pb.getMin() == 0, "Min should be 0");
    ASSERT(pb.getMax() == 100, "Max should be 100");
    ASSERT(pb.getValue() == 50, "Value should be 50");
    return true;
}

bool test_progressbar_value_clamping() {
    ProgressBar pb(1, 0, 100, 50);
    pb.setValue(150);
    ASSERT(pb.getValue() == 100, "Value should be clamped to max");
    pb.setValue(-10);
    ASSERT(pb.getValue() == 0, "Value should be clamped to min");
    return true;
}

bool test_progressbar_percentage() {
    ProgressBar pb(1, 0, 100, 50);
    ASSERT(pb.getPercentage() == 50, "50/100 should be 50%");
    pb.setValue(25);
    ASSERT(pb.getPercentage() == 25, "25/100 should be 25%");
    pb.setValue(0);
    ASSERT(pb.getPercentage() == 0, "0/100 should be 0%");
    pb.setValue(100);
    ASSERT(pb.getPercentage() == 100, "100/100 should be 100%");
    return true;
}

bool test_progressbar_orientation() {
    ProgressBar pb(1);
    ASSERT(pb.getOrientation() == ProgressBar::Orientation::HORIZONTAL, "Default should be horizontal");
    pb.setOrientation(ProgressBar::Orientation::VERTICAL);
    ASSERT(pb.getOrientation() == ProgressBar::Orientation::VERTICAL, "Should be vertical");
    return true;
}

bool test_progressbar_indeterminate() {
    ProgressBar pb(1);
    ASSERT(!pb.isIndeterminate(), "Should not be indeterminate by default");
    pb.setIndeterminate(true);
    ASSERT(pb.isIndeterminate(), "Should be indeterminate after set");
    return true;
}

bool test_progressbar_on_measure() {
    ProgressBar pb(1, 0, 100, 50);
    Size s = pb.onMeasure();
    ASSERT(s.width > 0, "ProgressBar width should be > 0");
    ASSERT(s.height > 0, "ProgressBar height should be > 0");
    return true;
}

bool test_progressbar_render() {
    ProgressBar pb(1, 0, 100, 50);
    pb.setBounds(Rect(0, 0, 100, 10));
    Framebuffer fb(120, 20);
    BitmapFont font;
    fb.clear(Color::Black);
    pb.onRender(fb, font);
    // Check fill pixels exist
    bool hasFill = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) { hasFill = true; break; }
    }
    ASSERT(hasFill, "Rendered ProgressBar should produce pixels");
    return true;
}

bool test_progressbar_custom_range() {
    ProgressBar pb(1, 10, 20, 15);
    ASSERT(pb.getPercentage() == 50, "15 in range 10-20 should be 50%");
    pb.setValue(10);
    ASSERT(pb.getPercentage() == 0, "10 in range 10-20 should be 0%");
    pb.setValue(20);
    ASSERT(pb.getPercentage() == 100, "20 in range 10-20 should be 100%");
    return true;
}

// ============================================================
// Slider Tests
// ============================================================

bool test_slider_construction() {
    Slider slider(1, 0, 100, 50);
    ASSERT(slider.getId() == 1, "Slider ID should be 1");
    ASSERT(slider.getMin() == 0, "Min should be 0");
    ASSERT(slider.getMax() == 100, "Max should be 100");
    ASSERT(slider.getValue() == 50, "Value should be 50");
    return true;
}

bool test_slider_value_clamping() {
    Slider slider(1, 0, 100, 50);
    slider.setValue(200);
    ASSERT(slider.getValue() == 100, "Value should be clamped to max");
    slider.setValue(-50);
    ASSERT(slider.getValue() == 0, "Value should be clamped to min");
    return true;
}

bool test_slider_change_callback() {
    Slider slider(1, 0, 100, 50);
    bool callbackCalled = false;
    int32_t callbackValue = -1;
    slider.setOnChange([&](int32_t value) {
        callbackCalled = true;
        callbackValue = value;
    });
    slider.setValue(75);
    ASSERT(callbackCalled, "Change callback should be called");
    ASSERT(callbackValue == 75, "Callback value should be 75");
    return true;
}

bool test_slider_position_to_value() {
    Slider slider(1, 0, 100, 0);
    slider.setBounds(Rect(0, 0, 110, 12));  // 110 wide, thumb=5, track=100
    int32_t v0 = slider.positionToValue(5);   // Leftmost
    ASSERT(v0 == 0, "Leftmost position should give min value");
    int32_t v100 = slider.positionToValue(105); // Rightmost
    ASSERT(v100 == 100, "Rightmost position should give max value");
    return true;
}

bool test_slider_value_to_position() {
    Slider slider(1, 0, 100, 50);
    slider.setBounds(Rect(0, 0, 110, 12));
    int32_t pos = slider.valueToPosition();
    // Value 50 should be approximately in the middle
    ASSERT(pos > 40 && pos < 70, "Value 50 should be near center position");
    return true;
}

bool test_slider_on_measure() {
    Slider slider(1, 0, 100, 50);
    Size s = slider.onMeasure();
    ASSERT(s.width > 0, "Slider width should be > 0");
    ASSERT(s.height > 0, "Slider height should be > 0");
    return true;
}

bool test_slider_render() {
    Slider slider(1, 0, 100, 50);
    slider.setBounds(Rect(0, 0, 120, 12));
    Framebuffer fb(140, 20);
    BitmapFont font;
    fb.clear(Color::Black);
    slider.onRender(fb, font);
    bool hasPixels = false;
    for (int32_t i = 0; i < fb.getPixelCount(); ++i) {
        if (fb.getPixelRaw(i) != 0) { hasPixels = true; break; }
    }
    ASSERT(hasPixels, "Rendered Slider should produce pixels");
    return true;
}

bool test_slider_touch() {
    Slider slider(1, 0, 100, 0);
    slider.setBounds(Rect(0, 0, 110, 12));
    ASSERT(slider.onTouchDown(55, 6), "TouchDown should return true");
    // Value should have changed
    ASSERT(slider.getValue() > 0, "Value should change after touch down");
    ASSERT(slider.onTouchMove(105, 6), "TouchMove should return true");
    ASSERT(slider.getValue() == 100, "Value should be max after moving right");
    ASSERT(slider.onTouchUp(105, 6), "TouchUp should return true");
    return true;
}

bool test_slider_disabled() {
    Slider slider(1, 0, 100, 50);
    slider.setEnabled(false);
    ASSERT(!slider.onTouchDown(55, 6), "Disabled slider should not respond to touch");
    return true;
}

bool test_radiobutton_destructor_cleanup() {
    // Test that destroyed RadioButtons are unregistered
    {
        RadioButton rb1(10, "A", 5);
        RadioButton rb2(11, "B", 5);
    }
    // After scope exit, rb1 and rb2 are destroyed.
    // selectInGroup should not crash with stale pointers.
    RadioButton::selectInGroup(5, 10);
    ASSERT(true, "selectInGroup with no registered buttons should not crash");
    return true;
}

int main() {
    printf("=== Extended Widget Tests ===\n");

    // CheckBox
    test_checkbox_construction();
    test_checkbox_toggle();
    test_checkbox_change_callback();
    test_checkbox_on_measure();
    test_checkbox_render();
    test_checkbox_touch();
    test_checkbox_disabled();

    // RadioButton
    test_radiobutton_construction();
    test_radiobutton_selection();
    test_radiobutton_group();
    test_radiobutton_touch();
    test_radiobutton_on_measure();
    test_radiobutton_render();
    test_radiobutton_destructor_cleanup();

    // ProgressBar
    test_progressbar_construction();
    test_progressbar_value_clamping();
    test_progressbar_percentage();
    test_progressbar_orientation();
    test_progressbar_indeterminate();
    test_progressbar_on_measure();
    test_progressbar_render();
    test_progressbar_custom_range();

    // Slider
    test_slider_construction();
    test_slider_value_clamping();
    test_slider_change_callback();
    test_slider_position_to_value();
    test_slider_value_to_position();
    test_slider_on_measure();
    test_slider_render();
    test_slider_touch();
    test_slider_disabled();

    printf("\nResults: %d/%d passed (%d tests)\n", pass_count, test_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
