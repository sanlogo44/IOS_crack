/*
 * Phantom OS - Sensor Manager Tests
 * v0.29.0 - License: GPL-3.0
 *
 * Tests for SensorManager: lifecycle, sensor control, permission/policy,
 * sensor updates, rate/interval filtering, single reading requests,
 * batching/flush, mock sensor, history/privacy, events, stats, callbacks,
 * failure simulation, integrations, string helpers, full workflow.
 */

#include "phantom/sensor/sensor_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>
#include <cmath>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_DBL_EQ(a, b) do { \
    g_tests_run++; \
    if (std::fabs((a) - (b)) > 0.0001) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST_SIMPLE(test) do { \
    int before = g_tests_failed; \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    if (g_tests_failed > before) std::cout << "FAIL" << std::endl; \
    else std::cout << "OK" << std::endl; \
} while(0)

using namespace phantom::sensor;
using namespace phantom::logging;
using namespace phantom::crashreporter;

// ============================================================
// Helper functions
// ============================================================

static SensorReading makeReading(SensorType sensor, double v0, double v1, double v2,
                                   SensorAccuracy acc = SensorAccuracy::HIGH) {
    SensorReading r;
    r.sensor = sensor;
    r.values[0] = v0;
    r.values[1] = v1;
    r.values[2] = v2;
    r.valueCount = 3;
    r.accuracy = acc;
    return r;
}

// ============================================================
// Lifecycle tests
// ============================================================

static void test_lifecycle() {
    SensorManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), SensorResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), SensorResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_initialize_invalid_params() {
    SensorManager mgr;
    ASSERT_EQ(mgr.initialize(0, 256, 64, 256), SensorResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(256, 0, 64, 256), SensorResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(256, 256, 0, 256), SensorResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(256, 256, 64, 0), SensorResult::INVALID_PARAMETER);
}

static void test_not_initialized_operations() {
    SensorManager mgr;
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::ACCELEROMETER, true), SensorResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.updateSensorReading(SensorType::ACCELEROMETER, SensorReading{}), SensorResult::NOT_INITIALIZED);
    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.requestSingleReading("com.app", SensorType::ACCELEROMETER), SensorResult::NOT_INITIALIZED);
}

static void test_shutdown_clears_state() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setSensorEnabled(SensorType::ACCELEROMETER, true);
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.shutdown();
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::ACCELEROMETER));
    auto policy = mgr.getAppSensorPolicy("com.app");
    ASSERT_EQ(policy.permission, SensorPermission::DENY);
}

static void test_already_initialized() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.initialize(), SensorResult::ALREADY_INITIALIZED);
    mgr.shutdown();
}

// ============================================================
// Sensor control tests
// ============================================================

static void test_sensor_default_state() {
    SensorManager mgr;
    mgr.initialize();
    // Accelerometer, gyroscope, magnetometer, proximity, ambient light, barometer enabled by default
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::ACCELEROMETER));
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::GYROSCOPE));
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::MAGNETOMETER));
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::PROXIMITY));
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::AMBIENT_LIGHT));
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::BAROMETER));
    // Step counter, heart rate, device orientation, mock are disabled by default
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::STEP_COUNTER));
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::HEART_RATE_STUB));
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::DEVICE_ORIENTATION_FUSED));
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::MOCK));
    mgr.shutdown();
}

static void test_sensor_enable_disable() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::STEP_COUNTER));
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::STEP_COUNTER, true), SensorResult::SUCCESS);
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::STEP_COUNTER));
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::STEP_COUNTER, false), SensorResult::SUCCESS);
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::STEP_COUNTER));
    mgr.shutdown();
}

static void test_sensor_info() {
    SensorManager mgr;
    mgr.initialize();
    auto info = mgr.getSensorInfo(SensorType::ACCELEROMETER);
    ASSERT_EQ(info.sensor, SensorType::ACCELEROMETER);
    ASSERT_TRUE(info.enabled);
    ASSERT_EQ(info.axisCount, 3);
    ASSERT_TRUE(info.wakeup);
    ASSERT_TRUE(info.batching);
    ASSERT_STREQ(info.name.c_str(), "Accelerometer");
    ASSERT_DBL_EQ(info.minValue, -19.6);
    ASSERT_DBL_EQ(info.maxValue, 19.6);
    mgr.shutdown();
}

static void test_get_all_sensors() {
    SensorManager mgr;
    mgr.initialize();
    auto sensors = mgr.getSensors();
    ASSERT_EQ(sensors.size(), 10u);
    auto available = mgr.getAvailableSensors();
    ASSERT_TRUE(available.size() >= 6);  // At least 6 default enabled
    mgr.shutdown();
}

static void test_sensor_enable_permission() {
    SensorManager mgr;
    mgr.initialize();
    // Non-system owner cannot enable/disable sensors
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::ACCELEROMETER, false, "com.app"),
              SensorResult::PERMISSION_DENIED);
    // System owner can
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::ACCELEROMETER, false, "system"),
              SensorResult::SUCCESS);
    mgr.shutdown();
}

// ============================================================
// Permission / policy tests
// ============================================================

static void test_set_get_policy() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS,
                                     SensorPrivacyMode::COARSE,
                                     SENSOR_PRIVACY_NO_HISTORY, 50),
              SensorResult::SUCCESS);
    auto policy = mgr.getAppSensorPolicy("com.app");
    ASSERT_EQ(policy.permission, SensorPermission::ALLOW_ALWAYS);
    ASSERT_EQ(policy.privacyMode, SensorPrivacyMode::COARSE);
    ASSERT_TRUE(policy.privacyFlags & SENSOR_PRIVACY_NO_HISTORY);
    ASSERT_EQ(policy.rateLimitHz, 50u);
    mgr.shutdown();
}

static void test_clear_policy() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    ASSERT_EQ(mgr.clearAppSensorPolicy("com.app"), SensorResult::SUCCESS);
    auto policy = mgr.getAppSensorPolicy("com.app");
    ASSERT_EQ(policy.permission, SensorPermission::DENY);
    mgr.shutdown();
}

static void test_clear_policy_permission() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    // Non-system owner cannot clear
    ASSERT_EQ(mgr.clearAppSensorPolicy("com.app", "com.other"), SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

static void test_check_access_deny() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::DENY, SensorPrivacyMode::FULL);
    ASSERT_FALSE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    mgr.shutdown();
}

static void test_check_access_allow_always() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    ASSERT_TRUE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    mgr.shutdown();
}

static void test_check_access_foreground_only() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_FOREGROUND, SensorPrivacyMode::FULL);
    // Not in foreground
    ASSERT_FALSE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    // Set foreground
    mgr.setAppForeground("com.app", true);
    ASSERT_TRUE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    mgr.shutdown();
}

static void test_check_access_allow_once() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ONCE, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);
    // First access OK
    ASSERT_TRUE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    // Provide a reading and consume ALLOW_ONCE via getLastReading
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 3.0);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    // Now ALLOW_ONCE should be consumed, second access denied
    ASSERT_FALSE(mgr.checkAppAccess("com.app", SensorType::ACCELEROMETER));
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out),
              SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

static void test_system_access_always_allowed() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_TRUE(mgr.checkAppAccess("system", SensorType::ACCELEROMETER));
    ASSERT_TRUE(mgr.checkAppAccess("android", SensorType::ACCELEROMETER));
    mgr.shutdown();
}

static void test_biometric_health_disabled() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setSensorEnabled(SensorType::HEART_RATE_STUB, true);
    ASSERT_TRUE(mgr.isSensorEnabled(SensorType::HEART_RATE_STUB));
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS,
                           SensorPrivacyMode::FULL,
                           SENSOR_PRIVACY_DISABLE_BIOMETRIC_HEALTH);
    // Heart rate should be disabled
    ASSERT_FALSE(mgr.isSensorEnabled(SensorType::HEART_RATE_STUB));
    // Access to heart rate should be denied
    ASSERT_FALSE(mgr.checkAppAccess("com.app", SensorType::HEART_RATE_STUB));
    mgr.shutdown();
}

static void test_set_foreground_not_found() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setAppForeground("com.unknown", true), SensorResult::INVALID_PARAMETER);
    mgr.shutdown();
}

// ============================================================
// Sensor update tests
// ============================================================

static void test_update_sensor_reading() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    ASSERT_EQ(mgr.updateSensorReading(SensorType::ACCELEROMETER, r), SensorResult::SUCCESS);
    auto info = mgr.getSensorInfo(SensorType::ACCELEROMETER);
    ASSERT_TRUE(info.lastReadingAt > 0);
    ASSERT_EQ(mgr.getStats().readingUpdates, 1u);
    mgr.shutdown();
}

static void test_update_disabled_sensor() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setSensorEnabled(SensorType::ACCELEROMETER, false);
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    ASSERT_EQ(mgr.updateSensorReading(SensorType::ACCELEROMETER, r), SensorResult::SENSOR_DISABLED);
    mgr.shutdown();
}

static void test_update_permission() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    // Non-system owner cannot update readings
    ASSERT_EQ(mgr.updateSensorReading(SensorType::ACCELEROMETER, r, "com.app"),
              SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

static void test_get_last_reading() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    ASSERT_DBL_EQ(out.values[0], 1.0);
    ASSERT_DBL_EQ(out.values[1], 2.0);
    ASSERT_DBL_EQ(out.values[2], 9.81);
    mgr.shutdown();
}

static void test_get_last_reading_unavailable() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);
    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out),
              SensorResult::READING_UNAVAILABLE);
    mgr.shutdown();
}

static void test_get_last_reading_coarse() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS,
                           SensorPrivacyMode::COARSE);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.7, 2.3, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    // Coarse mode rounds to integer
    ASSERT_DBL_EQ(out.values[0], 2.0);
    ASSERT_DBL_EQ(out.values[1], 2.0);
    mgr.shutdown();
}

static void test_get_last_reading_no_raw() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS,
                           SensorPrivacyMode::NO_RAW);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    SensorReading out;
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    // NO_RAW mode zeros out values
    ASSERT_DBL_EQ(out.values[0], 0.0);
    ASSERT_DBL_EQ(out.values[1], 0.0);
    ASSERT_DBL_EQ(out.values[2], 0.0);
    mgr.shutdown();
}

static void test_request_single_reading() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    ASSERT_EQ(mgr.requestSingleReading("com.app", SensorType::ACCELEROMETER),
              SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().deliveredReadings, 1u);
    mgr.shutdown();
}

static void test_request_single_reading_unavailable() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    ASSERT_EQ(mgr.requestSingleReading("com.app", SensorType::ACCELEROMETER),
              SensorResult::READING_UNAVAILABLE);
    mgr.shutdown();
}

static void test_allow_once_consumed_single() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ONCE, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    ASSERT_EQ(mgr.requestSingleReading("com.app", SensorType::ACCELEROMETER),
              SensorResult::SUCCESS);
    // Second request should be denied (ALLOW_ONCE consumed)
    ASSERT_EQ(mgr.requestSingleReading("com.app", SensorType::ACCELEROMETER),
              SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

// ============================================================
// Continuous updates tests
// ============================================================

static void test_start_cancel_updates() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    ASSERT_EQ(mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                                     50, 0, 0, &requestId),
              SensorResult::SUCCESS);
    ASSERT_TRUE(requestId > 0);
    ASSERT_EQ(mgr.cancelSensorUpdates(requestId, "com.app"), SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().requestsStarted, 1u);
    ASSERT_EQ(mgr.getStats().requestsCancelled, 1u);
    mgr.shutdown();
}

static void test_updates_delivered() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 0, 0, &requestId);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    ASSERT_EQ(mgr.getStats().deliveredReadings, 1u);
    mgr.shutdown();
}

static void test_rate_limit() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS,
                           SensorPrivacyMode::FULL, SENSOR_PRIVACY_RATE_LIMIT, 10);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 0, 0, &requestId);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // Immediate second update should be rate-limited (10Hz = 100ms interval)
    uint64_t before = mgr.getStats().deliveredReadings;
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    // Should be throttled (same timestamp)
    ASSERT_EQ(mgr.getStats().deliveredReadings, before);
    mgr.shutdown();
}

static void test_interval_filter() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    // 10Hz sample rate = 100ms interval
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           10, 0, 0, &requestId);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // Same timestamp — should be filtered
    uint64_t delivered1 = mgr.getStats().deliveredReadings;
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    ASSERT_EQ(mgr.getStats().deliveredReadings, delivered1);
    mgr.shutdown();
}

static void test_request_expiry() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    mgr.setCurrentTimeForTesting(100);

    uint64_t requestId = 0;
    // 100ms timeout
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 0, 100, &requestId);

    // Advance time past timeout
    mgr.setCurrentTimeForTesting(300);
    mgr.processSensorRequests();

    auto requests = mgr.getStats();
    ASSERT_EQ(requests.requestsExpired, 1u);
    mgr.clearTimeOverride();
    mgr.shutdown();
}

static void test_cancel_wrong_app() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 0, 0, &requestId);

    // Wrong app cannot cancel
    ASSERT_EQ(mgr.cancelSensorUpdates(requestId, "com.other"),
              SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

static void test_capacity_exceeded_requests() {
    SensorManager mgr;
    mgr.initialize(256, 256, 4, 256);  // maxRequests = 4
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    for (int i = 0; i < 4; ++i) {
        ASSERT_EQ(mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                                         100, 0, 0),
                  SensorResult::SUCCESS);
    }
    // 5th should fail
    ASSERT_EQ(mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                                     100, 0, 0),
              SensorResult::CAPACITY_EXCEEDED);
    mgr.shutdown();
}

// ============================================================
// Batching / flush tests
// ============================================================

static void test_batching() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    // maxReportLatency = 1000ms enables batching
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 1000, 0, &requestId);

    // Deliver multiple readings into batch
    mgr.setCurrentTimeForTesting(100);
    SensorReading r1 = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r1);

    mgr.setCurrentTimeForTesting(200);
    SensorReading r2 = makeReading(SensorType::ACCELEROMETER, 1.1, 2.1, 9.82);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r2);

    // Readings should be batched, not directly delivered
    ASSERT_EQ(mgr.getStats().deliveredReadings, 0u);

    // Flush delivers all batched readings
    ASSERT_EQ(mgr.flushBatch(requestId, "com.app"), SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().deliveredReadings, 2u);
    ASSERT_EQ(mgr.getStats().flushesCompleted, 1u);
    mgr.clearTimeOverride();
    mgr.shutdown();
}

static void test_flush_not_found() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.flushBatch(999, "com.app"), SensorResult::REQUEST_NOT_FOUND);
    mgr.shutdown();
}

static void test_flush_permission() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                           100, 1000, 0, &requestId);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // Wrong app cannot flush
    ASSERT_EQ(mgr.flushBatch(requestId, "com.other"),
              SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

// ============================================================
// History / privacy tests
// ============================================================

static void test_history_basic() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r1 = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    SensorReading r2 = makeReading(SensorType::GYROSCOPE, 0.1, 0.2, 0.3);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r1);
    mgr.updateSensorReading(SensorType::GYROSCOPE, r2);

    auto history = mgr.getHistory("system");
    ASSERT_EQ(history.size(), 2u);
    // Newest first
    ASSERT_EQ(history[0].sensor, SensorType::GYROSCOPE);
    mgr.shutdown();
}

static void test_history_capacity() {
    SensorManager mgr;
    mgr.initialize(5, 256, 64, 256);  // maxHistory = 5
    for (int i = 0; i < 10; ++i) {
        SensorReading r = makeReading(SensorType::ACCELEROMETER,
                                      static_cast<double>(i), 0.0, 0.0);
        mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    }
    ASSERT_EQ(mgr.getHistoryCount(), 5u);
    mgr.shutdown();
}

static void test_clear_history() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    ASSERT_EQ(mgr.clearHistory(), SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), 0u);
    mgr.shutdown();
}

static void test_clear_history_permission() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    ASSERT_EQ(mgr.clearHistory("com.app"), SensorResult::PERMISSION_DENIED);
    mgr.shutdown();
}

// ============================================================
// Mock tests
// ============================================================

static void test_mock_basic() {
    SensorManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setMockEnabled(true), SensorResult::SUCCESS);
    ASSERT_TRUE(mgr.isMockEnabled());

    SensorReading mock = makeReading(SensorType::ACCELEROMETER, 5.0, 5.0, 5.0);
    ASSERT_EQ(mgr.setMockReading(SensorType::ACCELEROMETER, mock), SensorResult::SUCCESS);

    // Update should deliver mock reading
    SensorReading empty;
    mgr.updateSensorReading(SensorType::ACCELEROMETER, empty);

    SensorReading out;
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    ASSERT_DBL_EQ(out.values[0], 5.0);
    ASSERT_TRUE(out.mock);
    mgr.shutdown();
}

static void test_mock_clear() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setMockEnabled(true);
    SensorReading mock = makeReading(SensorType::ACCELEROMETER, 5.0, 5.0, 5.0);
    mgr.setMockReading(SensorType::ACCELEROMETER, mock);
    ASSERT_EQ(mgr.clearMockReading(SensorType::ACCELEROMETER), SensorResult::SUCCESS);

    // After clearing mock, actual readings should be used
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    SensorReading out;
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);
    ASSERT_EQ(mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out), SensorResult::SUCCESS);
    ASSERT_DBL_EQ(out.values[0], 1.0);
    ASSERT_FALSE(out.mock);
    mgr.shutdown();
}

static void test_mock_permission() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    // Without MOCK_ALLOWED flag, non-system cannot set mock
    SensorReading mock = makeReading(SensorType::ACCELEROMETER, 5.0, 5.0, 5.0);
    ASSERT_EQ(mgr.setMockReading(SensorType::ACCELEROMETER, mock, "com.app"),
              SensorResult::MOCK_NOT_ALLOWED);
    mgr.shutdown();
}

// ============================================================
// Privacy transform tests
// ============================================================

static void test_privacy_transform_full() {
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.5, 2.7, 9.81);
    auto result = SensorManager::applyPrivacyTransform(r, SensorPrivacyMode::FULL,
                                                        SENSOR_PRIVACY_NONE);
    ASSERT_DBL_EQ(result.values[0], 1.5);
    ASSERT_DBL_EQ(result.values[1], 2.7);
}

static void test_privacy_transform_coarse() {
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.5, 2.7, 9.81);
    auto result = SensorManager::applyPrivacyTransform(r, SensorPrivacyMode::COARSE,
                                                        SENSOR_PRIVACY_NONE);
    // Coarse rounds to integer
    ASSERT_DBL_EQ(result.values[0], 2.0);
    ASSERT_DBL_EQ(result.values[1], 3.0);
}

static void test_privacy_transform_no_raw() {
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.5, 2.7, 9.81);
    auto result = SensorManager::applyPrivacyTransform(r, SensorPrivacyMode::NO_RAW,
                                                        SENSOR_PRIVACY_NONE);
    ASSERT_DBL_EQ(result.values[0], 0.0);
    ASSERT_DBL_EQ(result.values[1], 0.0);
    ASSERT_DBL_EQ(result.values[2], 0.0);
}

static void test_privacy_transform_redact_precision() {
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.5678, 2.3456, 9.8123);
    auto result = SensorManager::applyPrivacyTransform(r, SensorPrivacyMode::FULL,
                                                        SENSOR_PRIVACY_REDACT_PRECISION);
    // Redact precision keeps 1 decimal
    ASSERT_DBL_EQ(result.values[0], 1.6);
    ASSERT_DBL_EQ(result.values[1], 2.3);
}

static void test_quantize_precision() {
    ASSERT_DBL_EQ(SensorManager::quantizePrecision(1.5678, 0), 2.0);
    ASSERT_DBL_EQ(SensorManager::quantizePrecision(1.5678, 1), 1.6);
    ASSERT_DBL_EQ(SensorManager::quantizePrecision(1.5678, 2), 1.57);
    ASSERT_DBL_EQ(SensorManager::quantizePrecision(1.5678, 3), 1.568);
}

// ============================================================
// Events tests
// ============================================================

static void test_event_ring_buffer() {
    SensorManager mgr;
    mgr.initialize(256, 3, 64, 256);  // maxEvents = 3
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    for (int i = 0; i < 5; ++i) {
        mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    }
    // Ring buffer should be capped at 3
    ASSERT_EQ(mgr.getEventCount(), 3u);
    mgr.shutdown();
}

static void test_event_fields() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() > 0);
    bool found_update = false;
    for (const auto& e : events) {
        if (e.type == SensorEventType::READING_UPDATED) {
            found_update = true;
            ASSERT_EQ(e.sensor, SensorType::ACCELEROMETER);
        }
    }
    ASSERT_TRUE(found_update);
    mgr.shutdown();
}

static void test_events_by_type() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    auto updateEvents = mgr.getEventsByType(SensorEventType::READING_UPDATED);
    ASSERT_TRUE(updateEvents.size() > 0);
    auto deniedEvents = mgr.getEventsByType(SensorEventType::READING_DENIED);
    ASSERT_EQ(deniedEvents.size(), 0u);
    mgr.shutdown();
}

static void test_clear_events() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);
    ASSERT_TRUE(mgr.getEventCount() > 0);
    ASSERT_EQ(mgr.clearEvents(), SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), 0u);
    mgr.shutdown();
}

// ============================================================
// Stats tests
// ============================================================

static void test_stats_totals() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // getLastReading delivers a reading
    SensorReading out;
    mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out);

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.readingUpdates > 0);
    ASSERT_TRUE(stats.deliveredReadings > 0);
    ASSERT_EQ(stats.totalFailures, 0u);
    mgr.shutdown();
}

static void test_stats_arrays() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    auto stats = mgr.getStats();
    // Accelerometer is index 0
    ASSERT_TRUE(stats.bySensor[0] > 0);
    // READING_UPDATED is index 2
    ASSERT_TRUE(stats.byEventType[2] > 0);
    // SUCCESS is index 0
    ASSERT_TRUE(stats.byResult[0] > 0);
    mgr.shutdown();
}

static void test_reset_stats() {
    SensorManager mgr;
    mgr.initialize();
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    mgr.resetStats();
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.readingUpdates, 0u);
    ASSERT_EQ(stats.deliveredReadings, 0u);
    mgr.shutdown();
}

// ============================================================
// Callback tests
// ============================================================

static void test_reading_callback() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    bool called = false;
    std::string calledApp;
    mgr.setReadingCallback([&](const SensorReading&, const std::string& appId) {
        called = true;
        calledApp = appId;
    });

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER, 100, 0, 0, &requestId);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    ASSERT_TRUE(called);
    ASSERT_EQ(calledApp, "com.app");
    mgr.shutdown();
}

static void test_access_callback() {
    SensorManager mgr;
    mgr.initialize();
    bool called = false;
    mgr.setAccessCallback([&](const std::string&, SensorResult) {
        called = true;
    });

    mgr.setAppSensorPolicy("com.app", SensorPermission::DENY, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);
    SensorReading out;
    mgr.getLastReading("com.app", SensorType::ACCELEROMETER, out);

    ASSERT_TRUE(called);
    mgr.shutdown();
}

static void test_event_callback() {
    SensorManager mgr;
    mgr.initialize();
    bool called = false;
    mgr.setEventCallback([&](const SensorEvent&) {
        called = true;
    });

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    ASSERT_TRUE(called);
    mgr.shutdown();
}

// ============================================================
// Failure simulation tests
// ============================================================

static void test_failure_simulation() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::ACCELEROMETER, false), SensorResult::SIMULATED_FAILURE);
    // Should be reset after one use
    ASSERT_EQ(mgr.setSensorEnabled(SensorType::ACCELEROMETER, false), SensorResult::SUCCESS);
    mgr.shutdown();
}

static void test_failure_update() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setFailNextOperation(true);
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    ASSERT_EQ(mgr.updateSensorReading(SensorType::ACCELEROMETER, r), SensorResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

static void test_failure_flush() {
    SensorManager mgr;
    mgr.initialize();
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_ALWAYS, SensorPrivacyMode::FULL);
    mgr.setAppForeground("com.app", true);

    uint64_t requestId = 0;
    mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER, 100, 1000, 0, &requestId);
    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.flushBatch(requestId, "com.app"), SensorResult::FLUSH_FAILED);
    mgr.shutdown();
}

// ============================================================
// Integration tests
// ============================================================

static void test_log_server_integration() {
    SensorManager mgr;
    mgr.initialize();

    LogServer logs;
    logs.initialize();
    mgr.setLogServer(&logs);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 1.0, 2.0, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // LogServer should have entries
    auto recent = logs.getRecentLogs(10);
    ASSERT_TRUE(recent.size() > 0);
    mgr.shutdown();
    logs.shutdown();
}

static void test_crash_reporter_integration() {
    SensorManager mgr;
    mgr.initialize();

    CrashReporter cr;
    cr.initialize();
    mgr.setCrashReporter(&cr);

    // Just verify the crash reporter is set
    ASSERT_TRUE(mgr.getCrashReporter() != nullptr);

    mgr.shutdown();
    cr.shutdown();
}

static void test_log_no_raw_values() {
    SensorManager mgr;
    mgr.initialize();

    LogServer logs;
    logs.initialize();
    mgr.setLogServer(&logs);

    SensorReading r = makeReading(SensorType::ACCELEROMETER, 42.123, 99.456, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r);

    // Check that raw sensor values don't appear in logs
    auto recent = logs.getRecentLogs(50);
    for (const auto& entry : recent) {
        std::string msg = entry.message;
        // Should not contain raw sensor values
        ASSERT_TRUE(msg.find("42.123") == std::string::npos);
        ASSERT_TRUE(msg.find("99.456") == std::string::npos);
    }
    mgr.shutdown();
    logs.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

static void test_string_helpers_sensor_types() {
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::ACCELEROMETER), "ACCELEROMETER");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::GYROSCOPE), "GYROSCOPE");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::MAGNETOMETER), "MAGNETOMETER");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::PROXIMITY), "PROXIMITY");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::AMBIENT_LIGHT), "AMBIENT_LIGHT");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::BAROMETER), "BAROMETER");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::STEP_COUNTER), "STEP_COUNTER");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::HEART_RATE_STUB), "HEART_RATE_STUB");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::DEVICE_ORIENTATION_FUSED), "DEVICE_ORIENTATION_FUSED");
    ASSERT_STREQ(SensorManager::sensorTypeToString(SensorType::MOCK), "MOCK");
}

static void test_string_helpers_states() {
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::DISABLED), "DISABLED");
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::IDLE), "IDLE");
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::SEARCHING), "SEARCHING");
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::AVAILABLE), "AVAILABLE");
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::TEMP_UNAVAILABLE), "TEMP_UNAVAILABLE");
    ASSERT_STREQ(SensorManager::sensorStateToString(SensorState::FAILED), "FAILED");
}

static void test_string_helpers_accuracy() {
    ASSERT_STREQ(SensorManager::sensorAccuracyToString(SensorAccuracy::NONE), "NONE");
    ASSERT_STREQ(SensorManager::sensorAccuracyToString(SensorAccuracy::LOW), "LOW");
    ASSERT_STREQ(SensorManager::sensorAccuracyToString(SensorAccuracy::MEDIUM), "MEDIUM");
    ASSERT_STREQ(SensorManager::sensorAccuracyToString(SensorAccuracy::HIGH), "HIGH");
    ASSERT_STREQ(SensorManager::sensorAccuracyToString(SensorAccuracy::UNKNOWN), "UNKNOWN");
}

static void test_string_helpers_permissions() {
    ASSERT_STREQ(SensorManager::sensorPermissionToString(SensorPermission::DENY), "DENY");
    ASSERT_STREQ(SensorManager::sensorPermissionToString(SensorPermission::ALLOW_FOREGROUND), "ALLOW_FOREGROUND");
    ASSERT_STREQ(SensorManager::sensorPermissionToString(SensorPermission::ALLOW_ALWAYS), "ALLOW_ALWAYS");
    ASSERT_STREQ(SensorManager::sensorPermissionToString(SensorPermission::ALLOW_ONCE), "ALLOW_ONCE");
}

static void test_string_helpers_request_states() {
    ASSERT_STREQ(SensorManager::requestStateToString(SensorRequestState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(SensorManager::requestStateToString(SensorRequestState::PAUSED), "PAUSED");
    ASSERT_STREQ(SensorManager::requestStateToString(SensorRequestState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(SensorManager::requestStateToString(SensorRequestState::CANCELLED), "CANCELLED");
}

static void test_string_helpers_privacy_modes() {
    ASSERT_STREQ(SensorManager::sensorPrivacyModeToString(SensorPrivacyMode::FULL), "FULL");
    ASSERT_STREQ(SensorManager::sensorPrivacyModeToString(SensorPrivacyMode::COARSE), "COARSE");
    ASSERT_STREQ(SensorManager::sensorPrivacyModeToString(SensorPrivacyMode::NO_RAW), "NO_RAW");
}

static void test_string_helpers_results() {
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::SENSOR_DISABLED), "SENSOR_DISABLED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::READING_UNAVAILABLE), "READING_UNAVAILABLE");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::CAPACITY_EXCEEDED), "CAPACITY_EXCEEDED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::MOCK_NOT_ALLOWED), "MOCK_NOT_ALLOWED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::RATE_LIMITED), "RATE_LIMITED");
    ASSERT_STREQ(SensorManager::sensorResultToString(SensorResult::FLUSH_FAILED), "FLUSH_FAILED");
}

static void test_string_helpers_event_types() {
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::SENSOR_ENABLED), "SENSOR_ENABLED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::SENSOR_DISABLED), "SENSOR_DISABLED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::READING_UPDATED), "READING_UPDATED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::READING_DELIVERED), "READING_DELIVERED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::READING_DENIED), "READING_DENIED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::FLUSH_COMPLETED), "FLUSH_COMPLETED");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::MOCK_READING_SET), "MOCK_READING_SET");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::BATCH_OVERFLOW), "BATCH_OVERFLOW");
    ASSERT_STREQ(SensorManager::sensorEventTypeToString(SensorEventType::RATE_THROTTLED), "RATE_THROTTLED");
}

static void test_string_parsers() {
    ASSERT_EQ(SensorManager::stringToSensorType("ACCELEROMETER"), SensorType::ACCELEROMETER);
    ASSERT_EQ(SensorManager::stringToSensorType("GYROSCOPE"), SensorType::GYROSCOPE);
    ASSERT_EQ(SensorManager::stringToSensorType("MOCK"), SensorType::MOCK);
    ASSERT_EQ(SensorManager::stringToSensorResult("SUCCESS"), SensorResult::SUCCESS);
    ASSERT_EQ(SensorManager::stringToSensorResult("PERMISSION_DENIED"), SensorResult::PERMISSION_DENIED);
    ASSERT_EQ(SensorManager::stringToSensorResult("FLUSH_FAILED"), SensorResult::FLUSH_FAILED);
}

// ============================================================
// Full workflow test
// ============================================================

static void test_full_workflow() {
    SensorManager mgr;
    ASSERT_EQ(mgr.initialize(), SensorResult::SUCCESS);

    // 1. Set policy
    mgr.setAppSensorPolicy("com.app", SensorPermission::ALLOW_FOREGROUND,
                           SensorPrivacyMode::COARSE, SENSOR_PRIVACY_NO_HISTORY);
    mgr.setAppForeground("com.app", true);

    // 2. Start continuous updates with batching
    uint64_t requestId = 0;
    ASSERT_EQ(mgr.startSensorUpdates("com.app", SensorType::ACCELEROMETER,
                                     50, 500, 0, &requestId),
              SensorResult::SUCCESS);

    // 3. Deliver readings
    mgr.setCurrentTimeForTesting(100);
    SensorReading r1 = makeReading(SensorType::ACCELEROMETER, 1.5, 2.5, 9.81);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r1);

    mgr.setCurrentTimeForTesting(200);
    SensorReading r2 = makeReading(SensorType::ACCELEROMETER, 1.6, 2.6, 9.82);
    mgr.updateSensorReading(SensorType::ACCELEROMETER, r2);

    // 4. Readings should be batched (not directly delivered)
    uint64_t batched = mgr.getStats().deliveredReadings;
    ASSERT_EQ(batched, 0u);

    // 5. Flush delivers batched readings
    ASSERT_EQ(mgr.flushBatch(requestId, "com.app"), SensorResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().deliveredReadings, 2u);
    ASSERT_EQ(mgr.getStats().flushesCompleted, 1u);

    // 6. Check events
    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() > 0);

    // 7. Check stats
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.readingUpdates >= 2);
    ASSERT_TRUE(stats.flushesCompleted >= 1);

    // 8. Cancel request
    ASSERT_EQ(mgr.cancelSensorUpdates(requestId, "com.app"), SensorResult::SUCCESS);

    // 9. Clear history
    ASSERT_EQ(mgr.clearHistory(), SensorResult::SUCCESS);

    // 10. Shutdown
    mgr.clearTimeOverride();
    ASSERT_EQ(mgr.shutdown(), SensorResult::SUCCESS);
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Phantom OS Sensor Manager Tests (v0.29.0) ===" << std::endl;

    // Lifecycle
    RUN_TEST_SIMPLE(test_lifecycle);
    RUN_TEST_SIMPLE(test_initialize_invalid_params);
    RUN_TEST_SIMPLE(test_not_initialized_operations);
    RUN_TEST_SIMPLE(test_shutdown_clears_state);
    RUN_TEST_SIMPLE(test_already_initialized);

    // Sensor control
    RUN_TEST_SIMPLE(test_sensor_default_state);
    RUN_TEST_SIMPLE(test_sensor_enable_disable);
    RUN_TEST_SIMPLE(test_sensor_info);
    RUN_TEST_SIMPLE(test_get_all_sensors);
    RUN_TEST_SIMPLE(test_sensor_enable_permission);

    // Permission / policy
    RUN_TEST_SIMPLE(test_set_get_policy);
    RUN_TEST_SIMPLE(test_clear_policy);
    RUN_TEST_SIMPLE(test_clear_policy_permission);
    RUN_TEST_SIMPLE(test_check_access_deny);
    RUN_TEST_SIMPLE(test_check_access_allow_always);
    RUN_TEST_SIMPLE(test_check_access_foreground_only);
    RUN_TEST_SIMPLE(test_check_access_allow_once);
    RUN_TEST_SIMPLE(test_system_access_always_allowed);
    RUN_TEST_SIMPLE(test_biometric_health_disabled);
    RUN_TEST_SIMPLE(test_set_foreground_not_found);

    // Sensor updates
    RUN_TEST_SIMPLE(test_update_sensor_reading);
    RUN_TEST_SIMPLE(test_update_disabled_sensor);
    RUN_TEST_SIMPLE(test_update_permission);
    RUN_TEST_SIMPLE(test_get_last_reading);
    RUN_TEST_SIMPLE(test_get_last_reading_unavailable);
    RUN_TEST_SIMPLE(test_get_last_reading_coarse);
    RUN_TEST_SIMPLE(test_get_last_reading_no_raw);
    RUN_TEST_SIMPLE(test_request_single_reading);
    RUN_TEST_SIMPLE(test_request_single_reading_unavailable);
    RUN_TEST_SIMPLE(test_allow_once_consumed_single);

    // Continuous updates
    RUN_TEST_SIMPLE(test_start_cancel_updates);
    RUN_TEST_SIMPLE(test_updates_delivered);
    RUN_TEST_SIMPLE(test_rate_limit);
    RUN_TEST_SIMPLE(test_interval_filter);
    RUN_TEST_SIMPLE(test_request_expiry);
    RUN_TEST_SIMPLE(test_cancel_wrong_app);
    RUN_TEST_SIMPLE(test_capacity_exceeded_requests);

    // Batching / flush
    RUN_TEST_SIMPLE(test_batching);
    RUN_TEST_SIMPLE(test_flush_not_found);
    RUN_TEST_SIMPLE(test_flush_permission);

    // History / privacy
    RUN_TEST_SIMPLE(test_history_basic);
    RUN_TEST_SIMPLE(test_history_capacity);
    RUN_TEST_SIMPLE(test_clear_history);
    RUN_TEST_SIMPLE(test_clear_history_permission);

    // Mock
    RUN_TEST_SIMPLE(test_mock_basic);
    RUN_TEST_SIMPLE(test_mock_clear);
    RUN_TEST_SIMPLE(test_mock_permission);

    // Privacy transform
    RUN_TEST_SIMPLE(test_privacy_transform_full);
    RUN_TEST_SIMPLE(test_privacy_transform_coarse);
    RUN_TEST_SIMPLE(test_privacy_transform_no_raw);
    RUN_TEST_SIMPLE(test_privacy_transform_redact_precision);
    RUN_TEST_SIMPLE(test_quantize_precision);

    // Events
    RUN_TEST_SIMPLE(test_event_ring_buffer);
    RUN_TEST_SIMPLE(test_event_fields);
    RUN_TEST_SIMPLE(test_events_by_type);
    RUN_TEST_SIMPLE(test_clear_events);

    // Stats
    RUN_TEST_SIMPLE(test_stats_totals);
    RUN_TEST_SIMPLE(test_stats_arrays);
    RUN_TEST_SIMPLE(test_reset_stats);

    // Callbacks
    RUN_TEST_SIMPLE(test_reading_callback);
    RUN_TEST_SIMPLE(test_access_callback);
    RUN_TEST_SIMPLE(test_event_callback);

    // Failure simulation
    RUN_TEST_SIMPLE(test_failure_simulation);
    RUN_TEST_SIMPLE(test_failure_update);
    RUN_TEST_SIMPLE(test_failure_flush);

    // Integration
    RUN_TEST_SIMPLE(test_log_server_integration);
    RUN_TEST_SIMPLE(test_crash_reporter_integration);
    RUN_TEST_SIMPLE(test_log_no_raw_values);

    // String helpers
    RUN_TEST_SIMPLE(test_string_helpers_sensor_types);
    RUN_TEST_SIMPLE(test_string_helpers_states);
    RUN_TEST_SIMPLE(test_string_helpers_accuracy);
    RUN_TEST_SIMPLE(test_string_helpers_permissions);
    RUN_TEST_SIMPLE(test_string_helpers_request_states);
    RUN_TEST_SIMPLE(test_string_helpers_privacy_modes);
    RUN_TEST_SIMPLE(test_string_helpers_results);
    RUN_TEST_SIMPLE(test_string_helpers_event_types);
    RUN_TEST_SIMPLE(test_string_parsers);

    // Full workflow
    RUN_TEST_SIMPLE(test_full_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run
              << " passed ===" << std::endl;
    return g_tests_failed == 0 ? 0 : 1;
}
