/*
 * Phantom OS - i18n Localization Tests
 *
 * License: GPL-3.0
 */

#include "phantom/i18n/localization.h"
#include <cassert>
#include <cstdio>

using namespace phantom::i18n;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_locale_codes() {
    ASSERT(Localization::getLocaleCode(Locale::ENGLISH) == "en", "English code should be 'en'");
    ASSERT(Localization::getLocaleCode(Locale::GERMAN) == "de", "German code should be 'de'");
    return true;
}

bool test_parse_locale_code() {
    ASSERT(Localization::parseLocaleCode("en") == Locale::ENGLISH, "'en' should parse to ENGLISH");
    ASSERT(Localization::parseLocaleCode("de") == Locale::GERMAN, "'de' should parse to GERMAN");
    ASSERT(Localization::parseLocaleCode("de_DE") == Locale::GERMAN, "'de_DE' should parse to GERMAN");
    ASSERT(Localization::parseLocaleCode("fr") == Locale::ENGLISH, "'fr' should fall back to ENGLISH");
    ASSERT(Localization::parseLocaleCode("") == Locale::ENGLISH, "Empty should fall back to ENGLISH");
    return true;
}

bool test_register_and_translate() {
    Localization loc;
    loc.registerTranslation("greeting", "Hello", "Hallo");

    loc.setLocale(Locale::ENGLISH);
    ASSERT(loc.t("greeting") == "Hello", "English greeting should be 'Hello'");

    loc.setLocale(Locale::GERMAN);
    ASSERT(loc.t("greeting") == "Hallo", "German greeting should be 'Hallo'");
    return true;
}

bool test_fallback() {
    Localization loc;
    // Register with only English
    loc.registerTranslation("only_en", "Yes", "");

    loc.setLocale(Locale::GERMAN);
    ASSERT(loc.t("only_en") == "Yes", "Missing German should fall back to English");

    // Register with only German
    loc.registerTranslation("only_de", "", "Ja");

    loc.setLocale(Locale::ENGLISH);
    ASSERT(loc.t("only_de") == "Ja", "Missing English should fall back to German");
    return true;
}

bool test_missing_key() {
    Localization loc;
    loc.setLocale(Locale::ENGLISH);
    ASSERT(loc.t("nonexistent") == "nonexistent", "Missing key should return the key itself");
    ASSERT(!loc.hasTranslation("nonexistent"), "hasTranslation should return false for missing key");
    return true;
}

bool test_has_translation() {
    Localization loc;
    loc.registerTranslation("test", "Test", "Test");

    ASSERT(loc.hasTranslation("test"), "Should have translation for 'test'");
    ASSERT(loc.hasTranslation("test", Locale::ENGLISH), "Should have English translation");
    ASSERT(loc.hasTranslation("test", Locale::GERMAN), "Should have German translation");

    loc.registerTranslation("en_only", "EN", "");
    ASSERT(loc.hasTranslation("en_only", Locale::ENGLISH), "Should have English");
    ASSERT(!loc.hasTranslation("en_only", Locale::GERMAN), "Should not have German");
    return true;
}

bool test_default_translations() {
    Localization loc;
    loc.loadDefaults();

    loc.setLocale(Locale::ENGLISH);
    ASSERT(loc.t("settings") == "Settings", "Default English 'settings' should be 'Settings'");
    ASSERT(loc.t("wifi") == "Wi-Fi", "Default English 'wifi' should be 'Wi-Fi'");
    ASSERT(loc.t("ok") == "OK", "Default English 'ok' should be 'OK'");
    ASSERT(loc.t("cancel") == "Cancel", "Default English 'cancel' should be 'Cancel'");

    loc.setLocale(Locale::GERMAN);
    ASSERT(loc.t("settings") == "Einstellungen", "Default German 'settings' should be 'Einstellungen'");
    ASSERT(loc.t("wifi") == "WLAN", "Default German 'wifi' should be 'WLAN'");
    ASSERT(loc.t("ok") == "OK", "Default German 'ok' should be 'OK'");
    ASSERT(loc.t("cancel") == "Abbrechen", "Default German 'cancel' should be 'Abbrechen'");
    return true;
}

bool test_locale_specific_translation() {
    Localization loc;
    loc.registerTranslation("test", "English text", "Deutscher Text");

    // Translate with specific locale regardless of current
    ASSERT(loc.t("test", Locale::ENGLISH) == "English text", "Locale-specific EN should work");
    ASSERT(loc.t("test", Locale::GERMAN) == "Deutscher Text", "Locale-specific DE should work");
    return true;
}

bool test_get_keys() {
    Localization loc;
    loc.registerTranslation("a", "A", "A");
    loc.registerTranslation("b", "B", "B");
    loc.registerTranslation("c", "C", "C");

    auto keys = loc.getKeys();
    ASSERT(keys.size() == 3, "Should have 3 keys");
    ASSERT(loc.getTranslationCount() == 3, "Translation count should be 3");
    return true;
}

bool test_clear() {
    Localization loc;
    loc.registerTranslation("test", "Test", "Test");
    ASSERT(loc.getTranslationCount() == 1, "Should have 1 translation");

    loc.clear();
    ASSERT(loc.getTranslationCount() == 0, "Should have 0 translations after clear");
    return true;
}

int main() {
    printf("=== i18n Localization Tests ===\n");
    test_locale_codes();
    test_parse_locale_code();
    test_register_and_translate();
    test_fallback();
    test_missing_key();
    test_has_translation();
    test_default_translations();
    test_locale_specific_translation();
    test_get_keys();
    test_clear();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
