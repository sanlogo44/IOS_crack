/*
 * Phantom OS - Recovery Mode Manager Tests
 *
 * v0.22.0
 * License: GPL-3.0
 */

#include "phantom/recovery/recovery_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <cstring>
#include <iostream>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST(test) do { \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    if (g_tests_failed == 0 || true) { \
        std::cout << " OK" << std::endl; \
    } \
} while(0)

using namespace phantom::recovery;
using namespace phantom::logging;
using namespace phantom::crashreporter;

// ============================================================
// Lifecycle tests
// ============================================================

void test_init() {
    RecoveryManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
}

void test_double_init() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(), RecoveryResult::ALREADY_INITIALIZED);
}

void test_shutdown() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.shutdown(), RecoveryResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

void test_reinit() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.shutdown(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
}

void test_not_initialized() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearHistory(), RecoveryResult::NOT_INITIALIZED);
}

// ============================================================
// Session management tests
// ============================================================

void test_enter_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_TRUE(mgr.isInRecovery());
    ASSERT_EQ(mgr.getCurrentMode(), RecoveryMode::RECOVERY_SHELL);
}

void test_enter_already_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::SAFE_MODE), RecoveryResult::ALREADY_IN_RECOVERY);
}

void test_exit_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    ASSERT_FALSE(mgr.isInRecovery());
}

void test_exit_not_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::NOT_IN_RECOVERY);
}

void test_enter_with_boot_reason() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::SAFE_MODE, BootReason::SAFE_MODE_REQUESTED), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getBootReason(), BootReason::SAFE_MODE_REQUESTED);
    ASSERT_TRUE(mgr.isSafeMode());
}

void test_enter_factory_reset_mode() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::FACTORY_RESET), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getCurrentMode(), RecoveryMode::FACTORY_RESET);
}

void test_enter_all_modes() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    RecoveryMode modes[] = {
        RecoveryMode::NORMAL_BOOT, RecoveryMode::SAFE_MODE, RecoveryMode::RECOVERY_SHELL,
        RecoveryMode::UPDATE_RECOVERY, RecoveryMode::BACKUP_RESTORE, RecoveryMode::FACTORY_RESET,
        RecoveryMode::DIAGNOSTIC
    };

    for (auto mode : modes) {
        ASSERT_EQ(mgr.enterRecovery(mode), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.getCurrentMode(), mode);
        ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
        ASSERT_FALSE(mgr.isInRecovery());
    }
}

void test_all_boot_reasons() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    BootReason reasons[] = {
        BootReason::NORMAL, BootReason::RECOVERY_REQUESTED, BootReason::OTA_FAILURE,
        BootReason::BOOT_FAILURE, BootReason::SAFE_MODE_REQUESTED, BootReason::KERNEL_PANIC,
        BootReason::WATCHDOG_RESET, BootReason::POWER_LOSS
    };

    for (auto reason : reasons) {
        ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL, reason), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.getBootReason(), reason);
        ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    }
}

// ============================================================
// Action queue tests
// ============================================================

void test_queue_action() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 1u);
}

void test_queue_not_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::NOT_IN_RECOVERY);
}

void test_queue_multiple() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::WIPE_CACHE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::RUN_DIAGNOSTICS), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 3u);
}

void test_queue_full() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(5, 10), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);

    for (int i = 0; i < 5; ++i) {
        ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    }
    ASSERT_EQ(mgr.getQueueSize(), 5u);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::WIPE_CACHE), RecoveryResult::QUEUE_FULL);
}

void test_cancel_action() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.cancelAction(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 0u);
}

void test_cancel_empty_queue() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.cancelAction(), RecoveryResult::NOT_FOUND);
}

void test_get_action_queue() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::WIPE_CACHE), RecoveryResult::SUCCESS);
    auto queue = mgr.getActionQueue();
    ASSERT_EQ(queue.size(), 2u);
    ASSERT_EQ(queue[0], RecoveryAction::VERIFY_SYSTEM);
    ASSERT_EQ(queue[1], RecoveryAction::WIPE_CACHE);
}

// ============================================================
// Action execution tests
// ============================================================

void test_execute_next_action() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 0u);
}

void test_execute_empty_queue() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::NOT_FOUND);
}

void test_execute_all_actions() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::WIPE_CACHE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeAllActions(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 0u);
}

void test_execute_not_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.executeAllActions(), RecoveryResult::NOT_IN_RECOVERY);
}

void test_fail_next_action() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    mgr.setFailNextAction(true);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::ACTION_FAILED);
    ASSERT_EQ(mgr.getQueueSize(), 0u);
}

void test_fail_next_reset() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    mgr.setFailNextAction(true);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::ACTION_FAILED);
    ASSERT_FALSE(mgr.getFailNextAction());
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::SUCCESS);
}

// ============================================================
// Individual recovery operation tests
// ============================================================

void test_verify_system() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::SUCCESS);
}

void test_apply_update() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::UPDATE_RECOVERY), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.applyUpdate(123), RecoveryResult::SUCCESS);
}

void test_rollback_update() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::UPDATE_RECOVERY), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.rollbackUpdate(456), RecoveryResult::SUCCESS);
}

void test_restore_backup() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::BACKUP_RESTORE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.restoreBackup(789), RecoveryResult::SUCCESS);
}

void test_wipe_cache() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.wipeCache(), RecoveryResult::SUCCESS);
}

void test_factory_reset() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::FACTORY_RESET), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.factoryReset(), RecoveryResult::SUCCESS);
}

void test_repair_filesystem() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.repairFilesystem(), RecoveryResult::SUCCESS);
}

void test_operations_not_initialized() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.applyUpdate(0), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.rollbackUpdate(0), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.restoreBackup(0), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.wipeCache(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.factoryReset(), RecoveryResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.repairFilesystem(), RecoveryResult::NOT_INITIALIZED);
}

void test_operations_not_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.applyUpdate(0), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.rollbackUpdate(0), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.restoreBackup(0), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.wipeCache(), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.factoryReset(), RecoveryResult::NOT_IN_RECOVERY);
    ASSERT_EQ(mgr.repairFilesystem(), RecoveryResult::NOT_IN_RECOVERY);
}

// ============================================================
// Diagnostics tests
// ============================================================

void test_run_diagnostics() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::DIAGNOSTIC), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.runDiagnostics(), RecoveryResult::SUCCESS);

    auto result = mgr.getDiagnosticResult();
    ASSERT_TRUE(result.totalChecks > 0);
    ASSERT_TRUE(result.passed > 0);
    ASSERT_EQ(result.overallStatus, DiagnosticStatus::PASSED);
}

void test_diagnostics_not_in_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.runDiagnostics(), RecoveryResult::NOT_IN_RECOVERY);
}

void test_diagnostic_checks() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::DIAGNOSTIC), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.runDiagnostics(), RecoveryResult::SUCCESS);

    auto checks = mgr.getDiagnosticChecks();
    ASSERT_TRUE(checks.size() >= 8);
    for (const auto& check : checks) {
        ASSERT_EQ(check.status, DiagnosticStatus::PASSED);
    }
}

// ============================================================
// Report and history tests
// ============================================================

void test_generate_report() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::SUCCESS);

    auto report = mgr.generateReport();
    ASSERT_EQ(report.mode, RecoveryMode::RECOVERY_SHELL);
    ASSERT_TRUE(report.success);
}

void test_get_history_empty() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 0u);
}

void test_get_history_after_exit() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 1u);
    ASSERT_TRUE(history[0].success);
    ASSERT_EQ(history[0].finalState, RecoveryState::COMPLETED);
}

void test_history_after_failure() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    mgr.setFailNextAction(true);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::ACTION_FAILED);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 1u);
    ASSERT_FALSE(history[0].success);
    ASSERT_EQ(history[0].finalState, RecoveryState::FAILED);
}

void test_clear_history() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 1u);

    ASSERT_EQ(mgr.clearHistory(), RecoveryResult::SUCCESS);
    history = mgr.getHistory();
    ASSERT_EQ(history.size(), 0u);
}

void test_history_max_size() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(20, 3), RecoveryResult::SUCCESS);

    for (int i = 0; i < 5; ++i) {
        ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    }

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 3u);
}

// ============================================================
// Query tests
// ============================================================

void test_count_by_mode() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::SAFE_MODE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.getCountByMode(RecoveryMode::RECOVERY_SHELL), 2u);
    ASSERT_EQ(mgr.getCountByMode(RecoveryMode::SAFE_MODE), 1u);
    ASSERT_EQ(mgr.getCountByMode(RecoveryMode::FACTORY_RESET), 0u);
}

void test_count_by_boot_reason() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL, BootReason::OTA_FAILURE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL, BootReason::KERNEL_PANIC), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.getCountByBootReason(BootReason::OTA_FAILURE), 1u);
    ASSERT_EQ(mgr.getCountByBootReason(BootReason::KERNEL_PANIC), 1u);
    ASSERT_EQ(mgr.getCountByBootReason(BootReason::NORMAL), 0u);
}

// ============================================================
// Callback tests
// ============================================================

void test_state_callback() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    RecoveryState oldState = RecoveryState::IDLE;
    RecoveryState newState = RecoveryState::IDLE;
    bool called = false;

    mgr.setStateCallback([&](RecoveryState old_s, RecoveryState new_s) {
        oldState = old_s;
        newState = new_s;
        called = true;
    });

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_TRUE(called);
    // State changes: IDLE -> ENTERING -> ACTIVE. The callback fires twice.
    // The last call should be ENTERING -> ACTIVE.
    ASSERT_EQ(oldState, RecoveryState::ENTERING);
    ASSERT_EQ(newState, RecoveryState::ACTIVE);
}

void test_action_callback() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);

    RecoveryAction calledAction;
    RecoveryResult calledResult;
    bool called = false;

    mgr.setActionCallback([&](RecoveryAction action, RecoveryResult result) {
        calledAction = action;
        calledResult = result;
        called = true;
    });

    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(called);
    ASSERT_EQ(calledAction, RecoveryAction::VERIFY_SYSTEM);
    ASSERT_EQ(calledResult, RecoveryResult::SUCCESS);
}

void test_progress_callback() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);

    bool called = false;
    mgr.setProgressCallback([&](const RecoveryProgress&) {
        called = true;
    });

    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(called);
}

void test_complete_callback() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    bool called = false;
    mgr.setCompleteCallback([&](const RecoveryReport&) {
        called = true;
    });

    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(called);
}

// ============================================================
// Stats tests
// ============================================================

void test_stats_initial() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSessions, 0u);
    ASSERT_EQ(stats.totalRecoveries, 0u);
    ASSERT_EQ(stats.totalFactoryResets, 0u);
    ASSERT_EQ(stats.totalSafeModeBoots, 0u);
    ASSERT_EQ(stats.totalDiagnosticsRun, 0u);
}

void test_stats_after_recovery() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSessions, 1u);
    ASSERT_EQ(stats.totalRecoveries, 1u);
    ASSERT_EQ(stats.totalSafeModeBoots, 0u);
}

void test_stats_after_safe_mode() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::SAFE_MODE), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSafeModeBoots, 1u);
}

void test_stats_after_diagnostics() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::DIAGNOSTIC), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.runDiagnostics(), RecoveryResult::SUCCESS);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalDiagnosticsRun, 1u);
    ASSERT_TRUE(stats.totalDiagnosticChecks >= 8);
}

void test_stats_reset() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);

    mgr.resetStats();
    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSessions, 0u);
    ASSERT_EQ(stats.totalRecoveries, 0u);
}

// ============================================================
// Integration tests
// ============================================================

void test_logserver_integration() {
    RecoveryManager mgr;
    LogServer logServer;
    ASSERT_EQ(logServer.initialize(1000), phantom::logging::LogResult::SUCCESS);

    mgr.setLogServer(&logServer);
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    logServer.shutdown();
}

void test_logserver_not_set() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    ASSERT_TRUE(mgr.getLogServer() == nullptr);
}

void test_crashreporter_integration() {
    RecoveryManager mgr;
    CrashReporter crashReporter;
    ASSERT_EQ(crashReporter.initialize(100), phantom::crashreporter::CrashResult::SUCCESS);

    mgr.setCrashReporter(&crashReporter);
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    mgr.setFailNextAction(true);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::ACTION_FAILED);
    crashReporter.shutdown();
}

void test_crashreporter_not_set() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    mgr.setFailNextAction(true);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::ACTION_FAILED);
    ASSERT_TRUE(mgr.getCrashReporter() == nullptr);
}

// ============================================================
// String helper tests
// ============================================================

void test_string_helpers_mode() {
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::NORMAL_BOOT), "NORMAL_BOOT");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::SAFE_MODE), "SAFE_MODE");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::RECOVERY_SHELL), "RECOVERY_SHELL");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::UPDATE_RECOVERY), "UPDATE_RECOVERY");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::BACKUP_RESTORE), "BACKUP_RESTORE");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::FACTORY_RESET), "FACTORY_RESET");
    ASSERT_STREQ(RecoveryManager::recoveryModeToString(RecoveryMode::DIAGNOSTIC), "DIAGNOSTIC");
}

void test_string_helpers_state() {
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::IDLE), "IDLE");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::ENTERING), "ENTERING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::SCANNING), "SCANNING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::REPAIRING), "REPAIRING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::RESTORING), "RESTORING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::APPLYING_UPDATE), "APPLYING_UPDATE");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::WIPING), "WIPING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::REBOOTING), "REBOOTING");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::FAILED), "FAILED");
    ASSERT_STREQ(RecoveryManager::recoveryStateToString(RecoveryState::COMPLETED), "COMPLETED");
}

void test_string_helpers_action() {
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::VERIFY_SYSTEM), "VERIFY_SYSTEM");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::APPLY_UPDATE), "APPLY_UPDATE");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::ROLLBACK_UPDATE), "ROLLBACK_UPDATE");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::RESTORE_BACKUP), "RESTORE_BACKUP");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::WIPE_CACHE), "WIPE_CACHE");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::FACTORY_RESET), "FACTORY_RESET");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::RUN_DIAGNOSTICS), "RUN_DIAGNOSTICS");
    ASSERT_STREQ(RecoveryManager::recoveryActionToString(RecoveryAction::REPAIR_FILESYSTEM), "REPAIR_FILESYSTEM");
}

void test_string_helpers_boot_reason() {
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::NORMAL), "NORMAL");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::RECOVERY_REQUESTED), "RECOVERY_REQUESTED");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::OTA_FAILURE), "OTA_FAILURE");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::BOOT_FAILURE), "BOOT_FAILURE");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::SAFE_MODE_REQUESTED), "SAFE_MODE_REQUESTED");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::KERNEL_PANIC), "KERNEL_PANIC");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::WATCHDOG_RESET), "WATCHDOG_RESET");
    ASSERT_STREQ(RecoveryManager::bootReasonToString(BootReason::POWER_LOSS), "POWER_LOSS");
}

void test_string_helpers_diagnostic_status() {
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::NOT_RUN), "NOT_RUN");
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::RUNNING), "RUNNING");
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::PASSED), "PASSED");
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::WARNINGS), "WARNINGS");
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::FAILED), "FAILED");
    ASSERT_STREQ(RecoveryManager::diagnosticStatusToString(DiagnosticStatus::SKIPPED), "SKIPPED");
}

void test_string_helpers_diagnostic_severity() {
    ASSERT_STREQ(RecoveryManager::diagnosticSeverityToString(DiagnosticSeverity::INFO), "INFO");
    ASSERT_STREQ(RecoveryManager::diagnosticSeverityToString(DiagnosticSeverity::WARNING), "WARNING");
    ASSERT_STREQ(RecoveryManager::diagnosticSeverityToString(DiagnosticSeverity::ERROR), "ERROR");
    ASSERT_STREQ(RecoveryManager::diagnosticSeverityToString(DiagnosticSeverity::CRITICAL), "CRITICAL");
}

void test_string_helpers_result() {
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::ALREADY_INITIALIZED), "ALREADY_INITIALIZED");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::INVALID_ACTION), "INVALID_ACTION");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::NOT_FOUND), "NOT_FOUND");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::BAD_STATE), "BAD_STATE");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::ACTION_FAILED), "ACTION_FAILED");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::QUEUE_FULL), "QUEUE_FULL");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::ALREADY_IN_RECOVERY), "ALREADY_IN_RECOVERY");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::NOT_IN_RECOVERY), "NOT_IN_RECOVERY");
    ASSERT_STREQ(RecoveryManager::recoveryResultToString(RecoveryResult::CANCELLED), "CANCELLED");
}

void test_string_to_recovery_mode() {
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("NORMAL_BOOT"), RecoveryMode::NORMAL_BOOT);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("SAFE_MODE"), RecoveryMode::SAFE_MODE);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("RECOVERY_SHELL"), RecoveryMode::RECOVERY_SHELL);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("UPDATE_RECOVERY"), RecoveryMode::UPDATE_RECOVERY);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("BACKUP_RESTORE"), RecoveryMode::BACKUP_RESTORE);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("FACTORY_RESET"), RecoveryMode::FACTORY_RESET);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("DIAGNOSTIC"), RecoveryMode::DIAGNOSTIC);
    ASSERT_EQ(RecoveryManager::stringToRecoveryMode("INVALID"), RecoveryMode::NORMAL_BOOT);
}

void test_string_to_recovery_action() {
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("VERIFY_SYSTEM"), RecoveryAction::VERIFY_SYSTEM);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("APPLY_UPDATE"), RecoveryAction::APPLY_UPDATE);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("ROLLBACK_UPDATE"), RecoveryAction::ROLLBACK_UPDATE);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("RESTORE_BACKUP"), RecoveryAction::RESTORE_BACKUP);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("WIPE_CACHE"), RecoveryAction::WIPE_CACHE);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("FACTORY_RESET"), RecoveryAction::FACTORY_RESET);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("RUN_DIAGNOSTICS"), RecoveryAction::RUN_DIAGNOSTICS);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("REPAIR_FILESYSTEM"), RecoveryAction::REPAIR_FILESYSTEM);
    ASSERT_EQ(RecoveryManager::stringToRecoveryAction("INVALID"), RecoveryAction::VERIFY_SYSTEM);
}

void test_string_to_boot_reason() {
    ASSERT_EQ(RecoveryManager::stringToBootReason("NORMAL"), BootReason::NORMAL);
    ASSERT_EQ(RecoveryManager::stringToBootReason("RECOVERY_REQUESTED"), BootReason::RECOVERY_REQUESTED);
    ASSERT_EQ(RecoveryManager::stringToBootReason("OTA_FAILURE"), BootReason::OTA_FAILURE);
    ASSERT_EQ(RecoveryManager::stringToBootReason("BOOT_FAILURE"), BootReason::BOOT_FAILURE);
    ASSERT_EQ(RecoveryManager::stringToBootReason("SAFE_MODE_REQUESTED"), BootReason::SAFE_MODE_REQUESTED);
    ASSERT_EQ(RecoveryManager::stringToBootReason("KERNEL_PANIC"), BootReason::KERNEL_PANIC);
    ASSERT_EQ(RecoveryManager::stringToBootReason("WATCHDOG_RESET"), BootReason::WATCHDOG_RESET);
    ASSERT_EQ(RecoveryManager::stringToBootReason("POWER_LOSS"), BootReason::POWER_LOSS);
    ASSERT_EQ(RecoveryManager::stringToBootReason("INVALID"), BootReason::NORMAL);
}

// ============================================================
// Full lifecycle test
// ============================================================

void test_full_lifecycle() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL, BootReason::BOOT_FAILURE), RecoveryResult::SUCCESS);
    ASSERT_TRUE(mgr.isInRecovery());

    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::RUN_DIAGNOSTICS), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::REPAIR_FILESYSTEM), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::WIPE_CACHE), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.executeAllActions(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.getQueueSize(), 0u);

    auto session = mgr.getCurrentSession();
    ASSERT_EQ(session.actionsExecuted, 4u);
    ASSERT_EQ(session.actionsSucceeded, 4u);
    ASSERT_EQ(session.actionsFailed, 0u);

    ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    ASSERT_FALSE(mgr.isInRecovery());

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 1u);
    ASSERT_TRUE(history[0].success);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSessions, 1u);
    ASSERT_EQ(stats.totalRepairs, 2u);  // verifySystem + repairFilesystem
    ASSERT_EQ(stats.totalDiagnosticsRun, 1u);
    ASSERT_EQ(stats.totalCacheWipes, 1u);
}

// ============================================================
// Shutdown clears all test
// ============================================================

void test_shutdown_clears_all() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);

    ASSERT_EQ(mgr.shutdown(), RecoveryResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_FALSE(mgr.isInRecovery());
    ASSERT_EQ(mgr.getQueueSize(), 0u);
    ASSERT_EQ(mgr.getHistory().size(), 0u);
}

// ============================================================
// Progress test
// ============================================================

void test_progress_tracking() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
    ASSERT_EQ(mgr.verifySystem(), RecoveryResult::SUCCESS);

    auto progress = mgr.getProgress();
    ASSERT_EQ(progress.currentAction, RecoveryAction::VERIFY_SYSTEM);
    ASSERT_EQ(progress.progressPercent, 100u);
}

// ============================================================
// Multiple sessions test
// ============================================================

void test_multiple_sessions() {
    RecoveryManager mgr;
    ASSERT_EQ(mgr.initialize(), RecoveryResult::SUCCESS);

    for (int i = 0; i < 5; ++i) {
        ASSERT_EQ(mgr.enterRecovery(RecoveryMode::RECOVERY_SHELL), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.queueAction(RecoveryAction::VERIFY_SYSTEM), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.executeNextAction(), RecoveryResult::SUCCESS);
        ASSERT_EQ(mgr.exitRecovery(), RecoveryResult::SUCCESS);
    }

    auto history = mgr.getHistory();
    ASSERT_EQ(history.size(), 5u);

    auto stats = mgr.getStats();
    ASSERT_EQ(stats.totalSessions, 5u);
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Recovery Manager Tests ===" << std::endl;

    // Lifecycle
    RUN_TEST(test_init);
    RUN_TEST(test_double_init);
    RUN_TEST(test_shutdown);
    RUN_TEST(test_reinit);
    RUN_TEST(test_not_initialized);

    // Session management
    RUN_TEST(test_enter_recovery);
    RUN_TEST(test_enter_already_in_recovery);
    RUN_TEST(test_exit_recovery);
    RUN_TEST(test_exit_not_in_recovery);
    RUN_TEST(test_enter_with_boot_reason);
    RUN_TEST(test_enter_factory_reset_mode);
    RUN_TEST(test_enter_all_modes);
    RUN_TEST(test_all_boot_reasons);

    // Action queue
    RUN_TEST(test_queue_action);
    RUN_TEST(test_queue_not_in_recovery);
    RUN_TEST(test_queue_multiple);
    RUN_TEST(test_queue_full);
    RUN_TEST(test_cancel_action);
    RUN_TEST(test_cancel_empty_queue);
    RUN_TEST(test_get_action_queue);

    // Action execution
    RUN_TEST(test_execute_next_action);
    RUN_TEST(test_execute_empty_queue);
    RUN_TEST(test_execute_all_actions);
    RUN_TEST(test_execute_not_in_recovery);
    RUN_TEST(test_fail_next_action);
    RUN_TEST(test_fail_next_reset);

    // Individual operations
    RUN_TEST(test_verify_system);
    RUN_TEST(test_apply_update);
    RUN_TEST(test_rollback_update);
    RUN_TEST(test_restore_backup);
    RUN_TEST(test_wipe_cache);
    RUN_TEST(test_factory_reset);
    RUN_TEST(test_repair_filesystem);
    RUN_TEST(test_operations_not_initialized);
    RUN_TEST(test_operations_not_in_recovery);

    // Diagnostics
    RUN_TEST(test_run_diagnostics);
    RUN_TEST(test_diagnostics_not_in_recovery);
    RUN_TEST(test_diagnostic_checks);

    // Reports and history
    RUN_TEST(test_generate_report);
    RUN_TEST(test_get_history_empty);
    RUN_TEST(test_get_history_after_exit);
    RUN_TEST(test_history_after_failure);
    RUN_TEST(test_clear_history);
    RUN_TEST(test_history_max_size);

    // Query
    RUN_TEST(test_count_by_mode);
    RUN_TEST(test_count_by_boot_reason);

    // Callbacks
    RUN_TEST(test_state_callback);
    RUN_TEST(test_action_callback);
    RUN_TEST(test_progress_callback);
    RUN_TEST(test_complete_callback);

    // Stats
    RUN_TEST(test_stats_initial);
    RUN_TEST(test_stats_after_recovery);
    RUN_TEST(test_stats_after_safe_mode);
    RUN_TEST(test_stats_after_diagnostics);
    RUN_TEST(test_stats_reset);

    // Integration
    RUN_TEST(test_logserver_integration);
    RUN_TEST(test_logserver_not_set);
    RUN_TEST(test_crashreporter_integration);
    RUN_TEST(test_crashreporter_not_set);

    // String helpers
    RUN_TEST(test_string_helpers_mode);
    RUN_TEST(test_string_helpers_state);
    RUN_TEST(test_string_helpers_action);
    RUN_TEST(test_string_helpers_boot_reason);
    RUN_TEST(test_string_helpers_diagnostic_status);
    RUN_TEST(test_string_helpers_diagnostic_severity);
    RUN_TEST(test_string_helpers_result);
    RUN_TEST(test_string_to_recovery_mode);
    RUN_TEST(test_string_to_recovery_action);
    RUN_TEST(test_string_to_boot_reason);

    // Full lifecycle
    RUN_TEST(test_full_lifecycle);
    RUN_TEST(test_shutdown_clears_all);
    RUN_TEST(test_progress_tracking);
    RUN_TEST(test_multiple_sessions);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run << " passed ===" << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
