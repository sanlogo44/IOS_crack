// Test: Telephony / Cellular Identity Manager
// v0.32.0 - License: GPL-3.0

#include "phantom/telephony/telephony_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <cstring>
#include <iostream>
#include <vector>

using namespace phantom;
using namespace phantom::telephony;

// ============================================================
// Test framework
// ============================================================

static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (cond) { g_tests_passed++; } \
    else { g_tests_failed++; \
        std::cout << "  [FAIL] " << #cond << " at " << __FILE__ << ":" << __LINE__ << std::endl; } \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))
#define ASSERT_EQ(a, b) ASSERT_TRUE((a) == (b))
#define ASSERT_STREQ(a, b) ASSERT_TRUE(std::string(a) == std::string(b))

// ============================================================
// Lifecycle tests
// ============================================================

void test_lifecycle() {
    TelephonyManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4, 100), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(0, 64, 4, 100), TelephonyResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 0, 4, 100), TelephonyResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 64, 0, 100), TelephonyResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 64, 4, 0), TelephonyResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(64, 64, 4, 100), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(64, 64, 4, 100), TelephonyResult::ALREADY_INITIALIZED);
    ASSERT_EQ(mgr.shutdown(), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.shutdown(), TelephonyResult::NOT_INITIALIZED);
}

// ============================================================
// SIM / Subscription tests
// ============================================================

void test_sim_default_state() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    auto sims = mgr.getAllSimInfo();
    ASSERT_EQ(sims.size(), static_cast<size_t>(2));
    ASSERT_EQ(sims[0].state, SimState::READY);
    ASSERT_EQ(sims[1].state, SimState::ABSENT);
    ASSERT_TRUE(mgr.isSimReady());
    ASSERT_TRUE(mgr.isDataEnabled());

    auto subs = mgr.getActiveSubscriptions();
    ASSERT_EQ(subs.size(), static_cast<size_t>(1));
    ASSERT_STREQ(subs[0].carrierName.c_str(), "PhantomMobile");

    mgr.shutdown();
}

void test_sim_state_change() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    ASSERT_EQ(mgr.setSimState(0, SimState::PIN_LOCKED, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSimInfo(0).state, SimState::PIN_LOCKED);
    ASSERT_FALSE(mgr.isSimReady());

    ASSERT_EQ(mgr.setSimState(1, SimState::READY, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSimInfo(1).state, SimState::READY);

    // Non-system denied
    ASSERT_EQ(mgr.setSimState(0, SimState::READY, "app"), TelephonyResult::PERMISSION_DENIED);

    // Invalid slot
    ASSERT_EQ(mgr.setSimState(5, SimState::READY, "system"), TelephonyResult::INVALID_PARAMETER);

    mgr.shutdown();
}

void test_sim_failure() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setSimState(0, SimState::PIN_LOCKED, "system"),
              TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

void test_subscription() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    SubscriptionInfo sub;
    sub.subscriptionId = 2;
    sub.slotIndex = 1;
    sub.carrierName = "TestCarrier";
    sub.mcc = "310";
    sub.mnc = "26";
    sub.displayName = "TestCarrier";
    sub.mobileData = true;

    ASSERT_EQ(mgr.setSubscription(sub, "system"), TelephonyResult::SUCCESS);
    auto result = mgr.getSubscription(2);
    ASSERT_STREQ(result.carrierName.c_str(), "TestCarrier");

    // Non-system denied
    ASSERT_EQ(mgr.setSubscription(sub, "app"), TelephonyResult::PERMISSION_DENIED);

    // Invalid slot
    sub.slotIndex = 5;
    ASSERT_EQ(mgr.setSubscription(sub, "system"), TelephonyResult::INVALID_PARAMETER);

    mgr.shutdown();
}

// ============================================================
// Network registration tests
// ============================================================

void test_network_registration() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    ASSERT_EQ(mgr.getNetworkRegistration(), NetworkRegistrationState::HOME);
    ASSERT_TRUE(mgr.isRegistered());

    ASSERT_EQ(mgr.setNetworkRegistration(NetworkRegistrationState::ROAMING, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getNetworkRegistration(), NetworkRegistrationState::ROAMING);

    ASSERT_EQ(mgr.setNetworkRegistration(NetworkRegistrationState::NOT_REGISTERED, "system"), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.isRegistered());

    // Non-system denied
    ASSERT_EQ(mgr.setNetworkRegistration(NetworkRegistrationState::HOME, "app"), TelephonyResult::PERMISSION_DENIED);

    mgr.shutdown();
}

void test_data_connection() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    ASSERT_EQ(mgr.getDataConnection(), DataConnectionState::CONNECTED);

    ASSERT_EQ(mgr.setDataConnection(DataConnectionState::DISCONNECTED, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getDataConnection(), DataConnectionState::DISCONNECTED);

    ASSERT_EQ(mgr.setDataConnection(DataConnectionState::CONNECTED, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getDataConnection(), DataConnectionState::CONNECTED);
    ASSERT_TRUE(mgr.getStats().dataConnections >= 2);

    // Non-system denied
    ASSERT_EQ(mgr.setDataConnection(DataConnectionState::DISCONNECTED, "app"), TelephonyResult::PERMISSION_DENIED);

    mgr.shutdown();
}

void test_network_failure() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setNetworkRegistration(NetworkRegistrationState::ROAMING, "system"),
              TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Cell info / signal tests
// ============================================================

void test_cell_info() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    auto cell = mgr.getCellIdentity();
    ASSERT_EQ(cell.radioTech, TelephonyRadioTech::LTE);
    ASSERT_TRUE(cell.mcc > 0);

    CellIdentity newCell;
    newCell.radioTech = TelephonyRadioTech::NR;
    newCell.mcc = 262;
    newCell.mnc = 42;
    newCell.tac = 9999;
    newCell.ci = 88888;
    newCell.pci = 200;

    ASSERT_EQ(mgr.setCellIdentity(newCell, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getRadioTech(), TelephonyRadioTech::NR);
    ASSERT_EQ(mgr.getCellIdentity().ci, static_cast<uint32_t>(88888));

    CellSignal newSignal;
    newSignal.signalStrength = -70;
    newSignal.level = 4;
    newSignal.rsrp = 80;
    newSignal.rsrq = 15;
    newSignal.rssi = 70;
    newSignal.snr = 20;

    ASSERT_EQ(mgr.setCellSignal(newSignal, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getCellSignal().level, static_cast<uint32_t>(4));

    // Non-system denied
    ASSERT_EQ(mgr.setCellIdentity(newCell, "app"), TelephonyResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Permission / policy tests
// ============================================================

void test_permission_deny() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    auto policy = mgr.getAppTelephonyPolicy("app.test");
    ASSERT_EQ(policy.permission, TelephonyPermission::DENY);
    ASSERT_FALSE(mgr.checkAppAccess("app.test"));
    mgr.shutdown();
}

void test_permission_allow_foreground() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_EQ(mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_FOREGROUND,
                                          TelephonyPrivacyMode::FULL), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test"));
    ASSERT_EQ(mgr.setAppForeground("app.test", true), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test"));
    ASSERT_EQ(mgr.setAppForeground("app.test", false), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test"));
    mgr.shutdown();
}

void test_permission_allow_always() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_EQ(mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                          TelephonyPrivacyMode::FULL), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test"));
    mgr.shutdown();
}

void test_permission_allow_once() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_EQ(mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ONCE,
                                          TelephonyPrivacyMode::FULL), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.checkAppAccess("app.test"));

    SimInfo info;
    ASSERT_EQ(mgr.getSimIdentifiers("app.test", info), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.checkAppAccess("app.test"));
    mgr.shutdown();
}

void test_permission_system_access() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_TRUE(mgr.checkAppAccess("system"));
    ASSERT_TRUE(mgr.checkAppAccess("android"));
    ASSERT_TRUE(mgr.checkAppAccess("com.android.system"));
    mgr.shutdown();
}

void test_clear_app_policy() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_EQ(mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                          TelephonyPrivacyMode::FULL), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.clearAppTelephonyPolicy("app.test", "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getAppTelephonyPolicy("app.test").permission, TelephonyPermission::DENY);
    mgr.shutdown();
}

void test_policy_failure() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                          TelephonyPrivacyMode::FULL), TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// Call stub tests
// ============================================================

void test_call_start_end() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId), TelephonyResult::SUCCESS);
    ASSERT_TRUE(callId > 0);
    ASSERT_EQ(mgr.getActiveCallCount(), static_cast<size_t>(1));
    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());

    ASSERT_EQ(mgr.setCallState(callId, CallState::ACTIVE, "app.test"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.endCall(callId, "app.test"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getActiveCallCount(), static_cast<size_t>(0));
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    mgr.shutdown();
}

void test_call_incoming() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", true, &callId), TelephonyResult::SUCCESS);
    auto calls = mgr.getActiveCalls();
    ASSERT_EQ(calls.size(), static_cast<size_t>(1));
    ASSERT_TRUE(calls[0].incoming);
    ASSERT_EQ(calls[0].state, CallState::RINGING);
    mgr.shutdown();
}

void test_call_permission_denied() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId),
              TelephonyResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_call_capacity() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 2, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t c1 = 0, c2 = 0, c3 = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49111", false, &c1), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.startCall("app.test", "+49222", false, &c2), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.startCall("app.test", "+49333", false, &c3),
              TelephonyResult::CAPACITY_EXCEEDED);
    mgr.shutdown();
}

void test_call_bad_state() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.endCall(callId, "app.test"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.endCall(callId, "app.test"), TelephonyResult::BAD_STATE);
    mgr.shutdown();
}

void test_call_owner_check() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.endCall(callId, "other.app"), TelephonyResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.endCall(callId, "app.test"), TelephonyResult::SUCCESS);
    mgr.shutdown();
}

void test_call_failure() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);
    mgr.setFailNextOperation(true);
    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId),
              TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// SMS stub tests
// ============================================================

void test_sms_receive() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    ASSERT_EQ(mgr.receiveSms("app.test", "+49123456789", "Hello"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSmsCount(), static_cast<size_t>(1));
    ASSERT_EQ(mgr.getStats().smsReceived, static_cast<uint64_t>(1));

    auto history = mgr.getSmsHistory("app.test");
    ASSERT_EQ(history.size(), static_cast<size_t>(1));
    mgr.shutdown();
}

void test_sms_send() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    ASSERT_EQ(mgr.sendSms("app.test", "+49123456789", "Reply"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSmsCount(), static_cast<size_t>(1));
    ASSERT_EQ(mgr.getStats().smsSent, static_cast<uint64_t>(1));
    mgr.shutdown();
}

void test_sms_permission_denied() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_EQ(mgr.receiveSms("app.test", "+49123456789", "Hello"),
              TelephonyResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.sendSms("app.test", "+49123456789", "Reply"),
              TelephonyResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_sms_capacity() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 3);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    ASSERT_EQ(mgr.receiveSms("app.test", "+49111", "Msg1"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.receiveSms("app.test", "+49222", "Msg2"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.receiveSms("app.test", "+49333", "Msg3"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.receiveSms("app.test", "+49444", "Msg4"),
              TelephonyResult::CAPACITY_EXCEEDED);
    mgr.shutdown();
}

// ============================================================
// Identifier access tests
// ============================================================

void test_get_sim_identifiers() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    SimInfo info;
    ASSERT_EQ(mgr.getSimIdentifiers("app.test", info), TelephonyResult::SUCCESS);
    ASSERT_TRUE(!info.imsi.empty());
    ASSERT_TRUE(!info.msisdn.empty());
    mgr.shutdown();
}

void test_get_sim_identifiers_permission_denied() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    SimInfo info;
    ASSERT_EQ(mgr.getSimIdentifiers("app.test", info), TelephonyResult::PERMISSION_DENIED);
    mgr.shutdown();
}

void test_get_cell_info() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    CellIdentity cell;
    ASSERT_EQ(mgr.getCellInfo("app.test", cell), TelephonyResult::SUCCESS);
    ASSERT_EQ(cell.radioTech, TelephonyRadioTech::LTE);
    mgr.shutdown();
}

void test_get_cell_signal() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    CellSignal signal;
    ASSERT_EQ(mgr.getCellSignal("app.test", signal), TelephonyResult::SUCCESS);
    ASSERT_TRUE(signal.level > 0);
    mgr.shutdown();
}

// ============================================================
// Privacy transform tests
// ============================================================

void test_privacy_transform_full() {
    SimInfo sim;
    sim.imsi = "262420000000001";
    sim.msisdn = "+4915112345678";
    sim.iccid = "8949010000000000001";

    auto result = TelephonyManager::applyPrivacyTransform(sim, TelephonyPrivacyMode::FULL,
                                                            TELEPHONY_PRIVACY_NONE);
    ASSERT_STREQ(result.imsi.c_str(), "262420000000001");
    ASSERT_STREQ(result.msisdn.c_str(), "+4915112345678");
}

void test_privacy_transform_redacted() {
    SimInfo sim;
    sim.imsi = "262420000000001";
    sim.msisdn = "+4915112345678";
    sim.iccid = "8949010000000000001";

    auto result = TelephonyManager::applyPrivacyTransform(sim, TelephonyPrivacyMode::REDACTED,
                                                            TELEPHONY_PRIVACY_NONE);
    ASSERT_TRUE(result.imsi.empty());
    ASSERT_TRUE(result.msisdn.empty());
    ASSERT_TRUE(result.iccid.empty());
}

void test_privacy_transform_metadata_only() {
    SimInfo sim;
    sim.imsi = "262420000000001";
    sim.msisdn = "+4915112345678";
    sim.iccid = "8949010000000000001";
    sim.carrierName = "PhantomMobile";

    auto result = TelephonyManager::applyPrivacyTransform(sim, TelephonyPrivacyMode::METADATA_ONLY,
                                                            TELEPHONY_PRIVACY_NONE);
    ASSERT_TRUE(result.imsi.empty());
    ASSERT_TRUE(result.msisdn.empty());
    ASSERT_TRUE(result.iccid.empty());
    ASSERT_STREQ(result.carrierName.c_str(), "PhantomMobile");
}

void test_privacy_transform_pseudonymize() {
    SimInfo sim;
    sim.imsi = "262420000000001";
    sim.msisdn = "+4915112345678";
    sim.iccid = "8949010000000000001";

    auto result = TelephonyManager::applyPrivacyTransform(sim, TelephonyPrivacyMode::FULL,
                                                            TELEPHONY_PRIVACY_PSEUDONYMIZE,
                                                            "app-pseudonym");
    ASSERT_TRUE(result.imsi.find("pseudonym") != std::string::npos);
    ASSERT_TRUE(result.msisdn.find("pseudonym") != std::string::npos);
}

void test_privacy_transform_coarse_cell() {
    CellIdentity cell;
    cell.mcc = 262;
    cell.mnc = 42;
    cell.tac = 1234;
    cell.ci = 56789;
    cell.pci = 100;
    cell.lac = 999;
    cell.cid = 888;

    auto result = TelephonyManager::applyCellPrivacyTransform(cell, TelephonyPrivacyMode::FULL,
                                                                 TELEPHONY_PRIVACY_COARSE_CELL);
    ASSERT_EQ(result.ci, static_cast<uint32_t>(0));
    ASSERT_EQ(result.pci, static_cast<uint32_t>(0));
    ASSERT_EQ(result.tac, static_cast<uint32_t>(0));
    ASSERT_EQ(result.mcc, static_cast<uint32_t>(262));  // MCC kept
}

void test_privacy_transform_cell_metadata_only() {
    CellIdentity cell;
    cell.mcc = 262;
    cell.mnc = 42;
    cell.tac = 1234;
    cell.ci = 56789;

    auto result = TelephonyManager::applyCellPrivacyTransform(cell, TelephonyPrivacyMode::METADATA_ONLY,
                                                                 TELEPHONY_PRIVACY_NONE);
    ASSERT_EQ(result.mcc, static_cast<uint32_t>(0));
    ASSERT_EQ(result.mnc, static_cast<uint32_t>(0));
    ASSERT_EQ(result.ci, static_cast<uint32_t>(0));
}

void test_privacy_transform_disable_roaming() {
    SimInfo sim;
    sim.roaming = true;

    auto result = TelephonyManager::applyPrivacyTransform(sim, TelephonyPrivacyMode::FULL,
                                                            TELEPHONY_PRIVACY_DISABLE_ROAMING);
    ASSERT_FALSE(result.roaming);
}

// ============================================================
// History tests
// ============================================================

void test_history() {
    TelephonyManager mgr;
    mgr.initialize(128, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");

    auto history = mgr.getHistory("app.test");
    ASSERT_TRUE(history.size() >= 1);
    mgr.shutdown();
}

void test_history_clear() {
    TelephonyManager mgr;
    mgr.initialize(128, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");
    ASSERT_TRUE(mgr.getHistoryCount() > 0);
    ASSERT_EQ(mgr.clearHistory("system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_history_no_history_flag() {
    TelephonyManager mgr;
    mgr.initialize(128, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL,
                                TELEPHONY_PRIVACY_NO_HISTORY);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

// ============================================================
// Mock tests
// ============================================================

void test_mock_enabled() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    ASSERT_FALSE(mgr.isMockEnabled());
    ASSERT_EQ(mgr.setMockEnabled(true, "system"), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.isMockEnabled());
    mgr.shutdown();
}

void test_mock_sim() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    SimInfo mockSim;
    mockSim.slotIndex = 0;
    mockSim.state = SimState::READY;
    mockSim.carrierName = "MockCarrier";
    mockSim.mcc = "999";
    mockSim.mnc = "99";
    mockSim.imsi = "999990000000001";
    mockSim.msisdn = "+0000000000";

    ASSERT_EQ(mgr.setMockSim(mockSim, "system"), TelephonyResult::SUCCESS);
    auto result = mgr.getSimInfo(0);
    ASSERT_STREQ(result.carrierName.c_str(), "MockCarrier");
    mgr.shutdown();
}

void test_mock_cell() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    CellIdentity mockCell;
    mockCell.radioTech = TelephonyRadioTech::NR;
    mockCell.mcc = 999;
    mockCell.mnc = 99;
    mockCell.ci = 12345;

    CellSignal mockSignal;
    mockSignal.level = 5;
    mockSignal.signalStrength = -60;

    ASSERT_EQ(mgr.setMockCell(mockCell, mockSignal, "system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getRadioTech(), TelephonyRadioTech::NR);
    ASSERT_EQ(mgr.getCellSignal().level, static_cast<uint32_t>(5));
    mgr.shutdown();
}

void test_mock_sim_not_allowed() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    SimInfo mockSim;
    mockSim.slotIndex = 0;
    ASSERT_EQ(mgr.setMockSim(mockSim, "app"), TelephonyResult::MOCK_NOT_ALLOWED);
    mgr.shutdown();
}

// ============================================================
// Privacy indicator tests
// ============================================================

void test_privacy_indicator() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    ASSERT_TRUE(mgr.getActiveTelephonyUsers().empty());

    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());
    ASSERT_EQ(mgr.getActiveTelephonyUsers().size(), static_cast<size_t>(1));

    ASSERT_EQ(mgr.endCall(callId, "app.test"), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());
    mgr.shutdown();
}

// ============================================================
// Events tests
// ============================================================

void test_events() {
    TelephonyManager mgr;
    mgr.initialize(64, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 2);

    auto byType = mgr.getEventsByType(TelephonyEventType::CALL_OUTGOING);
    ASSERT_TRUE(byType.size() >= 1);

    ASSERT_EQ(mgr.clearEvents(), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), static_cast<size_t>(0));
    mgr.shutdown();
}

void test_events_capacity() {
    TelephonyManager mgr;
    mgr.initialize(64, 5, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    for (int i = 0; i < 10; ++i) {
        uint64_t callId = 0;
        mgr.startCall("app.test", "+49111" + std::to_string(i), false, &callId);
        mgr.endCall(callId, "app.test");
    }
    ASSERT_TRUE(mgr.getEventCount() <= 5);
    mgr.shutdown();
}

// ============================================================
// Stats tests
// ============================================================

void test_stats() {
    TelephonyManager mgr;
    mgr.initialize(64, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");
    mgr.receiveSms("app.test", "+49111", "Hello");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.callsStarted >= 1);
    ASSERT_TRUE(stats.callsEnded >= 1);
    ASSERT_TRUE(stats.smsReceived >= 1);
    mgr.shutdown();
}

void test_stats_reset() {
    TelephonyManager mgr;
    mgr.initialize(64, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    mgr.endCall(callId, "app.test");

    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.callsStarted > 0);

    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.callsStarted, static_cast<uint64_t>(0));
    mgr.shutdown();
}

// ============================================================
// Callbacks tests
// ============================================================

void test_event_callback() {
    TelephonyManager mgr;
    mgr.initialize(64, 256, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);

    TelephonyEventType receivedType = TelephonyEventType::SIM_STATE_CHANGED;
    mgr.setEventCallback([&](const TelephonyEvent& event) {
        receivedType = event.type;
    });

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    ASSERT_EQ(receivedType, TelephonyEventType::CALL_OUTGOING);
    mgr.shutdown();
}

void test_access_callback() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);

    std::string receivedApp;
    TelephonyResult receivedResult = TelephonyResult::SUCCESS;
    mgr.setAccessCallback([&](const std::string& appId, TelephonyResult result) {
        receivedApp = appId;
        receivedResult = result;
    });

    uint64_t callId = 0;
    mgr.startCall("app.test", "+49123456789", false, &callId);
    ASSERT_EQ(receivedApp, "app.test");
    ASSERT_EQ(receivedResult, TelephonyResult::PERMISSION_DENIED);
    mgr.shutdown();
}

// ============================================================
// Failure simulation tests
// ============================================================

void test_failure_start_call() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);
    mgr.setFailNextOperation(true);
    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("app.test", "+49123456789", false, &callId),
              TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

void test_failure_receive_sms() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.receiveSms("app.test", "+49111", "Hello"),
              TelephonyResult::SIMULATED_FAILURE);
    mgr.shutdown();
}

// ============================================================
// LogServer / CrashReporter integration tests
// ============================================================

void test_logserver_integration() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    logging::LogServer logServer;
    logServer.initialize(256);
    mgr.setLogServer(&logServer);

    mgr.setAppTelephonyPolicy("app.test", TelephonyPermission::ALLOW_ALWAYS,
                                TelephonyPrivacyMode::FULL);
    ASSERT_TRUE(logServer.getLogCount() > 0);

    // Verify no raw identifiers, phone numbers, or SMS bodies are logged
    auto logs = logServer.getLogs();
    bool foundRawData = false;
    for (const auto& entry : logs) {
        if (entry.message.find("imsi") != std::string::npos ||
            entry.message.find("msisdn") != std::string::npos ||
            entry.message.find("iccid") != std::string::npos ||
            entry.message.find("+49") != std::string::npos ||
            entry.message.find("body") != std::string::npos) {
            foundRawData = true;
        }
    }
    ASSERT_FALSE(foundRawData);
    mgr.shutdown();
}

void test_crashreporter_integration() {
    TelephonyManager mgr;
    mgr.initialize(64, 64, 4, 100);
    crashreporter::CrashReporter reporter;
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    mgr.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

void test_string_helpers() {
    ASSERT_STREQ(TelephonyManager::radioTechToString(TelephonyRadioTech::LTE), "LTE");
    ASSERT_STREQ(TelephonyManager::radioTechToString(TelephonyRadioTech::NR), "NR");
    ASSERT_STREQ(TelephonyManager::radioTechToString(TelephonyRadioTech::GPRS), "GPRS");

    ASSERT_STREQ(TelephonyManager::simStateToString(SimState::READY), "READY");
    ASSERT_STREQ(TelephonyManager::simStateToString(SimState::ABSENT), "ABSENT");
    ASSERT_STREQ(TelephonyManager::simStateToString(SimState::PIN_LOCKED), "PIN_LOCKED");

    ASSERT_STREQ(TelephonyManager::networkRegToString(NetworkRegistrationState::HOME), "HOME");
    ASSERT_STREQ(TelephonyManager::networkRegToString(NetworkRegistrationState::ROAMING), "ROAMING");

    ASSERT_STREQ(TelephonyManager::dataConnToString(DataConnectionState::CONNECTED), "CONNECTED");
    ASSERT_STREQ(TelephonyManager::dataConnToString(DataConnectionState::DISCONNECTED), "DISCONNECTED");

    ASSERT_STREQ(TelephonyManager::callStateToString(CallState::RINGING), "RINGING");
    ASSERT_STREQ(TelephonyManager::callStateToString(CallState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(TelephonyManager::callStateToString(CallState::DISCONNECTED), "DISCONNECTED");

    ASSERT_STREQ(TelephonyManager::smsStateToString(SmsState::RECEIVED), "RECEIVED");
    ASSERT_STREQ(TelephonyManager::smsStateToString(SmsState::SENT), "SENT");

    ASSERT_STREQ(TelephonyManager::permissionToString(TelephonyPermission::DENY), "DENY");
    ASSERT_STREQ(TelephonyManager::permissionToString(TelephonyPermission::ALLOW_FOREGROUND), "ALLOW_FOREGROUND");
    ASSERT_STREQ(TelephonyManager::permissionToString(TelephonyPermission::ALLOW_ALWAYS), "ALLOW_ALWAYS");
    ASSERT_STREQ(TelephonyManager::permissionToString(TelephonyPermission::ALLOW_ONCE), "ALLOW_ONCE");

    ASSERT_STREQ(TelephonyManager::privacyModeToString(TelephonyPrivacyMode::FULL), "FULL");
    ASSERT_STREQ(TelephonyManager::privacyModeToString(TelephonyPrivacyMode::REDACTED), "REDACTED");
    ASSERT_STREQ(TelephonyManager::privacyModeToString(TelephonyPrivacyMode::METADATA_ONLY), "METADATA_ONLY");

    ASSERT_STREQ(TelephonyManager::resultToString(TelephonyResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(TelephonyManager::resultToString(TelephonyResult::PERMISSION_DENIED), "PERMISSION_DENIED");
    ASSERT_STREQ(TelephonyManager::resultToString(TelephonyResult::SIM_NOT_READY), "SIM_NOT_READY");

    ASSERT_STREQ(TelephonyManager::eventTypeToString(TelephonyEventType::SIM_STATE_CHANGED), "SIM_STATE_CHANGED");
    ASSERT_STREQ(TelephonyManager::eventTypeToString(TelephonyEventType::CALL_INCOMING), "CALL_INCOMING");
    ASSERT_STREQ(TelephonyManager::eventTypeToString(TelephonyEventType::SMS_RECEIVED), "SMS_RECEIVED");
    ASSERT_STREQ(TelephonyManager::eventTypeToString(TelephonyEventType::CELL_INFO_UPDATED), "CELL_INFO_UPDATED");

    ASSERT_EQ(TelephonyManager::stringToRadioTech("LTE"), TelephonyRadioTech::LTE);
    ASSERT_EQ(TelephonyManager::stringToRadioTech("NR"), TelephonyRadioTech::NR);
    ASSERT_EQ(TelephonyManager::stringToRadioTech("GPRS"), TelephonyRadioTech::GPRS);

    ASSERT_EQ(TelephonyManager::stringToResult("SUCCESS"), TelephonyResult::SUCCESS);
    ASSERT_EQ(TelephonyManager::stringToResult("PERMISSION_DENIED"), TelephonyResult::PERMISSION_DENIED);
}

// ============================================================
// Full workflow test
// ============================================================

void test_full_workflow() {
    TelephonyManager mgr;
    mgr.initialize(256, 256, 4, 100);

    // 1. Verify default SIM state
    ASSERT_TRUE(mgr.isSimReady());
    ASSERT_TRUE(mgr.isRegistered());

    // 2. Setup app policy
    ASSERT_EQ(mgr.setAppTelephonyPolicy("com.test.app", TelephonyPermission::ALLOW_FOREGROUND,
                                          TelephonyPrivacyMode::REDACTED,
                                          TELEPHONY_PRIVACY_REQUIRE_FOREGROUND), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.setAppForeground("com.test.app", true), TelephonyResult::SUCCESS);

    // 3. Get SIM identifiers (should be redacted)
    SimInfo info;
    ASSERT_EQ(mgr.getSimIdentifiers("com.test.app", info), TelephonyResult::SUCCESS);
    ASSERT_TRUE(info.imsi.empty());  // Redacted
    ASSERT_STREQ(info.carrierName.c_str(), "PhantomMobile");  // Carrier kept

    // 4. Get cell info
    CellIdentity cell;
    ASSERT_EQ(mgr.getCellInfo("com.test.app", cell), TelephonyResult::SUCCESS);
    ASSERT_EQ(cell.radioTech, TelephonyRadioTech::LTE);

    // 5. Start a call
    uint64_t callId = 0;
    ASSERT_EQ(mgr.startCall("com.test.app", "+49123456789", false, &callId), TelephonyResult::SUCCESS);
    ASSERT_TRUE(mgr.isPrivacyIndicatorOn());

    // 6. Set call active
    ASSERT_EQ(mgr.setCallState(callId, CallState::ACTIVE, "com.test.app"), TelephonyResult::SUCCESS);

    // 7. End call
    ASSERT_EQ(mgr.endCall(callId, "com.test.app"), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.isPrivacyIndicatorOn());

    // 8. Send SMS
    ASSERT_EQ(mgr.sendSms("com.test.app", "+49111", "Test message"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSmsCount(), static_cast<size_t>(1));

    // 9. Receive SMS
    ASSERT_EQ(mgr.receiveSms("com.test.app", "+49222", "Reply"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getSmsCount(), static_cast<size_t>(2));

    // 10. Check history
    auto history = mgr.getHistory("com.test.app");
    ASSERT_TRUE(history.size() >= 3);

    // 11. Check events
    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 3);

    // 12. Check stats
    auto stats = mgr.getStats();
    ASSERT_TRUE(stats.callsStarted >= 1);
    ASSERT_TRUE(stats.smsSent >= 1);
    ASSERT_TRUE(stats.smsReceived >= 1);
    ASSERT_TRUE(stats.privacyApplications >= 1);

    // 13. System access
    ASSERT_TRUE(mgr.checkAppAccess("system"));

    // 14. Clear history
    ASSERT_EQ(mgr.clearHistory("system"), TelephonyResult::SUCCESS);
    ASSERT_EQ(mgr.getHistoryCount(), static_cast<size_t>(0));

    // 15. Reset stats
    mgr.resetStats();
    auto stats2 = mgr.getStats();
    ASSERT_EQ(stats2.callsStarted, static_cast<uint64_t>(0));

    // 16. Shutdown
    ASSERT_EQ(mgr.shutdown(), TelephonyResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Telephony Manager Tests ===" << std::endl;

    // Lifecycle
    std::cout << "Testing lifecycle..." << std::endl;
    test_lifecycle();

    // SIM / Subscription
    std::cout << "Testing SIM/Subscription..." << std::endl;
    test_sim_default_state();
    test_sim_state_change();
    test_sim_failure();
    test_subscription();

    // Network registration
    std::cout << "Testing network registration..." << std::endl;
    test_network_registration();
    test_data_connection();
    test_network_failure();

    // Cell info / signal
    std::cout << "Testing cell info/signal..." << std::endl;
    test_cell_info();

    // Permission / policy
    std::cout << "Testing permission/policy..." << std::endl;
    test_permission_deny();
    test_permission_allow_foreground();
    test_permission_allow_always();
    test_permission_allow_once();
    test_permission_system_access();
    test_clear_app_policy();
    test_policy_failure();

    // Call stubs
    std::cout << "Testing call stubs..." << std::endl;
    test_call_start_end();
    test_call_incoming();
    test_call_permission_denied();
    test_call_capacity();
    test_call_bad_state();
    test_call_owner_check();
    test_call_failure();

    // SMS stubs
    std::cout << "Testing SMS stubs..." << std::endl;
    test_sms_receive();
    test_sms_send();
    test_sms_permission_denied();
    test_sms_capacity();

    // Identifier access
    std::cout << "Testing identifier access..." << std::endl;
    test_get_sim_identifiers();
    test_get_sim_identifiers_permission_denied();
    test_get_cell_info();
    test_get_cell_signal();

    // Privacy transform
    std::cout << "Testing privacy transform..." << std::endl;
    test_privacy_transform_full();
    test_privacy_transform_redacted();
    test_privacy_transform_metadata_only();
    test_privacy_transform_pseudonymize();
    test_privacy_transform_coarse_cell();
    test_privacy_transform_cell_metadata_only();
    test_privacy_transform_disable_roaming();

    // History
    std::cout << "Testing history..." << std::endl;
    test_history();
    test_history_clear();
    test_history_no_history_flag();

    // Mock
    std::cout << "Testing mock..." << std::endl;
    test_mock_enabled();
    test_mock_sim();
    test_mock_cell();
    test_mock_sim_not_allowed();

    // Privacy indicator
    std::cout << "Testing privacy indicator..." << std::endl;
    test_privacy_indicator();

    // Events
    std::cout << "Testing events..." << std::endl;
    test_events();
    test_events_capacity();

    // Stats
    std::cout << "Testing stats..." << std::endl;
    test_stats();
    test_stats_reset();

    // Callbacks
    std::cout << "Testing callbacks..." << std::endl;
    test_event_callback();
    test_access_callback();

    // Failure simulation
    std::cout << "Testing failure simulation..." << std::endl;
    test_failure_start_call();
    test_failure_receive_sms();

    // LogServer / CrashReporter
    std::cout << "Testing LogServer/CrashReporter integration..." << std::endl;
    test_logserver_integration();
    test_crashreporter_integration();

    // String helpers
    std::cout << "Testing string helpers..." << std::endl;
    test_string_helpers();

    // Full workflow
    std::cout << "Testing full workflow..." << std::endl;
    test_full_workflow();

    std::cout << std::endl;
    std::cout << "=== Results ===" << std::endl;
    std::cout << "Total: " << g_tests_run << ", Passed: " << g_tests_passed
              << ", Failed: " << g_tests_failed << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
