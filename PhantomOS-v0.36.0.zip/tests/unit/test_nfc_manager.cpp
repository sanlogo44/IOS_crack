/*
 * Phantom OS - NFC Manager Tests
 * v0.35.0 - License: GPL-3.0
 *
 * Tests all functions of the NfcManager.
 * Mock implementation is used (no real NFC hardware).
 */

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include "phantom/nfc/nfc_manager.h"

using namespace phantom::nfc;
using phantom::nfc::NfcManager;

static int g_testsPassed = 0;
static int g_testsFailed = 0;

static void test(const std::string& name, bool condition) {
    std::cout << "  " << (condition ? "[PASS]" : "[FAIL]") << " " << name << "\n";
    if (condition) g_testsPassed++;
    else g_testsFailed++;
}

static void testLifecycle() {
    std::cout << "\n  [Lifecycle]\n";
    NfcManager mgr;
    test("not initialized initially", !mgr.isInitialized());
    test("initialize SUCCESS", mgr.initialize() == NfcResult::SUCCESS);
    test("already initialized", mgr.initialize() == NfcResult::ALREADY_INITIALIZED);
    test("initialized", mgr.isInitialized());
    test("shutdown SUCCESS", mgr.shutdown() == NfcResult::SUCCESS);
    test("not initialized after shutdown", !mgr.isInitialized());
    test("init with maxTags=0 fails", mgr.initialize(0, 128, 256) == NfcResult::INVALID_PARAMETER);
    test("init with maxHistory=0 fails", mgr.initialize(16, 0, 256) == NfcResult::INVALID_PARAMETER);
}

static void testAdapterState() {
    std::cout << "\n  [Adapter State]\n";
    NfcManager mgr;
    mgr.initialize();

    test("initial state OFF", mgr.getAdapterState() == NfcAdapterState::OFF);
    test("isAdapterOff", mgr.isAdapterOff());
    test("not isAdapterEnabled", !mgr.isAdapterEnabled());

    test("enable SUCCESS", mgr.enableAdapter() == NfcResult::SUCCESS);
    test("state is ON", mgr.getAdapterState() == NfcAdapterState::ON);
    test("isAdapterEnabled", mgr.isAdapterEnabled());

    test("enable already ON BAD_STATE", mgr.enableAdapter() == NfcResult::BAD_STATE);

    test("disable SUCCESS", mgr.disableAdapter() == NfcResult::SUCCESS);
    test("state is OFF", mgr.getAdapterState() == NfcAdapterState::OFF);

    test("disable already OFF BAD_STATE", mgr.disableAdapter() == NfcResult::BAD_STATE);

    // Permission
    mgr.enableAdapter();
    test("non-system disable PERMISSION_DENIED",
         mgr.disableAdapter("app1") == NfcResult::PERMISSION_DENIED);
}

static void testDiscovery() {
    std::cout << "\n  [Discovery]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    test("initial discovery IDLE", mgr.getDiscoveryMode() == NfcDiscoveryMode::IDLE);
    test("not discovery active", !mgr.isDiscoveryActive());

    test("start READER SUCCESS", mgr.startDiscovery(NfcDiscoveryMode::READER) == NfcResult::SUCCESS);
    test("discovery is READER", mgr.getDiscoveryMode() == NfcDiscoveryMode::READER);
    test("isDiscoveryActive", mgr.isDiscoveryActive());

    test("start while active DISCOVERY_ACTIVE",
         mgr.startDiscovery(NfcDiscoveryMode::WRITER) == NfcResult::DISCOVERY_ACTIVE);

    test("stop SUCCESS", mgr.stopDiscovery() == NfcResult::SUCCESS);
    test("discovery is IDLE", mgr.getDiscoveryMode() == NfcDiscoveryMode::IDLE);

    test("stop when IDLE NO_DISCOVERY", mgr.stopDiscovery() == NfcResult::NO_DISCOVERY);

    // Adapter off
    mgr.disableAdapter();
    test("start with adapter off ADAPTER_OFF",
         mgr.startDiscovery(NfcDiscoveryMode::READER) == NfcResult::ADAPTER_OFF);

    test("start IDLE mode INVALID_PARAMETER",
         mgr.enableAdapter() == NfcResult::SUCCESS && mgr.startDiscovery(NfcDiscoveryMode::IDLE) == NfcResult::INVALID_PARAMETER);

    // Permission
    mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                          NFC_PRIVACY_NONE, true, false, false, false);
    test("start as app1 READER SUCCESS",
         mgr.startDiscovery(NfcDiscoveryMode::READER, "app1") == NfcResult::SUCCESS);
    mgr.stopDiscovery("app1");
}

static void testTagManagement() {
    std::cout << "\n  [Tag Management]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Stub tags created on initialize
    test("3 stub tags created", mgr.getTagCount() >= 3);

    auto tags = mgr.getAllTags();
    test("all tags returned", tags.size() == mgr.getTagCount());

    // Connect first tag
    std::string tagId = tags[0].tagId;
    test("connect tag SUCCESS", mgr.connectTag(tagId) == NfcResult::SUCCESS);

    NfcTag retrieved;
    test("getTag SUCCESS", mgr.getTag(tagId, retrieved) == NfcResult::SUCCESS);
    test("retrieved tagId matches", retrieved.tagId == tagId);
    test("tag is connected", retrieved.connected);

    auto connected = mgr.getConnectedTags();
    test("1 connected tag", connected.size() == 1);

    test("disconnect SUCCESS", mgr.disconnectTag() == NfcResult::SUCCESS);
    test("0 connected after disconnect", mgr.getConnectedTags().empty());

    // Not found
    test("getTag not found", mgr.getTag("nonexistent", retrieved) == NfcResult::TAG_NOT_FOUND);

    // Remove tag
    test("removeTag SUCCESS", mgr.removeTag(tagId) == NfcResult::SUCCESS);
    test("tag count decreased", mgr.getTagCount() == 2);

    // Permission
    test("non-system removeTag PERMISSION_DENIED",
         mgr.removeTag(tags[1].tagId, "app1") == NfcResult::PERMISSION_DENIED);

    // Adapter off
    mgr.disableAdapter();
    test("connect with adapter off ADAPTER_OFF",
         mgr.connectTag(tags[1].tagId) == NfcResult::ADAPTER_OFF);
}

static void testNdef() {
    std::cout << "\n  [NDEF]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto tags = mgr.getAllTags();
    std::string tagId = tags[0].tagId;

    // Connect first
    mgr.connectTag(tagId);

    // Read NDEF
    std::vector<uint8_t> data;
    test("readNdef SUCCESS", mgr.readNdef(tagId, data) == NfcResult::SUCCESS);
    test("NDEF data not empty", !data.empty());

    // Write NDEF
    std::vector<uint8_t> newData = {0x03, 0x02, 0x00, 0x00};
    test("writeNdef SUCCESS", mgr.writeNdef(tagId, newData) == NfcResult::SUCCESS);

    // Verify write
    std::vector<uint8_t> readBack;
    mgr.readNdef(tagId, readBack);
    test("NDEF data matches after write", readBack == newData);

    // Read-only tag
    std::string roTagId = tags[2].tagId; // FeliCa tag, readOnly=true
    mgr.connectTag(roTagId);
    test("write to read-only NDEF_INVALID",
         mgr.writeNdef(roTagId, newData) == NfcResult::NDEF_INVALID);
    test("isTagReadOnly true", mgr.isTagReadOnly(roTagId));

    // Not connected
    mgr.disconnectTag();
    test("readNdef not connected TAG_IO_ERROR",
         mgr.readNdef(tagId, data) == NfcResult::TAG_IO_ERROR);

    // Tag not found
    test("readNdef tag not found", mgr.readNdef("nonexistent", data) == NfcResult::TAG_NOT_FOUND);

    // Permission
    mgr.connectTag(tagId);
    test("non-system readNdef PERMISSION_DENIED",
         mgr.readNdef(tagId, data, "app1") == NfcResult::PERMISSION_DENIED);

    // Adapter off
    mgr.disableAdapter();
    mgr.enableAdapter();
    mgr.connectTag(tagId);
    test("readNdef with adapter off after reconnect",
         mgr.disableAdapter() == NfcResult::SUCCESS &&
         mgr.readNdef(tagId, data) == NfcResult::ADAPTER_OFF);
}

static void testCardEmulation() {
    std::cout << "\n  [Card Emulation / HCE]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Set policy with card emulation allowed
    mgr.setAppNfcPolicy("wallet", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::REDACTED,
                          NFC_PRIVACY_NONE, false, false, false, true);

    // Register AID route
    test("registerAidRoute SUCCESS",
         mgr.registerAidRoute("wallet", "A0000000041010", "Payment", "system") == NfcResult::SUCCESS);

    auto routes = mgr.getAidRoutes();
    test("1 AID route registered", routes.size() == 1);
    test("route AID matches", routes[0].aid == "A0000000041010");

    auto appRoutes = mgr.getAidRoutesForApp("wallet");
    test("app routes has 1", appRoutes.size() == 1);

    // Activate card emulation
    test("setCardEmulationActive SUCCESS",
         mgr.setCardEmulationActive("wallet", true) == NfcResult::SUCCESS);
    test("card emulation active", mgr.isCardEmulationActive());

    // Deactivate
    test("setCardEmulationActive false SUCCESS",
         mgr.setCardEmulationActive("wallet", false) == NfcResult::SUCCESS);
    test("card emulation not active", !mgr.isCardEmulationActive());

    // AID conflict
    mgr.setAppNfcPolicy("wallet2", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                          NFC_PRIVACY_NONE, false, false, false, true);
    test("duplicate AID AID_CONFLICT",
         mgr.registerAidRoute("wallet2", "A0000000041010", "Payment2", "system") == NfcResult::AID_CONFLICT);

    // Unregister
    test("unregisterAidRoute SUCCESS",
         mgr.unregisterAidRoute("wallet", "A0000000041010", "system") == NfcResult::SUCCESS);
    test("0 AID routes after unregister", mgr.getAidRoutes().empty());

    // Card emulation without AID routes
    test("activate without routes BAD_STATE",
         mgr.setCardEmulationActive("wallet", true) == NfcResult::BAD_STATE);

    // Permission - app without card emulation allowed
    mgr.setAppNfcPolicy("noreader", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                          NFC_PRIVACY_NONE, true, false, false, false);
    test("register AID without card emulation PERMISSION_DENIED",
         mgr.registerAidRoute("noreader", "B0000000041010", "Test", "system") == NfcResult::PERMISSION_DENIED);

    // Adapter off
    mgr.disableAdapter();
    test("activate with adapter off ADAPTER_OFF",
         mgr.setCardEmulationActive("wallet", true) == NfcResult::ADAPTER_OFF);
}

static void testPermissionPolicy() {
    std::cout << "\n  [Permission / Policy]\n";
    NfcManager mgr;
    mgr.initialize();

    mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                          NFC_PRIVACY_NONE, true, false, false, false);
    auto policy = mgr.getAppNfcPolicy("app1");
    test("permission ALLOW_ALWAYS", policy.permission == NfcPermission::ALLOW_ALWAYS);
    test("allowReader true", policy.allowReaderMode);
    test("allowWriter false", !policy.allowWriterMode);

    test("app1 has access", mgr.checkAppAccess("app1"));

    // ALLOW_ONCE
    mgr.setAppNfcPolicy("app2", NfcPermission::ALLOW_ONCE, NfcPrivacyMode::REDACTED,
                          NFC_PRIVACY_NONE, true, false, false, false);
    test("app2 has access (one-shot)", mgr.checkAppAccess("app2"));

    // ALLOW_FOREGROUND
    mgr.setAppNfcPolicy("app3", NfcPermission::ALLOW_FOREGROUND, NfcPrivacyMode::METADATA_ONLY,
                          NFC_PRIVACY_NONE, true, false, false, false);
    test("app3 no access (not foreground)", !mgr.checkAppAccess("app3"));
    mgr.setAppForeground("app3", true);
    test("app3 has access (foreground)", mgr.checkAppAccess("app3"));

    // DENY
    mgr.setAppNfcPolicy("app4", NfcPermission::DENY, NfcPrivacyMode::FULL);
    test("app4 no access (denied)", !mgr.checkAppAccess("app4"));

    // Clear
    test("clearAppNfcPolicy SUCCESS", mgr.clearAppNfcPolicy("app1") == NfcResult::SUCCESS);
    test("app1 no policy permission DENY",
         mgr.getAppNfcPolicy("app1").permission == NfcPermission::DENY);

    // Non-system can't set policy
    test("non-system setAppNfcPolicy PERMISSION_DENIED",
         mgr.setAppNfcPolicy("app5", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                               NFC_PRIVACY_NONE, true, false, false, false, "app1") == NfcResult::PERMISSION_DENIED);

    // Clear non-existent
    test("clearAppNfcPolicy non-existent INVALID_PARAMETER",
         mgr.clearAppNfcPolicy("nonexistent") == NfcResult::INVALID_PARAMETER);
}

static void testIdentifierAccess() {
    std::cout << "\n  [Identifier Access]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto tags = mgr.getAllTags();
    std::string tagId = tags[0].tagId;

    // Set policy for app1 with FULL privacy
    mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                          NFC_PRIVACY_NONE, true, false, false, false);

    std::string outId;
    test("getTagId FULL returns raw",
         mgr.getTagId("app1", tagId, outId) == NfcResult::SUCCESS && outId == tagId);

    // REDACTED privacy
    mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::REDACTED,
                          NFC_PRIVACY_REDACT_TAG_ID, true, false, false, false);
    test("getTagId REDACTED returns redacted",
         mgr.getTagId("app1", tagId, outId) == NfcResult::SUCCESS && outId != tagId);

    // METADATA_ONLY privacy
    mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::METADATA_ONLY,
                          NFC_PRIVACY_METADATA_ONLY, true, false, false, false);
    test("getTagId METADATA_ONLY returns metadata",
         mgr.getTagId("app1", tagId, outId) == NfcResult::SUCCESS);

    // System always gets raw
    test("system getTagId returns raw",
         mgr.getTagId("system", tagId, outId) == NfcResult::SUCCESS && outId == tagId);

    // Protocol
    NfcProtocol protocol;
    test("getTagProtocol SUCCESS",
         mgr.getTagProtocol("app1", tagId, protocol) == NfcResult::SUCCESS);
    test("protocol is ISO_14443_A", protocol == NfcProtocol::ISO_14443_A);

    // RSSI
    int32_t rssi;
    test("getTagRssi SUCCESS",
         mgr.getTagRssi("app1", tagId, rssi) == NfcResult::SUCCESS);

    // Non-permissioned app
    test("non-permissioned getTagId PERMISSION_DENIED",
         mgr.getTagId("unauthorized", tagId, outId) == NfcResult::PERMISSION_DENIED);

    // Tag not found
    test("getTagId not found", mgr.getTagId("app1", "nonexistent", outId) == NfcResult::TAG_NOT_FOUND);
}

static void testHistory() {
    std::cout << "\n  [History / Privacy]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Generate events
    mgr.connectTag(mgr.getAllTags()[0].tagId);
    mgr.disconnectTag();

    // Archive to history
    mgr.clearEvents();

    auto history = mgr.getHistory("system");
    test("history not empty after clearEvents", !history.empty());

    // Clear history
    test("clearHistory SUCCESS", mgr.clearHistory() == NfcResult::SUCCESS);
    test("history empty after clear", mgr.getHistory("system").empty());

    // Permission
    test("non-system clearHistory PERMISSION_DENIED",
         mgr.clearHistory("app1") == NfcResult::PERMISSION_DENIED);
}

static void testMock() {
    std::cout << "\n  [Mock / Testing]\n";
    NfcManager mgr;
    mgr.initialize();

    test("mock disabled initially", !mgr.isMockEnabled());
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == NfcResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    // Set mock tag
    std::vector<uint8_t> ndefData = {0x01, 0x02, 0x03, 0x04};
    test("setMockTag SUCCESS",
         mgr.setMockTag("mock:01", NfcProtocol::ISO_14443_B, NfcTagType::NDEF,
                          ndefData, 256, false) == NfcResult::SUCCESS);

    NfcTag retrieved;
    test("mock tag exists", mgr.getTag("mock:01", retrieved) == NfcResult::SUCCESS);
    test("mock tag protocol", retrieved.protocol == NfcProtocol::ISO_14443_B);
    test("mock tag NDEF data", retrieved.ndefContent == ndefData);

    // Add mock tag
    NfcTag newTag;
    newTag.tagId = "mock:02";
    newTag.protocol = NfcProtocol::MIFARE_ULTRALIGHT;
    newTag.type = NfcTagType::MIFARE_ULTRALIGHT;
    newTag.maxSize = 512;
    test("addMockTag SUCCESS", mgr.addMockTag(newTag) == NfcResult::SUCCESS);
    test("tag count increased", mgr.getTagCount() >= 5);

    // Remove mock tag
    test("removeMockTag SUCCESS", mgr.removeMockTag("mock:01") == NfcResult::SUCCESS);
    test("mock tag gone", mgr.getTag("mock:01", retrieved) == NfcResult::TAG_NOT_FOUND);

    // Permission
    test("non-system setMockTag PERMISSION_DENIED",
         mgr.setMockTag("mock:03", NfcProtocol::UNKNOWN, NfcTagType::UNKNOWN,
                          ndefData, 128, false, "app1") == NfcResult::PERMISSION_DENIED);
}

static void testPrivacyIndicator() {
    std::cout << "\n  [Privacy Indicator]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    test("indicator off initially", !mgr.isPrivacyIndicatorOn());
    test("no active users", mgr.getActiveNfcUsers().empty());
    test("lastAccessTime 0", mgr.getLastAccessTime() == 0);

    // Connect a tag (adds to active users)
    auto tags = mgr.getAllTags();
    mgr.connectTag(tags[0].tagId);
    test("indicator on after connect", mgr.isPrivacyIndicatorOn());
    test("1 active user", mgr.getActiveNfcUsers().size() == 1);
    test("lastAccessTime > 0", mgr.getLastAccessTime() > 0);

    // Disconnect
    mgr.disconnectTag();
    test("indicator off after disconnect", !mgr.isPrivacyIndicatorOn());
}

static void testEvents() {
    std::cout << "\n  [Events]\n";
    NfcManager mgr;
    mgr.initialize(16, 128, 256);
    mgr.enableAdapter();

    mgr.connectTag(mgr.getAllTags()[0].tagId);
    mgr.disconnectTag();

    auto events = mgr.getEvents();
    test("events not empty", !events.empty());
    test("events has tag discovered",
         !mgr.getEventsByType(NfcEventType::TAG_DISCOVERED).empty());
    test("events has tag removed",
         !mgr.getEventsByType(NfcEventType::TAG_REMOVED).empty());

    // Clear events (archives to history)
    test("clearEvents SUCCESS", mgr.clearEvents() == NfcResult::SUCCESS);
    test("events empty after clear", mgr.getEvents().empty());
    test("history has archived events", mgr.getHistoryCount() > 0);

    // Event callback
    bool callbackCalled = false;
    NfcEvent capturedEvent;
    mgr.setEventCallback([&](const NfcEvent& e) {
        callbackCalled = true;
        capturedEvent = e;
    });

    mgr.connectTag(mgr.getAllTags()[0].tagId);
    test("callback called", callbackCalled);
    test("callback event type TAG_DISCOVERED",
         capturedEvent.type == NfcEventType::TAG_DISCOVERED);
}

static void testStats() {
    std::cout << "\n  [Stats]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    mgr.connectTag(mgr.getAllTags()[0].tagId);
    mgr.disconnectTag();
    mgr.disableAdapter();
    mgr.enableAdapter();

    auto stats = mgr.getStats();
    test("adapterOnCount > 0", stats.adapterOnCount > 0);
    test("adapterOffCount > 0", stats.adapterOffCount > 0);
    test("tagsDiscovered > 0", stats.tagsDiscovered > 0);
    test("tagsRemoved > 0", stats.tagsRemoved > 0);
    test("totalFailures 0", stats.totalFailures == 0);

    // Reset
    mgr.resetStats();
    auto resetStats = mgr.getStats();
    test("adapterOnCount 0 after reset", resetStats.adapterOnCount == 0);
    test("tagsDiscovered 0 after reset", resetStats.tagsDiscovered == 0);
}

static void testFailureSimulation() {
    std::cout << "\n  [Failure Simulation]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Test enable failure (adapter is ON, disable first without fail flag)
    mgr.disableAdapter();  // adapter OFF, no fail flag
    mgr.setFailNextOperation(true);
    test("enableAdapter SIMULATED_FAILURE",
         mgr.enableAdapter() == NfcResult::SIMULATED_FAILURE);
    test("failNextOperation consumed", !mgr.getFailNextOperation());

    // Adapter is OFF now, enable should succeed
    test("enableAdapter SUCCESS after failure consumed",
         mgr.enableAdapter() == NfcResult::SUCCESS);

    // Test disable failure
    mgr.setFailNextOperation(true);
    test("disableAdapter SIMULATED_FAILURE",
         mgr.disableAdapter() == NfcResult::SIMULATED_FAILURE);
    // Now disable for real
    test("disableAdapter SUCCESS", mgr.disableAdapter() == NfcResult::SUCCESS);

    mgr.setFailNextOperation(true);
    test("startDiscovery SIMULATED_FAILURE",
         mgr.startDiscovery(NfcDiscoveryMode::READER) == NfcResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("connectTag SIMULATED_FAILURE",
         mgr.connectTag(mgr.getAllTags()[0].tagId) == NfcResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("registerAidRoute SIMULATED_FAILURE",
         (mgr.setAppNfcPolicy("app1", NfcPermission::ALLOW_ALWAYS, NfcPrivacyMode::FULL,
                               NFC_PRIVACY_NONE, false, false, false, true) == NfcResult::SUCCESS,
          mgr.setFailNextOperation(true),
          mgr.registerAidRoute("app1", "A0000000041010", "Payment")) == NfcResult::SIMULATED_FAILURE);
}

static void testTimeInjection() {
    std::cout << "\n  [Time Injection]\n";
    NfcManager mgr;
    mgr.initialize();
    mgr.enableAdapter();
    mgr.setCurrentTimeForTesting(1000000);
    mgr.connectTag(mgr.getAllTags()[0].tagId);

    auto events = mgr.getEvents();
    if (!events.empty()) {
        test("event timestamp matches override",
             events.back().timestamp == 1000000);
    }
    mgr.clearTimeOverride();
    test("time override cleared", true);
}

static void testStringHelpers() {
    std::cout << "\n  [String Helpers]\n";

    test("adapterStateToString(OFF)", std::string(NfcManager::adapterStateToString(NfcAdapterState::OFF)) == "OFF");
    test("adapterStateToString(ON)", std::string(NfcManager::adapterStateToString(NfcAdapterState::ON)) == "ON");

    test("discoveryModeToString(IDLE)", std::string(NfcManager::discoveryModeToString(NfcDiscoveryMode::IDLE)) == "IDLE");
    test("discoveryModeToString(READER)", std::string(NfcManager::discoveryModeToString(NfcDiscoveryMode::READER)) == "READER");
    test("discoveryModeToString(CARD_EMULATION)", std::string(NfcManager::discoveryModeToString(NfcDiscoveryMode::CARD_EMULATION)) == "CARD_EMULATION");

    test("protocolToString(ISO_14443_A)", std::string(NfcManager::protocolToString(NfcProtocol::ISO_14443_A)) == "ISO_14443_A");
    test("protocolToString(MIFARE_CLASSIC)", std::string(NfcManager::protocolToString(NfcProtocol::MIFARE_CLASSIC)) == "MIFARE_CLASSIC");
    test("protocolToString(FELICA)", std::string(NfcManager::protocolToString(NfcProtocol::FELICA)) == "FELICA");

    test("tagTypeToString(NDEF)", std::string(NfcManager::tagTypeToString(NfcTagType::NDEF)) == "NDEF");
    test("tagTypeToString(MIFARE_CLASSIC)", std::string(NfcManager::tagTypeToString(NfcTagType::MIFARE_CLASSIC)) == "MIFARE_CLASSIC");

    test("permissionToString(DENY)", std::string(NfcManager::permissionToString(NfcPermission::DENY)) == "DENY");
    test("permissionToString(ALLOW_ALWAYS)", std::string(NfcManager::permissionToString(NfcPermission::ALLOW_ALWAYS)) == "ALLOW_ALWAYS");

    test("privacyModeToString(FULL)", std::string(NfcManager::privacyModeToString(NfcPrivacyMode::FULL)) == "FULL");
    test("privacyModeToString(REDACTED)", std::string(NfcManager::privacyModeToString(NfcPrivacyMode::REDACTED)) == "REDACTED");

    test("resultToString(SUCCESS)", std::string(NfcManager::resultToString(NfcResult::SUCCESS)) == "SUCCESS");
    test("resultToString(TAG_NOT_FOUND)", std::string(NfcManager::resultToString(NfcResult::TAG_NOT_FOUND)) == "TAG_NOT_FOUND");
    test("resultToString(AID_CONFLICT)", std::string(NfcManager::resultToString(NfcResult::AID_CONFLICT)) == "AID_CONFLICT");

    // Parsers
    test("stringToResult(SUCCESS)", NfcManager::stringToResult("SUCCESS") == NfcResult::SUCCESS);
    test("stringToResult(PERMISSION_DENIED)", NfcManager::stringToResult("PERMISSION_DENIED") == NfcResult::PERMISSION_DENIED);
    test("stringToResult(unknown)", NfcManager::stringToResult("UNKNOWN") == NfcResult::OPERATION_FAILED);

    test("stringToProtocol(ISO_14443_A)", NfcManager::stringToProtocol("ISO_14443_A") == NfcProtocol::ISO_14443_A);
    test("stringToProtocol(FELICA)", NfcManager::stringToProtocol("FELICA") == NfcProtocol::FELICA);
}

static void testLogServerIntegration() {
    std::cout << "\n  [LogServer / CrashReporter Integration]\n";
    NfcManager mgr;
    mgr.initialize();

    test("logServer null initially", mgr.getLogServer() == nullptr);
    test("crashReporter null initially", mgr.getCrashReporter() == nullptr);

    mgr.enableAdapter();
    test("enableAdapter with null integration SUCCESS",
         mgr.isAdapterEnabled());

    mgr.shutdown();
}

static void testFullWorkflow() {
    std::cout << "\n  [Full Workflow]\n";
    NfcManager mgr;
    mgr.initialize();

    // 1. Enable adapter
    test("1. enable adapter", mgr.enableAdapter() == NfcResult::SUCCESS);

    // 2. Set app policy
    test("2. set wallet policy",
         mgr.setAppNfcPolicy("wallet", NfcPermission::ALLOW_FOREGROUND, NfcPrivacyMode::REDACTED,
                               NFC_PRIVACY_REDACT_TAG_ID | NFC_PRIVACY_INDICATOR_REQUIRED,
                               true, true, false, true) == NfcResult::SUCCESS);

    // 3. Set foreground
    test("3. set foreground", mgr.setAppForeground("wallet", true) == NfcResult::SUCCESS);

    // 4. Start discovery
    test("4. start discovery READER",
         mgr.startDiscovery(NfcDiscoveryMode::READER, "wallet") == NfcResult::SUCCESS);

    // 5. Connect tag
    auto tags = mgr.getAllTags();
    test("5. connect tag", mgr.connectTag(tags[0].tagId, "wallet") == NfcResult::SUCCESS);

    // 6. Read NDEF
    std::vector<uint8_t> data;
    test("6. read NDEF", mgr.readNdef(tags[0].tagId, data, "wallet") == NfcResult::SUCCESS);

    // 7. Write NDEF
    std::vector<uint8_t> newData = {0x03, 0x02, 0x00, 0x00};
    test("7. write NDEF", mgr.writeNdef(tags[0].tagId, newData, "wallet") == NfcResult::SUCCESS);

    // 8. Get tag ID (redacted)
    std::string outId;
    test("8. get tag ID (redacted)", mgr.getTagId("wallet", tags[0].tagId, outId) == NfcResult::SUCCESS);
    test("8a. tag ID redacted", outId != tags[0].tagId);

    // 9. Register AID route
    test("9. register AID route",
         mgr.registerAidRoute("wallet", "A0000000041010", "Payment") == NfcResult::SUCCESS);

    // 10. Activate card emulation
    test("10. activate card emulation",
         mgr.setCardEmulationActive("wallet", true) == NfcResult::SUCCESS);

    // 11. Check stats
    auto stats = mgr.getStats();
    test("11. adapterOnCount > 0", stats.adapterOnCount > 0);
    test("11a. tagsDiscovered > 0", stats.tagsDiscovered > 0);

    // 12. Deactivate card emulation
    test("12. deactivate card emulation",
         mgr.setCardEmulationActive("wallet", false) == NfcResult::SUCCESS);

    // 13. Disconnect tag
    test("13. disconnect tag", mgr.disconnectTag("wallet") == NfcResult::SUCCESS);

    // 14. Stop discovery
    test("14. stop discovery", mgr.stopDiscovery("wallet") == NfcResult::SUCCESS);

    // 15. Archive events
    test("15. clearEvents", mgr.clearEvents() == NfcResult::SUCCESS);
    test("15a. history has entries", mgr.getHistoryCount() > 0);

    // 16. Clear history
    test("16. clearHistory", mgr.clearHistory() == NfcResult::SUCCESS);
    test("16a. history empty", mgr.getHistoryCount() == 0);

    // 17. Reset stats
    mgr.resetStats();
    test("17. stats reset", mgr.getStats().adapterOnCount == 0);

    // 18. Shutdown
    test("18. shutdown SUCCESS", mgr.shutdown() == NfcResult::SUCCESS);
    test("18a. not initialized", !mgr.isInitialized());
}

int main() {
    std::cout << "========================================\n";
    std::cout << "Phantom OS - NFC Manager Tests\n";
    std::cout << "v0.35.0\n";
    std::cout << "========================================\n";

    testLifecycle(); fflush(stdout);
    testAdapterState(); fflush(stdout);
    testDiscovery(); fflush(stdout);
    testTagManagement(); fflush(stdout);
    testNdef(); fflush(stdout);
    testCardEmulation(); fflush(stdout);
    testPermissionPolicy(); fflush(stdout);
    testIdentifierAccess(); fflush(stdout);
    testHistory(); fflush(stdout);
    testMock(); fflush(stdout);
    testPrivacyIndicator(); fflush(stdout);
    testEvents(); fflush(stdout);
    testStats(); fflush(stdout);
    testFailureSimulation(); fflush(stdout);
    testTimeInjection(); fflush(stdout);
    testStringHelpers(); fflush(stdout);
    testLogServerIntegration(); fflush(stdout);
    testFullWorkflow(); fflush(stdout);

    std::cout << "\n========================================\n";
    std::cout << "Results: " << g_testsPassed << " passed, " << g_testsFailed << " failed\n";
    std::cout << "========================================\n";

    return g_testsFailed > 0 ? 1 : 0;
}
