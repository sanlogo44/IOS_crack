/*
 * Phantom OS - System Server Tests
 * v0.15.0 — Boot sequence, service lifecycle, and dependency tests
 *
 * License: GPL-3.0
 */

#include "phantom/sysserver/system_server.h"
#include <cstdio>
#include <cstring>
#include <algorithm>

static int tests_passed = 0;
static int tests_failed = 0;

#define RUN_TEST(name) do { \
    printf("  Running %s\n", #name); \
    tests_passed++; \
    name(); \
} while(0)

#define ASSERT_TRUE(cond) do { if(!(cond)) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_FALSE(cond) do { if(cond) { printf("FAIL: %s\n", #cond); tests_failed++; return; } } while(0)
#define ASSERT_EQ(a, b) do { if((a) != (b)) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_NE(a, b) do { if((a) == (b)) { printf("FAIL: %s == %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GT(a, b) do { if(!((a) > (b))) { printf("FAIL: %s <= %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_GE(a, b) do { if(!((a) >= (b))) { printf("FAIL: %s < %s\n", #a, #b); tests_failed++; return; } } while(0)
#define ASSERT_STREQ(a, b) do { if(strcmp((a), (b)) != 0) { printf("FAIL: %s != %s\n", #a, #b); tests_failed++; return; } } while(0)

static void testInitialization() {
    phantom::sysserver::SystemServer server;
    ASSERT_FALSE(server.isInitialized());
    ASSERT_EQ(server.getSystemState(), phantom::sysserver::SystemState::OFF);

    auto result = server.initialize();
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    ASSERT_TRUE(server.isInitialized());
    ASSERT_EQ(server.getSystemState(), phantom::sysserver::SystemState::OFF);
}

static void testReinitialization() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.initialize();
    ASSERT_EQ(result, phantom::sysserver::InitResult::ALREADY_RUNNING);
}

static void testBoot() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.boot();
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    ASSERT_TRUE(server.isRunning());
    ASSERT_EQ(server.getSystemState(), phantom::sysserver::SystemState::RUNNING);
    ASSERT_EQ(server.getBootPhase(), phantom::sysserver::BootPhase::COMPLETE);
}

static void testBootWithoutInit() {
    phantom::sysserver::SystemServer server;
    auto result = server.boot();
    ASSERT_EQ(result, phantom::sysserver::InitResult::NOT_INITIALIZED);
}

static void testShutdown() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();
    auto result = server.shutdown();
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    ASSERT_FALSE(server.isInitialized());
    ASSERT_EQ(server.getSystemState(), phantom::sysserver::SystemState::OFF);
    ASSERT_EQ(server.getServiceCount(), static_cast<size_t>(0));
}

static void testReboot() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();
    auto runningBefore = server.getRunningServiceCount();
    auto result = server.reboot();
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    ASSERT_TRUE(server.isRunning());
    auto runningAfter = server.getRunningServiceCount();
    ASSERT_TRUE(runningAfter > 0);
}

static void testDefaultServicesRegistered() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto count = server.getServiceCount();
    ASSERT_EQ(count, server.getDefaultServiceCount());
    ASSERT_TRUE(count >= 14);
}

static void testGetServiceByName() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto s = server.getService("hal_service");
    ASSERT_TRUE(s.id > 0);
    ASSERT_EQ(s.name, "hal_service");
    ASSERT_EQ(s.group, phantom::sysserver::ServiceGroup::CORE);
}

static void testGetServiceById() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto all = server.getServices();
    ASSERT_TRUE(!all.empty());
    auto s = server.getServiceById(all[0].id);
    ASSERT_EQ(s.name, all[0].name);
}

static void testGetServiceNotFound() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto s = server.getService("nonexistent");
    ASSERT_EQ(s.id, 0u);
}

static void testGetServicesByGroup() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto core = server.getServicesByGroup(phantom::sysserver::ServiceGroup::CORE);
    ASSERT_TRUE(core.size() >= 4);
    auto apps = server.getServicesByGroup(phantom::sysserver::ServiceGroup::APPS);
    ASSERT_TRUE(apps.size() >= 4);
    auto network = server.getServicesByGroup(phantom::sysserver::ServiceGroup::NETWORK);
    ASSERT_TRUE(network.size() >= 2);
}

static void testGetServicesByState() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto stopped = server.getServicesByState(phantom::sysserver::ServiceState::STOPPED);
    ASSERT_TRUE(stopped.size() > 0);
    auto running = server.getServicesByState(phantom::sysserver::ServiceState::RUNNING);
    ASSERT_EQ(running.size(), static_cast<size_t>(0));
}

static void testStartService() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.startService("hal_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    auto s = server.getService("hal_service");
    ASSERT_EQ(s.state, phantom::sysserver::ServiceState::RUNNING);
    ASSERT_EQ(s.health, phantom::sysserver::HealthStatus::HEALTHY);
    ASSERT_TRUE(s.pid > 0);
}

static void testStartServiceNotFound() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.startService("nonexistent");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SERVICE_NOT_FOUND);
}

static void testStartServiceDependencyFailed() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    // config_service depends on hal_service, which is not running
    auto result = server.startService("config_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::DEPENDENCY_FAILED);
    auto s = server.getService("config_service");
    ASSERT_EQ(s.state, phantom::sysserver::ServiceState::FAILED);
}

static void testStartServiceWithDependencies() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.startService("hal_service");
    auto result = server.startService("config_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
}

static void testStartAlreadyRunning() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.startService("hal_service");
    auto result = server.startService("hal_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::ALREADY_RUNNING);
}

static void testStopService() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.startService("hal_service");
    auto result = server.stopService("hal_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    auto s = server.getService("hal_service");
    ASSERT_EQ(s.state, phantom::sysserver::ServiceState::STOPPED);
    ASSERT_EQ(s.pid, -1);
}

static void testStopServiceNotFound() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.stopService("nonexistent");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SERVICE_NOT_FOUND);
}

static void testRestartService() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.startService("hal_service");
    auto result = server.restartService("hal_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);
    auto s = server.getService("hal_service");
    ASSERT_EQ(s.state, phantom::sysserver::ServiceState::RUNNING);
    ASSERT_EQ(s.restartCount, 1u);
}

static void testEnableDisableService() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.disableService("hal_service");
    auto s = server.getService("hal_service");
    ASSERT_EQ(s.state, phantom::sysserver::ServiceState::DISABLED);
    ASSERT_FALSE(s.autoStart);

    // Can't start disabled service
    auto result = server.startService("hal_service");
    ASSERT_EQ(result, phantom::sysserver::InitResult::INVALID_STATE);

    server.enableService("hal_service");
    auto s2 = server.getService("hal_service");
    ASSERT_EQ(s2.state, phantom::sysserver::ServiceState::STOPPED);
    ASSERT_TRUE(s2.autoStart);
}

static void testRegisterCustomService() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    phantom::sysserver::ServiceInfo custom;
    custom.name = "custom_service";
    custom.description = "Custom test service";
    custom.group = phantom::sysserver::ServiceGroup::OPTIONAL;
    custom.priority = 200;

    auto id = server.registerService(custom);
    ASSERT_TRUE(id > 0);
    auto s = server.getService("custom_service");
    ASSERT_EQ(s.name, "custom_service");
}

static void testRegisterDuplicateService() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    phantom::sysserver::ServiceInfo dup;
    dup.name = "hal_service";
    dup.description = "Duplicate";

    auto id = server.registerService(dup);
    ASSERT_EQ(id, 0u);
}

static void testUnregisterService() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    phantom::sysserver::ServiceInfo custom;
    custom.name = "temp_service";
    auto id = server.registerService(custom);
    ASSERT_TRUE(id > 0);

    bool removed = server.unregisterService("temp_service");
    ASSERT_TRUE(removed);
    auto s = server.getService("temp_service");
    ASSERT_EQ(s.id, 0u);
}

static void testBootSequence() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto result = server.boot();
    ASSERT_EQ(result, phantom::sysserver::InitResult::SUCCESS);

    // All core services should be running
    auto core = server.getServicesByGroup(phantom::sysserver::ServiceGroup::CORE);
    for (const auto& s : core) {
        if (s.autoStart) {
            ASSERT_EQ(s.state, phantom::sysserver::ServiceState::RUNNING);
        }
    }
}

static void testBootEvents() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();

    auto events = server.getBootEvents();
    ASSERT_TRUE(events.size() > 5);
    auto count = server.getBootEventCount();
    ASSERT_TRUE(count > 5);

    // Check first event is the init message
    ASSERT_TRUE(!events[0].message.empty());

    // Check boot phase in last event
    ASSERT_EQ(events.back().phase, phantom::sysserver::BootPhase::COMPLETE);
}

static void testClearBootEvents() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();
    server.clearBootEvents();
    ASSERT_EQ(server.getBootEventCount(), static_cast<size_t>(0));
}

static void testDependencyResolution() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    // sysmon depends on hal_service and linux_compat_service
    auto deps = server.resolveDependencies("system_monitor_app");
    ASSERT_TRUE(deps.size() >= 3);
    ASSERT_TRUE(deps.front() == "hal_service");  // hal should come first
}

static void testCircularDependency() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    phantom::sysserver::ServiceInfo a;
    a.name = "svc_a";
    a.dependencies = {"svc_b"};

    phantom::sysserver::ServiceInfo b;
    b.name = "svc_b";
    b.dependencies = {"svc_a"};

    server.registerService(a);
    server.registerService(b);

    ASSERT_TRUE(server.hasCircularDependency("svc_a"));
}

static void testNoCircularDependency() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    ASSERT_FALSE(server.hasCircularDependency("hal_service"));
    ASSERT_FALSE(server.hasCircularDependency("system_monitor_app"));
}

static void testStartupOrder() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    auto order = server.getStartupOrder();
    ASSERT_EQ(order.size(), server.getServiceCount());

    // hal_service should come before config_service
    auto halIt = std::find(order.begin(), order.end(), "hal_service");
    auto configIt = std::find(order.begin(), order.end(), "config_service");
    ASSERT_TRUE(halIt < configIt);
}

static void testHealthMonitoring() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();

    server.runHealthCheck();
    auto health = server.getOverallHealth();
    // After boot, system should be healthy or at least not critical
    ASSERT_NE(health, phantom::sysserver::HealthStatus::CRITICAL);
}

static void testSetHealthStatus() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.startService("hal_service");

    server.setHealthStatus("hal_service", phantom::sysserver::HealthStatus::DEGRADED);
    auto health = server.getServiceHealth("hal_service");
    ASSERT_EQ(health, phantom::sysserver::HealthStatus::DEGRADED);
}

static void testSystemStats() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();

    auto stats = server.getSystemStats();
    ASSERT_TRUE(stats.totalServices > 0);
    ASSERT_TRUE(stats.runningServices > 0);
    ASSERT_EQ(stats.failedServices, 0u);
}

static void testStateChangeCallback() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    int callbackCount = 0;
    server.setStateChangeCallback([&](phantom::sysserver::SystemState, phantom::sysserver::SystemState) {
        callbackCount++;
    });

    server.boot();
    ASSERT_TRUE(callbackCount > 0);
}

static void testServiceStateCallback() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    int callbackCount = 0;
    server.setServiceStateCallback([&](const std::string&, phantom::sysserver::ServiceState, phantom::sysserver::ServiceState) {
        callbackCount++;
    });

    server.startService("hal_service");
    ASSERT_TRUE(callbackCount > 0);
}

static void testBootEventCallback() {
    phantom::sysserver::SystemServer server;
    server.initialize();

    int callbackCount = 0;
    server.setBootEventCallback([&](const phantom::sysserver::BootEvent&) {
        callbackCount++;
    });

    server.boot();
    ASSERT_TRUE(callbackCount > 0);
}

static void testRunningServiceCount() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    ASSERT_EQ(server.getRunningServiceCount(), static_cast<size_t>(0));
    server.boot();
    ASSERT_TRUE(server.getRunningServiceCount() > 0);
}

static void testFailedServiceCount() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    // Try to start a service with unmet dependencies
    server.startService("config_service");
    ASSERT_TRUE(server.getFailedServiceCount() > 0);
}

static void testStringHelpers() {
    ASSERT_EQ(phantom::sysserver::SystemServer::systemStateToString(phantom::sysserver::SystemState::RUNNING), "RUNNING");
    ASSERT_EQ(phantom::sysserver::SystemServer::serviceStateToString(phantom::sysserver::ServiceState::RUNNING), "RUNNING");
    ASSERT_EQ(phantom::sysserver::SystemServer::serviceGroupToString(phantom::sysserver::ServiceGroup::CORE), "CORE");
    ASSERT_EQ(phantom::sysserver::SystemServer::bootPhaseToString(phantom::sysserver::BootPhase::COMPLETE), "COMPLETE");
    ASSERT_EQ(phantom::sysserver::SystemServer::serviceTypeToString(phantom::sysserver::ServiceType::HAL), "HAL");
    ASSERT_EQ(phantom::sysserver::SystemServer::healthStatusToString(phantom::sysserver::HealthStatus::HEALTHY), "HEALTHY");
    ASSERT_EQ(phantom::sysserver::SystemServer::initResultToString(phantom::sysserver::InitResult::SUCCESS), "SUCCESS");
}

static void testTelemetryDisabled() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    auto s = server.getService("telemetry_service");
    ASSERT_EQ(s.group, phantom::sysserver::ServiceGroup::OPTIONAL);
    ASSERT_FALSE(s.autoStart);
}

static void testShutdownStopsAllServices() {
    phantom::sysserver::SystemServer server;
    server.initialize();
    server.boot();
    ASSERT_TRUE(server.getRunningServiceCount() > 0);
    server.shutdown();
    ASSERT_EQ(server.getRunningServiceCount(), static_cast<size_t>(0));
    ASSERT_EQ(server.getServiceCount(), static_cast<size_t>(0));
}

int runAllTests() {
    printf("=== System Server Tests ===\n");
    RUN_TEST(testInitialization);
    RUN_TEST(testReinitialization);
    RUN_TEST(testBoot);
    RUN_TEST(testBootWithoutInit);
    RUN_TEST(testShutdown);
    RUN_TEST(testReboot);
    RUN_TEST(testDefaultServicesRegistered);
    RUN_TEST(testGetServiceByName);
    RUN_TEST(testGetServiceById);
    RUN_TEST(testGetServiceNotFound);
    RUN_TEST(testGetServicesByGroup);
    RUN_TEST(testGetServicesByState);
    RUN_TEST(testStartService);
    RUN_TEST(testStartServiceNotFound);
    RUN_TEST(testStartServiceDependencyFailed);
    RUN_TEST(testStartServiceWithDependencies);
    RUN_TEST(testStartAlreadyRunning);
    RUN_TEST(testStopService);
    RUN_TEST(testStopServiceNotFound);
    RUN_TEST(testRestartService);
    RUN_TEST(testEnableDisableService);
    RUN_TEST(testRegisterCustomService);
    RUN_TEST(testRegisterDuplicateService);
    RUN_TEST(testUnregisterService);
    RUN_TEST(testBootSequence);
    RUN_TEST(testBootEvents);
    RUN_TEST(testClearBootEvents);
    RUN_TEST(testDependencyResolution);
    RUN_TEST(testCircularDependency);
    RUN_TEST(testNoCircularDependency);
    RUN_TEST(testStartupOrder);
    RUN_TEST(testHealthMonitoring);
    RUN_TEST(testSetHealthStatus);
    RUN_TEST(testSystemStats);
    RUN_TEST(testStateChangeCallback);
    RUN_TEST(testServiceStateCallback);
    RUN_TEST(testBootEventCallback);
    RUN_TEST(testRunningServiceCount);
    RUN_TEST(testFailedServiceCount);
    RUN_TEST(testStringHelpers);
    RUN_TEST(testTelemetryDisabled);
    RUN_TEST(testShutdownStopsAllServices);
    printf("\n=== Summary ===\n");
    printf("Tests passed: %d\n", tests_passed);
    printf("Tests failed: %d\n", tests_failed);
    printf("Total: %d\n", tests_passed + tests_failed);
    return tests_failed > 0 ? 1 : 0;
}

int main() {
    return runAllTests();
}
