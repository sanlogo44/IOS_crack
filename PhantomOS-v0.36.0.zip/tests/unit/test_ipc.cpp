/*
 * Phantom OS - IPC Message Bus Tests
 * Tests for the in-process IPC message bus
 *
 * License: GPL-3.0
 */

#include "phantom/ipc/message_bus.h"
#include "phantom/ipc/message.h"
#include <cassert>
#include <cstdio>
#include <string>
#include <unordered_map>

using namespace phantom::ipc;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

// Message capture for testing
struct MessageCapture {
    bool received = false;
    Message last_message;
    int receive_count = 0;
};

bool test_register_endpoint() {
    TEST("Register endpoint");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    auto result = bus.registerEndpoint("ep1");
    ASSERT(result == IpcResult::SUCCESS, "Should register successfully");
    ASSERT(bus.isEndpointRegistered("ep1"), "Endpoint should be registered");
    ASSERT(bus.getEndpointCount() == 1, "Should have 1 endpoint");
    PASS();
    return true;
}

bool test_duplicate_endpoint() {
    TEST("Duplicate endpoint registration fails");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    bus.registerEndpoint("ep_dup");
    auto result = bus.registerEndpoint("ep_dup");
    ASSERT(result == IpcResult::ENDPOINT_ALREADY_EXISTS, "Should fail on duplicate");
    PASS();
    return true;
}

bool test_unregister_endpoint() {
    TEST("Unregister endpoint");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    bus.registerEndpoint("ep_unreg");
    auto result = bus.unregisterEndpoint("ep_unreg");
    ASSERT(result == IpcResult::SUCCESS, "Should unregister successfully");
    ASSERT(!bus.isEndpointRegistered("ep_unreg"), "Endpoint should not be registered");
    PASS();
    return true;
}

bool test_send_message() {
    TEST("Send message to endpoint");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture capture;
    bus.registerEndpoint("ep_src");
    bus.registerEndpoint("ep_dst", "app1", [&capture](const Message& msg) {
        capture.received = true;
        capture.last_message = msg;
        capture.receive_count++;
        return true;
    });

    auto msgId = bus.send("ep_src", "ep_dst", "test_type", "hello");
    ASSERT(capture.received, "Message should be received");
    ASSERT(capture.receive_count == 1, "Should receive 1 message");
    ASSERT(capture.last_message.payload == "hello", "Payload should match");
    ASSERT(capture.last_message.type == "test_type", "Type should match");
    ASSERT(capture.last_message.source == "ep_src", "Source should match");
    ASSERT(capture.last_message.target == "ep_dst", "Target should match");
    PASS();
    return true;
}

bool test_send_nonexistent_target() {
    TEST("Send to non-existent endpoint");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    bus.registerEndpoint("ep_src2");

    bool delivery_failed = false;
    bus.setDeliveryCallback([&delivery_failed](const std::string& msgId, IpcResult result) {
        if (result != IpcResult::SUCCESS) delivery_failed = true;
    });

    bus.send("ep_src2", "nonexistent", "test", "data");
    ASSERT(delivery_failed, "Delivery should fail for non-existent endpoint");
    PASS();
    return true;
}

bool test_broadcast_message() {
    TEST("Broadcast message to all endpoints");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    int receive_count = 0;
    bus.registerEndpoint("ep_b1");
    bus.registerEndpoint("ep_b2", "", [&receive_count](const Message&) {
        receive_count++;
        return true;
    });
    bus.registerEndpoint("ep_b3", "", [&receive_count](const Message&) {
        receive_count++;
        return true;
    });

    bus.broadcast("ep_b1", "broadcast_type", "announcement");
    ASSERT(receive_count == 2, "Should deliver to 2 endpoints (excluding sender)");
    PASS();
    return true;
}

bool test_round_robin() {
    TEST("Round-robin message delivery");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    int ep_a_count = 0;
    int ep_b_count = 0;
    int ep_c_count = 0;

    bus.registerEndpoint("rr_src");
    bus.registerEndpoint("rr_a", "", [&ep_a_count](const Message&) { ep_a_count++; return true; });
    bus.registerEndpoint("rr_b", "", [&ep_b_count](const Message&) { ep_b_count++; return true; });
    bus.registerEndpoint("rr_c", "", [&ep_c_count](const Message&) { ep_c_count++; return true; });

    bus.sendRoundRobin("rr_src", "rr_type", "msg1");
    bus.sendRoundRobin("rr_src", "rr_type", "msg2");
    bus.sendRoundRobin("rr_src", "rr_type", "msg3");

    int total = ep_a_count + ep_b_count + ep_c_count;
    ASSERT(total == 3, "Should deliver 3 messages total");
    // Each endpoint should get exactly 1 (round-robin)
    ASSERT(ep_a_count == 1, "Endpoint A should get 1 message");
    ASSERT(ep_b_count == 1, "Endpoint B should get 1 message");
    ASSERT(ep_c_count == 1, "Endpoint C should get 1 message");
    PASS();
    return true;
}

bool test_message_params() {
    TEST("Message parameters");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture capture;
    bus.registerEndpoint("ep_src3");
    bus.registerEndpoint("ep_dst3", "app3", [&capture](const Message& msg) {
        capture.received = true;
        capture.last_message = msg;
        return true;
    });

    std::unordered_map<std::string, std::string> params;
    params["key1"] = "value1";
    params["key2"] = "value2";
    bus.send("ep_src3", "ep_dst3", "param_test", "payload", params);

    ASSERT(capture.received, "Message should be received");
    ASSERT(capture.last_message.params.size() == 2, "Should have 2 params");
    ASSERT(capture.last_message.params.at("key1") == "value1", "Param key1 should match");
    ASSERT(capture.last_message.params.at("key2") == "value2", "Param key2 should match");
    PASS();
    return true;
}

bool test_endpoint_state() {
    TEST("Endpoint state management");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture capture;
    bus.registerEndpoint("ep_state_src");
    bus.registerEndpoint("ep_state_dst", "app", [&capture](const Message& msg) {
        capture.received = true;
        capture.receive_count++;
        return true;
    });

    // Set to BLOCKED - should not receive
    bus.setEndpointState("ep_state_dst", EndpointState::BLOCKED);
    ASSERT(!bus.isEndpointActive("ep_state_dst"), "Endpoint should not be active when BLOCKED");

    bus.send("ep_state_src", "ep_state_dst", "test", "msg1");
    ASSERT(!capture.received, "Should not receive when BLOCKED");

    // Set back to ACTIVE
    bus.setEndpointState("ep_state_dst", EndpointState::ACTIVE);
    ASSERT(bus.isEndpointActive("ep_state_dst"), "Endpoint should be active");

    bus.send("ep_state_src", "ep_state_dst", "test", "msg2");
    ASSERT(capture.received, "Should receive when ACTIVE");
    ASSERT(capture.receive_count == 1, "Should have received 1 message");
    PASS();
    return true;
}

bool test_allowed_types() {
    TEST("Allowed message types");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture capture;
    bus.registerEndpoint("ep_type_src");
    bus.registerEndpoint("ep_type_dst", "app", [&capture](const Message& msg) {
        capture.received = true;
        capture.receive_count++;
        return true;
    });

    // Restrict to only "allowed_type"
    bus.addAllowedType("ep_type_dst", "allowed_type");

    // Send allowed type
    capture.received = false;
    bus.send("ep_type_src", "ep_type_dst", "allowed_type", "msg1");
    ASSERT(capture.received, "Should receive allowed type");

    // Send disallowed type
    capture.received = false;
    bus.send("ep_type_src", "ep_type_dst", "disallowed_type", "msg2");
    ASSERT(!capture.received, "Should not receive disallowed type");

    // Remove restriction
    bus.removeAllowedType("ep_type_dst", "allowed_type");
    capture.received = false;
    bus.send("ep_type_src", "ep_type_dst", "any_type", "msg3");
    ASSERT(capture.received, "Should receive any type when no restrictions");
    PASS();
    return true;
}

bool test_message_statistics() {
    TEST("Message statistics");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("stat_src");
    bus.registerEndpoint("stat_dst", "app", [](const Message&) { return true; });

    bus.send("stat_src", "stat_dst", "type1", "msg1");
    bus.send("stat_src", "stat_dst", "type2", "msg2");
    bus.send("stat_src", "stat_dst", "type3", "msg3");

    ASSERT(bus.getTotalMessagesSent() == 3, "Should have sent 3 messages");
    ASSERT(bus.getTotalMessagesDelivered() == 3, "Should have delivered 3 messages");
    ASSERT(bus.getMessagesReceivedBy("stat_dst") == 3, "Destination should have received 3");
    ASSERT(bus.getMessagesSentBy("stat_src") == 3, "Source should have sent 3");
    PASS();
    return true;
}

bool test_endpoint_state_callback() {
    TEST("Endpoint state change callback");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    std::string callback_ep;
    EndpointState callback_old = EndpointState::INACTIVE;
    EndpointState callback_new = EndpointState::INACTIVE;
    int callback_count = 0;

    bus.setEndpointStateCallback([&](const std::string& epId, EndpointState oldState, EndpointState newState) {
        callback_ep = epId;
        callback_old = oldState;
        callback_new = newState;
        callback_count++;
    });

    bus.registerEndpoint("ep_callback");
    bus.setEndpointState("ep_callback", EndpointState::BLOCKED);

    ASSERT(callback_count > 0, "Callback should have been called");
    ASSERT(callback_ep == "ep_callback", "Callback should have correct endpoint ID");
    ASSERT(callback_new == EndpointState::BLOCKED, "New state should be BLOCKED");
    PASS();
    return true;
}

bool test_delivery_callback() {
    TEST("Delivery callback");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    IpcResult delivery_result = IpcResult::SUCCESS;
    std::string delivery_msg_id;
    int callback_count = 0;

    bus.setDeliveryCallback([&](const std::string& msgId, IpcResult result) {
        delivery_msg_id = msgId;
        delivery_result = result;
        callback_count++;
    });

    bus.registerEndpoint("del_src");
    bus.registerEndpoint("del_dst", "app", [](const Message&) { return true; });

    auto msgId = bus.send("del_src", "del_dst", "test", "payload");

    ASSERT(callback_count > 0, "Delivery callback should have been called");
    ASSERT(delivery_result == IpcResult::SUCCESS, "Delivery result should be SUCCESS");
    ASSERT(delivery_msg_id == msgId, "Message ID should match");
    PASS();
    return true;
}

bool test_no_handler() {
    TEST("Send to endpoint without handler");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("noh_src");
    bus.registerEndpoint("noh_dst");  // No handler

    bool delivery_failed = false;
    bus.setDeliveryCallback([&](const std::string&, IpcResult result) {
        if (result != IpcResult::SUCCESS) delivery_failed = true;
    });

    bus.send("noh_src", "noh_dst", "test", "data");
    ASSERT(delivery_failed, "Delivery should fail without handler");
    PASS();
    return true;
}

bool test_get_registered_endpoints() {
    TEST("Get registered endpoints list");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("ep_list1");
    bus.registerEndpoint("ep_list2");
    bus.registerEndpoint("ep_list3");

    auto endpoints = bus.getRegisteredEndpoints();
    ASSERT(endpoints.size() == 3, "Should have 3 endpoints");
    PASS();
    return true;
}

bool test_get_active_endpoints() {
    TEST("Get active endpoints list");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("ep_act1");
    bus.registerEndpoint("ep_act2");
    bus.registerEndpoint("ep_act3");
    bus.setEndpointState("ep_act3", EndpointState::BLOCKED);

    auto active = bus.getActiveEndpoints();
    ASSERT(active.size() == 2, "Should have 2 active endpoints");
    PASS();
    return true;
}

bool test_set_handler() {
    TEST("Set endpoint handler after registration");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture capture;
    bus.registerEndpoint("ep_set_src");
    bus.registerEndpoint("ep_set_dst");  // No handler initially

    bus.send("ep_set_src", "ep_set_dst", "test", "msg1");
    ASSERT(!capture.received, "Should not receive without handler");

    bus.setEndpointHandler("ep_set_dst", [&capture](const Message& msg) {
        capture.received = true;
        capture.last_message = msg;
        return true;
    });

    capture.received = false;
    bus.send("ep_set_src", "ep_set_dst", "test", "msg2");
    ASSERT(capture.received, "Should receive after handler is set");
    ASSERT(capture.last_message.payload == "msg2", "Payload should match");
    PASS();
    return true;
}

bool test_owner_app() {
    TEST("Endpoint owner app");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("ep_owner", "com.test.app");
    auto info = bus.getEndpointInfo("ep_owner");
    ASSERT(info.owner_app == "com.test.app", "Owner app should match");
    ASSERT(info.id == "ep_owner", "Endpoint ID should match");
    ASSERT(info.state == EndpointState::ACTIVE, "State should be ACTIVE");
    PASS();
    return true;
}

bool test_reply_message() {
    TEST("Reply message delivery");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    MessageCapture srcCapture;
    bus.registerEndpoint("ep_reply_src", "app_src", [&srcCapture](const Message& msg) {
        srcCapture.received = true;
        srcCapture.last_message = msg;
        srcCapture.receive_count++;
        return true;
    });
    bus.registerEndpoint("ep_reply_dst", "app_dst", [](const Message&) { return true; });

    auto originalId = bus.send("ep_reply_src", "ep_reply_dst", "request", "ping");
    auto replyId = bus.reply("ep_reply_dst", originalId, "pong");

    ASSERT(!replyId.empty(), "Reply should have a message ID");
    ASSERT(srcCapture.received, "Source endpoint should receive the reply");
    ASSERT(srcCapture.last_message.payload == "pong", "Reply payload should be pong");
    ASSERT(srcCapture.last_message.reply_to == originalId, "Reply should reference original message");
    ASSERT(srcCapture.last_message.source == "ep_reply_dst", "Reply source should be ep_reply_dst");
    ASSERT(srcCapture.last_message.target == "ep_reply_src", "Reply target should be ep_reply_src");
    PASS();
    return true;
}

bool test_result_to_string() {
    TEST("Result to string conversion");
    ASSERT(std::string(MessageBus::resultToString(IpcResult::SUCCESS)) == "SUCCESS", "SUCCESS string");
    ASSERT(std::string(MessageBus::resultToString(IpcResult::ENDPOINT_NOT_FOUND)) == "ENDPOINT_NOT_FOUND", "ENDPOINT_NOT_FOUND string");
    ASSERT(std::string(MessageBus::resultToString(IpcResult::PERMISSION_DENIED)) == "PERMISSION_DENIED", "PERMISSION_DENIED string");
    ASSERT(std::string(MessageBus::stateToString(EndpointState::ACTIVE)) == "ACTIVE", "ACTIVE string");
    ASSERT(std::string(MessageBus::stateToString(EndpointState::BLOCKED)) == "BLOCKED", "BLOCKED string");
    ASSERT(std::string(MessageBus::priorityToString(MessagePriority::URGENT)) == "URGENT", "URGENT string");
    ASSERT(std::string(MessageBus::deliveryToString(DeliveryMode::BROADCAST)) == "BROADCAST", "BROADCAST string");
    PASS();
    return true;
}

bool test_broadcast_no_eligible() {
    TEST("Broadcast with no eligible endpoints");
    auto& bus = MessageBus::getInstance();
    bus.clear();

    bus.registerEndpoint("ep_bcast_solo");

    bool delivery_failed = false;
    bus.setDeliveryCallback([&](const std::string&, IpcResult result) {
        if (result != IpcResult::SUCCESS) delivery_failed = true;
    });

    bus.broadcast("ep_bcast_solo", "test", "data");
    ASSERT(delivery_failed, "Broadcast should fail with no eligible endpoints");
    PASS();
    return true;
}

bool test_round_robin_no_candidates() {
    TEST("Round-robin with no candidates");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    bus.registerEndpoint("rr_empty");

    bool delivery_failed = false;
    bus.setDeliveryCallback([&](const std::string&, IpcResult result) {
        if (result != IpcResult::SUCCESS) delivery_failed = true;
    });

    bus.sendRoundRobin("rr_empty", "test", "data");
    ASSERT(delivery_failed, "Round-robin should fail with no candidates");
    PASS();
    return true;
}

bool test_clear_all() {
    TEST("Clear all endpoints");
    auto& bus = MessageBus::getInstance();
    bus.clear();
    bus.registerEndpoint("ep_clear1");
    bus.registerEndpoint("ep_clear2");
    bus.registerEndpoint("ep_clear3");

    bus.clear();
    ASSERT(bus.getEndpointCount() == 0, "Should have 0 endpoints after clear");
    ASSERT(bus.getTotalMessagesSent() == 0, "Stats should be reset");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - IPC Message Bus Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_register_endpoint();
    all_pass &= test_duplicate_endpoint();
    all_pass &= test_unregister_endpoint();
    all_pass &= test_send_message();
    all_pass &= test_send_nonexistent_target();
    all_pass &= test_broadcast_message();
    all_pass &= test_round_robin();
    all_pass &= test_message_params();
    all_pass &= test_endpoint_state();
    all_pass &= test_allowed_types();
    all_pass &= test_message_statistics();
    all_pass &= test_endpoint_state_callback();
    all_pass &= test_delivery_callback();
    all_pass &= test_no_handler();
    all_pass &= test_get_registered_endpoints();
    all_pass &= test_get_active_endpoints();
    all_pass &= test_set_handler();
    all_pass &= test_owner_app();
    all_pass &= test_reply_message();
    all_pass &= test_result_to_string();
    all_pass &= test_broadcast_no_eligible();
    all_pass &= test_round_robin_no_candidates();
    all_pass &= test_clear_all();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
