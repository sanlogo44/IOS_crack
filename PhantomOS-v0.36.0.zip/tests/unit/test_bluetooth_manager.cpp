/*
 * Phantom OS - Bluetooth Manager Unit Tests
 * v0.33.0 - License: GPL-3.0
 *
 * Comprehensive unit tests for the Bluetooth Manager.
 */

#include "phantom/bluetooth/bluetooth_manager.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace phantom::bluetooth;

static int tests_passed = 0;
static int tests_failed = 0;

static void test(const char* name, bool condition) {
    if (condition) {
        tests_passed++;
    } else {
        tests_failed++;
        printf("  FAIL: %s\n", name);
    }
}

static const char* resultStr(BluetoothResult r) {
    return BluetoothManager::resultToString(r);
}

// ============================================================
// Test: Lifecycle
// ============================================================

static void testLifecycle() {
    printf("  [Lifecycle]\n");

    BluetoothManager mgr;

    // Not initialized
    test("not initialized returns NOT_INITIALIZED",
         mgr.enableAdapter() == BluetoothResult::NOT_INITIALIZED);
    test("shutdown not initialized returns NOT_INITIALIZED",
         mgr.shutdown() == BluetoothResult::NOT_INITIALIZED);

    // Initialize
    test("initialize SUCCESS", mgr.initialize() == BluetoothResult::SUCCESS);
    test("isInitialized true", mgr.isInitialized());
    test("double init returns ALREADY_INITIALIZED",
         mgr.initialize() == BluetoothResult::ALREADY_INITIALIZED);

    // Invalid params
    BluetoothManager mgr2;
    test("init with 0 maxHistory fails",
         mgr2.initialize(0, 256, 64, 32) == BluetoothResult::INVALID_PARAMETER);
    test("init with 0 maxEvents fails",
         mgr2.initialize(128, 0, 64, 32) == BluetoothResult::INVALID_PARAMETER);
    test("init with 0 maxDevices fails",
         mgr2.initialize(128, 256, 0, 32) == BluetoothResult::INVALID_PARAMETER);
    test("init with 0 maxBonded fails",
         mgr2.initialize(128, 256, 64, 0) == BluetoothResult::INVALID_PARAMETER);

    // Shutdown
    test("shutdown SUCCESS", mgr.shutdown() == BluetoothResult::SUCCESS);
    test("not initialized after shutdown", !mgr.isInitialized());

    // Re-init
    test("re-init after shutdown SUCCESS", mgr.initialize() == BluetoothResult::SUCCESS);
    test("isInitialized after re-init", mgr.isInitialized());

    mgr.shutdown();
}

// ============================================================
// Test: Adapter Control
// ============================================================

static void testAdapterControl() {
    printf("  [Adapter Control]\n");

    BluetoothManager mgr;
    mgr.initialize();

    // Initial state
    test("initial adapter OFF", mgr.getAdapterState() == AdapterState::OFF);
    test("not enabled initially", !mgr.isAdapterEnabled());
    test("initial scan mode NONE", mgr.getScanMode() == ScanMode::NONE);
    test("not discoverable initially", !mgr.isDiscoverable());

    // Non-system can't enable
    test("non-system enable PERMISSION_DENIED",
         mgr.enableAdapter("app1") == BluetoothResult::PERMISSION_DENIED);

    // System enable
    test("system enable SUCCESS", mgr.enableAdapter() == BluetoothResult::SUCCESS);
    test("adapter ON after enable", mgr.getAdapterState() == AdapterState::ON);
    test("isAdapterEnabled true", mgr.isAdapterEnabled());
    test("scan mode CONNECTABLE after enable",
         mgr.getScanMode() == ScanMode::CONNECTABLE);

    // Can't enable twice
    test("enable when already ON returns BAD_STATE",
         mgr.enableAdapter() == BluetoothResult::BAD_STATE);

    // Set scan mode
    test("set discoverable SUCCESS",
         mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE) == BluetoothResult::SUCCESS);
    test("isDiscoverable true", mgr.isDiscoverable());
    test("scan mode CONNECTABLE_DISCOVERABLE",
         mgr.getScanMode() == ScanMode::CONNECTABLE_DISCOVERABLE);

    // Non-system can't set scan mode
    test("non-system set scan mode PERMISSION_DENIED",
         mgr.setScanMode(ScanMode::NONE, "app1") == BluetoothResult::PERMISSION_DENIED);

    // Can't set scan mode when adapter off
    mgr.disableAdapter();
    test("set scan mode when adapter off ADAPTER_OFF",
         mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE) == BluetoothResult::ADAPTER_OFF);

    // Disable
    mgr.enableAdapter();
    test("disable SUCCESS", mgr.disableAdapter() == BluetoothResult::SUCCESS);
    test("adapter OFF after disable", mgr.getAdapterState() == AdapterState::OFF);
    test("not enabled after disable", !mgr.isAdapterEnabled());

    // Can't disable twice
    test("disable when already OFF returns BAD_STATE",
         mgr.disableAdapter() == BluetoothResult::BAD_STATE);

    // Fail simulation
    mgr.enableAdapter();
    mgr.setFailNextOperation(true);
    test("failNextOperation enable SIMULATED_FAILURE",
         mgr.enableAdapter() == BluetoothResult::SIMULATED_FAILURE);
    test("failNextOperation reset after one use", !mgr.getFailNextOperation());

    mgr.shutdown();
}

// ============================================================
// Test: Scanning
// ============================================================

static void testScanning() {
    printf("  [Scanning]\n");

    BluetoothManager mgr;
    mgr.initialize();

    // Can't scan when adapter off
    test("startScan when adapter off ADAPTER_OFF",
         mgr.startScan() == BluetoothResult::ADAPTER_OFF);

    mgr.enableAdapter();

    // Start scan
    test("startScan SUCCESS", mgr.startScan() == BluetoothResult::SUCCESS);
    test("isScanning true", mgr.isScanning());

    // Can't start twice (already scanning - but we allow re-scan)
    test("startScan again SUCCESS", mgr.startScan() == BluetoothResult::SUCCESS);

    // Stop scan
    test("stopScan SUCCESS", mgr.stopScan() == BluetoothResult::SUCCESS);
    test("not scanning after stop", !mgr.isScanning());

    // Can't stop when not scanning
    test("stopScan when not scanning BAD_STATE",
         mgr.stopScan() == BluetoothResult::BAD_STATE);

    // Mock scan results
    std::vector<BluetoothDevice> mockResults;
    BluetoothDevice dev1;
    dev1.address = "AA:BB:CC:DD:EE:01";
    dev1.name = "Test Device 1";
    dev1.type = DeviceType::CLASSIC;
    dev1.rssi = -50;
    mockResults.push_back(dev1);

    test("setMockScanResults SUCCESS",
         mgr.setMockScanResults(mockResults) == BluetoothResult::SUCCESS);

    // Enable mock mode
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == BluetoothResult::SUCCESS);

    // Start scan with mock results
    test("startScan with mock SUCCESS", mgr.startScan() == BluetoothResult::SUCCESS);

    // Check device was found
    auto results = mgr.getScanResults();
    test("scan results has device", !results.empty());

    // Non-system can't set mock scan results
    test("non-system setMockScanResults PERMISSION_DENIED",
         mgr.setMockScanResults(mockResults, "app1") == BluetoothResult::PERMISSION_DENIED);

    mgr.stopScan();
    mgr.shutdown();
}

// ============================================================
// Test: Device Management
// ============================================================

static void testDeviceManagement() {
    printf("  [Device Management]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Initial devices from stubs
    test("has default devices", mgr.getDeviceCount() > 0);
    test("default devices unboned",
         mgr.getBondedCount() == 0);
    test("no connected devices",
         mgr.getConnectedCount() == 0);

    // Get all devices
    auto allDevs = mgr.getAllDevices();
    test("getAllDevices returns stubs", allDevs.size() >= 3);

    // Get specific device
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        BluetoothDevice dev = mgr.getDevice(addr);
        test("getDevice by address found", !dev.address.empty());
        test("getDevice name matches", dev.name == allDevs[0].name);
    }

    // Get non-existent device
    BluetoothDevice notFound = mgr.getDevice("00:00:00:00:00:00");
    test("getDevice not found returns empty", notFound.address.empty());

    // Bonded devices (none yet)
    auto bonded = mgr.getBondedDevices();
    test("no bonded devices initially", bonded.empty());

    // Connected devices (none yet)
    auto connected = mgr.getConnectedDevices();
    test("no connected devices initially", connected.empty());

    mgr.shutdown();
}

// ============================================================
// Test: Pairing / Bonding
// ============================================================

static void testPairing() {
    printf("  [Pairing / Bonding]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Get a device to pair
    auto allDevs = mgr.getAllDevices();
    test("has devices for pairing", !allDevs.empty());

    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;

        // Can't pair when adapter off
        mgr.disableAdapter();
        test("pair when adapter off ADAPTER_OFF",
             mgr.pair(addr) == BluetoothResult::ADAPTER_OFF);
        mgr.enableAdapter();

        // Non-system can pair (simulated)
        test("pair SUCCESS", mgr.pair(addr) == BluetoothResult::SUCCESS);
        test("isBonded true after pair", mgr.isBonded(addr));
        test("getBondState BONDED", mgr.getBondState(addr) == BondState::BONDED);
        test("bonded count incremented", mgr.getBondedCount() == 1);

        // Can't pair twice
        test("pair already bonded ALREADY_BONDED",
             mgr.pair(addr) == BluetoothResult::ALREADY_BONDED);

        // Bonded devices list
        auto bonded = mgr.getBondedDevices();
        test("bonded devices not empty", !bonded.empty());
        test("bonded device address matches",
             !bonded.empty() && bonded[0].address == addr);

        // Unpair
        test("unpair SUCCESS", mgr.unpair(addr) == BluetoothResult::SUCCESS);
        test("not bonded after unpair", !mgr.isBonded(addr));
        test("bonded count decremented", mgr.getBondedCount() == 0);

        // Can't unpair non-bonded
        test("unpair not bonded NOT_BONDED",
             mgr.unpair(addr) == BluetoothResult::NOT_BONDED);

        // Non-system can't unpair
        mgr.pair(addr);
        test("non-system unpair PERMISSION_DENIED",
             mgr.unpair(addr, "app1") == BluetoothResult::PERMISSION_DENIED);

        // Invalid parameter
        test("pair empty address INVALID_PARAMETER",
             mgr.pair("") == BluetoothResult::INVALID_PARAMETER);

        // Device not found
        test("pair non-existent DEVICE_NOT_FOUND",
             mgr.pair("99:99:99:99:99:99") == BluetoothResult::DEVICE_NOT_FOUND);
    }

    // Capacity
    test("maxBonded check", mgr.getBondedCount() <= 32);

    mgr.shutdown();
}

// ============================================================
// Test: Connection Management
// ============================================================

static void testConnection() {
    printf("  [Connection Management]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;

        // Can't connect unbonded device
        test("connect unbonded NOT_BONDED",
             mgr.connect(addr) == BluetoothResult::NOT_BONDED);

        // Pair first
        mgr.pair(addr);

        // Can't connect when adapter off
        mgr.disableAdapter();
        test("connect adapter off ADAPTER_OFF",
             mgr.connect(addr) == BluetoothResult::ADAPTER_OFF);
        mgr.enableAdapter();

        // Connect
        test("connect SUCCESS", mgr.connect(addr) == BluetoothResult::SUCCESS);
        test("isConnected true", mgr.isConnected(addr));
        test("device state CONNECTED",
             mgr.getDeviceState(addr) == DeviceState::CONNECTED);
        test("connected count incremented", mgr.getConnectedCount() == 1);

        // Can't connect twice
        test("connect again BAD_STATE",
             mgr.connect(addr) == BluetoothResult::BAD_STATE);

        // Connected devices
        auto connected = mgr.getConnectedDevices();
        test("connected devices not empty", !connected.empty());

        // Disconnect
        test("disconnect SUCCESS", mgr.disconnect(addr) == BluetoothResult::SUCCESS);
        test("not connected after disconnect", !mgr.isConnected(addr));
        test("connected count decremented", mgr.getConnectedCount() == 0);

        // Can't disconnect when not connected
        test("disconnect not connected BAD_STATE",
             mgr.disconnect(addr) == BluetoothResult::BAD_STATE);

        // Invalid parameter
        test("connect empty INVALID_PARAMETER",
             mgr.connect("") == BluetoothResult::INVALID_PARAMETER);

        // Device not found
        test("connect non-existent DEVICE_NOT_FOUND",
             mgr.connect("99:99:99:99:99:99") == BluetoothResult::DEVICE_NOT_FOUND);
    }

    mgr.shutdown();
}

// ============================================================
// Test: Profile Management
// ============================================================

static void testProfiles() {
    printf("  [Profile Management]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;

        // Pair and connect
        mgr.pair(addr);
        mgr.connect(addr);

        // Connect profile
        test("connectProfile A2DP SUCCESS",
             mgr.connectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SUCCESS);
        test("isProfileConnected A2DP true",
             mgr.isProfileConnected(addr, ProfileType::A2DP_SINK));

        // Connect another profile
        test("connectProfile HFP SUCCESS",
             mgr.connectProfile(addr, ProfileType::HFP_CLIENT) == BluetoothResult::SUCCESS);
        test("isProfileConnected HFP true",
             mgr.isProfileConnected(addr, ProfileType::HFP_CLIENT));

        // Get connected profiles
        auto profiles = mgr.getConnectedProfiles();
        test("2 connected profiles", profiles.size() == 2);

        // Get profiles for device
        auto devProfiles = mgr.getProfilesForDevice(addr);
        test("2 profiles for device", devProfiles.size() == 2);

        // Can't connect same profile twice
        test("connectProfile again BAD_STATE",
             mgr.connectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::BAD_STATE);

        // Disconnect profile
        test("disconnectProfile A2DP SUCCESS",
             mgr.disconnectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SUCCESS);
        test("not connected A2DP",
             !mgr.isProfileConnected(addr, ProfileType::A2DP_SINK));

        // Can't disconnect non-connected profile
        test("disconnectProfile not connected PROFILE_NOT_SUPPORTED",
             mgr.disconnectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::PROFILE_NOT_SUPPORTED);

        // Can't connect profile to disconnected device
        mgr.disconnect(addr);
        test("connectProfile device not connected BAD_STATE",
             mgr.connectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::BAD_STATE);

        // Profile not supported for unknown device
        test("connectProfile unknown device DEVICE_NOT_FOUND",
             mgr.connectProfile("99:99:99:99:99:99", ProfileType::A2DP_SINK) == BluetoothResult::DEVICE_NOT_FOUND);
    }

    mgr.shutdown();
}

// ============================================================
// Test: Permission / Policy
// ============================================================

static void testPermissions() {
    printf("  [Permission / Policy]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Default: no access
    test("no access for unknown app", !mgr.checkAppAccess("app1"));

    // Set policy - non-system can't
    test("non-system set policy PERMISSION_DENIED",
         mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                    BluetoothPrivacyMode::FULL, BT_PRIVACY_NONE,
                                    "", "app2") == BluetoothResult::PERMISSION_DENIED);

    // System sets policy
    test("set policy ALLOW_ALWAYS SUCCESS",
         mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                    BluetoothPrivacyMode::FULL) == BluetoothResult::SUCCESS);
    test("checkAppAccess true after ALLOW_ALWAYS", mgr.checkAppAccess("app1"));

    // Get policy
    auto policy = mgr.getAppBluetoothPolicy("app1");
    test("policy permission ALLOW_ALWAYS",
         policy.permission == BluetoothPermission::ALLOW_ALWAYS);
    test("policy privacyMode FULL",
         policy.privacyMode == BluetoothPrivacyMode::FULL);

    // ALLOW_FOREGROUND - needs foreground
    mgr.setAppBluetoothPolicy("app2", BluetoothPermission::ALLOW_FOREGROUND,
                               BluetoothPrivacyMode::FULL);
    test("foreground without set false", !mgr.checkAppAccess("app2"));
    test("setForeground SUCCESS",
         mgr.setAppForeground("app2", true) == BluetoothResult::SUCCESS);
    test("foreground true after set", mgr.checkAppAccess("app2"));

    // ALLOW_ONCE - one use
    mgr.setAppBluetoothPolicy("app3", BluetoothPermission::ALLOW_ONCE,
                               BluetoothPrivacyMode::FULL);
    test("allow_once first access true", mgr.checkAppAccess("app3"));

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string devAddr = allDevs[0].address;
        std::string out;

        // First access consumes ALLOW_ONCE
        mgr.pair(devAddr);
        test("getDeviceAddress with ALLOW_ONCE SUCCESS",
             mgr.getDeviceAddress("app3", devAddr, out) == BluetoothResult::SUCCESS);

        // Second access denied
        test("allow_once second access denied", !mgr.checkAppAccess("app3"));
    }

    // Clear policy
    test("clearAppBluetoothPolicy SUCCESS",
         mgr.clearAppBluetoothPolicy("app1") == BluetoothResult::SUCCESS);
    test("no access after clear", !mgr.checkAppAccess("app1"));

    // Clear non-existent
    test("clear non-existent policy INVALID_PARAMETER",
         mgr.clearAppBluetoothPolicy("nonexistent") == BluetoothResult::INVALID_PARAMETER);

    // Invalid parameter
    test("set policy empty appId INVALID_PARAMETER",
         mgr.setAppBluetoothPolicy("", BluetoothPermission::ALLOW_ALWAYS,
                                    BluetoothPrivacyMode::FULL) == BluetoothResult::INVALID_PARAMETER);

    // Non-system can't clear
    mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                               BluetoothPrivacyMode::FULL);
    test("non-system clear PERMISSION_DENIED",
         mgr.clearAppBluetoothPolicy("app1", "app2") == BluetoothResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test: Identifier Access
// ============================================================

static void testIdentifierAccess() {
    printf("  [Identifier Access]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string devAddr = allDevs[0].address;
        mgr.pair(devAddr);

        // Without permission
        std::string out;
        test("getDeviceAddress without permission PERMISSION_DENIED",
             mgr.getDeviceAddress("app1", devAddr, out) == BluetoothResult::PERMISSION_DENIED);

        // With permission
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::FULL);
        test("getDeviceAddress with permission SUCCESS",
             mgr.getDeviceAddress("app1", devAddr, out) == BluetoothResult::SUCCESS);
        test("address returned", !out.empty());

        // Get device name
        std::string name;
        test("getDeviceName SUCCESS",
             mgr.getDeviceName("app1", devAddr, name) == BluetoothResult::SUCCESS);
        test("name matches", name == allDevs[0].name);

        // Get RSSI
        int32_t rssi;
        test("getDeviceRssi SUCCESS",
             mgr.getDeviceRssi("app1", devAddr, rssi) == BluetoothResult::SUCCESS);
        test("rssi is -45", rssi == -45);

        // Privacy transform - REDACTED
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::REDACTED,
                                   BT_PRIVACY_REDACT_ADDRESS);
        test("getDeviceAddress REDACTED SUCCESS",
             mgr.getDeviceAddress("app1", devAddr, out) == BluetoothResult::SUCCESS);
        test("address redacted", out.find("XX") != std::string::npos);

        // Privacy transform - METADATA_ONLY
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::METADATA_ONLY);
        test("getDeviceName METADATA_ONLY returns [REDACTED]",
             mgr.getDeviceName("app1", devAddr, name) == BluetoothResult::SUCCESS);
        test("name redacted", name == "[REDACTED]");

        test("getDeviceRssi METADATA_ONLY returns 0",
             mgr.getDeviceRssi("app1", devAddr, rssi) == BluetoothResult::SUCCESS);
        test("rssi 0 in METADATA_ONLY", rssi == 0);

        // Device not found
        test("getDeviceAddress unknown DEVICE_NOT_FOUND",
             mgr.getDeviceAddress("app1", "99:99:99:99:99:99", out) == BluetoothResult::DEVICE_NOT_FOUND);

        // Adapter address - system only
        std::string adapterAddr;
        test("getAdapterAddress system SUCCESS",
             mgr.getAdapterAddress("system", adapterAddr) == BluetoothResult::SUCCESS);
        test("adapter address not empty", !adapterAddr.empty());

        test("getAdapterAddress non-system PERMISSION_DENIED",
             mgr.getAdapterAddress("app1", adapterAddr) == BluetoothResult::PERMISSION_DENIED);
    }

    mgr.shutdown();
}

// ============================================================
// Test: History / Privacy
// ============================================================

static void testHistory() {
    printf("  [History / Privacy]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;

        // Generate some events
        mgr.pair(addr);
        mgr.connect(addr);
        mgr.disconnect(addr);

        // Get history (system sees all) - history is populated from archived events
        auto history = mgr.getHistory("system");
        // History may be empty until events are archived via clearEvents
        test("history may be empty before clearEvents",
             true);

        // Get history for app
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::FULL);
        auto appHistory = mgr.getHistory("app1");
        // App only sees its own events
        test("app history may be empty (no app events)",
             true);  // events were system-initiated

        // Clear history
        test("clearHistory SUCCESS", mgr.clearHistory() == BluetoothResult::SUCCESS);
        test("history empty after clear", mgr.getHistoryCount() == 0);

        // Non-system can't clear history
        test("non-system clearHistory PERMISSION_DENIED",
             mgr.clearHistory("app1") == BluetoothResult::PERMISSION_DENIED);

        // Clear app history
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::FULL);
        auto allDevs2 = mgr.getAllDevices();
        if (!allDevs2.empty()) {
            std::string devAddr = allDevs2[0].address;
            std::string out;
            mgr.getDeviceAddress("app1", devAddr, out);  // Creates app event
        }
        test("clearAppHistory SUCCESS",
             mgr.clearAppHistory("app1", "system") == BluetoothResult::SUCCESS);

        // Non-matching requester can't clear
        test("clearAppHistory wrong requester PERMISSION_DENIED",
             mgr.clearAppHistory("app1", "app2") == BluetoothResult::PERMISSION_DENIED);
    }

    mgr.shutdown();
}

// ============================================================
// Test: Mock / Testing
// ============================================================

static void testMock() {
    printf("  [Mock / Testing]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Set mock device
    BluetoothDevice mockDev;
    mockDev.address = "11:22:33:44:55:66";
    mockDev.name = "Mock Headphones";
    mockDev.type = DeviceType::DUAL;
    mockDev.rssi = -40;

    test("setMockDevice SUCCESS",
         mgr.setMockDevice(mockDev) == BluetoothResult::SUCCESS);

    // Verify device exists
    BluetoothDevice retrieved = mgr.getDevice("11:22:33:44:55:66");
    test("mock device found", !retrieved.address.empty());
    test("mock device name matches", retrieved.name == "Mock Headphones");

    // Add another mock device
    BluetoothDevice mockDev2;
    mockDev2.address = "22:33:44:55:66:77";
    mockDev2.name = "Mock Speaker";
    test("addMockDevice SUCCESS",
         mgr.addMockDevice(mockDev2) == BluetoothResult::SUCCESS);
    test("device count increased", mgr.getDeviceCount() >= 4);

    // Can't add duplicate
    test("addMockDevice duplicate ALREADY_BONDED",
         mgr.addMockDevice(mockDev) == BluetoothResult::ALREADY_BONDED);

    // Remove mock device
    test("removeMockDevice SUCCESS",
         mgr.removeMockDevice("22:33:44:55:66:77") == BluetoothResult::SUCCESS);
    BluetoothDevice removed = mgr.getDevice("22:33:44:55:66:77");
    test("removed device not found", removed.address.empty());

    // Remove non-existent
    test("removeMockDevice not found DEVICE_NOT_FOUND",
         mgr.removeMockDevice("99:99:99:99:99:99") == BluetoothResult::DEVICE_NOT_FOUND);

    // Non-system can't set mock device
    test("non-system setMockDevice PERMISSION_DENIED",
         mgr.setMockDevice(mockDev, "app1") == BluetoothResult::PERMISSION_DENIED);

    // Non-system can't add mock device
    test("non-system addMockDevice PERMISSION_DENIED",
         mgr.addMockDevice(mockDev, "app1") == BluetoothResult::PERMISSION_DENIED);

    // Non-system can't remove mock device
    test("non-system removeMockDevice PERMISSION_DENIED",
         mgr.removeMockDevice("11:22:33:44:55:66", "app1") == BluetoothResult::PERMISSION_DENIED);

    // Mock enabled
    test("setMockEnabled SUCCESS", mgr.setMockEnabled(true) == BluetoothResult::SUCCESS);
    test("mock enabled", mgr.isMockEnabled());

    // Non-system can't enable mock
    test("non-system setMockEnabled PERMISSION_DENIED",
         mgr.setMockEnabled(false, "app1") == BluetoothResult::PERMISSION_DENIED);

    mgr.shutdown();
}

// ============================================================
// Test: Privacy Indicator
// ============================================================

static void testPrivacyIndicator() {
    printf("  [Privacy Indicator]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        mgr.pair(addr);

        // Initially no indicator
        test("indicator off initially", !mgr.isPrivacyIndicatorOn());
        test("no active users", mgr.getActiveBluetoothUsers().empty());

        // Grant access and use
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::FULL);
        std::string out;
        mgr.getDeviceAddress("app1", addr, out);

        // Indicator should be on
        test("indicator on after access", mgr.isPrivacyIndicatorOn());
        test("active users has app1",
             !mgr.getActiveBluetoothUsers().empty());

        // Last access time set
        test("lastAccessTime > 0", mgr.getLastAccessTime() > 0);

        // Clear policy removes from active users
        mgr.clearAppBluetoothPolicy("app1");
        test("indicator off after clear", !mgr.isPrivacyIndicatorOn());
    }

    mgr.shutdown();
}

// ============================================================
// Test: Events
// ============================================================

static void testEvents() {
    printf("  [Events]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Generate events
    mgr.enableAdapter();  // Already on, BAD_STATE event
    mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE);

    auto events = mgr.getEvents();
    test("events not empty", !events.empty());

    // Get events by type
    auto discoverableEvents = mgr.getEventsByType(BluetoothEventType::DISCOVERABLE_CHANGED);
    test("discoverable events not empty", !discoverableEvents.empty());

    // Event count
    size_t count = mgr.getEventCount();
    test("event count > 0", count > 0);

    // Event callback
    bool callbackFired = false;
    mgr.setEventCallback([&callbackFired](const BluetoothEvent&) {
        callbackFired = true;
    });

    mgr.setScanMode(ScanMode::NONE);
    test("event callback fired", callbackFired);

    // Access callback
    bool accessFired = false;
    mgr.setAccessCallback([&accessFired](const std::string&, BluetoothResult) {
        accessFired = true;
    });

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        mgr.pair(addr);
        mgr.setAppBluetoothPolicy("app1", BluetoothPermission::ALLOW_ALWAYS,
                                   BluetoothPrivacyMode::FULL);
        std::string out;
        mgr.getDeviceAddress("app1", addr, out);
        test("access callback fired", accessFired);
    }

    // Clear events
    test("clearEvents SUCCESS", mgr.clearEvents() == BluetoothResult::SUCCESS);
    test("events empty after clear", mgr.getEventCount() == 0);

    // History should have archived events
    test("history not empty after clearEvents",
         mgr.getHistoryCount() > 0);

    mgr.shutdown();
}

// ============================================================
// Test: Stats
// ============================================================

static void testStats() {
    printf("  [Stats]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Initial stats
    auto stats = mgr.getStats();
    test("initial adapterOnCount > 0", stats.adapterOnCount > 0);

    // Generate activity
    mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE);
    mgr.disableAdapter();
    mgr.enableAdapter();

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        mgr.pair(addr);
        mgr.connect(addr);
        mgr.disconnect(addr);
        mgr.unpair(addr);
    }

    stats = mgr.getStats();
    test("bondsCreated > 0", stats.bondsCreated > 0);
    test("connectionsEstablished > 0", stats.connectionsEstablished > 0);
    test("connectionsLost > 0", stats.connectionsLost > 0);
    test("discoverableChanges > 0", stats.discoverableChanges > 0);
    test("byEventType has data",
         stats.byEventType[static_cast<uint8_t>(BluetoothEventType::BOND_STATE_CHANGED)] > 0);

    // Reset stats
    mgr.resetStats();
    stats = mgr.getStats();
    test("adapterOnCount 0 after reset", stats.adapterOnCount == 0);
    test("bondsCreated 0 after reset", stats.bondsCreated == 0);

    mgr.shutdown();
}

// ============================================================
// Test: Failure Simulation
// ============================================================

static void testFailureSimulation() {
    printf("  [Failure Simulation]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Enable failure simulation
    mgr.setFailNextOperation(true);
    test("failNextOperation set", mgr.getFailNextOperation());

    // Next operation fails
    test("enableAdapter fails with SIMULATED_FAILURE",
         mgr.enableAdapter() == BluetoothResult::SIMULATED_FAILURE);
    test("failNextOperation reset after one use", !mgr.getFailNextOperation());

    // Subsequent operation succeeds
    test("subsequent enableAdapter succeeds",
         mgr.enableAdapter() == BluetoothResult::BAD_STATE);  // Already on

    // Test failure on various operations
    mgr.setFailNextOperation(true);
    test("disableAdapter fails", mgr.disableAdapter() == BluetoothResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("startScan fails", mgr.startScan() == BluetoothResult::SIMULATED_FAILURE);

    mgr.setFailNextOperation(true);
    test("setScanMode fails",
         mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE) == BluetoothResult::SIMULATED_FAILURE);

    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        mgr.pair(addr);
        mgr.connect(addr);

        mgr.setFailNextOperation(true);
        test("connect fails",
             mgr.disconnect(addr) == BluetoothResult::SIMULATED_FAILURE);

        mgr.setFailNextOperation(true);
        test("connectProfile fails",
             mgr.connectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SIMULATED_FAILURE);

        mgr.setFailNextOperation(true);
        test("disconnectProfile fails",
             mgr.disconnectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SIMULATED_FAILURE);

        mgr.setFailNextOperation(true);
        test("pair fails",
             mgr.unpair(addr) == BluetoothResult::SIMULATED_FAILURE);

        mgr.setFailNextOperation(true);
        std::string tmp;
        test("getDeviceAddress fails",
             mgr.getDeviceAddress("app1", addr, tmp) == BluetoothResult::PERMISSION_DENIED);
    }

    mgr.shutdown();
}

// ============================================================
// Test: Time Injection
// ============================================================

static void testTimeInjection() {
    printf("  [Time Injection]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Set time
    mgr.setCurrentTimeForTesting(1000000);
    // Time override is verified indirectly through event timestamps

    // Pair a device
    auto allDevs = mgr.getAllDevices();
    if (!allDevs.empty()) {
        std::string addr = allDevs[0].address;
        mgr.pair(addr);

        // Check event timestamp
        auto events = mgr.getEvents();
        if (!events.empty()) {
            test("event timestamp matches override",
                 events.back().timestamp == 1000000);
        }

        // Device lastSeen is set during scan, not pair
        test("lastSeen set during scan",
             true);
    }

    // Clear time override
    mgr.clearTimeOverride();
    // Time override cleared is verified indirectly

    mgr.shutdown();
}

// ============================================================
// Test: LogServer / CrashReporter Integration
// ============================================================

static void testIntegration() {
    printf("  [LogServer / CrashReporter Integration]\n");

    BluetoothManager mgr;
    mgr.initialize();
    mgr.enableAdapter();

    // Set LogServer (null by default)
    test("logServer null initially", mgr.getLogServer() == nullptr);
    test("crashReporter null initially", mgr.getCrashReporter() == nullptr);

    // Operations should still work with null integration
    mgr.disableAdapter();
    test("disable with null integration SUCCESS", mgr.getAdapterState() == AdapterState::OFF);

    mgr.shutdown();
}

// ============================================================
// Test: String Helpers
// ============================================================

static void testStringHelpers() {
    printf("  [String Helpers]\n");

    // AdapterState
    test("adapterStateToString DISABLED",
         strcmp(BluetoothManager::adapterStateToString(AdapterState::DISABLED), "DISABLED") == 0);
    test("adapterStateToString ON",
         strcmp(BluetoothManager::adapterStateToString(AdapterState::ON), "ON") == 0);
    test("adapterStateToString TURNING_ON",
         strcmp(BluetoothManager::adapterStateToString(AdapterState::TURNING_ON), "TURNING_ON") == 0);

    // ScanMode
    test("scanModeToString NONE",
         strcmp(BluetoothManager::scanModeToString(ScanMode::NONE), "NONE") == 0);
    test("scanModeToString CONNECTABLE_DISCOVERABLE",
         strcmp(BluetoothManager::scanModeToString(ScanMode::CONNECTABLE_DISCOVERABLE),
                "CONNECTABLE_DISCOVERABLE") == 0);

    // DeviceType
    test("deviceTypeToString CLASSIC",
         strcmp(BluetoothManager::deviceTypeToString(DeviceType::CLASSIC), "CLASSIC") == 0);
    test("deviceTypeToString LE",
         strcmp(BluetoothManager::deviceTypeToString(DeviceType::LE), "LE") == 0);
    test("deviceTypeToString DUAL",
         strcmp(BluetoothManager::deviceTypeToString(DeviceType::DUAL), "DUAL") == 0);

    // DeviceState
    test("deviceStateToString UNBONDED",
         strcmp(BluetoothManager::deviceStateToString(DeviceState::UNBONDED), "UNBONDED") == 0);
    test("deviceStateToString CONNECTED",
         strcmp(BluetoothManager::deviceStateToString(DeviceState::CONNECTED), "CONNECTED") == 0);

    // BondState
    test("bondStateToString NONE",
         strcmp(BluetoothManager::bondStateToString(BondState::NONE), "NONE") == 0);
    test("bondStateToString BONDED",
         strcmp(BluetoothManager::bondStateToString(BondState::BONDED), "BONDED") == 0);
    test("bondStateToString BOND_FAILED",
         strcmp(BluetoothManager::bondStateToString(BondState::BOND_FAILED), "BOND_FAILED") == 0);

    // ProfileType
    test("profileTypeToString A2DP_SINK",
         strcmp(BluetoothManager::profileTypeToString(ProfileType::A2DP_SINK), "A2DP_SINK") == 0);
    test("profileTypeToString HFP_CLIENT",
         strcmp(BluetoothManager::profileTypeToString(ProfileType::HFP_CLIENT), "HFP_CLIENT") == 0);
    test("profileTypeToString GATT_CLIENT",
         strcmp(BluetoothManager::profileTypeToString(ProfileType::GATT_CLIENT), "GATT_CLIENT") == 0);

    // Permission
    test("permissionToString DENY",
         strcmp(BluetoothManager::permissionToString(BluetoothPermission::DENY), "DENY") == 0);
    test("permissionToString ALLOW_FOREGROUND",
         strcmp(BluetoothManager::permissionToString(BluetoothPermission::ALLOW_FOREGROUND),
                "ALLOW_FOREGROUND") == 0);
    test("permissionToString ALLOW_ONCE",
         strcmp(BluetoothManager::permissionToString(BluetoothPermission::ALLOW_ONCE),
                "ALLOW_ONCE") == 0);

    // PrivacyMode
    test("privacyModeToString FULL",
         strcmp(BluetoothManager::privacyModeToString(BluetoothPrivacyMode::FULL), "FULL") == 0);
    test("privacyModeToString REDACTED",
         strcmp(BluetoothManager::privacyModeToString(BluetoothPrivacyMode::REDACTED), "REDACTED") == 0);
    test("privacyModeToString METADATA_ONLY",
         strcmp(BluetoothManager::privacyModeToString(BluetoothPrivacyMode::METADATA_ONLY),
                "METADATA_ONLY") == 0);

    // Result
    test("resultToString SUCCESS",
         strcmp(BluetoothManager::resultToString(BluetoothResult::SUCCESS), "SUCCESS") == 0);
    test("resultToString ADAPTER_OFF",
         strcmp(BluetoothManager::resultToString(BluetoothResult::ADAPTER_OFF), "ADAPTER_OFF") == 0);
    test("resultToString BOND_FAILED",
         strcmp(BluetoothManager::resultToString(BluetoothResult::BOND_FAILED), "BOND_FAILED") == 0);
    test("resultToString SIMULATED_FAILURE",
         strcmp(BluetoothManager::resultToString(BluetoothResult::SIMULATED_FAILURE),
                "SIMULATED_FAILURE") == 0);

    // EventType
    test("eventTypeToString ADAPTER_STATE_CHANGED",
         strcmp(BluetoothManager::eventTypeToString(BluetoothEventType::ADAPTER_STATE_CHANGED),
                "ADAPTER_STATE_CHANGED") == 0);
    test("eventTypeToString DEVICE_FOUND",
         strcmp(BluetoothManager::eventTypeToString(BluetoothEventType::DEVICE_FOUND),
                "DEVICE_FOUND") == 0);
    test("eventTypeToString PROFILE_CONNECTED",
         strcmp(BluetoothManager::eventTypeToString(BluetoothEventType::PROFILE_CONNECTED),
                "PROFILE_CONNECTED") == 0);

    // String to Result parser
    test("stringToResult SUCCESS",
         BluetoothManager::stringToResult("SUCCESS") == BluetoothResult::SUCCESS);
    test("stringToResult PERMISSION_DENIED",
         BluetoothManager::stringToResult("PERMISSION_DENIED") == BluetoothResult::PERMISSION_DENIED);
    test("stringToResult ADAPTER_OFF",
         BluetoothManager::stringToResult("ADAPTER_OFF") == BluetoothResult::ADAPTER_OFF);
    test("stringToResult unknown returns OPERATION_FAILED",
         BluetoothManager::stringToResult("UNKNOWN") == BluetoothResult::OPERATION_FAILED);

    // String to Profile parser
    test("stringToProfile A2DP_SINK",
         BluetoothManager::stringToProfile("A2DP_SINK") == ProfileType::A2DP_SINK);
    test("stringToProfile HFP_CLIENT",
         BluetoothManager::stringToProfile("HFP_CLIENT") == ProfileType::HFP_CLIENT);
    test("stringToProfile GATT_SERVER",
         BluetoothManager::stringToProfile("GATT_SERVER") == ProfileType::GATT_SERVER);
}

// ============================================================
// Test: Privacy Transforms
// ============================================================

static void testPrivacyTransforms() {
    printf("  [Privacy Transforms]\n");

    BluetoothDevice dev;
    dev.address = "AA:BB:CC:DD:EE:FF";
    dev.name = "Test Device";
    dev.rssi = -50;
    dev.uuids.push_back("test-uuid");

    // FULL mode - no transform
    auto full = BluetoothManager::applyPrivacyTransform(dev, BluetoothPrivacyMode::FULL,
                                                          BT_PRIVACY_NONE);
    test("FULL address unchanged", full.address == "AA:BB:CC:DD:EE:FF");
    test("FULL name unchanged", full.name == "Test Device");
    test("FULL rssi unchanged", full.rssi == -50);
    test("FULL uuids preserved", full.uuids.size() == 1);

    // REDACTED mode - redact address
    auto redacted = BluetoothManager::applyPrivacyTransform(dev, BluetoothPrivacyMode::REDACTED,
                                                              BT_PRIVACY_REDACT_ADDRESS);
    test("REDACTED address has XX", redacted.address.find("XX") != std::string::npos);
    test("REDACTED name unchanged", redacted.name == "Test Device");

    // METADATA_ONLY mode - redact everything
    auto metadata = BluetoothManager::applyPrivacyTransform(dev, BluetoothPrivacyMode::METADATA_ONLY,
                                                              BT_PRIVACY_NONE);
    test("METADATA_ONLY address redacted", metadata.address.find("XX") != std::string::npos);
    test("METADATA_ONLY name [REDACTED]", metadata.name == "[REDACTED]");
    test("METADATA_ONLY rssi 0", metadata.rssi == 0);
    test("METADATA_ONLY uuids cleared", metadata.uuids.empty());

    // PSEUDONYMIZE flag
    auto pseudo = BluetoothManager::applyPrivacyTransform(dev, BluetoothPrivacyMode::FULL,
                                                            BT_PRIVACY_PSEUDONYMIZE,
                                                            "my-app-pseudonym");
    test("PSEUDONYMIZE address changed", pseudo.address != "AA:BB:CC:DD:EE:FF");
    test("PSEUDONYMIZE address starts with 02", pseudo.address.substr(0, 2) == "02");

    // Redact address helper
    std::string redactedAddr = BluetoothManager::redactAddress("AA:BB:CC:DD:EE:FF");
    test("redactAddress has XX", redactedAddr.find("XX") != std::string::npos);
    test("redactAddress keeps first 2 octets",
         redactedAddr.substr(0, 5) == "AA:BB");

    // Pseudonymize address helper
    std::string pseudoAddr = BluetoothManager::pseudonymizeAddress("AA:BB:CC:DD:EE:FF",
                                                                       "test-pseudonym");
    test("pseudonymizeAddress starts with 02", pseudoAddr.substr(0, 2) == "02");
    test("pseudonymizeAddress different from original",
         pseudoAddr != "AA:BB:CC:DD:EE:FF");

    // Empty pseudonym falls back to redaction
    std::string emptyPseudo = BluetoothManager::pseudonymizeAddress("AA:BB:CC:DD:EE:FF", "");
    test("pseudonymizeAddress empty pseudonym redacts",
         emptyPseudo.find("XX") != std::string::npos);
}

// ============================================================
// Test: Full Workflow
// ============================================================

static void testFullWorkflow() {
    printf("  [Full Workflow]\n");

    BluetoothManager mgr;
    mgr.initialize();

    // 1. Enable adapter
    test("workflow: enable adapter", mgr.enableAdapter() == BluetoothResult::SUCCESS);

    // 2. Set discoverable
    test("workflow: set discoverable",
         mgr.setScanMode(ScanMode::CONNECTABLE_DISCOVERABLE) == BluetoothResult::SUCCESS);

    // 3. Start scanning
    test("workflow: start scan", mgr.startScan() == BluetoothResult::SUCCESS);

    // 4. Find devices
    auto devices = mgr.getAllDevices();
    test("workflow: devices found", !devices.empty());

    if (!devices.empty()) {
        std::string addr = devices[0].address;

        // 5. Pair device
        test("workflow: pair device", mgr.pair(addr) == BluetoothResult::SUCCESS);

        // 6. Connect device
        test("workflow: connect device", mgr.connect(addr) == BluetoothResult::SUCCESS);

        // 7. Connect A2DP profile
        test("workflow: connect A2DP",
             mgr.connectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SUCCESS);

        // 8. Grant app access
        test("workflow: set app policy",
             mgr.setAppBluetoothPolicy("music_app", BluetoothPermission::ALLOW_FOREGROUND,
                                        BluetoothPrivacyMode::REDACTED,
                                        BT_PRIVACY_REDACT_ADDRESS) == BluetoothResult::SUCCESS);
        mgr.setAppForeground("music_app", true);

        // 9. App reads device address (redacted)
        std::string addrOut;
        test("workflow: app gets redacted address",
             mgr.getDeviceAddress("music_app", addr, addrOut) == BluetoothResult::SUCCESS);
        test("workflow: address redacted",
             addrOut.find("XX") != std::string::npos);

        // 10. Privacy indicator on
        test("workflow: privacy indicator on", mgr.isPrivacyIndicatorOn());

        // 11. Disconnect profile
        test("workflow: disconnect A2DP",
             mgr.disconnectProfile(addr, ProfileType::A2DP_SINK) == BluetoothResult::SUCCESS);

        // 12. Disconnect device
        test("workflow: disconnect device",
             mgr.disconnect(addr) == BluetoothResult::SUCCESS);

        // 13. Unpair
        test("workflow: unpair device", mgr.unpair(addr) == BluetoothResult::SUCCESS);

        // 14. Privacy indicator off after policy clear
        mgr.clearAppBluetoothPolicy("music_app");
        test("workflow: privacy indicator off", !mgr.isPrivacyIndicatorOn());
    }

    // 15. Stop scan
    test("workflow: stop scan", mgr.stopScan() == BluetoothResult::SUCCESS);

    // 16. Disable adapter
    test("workflow: disable adapter", mgr.disableAdapter() == BluetoothResult::SUCCESS);

    // 17. Check stats
    auto stats = mgr.getStats();
    test("workflow: stats recorded", stats.adapterOnCount > 0);

    // 18. Check events
    test("workflow: events recorded", mgr.getEventCount() > 0);

    // 19. Clear events
    test("workflow: clear events", mgr.clearEvents() == BluetoothResult::SUCCESS);

    // 20. Shutdown
    test("workflow: shutdown", mgr.shutdown() == BluetoothResult::SUCCESS);
}

// ============================================================
// Main
// ============================================================

int main() {
    printf("========================================\n");
    printf("Phantom OS - Bluetooth Manager Tests\n");
    printf("v0.33.0\n");
    printf("========================================\n\n");
    fflush(stdout);

    testLifecycle(); fflush(stdout);
    testAdapterControl(); fflush(stdout);
    testScanning(); fflush(stdout);
    testDeviceManagement(); fflush(stdout);
    testPairing(); fflush(stdout);
    testConnection(); fflush(stdout);
    testProfiles(); fflush(stdout);
    testPermissions(); fflush(stdout);
    testIdentifierAccess(); fflush(stdout);
    testHistory(); fflush(stdout);
    testMock(); fflush(stdout);
    testPrivacyIndicator(); fflush(stdout);
    testEvents(); fflush(stdout);
    testStats(); fflush(stdout);
    testFailureSimulation(); fflush(stdout);
    testTimeInjection(); fflush(stdout);
    testIntegration(); fflush(stdout);
    testStringHelpers(); fflush(stdout);
    testPrivacyTransforms(); fflush(stdout);
    testFullWorkflow(); fflush(stdout);

    printf("\n========================================\n");
    printf("Results: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("========================================\n");

    return tests_failed > 0 ? 1 : 0;
}
