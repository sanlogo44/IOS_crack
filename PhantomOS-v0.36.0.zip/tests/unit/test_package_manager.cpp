/*
 * Phantom OS - Package Manager Tests
 * Tests for the local manifest-based package manager
 *
 * License: GPL-3.0
 */

#include "phantom/package_manager/package_manager.h"
#include "phantom/package_manager/package.h"
#include "phantom/app_lifecycle.h"
#include <cassert>
#include <cstdio>
#include <string>

using namespace phantom::package;
using namespace phantom::framework;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

// Helper to create a valid manifest
PackageManifest makeManifest(const std::string& id, const std::string& name = "TestPkg",
                              const std::string& version = "1.0.0",
                              const std::string& appId = "") {
    PackageManifest m;
    m.info.package_id = id;
    m.info.app_id = appId;
    m.info.name = name;
    m.info.version_str = version;
    m.info.version = PackageVersion::parse(version);
    m.info.description = "Test package";
    m.info.vendor = "PhantomOS";
    m.info.entry_point = "main";
    m.info.install_path = "/system/apps/" + id;
    m.sandbox_profile = SandboxProfile::NORMAL;
    return m;
}

PackageManifest makeManifestWithApp(const std::string& id, const std::string& appId,
                                     const std::string& version = "1.0.0",
                                     bool autoStart = false) {
    auto m = makeManifest(id, "TestApp", version, appId);
    m.auto_start = autoStart;
    m.permissions = {"camera", "location"};
    return m;
}

// ============================================================
// Version tests
// ============================================================

bool test_version_parse() {
    TEST("Parse version string");
    auto v = PackageVersion::parse("2.5.3");
    ASSERT(v.major == 2, "Major should be 2");
    ASSERT(v.minor == 5, "Minor should be 5");
    ASSERT(v.patch == 3, "Patch should be 3");
    ASSERT(v.toString() == "2.5.3", "toString should match");
    PASS();
    return true;
}

bool test_version_comparison() {
    TEST("Version comparison");
    auto v1 = PackageVersion::parse("1.0.0");
    auto v2 = PackageVersion::parse("1.0.1");
    auto v3 = PackageVersion::parse("1.1.0");
    auto v4 = PackageVersion::parse("2.0.0");

    ASSERT(v1 < v2, "1.0.0 < 1.0.1");
    ASSERT(v2 < v3, "1.0.1 < 1.1.0");
    ASSERT(v3 < v4, "1.1.0 < 2.0.0");
    ASSERT(v1 <= v1, "1.0.0 <= 1.0.0");
    ASSERT(v4 > v3, "2.0.0 > 1.1.0");
    ASSERT(v1 == PackageVersion::parse("1.0.0"), "1.0.0 == 1.0.0");
    ASSERT(v1 != v2, "1.0.0 != 1.0.1");
    PASS();
    return true;
}

bool test_version_edge_cases() {
    TEST("Version edge cases");
    auto v = PackageVersion::parse("0.0.0");
    ASSERT(v.major == 0 && v.minor == 0 && v.patch == 0, "0.0.0 parsed");

    auto v2 = PackageVersion::parse("10.20.30");
    ASSERT(v2.major == 10 && v2.minor == 20 && v2.patch == 30, "10.20.30 parsed");

    auto v3 = PackageVersion::parse("1");
    ASSERT(v3.major == 1 && v3.minor == 0 && v3.patch == 0, "1 parsed as 1.0.0");

    auto v4 = PackageVersion::parse("");
    ASSERT(v4.major == 0 && v4.minor == 0 && v4.patch == 0, "empty parsed as 0.0.0");
    PASS();
    return true;
}

bool test_is_newer_version() {
    TEST("isNewerVersion");
    ASSERT(PackageManager::isNewerVersion(PackageVersion::parse("1.0.0"), PackageVersion::parse("1.0.1")), "1.0.1 is newer than 1.0.0");
    ASSERT(PackageManager::isNewerVersion(PackageVersion::parse("1.0.0"), PackageVersion::parse("2.0.0")), "2.0.0 is newer than 1.0.0");
    ASSERT(!PackageManager::isNewerVersion(PackageVersion::parse("1.0.1"), PackageVersion::parse("1.0.0")), "1.0.0 is not newer than 1.0.1");
    ASSERT(!PackageManager::isNewerVersion(PackageVersion::parse("1.0.0"), PackageVersion::parse("1.0.0")), "Same version is not newer");
    PASS();
    return true;
}

bool test_is_downgrade() {
    TEST("isDowngrade");
    ASSERT(PackageManager::isDowngrade(PackageVersion::parse("1.0.1"), PackageVersion::parse("1.0.0")), "1.0.0 is downgrade from 1.0.1");
    ASSERT(PackageManager::isDowngrade(PackageVersion::parse("2.0.0"), PackageVersion::parse("1.9.9")), "1.9.9 is downgrade from 2.0.0");
    ASSERT(!PackageManager::isDowngrade(PackageVersion::parse("1.0.0"), PackageVersion::parse("1.0.1")), "1.0.1 is not downgrade");
    ASSERT(!PackageManager::isDowngrade(PackageVersion::parse("1.0.0"), PackageVersion::parse("1.0.0")), "Same version is not downgrade");
    PASS();
    return true;
}

// ============================================================
// Available repository tests
// ============================================================

bool test_add_available_package() {
    TEST("Add available package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto result = pm.addAvailablePackage(makeManifest("com.test.pkg1"));
    ASSERT(result == PackageManagerResult::SUCCESS, "Should add successfully");
    ASSERT(pm.isPackageAvailable("com.test.pkg1"), "Should be available");
    ASSERT(pm.getAvailableCount() == 1, "Should have 1 available");
    PASS();
    return true;
}

bool test_duplicate_available() {
    TEST("Duplicate available fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.addAvailablePackage(makeManifest("com.test.dup"));
    auto result = pm.addAvailablePackage(makeManifest("com.test.dup"));
    ASSERT(result == PackageManagerResult::ALREADY_AVAILABLE, "Should fail on duplicate");
    PASS();
    return true;
}

bool test_remove_available() {
    TEST("Remove available package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.addAvailablePackage(makeManifest("com.test.removable"));
    auto result = pm.removeAvailablePackage("com.test.removable");
    ASSERT(result == PackageManagerResult::SUCCESS, "Should remove successfully");
    ASSERT(!pm.isPackageAvailable("com.test.removable"), "Should not be available");
    PASS();
    return true;
}

bool test_get_available_manifest() {
    TEST("Get available manifest");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto m = makeManifest("com.test.manifest", "MyApp", "3.1.0");
    pm.addAvailablePackage(m);
    auto retrieved = pm.getAvailableManifest("com.test.manifest");
    ASSERT(retrieved.info.package_id == "com.test.manifest", "Package ID should match");
    ASSERT(retrieved.info.name == "MyApp", "Name should match");
    ASSERT(retrieved.info.version_str == "3.1.0", "Version should match");
    PASS();
    return true;
}

// ============================================================
// Manifest validation tests
// ============================================================

bool test_validate_valid_manifest() {
    TEST("Validate valid manifest");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto m = makeManifest("com.valid.pkg");
    auto result = pm.validateManifest(m);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should be valid");
    PASS();
    return true;
}

bool test_validate_invalid_manifest() {
    TEST("Validate invalid manifest (empty name)");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    PackageManifest m;
    m.info.package_id = "com.invalid.pkg";
    m.info.name = "";
    m.info.version_str = "1.0.0";
    auto result = pm.validateManifest(m);
    ASSERT(result == PackageManagerResult::INVALID_MANIFEST, "Should be invalid");
    PASS();
    return true;
}

bool test_validate_empty_package_id() {
    TEST("Validate manifest with empty package ID");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    PackageManifest m;
    m.info.package_id = "";
    m.info.name = "Test";
    m.info.version_str = "1.0.0";
    auto result = pm.validateManifest(m);
    ASSERT(result == PackageManagerResult::INVALID_PACKAGE_ID, "Should be invalid");
    PASS();
    return true;
}

// ============================================================
// Install tests
// ============================================================

bool test_install_package() {
    TEST("Install package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto result = pm.installPackage(makeManifest("com.test.install"));
    ASSERT(result == PackageManagerResult::SUCCESS, "Should install successfully");
    ASSERT(pm.isPackageInstalled("com.test.install"), "Should be installed");
    ASSERT(pm.getInstallState("com.test.install") == InstallState::INSTALLED, "State should be INSTALLED");
    PASS();
    return true;
}

bool test_install_duplicate() {
    TEST("Install duplicate package fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.dupinstall"));
    auto result = pm.installPackage(makeManifest("com.test.dupinstall"));
    ASSERT(result == PackageManagerResult::ALREADY_INSTALLED, "Should fail on duplicate");
    PASS();
    return true;
}

bool test_install_from_available() {
    TEST("Install from available repository");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.addAvailablePackage(makeManifest("com.test.fromavail", "AvailApp", "2.0.0"));
    auto result = pm.installPackage("com.test.fromavail");
    ASSERT(result == PackageManagerResult::SUCCESS, "Should install from available");
    ASSERT(pm.isPackageInstalled("com.test.fromavail"), "Should be installed");
    PASS();
    return true;
}

bool test_install_not_available() {
    TEST("Install non-available package fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto result = pm.installPackage("com.test.nonavail");
    ASSERT(result == PackageManagerResult::NOT_AVAILABLE, "Should fail - not available");
    PASS();
    return true;
}

bool test_force_reinstall() {
    TEST("Force reinstall package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.reinstall"));
    InstallOptions opts;
    opts.force = true;
    auto result = pm.installPackage(makeManifest("com.test.reinstall"), opts);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should reinstall with force");
    ASSERT(pm.isPackageInstalled("com.test.reinstall"), "Should still be installed");
    PASS();
    return true;
}

// ============================================================
// Uninstall tests
// ============================================================

bool test_uninstall_package() {
    TEST("Uninstall package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.uninstall"));
    auto result = pm.uninstallPackage("com.test.uninstall");
    ASSERT(result == PackageManagerResult::SUCCESS, "Should uninstall successfully");
    ASSERT(!pm.isPackageInstalled("com.test.uninstall"), "Should not be installed");
    PASS();
    return true;
}

bool test_uninstall_not_installed() {
    TEST("Uninstall non-installed fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto result = pm.uninstallPackage("com.test.notinstalled");
    ASSERT(result == PackageManagerResult::NOT_INSTALLED, "Should fail - not installed");
    PASS();
    return true;
}

bool test_uninstall_running_app_blocked() {
    TEST("Uninstall running app blocked");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();

    auto m = makeManifestWithApp("com.test.running", "com.app.running");
    pm.installPackage(m);
    alm.startApp("com.app.running");

    auto result = pm.uninstallPackage("com.test.running");
    ASSERT(result == PackageManagerResult::APP_RUNNING, "Should fail - app running");
    PASS();
    return true;
}

bool test_force_uninstall_running() {
    TEST("Force uninstall running app");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    auto m = makeManifestWithApp("com.test.forcerun", "com.app.forcerun");
    pm.installPackage(m);
    alm.startApp("com.app.forcerun");

    UninstallOptions opts;
    opts.force = true;
    auto result = pm.uninstallPackage("com.test.forcerun", opts);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should succeed with force");
    ASSERT(!pm.isPackageInstalled("com.test.forcerun"), "Should be uninstalled");
    PASS();
    return true;
}

bool test_purge_uninstall() {
    TEST("Purge uninstall removes from available");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.addAvailablePackage(makeManifest("com.test.purge"));
    pm.installPackage("com.test.purge");

    UninstallOptions opts;
    opts.purge = true;
    auto result = pm.uninstallPackage("com.test.purge", opts);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should succeed");
    ASSERT(!pm.isPackageAvailable("com.test.purge"), "Should be removed from available");
    PASS();
    return true;
}

// ============================================================
// Update tests
// ============================================================

bool test_update_package() {
    TEST("Update package");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.update", "UpdateApp", "1.0.0"));
    auto result = pm.updatePackage(makeManifest("com.test.update", "UpdateApp", "1.1.0"));
    ASSERT(result == PackageManagerResult::SUCCESS, "Should update successfully");
    auto info = pm.getInstalledPackageInfo("com.test.update");
    ASSERT(info.version_str == "1.1.0", "Version should be 1.1.0");
    PASS();
    return true;
}

bool test_update_downgrade_blocked() {
    TEST("Downgrade blocked");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.downgrade", "DownApp", "2.0.0"));
    auto result = pm.updatePackage(makeManifest("com.test.downgrade", "DownApp", "1.0.0"));
    ASSERT(result == PackageManagerResult::VERSION_DOWNGRADE_BLOCKED, "Should block downgrade");
    auto info = pm.getInstalledPackageInfo("com.test.downgrade");
    ASSERT(info.version_str == "2.0.0", "Version should remain 2.0.0");
    PASS();
    return true;
}

bool test_update_not_installed() {
    TEST("Update non-installed fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto result = pm.updatePackage(makeManifest("com.test.updatenotinst"));
    ASSERT(result == PackageManagerResult::NOT_INSTALLED, "Should fail - not installed");
    PASS();
    return true;
}

bool test_update_same_version() {
    TEST("Update same version is no-op");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.test.samever", "SameApp", "1.0.0"));
    auto result = pm.updatePackage(makeManifest("com.test.samever", "SameApp", "1.0.0"));
    ASSERT(result == PackageManagerResult::SUCCESS, "Should succeed (already up to date)");
    PASS();
    return true;
}

// ============================================================
// Dependency tests
// ============================================================

bool test_dependency_satisfied() {
    TEST("Dependency satisfied");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    // Install dependency first
    pm.installPackage(makeManifest("com.dep.base", "BaseDep", "1.0.0"));

    // Create package that depends on it
    auto m = makeManifest("com.dep.user", "DepUser", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.base";
    dep.min_version = PackageVersion::parse("1.0.0");
    dep.max_version = PackageVersion::parse("1.99.99");
    dep.optional = false;
    m.dependencies.push_back(dep);

    auto result = pm.installPackage(m);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should install with satisfied dependency");
    PASS();
    return true;
}

bool test_dependency_missing() {
    TEST("Dependency missing fails");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    auto m = makeManifest("com.dep.missing", "DepMissing", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.nonexistent";
    dep.min_version = PackageVersion::parse("1.0.0");
    dep.optional = false;
    m.dependencies.push_back(dep);

    auto result = pm.installPackage(m);
    ASSERT(result == PackageManagerResult::DEPENDENCY_MISSING, "Should fail - dependency missing");
    PASS();
    return true;
}

bool test_dependency_version_conflict() {
    TEST("Dependency version conflict");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    // Install version 1.0.0
    pm.installPackage(makeManifest("com.dep.conflict", "ConflictDep", "1.0.0"));

    // Require version >= 2.0.0
    auto m = makeManifest("com.dep.conflicter", "ConflictUser", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.conflict";
    dep.min_version = PackageVersion::parse("2.0.0");
    dep.optional = false;
    m.dependencies.push_back(dep);

    auto result = pm.installPackage(m);
    ASSERT(result == PackageManagerResult::DEPENDENCY_MISSING, "Should fail - version conflict");
    PASS();
    return true;
}

bool test_optional_dependency_not_blocking() {
    TEST("Optional dependency does not block");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    auto m = makeManifest("com.dep.optional", "OptDep", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.missingoptional";
    dep.optional = true;
    m.dependencies.push_back(dep);

    auto result = pm.installPackage(m);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should succeed - optional dep missing");
    PASS();
    return true;
}

bool test_skip_dependency_check() {
    TEST("Skip dependency check");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    auto m = makeManifest("com.dep.skip", "SkipDep", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.nonexistent";
    dep.optional = false;
    m.dependencies.push_back(dep);

    InstallOptions opts;
    opts.skip_dependency_check = true;
    auto result = pm.installPackage(m, opts);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should succeed with skip");
    PASS();
    return true;
}

// ============================================================
// Batch install with dependencies
// ============================================================

bool test_install_with_dependencies() {
    TEST("Install with dependencies (topological sort)");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    // Add base package
    pm.addAvailablePackage(makeManifest("com.batch.base", "Base", "1.0.0"));

    // Add dependent package
    auto m = makeManifest("com.batch.dependent", "Dependent", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.batch.base";
    dep.min_version = PackageVersion::parse("1.0.0");
    dep.optional = false;
    m.dependencies.push_back(dep);
    pm.addAvailablePackage(m);

    auto result = pm.installWithDependencies({"com.batch.dependent"});
    ASSERT(result == PackageManagerResult::SUCCESS, "Should install with dependencies");
    ASSERT(pm.isPackageInstalled("com.batch.base"), "Base should be installed");
    ASSERT(pm.isPackageInstalled("com.batch.dependent"), "Dependent should be installed");
    PASS();
    return true;
}

bool test_cycle_detection() {
    TEST("Dependency cycle detection");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    // Create cycle: A -> B -> C -> A
    auto mA = makeManifest("com.cycle.a");
    PackageDependency depAB;
    depAB.package_id = "com.cycle.b";
    depAB.min_version = PackageVersion::parse("1.0.0");
    mA.dependencies.push_back(depAB);

    auto mB = makeManifest("com.cycle.b");
    PackageDependency depBC;
    depBC.package_id = "com.cycle.c";
    depBC.min_version = PackageVersion::parse("1.0.0");
    mB.dependencies.push_back(depBC);

    auto mC = makeManifest("com.cycle.c");
    PackageDependency depCA;
    depCA.package_id = "com.cycle.a";
    depCA.min_version = PackageVersion::parse("1.0.0");
    mC.dependencies.push_back(depCA);

    pm.addAvailablePackage(mA);
    pm.addAvailablePackage(mB);
    pm.addAvailablePackage(mC);

    auto result = pm.detectCycle({"com.cycle.a"});
    ASSERT(result == PackageManagerResult::CYCLE_DETECTED, "Should detect cycle");
    PASS();
    return true;
}

// ============================================================
// Lifecycle integration tests
// ============================================================

bool test_lifecycle_registration_on_install() {
    TEST("Lifecycle registration on install");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    auto m = makeManifestWithApp("com.lifecycle.test", "com.app.lifecycle", "1.0.0");
    auto result = pm.installPackage(m);
    ASSERT(result == PackageManagerResult::SUCCESS, "Should install");
    ASSERT(alm.isAppRegistered("com.app.lifecycle"), "App should be registered with lifecycle manager");
    PASS();
    return true;
}

bool test_auto_start_passed_to_lifecycle() {
    TEST("Auto-start flag passed to lifecycle");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    auto m = makeManifestWithApp("com.autostart.test", "com.app.autostart", "1.0.0", true);
    pm.installPackage(m);

    auto info = alm.getAppInfo("com.app.autostart");
    ASSERT(info.auto_start == true, "auto_start should be true in AppInfo");
    PASS();
    return true;
}

bool test_permissions_passed_to_lifecycle() {
    TEST("Permissions passed to lifecycle");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    auto m = makeManifestWithApp("com.perms.test", "com.app.perms", "1.0.0");
    pm.installPackage(m);

    auto info = alm.getAppInfo("com.app.perms");
    ASSERT(info.required_permissions.size() == 2, "Should have 2 permissions");
    ASSERT(info.required_permissions[0] == "camera", "First permission should be camera");
    PASS();
    return true;
}

bool test_uninstall_unregisters_lifecycle() {
    TEST("Uninstall unregisters from lifecycle");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto& alm = AppLifecycleManager::getInstance();
    alm.clear();

    auto m = makeManifestWithApp("com.unreg.test", "com.app.unreg", "1.0.0");
    pm.installPackage(m);
    ASSERT(alm.isAppRegistered("com.app.unreg"), "Should be registered");

    pm.uninstallPackage("com.unreg.test");
    ASSERT(!alm.isAppRegistered("com.app.unreg"), "Should be unregistered");
    PASS();
    return true;
}

// ============================================================
// Query tests
// ============================================================

bool test_get_installed_packages() {
    TEST("Get installed packages list");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.installPackage(makeManifest("com.list.1"));
    pm.installPackage(makeManifest("com.list.2"));
    pm.installPackage(makeManifest("com.list.3"));
    auto list = pm.getInstalledPackages();
    ASSERT(list.size() == 3, "Should have 3 installed");
    PASS();
    return true;
}

bool test_get_dependents() {
    TEST("Get dependents");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    pm.installPackage(makeManifest("com.dep.target", "Target", "1.0.0"));

    auto m = makeManifest("com.dep.user1", "User1", "1.0.0");
    PackageDependency dep;
    dep.package_id = "com.dep.target";
    dep.min_version = PackageVersion::parse("1.0.0");
    m.dependencies.push_back(dep);
    pm.installPackage(m);

    auto deps = pm.getDependents("com.dep.target");
    ASSERT(deps.size() == 1, "Should have 1 dependent");
    ASSERT(deps[0] == "com.dep.user1", "Dependent should match");
    PASS();
    return true;
}

bool test_get_dependencies() {
    TEST("Get dependencies");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    auto m = makeManifest("com.getdep.test", "Test", "1.0.0");
    PackageDependency dep1;
    dep1.package_id = "com.getdep.dep1";
    dep1.min_version = PackageVersion::parse("1.0.0");
    PackageDependency dep2;
    dep2.package_id = "com.getdep.dep2";
    dep2.min_version = PackageVersion::parse("2.0.0");
    dep2.optional = true;
    m.dependencies.push_back(dep1);
    m.dependencies.push_back(dep2);
    InstallOptions opts;
    opts.skip_dependency_check = true;
    pm.installPackage(m, opts);

    auto deps = pm.getDependencies("com.getdep.test");
    ASSERT(deps.size() == 2, "Should have 2 dependencies");
    ASSERT(deps[0].package_id == "com.getdep.dep1", "First dep should match");
    ASSERT(deps[1].optional == true, "Second dep should be optional");
    PASS();
    return true;
}

bool test_get_installed_count() {
    TEST("Get installed count");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    ASSERT(pm.getInstalledCount() == 0, "Should be 0");
    pm.installPackage(makeManifest("com.count.1"));
    pm.installPackage(makeManifest("com.count.2"));
    ASSERT(pm.getInstalledCount() == 2, "Should be 2");
    PASS();
    return true;
}

bool test_get_installed_manifest() {
    TEST("Get installed manifest");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    auto m = makeManifest("com.manifest.get", "ManifestApp", "1.5.0");
    m.permissions = {"camera", "storage"};
    m.sandbox_profile = SandboxProfile::STRICT;
    pm.installPackage(m);

    auto retrieved = pm.getInstalledManifest("com.manifest.get");
    ASSERT(retrieved.info.package_id == "com.manifest.get", "Package ID should match");
    ASSERT(retrieved.info.name == "ManifestApp", "Name should match");
    ASSERT(retrieved.info.version_str == "1.5.0", "Version should match");
    ASSERT(retrieved.permissions.size() == 2, "Should have 2 permissions");
    ASSERT(retrieved.sandbox_profile == SandboxProfile::STRICT, "Sandbox should be STRICT");
    PASS();
    return true;
}

// ============================================================
// State callback test
// ============================================================

bool test_state_change_callback() {
    TEST("State change callback");
    auto& pm = PackageManager::getInstance();
    pm.clear();

    std::string callback_pkg;
    InstallState callback_old = InstallState::AVAILABLE;
    InstallState callback_new = InstallState::AVAILABLE;
    int callback_count = 0;

    pm.setStateChangeCallback([&](const std::string& pkgId, InstallState oldState, InstallState newState) {
        callback_pkg = pkgId;
        callback_old = oldState;
        callback_new = newState;
        callback_count++;
    });

    pm.installPackage(makeManifest("com.callback.test"));
    ASSERT(callback_count > 0, "Callback should have been called");
    ASSERT(callback_pkg == "com.callback.test", "Callback should have correct package ID");
    ASSERT(callback_new == InstallState::INSTALLED, "New state should be INSTALLED");
    PASS();
    return true;
}

// ============================================================
// String conversion tests
// ============================================================

bool test_string_conversions() {
    TEST("String conversions");
    ASSERT(std::string(installStateToString(InstallState::INSTALLED)) == "INSTALLED", "INSTALLED string");
    ASSERT(std::string(installStateToString(InstallState::AVAILABLE)) == "AVAILABLE", "AVAILABLE string");
    ASSERT(std::string(installStateToString(InstallState::FAILED)) == "FAILED", "FAILED string");
    ASSERT(std::string(sandboxProfileToString(SandboxProfile::STRICT)) == "STRICT", "STRICT string");
    ASSERT(std::string(sandboxProfileToString(SandboxProfile::NETWORK)) == "NETWORK", "NETWORK string");
    ASSERT(std::string(resultToString(PackageManagerResult::SUCCESS)) == "SUCCESS", "SUCCESS string");
    ASSERT(std::string(resultToString(PackageManagerResult::DEPENDENCY_MISSING)) == "DEPENDENCY_MISSING", "DEPENDENCY_MISSING string");
    PASS();
    return true;
}

bool test_clear_all() {
    TEST("Clear all packages");
    auto& pm = PackageManager::getInstance();
    pm.clear();
    pm.addAvailablePackage(makeManifest("com.clear.1"));
    pm.addAvailablePackage(makeManifest("com.clear.2"));
    pm.installPackage(makeManifest("com.clear.3"));

    pm.clear();
    ASSERT(pm.getAvailableCount() == 0, "Available should be 0");
    ASSERT(pm.getInstalledCount() == 0, "Installed should be 0");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Package Manager Tests ===\n\n");

    bool all_pass = true;
    // Version tests
    all_pass &= test_version_parse();
    all_pass &= test_version_comparison();
    all_pass &= test_version_edge_cases();
    all_pass &= test_is_newer_version();
    all_pass &= test_is_downgrade();
    // Available repository tests
    all_pass &= test_add_available_package();
    all_pass &= test_duplicate_available();
    all_pass &= test_remove_available();
    all_pass &= test_get_available_manifest();
    // Manifest validation tests
    all_pass &= test_validate_valid_manifest();
    all_pass &= test_validate_invalid_manifest();
    all_pass &= test_validate_empty_package_id();
    // Install tests
    all_pass &= test_install_package();
    all_pass &= test_install_duplicate();
    all_pass &= test_install_from_available();
    all_pass &= test_install_not_available();
    all_pass &= test_force_reinstall();
    // Uninstall tests
    all_pass &= test_uninstall_package();
    all_pass &= test_uninstall_not_installed();
    all_pass &= test_uninstall_running_app_blocked();
    all_pass &= test_force_uninstall_running();
    all_pass &= test_purge_uninstall();
    // Update tests
    all_pass &= test_update_package();
    all_pass &= test_update_downgrade_blocked();
    all_pass &= test_update_not_installed();
    all_pass &= test_update_same_version();
    // Dependency tests
    all_pass &= test_dependency_satisfied();
    all_pass &= test_dependency_missing();
    all_pass &= test_dependency_version_conflict();
    all_pass &= test_optional_dependency_not_blocking();
    all_pass &= test_skip_dependency_check();
    // Batch install
    all_pass &= test_install_with_dependencies();
    all_pass &= test_cycle_detection();
    // Lifecycle integration
    all_pass &= test_lifecycle_registration_on_install();
    all_pass &= test_auto_start_passed_to_lifecycle();
    all_pass &= test_permissions_passed_to_lifecycle();
    all_pass &= test_uninstall_unregisters_lifecycle();
    // Query tests
    all_pass &= test_get_installed_packages();
    all_pass &= test_get_dependents();
    all_pass &= test_get_dependencies();
    all_pass &= test_get_installed_count();
    all_pass &= test_get_installed_manifest();
    // State callback
    all_pass &= test_state_change_callback();
    // String conversions
    all_pass &= test_string_conversions();
    // Clear
    all_pass &= test_clear_all();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
