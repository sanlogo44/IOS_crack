/*
 * Phantom OS - Window Manager Tests
 *
 * License: GPL-3.0
 */

#include "phantom/gui/window_manager.h"
#include <cassert>
#include <cstdio>

using namespace phantom::gui;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_create_window() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Window::WindowId id = wm.createWindow("Test", "com.test.app", Rect(0, 0, 100, 100));
    ASSERT(id != 0, "Window ID should be non-zero");
    ASSERT(wm.getWindowCount() == 1, "Should have 1 window");

    Window* win = wm.getWindow(id);
    ASSERT(win != nullptr, "getWindow should return the window");
    ASSERT(win->getTitle() == "Test", "Title should match");
    ASSERT(win->getAppId() == "com.test.app", "AppId should match");
    ASSERT(win->getSize() == Size(100, 100), "Size should be 100x100");
    ASSERT(win->hasSurface(), "Window should have a backing surface");

    return true;
}

bool test_destroy_window() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Window::WindowId id = wm.createWindow("Test", "com.test.app", Rect(0, 0, 50, 50));
    ASSERT(wm.getWindowCount() == 1, "Should have 1 window");

    auto result = wm.destroyWindow(id);
    ASSERT(result == WindowManager::Result::SUCCESS, "Destroy should succeed");
    ASSERT(wm.getWindowCount() == 0, "Should have 0 windows after destroy");

    result = wm.destroyWindow(id);
    ASSERT(result == WindowManager::Result::WINDOW_NOT_FOUND, "Destroying again should fail");

    return true;
}

bool test_show_hide_focus() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Window::WindowId id1 = wm.createWindow("Win1", "com.app1", Rect(0, 0, 100, 100));
    Window::WindowId id2 = wm.createWindow("Win2", "com.app2", Rect(50, 50, 100, 100));

    // Show both
    wm.showWindow(id1);
    wm.showWindow(id2);

    ASSERT(wm.getWindow(id1)->isVisible(), "Win1 should be visible");
    ASSERT(wm.getWindow(id2)->isVisible(), "Win2 should be visible");

    // Focus Win2
    wm.focusWindow(id2);
    ASSERT(wm.getFocusedWindowId() == id2, "Focused window should be Win2");

    // Focus Win1
    wm.focusWindow(id1);
    ASSERT(wm.getFocusedWindowId() == id1, "Focused window should be Win1");

    // Hide Win1 — should clear focus
    wm.hideWindow(id1);
    ASSERT(!wm.getWindow(id1)->isVisible(), "Win1 should be hidden");
    ASSERT(wm.getFocusedWindowId() == 0, "Focus should be cleared when hiding focused window");

    return true;
}

bool test_hit_test() {
    auto& wm = WindowManager::getInstance();
    wm.clear();
    wm.setScreenBounds(Rect(0, 0, 500, 500));

    // Create two overlapping windows
    Window::WindowId id1 = wm.createWindow("Back", "com.app1", Rect(0, 0, 200, 200));
    Window::WindowId id2 = wm.createWindow("Front", "com.app2", Rect(100, 100, 200, 200));

    wm.showWindow(id1);
    wm.showWindow(id2);

    // Focus front to bring it to top z-order
    wm.focusWindow(id2);

    // Hit test in the overlap area — should hit the front window
    Window* hit = wm.hitTest(150, 150);
    ASSERT(hit != nullptr, "Hit test should find a window");
    ASSERT(hit->getId() == id2, "Hit test should find front window in overlap area");

    // Hit test in area only covered by back window
    Window* hit2 = wm.hitTest(50, 50);
    ASSERT(hit2 != nullptr, "Hit test should find back window");
    ASSERT(hit2->getId() == id1, "Hit test should find back window in its area only");

    // Hit test outside all windows
    Window* hit3 = wm.hitTest(400, 400);
    ASSERT(hit3 == nullptr, "Hit test outside all windows should return nullptr");

    return true;
}

bool test_z_order() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Window::WindowId id1 = wm.createWindow("Low", "com.app1", Rect(0, 0, 100, 100));
    Window::WindowId id2 = wm.createWindow("High", "com.app2", Rect(0, 0, 100, 100));
    Window::WindowId id3 = wm.createWindow("Mid", "com.app3", Rect(0, 0, 100, 100));

    wm.showWindow(id1);
    wm.showWindow(id2);
    wm.showWindow(id3);

    // Set explicit z-order
    wm.setZOrder(id1, 1);
    wm.setZOrder(id2, 3);
    wm.setZOrder(id3, 2);

    auto visible = wm.getVisibleWindows();
    ASSERT(visible.size() == 3, "Should have 3 visible windows");
    ASSERT(visible[0]->getId() == id1, "First in z-order should be id1 (z=1)");
    ASSERT(visible[1]->getId() == id3, "Second should be id3 (z=2)");
    ASSERT(visible[2]->getId() == id2, "Third should be id2 (z=3)");

    return true;
}

bool test_move_resize() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    Window::WindowId id = wm.createWindow("Test", "com.app", Rect(10, 10, 100, 100));
    Window* win = wm.getWindow(id);

    wm.setWindowPosition(id, 50, 60);
    ASSERT(win->getPosition() == Point(50, 60), "Position should be (50,60)");

    wm.setWindowSize(id, 200, 150);
    ASSERT(win->getSize() == Size(200, 150), "Size should be 200x150");

    wm.setWindowBounds(id, Rect(0, 0, 320, 480));
    ASSERT(win->getBounds() == Rect(0, 0, 320, 480), "Bounds should match");

    return true;
}

bool test_multiple_windows() {
    auto& wm = WindowManager::getInstance();
    wm.clear();

    // Create 10 windows
    for (int i = 0; i < 10; ++i) {
        wm.createWindow("Win" + std::to_string(i), "com.app" + std::to_string(i),
                       Rect(i * 10, i * 10, 50, 50));
    }
    ASSERT(wm.getWindowCount() == 10, "Should have 10 windows");

    auto ids = wm.getWindowIds();
    ASSERT(ids.size() == 10, "Should have 10 IDs");

    // Clear all
    wm.clear();
    ASSERT(wm.getWindowCount() == 0, "Should have 0 windows after clear");

    return true;
}

int main() {
    printf("=== Window Manager Tests ===\n");
    test_create_window();
    test_destroy_window();
    test_show_hide_focus();
    test_hit_test();
    test_z_order();
    test_move_resize();
    test_multiple_windows();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
