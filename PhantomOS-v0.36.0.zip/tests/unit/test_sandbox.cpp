/*
 * Phantom OS - App Sandbox Tests
 *
 * License: GPL-3.0
 */

#include "phantom/security/sandbox.h"
#include <cassert>
#include <cstdio>

using namespace phantom::security;

static int test_count = 0;
static int pass_count = 0;

#define ASSERT(cond, msg) \
    test_count++; \
    if (cond) { pass_count++; } \
    else { printf("  [FAIL] %s\n", msg); }

bool test_register_and_get_policy() {
    AppSandbox sandbox;

    SandboxPolicy policy = AppSandbox::createFromProfile("com.test.app", SandboxProfile::NORMAL);
    SandboxResult result = sandbox.registerPolicy(policy);
    ASSERT(result == SandboxResult::SUCCESS, "Register should succeed");

    ASSERT(sandbox.hasPolicy("com.test.app"), "Should have policy after register");
    ASSERT(sandbox.getPolicyCount() == 1, "Should have 1 policy");

    const SandboxPolicy* retrieved = sandbox.getPolicy("com.test.app");
    ASSERT(retrieved != nullptr, "Retrieved policy should not be null");
    ASSERT(retrieved->appId == "com.test.app", "AppId should match");
    ASSERT(retrieved->profile == SandboxProfile::NORMAL, "Profile should be NORMAL");

    return true;
}

bool test_duplicate_registration() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("app1", SandboxProfile::NORMAL);
    ASSERT(sandbox.registerPolicy(policy) == SandboxResult::SUCCESS, "First register should succeed");
    ASSERT(sandbox.registerPolicy(policy) == SandboxResult::ALREADY_EXISTS, "Duplicate should fail");
    return true;
}

bool test_update_policy() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("app1", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    policy.profile = SandboxProfile::DEVELOPER;
    ASSERT(sandbox.updatePolicy("app1", policy) == SandboxResult::SUCCESS, "Update should succeed");

    const SandboxPolicy* updated = sandbox.getPolicy("app1");
    ASSERT(updated->profile == SandboxProfile::DEVELOPER, "Profile should be DEVELOPER after update");

    SandboxPolicy dummy;
    dummy.appId = "nonexistent";
    ASSERT(sandbox.updatePolicy("nonexistent", dummy) == SandboxResult::POLICY_NOT_FOUND, "Update nonexistent should fail");
    return true;
}

bool test_remove_policy() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("app1", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    ASSERT(sandbox.removePolicy("app1") == SandboxResult::SUCCESS, "Remove should succeed");
    ASSERT(!sandbox.hasPolicy("app1"), "Should not have policy after remove");
    ASSERT(sandbox.removePolicy("app1") == SandboxResult::POLICY_NOT_FOUND, "Remove again should fail");
    return true;
}

bool test_syscall_check() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("app1", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    // 'read' should be allowed in NORMAL profile
    ASSERT(sandbox.checkSyscall("app1", "read") == SyscallAction::ALLOW, "read should be ALLOW");
    ASSERT(sandbox.checkSyscall("app1", "write") == SyscallAction::ALLOW, "write should be ALLOW");

    // Unknown syscall should be denied by default
    ASSERT(sandbox.checkSyscall("app1", "execve") == SyscallAction::DENY, "execve should be DENY");

    // Unregistered app should deny everything
    ASSERT(sandbox.checkSyscall("unregistered", "read") == SyscallAction::DENY, "Unregistered app should DENY");
    return true;
}

bool test_file_access_check() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("com.test", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    FileAccess access = sandbox.checkFileAccess("com.test", "/data/app/com.test/file.txt");
    ASSERT(access == FileAccess::READ_WRITE, "App's own directory should be READ_WRITE");

    FileAccess access2 = sandbox.checkFileAccess("com.test", "/system/lib/libc.so");
    ASSERT(access2 == FileAccess::READ, "System directory should be READ");

    FileAccess access3 = sandbox.checkFileAccess("com.test", "/data/app/com.other/file.txt");
    ASSERT(access3 == FileAccess::NONE, "Other app's directory should be NONE");
    return true;
}

bool test_capability_check() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("com.test", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    ASSERT(sandbox.canAccessNetwork("com.test") == false, "NORMAL profile should not allow network");
    ASSERT(sandbox.hasCapability("com.test", "storage") == true, "NORMAL profile should allow storage");
    ASSERT(sandbox.hasCapability("com.test", "camera") == false, "NORMAL profile should not allow camera");

    // Test network profile
    SandboxPolicy netPolicy = AppSandbox::createFromProfile("com.net", SandboxProfile::NETWORK);
    sandbox.registerPolicy(netPolicy);
    ASSERT(sandbox.canAccessNetwork("com.net") == true, "NETWORK profile should allow network");
    ASSERT(sandbox.hasCapability("com.net", "internet") == true, "NETWORK profile should allow internet");
    return true;
}

bool test_create_from_profile_strict() {
    SandboxPolicy policy = AppSandbox::createFromProfile("com.strict", SandboxProfile::STRICT);

    ASSERT(policy.profile == SandboxProfile::STRICT, "Profile should be STRICT");
    ASSERT(policy.limits.maxMemoryBytes == 64 * 1024 * 1024, "Strict memory should be 64MB");
    ASSERT(policy.limits.maxFileDescriptors == 32, "Strict fd limit should be 32");
    ASSERT(policy.limits.maxProcesses == 0, "Strict process limit should be 0");

    // Strict should have read/write/exit
    auto syscalls = AppSandbox::getProfileSyscalls(SandboxProfile::STRICT);
    bool hasRead = false;
    for (const auto& sc : syscalls) {
        if (sc == "read") hasRead = true;
    }
    ASSERT(hasRead, "STRICT profile should include 'read' syscall");
    return true;
}

bool test_create_from_profile_network() {
    SandboxPolicy policy = AppSandbox::createFromProfile("com.net", SandboxProfile::NETWORK);

    ASSERT(policy.networkAllowed == true, "Network profile should allow network");
    ASSERT(policy.internetAllowed == true, "Network profile should allow internet");
    ASSERT(policy.limits.maxNetworkConnections == 64, "Network connections should be 64");

    auto syscalls = AppSandbox::getProfileSyscalls(SandboxProfile::NETWORK);
    bool hasSocket = false;
    for (const auto& sc : syscalls) {
        if (sc == "socket") hasSocket = true;
    }
    ASSERT(hasSocket, "NETWORK profile should include 'socket' syscall");
    return true;
}

bool test_validate_policy() {
    SandboxPolicy valid;
    valid.appId = "com.test";
    std::string error;
    ASSERT(AppSandbox::validatePolicy(valid, error), "Valid policy should pass validation");

    SandboxPolicy invalid;
    invalid.appId = "";
    ASSERT(!AppSandbox::validatePolicy(invalid, error), "Empty appId should fail validation");
    return true;
}

bool test_seccomp_availability() {
    // Should return false in prototype mode
    bool available = AppSandbox::isSeccompAvailable();
    ASSERT(available == false, "Seccomp should not be available in prototype");
    return true;
}

bool test_apply_sandbox() {
    AppSandbox sandbox;
    SandboxPolicy policy = AppSandbox::createFromProfile("com.test", SandboxProfile::NORMAL);
    sandbox.registerPolicy(policy);

    // Should return UNSUPPORTED since seccomp is not available
    SandboxResult result = sandbox.applySandbox("com.test");
    ASSERT(result == SandboxResult::UNSUPPORTED, "Apply should return UNSUPPORTED in prototype");

    // Nonexistent policy
    SandboxResult result2 = sandbox.applySandbox("nonexistent");
    ASSERT(result2 == SandboxResult::POLICY_NOT_FOUND, "Apply nonexistent should return POLICY_NOT_FOUND");
    return true;
}

bool test_get_registered_app_ids() {
    AppSandbox sandbox;
    sandbox.registerPolicy(AppSandbox::createFromProfile("app1", SandboxProfile::NORMAL));
    sandbox.registerPolicy(AppSandbox::createFromProfile("app2", SandboxProfile::STRICT));
    sandbox.registerPolicy(AppSandbox::createFromProfile("app3", SandboxProfile::NETWORK));

    auto ids = sandbox.getRegisteredAppIds();
    ASSERT(ids.size() == 3, "Should have 3 registered app IDs");
    return true;
}

bool test_profile_names() {
    ASSERT(AppSandbox::getProfileName(SandboxProfile::NONE) == "NONE", "NONE name");
    ASSERT(AppSandbox::getProfileName(SandboxProfile::STRICT) == "STRICT", "STRICT name");
    ASSERT(AppSandbox::getProfileName(SandboxProfile::NORMAL) == "NORMAL", "NORMAL name");
    ASSERT(AppSandbox::getProfileName(SandboxProfile::DEVELOPER) == "DEVELOPER", "DEVELOPER name");
    ASSERT(AppSandbox::getProfileName(SandboxProfile::NETWORK) == "NETWORK", "NETWORK name");
    return true;
}

bool test_action_names() {
    ASSERT(AppSandbox::getActionName(SyscallAction::ALLOW) == "ALLOW", "ALLOW name");
    ASSERT(AppSandbox::getActionName(SyscallAction::DENY) == "DENY", "DENY name");
    ASSERT(AppSandbox::getActionName(SyscallAction::LOG) == "LOG", "LOG name");
    ASSERT(AppSandbox::getActionName(SyscallAction::KILL) == "KILL", "KILL name");
    return true;
}

bool test_file_access_names() {
    ASSERT(AppSandbox::getFileAccessName(FileAccess::NONE) == "NONE", "NONE name");
    ASSERT(AppSandbox::getFileAccessName(FileAccess::READ) == "READ", "READ name");
    ASSERT(AppSandbox::getFileAccessName(FileAccess::WRITE) == "WRITE", "WRITE name");
    ASSERT(AppSandbox::getFileAccessName(FileAccess::READ_WRITE) == "READ_WRITE", "READ_WRITE name");
    return true;
}

int main() {
    printf("=== App Sandbox Tests ===\n");
    test_register_and_get_policy();
    test_duplicate_registration();
    test_update_policy();
    test_remove_policy();
    test_syscall_check();
    test_file_access_check();
    test_capability_check();
    test_create_from_profile_strict();
    test_create_from_profile_network();
    test_validate_policy();
    test_seccomp_availability();
    test_apply_sandbox();
    test_get_registered_app_ids();
    test_profile_names();
    test_action_names();
    test_file_access_names();

    printf("\nResults: %d/%d passed\n", pass_count, test_count);
    return (pass_count == test_count) ? 0 : 1;
}
