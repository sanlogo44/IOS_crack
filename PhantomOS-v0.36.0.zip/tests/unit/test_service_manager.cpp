/*
 * Phantom OS - Service Manager Tests
 * Tests for the system service lifecycle manager
 *
 * License: GPL-3.0
 */

#include "phantom/service_manager.h"
#include "phantom/service.h"
#include <cassert>
#include <cstdio>

using namespace phantom::framework;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }

// Test service implementation
class TestService : public IService {
private:
    std::string name_;
    std::string desc_;
    ServiceState state_ = ServiceState::CREATED;
    ServicePriority priority_;
    bool healthy_ = true;
    bool start_called_ = false;
    bool stop_called_ = false;

public:
    TestService(const std::string& name, ServicePriority priority, bool healthy = true)
        : name_(name), desc_("Test service: " + name), priority_(priority), healthy_(healthy) {}

    const char* getName() const override { return name_.c_str(); }
    const char* getDescription() const override { return desc_.c_str(); }
    ServiceState getState() const override { return state_; }
    ServicePriority getPriority() const override { return priority_; }

    bool onStart() override {
        start_called_ = true;
        state_ = ServiceState::RUNNING;
        return healthy_;
    }

    bool onStop() override {
        stop_called_ = true;
        state_ = ServiceState::STOPPED;
        return true;
    }

    bool isHealthy() const override { return healthy_; }
    bool wasStartCalled() const { return start_called_; }
    bool wasStopCalled() const { return stop_called_; }
};

bool test_register_service() {
    TEST("Register service");
    auto& sm = ServiceManager::getInstance();
    size_t before = sm.getServiceCount();
    sm.registerService(std::make_unique<TestService>("TestService1", ServicePriority::NORMAL));
    ASSERT(sm.getServiceCount() == before + 1, "Service count should increase");
    PASS();
    return true;
}

bool test_start_service() {
    TEST("Start service");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("TestService2", ServicePriority::NORMAL));
    auto result = sm.startService("TestService2");
    ASSERT(result == ServiceManager::Result::SUCCESS, "Service should start successfully");
    ASSERT(sm.isServiceRunning("TestService2"), "Service should be running");
    PASS();
    return true;
}

bool test_stop_service() {
    TEST("Stop service");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("TestService3", ServicePriority::NORMAL));
    sm.startService("TestService3");
    auto result = sm.stopService("TestService3");
    ASSERT(result == ServiceManager::Result::SUCCESS, "Service should stop successfully");
    ASSERT(!sm.isServiceRunning("TestService3"), "Service should not be running");
    PASS();
    return true;
}

bool test_start_all_priority_order() {
    TEST("Start all services in priority order");
    auto& sm = ServiceManager::getInstance();
    // Clear existing and add in non-priority order
    sm.registerService(std::make_unique<TestService>("LowPriority", ServicePriority::LOW));
    sm.registerService(std::make_unique<TestService>("CriticalPriority", ServicePriority::CRITICAL));
    sm.registerService(std::make_unique<TestService>("NormalPriority", ServicePriority::NORMAL));

    sm.startAll();

    ASSERT(sm.isServiceRunning("CriticalPriority"), "Critical service should be running");
    ASSERT(sm.isServiceRunning("NormalPriority"), "Normal service should be running");
    ASSERT(sm.isServiceRunning("LowPriority"), "Low priority service should be running");
    PASS();
    return true;
}

bool test_stop_all() {
    TEST("Stop all services");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("StopAll1", ServicePriority::NORMAL));
    sm.registerService(std::make_unique<TestService>("StopAll2", ServicePriority::HIGH));
    sm.startAll();
    sm.stopAll();
    ASSERT(!sm.isServiceRunning("StopAll1"), "StopAll1 should be stopped");
    ASSERT(!sm.isServiceRunning("StopAll2"), "StopAll2 should be stopped");
    PASS();
    return true;
}

bool test_duplicate_register() {
    TEST("Duplicate registration fails");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("DupService", ServicePriority::NORMAL));
    auto result = sm.registerService(std::make_unique<TestService>("DupService", ServicePriority::NORMAL));
    ASSERT(result == ServiceManager::Result::ALREADY_REGISTERED, "Should fail on duplicate");
    PASS();
    return true;
}

bool test_start_nonexistent() {
    TEST("Start non-existent service fails");
    auto& sm = ServiceManager::getInstance();
    auto result = sm.startService("NonExistentService12345");
    ASSERT(result == ServiceManager::Result::NOT_FOUND, "Should return NOT_FOUND");
    PASS();
    return true;
}

bool test_running_count() {
    TEST("Running count");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("CountTest1", ServicePriority::NORMAL));
    sm.registerService(std::make_unique<TestService>("CountTest2", ServicePriority::NORMAL));
    sm.startService("CountTest1");
    sm.startService("CountTest2");
    size_t running = sm.getRunningCount();
    ASSERT(running >= 2, "Should have at least 2 running services");
    PASS();
    return true;
}

bool test_all_healthy() {
    TEST("All services healthy check");
    auto& sm = ServiceManager::getInstance();
    sm.registerService(std::make_unique<TestService>("HealthyService", ServicePriority::NORMAL, true));
    sm.startService("HealthyService");
    ASSERT(sm.allServicesHealthy(), "All services should be healthy");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Service Manager Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_register_service();
    all_pass &= test_start_service();
    all_pass &= test_stop_service();
    all_pass &= test_start_all_priority_order();
    all_pass &= test_stop_all();
    all_pass &= test_duplicate_register();
    all_pass &= test_start_nonexistent();
    all_pass &= test_running_count();
    all_pass &= test_all_healthy();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
