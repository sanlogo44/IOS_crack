/*
 * Phantom OS - Data Sanitizer Tests
 * Tests for metadata stripping and location approximation
 *
 * License: GPL-3.0
 */

#include "phantom/privacy/data_sanitizer.h"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <cstring>

using namespace phantom::privacy;

static int test_count = 0;
static int pass_count = 0;

#define TEST(name) printf("  [TEST] %s ... ", name); test_count++;
#define PASS() printf("PASS\n"); pass_count++;
#define FAIL(msg) printf("FAIL: %s\n", msg); return false;
#define ASSERT(cond, msg) if (!(cond)) { FAIL(msg); }
#define ASSERT_NEAR(a, b, tol, msg) if (fabs((a) - (b)) > (tol)) { FAIL(msg); }

bool test_precise_location() {
    TEST("Precise location - no approximation");
    double lat = 52.5200, lng = 13.4050;
    auto result = approximateLocation(lat, lng, 0);
    ASSERT_NEAR(result.latitude, lat, 0.0001, "Precise lat should match input");
    ASSERT_NEAR(result.longitude, lng, 0.0001, "Precise lng should match input");
    PASS();
    return true;
}

bool test_approximate_location() {
    TEST("Approximate location - ~100m accuracy");
    double lat = 52.5200, lng = 13.4050;
    auto result = approximateLocation(lat, lng, 1);
    // Should be within ~0.002 degrees of original
    ASSERT_NEAR(result.latitude, lat, 0.005, "Approximate lat should be close to input");
    ASSERT_NEAR(result.longitude, lng, 0.005, "Approximate lng should be close to input");
    // Should be rounded to 3 decimal places
    double frac = result.latitude * 1000 - floor(result.latitude * 1000);
    ASSERT_NEAR(frac, 0.0, 0.001, "Approximate should be rounded");
    PASS();
    return true;
}

bool test_city_location() {
    TEST("City-level location - returns city center");
    // Berlin coordinates
    double lat = 52.5200, lng = 13.4050;
    auto result = approximateLocation(lat, lng, 2);
    // Should return Berlin city center
    ASSERT_NEAR(result.latitude, 52.5200, 0.01, "Should return Berlin lat");
    ASSERT_NEAR(result.longitude, 13.4050, 0.01, "Should return Berlin lng");
    PASS();
    return true;
}

bool test_none_location() {
    TEST("None location - returns (0, 0)");
    double lat = 52.5200, lng = 13.4050;
    auto result = approximateLocation(lat, lng, 5);
    ASSERT_NEAR(result.latitude, 0.0, 0.0001, "None should return 0 lat");
    ASSERT_NEAR(result.longitude, 0.0, 0.0001, "None should return 0 lng");
    PASS();
    return true;
}

bool test_sanitize_buffer() {
    TEST("Sanitize buffer - removes metadata");
    std::vector<uint8_t> input = {0xFF, 0xD8, 0xFF, 0xE1, 0x00, 0x04, 't', 'e', 's', 't'};
    std::vector<uint8_t> output;
    auto result = sanitizeBuffer(input, output, {MetadataField::GPS_COORDINATES, MetadataField::DEVICE_MODEL});
    ASSERT(result.success, "Sanitization should succeed");
    ASSERT(result.removed_fields.size() == 2, "Should remove 2 fields");
    ASSERT(result.original_size == input.size(), "Original size should match");
    PASS();
    return true;
}

bool test_sanitize_all_fields() {
    TEST("Sanitize all fields - ALL flag");
    std::vector<uint8_t> input = {0x01, 0x02, 0x03, 0x04};
    std::vector<uint8_t> output;
    auto result = sanitizeBuffer(input, output, {MetadataField::ALL});
    ASSERT(result.success, "Sanitization should succeed");
    ASSERT(result.removed_fields.size() >= 9, "Should remove all fields");
    PASS();
    return true;
}

bool test_metadata_field_string() {
    TEST("Metadata field to string");
    ASSERT(strcmp(metadataFieldToString(MetadataField::GPS_COORDINATES), "GPS_COORDINATES") == 0,
           "GPS_COORDINATES string mismatch");
    ASSERT(strcmp(metadataFieldToString(MetadataField::DEVICE_MANUFACTURER), "DEVICE_MANUFACTURER") == 0,
           "DEVICE_MANUFACTURER string mismatch");
    ASSERT(strcmp(metadataFieldToString(MetadataField::ALL), "ALL") == 0,
           "ALL string mismatch");
    PASS();
    return true;
}

bool test_nearest_city() {
    TEST("Nearest city - Munich area returns Munich");
    // Munich area coordinates
    double lat = 48.14, lng = 11.58;
    auto result = approximateLocation(lat, lng, 2);
    ASSERT_NEAR(result.latitude, 48.1351, 0.01, "Should return Munich lat");
    ASSERT_NEAR(result.longitude, 11.5820, 0.01, "Should return Munich lng");
    PASS();
    return true;
}

int main() {
    printf("=== Phantom OS - Data Sanitizer Tests ===\n\n");

    bool all_pass = true;
    all_pass &= test_precise_location();
    all_pass &= test_approximate_location();
    all_pass &= test_city_location();
    all_pass &= test_none_location();
    all_pass &= test_sanitize_buffer();
    all_pass &= test_sanitize_all_fields();
    all_pass &= test_metadata_field_string();
    all_pass &= test_nearest_city();

    printf("\n=== Results: %d/%d passed ===\n", pass_count, test_count);
    return all_pass ? 0 : 1;
}
