/*
 * Phantom OS - Device Lock / Authentication Manager Tests
 * v0.24.0 - License: GPL-3.0
 *
 * Tests for AuthManager: lifecycle, lock control, credential enrollment,
 * authentication, rate limiting/lockout, sessions, recovery, events, stats,
 * callbacks, integration, string helpers, failure simulation
 */

#include "phantom/auth/auth_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST(test) do { \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    std::cout << " OK" << std::endl; \
} while(0)

using namespace phantom::auth;
using namespace phantom::logging;
using namespace phantom::crashreporter;

static CredentialPolicy pinPolicy() {
    CredentialPolicy p;
    p.minLength = 4;
    p.maxLength = 8;
    p.maxAttempts = 3;
    p.lockoutDurationMs = 30000;
    p.requireDigitsOnly = true;
    return p;
}

static CredentialPolicy passwordPolicy() {
    CredentialPolicy p;
    p.minLength = 8;
    p.maxLength = 64;
    p.maxAttempts = 5;
    p.lockoutDurationMs = 60000;
    p.requireAlphanumeric = true;
    return p;
}

static CredentialPolicy biometricPolicy() {
    CredentialPolicy p;
    p.minLength = 1;
    p.maxLength = 256;
    p.maxAttempts = 10;
    p.lockoutDurationMs = 10000;
    return p;
}

// ============================================================
// Lifecycle tests
// ============================================================

static void test_initialize() {
    AuthManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), AuthResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.getLockState(), LockState::UNCONFIGURED);
    ASSERT_EQ(mgr.shutdown(), AuthResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_double_initialize() {
    AuthManager mgr;
    ASSERT_EQ(mgr.initialize(), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.initialize(), AuthResult::ALREADY_INITIALIZED);
    mgr.shutdown();
}

static void test_invalid_initialize_params() {
    AuthManager mgr;
    ASSERT_EQ(mgr.initialize(0), AuthResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(16, 0), AuthResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(16, 64, 0), AuthResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(16, 64, 500, 0), AuthResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_not_initialized_operations() {
    AuthManager mgr;
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system"), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.validateSession(1, "system"), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.revokeSession(1), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearEvents(), AuthResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.markCredentialCompromised(AuthMethod::PIN, "system"), AuthResult::NOT_INITIALIZED);
}

static void test_reinitialize() {
    AuthManager mgr;
    mgr.initialize();
    CredentialPolicy p = pinPolicy();
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system", p), AuthResult::SUCCESS);
    ASSERT_TRUE(mgr.hasCredential(AuthMethod::PIN, "system"));
    mgr.shutdown();
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "system"));
    ASSERT_EQ(mgr.getLockState(), LockState::UNCONFIGURED);
    ASSERT_EQ(mgr.initialize(), AuthResult::SUCCESS);
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "system"));
    mgr.shutdown();
}

static void test_shutdown_clears_state() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    ASSERT_TRUE(mgr.getEvents().size() > 0);
    mgr.shutdown();
    ASSERT_EQ(mgr.getStats().totalCredentials, 0u);
    ASSERT_TRUE(mgr.getEvents().empty());
}

static void test_default_limits() {
    AuthManager mgr;
    mgr.initialize(10, 20, 30, 40);
    ASSERT_EQ(mgr.getMaxCredentials(), 10u);
    ASSERT_EQ(mgr.getMaxSessions(), 20u);
    ASSERT_EQ(mgr.getMaxEvents(), 30u);
    ASSERT_EQ(mgr.getMaxHistory(), 40u);
    mgr.shutdown();
}

// ============================================================
// Lock control tests
// ============================================================

static void test_lock_requires_credential() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::NO_CREDENTIAL_CONFIGURED);
    mgr.shutdown();
}

static void test_enroll_transitions_to_unlocked() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.getLockState(), LockState::UNCONFIGURED);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    mgr.shutdown();
}

static void test_lock_and_unlock_cycle() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::LOCKED);
    ASSERT_TRUE(mgr.isLocked());

    uint64_t token = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system", &token), AuthResult::SUCCESS);
    ASSERT_TRUE(token != 0);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    ASSERT_FALSE(mgr.isLocked());
    mgr.shutdown();
}

static void test_double_lock_rejected() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::BAD_STATE);
    mgr.shutdown();
}

static void test_unlock_with_trusted_session() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    mgr.lockDevice("system");
    ASSERT_EQ(mgr.unlockDevice(token, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    mgr.shutdown();
}

static void test_unlock_unknown_session() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.lockDevice("system");
    ASSERT_EQ(mgr.unlockDevice(999999, "system"), AuthResult::SESSION_NOT_FOUND);
    mgr.shutdown();
}

static void test_unlock_wrong_owner() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    mgr.lockDevice("system");
    ASSERT_EQ(mgr.unlockDevice(token, "other.app"), AuthResult::PERMISSION_DENIED);
    mgr.shutdown();
}

static void test_unlock_when_not_locked() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    ASSERT_EQ(mgr.unlockDevice(token, "system"), AuthResult::BAD_STATE);
    mgr.shutdown();
}

static void test_set_lock_disabled() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.setLockDisabled(true, "user.app"), AuthResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.setLockDisabled(true, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::DISABLED);

    // Lock disabled: auto-grant without credential check
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "wrong", "anyone"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.setLockDisabled(false, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::LOCKED);
    mgr.shutdown();
}

static void test_lock_disabled_no_credential() {
    AuthManager mgr;
    mgr.initialize();
    // Disable without any credential enrolled
    ASSERT_EQ(mgr.setLockDisabled(true, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::BAD_STATE);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "whatever", "app"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.setLockDisabled(false, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNCONFIGURED);
    mgr.shutdown();
}

static void test_auto_lock_timeout() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setAutoLockTimeout(60000, "user.app"), AuthResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.setAutoLockTimeout(60000, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getAutoLockTimeout(), 60000u);

    // No auto-lock when not unlocked
    ASSERT_FALSE(mgr.shouldAutoLock(0));

    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);

    // Inject time
    mgr.setCurrentTimeForTesting(1000000);
    ASSERT_FALSE(mgr.shouldAutoLock(1000000 - 30000));  // 30s ago < 60s timeout
    ASSERT_TRUE(mgr.shouldAutoLock(1000000 - 60000));   // exactly at timeout
    ASSERT_TRUE(mgr.shouldAutoLock(1000000 - 120000));  // way past

    // Disabled timeout never auto-locks
    mgr.setAutoLockTimeout(0, "system");
    ASSERT_FALSE(mgr.shouldAutoLock(0));
    mgr.shutdown();
}

// ============================================================
// Credential enrollment tests
// ============================================================

static void test_enroll_pin() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_TRUE(mgr.hasCredential(AuthMethod::PIN, "system"));
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "other"));
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PASSWORD, "system"));
    mgr.shutdown();
}

static void test_enroll_duplicate_rejected() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "5678", "system", pinPolicy()), AuthResult::CREDENTIAL_EXISTS);
    // Different owner is fine
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "5678", "user.app", pinPolicy()), AuthResult::SUCCESS);
    mgr.shutdown();
}

static void test_enroll_same_owner_different_method() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getCredentialsByOwner("system").size(), 2u);
    mgr.shutdown();
}

static void test_enroll_invalid_secrets() {
    AuthManager mgr;
    mgr.initialize();
    // Too short
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "123", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // Too long
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "123456789", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // Non-digits
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "12a4", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // Empty
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // Password without letters
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PASSWORD, "12345678", "system", passwordPolicy()), AuthResult::INVALID_PARAMETER);
    // Password without digits
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PASSWORD, "abcdefgh", "system", passwordPolicy()), AuthResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "system"));
    mgr.shutdown();
}

static void test_enroll_empty_owner_rejected() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // TRUSTED_SESSION not enrollable
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::TRUSTED_SESSION, "1234", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    // RECOVERY_KEY only via generateRecoveryKey
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::RECOVERY_KEY, "1234", "system", pinPolicy()), AuthResult::INVALID_PARAMETER);
    mgr.shutdown();
}

static void test_enroll_biometric_policy() {
    AuthManager mgr;
    mgr.initialize();
    CredentialPolicy p = biometricPolicy();
    p.allowBiometric = false;
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::BIOMETRIC_STUB, "token123", "system", p), AuthResult::INVALID_PARAMETER);
    p.allowBiometric = true;
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::BIOMETRIC_STUB, "token123", "system", p), AuthResult::SUCCESS);
    ASSERT_TRUE(mgr.hasCredential(AuthMethod::BIOMETRIC_STUB, "system"));
    mgr.shutdown();
}

static void test_credential_capacity() {
    AuthManager mgr;
    mgr.initialize(2);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "a.app", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "b.app", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "c.app", pinPolicy()), AuthResult::RATE_LIMITED);
    mgr.shutdown();
}

static void test_get_credential_info() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    AuthCredential info = mgr.getCredentialInfo(AuthMethod::PIN, "system");
    ASSERT_TRUE(info.id != 0);
    ASSERT_EQ(info.owner, std::string("system"));
    ASSERT_EQ(info.method, AuthMethod::PIN);
    ASSERT_EQ(info.state, CredentialState::ACTIVE);
    ASSERT_EQ(info.version, 1u);
    // Secret hash never exposed as raw secret
    AuthCredential missing = mgr.getCredentialInfo(AuthMethod::PIN, "other");
    ASSERT_EQ(missing.id, 0u);
    mgr.shutdown();
}

static void test_list_credentials() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "user.app", passwordPolicy());
    ASSERT_EQ(mgr.listCredentials().size(), 2u);
    ASSERT_EQ(mgr.getCredentialsByOwner("system").size(), 1u);
    ASSERT_EQ(mgr.getCredentialsByOwner("user.app").size(), 1u);
    ASSERT_EQ(mgr.getCredentialsByOwner("nobody").size(), 0u);
    mgr.shutdown();
}

static void test_change_credential() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());

    // Wrong old secret
    ASSERT_EQ(mgr.changeCredential(AuthMethod::PIN, "0000", "5678", "system"), AuthResult::INVALID_CREDENTIAL);
    // Valid change
    ASSERT_EQ(mgr.changeCredential(AuthMethod::PIN, "1234", "5678", "system"), AuthResult::SUCCESS);
    AuthCredential info = mgr.getCredentialInfo(AuthMethod::PIN, "system");
    ASSERT_EQ(info.version, 2u);

    // Old secret no longer works
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::INVALID_CREDENTIAL);
    // New secret works
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "5678", "system"), AuthResult::SUCCESS);
    mgr.shutdown();
}

static void test_change_credential_invalid_new() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.changeCredential(AuthMethod::PIN, "1234", "abc", "system"), AuthResult::INVALID_PARAMETER);
    mgr.shutdown();
}

static void test_change_credential_not_found() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.changeCredential(AuthMethod::PIN, "1234", "5678", "system"), AuthResult::CREDENTIAL_NOT_FOUND);
    mgr.shutdown();
}

static void test_remove_credential() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy());

    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "system"));
    ASSERT_TRUE(mgr.hasCredential(AuthMethod::PASSWORD, "system"));

    // Removing not enrolled
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::CREDENTIAL_NOT_FOUND);
    mgr.shutdown();
}

static void test_remove_last_credential_rejected() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::BAD_STATE);
    mgr.shutdown();
}

static void test_remove_last_credential_allowed_when_disabled() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setLockDisabled(true, "system");
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_FALSE(mgr.hasCredential(AuthMethod::PIN, "system"));
    mgr.shutdown();
}

static void test_remove_credential_revokes_sessions() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_INVALID);
    mgr.shutdown();
}

static void test_remove_all_credentials_unconfigured() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy());
    // Removal of all credentials requires the lock to be disabled first
    mgr.setLockDisabled(true, "system");
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.removeCredential(AuthMethod::PASSWORD, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.setLockDisabled(false, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNCONFIGURED);
    mgr.shutdown();
}

static void test_disable_enable_credential() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());

    ASSERT_EQ(mgr.disableCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getCredentialInfo(AuthMethod::PIN, "system").state, CredentialState::DISABLED);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::CREDENTIAL_DISABLED);
    // Double disable
    ASSERT_EQ(mgr.disableCredential(AuthMethod::PIN, "system"), AuthResult::BAD_STATE);

    ASSERT_EQ(mgr.enableCredential(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getCredentialInfo(AuthMethod::PIN, "system").state, CredentialState::ACTIVE);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::SUCCESS);
    // Double enable
    ASSERT_EQ(mgr.enableCredential(AuthMethod::PIN, "system"), AuthResult::BAD_STATE);
    mgr.shutdown();
}

static void test_disable_not_found() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.disableCredential(AuthMethod::PIN, "system"), AuthResult::CREDENTIAL_NOT_FOUND);
    ASSERT_EQ(mgr.enableCredential(AuthMethod::PIN, "system"), AuthResult::CREDENTIAL_NOT_FOUND);
    mgr.shutdown();
}

static void test_mark_compromised() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);

    ASSERT_EQ(mgr.markCredentialCompromised(AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getCredentialInfo(AuthMethod::PIN, "system").state, CredentialState::COMPROMISED);
    // Compromised credential cannot authenticate
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::CREDENTIAL_DISABLED);
    // Sessions revoked
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_INVALID);
    mgr.shutdown();
}

static void test_credential_expiry() {
    AuthManager mgr;
    mgr.initialize();
    CredentialPolicy p = pinPolicy();
    p.expiresAt = 200000;  // Fixed future timestamp
    mgr.setCurrentTimeForTesting(100000);
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1234", "system", p), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::SUCCESS);

    // Advance past expiry
    mgr.setCurrentTimeForTesting(300000);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::CREDENTIAL_EXPIRED);
    mgr.shutdown();
}

// ============================================================
// Authentication tests
// ============================================================

static void test_authenticate_success() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system", &token), AuthResult::SUCCESS);
    ASSERT_TRUE(token != 0);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);

    AuthCredential info = mgr.getCredentialInfo(AuthMethod::PIN, "system");
    ASSERT_EQ(info.useCount, 1u);
    mgr.shutdown();
}

static void test_authenticate_wrong_secret() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "9999", "system"), AuthResult::INVALID_CREDENTIAL);
    ASSERT_EQ(mgr.getFailedAttempts("system", AuthMethod::PIN), 1u);
    mgr.shutdown();
}

static void test_authenticate_method_not_enrolled() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.authenticate(AuthMethod::PASSWORD, "secret12", "system"), AuthResult::METHOD_NOT_ENROLLED);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "other.app"), AuthResult::METHOD_NOT_ENROLLED);
    mgr.shutdown();
}

static void test_authenticate_biometric() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::BIOMETRIC_STUB, "biotoken", "system", biometricPolicy());
    uint64_t token = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::BIOMETRIC_STUB, "biotoken", "system", &token), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.authenticate(AuthMethod::BIOMETRIC_STUB, "wrongtoken", "system"), AuthResult::INVALID_CREDENTIAL);
    mgr.shutdown();
}

static void test_authenticate_creates_unique_tokens() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t t1 = 0, t2 = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t1);
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t2);
    ASSERT_TRUE(t1 != t2);
    ASSERT_EQ(mgr.getStats().sessionsCreated, 2u);
    mgr.shutdown();
}

static void test_authenticate_use_count_increments() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    ASSERT_EQ(mgr.getCredentialInfo(AuthMethod::PIN, "system").useCount, 3u);
    mgr.shutdown();
}

// ============================================================
// Rate limiting / lockout tests
// ============================================================

static void test_failed_attempts_tracking() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    ASSERT_EQ(mgr.getFailedAttempts("system", AuthMethod::PIN), 2u);
    // Success resets the counter
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    ASSERT_EQ(mgr.getFailedAttempts("system", AuthMethod::PIN), 0u);
    mgr.shutdown();
}

static void test_lockout_after_max_attempts() {
    AuthManager mgr;
    mgr.initialize();
    CredentialPolicy p = pinPolicy();  // maxAttempts = 3
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", p);

    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "0003", "system"), AuthResult::INVALID_CREDENTIAL);
    // Third failure triggers lockout
    ASSERT_EQ(mgr.getLockState(), LockState::TEMP_LOCKED);
    ASSERT_TRUE(mgr.isLocked());
    ASSERT_TRUE(mgr.getLockoutUntil("system", AuthMethod::PIN) > 0);
    ASSERT_EQ(mgr.getFailedAttempts("system", AuthMethod::PIN), 0u);  // Reset after trigger

    // Even the correct secret is rejected during lockout
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::LOCKED_OUT);
    ASSERT_EQ(mgr.getStats().lockouts, 1u);
    mgr.shutdown();
}

static void test_lockout_expiry() {
    AuthManager mgr;
    mgr.initialize();
    CredentialPolicy p = pinPolicy();  // lockout 30s
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", p);
    mgr.setCurrentTimeForTesting(1000000);

    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");
    ASSERT_EQ(mgr.getLockState(), LockState::TEMP_LOCKED);

    // Advance past lockout
    mgr.setCurrentTimeForTesting(1040000);
    uint64_t token = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system", &token), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    mgr.shutdown();
}

static void test_lockout_per_owner() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "a.app", pinPolicy());
    mgr.enrollCredential(AuthMethod::PIN, "5678", "b.app", pinPolicy());

    // Lockout a.app
    mgr.authenticate(AuthMethod::PIN, "0001", "a.app");
    mgr.authenticate(AuthMethod::PIN, "0002", "a.app");
    mgr.authenticate(AuthMethod::PIN, "0003", "a.app");
    ASSERT_TRUE(mgr.getLockoutUntil("a.app", AuthMethod::PIN) > 0);

    // b.app unaffected
    ASSERT_EQ(mgr.getLockoutUntil("b.app", AuthMethod::PIN), 0u);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "5678", "b.app"), AuthResult::SUCCESS);
    mgr.shutdown();
}

static void test_lockout_per_method() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy());

    // Fail PIN repeatedly
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");
    ASSERT_TRUE(mgr.getLockoutUntil("system", AuthMethod::PIN) > 0);

    // PASSWORD method unaffected
    ASSERT_EQ(mgr.getLockoutUntil("system", AuthMethod::PASSWORD), 0u);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PASSWORD, "secret12", "system"), AuthResult::SUCCESS);
    mgr.shutdown();
}

static void test_reset_failed_attempts() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");

    // Non-system caller rejected
    ASSERT_EQ(mgr.resetFailedAttempts("system", AuthMethod::PIN, "user.app"), AuthResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.resetFailedAttempts("system", AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getFailedAttempts("system", AuthMethod::PIN), 0u);
    mgr.shutdown();
}

static void test_lockout_state_recovers_to_locked() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");
    ASSERT_EQ(mgr.getLockState(), LockState::TEMP_LOCKED);
    // System can clear lockout back to LOCKED
    ASSERT_EQ(mgr.resetFailedAttempts("system", AuthMethod::PIN, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::LOCKED);
    mgr.shutdown();
}

// ============================================================
// Session tests
// ============================================================

static void test_session_validation() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);

    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);
    // Wrong owner
    ASSERT_EQ(mgr.validateSession(token, "other.app"), AuthResult::PERMISSION_DENIED);
    // Unknown token
    ASSERT_EQ(mgr.validateSession(424242, "system"), AuthResult::SESSION_NOT_FOUND);
    mgr.shutdown();
}

static void test_session_expiry() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setCurrentTimeForTesting(1000000);
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);

    // Advance 6 minutes (default session is 5 min)
    mgr.setCurrentTimeForTesting(1360000);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_EXPIRED);
    ASSERT_EQ(mgr.getSession(token).state, SessionState::EXPIRED);
    mgr.shutdown();
}

static void test_session_refresh() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setCurrentTimeForTesting(1000000);
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);

    // Extend by 10 minutes
    ASSERT_EQ(mgr.refreshSession(token, 600000), AuthResult::SUCCESS);
    mgr.setCurrentTimeForTesting(1360000);  // 6 min later
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);
    mgr.setCurrentTimeForTesting(1700000);  // > 10+5 min later
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_EXPIRED);
    mgr.shutdown();
}

static void test_session_refresh_invalid() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);

    ASSERT_EQ(mgr.refreshSession(424242, 60000), AuthResult::SESSION_NOT_FOUND);
    mgr.revokeSession(token);
    ASSERT_EQ(mgr.refreshSession(token, 60000), AuthResult::SESSION_INVALID);
    mgr.shutdown();
}

static void test_revoke_session() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t token = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &token);

    ASSERT_EQ(mgr.revokeSession(token), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_INVALID);
    ASSERT_EQ(mgr.getSession(token).state, SessionState::REVOKED);
    // Double revoke
    ASSERT_EQ(mgr.revokeSession(token), AuthResult::BAD_STATE);
    // Unknown
    ASSERT_EQ(mgr.revokeSession(424242), AuthResult::SESSION_NOT_FOUND);
    mgr.shutdown();
}

static void test_revoke_all_sessions() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t t1 = 0, t2 = 0, t3 = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t1);
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t2);
    mgr.authenticate(AuthMethod::PIN, "1234", "other.app", &t3);
    (void)t3;

    ASSERT_EQ(mgr.revokeAllSessions("system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(t1, "system"), AuthResult::SESSION_INVALID);
    ASSERT_EQ(mgr.validateSession(t2, "system"), AuthResult::SESSION_INVALID);
    // Empty owner rejected
    ASSERT_EQ(mgr.revokeAllSessions(""), AuthResult::INVALID_PARAMETER);
    // No active sessions left
    ASSERT_EQ(mgr.revokeAllSessions("system"), AuthResult::SESSION_NOT_FOUND);
    mgr.shutdown();
}

static void test_active_session_count() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(mgr.getActiveSessionCount(), 0u);
    uint64_t t1 = 0, t2 = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t1);
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t2);
    ASSERT_EQ(mgr.getActiveSessionCount(), 2u);
    mgr.revokeSession(t1);
    ASSERT_EQ(mgr.getActiveSessionCount(), 1u);
    mgr.shutdown();
}

static void test_process_expired_sessions() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setCurrentTimeForTesting(1000000);
    uint64_t t1 = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t1);

    ASSERT_EQ(mgr.processExpiredSessions(), 0u);
    mgr.setCurrentTimeForTesting(1400000);
    ASSERT_EQ(mgr.processExpiredSessions(), 1u);
    ASSERT_EQ(mgr.getSession(t1).state, SessionState::EXPIRED);
    ASSERT_EQ(mgr.processExpiredSessions(), 0u);
    mgr.shutdown();
}

static void test_session_capacity() {
    AuthManager mgr;
    mgr.initialize(16, 2);  // max 2 sessions
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    uint64_t t1 = 0, t2 = 0, t3 = 0;
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t1);
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t2);
    // Third session evicts the oldest
    mgr.authenticate(AuthMethod::PIN, "1234", "system", &t3);
    ASSERT_EQ(mgr.validateSession(t1, "system"), AuthResult::SESSION_NOT_FOUND);
    ASSERT_EQ(mgr.validateSession(t2, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(t3, "system"), AuthResult::SUCCESS);
    mgr.shutdown();
}

// ============================================================
// Recovery tests
// ============================================================

static void test_generate_recovery_key() {
    AuthManager mgr;
    mgr.initialize();
    std::string key = mgr.generateRecoveryKey("system");
    ASSERT_TRUE(!key.empty());
    // Format: 8 groups of 4 chars separated by dashes
    ASSERT_EQ(key.size(), 39u);  // 8*4 + 7 dashes
    ASSERT_TRUE(key.find('-') != std::string::npos);
    ASSERT_TRUE(mgr.hasCredential(AuthMethod::RECOVERY_KEY, "system"));
    ASSERT_TRUE(mgr.isRecoveryAvailable());
    mgr.shutdown();
}

static void test_recovery_key_not_deterministic() {
    AuthManager mgr;
    mgr.initialize();
    std::string k1 = mgr.generateRecoveryKey("system");
    std::string k2 = mgr.generateRecoveryKey("system");
    ASSERT_TRUE(k1 != k2);  // Second generation rotates the key
    mgr.shutdown();
}

static void test_recovery_key_regeneration_invalidates_old() {
    AuthManager mgr;
    mgr.initialize();
    std::string k1 = mgr.generateRecoveryKey("system");
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(k1, "system"), AuthResult::SUCCESS);

    std::string k2 = mgr.generateRecoveryKey("system");
    // Old key no longer valid
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(k1, "system"), AuthResult::INVALID_CREDENTIAL);
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(k2, "system"), AuthResult::SUCCESS);
    mgr.shutdown();
}

static void test_recovery_unlock_from_locked() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    std::string key = mgr.generateRecoveryKey("system");
    mgr.lockDevice("system");
    ASSERT_EQ(mgr.getLockState(), LockState::LOCKED);

    ASSERT_EQ(mgr.authenticateWithRecoveryKey(key, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    ASSERT_EQ(mgr.getStats().recoveryUnlocks, 1u);
    mgr.shutdown();
}

static void test_recovery_unlock_from_recovery_required() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    std::string key = mgr.generateRecoveryKey("system");

    // Trigger recovery-required via repeated lockouts
    mgr.setCurrentTimeForTesting(1000000);
    for (int round = 0; round < 5; round++) {
        mgr.setCurrentTimeForTesting(1000000 + round * 1000000);
        mgr.authenticate(AuthMethod::PIN, "0001", "system");
        mgr.authenticate(AuthMethod::PIN, "0002", "system");
        mgr.authenticate(AuthMethod::PIN, "0003", "system");
    }
    ASSERT_EQ(mgr.getLockState(), LockState::RECOVERY_REQUIRED);

    // PIN is rejected even with correct secret? No - lockout may have expired;
    // but recovery key works regardless
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(key, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);
    mgr.shutdown();
}

static void test_recovery_wrong_key() {
    AuthManager mgr;
    mgr.initialize();
    mgr.generateRecoveryKey("system");
    ASSERT_EQ(mgr.authenticateWithRecoveryKey("AAAA-BBBB-CCCC-DDDD-EEEE-FFFF-GGGG-HHHH", "system"),
              AuthResult::INVALID_CREDENTIAL);
    mgr.shutdown();
}

static void test_recovery_not_available() {
    AuthManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.isRecoveryAvailable());
    ASSERT_EQ(mgr.authenticateWithRecoveryKey("whatever", "system"), AuthResult::RECOVERY_NOT_AVAILABLE);
    // Empty owner generates nothing
    ASSERT_TRUE(mgr.generateRecoveryKey("").empty());
    mgr.shutdown();
}

static void test_recovery_rate_limit() {
    AuthManager mgr;
    mgr.initialize();
    std::string key = mgr.generateRecoveryKey("system");
    mgr.setCurrentTimeForTesting(1000000);

    // Recovery policy: maxAttempts=3
    mgr.authenticateWithRecoveryKey("AAAA-BBBB-CCCC-DDDD-EEEE-FFFF-GGGG-HHHH", "system");
    mgr.authenticateWithRecoveryKey("AAAA-BBBB-CCCC-DDDD-EEEE-FFFF-GGGG-HHHH", "system");
    ASSERT_EQ(mgr.authenticateWithRecoveryKey("AAAA-BBBB-CCCC-DDDD-EEEE-FFFF-GGGG-HHHH", "system"),
              AuthResult::INVALID_CREDENTIAL);
    // Lockout active even for the correct key
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(key, "system"), AuthResult::LOCKED_OUT);
    mgr.shutdown();
}

static void test_recovery_key_removable() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.generateRecoveryKey("system");
    ASSERT_EQ(mgr.removeCredential(AuthMethod::RECOVERY_KEY, "system"), AuthResult::SUCCESS);
    ASSERT_FALSE(mgr.isRecoveryAvailable());
    mgr.shutdown();
}

// ============================================================
// Events and stats tests
// ============================================================

static void test_events_recorded() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.lockDevice("system");
    mgr.authenticate(AuthMethod::PIN, "1234", "system");

    auto events = mgr.getEvents();
    ASSERT_TRUE(events.size() >= 3);
    bool hasEnrolled = false, hasLock = false, hasAuth = false;
    for (const auto& e : events) {
        if (e.type == AuthEventType::METHOD_ENROLLED) hasEnrolled = true;
        if (e.type == AuthEventType::LOCK) hasLock = true;
        if (e.type == AuthEventType::AUTH_SUCCESS) hasAuth = true;
    }
    ASSERT_TRUE(hasEnrolled);
    ASSERT_TRUE(hasLock);
    ASSERT_TRUE(hasAuth);
    mgr.shutdown();
}

static void test_events_by_type() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0000", "system");
    mgr.authenticate(AuthMethod::PIN, "1234", "system");

    auto failures = mgr.getEventsByType(AuthEventType::AUTH_FAILURE);
    ASSERT_EQ(failures.size(), 1u);
    ASSERT_EQ(failures[0].result, AuthResult::INVALID_CREDENTIAL);
    auto successes = mgr.getEventsByType(AuthEventType::AUTH_SUCCESS);
    ASSERT_EQ(successes.size(), 1u);
    auto locks = mgr.getEventsByType(AuthEventType::LOCKOUT);
    ASSERT_TRUE(locks.empty());
    mgr.shutdown();
}

static void test_event_limit() {
    AuthManager mgr;
    mgr.initialize(16, 64, 5);
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    for (int i = 0; i < 10; i++) {
        mgr.authenticate(AuthMethod::PIN, "0000", "system");
        mgr.authenticate(AuthMethod::PIN, "1234", "system");
    }
    // Buffer trimmed to maxEvents
    ASSERT_TRUE(mgr.getEvents().size() <= 5);
    // Limit parameter
    ASSERT_EQ(mgr.getEvents(2).size(), 2u);
    mgr.shutdown();
}

static void test_clear_events() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    ASSERT_TRUE(mgr.getEvents().size() > 0);
    ASSERT_EQ(mgr.clearEvents(), AuthResult::SUCCESS);
    ASSERT_TRUE(mgr.getEvents().empty());
    mgr.shutdown();
}

static void test_stats_lifecycle() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.enrollCredential(AuthMethod::PASSWORD, "secret12", "system", passwordPolicy());
    mgr.lockDevice("system");
    mgr.authenticate(AuthMethod::PIN, "0000", "system");
    mgr.authenticate(AuthMethod::PIN, "1234", "system");

    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.totalCredentials, 2u);
    ASSERT_EQ(stats.credentialsEnrolled, 2u);
    ASSERT_EQ(stats.lockCount, 1u);
    ASSERT_EQ(stats.unlockCount, 1u);
    ASSERT_EQ(stats.totalAuthAttempts, 2u);
    ASSERT_EQ(stats.successfulAuths, 1u);
    ASSERT_EQ(stats.failedAuths, 1u);
    ASSERT_EQ(stats.sessionsCreated, 1u);

    mgr.resetStats();
    stats = mgr.getStats();
    ASSERT_EQ(stats.totalCredentials, 2u);      // Live state untouched
    ASSERT_EQ(stats.credentialsEnrolled, 0u);
    ASSERT_EQ(stats.totalAuthAttempts, 0u);
    mgr.shutdown();
}

static void test_stats_by_method_and_result() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    mgr.authenticate(AuthMethod::PIN, "0000", "system");
    mgr.authenticate(AuthMethod::PASSWORD, "x", "system");

    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.byMethod[static_cast<size_t>(AuthMethod::PIN)], 2u);
    ASSERT_EQ(stats.byMethod[static_cast<size_t>(AuthMethod::PASSWORD)], 1u);
    ASSERT_EQ(stats.byResult[static_cast<size_t>(AuthResult::SUCCESS)], 1u);
    ASSERT_EQ(stats.byResult[static_cast<size_t>(AuthResult::INVALID_CREDENTIAL)], 1u);
    ASSERT_EQ(stats.byResult[static_cast<size_t>(AuthResult::METHOD_NOT_ENROLLED)], 1u);
    mgr.shutdown();
}

static void test_stats_by_event_type() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.lockDevice("system");
    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(AuthEventType::METHOD_ENROLLED)], 1u);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(AuthEventType::LOCK)], 1u);
    mgr.shutdown();
}

static void test_stats_recovery() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    std::string key = mgr.generateRecoveryKey("system");
    mgr.lockDevice("system");
    mgr.authenticateWithRecoveryKey(key, "system");

    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.recoveryKeysGenerated, 1u);
    ASSERT_EQ(stats.recoveryUnlocks, 1u);
    mgr.shutdown();
}

static void test_stats_lockout_tracking() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");

    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.lockouts, 1u);
    ASSERT_EQ(stats.failedAuths, 3u);
    ASSERT_EQ(stats.totalFailures, 3u);
    mgr.shutdown();
}

// ============================================================
// Callback tests
// ============================================================

static void test_lock_state_callback() {
    AuthManager mgr;
    mgr.initialize();
    int calls = 0;
    LockState lastOld = LockState::UNCONFIGURED, lastNew = LockState::UNCONFIGURED;
    mgr.setLockStateCallback([&](LockState oldState, LockState newState) {
        calls++;
        lastOld = oldState;
        lastNew = newState;
    });

    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(calls, 1);  // UNCONFIGURED -> UNLOCKED
    ASSERT_EQ(lastOld, LockState::UNCONFIGURED);
    ASSERT_EQ(lastNew, LockState::UNLOCKED);

    mgr.lockDevice("system");
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(lastNew, LockState::LOCKED);

    // Same-state transition does not fire
    mgr.lockDevice("system");
    ASSERT_EQ(calls, 2);
    mgr.shutdown();
}

static void test_auth_event_callback() {
    AuthManager mgr;
    mgr.initialize();
    int calls = 0;
    AuthEventType lastType = AuthEventType::LOCK;
    mgr.setAuthEventCallback([&](const AuthEvent& event) {
        calls++;
        lastType = event.type;
    });

    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    ASSERT_EQ(calls, 1);
    ASSERT_EQ(lastType, AuthEventType::METHOD_ENROLLED);

    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    ASSERT_EQ(calls, 3);  // METHOD_ENROLLED + SESSION_CREATED + AUTH_SUCCESS
    ASSERT_EQ(lastType, AuthEventType::AUTH_SUCCESS);
    mgr.shutdown();
}

// ============================================================
// Integration tests
// ============================================================

static void test_set_log_server() {
    AuthManager mgr;
    LogServer log;
    log.initialize();
    mgr.initialize();
    mgr.setLogServer(&log);
    ASSERT_EQ(mgr.getLogServer(), &log);
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setLogServer(nullptr);
    ASSERT_EQ(mgr.getLogServer(), nullptr);
    mgr.shutdown();
    log.shutdown();
}

static void test_set_crash_reporter() {
    AuthManager mgr;
    CrashReporter reporter;
    reporter.initialize();
    mgr.initialize();
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    mgr.setCrashReporter(nullptr);
    ASSERT_EQ(mgr.getCrashReporter(), nullptr);
    mgr.shutdown();
    reporter.shutdown();
}

static void test_log_server_on_lockout() {
    AuthManager mgr;
    LogServer log;
    log.initialize();
    mgr.initialize();
    mgr.setLogServer(&log);
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");
    // Lockout logged as warning
    ASSERT_TRUE(log.getRecentLogs(100).size() > 0);
    mgr.shutdown();
    log.shutdown();
}

static void test_crash_reporter_on_lockout() {
    AuthManager mgr;
    CrashReporter reporter;
    reporter.initialize();
    mgr.initialize();
    mgr.setCrashReporter(&reporter);
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    mgr.authenticate(AuthMethod::PIN, "0003", "system");
    // ANR captured for lockout
    ASSERT_TRUE(reporter.getRecent(10).size() > 0);
    mgr.shutdown();
    reporter.shutdown();
}

// ============================================================
// Failure simulation tests
// ============================================================

static void test_fail_next_auth_flag() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setFailNextAuth(true);
    ASSERT_TRUE(mgr.getFailNextAuth());
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::OPERATION_FAILED);
    // Flag auto-resets
    ASSERT_FALSE(mgr.getFailNextAuth());
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1234", "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().totalFailures, 1u);
    mgr.shutdown();
}

static void test_failed_auth_updates_stats() {
    AuthManager mgr;
    mgr.initialize();
    mgr.enrollCredential(AuthMethod::PIN, "1234", "system", pinPolicy());
    mgr.setFailNextAuth(true);
    mgr.authenticate(AuthMethod::PIN, "1234", "system");
    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.failedAuths, 1u);
    ASSERT_EQ(stats.successfulAuths, 0u);
    mgr.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

static void test_auth_method_to_string() {
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::PIN), "PIN");
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::PASSWORD), "PASSWORD");
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::PATTERN), "PATTERN");
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::BIOMETRIC_STUB), "BIOMETRIC_STUB");
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::RECOVERY_KEY), "RECOVERY_KEY");
    ASSERT_STREQ(AuthManager::authMethodToString(AuthMethod::TRUSTED_SESSION), "TRUSTED_SESSION");
}

static void test_lock_state_to_string() {
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::UNCONFIGURED), "UNCONFIGURED");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::UNLOCKED), "UNLOCKED");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::LOCKED), "LOCKED");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::AUTHENTICATING), "AUTHENTICATING");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::TEMP_LOCKED), "TEMP_LOCKED");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::RECOVERY_REQUIRED), "RECOVERY_REQUIRED");
    ASSERT_STREQ(AuthManager::lockStateToString(LockState::DISABLED), "DISABLED");
}

static void test_auth_result_to_string() {
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::NOT_INITIALIZED), "NOT_INITIALIZED");
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::INVALID_CREDENTIAL), "INVALID_CREDENTIAL");
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::LOCKED_OUT), "LOCKED_OUT");
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::SESSION_EXPIRED), "SESSION_EXPIRED");
    ASSERT_STREQ(AuthManager::authResultToString(AuthResult::RECOVERY_NOT_AVAILABLE), "RECOVERY_NOT_AVAILABLE");
}

static void test_session_state_to_string() {
    ASSERT_STREQ(AuthManager::sessionStateToString(SessionState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(AuthManager::sessionStateToString(SessionState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(AuthManager::sessionStateToString(SessionState::REVOKED), "REVOKED");
}

static void test_credential_state_to_string() {
    ASSERT_STREQ(AuthManager::credentialStateToString(CredentialState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(AuthManager::credentialStateToString(CredentialState::DISABLED), "DISABLED");
    ASSERT_STREQ(AuthManager::credentialStateToString(CredentialState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(AuthManager::credentialStateToString(CredentialState::COMPROMISED), "COMPROMISED");
    ASSERT_STREQ(AuthManager::credentialStateToString(CredentialState::ROTATED), "ROTATED");
}

static void test_auth_event_type_to_string() {
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::LOCK), "LOCK");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::UNLOCK), "UNLOCK");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::AUTH_SUCCESS), "AUTH_SUCCESS");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::AUTH_FAILURE), "AUTH_FAILURE");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::LOCKOUT), "LOCKOUT");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::METHOD_ENROLLED), "METHOD_ENROLLED");
    ASSERT_STREQ(AuthManager::authEventTypeToString(AuthEventType::RECOVERY_KEY_GENERATED), "RECOVERY_KEY_GENERATED");
}

static void test_string_to_auth_method() {
    ASSERT_EQ(AuthManager::stringToAuthMethod("PIN"), AuthMethod::PIN);
    ASSERT_EQ(AuthManager::stringToAuthMethod("PASSWORD"), AuthMethod::PASSWORD);
    ASSERT_EQ(AuthManager::stringToAuthMethod("PATTERN"), AuthMethod::PATTERN);
    ASSERT_EQ(AuthManager::stringToAuthMethod("BIOMETRIC_STUB"), AuthMethod::BIOMETRIC_STUB);
    ASSERT_EQ(AuthManager::stringToAuthMethod("RECOVERY_KEY"), AuthMethod::RECOVERY_KEY);
    ASSERT_EQ(AuthManager::stringToAuthMethod("TRUSTED_SESSION"), AuthMethod::TRUSTED_SESSION);
    // Unknown falls back to PIN
    ASSERT_EQ(AuthManager::stringToAuthMethod("nope"), AuthMethod::PIN);
}

static void test_string_to_lock_state() {
    ASSERT_EQ(AuthManager::stringToLockState("UNLOCKED"), LockState::UNLOCKED);
    ASSERT_EQ(AuthManager::stringToLockState("LOCKED"), LockState::LOCKED);
    ASSERT_EQ(AuthManager::stringToLockState("TEMP_LOCKED"), LockState::TEMP_LOCKED);
    ASSERT_EQ(AuthManager::stringToLockState("RECOVERY_REQUIRED"), LockState::RECOVERY_REQUIRED);
    ASSERT_EQ(AuthManager::stringToLockState("DISABLED"), LockState::DISABLED);
    // Unknown falls back to UNCONFIGURED
    ASSERT_EQ(AuthManager::stringToLockState("nope"), LockState::UNCONFIGURED);
}

static void test_string_to_auth_result() {
    ASSERT_EQ(AuthManager::stringToAuthResult("SUCCESS"), AuthResult::SUCCESS);
    ASSERT_EQ(AuthManager::stringToAuthResult("INVALID_CREDENTIAL"), AuthResult::INVALID_CREDENTIAL);
    ASSERT_EQ(AuthManager::stringToAuthResult("LOCKED_OUT"), AuthResult::LOCKED_OUT);
    ASSERT_EQ(AuthManager::stringToAuthResult("SESSION_INVALID"), AuthResult::SESSION_INVALID);
    ASSERT_EQ(AuthManager::stringToAuthResult("OPERATION_FAILED"), AuthResult::OPERATION_FAILED);
}

static void test_string_roundtrip() {
    for (int m = 0; m <= 5; m++) {
        AuthMethod method = static_cast<AuthMethod>(m);
        const char* str = AuthManager::authMethodToString(method);
        ASSERT_EQ(AuthManager::stringToAuthMethod(str), method);
    }
    for (int s = 0; s <= 6; s++) {
        LockState state = static_cast<LockState>(s);
        const char* str = AuthManager::lockStateToString(state);
        ASSERT_EQ(AuthManager::stringToLockState(str), state);
    }
}

// ============================================================
// Full workflow tests
// ============================================================

static void test_full_workflow() {
    AuthManager mgr;
    mgr.initialize(32, 64, 500, 500);

    // 1. Enroll PIN
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::PIN, "1357", "system", pinPolicy()), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);

    // 2. Enroll biometric
    ASSERT_EQ(mgr.enrollCredential(AuthMethod::BIOMETRIC_STUB, "bio1", "system", biometricPolicy()), AuthResult::SUCCESS);

    // 3. Generate recovery key
    std::string recoveryKey = mgr.generateRecoveryKey("system");
    ASSERT_TRUE(!recoveryKey.empty());

    // 4. Lock the device
    ASSERT_EQ(mgr.lockDevice("system"), AuthResult::SUCCESS);

    // 5. Fail auth, trigger lockout
    mgr.setCurrentTimeForTesting(1000000);
    mgr.authenticate(AuthMethod::PIN, "0001", "system");
    mgr.authenticate(AuthMethod::PIN, "0002", "system");
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "0003", "system"), AuthResult::INVALID_CREDENTIAL);
    ASSERT_EQ(mgr.getLockState(), LockState::TEMP_LOCKED);

    // 6. Unlock via recovery key
    ASSERT_EQ(mgr.authenticateWithRecoveryKey(recoveryKey, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);

    // 7. Lock again, unlock via biometric
    mgr.lockDevice("system");
    uint64_t token = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::BIOMETRIC_STUB, "bio1", "system", &token), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.getLockState(), LockState::UNLOCKED);

    // 8. Session lifecycle
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.refreshSession(token, 3600000), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.revokeSession(token), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(token, "system"), AuthResult::SESSION_INVALID);

    // 9. Lock and unlock via trusted session (past the PIN lockout window)
    mgr.setCurrentTimeForTesting(1040000);
    uint64_t token2 = 0;
    mgr.authenticate(AuthMethod::PIN, "1357", "system", &token2);
    mgr.lockDevice("system");
    ASSERT_EQ(mgr.unlockDevice(token2, "system"), AuthResult::SUCCESS);

    // 10. Stats reflect the whole workflow
    AuthManagerStats stats = mgr.getStats();
    ASSERT_EQ(stats.totalCredentials, 3u);
    ASSERT_TRUE(stats.recoveryUnlocks >= 1u);
    ASSERT_TRUE(stats.sessionsCreated >= 2u);
    ASSERT_TRUE(stats.lockouts >= 1u);
    ASSERT_TRUE(stats.lockCount >= 3u);
    mgr.shutdown();
}

static void test_multi_owner_workflow() {
    AuthManager mgr;
    mgr.initialize(32, 64);
    mgr.enrollCredential(AuthMethod::PIN, "1111", "app.one", pinPolicy());
    mgr.enrollCredential(AuthMethod::PIN, "2222", "app.two", pinPolicy());

    uint64_t t1 = 0, t2 = 0;
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1111", "app.one", &t1), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "2222", "app.two", &t2), AuthResult::SUCCESS);

    // Cross-owner validation fails
    ASSERT_EQ(mgr.validateSession(t1, "app.two"), AuthResult::PERMISSION_DENIED);

    // Each owner's secrets are independent
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "2222", "app.one"), AuthResult::INVALID_CREDENTIAL);
    ASSERT_EQ(mgr.authenticate(AuthMethod::PIN, "1111", "app.two"), AuthResult::INVALID_CREDENTIAL);

    // revokeAllSessions scoped per owner
    ASSERT_EQ(mgr.revokeAllSessions("app.one"), AuthResult::SUCCESS);
    ASSERT_EQ(mgr.validateSession(t1, "app.one"), AuthResult::SESSION_INVALID);
    ASSERT_EQ(mgr.validateSession(t2, "app.two"), AuthResult::SUCCESS);
    mgr.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Phantom OS Auth Manager Tests (v0.24.0) ===" << std::endl;

    // Lifecycle
    RUN_TEST(test_initialize);
    RUN_TEST(test_double_initialize);
    RUN_TEST(test_invalid_initialize_params);
    RUN_TEST(test_not_initialized_operations);
    RUN_TEST(test_reinitialize);
    RUN_TEST(test_shutdown_clears_state);
    RUN_TEST(test_default_limits);

    // Lock control
    RUN_TEST(test_lock_requires_credential);
    RUN_TEST(test_enroll_transitions_to_unlocked);
    RUN_TEST(test_lock_and_unlock_cycle);
    RUN_TEST(test_double_lock_rejected);
    RUN_TEST(test_unlock_with_trusted_session);
    RUN_TEST(test_unlock_unknown_session);
    RUN_TEST(test_unlock_wrong_owner);
    RUN_TEST(test_unlock_when_not_locked);
    RUN_TEST(test_set_lock_disabled);
    RUN_TEST(test_lock_disabled_no_credential);
    RUN_TEST(test_auto_lock_timeout);

    // Credential enrollment
    RUN_TEST(test_enroll_pin);
    RUN_TEST(test_enroll_duplicate_rejected);
    RUN_TEST(test_enroll_same_owner_different_method);
    RUN_TEST(test_enroll_invalid_secrets);
    RUN_TEST(test_enroll_empty_owner_rejected);
    RUN_TEST(test_enroll_biometric_policy);
    RUN_TEST(test_credential_capacity);
    RUN_TEST(test_get_credential_info);
    RUN_TEST(test_list_credentials);
    RUN_TEST(test_change_credential);
    RUN_TEST(test_change_credential_invalid_new);
    RUN_TEST(test_change_credential_not_found);
    RUN_TEST(test_remove_credential);
    RUN_TEST(test_remove_last_credential_rejected);
    RUN_TEST(test_remove_last_credential_allowed_when_disabled);
    RUN_TEST(test_remove_credential_revokes_sessions);
    RUN_TEST(test_remove_all_credentials_unconfigured);
    RUN_TEST(test_disable_enable_credential);
    RUN_TEST(test_disable_not_found);
    RUN_TEST(test_mark_compromised);
    RUN_TEST(test_credential_expiry);

    // Authentication
    RUN_TEST(test_authenticate_success);
    RUN_TEST(test_authenticate_wrong_secret);
    RUN_TEST(test_authenticate_method_not_enrolled);
    RUN_TEST(test_authenticate_biometric);
    RUN_TEST(test_authenticate_creates_unique_tokens);
    RUN_TEST(test_authenticate_use_count_increments);

    // Rate limiting / lockout
    RUN_TEST(test_failed_attempts_tracking);
    RUN_TEST(test_lockout_after_max_attempts);
    RUN_TEST(test_lockout_expiry);
    RUN_TEST(test_lockout_per_owner);
    RUN_TEST(test_lockout_per_method);
    RUN_TEST(test_reset_failed_attempts);
    RUN_TEST(test_lockout_state_recovers_to_locked);

    // Sessions
    RUN_TEST(test_session_validation);
    RUN_TEST(test_session_expiry);
    RUN_TEST(test_session_refresh);
    RUN_TEST(test_session_refresh_invalid);
    RUN_TEST(test_revoke_session);
    RUN_TEST(test_revoke_all_sessions);
    RUN_TEST(test_active_session_count);
    RUN_TEST(test_process_expired_sessions);
    RUN_TEST(test_session_capacity);

    // Recovery
    RUN_TEST(test_generate_recovery_key);
    RUN_TEST(test_recovery_key_not_deterministic);
    RUN_TEST(test_recovery_key_regeneration_invalidates_old);
    RUN_TEST(test_recovery_unlock_from_locked);
    RUN_TEST(test_recovery_unlock_from_recovery_required);
    RUN_TEST(test_recovery_wrong_key);
    RUN_TEST(test_recovery_not_available);
    RUN_TEST(test_recovery_rate_limit);
    RUN_TEST(test_recovery_key_removable);

    // Events and stats
    RUN_TEST(test_events_recorded);
    RUN_TEST(test_events_by_type);
    RUN_TEST(test_event_limit);
    RUN_TEST(test_clear_events);
    RUN_TEST(test_stats_lifecycle);
    RUN_TEST(test_stats_by_method_and_result);
    RUN_TEST(test_stats_by_event_type);
    RUN_TEST(test_stats_recovery);
    RUN_TEST(test_stats_lockout_tracking);

    // Callbacks
    RUN_TEST(test_lock_state_callback);
    RUN_TEST(test_auth_event_callback);

    // Integration
    RUN_TEST(test_set_log_server);
    RUN_TEST(test_set_crash_reporter);
    RUN_TEST(test_log_server_on_lockout);
    RUN_TEST(test_crash_reporter_on_lockout);

    // Failure simulation
    RUN_TEST(test_fail_next_auth_flag);
    RUN_TEST(test_failed_auth_updates_stats);

    // String helpers
    RUN_TEST(test_auth_method_to_string);
    RUN_TEST(test_lock_state_to_string);
    RUN_TEST(test_auth_result_to_string);
    RUN_TEST(test_session_state_to_string);
    RUN_TEST(test_credential_state_to_string);
    RUN_TEST(test_auth_event_type_to_string);
    RUN_TEST(test_string_to_auth_method);
    RUN_TEST(test_string_to_lock_state);
    RUN_TEST(test_string_to_auth_result);
    RUN_TEST(test_string_roundtrip);

    // Workflows
    RUN_TEST(test_full_workflow);
    RUN_TEST(test_multi_owner_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run << " passed ===" << std::endl;
    return (g_tests_failed == 0) ? 0 : 1;
}
