/*
 * Phantom OS - Clipboard Manager Tests
 * v0.27.0 - License: GPL-3.0
 *
 * Tests for ClipboardManager: lifecycle, primary clip set/get/peek/clear,
 * data types, size limits, history order/capacity/trimming/pinning,
 * per-app access control (confirmation, grants, policies), sensitive-data
 * detection and redaction, expiry policies (timeout/after-read/owner-exit/
 * system-lock), events, stats, callbacks, failure simulation, integrations,
 * string helpers, full workflow
 */

#include "phantom/clipboard/clipboard_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <iostream>
#include <cstring>
#include <string>
#include <vector>

// Test framework macros
static int g_tests_run = 0;
static int g_tests_passed = 0;
static int g_tests_failed = 0;

#define ASSERT_TRUE(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        std::cerr << "FAIL: " << #cond << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_FALSE(cond) ASSERT_TRUE(!(cond))

#define ASSERT_EQ(a, b) do { \
    g_tests_run++; \
    if ((a) != (b)) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define ASSERT_STREQ(a, b) do { \
    g_tests_run++; \
    if (strcmp((a), (b)) != 0) { \
        std::cerr << "FAIL: " << #a << " == " << #b << " (line " << __LINE__ << ")" << std::endl; \
        g_tests_failed++; \
        return; \
    } \
    g_tests_passed++; \
} while(0)

#define RUN_TEST_SIMPLE(test) do { \
    int before = g_tests_failed; \
    std::cout << "  Running " << #test << "..." << std::flush; \
    test(); \
    if (g_tests_failed > before) std::cout << "FAIL" << std::endl; \
    else std::cout << "OK" << std::endl; \
} while(0)

using namespace phantom::clipboard;

// ============================================================
// Lifecycle tests
// ============================================================

static void test_lifecycle() {
    ClipboardManager mgr;
    ASSERT_FALSE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.initialize(), ClipboardResult::ALREADY_INITIALIZED);
    ASSERT_EQ(mgr.shutdown(), ClipboardResult::SUCCESS);
    ASSERT_FALSE(mgr.isInitialized());
    // Re-initialize after shutdown
    ASSERT_EQ(mgr.initialize(10, 50, 2048), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.isInitialized());
    ASSERT_EQ(mgr.shutdown(), ClipboardResult::SUCCESS);
    // Double shutdown
    ASSERT_EQ(mgr.shutdown(), ClipboardResult::NOT_INITIALIZED);
}

static void test_initialize_invalid_params() {
    ClipboardManager mgr;
    ASSERT_EQ(mgr.initialize(0, 256, 1048576), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 0, 1048576), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.initialize(64, 256, 0), ClipboardResult::INVALID_PARAMETER);
    ASSERT_FALSE(mgr.isInitialized());
}

static void test_not_initialized_operations() {
    ClipboardManager mgr;
    ClipboardItem item;
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "hello", ClipboardDataType::TEXT),
              ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.peekPrimaryClipMetadata("com.app", item), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearPrimaryClip("com.app"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_TRUE(mgr.getHistory("com.app").empty());
    ASSERT_EQ(mgr.getClipById(1, "com.app", item), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearOwnerClips("com.app", "com.app"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearAllClips("system"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.pinClip(1, "com.app"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.unpinClip(1, "com.app"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.handleOwnerExit("com.app"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.handleSystemLock("system"), ClipboardResult::NOT_INITIALIZED);
    ASSERT_EQ(mgr.clearEvents(), ClipboardResult::NOT_INITIALIZED);
}

static void test_shutdown_clears_state() {
    ClipboardManager mgr;
    mgr.initialize(16, 64, 4096);
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    mgr.grantPasteAccess("com.app", "com.other", PasteGrantType::ALLOW_ALWAYS);
    mgr.setAppClipboardPolicy("com.x", PasteGrantType::DENY_ALWAYS);
    ASSERT_EQ(mgr.getClipCount(), (size_t)1);
    ASSERT_EQ(mgr.shutdown(), ClipboardResult::SUCCESS);
    mgr.initialize(16, 64, 4096);
    ASSERT_EQ(mgr.getClipCount(), (size_t)0);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_TRUE(mgr.getHistory("com.app").empty());
    ClipboardItem probe;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", probe), ClipboardResult::CLIP_EMPTY);
    // Grants and policies are gone too: cross-app read asks for confirmation
    // (fresh state after shutdown)
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.getPrimaryClip("com.other", probe), ClipboardResult::CONFIRMATION_REQUIRED);
    mgr.shutdown();
}

// ============================================================
// Primary clip tests
// ============================================================

static void test_set_get_owner_basic() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "Hello World", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "Hello World");
    ASSERT_STREQ(item.ownerApp.c_str(), "com.app");
    ASSERT_STREQ(item.mimeType.c_str(), "text/plain");
    ASSERT_EQ(item.type, ClipboardDataType::TEXT);
    ASSERT_EQ(item.state, ClipState::ACTIVE);
    ASSERT_TRUE(item.id != 0);
    ASSERT_EQ(item.readCount, (uint32_t)1);
    // System can read
    ClipboardItem sysItem;
    ASSERT_EQ(mgr.getPrimaryClip("system", sysItem), ClipboardResult::SUCCESS);
    ASSERT_STREQ(sysItem.data.c_str(), "Hello World");
    ASSERT_EQ(sysItem.readCount, (uint32_t)2);
    // phantos.system is also a system owner
    ASSERT_EQ(mgr.getPrimaryClip("phantos.system", sysItem), ClipboardResult::SUCCESS);
    // Read count and lastReadAt tracked
    ASSERT_TRUE(sysItem.lastReadAt > 0);
    // Second set replaces the primary
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "Second", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "Second");
    // Old primary is no longer primary but stays in history
    ASSERT_EQ(mgr.getHistory("com.app").size(), (size_t)2);
}

static void test_set_invalid_params() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPrimaryClip("", "data", ClipboardDataType::TEXT),
              ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "", ClipboardDataType::TEXT),
              ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "data", ClipboardDataType::UNKNOWN),
              ClipboardResult::UNSUPPORTED_TYPE);
    // AFTER_TIMEOUT requires a timeout
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NONE,
                                 ClipExpiryPolicy::AFTER_TIMEOUT, 0),
              ClipboardResult::INVALID_PARAMETER);
    // Custom mime type defaults when empty
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "x", ClipboardDataType::TEXT, ""),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.mimeType.c_str(), "text/plain");
}

static void test_max_data_size() {
    ClipboardManager mgr;
    mgr.initialize(64, 256, 100);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", std::string(101, 'x'),
                                 ClipboardDataType::TEXT),
              ClipboardResult::CAPACITY_EXCEEDED);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", std::string(100, 'x'),
                                 ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.dataSize(), (size_t)100);
    // Empty primary after failed set
    mgr.clearAllClips("system");
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::CLIP_EMPTY);
}

static void test_all_data_types() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "plain", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "https://example.com", ClipboardDataType::URL),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "<b>bold</b>", ClipboardDataType::HTML,
                                "text/html"),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "IMGDATA", ClipboardDataType::IMAGE_STUB,
                                "image/png"),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "/a.txt,/b.txt", ClipboardDataType::FILE_LIST_STUB),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "{rtf}", ClipboardDataType::RICH_TEXT_STUB),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "BIN", ClipboardDataType::BINARY_STUB,
                                "application/octet-stream"),
              ClipboardResult::SUCCESS);
    // Stats per type (one TEXT set from previous test managers is not shared)
    ClipboardStats stats = mgr.getStats();
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::TEXT)], (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::URL)], (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::HTML)], (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::IMAGE_STUB)], (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::FILE_LIST_STUB)],
              (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::RICH_TEXT_STUB)],
              (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::BINARY_STUB)], (uint64_t)1);
    // The binary clip is primary now
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.type, ClipboardDataType::BINARY_STUB);
}

static void test_metadata_peek_hides_content() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "SecretContent", ClipboardDataType::TEXT);
    // Any app may peek metadata, but never the content
    ClipboardItem meta;
    ASSERT_EQ(mgr.peekPrimaryClipMetadata("com.other", meta), ClipboardResult::SUCCESS);
    ASSERT_TRUE(meta.data.empty());
    ASSERT_STREQ(meta.ownerApp.c_str(), "com.app");
    ASSERT_EQ(meta.type, ClipboardDataType::TEXT);
    ASSERT_TRUE(meta.id != 0);
    // Owner peek also hides content
    ClipboardItem ownerMeta;
    ASSERT_EQ(mgr.peekPrimaryClipMetadata("com.app", ownerMeta), ClipboardResult::SUCCESS);
    ASSERT_TRUE(ownerMeta.data.empty());
    // Empty requester invalid
    ASSERT_EQ(mgr.peekPrimaryClipMetadata("", meta), ClipboardResult::INVALID_PARAMETER);
    // Empty clipboard
    mgr.clearAllClips("system");
    ASSERT_EQ(mgr.peekPrimaryClipMetadata("com.app", meta), ClipboardResult::CLIP_EMPTY);
}

static void test_clear_primary() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    // Foreign app cannot clear
    ASSERT_EQ(mgr.clearPrimaryClip("com.other"), ClipboardResult::PERMISSION_DENIED);
    // Owner clears
    ASSERT_EQ(mgr.clearPrimaryClip("com.app"), ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::CLIP_EMPTY);
    // Clearing again
    ASSERT_EQ(mgr.clearPrimaryClip("com.app"), ClipboardResult::CLIP_EMPTY);
    // System can clear a foreign clip
    mgr.setPrimaryClip("com.app", "data2", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.clearPrimaryClip("system"), ClipboardResult::SUCCESS);
    // Cleared clip remains in history with CLEARED state
    std::vector<ClipboardItem> history = mgr.getHistory("com.app", 0, true);
    ASSERT_EQ(history.size(), (size_t)2);
    ASSERT_STREQ(history[0].data.c_str(), "data2");
    ASSERT_EQ(history[1].state, ClipState::CLEARED);
    // Stats
    ASSERT_EQ(mgr.getStats().clipsCleared, (uint64_t)2);
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_CLEARED).size(), (size_t)2);
}

static void test_clear_owner_clips() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "one", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.a", "two", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.b", "three", ClipboardDataType::TEXT);
    // Foreign app cannot clear
    ASSERT_EQ(mgr.clearOwnerClips("com.a", "com.b"), ClipboardResult::PERMISSION_DENIED);
    // System clears any owner
    ASSERT_EQ(mgr.clearOwnerClips("com.a", "system"), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.getHistory("com.a", 0, true).empty());
    ASSERT_EQ(mgr.getHistory("com.b", 0, true).size(), (size_t)1);
    // Primary now belongs to com.b
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "three");
    // Owner clears own clips
    ASSERT_EQ(mgr.clearOwnerClips("com.b", "com.b"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CLIP_EMPTY);
    // No clips left to clear
    ASSERT_EQ(mgr.clearOwnerClips("com.b", "com.b"), ClipboardResult::CLIP_NOT_FOUND);
    // Invalid params
    ASSERT_EQ(mgr.clearOwnerClips("", "system"), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.clearOwnerClips("com.b", ""), ClipboardResult::INVALID_PARAMETER);
}

static void test_clear_all_system_only() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "one", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.b", "two", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.clearAllClips("com.app"), ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.getClipCount(), (size_t)2);
    ASSERT_EQ(mgr.clearAllClips("phantos.system"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipCount(), (size_t)0);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("system", item), ClipboardResult::CLIP_EMPTY);
    // Stats include both cleared clips
    ASSERT_EQ(mgr.getStats().clipsCleared, (uint64_t)2);
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_CLEARED).size(), (size_t)1);
}

// ============================================================
// History tests
// ============================================================

static void test_history_order() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "first", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "second", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "third", ClipboardDataType::TEXT);
    std::vector<ClipboardItem> history = mgr.getHistory("com.app");
    ASSERT_EQ(history.size(), (size_t)3);
    ASSERT_STREQ(history[0].data.c_str(), "third");   // Newest first
    ASSERT_STREQ(history[1].data.c_str(), "second");
    ASSERT_STREQ(history[2].data.c_str(), "first");
    // Limit
    ASSERT_EQ(mgr.getHistory("com.app", 2).size(), (size_t)2);
    ASSERT_STREQ(mgr.getHistory("com.app", 2)[0].data.c_str(), "third");
    // IDs strictly increasing with recency
    ASSERT_TRUE(history[0].id > history[1].id);
    ASSERT_TRUE(history[1].id > history[2].id);
}

static void test_history_capacity_trim() {
    ClipboardManager mgr;
    mgr.initialize(3, 256);
    mgr.setPrimaryClip("com.app", "c1", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "c2", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "c3", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.getClipCount(), (size_t)3);
    // Fourth clip trims the oldest (c1)
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "c4", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipCount(), (size_t)3);
    std::vector<ClipboardItem> history = mgr.getHistory("com.app", 0, true);
    ASSERT_STREQ(history[2].data.c_str(), "c2");  // c1 trimmed
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::HISTORY_TRIMMED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().historyTrims, (uint64_t)1);
    // The new clip is primary
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "c4");
}

static void test_pinned_blocks_trimming() {
    ClipboardManager mgr;
    mgr.initialize(3, 256);
    mgr.setPrimaryClip("com.app", "c1", ClipboardDataType::TEXT);
    uint64_t c1 = mgr.getHistory("com.app")[0].id;
    ASSERT_EQ(mgr.pinClip(c1, "com.app"), ClipboardResult::SUCCESS);
    mgr.setPrimaryClip("com.app", "c2", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "c3", ClipboardDataType::TEXT);
    // c4 arrives: c1 is pinned, so c2 is trimmed instead
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "c4", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipCount(), (size_t)3);
    std::vector<ClipboardItem> history = mgr.getHistory("com.app", 0, true);
    bool c1Present = false;
    for (const auto& h : history) {
        if (h.id == c1) c1Present = true;
    }
    ASSERT_TRUE(c1Present);
    // All remaining clips pinned: capacity exceeded
    uint64_t c3 = 0, c4 = 0;
    for (const auto& h : history) {
        if (h.data == "c3") c3 = h.id;
        if (h.data == "c4") c4 = h.id;
    }
    ASSERT_EQ(mgr.pinClip(c3, "com.app"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.pinClip(c4, "com.app"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "c5", ClipboardDataType::TEXT),
              ClipboardResult::CAPACITY_EXCEEDED);
    ASSERT_EQ(mgr.getClipCount(), (size_t)3);
}

static void test_get_clip_by_id() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    uint64_t id = mgr.getHistory("com.app")[0].id;
    ClipboardItem item;
    // Owner access
    ASSERT_EQ(mgr.getClipById(id, "com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "data");
    // System access
    ASSERT_EQ(mgr.getClipById(id, "system", item), ClipboardResult::SUCCESS);
    // Foreign app denied
    ASSERT_EQ(mgr.getClipById(id, "com.other", item), ClipboardResult::PERMISSION_DENIED);
    // Not found / invalid
    ASSERT_EQ(mgr.getClipById(9999, "com.app", item), ClipboardResult::CLIP_NOT_FOUND);
    ASSERT_EQ(mgr.getClipById(0, "com.app", item), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.getClipById(id, "", item), ClipboardResult::INVALID_PARAMETER);
    // Direct fetch does not count as a read for AFTER_READ expiry
    mgr.setPrimaryClip("com.app", "once", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_READ);
    uint64_t once = mgr.getHistory("com.app")[0].id;
    ASSERT_EQ(mgr.getClipById(once, "com.app", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipById(once, "com.app", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.state, ClipState::ACTIVE);
}

static void test_owner_only_history_visibility() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "secret-a", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.b", "secret-b", ClipboardDataType::TEXT);
    // A sees only its own clips
    std::vector<ClipboardItem> aHistory = mgr.getHistory("com.a");
    ASSERT_EQ(aHistory.size(), (size_t)1);
    ASSERT_STREQ(aHistory[0].data.c_str(), "secret-a");
    // B sees only its own clips
    ASSERT_EQ(mgr.getHistory("com.b").size(), (size_t)1);
    // System sees everything
    ASSERT_EQ(mgr.getHistory("system").size(), (size_t)2);
    // Empty requester gets nothing
    ASSERT_TRUE(mgr.getHistory("").empty());
}

static void test_no_history_flag() {
    ClipboardManager mgr;
    mgr.initialize();
    // NO_HISTORY clips never enter the history
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "ephemeral", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NO_HISTORY),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipCount(), (size_t)0);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "ephemeral");
    // Still primary and readable, just not persisted
    ASSERT_TRUE(mgr.getHistory("com.app").empty());
}

// ============================================================
// Access control tests
// ============================================================

static void test_cross_app_confirmation_required() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "private-data", ClipboardDataType::TEXT);
    ClipboardItem item;
    // Cross-app read leaks nothing by default
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CONFIRMATION_REQUIRED);
    ASSERT_TRUE(item.data.empty());
    ASSERT_TRUE(item.ownerApp.empty());
    // Confirmation request recorded
    std::vector<ClipboardEvent> events =
        mgr.getEventsByType(ClipboardEventType::CONFIRMATION_REQUESTED);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_STREQ(events[0].owner.c_str(), "com.a");
    ASSERT_STREQ(events[0].requester.c_str(), "com.b");
    ASSERT_TRUE(events[0].clipId != 0);
    ASSERT_EQ(events[0].result, ClipboardResult::CONFIRMATION_REQUIRED);
    // Stats
    ASSERT_EQ(mgr.getStats().confirmationsRequested, (uint64_t)1);
    // No read happened
    ASSERT_EQ(mgr.getStats().clipsRead, (uint64_t)0);
    // Empty requester invalid
    ASSERT_EQ(mgr.getPrimaryClip("", item), ClipboardResult::INVALID_PARAMETER);
}

static void test_allow_once_grant_consumed() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "shared", ClipboardDataType::TEXT);
    // Grant validation
    ASSERT_EQ(mgr.grantPasteAccess("", "com.b", PasteGrantType::ALLOW_ONCE),
              ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "", PasteGrantType::ALLOW_ONCE),
              ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::NONE),
              ClipboardResult::INVALID_PARAMETER);
    // Only the source owner or system may grant
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ONCE, "com.c"),
              ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ONCE, "com.a"),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "shared");
    // Grant consumed: second read requires confirmation again
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CONFIRMATION_REQUIRED);
    // System grant path
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ONCE, "system"),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
}

static void test_allow_always_grant_persists() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "shared", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    for (int i = 0; i < 3; i++) {
        ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    }
    // Still granted after multiple reads
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    // Policy change event recorded
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::APP_POLICY_CHANGED).size(), (size_t)1);
    // Grant survives a new clip from the same owner
    mgr.setPrimaryClip("com.a", "shared2", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "shared2");
}

static void test_deny_always() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "private", ClipboardDataType::TEXT);
    // denyPasteAccess = DENY_ALWAYS grant
    ASSERT_EQ(mgr.denyPasteAccess("com.a", "com.b"), ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::PERMISSION_DENIED);
    ASSERT_TRUE(item.data.empty());
    // Denial event and stats
    std::vector<ClipboardEvent> events =
        mgr.getEventsByType(ClipboardEventType::CLIP_DENIED);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_STREQ(events[0].requester.c_str(), "com.b");
    ASSERT_EQ(mgr.getStats().readsDenied, (uint64_t)1);
    // Owner unaffected
    ASSERT_EQ(mgr.getPrimaryClip("com.a", item), ClipboardResult::SUCCESS);
}

static void test_revoke_grant() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "shared", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    // Revoke (system or source owner)
    ASSERT_EQ(mgr.revokePasteAccess("com.a", "com.b", "com.c"),
              ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.revokePasteAccess("com.a", "com.b", "com.a"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CONFIRMATION_REQUIRED);
    // Revoking a non-existent grant
    ASSERT_EQ(mgr.revokePasteAccess("com.a", "com.b"), ClipboardResult::CLIP_NOT_FOUND);
    // Invalid params
    ASSERT_EQ(mgr.revokePasteAccess("", "com.b"), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.revokePasteAccess("com.a", ""), ClipboardResult::INVALID_PARAMETER);
}

static void test_app_policy() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "shared", ClipboardDataType::TEXT);
    // System-only
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.b", PasteGrantType::ALLOW_ALWAYS, "com.x"),
              ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.setAppClipboardPolicy("", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::INVALID_PARAMETER);
    // ALLOW_ALWAYS policy: com.b can read anything without confirmation
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    // DENY_ALWAYS policy overrides grants
    mgr.setPrimaryClip("com.a", "other", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.b", PasteGrantType::DENY_ALWAYS),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::PERMISSION_DENIED);
    // ALLOW_ONCE policy is consumed by one read
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.b", PasteGrantType::ALLOW_ONCE),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CONFIRMATION_REQUIRED);
    // Reset to NONE
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.b", PasteGrantType::NONE),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CONFIRMATION_REQUIRED);
    // Events (ALLOW_ALWAYS, DENY_ALWAYS, ALLOW_ONCE, NONE)
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::APP_POLICY_CHANGED).size(), (size_t)4);
}

// ============================================================
// Sensitive data tests
// ============================================================

static void test_sensitive_detection() {
    ASSERT_FALSE(ClipboardManager::isSensitiveData(""));
    ASSERT_FALSE(ClipboardManager::isSensitiveData("hello world"));
    ASSERT_FALSE(ClipboardManager::isSensitiveData("grocery list: milk, eggs"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("password=hunter2"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("my PASSWORD=secret123 here"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("token=abc.def.ghi"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("api_key=12345"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("the API_KEY is leaked"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("a very secret message"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("card 4111111111111111"));
    ASSERT_TRUE(ClipboardManager::isSensitiveData("1234567890123456"));
    // 15 digits are fine
    ASSERT_FALSE(ClipboardManager::isSensitiveData("123456789012345"));
}

static void test_sensitive_owner_full_read() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPrimaryClip("com.a", "password=hunter2", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    // SENSITIVE_DETECTED event
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::SENSITIVE_DETECTED).size(), (size_t)1);
    // Owner reads full content
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.a", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "password=hunter2");
    // Flags were applied automatically
    ASSERT_TRUE((item.privacyFlags & CLIPBOARD_PRIVACY_SENSITIVE) != 0);
    ASSERT_TRUE((item.privacyFlags & CLIPBOARD_PRIVACY_REDACT_ON_CROSS_APP) != 0);
    ASSERT_TRUE((item.privacyFlags & CLIPBOARD_PRIVACY_REQUIRE_CONFIRMATION) != 0);
    // Sensitive clips get a default timeout policy (60 s)
    ASSERT_EQ(item.expiryPolicy, ClipExpiryPolicy::AFTER_TIMEOUT);
    ASSERT_TRUE(item.expiresAt > item.createdAt);
    // Explicit expiry is preserved
    mgr.setPrimaryClip("com.a", "token=xyz", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_READ);
    ClipboardItem item2;
    ASSERT_EQ(mgr.getPrimaryClip("com.a", item2), ClipboardResult::SUCCESS);
    ASSERT_EQ(item2.expiryPolicy, ClipExpiryPolicy::AFTER_READ);
}

static void test_sensitive_cross_app_redaction() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "password=hunter2", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ClipboardItem item;
    // Granted cross-app read is redacted
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SENSITIVE_REDACTED);
    ASSERT_STREQ(item.data.c_str(), "[REDACTED]");
    // Redaction event and stats
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::REDACTION_APPLIED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().redactions, (uint64_t)1);
    // Redacted reads still count
    ASSERT_EQ(item.readCount, (uint32_t)1);
    // Repeated granted reads stay redacted
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SENSITIVE_REDACTED);
    ASSERT_EQ(mgr.getStats().redactions, (uint64_t)2);
    // Owner still sees full data
    ClipboardItem ownerItem;
    ASSERT_EQ(mgr.getPrimaryClip("com.a", ownerItem), ClipboardResult::SUCCESS);
    ASSERT_STREQ(ownerItem.data.c_str(), "password=hunter2");
    // System also sees full data
    ClipboardItem sysItem;
    ASSERT_EQ(mgr.getPrimaryClip("system", sysItem), ClipboardResult::SUCCESS);
    ASSERT_STREQ(sysItem.data.c_str(), "password=hunter2");
}

static void test_redaction_helper() {
    ASSERT_STREQ(ClipboardManager::redactData("anything").c_str(), "[REDACTED]");
    ASSERT_STREQ(ClipboardManager::redactData("").c_str(), "[REDACTED]");
    ASSERT_STREQ(ClipboardManager::redactData("password=hunter2").c_str(), "[REDACTED]");
    ASSERT_STREQ(ClipboardManager::redactData("4111111111111111").c_str(), "[REDACTED]");
}

// ============================================================
// Expiry tests
// ============================================================

static void test_expiry_after_timeout() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setCurrentTimeForTesting(1700000000000ULL);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "fleeting", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NONE,
                                 ClipExpiryPolicy::AFTER_TIMEOUT, 5000),
              ClipboardResult::SUCCESS);
    uint64_t id = mgr.getHistory("com.app")[0].id;
    ClipboardItem item;
    // Before timeout: readable
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    // Just before the boundary
    mgr.setCurrentTimeForTesting(1700000004999ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    // Past the timeout
    mgr.setCurrentTimeForTesting(1700000005000ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    // Primary is cleared, clip is expired
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::CLIP_EMPTY);
    ASSERT_EQ(mgr.getClipById(id, "com.app", item), ClipboardResult::CLIP_EXPIRED);
    // History hides expired by default
    ASSERT_TRUE(mgr.getHistory("com.app").empty());
    ASSERT_EQ(mgr.getHistory("com.app", 0, true).size(), (size_t)1);
    ASSERT_EQ(mgr.getHistory("com.app", 0, true)[0].state, ClipState::EXPIRED);
    // Event and stats
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_EXPIRED).size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)1);
    mgr.clearTimeOverride();
}

static void test_expiry_after_read() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "one-time", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NONE,
                                 ClipExpiryPolicy::AFTER_READ),
              ClipboardResult::SUCCESS);
    uint64_t id = mgr.getHistory("com.app")[0].id;
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "one-time");
    // The read consumed the clip
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::CLIP_EMPTY);
    ASSERT_EQ(mgr.getClipById(id, "com.app", item), ClipboardResult::CLIP_EXPIRED);
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)1);
    // Cross-app read also consumes
    mgr.setPrimaryClip("com.a", "shared-once", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_READ);
    ASSERT_EQ(mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.b", item), ClipboardResult::CLIP_EMPTY);
}

static void test_expiry_owner_exit() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "dies-on-exit", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::ON_OWNER_EXIT);
    mgr.setPrimaryClip("com.a", "stays", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.b", "b-exit", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::ON_OWNER_EXIT);
    ASSERT_EQ(mgr.handleOwnerExit(""), ClipboardResult::INVALID_PARAMETER);
    // Only com.a's ON_OWNER_EXIT clip expires
    ASSERT_EQ(mgr.handleOwnerExit("com.a"), ClipboardResult::SUCCESS);
    std::vector<ClipboardItem> aHistory = mgr.getHistory("com.a", 0, true);
    ASSERT_EQ(aHistory.size(), (size_t)2);
    int expired = 0;
    for (const auto& h : aHistory) {
        if (h.state == ClipState::EXPIRED) expired++;
    }
    ASSERT_EQ(expired, 1);
    ASSERT_STREQ(aHistory[0].data.c_str(), "stays");
    // "stays" was replaced as primary by com.b's clip: CLEARED, not ACTIVE
    ASSERT_EQ(aHistory[0].state, ClipState::CLEARED);
    // com.b unaffected
    ASSERT_EQ(mgr.getHistory("com.b").size(), (size_t)1);
    ASSERT_EQ(mgr.handleOwnerExit("com.b"), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.getHistory("com.b").empty());
    // Non-owner-exit policy never expires on owner exit
    mgr.setPrimaryClip("com.c", "never", ClipboardDataType::TEXT);
    mgr.handleOwnerExit("com.c");
    ASSERT_EQ(mgr.getHistory("com.c").size(), (size_t)1);
}

// === Replacement semantics ===

static void test_replacement_marks_cleared() {
    ClipboardManager mgr;
    mgr.initialize(16, 64, 2048);

    // First clip is superseded: ACTIVE -> CLEARED, pinned stays PINNED
    mgr.setPrimaryClip("com.a", "first", ClipboardDataType::TEXT);
    uint64_t firstId = mgr.getHistory("com.a")[0].id;

    mgr.setPrimaryClip("com.a", "second", ClipboardDataType::TEXT);
    uint64_t secondId = mgr.getHistory("com.a")[0].id;

    ClipboardItem item;
    ASSERT_EQ(mgr.getClipById(firstId, "com.a", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.state, ClipState::CLEARED);

    // Pin the current primary, then replace it: pinned stays PINNED
    ASSERT_EQ(mgr.pinClip(secondId, "com.a"), ClipboardResult::SUCCESS);
    mgr.setPrimaryClip("com.a", "third", ClipboardDataType::TEXT);

    ASSERT_EQ(mgr.getClipById(secondId, "com.a", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.state, ClipState::PINNED);
    ASSERT_EQ(mgr.getPrimaryClip("com.a", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "third");

    mgr.shutdown();
}

static void test_expiry_system_lock() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "locked", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::ON_SYSTEM_LOCK);
    mgr.setPrimaryClip("com.b", "persists", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.c", "locked-too", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::ON_SYSTEM_LOCK);
    // System-only operation
    ASSERT_EQ(mgr.handleSystemLock("com.app"), ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.handleSystemLock("system"), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.getHistory("com.a").empty());
    ASSERT_EQ(mgr.getHistory("com.b").size(), (size_t)1);
    ASSERT_TRUE(mgr.getHistory("com.c").empty());
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)2);
}

static void test_pinned_prevents_expiry() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setCurrentTimeForTesting(1700000000000ULL);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "pinned-fleeting", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NONE,
                                 ClipExpiryPolicy::AFTER_TIMEOUT, 5000),
              ClipboardResult::SUCCESS);
    uint64_t id = mgr.getHistory("com.app")[0].id;
    ASSERT_EQ(mgr.pinClip(id, "com.app"), ClipboardResult::SUCCESS);
    mgr.setCurrentTimeForTesting(1700000006000ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    // Pinned clip survives
    ClipboardItem item;
    ASSERT_EQ(mgr.getClipById(id, "com.app", item), ClipboardResult::SUCCESS);
    ASSERT_EQ(item.state, ClipState::PINNED);
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)0);
    // After unpinning it can expire
    ASSERT_EQ(mgr.unpinClip(id, "com.app"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipById(id, "com.app", item), ClipboardResult::CLIP_EXPIRED);
    mgr.clearTimeOverride();
}

static void test_pin_unpin_owner_checks() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "data", ClipboardDataType::TEXT);
    uint64_t id = mgr.getHistory("com.a")[0].id;
    // Invalid params
    ASSERT_EQ(mgr.pinClip(0, "com.a"), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.pinClip(id, ""), ClipboardResult::INVALID_PARAMETER);
    ASSERT_EQ(mgr.pinClip(9999, "com.a"), ClipboardResult::CLIP_NOT_FOUND);
    // Foreign app cannot pin
    ASSERT_EQ(mgr.pinClip(id, "com.b"), ClipboardResult::PERMISSION_DENIED);
    // Owner pins
    ASSERT_EQ(mgr.pinClip(id, "com.a"), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getHistory("com.a")[0].state, ClipState::PINNED);
    // Double pin
    ASSERT_EQ(mgr.pinClip(id, "com.a"), ClipboardResult::BAD_STATE);
    // System can pin/unpin any clip
    uint64_t id2;
    mgr.setPrimaryClip("com.a", "data2", ClipboardDataType::TEXT);
    id2 = mgr.getHistory("com.a")[0].id;
    ASSERT_EQ(mgr.pinClip(id2, "system"), ClipboardResult::SUCCESS);
    // Unpin checks
    ASSERT_EQ(mgr.unpinClip(9999, "com.a"), ClipboardResult::CLIP_NOT_FOUND);
    ASSERT_EQ(mgr.unpinClip(id2, "com.b"), ClipboardResult::PERMISSION_DENIED);
    ASSERT_EQ(mgr.unpinClip(id2, "system"), ClipboardResult::SUCCESS);
    ClipboardItem probe;
    ASSERT_EQ(mgr.getClipById(id2, "com.a", probe), ClipboardResult::SUCCESS);
    // Not pinned any more
    ASSERT_EQ(mgr.unpinClip(id2, "com.a"), ClipboardResult::BAD_STATE);
    // Expired clips cannot be pinned
    mgr.setCurrentTimeForTesting(1700000000000ULL);
    mgr.setPrimaryClip("com.a", "old", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_TIMEOUT, 1000);
    uint64_t id3 = mgr.getHistory("com.a")[0].id;
    mgr.setCurrentTimeForTesting(1700000002000ULL);
    mgr.processExpiredClips();
    ASSERT_EQ(mgr.pinClip(id3, "com.a"), ClipboardResult::BAD_STATE);
    mgr.clearTimeOverride();
    // Stats and events
    ASSERT_EQ(mgr.getStats().clipsPinned, (uint64_t)2);
    ASSERT_EQ(mgr.getStats().clipsUnpinned, (uint64_t)1);
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_PINNED).size(), (size_t)2);
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_UNPINNED).size(), (size_t)1);
}

static void test_process_expired_multiple() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setCurrentTimeForTesting(1700000000000ULL);
    // Two timeout clips and one that never expires
    mgr.setPrimaryClip("com.a", "t1", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_TIMEOUT, 1000);
    mgr.setPrimaryClip("com.b", "t2", ClipboardDataType::TEXT, "text/plain",
                       CLIPBOARD_PRIVACY_NONE, ClipExpiryPolicy::AFTER_TIMEOUT, 2000);
    mgr.setPrimaryClip("com.c", "forever", ClipboardDataType::TEXT);
    mgr.setCurrentTimeForTesting(1700000005000ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.getHistory("com.a").empty());
    ASSERT_TRUE(mgr.getHistory("com.b").empty());
    ASSERT_EQ(mgr.getHistory("com.c").size(), (size_t)1);
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)2);
    // Repeated calls are safe
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getStats().clipsExpired, (uint64_t)2);
    mgr.clearTimeOverride();
}

// ============================================================
// Event tests
// ============================================================

static void test_event_ring_buffer() {
    ClipboardManager mgr;
    mgr.initialize(64, 10);
    // Each set generates one CLIP_SET event; 12 sets > 10 slots
    for (int i = 0; i < 12; i++) {
        mgr.setPrimaryClip("com.app", "clip" + std::to_string(i),
                           ClipboardDataType::TEXT);
    }
    ASSERT_EQ(mgr.getEventCount(), (size_t)10);
    std::vector<ClipboardEvent> events = mgr.getEvents();
    ASSERT_EQ(events.size(), (size_t)10);
    // IDs strictly increasing
    for (size_t i = 1; i < events.size(); i++) {
        ASSERT_TRUE(events[i].id > events[i - 1].id);
    }
    ASSERT_TRUE(events[0].timestamp > 0);
    // Limit returns the most recent
    ASSERT_EQ(mgr.getEvents(3).size(), (size_t)3);
    ASSERT_TRUE(mgr.getEvents(3)[2].id == events[9].id);
    // Clear archives to history
    ASSERT_EQ(mgr.clearEvents(), ClipboardResult::SUCCESS);
    ASSERT_TRUE(mgr.getEvents().empty());
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_SET).size(), (size_t)0);
}

static void test_event_fields() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "hello", ClipboardDataType::TEXT);
    std::vector<ClipboardEvent> events =
        mgr.getEventsByType(ClipboardEventType::CLIP_SET);
    ASSERT_EQ(events.size(), (size_t)1);
    ASSERT_STREQ(events[0].owner.c_str(), "com.app");
    ASSERT_TRUE(events[0].requester.empty());
    ASSERT_TRUE(events[0].clipId != 0);
    ASSERT_EQ(events[0].result, ClipboardResult::SUCCESS);
    // Detail carries metadata, never content
    ASSERT_TRUE(events[0].detail.find("type=TEXT") != std::string::npos);
    ASSERT_TRUE(events[0].detail.find("hello") == std::string::npos);
    // Read event carries requester
    ClipboardItem item;
    mgr.getPrimaryClip("com.app", item);
    std::vector<ClipboardEvent> reads =
        mgr.getEventsByType(ClipboardEventType::CLIP_READ);
    ASSERT_EQ(reads.size(), (size_t)1);
    ASSERT_STREQ(reads[0].requester.c_str(), "com.app");
}

static void test_clear_events() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "a", ClipboardDataType::TEXT);
    uint64_t lastId = mgr.getEvents().back().id;
    ASSERT_EQ(mgr.clearEvents(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getEventCount(), (size_t)0);
    // New events continue with fresh increasing IDs
    mgr.setPrimaryClip("com.app", "b", ClipboardDataType::TEXT);
    ASSERT_EQ(mgr.getEventCount(), (size_t)1);
    ASSERT_TRUE(mgr.getEvents()[0].id > lastId);
    // Stats survive event clearing
    ASSERT_EQ(mgr.getStats().clipsSet, (uint64_t)2);
}

// ============================================================
// Stats tests
// ============================================================

static void test_stats_totals() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "12345", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.a", "678", ClipboardDataType::TEXT);
    ClipboardItem item;
    mgr.getPrimaryClip("com.a", item);   // 1 read
    mgr.getPrimaryClip("com.b", item);   // 1 confirmation request
    mgr.denyPasteAccess("com.a", "com.c");
    mgr.getPrimaryClip("com.c", item);   // 1 denied read
    mgr.setPrimaryClip("com.a", "password=x", ClipboardDataType::TEXT);
    mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS);
    mgr.getPrimaryClip("com.b", item);   // 1 redacted read
    mgr.clearPrimaryClip("com.a");       // 1 clear
    uint64_t id = mgr.getHistory("com.a", 0, true)[0].id;
    mgr.pinClip(id, "com.a");            // 1 pin
    mgr.unpinClip(id, "com.a");          // 1 unpin
    ClipboardStats stats = mgr.getStats();
    ASSERT_EQ(stats.clipsSet, (uint64_t)3);
    ASSERT_EQ(stats.clipsRead, (uint64_t)2);  // Successful reads only
    ASSERT_EQ(stats.readsDenied, (uint64_t)1);
    ASSERT_EQ(stats.clipsCleared, (uint64_t)1);
    ASSERT_EQ(stats.clipsPinned, (uint64_t)1);
    ASSERT_EQ(stats.clipsUnpinned, (uint64_t)1);
    ASSERT_EQ(stats.redactions, (uint64_t)1);
    ASSERT_EQ(stats.confirmationsRequested, (uint64_t)1);
    ASSERT_EQ(stats.bytesStored, (uint64_t)(5 + 3 + 10));
    // Owner read of "678" (3) plus the redacted read of "password=x" (10)
    ASSERT_EQ(stats.bytesRead, (uint64_t)(3 + 10));
    ASSERT_EQ(stats.totalFailures, (uint64_t)0);
}

static void test_stats_arrays() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "text", ClipboardDataType::TEXT);
    mgr.setPrimaryClip("com.app", "https://x.io", ClipboardDataType::URL);
    ClipboardItem item;
    mgr.getPrimaryClip("com.app", item);
    mgr.getPrimaryClip("com.other", item);  // confirmation
    ClipboardStats stats = mgr.getStats();
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::TEXT)], (uint64_t)1);
    ASSERT_EQ(stats.byDataType[static_cast<size_t>(ClipboardDataType::URL)], (uint64_t)1);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(ClipboardEventType::CLIP_SET)],
              (uint64_t)2);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(ClipboardEventType::CLIP_READ)],
              (uint64_t)1);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(ClipboardEventType::CONFIRMATION_REQUESTED)],
              (uint64_t)1);
    ASSERT_EQ(stats.byResult[static_cast<size_t>(ClipboardResult::SUCCESS)], (uint64_t)3);
    ASSERT_EQ(stats.byResult[static_cast<size_t>(ClipboardResult::CONFIRMATION_REQUIRED)],
              (uint64_t)1);
}

static void test_reset_stats() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    ClipboardItem item;
    mgr.getPrimaryClip("com.app", item);
    mgr.resetStats();
    ClipboardStats stats = mgr.getStats();
    ASSERT_EQ(stats.clipsSet, (uint64_t)0);
    ASSERT_EQ(stats.clipsRead, (uint64_t)0);
    ASSERT_EQ(stats.byEventType[static_cast<size_t>(ClipboardEventType::CLIP_SET)],
              (uint64_t)0);
    // Events survive a stats reset
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::CLIP_SET).size(), (size_t)1);
}

// ============================================================
// Callback tests
// ============================================================

static void test_clip_callback() {
    ClipboardManager mgr;
    mgr.initialize();
    int calls = 0;
    std::string lastData;
    mgr.setClipCallback([&](const ClipboardItem& item) {
        calls++;
        lastData = item.data;
    });
    mgr.setPrimaryClip("com.app", "hello", ClipboardDataType::TEXT);
    ASSERT_EQ(calls, 1);
    ASSERT_STREQ(lastData.c_str(), "hello");
    mgr.setPrimaryClip("com.app", "world", ClipboardDataType::TEXT);
    ASSERT_EQ(calls, 2);
    ASSERT_STREQ(lastData.c_str(), "world");
    // Clear fires the callback with the cleared item
    mgr.clearPrimaryClip("com.app");
    ASSERT_EQ(calls, 3);
}

static void test_access_callback() {
    ClipboardManager mgr;
    mgr.initialize();
    mgr.setPrimaryClip("com.a", "data", ClipboardDataType::TEXT);
    int calls = 0;
    std::string lastRequester;
    ClipboardResult lastResult = ClipboardResult::SUCCESS;
    mgr.setAccessCallback([&](const std::string& requester, ClipboardResult result) {
        calls++;
        lastRequester = requester;
        lastResult = result;
    });
    ClipboardItem item;
    mgr.getPrimaryClip("com.a", item);
    ASSERT_EQ(calls, 1);
    ASSERT_STREQ(lastRequester.c_str(), "com.a");
    ASSERT_EQ(lastResult, ClipboardResult::SUCCESS);
    mgr.getPrimaryClip("com.b", item);
    ASSERT_EQ(calls, 2);
    ASSERT_STREQ(lastRequester.c_str(), "com.b");
    ASSERT_EQ(lastResult, ClipboardResult::CONFIRMATION_REQUIRED);
    mgr.denyPasteAccess("com.a", "com.b");
    mgr.getPrimaryClip("com.b", item);
    ASSERT_EQ(calls, 3);
    ASSERT_EQ(lastResult, ClipboardResult::PERMISSION_DENIED);
}

static void test_event_callback() {
    ClipboardManager mgr;
    mgr.initialize();
    int calls = 0;
    ClipboardEventType lastType = ClipboardEventType::CLIP_SET;
    mgr.setEventCallback([&](const ClipboardEvent& event) {
        calls++;
        lastType = event.type;
    });
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    ASSERT_EQ(calls, 1);
    ASSERT_EQ(lastType, ClipboardEventType::CLIP_SET);
    ClipboardItem item;
    mgr.getPrimaryClip("com.app", item);
    ASSERT_EQ(calls, 2);
    ASSERT_EQ(lastType, ClipboardEventType::CLIP_READ);
    mgr.clearPrimaryClip("com.app");
    ASSERT_EQ(calls, 3);
    ASSERT_EQ(lastType, ClipboardEventType::CLIP_CLEARED);
}

// ============================================================
// Failure simulation tests
// ============================================================

static void test_failure_simulation() {
    ClipboardManager mgr;
    mgr.initialize();
    ASSERT_FALSE(mgr.getFailNextOperation());
    mgr.setFailNextOperation(true);
    ASSERT_TRUE(mgr.getFailNextOperation());
    // Set fails
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT),
              ClipboardResult::SIMULATED_FAILURE);
    ASSERT_FALSE(mgr.getFailNextOperation());  // One-shot
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    // Get fails
    mgr.setFailNextOperation(true);
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SIMULATED_FAILURE);
    ASSERT_EQ(mgr.getPrimaryClip("com.app", item), ClipboardResult::SUCCESS);
    // Clear fails
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.clearPrimaryClip("com.app"), ClipboardResult::SIMULATED_FAILURE);
    ASSERT_EQ(mgr.clearPrimaryClip("com.app"), ClipboardResult::SUCCESS);
    // Stats
    ASSERT_EQ(mgr.getStats().totalFailures, (uint64_t)3);
    ASSERT_EQ(mgr.getStats().byResult[static_cast<size_t>(ClipboardResult::SIMULATED_FAILURE)],
              (uint64_t)3);
}

// ============================================================
// Integration tests
// ============================================================

static void test_log_server_integration() {
    ClipboardManager mgr;
    phantom::logging::LogServer logs;
    logs.initialize(200);
    mgr.initialize();
    mgr.setLogServer(&logs);
    ASSERT_EQ(mgr.getLogServer(), &logs);
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    ClipboardItem item;
    mgr.getPrimaryClip("com.other", item);  // Logs the confirmation request
    mgr.clearPrimaryClip("com.app");
    ASSERT_TRUE(logs.getLogCount() >= 3);
    logs.shutdown();
}

static void test_log_privacy_no_content() {
    // Raw clip content must never appear in logs
    ClipboardManager mgr;
    phantom::logging::LogServer logs;
    logs.initialize(200);
    mgr.initialize();
    mgr.setLogServer(&logs);
    mgr.setPrimaryClip("com.a", "password=supersecret42", ClipboardDataType::TEXT);
    ClipboardItem item;
    mgr.getPrimaryClip("com.a", item);
    mgr.getPrimaryClip("com.b", item);  // Confirmation request
    mgr.grantPasteAccess("com.a", "com.b", PasteGrantType::ALLOW_ALWAYS);
    mgr.getPrimaryClip("com.b", item);  // Redacted
    mgr.clearPrimaryClip("com.a");
    std::vector<phantom::logging::LogEntry> entries = logs.getRecentLogs(100);
    ASSERT_TRUE(entries.size() >= 5);
    for (const auto& entry : entries) {
        ASSERT_TRUE(entry.message.find("supersecret42") == std::string::npos);
    }
    logs.shutdown();
}

static void test_crash_reporter_integration() {
    ClipboardManager mgr;
    phantom::crashreporter::CrashReporter reporter;
    reporter.initialize(100);
    mgr.initialize();
    mgr.setCrashReporter(&reporter);
    ASSERT_EQ(mgr.getCrashReporter(), &reporter);
    // Simulated failures notify the crash reporter
    mgr.setFailNextOperation(true);
    ASSERT_EQ(mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT),
              ClipboardResult::SIMULATED_FAILURE);
    ASSERT_TRUE(reporter.getRecent(10).size() >= 1);
    // Normal operations do not
    size_t before = reporter.getRecent(10).size();
    mgr.setPrimaryClip("com.app", "data", ClipboardDataType::TEXT);
    ASSERT_EQ(reporter.getRecent(10).size(), before);
    reporter.shutdown();
}

// ============================================================
// String helper tests
// ============================================================

static void test_string_helpers_types_states() {
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::TEXT), "TEXT");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::URL), "URL");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::HTML), "HTML");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::IMAGE_STUB),
                 "IMAGE_STUB");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::FILE_LIST_STUB),
                 "FILE_LIST_STUB");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::RICH_TEXT_STUB),
                 "RICH_TEXT_STUB");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::BINARY_STUB),
                 "BINARY_STUB");
    ASSERT_STREQ(ClipboardManager::clipboardDataTypeToString(ClipboardDataType::UNKNOWN),
                 "UNKNOWN");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::EMPTY), "EMPTY");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::ACTIVE), "ACTIVE");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::EXPIRED), "EXPIRED");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::PINNED), "PINNED");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::CLEARED), "CLEARED");
    ASSERT_STREQ(ClipboardManager::clipStateToString(ClipState::REDACTED), "REDACTED");
    ASSERT_STREQ(ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy::NEVER), "NEVER");
    ASSERT_STREQ(ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy::AFTER_TIMEOUT),
                 "AFTER_TIMEOUT");
    ASSERT_STREQ(ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy::AFTER_READ),
                 "AFTER_READ");
    ASSERT_STREQ(ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy::ON_OWNER_EXIT),
                 "ON_OWNER_EXIT");
    ASSERT_STREQ(ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy::ON_SYSTEM_LOCK),
                 "ON_SYSTEM_LOCK");
    ASSERT_STREQ(ClipboardManager::pasteGrantTypeToString(PasteGrantType::NONE), "NONE");
    ASSERT_STREQ(ClipboardManager::pasteGrantTypeToString(PasteGrantType::ALLOW_ONCE),
                 "ALLOW_ONCE");
    ASSERT_STREQ(ClipboardManager::pasteGrantTypeToString(PasteGrantType::ALLOW_ALWAYS),
                 "ALLOW_ALWAYS");
    ASSERT_STREQ(ClipboardManager::pasteGrantTypeToString(PasteGrantType::DENY_ALWAYS),
                 "DENY_ALWAYS");
    // Parser
    ASSERT_EQ(ClipboardManager::stringToClipboardDataType("HTML"), ClipboardDataType::HTML);
    ASSERT_EQ(ClipboardManager::stringToClipboardDataType("BINARY_STUB"),
              ClipboardDataType::BINARY_STUB);
    ASSERT_EQ(ClipboardManager::stringToClipboardDataType("bogus"),
              ClipboardDataType::UNKNOWN);
}

static void test_string_helpers_results_events() {
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::SUCCESS), "SUCCESS");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::NOT_INITIALIZED),
                 "NOT_INITIALIZED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::ALREADY_INITIALIZED),
                 "ALREADY_INITIALIZED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::INVALID_PARAMETER),
                 "INVALID_PARAMETER");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::PERMISSION_DENIED),
                 "PERMISSION_DENIED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::CLIP_NOT_FOUND),
                 "CLIP_NOT_FOUND");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::CLIP_EXPIRED),
                 "CLIP_EXPIRED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::CLIP_EMPTY),
                 "CLIP_EMPTY");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::CAPACITY_EXCEEDED),
                 "CAPACITY_EXCEEDED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::CONFIRMATION_REQUIRED),
                 "CONFIRMATION_REQUIRED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::SENSITIVE_REDACTED),
                 "SENSITIVE_REDACTED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::UNSUPPORTED_TYPE),
                 "UNSUPPORTED_TYPE");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::BAD_STATE),
                 "BAD_STATE");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::OPERATION_FAILED),
                 "OPERATION_FAILED");
    ASSERT_STREQ(ClipboardManager::clipboardResultToString(ClipboardResult::SIMULATED_FAILURE),
                 "SIMULATED_FAILURE");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_SET),
                 "CLIP_SET");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_READ),
                 "CLIP_READ");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_DENIED),
                 "CLIP_DENIED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_CLEARED),
                 "CLIP_CLEARED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_EXPIRED),
                 "CLIP_EXPIRED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_PINNED),
                 "CLIP_PINNED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::CLIP_UNPINNED),
                 "CLIP_UNPINNED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::HISTORY_TRIMMED),
                 "HISTORY_TRIMMED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(ClipboardEventType::APP_POLICY_CHANGED),
                 "APP_POLICY_CHANGED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(
                     ClipboardEventType::CONFIRMATION_REQUESTED),
                 "CONFIRMATION_REQUESTED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(
                     ClipboardEventType::CONFIRMATION_GRANTED),
                 "CONFIRMATION_GRANTED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(
                     ClipboardEventType::CONFIRMATION_DENIED),
                 "CONFIRMATION_DENIED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(
                     ClipboardEventType::SENSITIVE_DETECTED),
                 "SENSITIVE_DETECTED");
    ASSERT_STREQ(ClipboardManager::clipboardEventTypeToString(
                     ClipboardEventType::REDACTION_APPLIED),
                 "REDACTION_APPLIED");
    // Parser
    ASSERT_EQ(ClipboardManager::stringToClipboardResult("CONFIRMATION_REQUIRED"),
              ClipboardResult::CONFIRMATION_REQUIRED);
    ASSERT_EQ(ClipboardManager::stringToClipboardResult("SENSITIVE_REDACTED"),
              ClipboardResult::SENSITIVE_REDACTED);
    ASSERT_EQ(ClipboardManager::stringToClipboardResult("bogus"), ClipboardResult::SUCCESS);
}

// ============================================================
// Full workflow test
// ============================================================

static void test_full_workflow() {
    ClipboardManager mgr;
    phantom::logging::LogServer logs;
    logs.initialize(200);
    mgr.initialize(32, 200);
    mgr.setLogServer(&logs);
    mgr.setCurrentTimeForTesting(1700000000000ULL);

    // 1. App A copies an address
    ASSERT_EQ(mgr.setPrimaryClip("com.maps", "Hauptstrasse 1, Berlin", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);

    // 2. App B tries to paste: confirmation required, no data leaked
    ClipboardItem item;
    ASSERT_EQ(mgr.getPrimaryClip("com.notes", item), ClipboardResult::CONFIRMATION_REQUIRED);
    ASSERT_TRUE(item.data.empty());

    // 3. User grants one-time access; B pastes successfully
    ASSERT_EQ(mgr.grantPasteAccess("com.maps", "com.notes", PasteGrantType::ALLOW_ONCE,
                                    "system"),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.notes", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "Hauptstrasse 1, Berlin");
    // Grant consumed
    ASSERT_EQ(mgr.getPrimaryClip("com.notes", item), ClipboardResult::CONFIRMATION_REQUIRED);

    // 4. A copies a password: sensitive handling kicks in
    ASSERT_EQ(mgr.setPrimaryClip("com.browser", "password=abc123", ClipboardDataType::TEXT),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getEventsByType(ClipboardEventType::SENSITIVE_DETECTED).size(), (size_t)1);
    // Owner reads it in full
    ASSERT_EQ(mgr.getPrimaryClip("com.browser", item), ClipboardResult::SUCCESS);
    ASSERT_STREQ(item.data.c_str(), "password=abc123");
    // B has an ALLOW_ALWAYS policy but only sees redacted content
    ASSERT_EQ(mgr.setAppClipboardPolicy("com.notes", PasteGrantType::ALLOW_ALWAYS),
              ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.notes", item), ClipboardResult::SENSITIVE_REDACTED);
    ASSERT_STREQ(item.data.c_str(), "[REDACTED]");

    // 5. The sensitive clip auto-expires after its default timeout (60 s)
    mgr.setCurrentTimeForTesting(1700000061000ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getPrimaryClip("com.notes", item), ClipboardResult::CLIP_EMPTY);

    // 6. A pins a useful clip; it survives expiry and trimming
    mgr.setCurrentTimeForTesting(1700000100000ULL);
    ASSERT_EQ(mgr.setPrimaryClip("com.maps", "pinned-address", ClipboardDataType::TEXT,
                                 "text/plain", CLIPBOARD_PRIVACY_NONE,
                                 ClipExpiryPolicy::AFTER_TIMEOUT, 5000),
              ClipboardResult::SUCCESS);
    uint64_t pinned = mgr.getHistory("com.maps")[0].id;
    ASSERT_EQ(mgr.pinClip(pinned, "com.maps"), ClipboardResult::SUCCESS);
    mgr.setCurrentTimeForTesting(1700000110000ULL);
    ASSERT_EQ(mgr.processExpiredClips(), ClipboardResult::SUCCESS);
    ASSERT_EQ(mgr.getClipById(pinned, "com.maps", item), ClipboardResult::SUCCESS);

    // 7. System lock clears ON_SYSTEM_LOCK clips; final stats
    ASSERT_EQ(mgr.handleSystemLock("system"), ClipboardResult::SUCCESS);
    ClipboardStats stats = mgr.getStats();
    ASSERT_EQ(stats.clipsSet, (uint64_t)3);
    ASSERT_TRUE(stats.clipsRead >= 3);
    ASSERT_EQ(stats.redactions, (uint64_t)1);
    ASSERT_EQ(stats.confirmationsRequested, (uint64_t)2);
    ASSERT_EQ(stats.clipsExpired, (uint64_t)1);
    ASSERT_EQ(stats.clipsPinned, (uint64_t)1);

    mgr.clearTimeOverride();
    mgr.shutdown();
    logs.shutdown();
}

// ============================================================
// Main
// ============================================================

int main() {
    std::cout << "=== Phantom OS Clipboard Manager Tests (v0.27.0) ===" << std::endl;

    RUN_TEST_SIMPLE(test_lifecycle);
    RUN_TEST_SIMPLE(test_initialize_invalid_params);
    RUN_TEST_SIMPLE(test_not_initialized_operations);
    RUN_TEST_SIMPLE(test_shutdown_clears_state);
    RUN_TEST_SIMPLE(test_set_get_owner_basic);
    RUN_TEST_SIMPLE(test_set_invalid_params);
    RUN_TEST_SIMPLE(test_max_data_size);
    RUN_TEST_SIMPLE(test_all_data_types);
    RUN_TEST_SIMPLE(test_metadata_peek_hides_content);
    RUN_TEST_SIMPLE(test_clear_primary);
    RUN_TEST_SIMPLE(test_clear_owner_clips);
    RUN_TEST_SIMPLE(test_clear_all_system_only);
    RUN_TEST_SIMPLE(test_history_order);
    RUN_TEST_SIMPLE(test_history_capacity_trim);
    RUN_TEST_SIMPLE(test_pinned_blocks_trimming);
    RUN_TEST_SIMPLE(test_get_clip_by_id);
    RUN_TEST_SIMPLE(test_owner_only_history_visibility);
    RUN_TEST_SIMPLE(test_no_history_flag);
    RUN_TEST_SIMPLE(test_cross_app_confirmation_required);
    RUN_TEST_SIMPLE(test_allow_once_grant_consumed);
    RUN_TEST_SIMPLE(test_allow_always_grant_persists);
    RUN_TEST_SIMPLE(test_deny_always);
    RUN_TEST_SIMPLE(test_revoke_grant);
    RUN_TEST_SIMPLE(test_app_policy);
    RUN_TEST_SIMPLE(test_sensitive_detection);
    RUN_TEST_SIMPLE(test_sensitive_owner_full_read);
    RUN_TEST_SIMPLE(test_sensitive_cross_app_redaction);
    RUN_TEST_SIMPLE(test_redaction_helper);
    RUN_TEST_SIMPLE(test_expiry_after_timeout);
    RUN_TEST_SIMPLE(test_expiry_after_read);
    RUN_TEST_SIMPLE(test_expiry_owner_exit);
    RUN_TEST_SIMPLE(test_replacement_marks_cleared);
    RUN_TEST_SIMPLE(test_expiry_system_lock);
    RUN_TEST_SIMPLE(test_pinned_prevents_expiry);
    RUN_TEST_SIMPLE(test_pin_unpin_owner_checks);
    RUN_TEST_SIMPLE(test_process_expired_multiple);
    RUN_TEST_SIMPLE(test_event_ring_buffer);
    RUN_TEST_SIMPLE(test_event_fields);
    RUN_TEST_SIMPLE(test_clear_events);
    RUN_TEST_SIMPLE(test_stats_totals);
    RUN_TEST_SIMPLE(test_stats_arrays);
    RUN_TEST_SIMPLE(test_reset_stats);
    RUN_TEST_SIMPLE(test_clip_callback);
    RUN_TEST_SIMPLE(test_access_callback);
    RUN_TEST_SIMPLE(test_event_callback);
    RUN_TEST_SIMPLE(test_failure_simulation);
    RUN_TEST_SIMPLE(test_log_server_integration);
    RUN_TEST_SIMPLE(test_log_privacy_no_content);
    RUN_TEST_SIMPLE(test_crash_reporter_integration);
    RUN_TEST_SIMPLE(test_string_helpers_types_states);
    RUN_TEST_SIMPLE(test_string_helpers_results_events);
    RUN_TEST_SIMPLE(test_full_workflow);

    std::cout << "\n=== Results: " << g_tests_passed << "/" << g_tests_run
              << " passed ===" << std::endl;
    return g_tests_failed == 0 ? 0 : 1;
}
