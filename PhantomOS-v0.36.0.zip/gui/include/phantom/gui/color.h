/*
 * Phantom OS - GUI Color
 * RGBA color type and blending helpers
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>

namespace phantom::gui {

struct Color {
    uint8_t r = 0;
    uint8_t g = 0;
    uint8_t b = 0;
    uint8_t a = 255;

    Color() = default;
    Color(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) : r(r), g(g), b(b), a(a) {}

    // Common colors
    static const Color Black;
    static const Color White;
    static const Color Red;
    static const Color Green;
    static const Color Blue;
    static const Color Transparent;
    static const Color DarkGray;
    static const Color LightGray;

    uint32_t toRGBA32() const {
        return (static_cast<uint32_t>(r) << 24) |
               (static_cast<uint32_t>(g) << 16) |
               (static_cast<uint32_t>(b) << 8) |
               static_cast<uint32_t>(a);
    }

    static Color fromRGBA32(uint32_t rgba) {
        return Color(
            static_cast<uint8_t>((rgba >> 24) & 0xFF),
            static_cast<uint8_t>((rgba >> 16) & 0xFF),
            static_cast<uint8_t>((rgba >> 8) & 0xFF),
            static_cast<uint8_t>(rgba & 0xFF)
        );
    }

    bool operator==(const Color& other) const {
        return r == other.r && g == other.g && b == other.b && a == other.a;
    }
    bool operator!=(const Color& other) const { return !(*this == other); }
};

// Alpha blend src over dst, returns blended color
inline Color blend(const Color& src, const Color& dst) {
    if (src.a == 0) return dst;
    if (src.a == 255) return src;
    float alpha = src.a / 255.0f;
    float inv = 1.0f - alpha;
    return Color(
        static_cast<uint8_t>(src.r * alpha + dst.r * inv),
        static_cast<uint8_t>(src.g * alpha + dst.g * inv),
        static_cast<uint8_t>(src.b * alpha + dst.b * inv),
        static_cast<uint8_t>(255 - (255 - src.a) * (255 - dst.a) / 255)
    );
}

}  // namespace phantom::gui
