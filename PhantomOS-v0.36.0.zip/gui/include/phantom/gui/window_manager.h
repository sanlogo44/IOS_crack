/*
 * Phantom OS - GUI Window Manager
 * Manages window lifecycle, z-order, focus, and hit-testing
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/window.h"
#include <vector>
#include <memory>
#include <functional>

namespace phantom::gui {

class WindowManager {
public:
    enum class Result {
        SUCCESS = 0,
        INVALID_PARAMETER = 1,
        WINDOW_NOT_FOUND = 2,
        ALREADY_EXISTS = 3,
        OUT_OF_RESOURCES = 4,
    };

    static WindowManager& getInstance();

    // Window creation / destruction
    Window::WindowId createWindow(const std::string& title, const std::string& appId,
                                   const Rect& bounds,
                                   WindowFlags flags = WindowFlags::FOCUSABLE | WindowFlags::TOUCHABLE);
    Result destroyWindow(Window::WindowId id);

    // Window queries
    Window* getWindow(Window::WindowId id);
    const Window* getWindow(Window::WindowId id) const;
    size_t getWindowCount() const { return windows_.size(); }
    std::vector<Window::WindowId> getWindowIds() const;

    // Window state management
    Result showWindow(Window::WindowId id);
    Result hideWindow(Window::WindowId id);
    Result focusWindow(Window::WindowId id);
    Result setWindowPosition(Window::WindowId id, int32_t x, int32_t y);
    Result setWindowSize(Window::WindowId id, int32_t w, int32_t h);
    Result setWindowBounds(Window::WindowId id, const Rect& bounds);
    Result setZOrder(Window::WindowId id, int32_t z);

    // Focus management
    Window::WindowId getFocusedWindowId() const { return focusedWindowId_; }
    Window* getFocusedWindow();
    Result clearFocus();

    // Hit-testing: find the topmost visible touchable window at a point
    Window* hitTest(int32_t x, int32_t y);
    const Window* hitTest(int32_t x, int32_t y) const;

    // Get visible windows sorted by z-order (ascending = back to front)
    std::vector<Window*> getVisibleWindows();

    // Get all windows sorted by z-order
    std::vector<Window*> getAllWindowsSorted();

    // Screen bounds (set by display HAL)
    void setScreenBounds(const Rect& bounds) { screenBounds_ = bounds; }
    Rect getScreenBounds() const { return screenBounds_; }

    // Clear all windows
    void clear();

private:
    WindowManager() = default;
    WindowManager(const WindowManager&) = delete;
    WindowManager& operator=(const WindowManager&) = delete;

    std::vector<std::unique_ptr<Window>> windows_;
    Window::WindowId nextWindowId_ = 1;
    Window::WindowId focusedWindowId_ = 0;
    Rect screenBounds_;

    Window* findWindow(Window::WindowId id);
    const Window* findWindow(Window::WindowId id) const;
};

}  // namespace phantom::gui
