/*
 * Phantom OS - GUI Compositor
 * Software compositor that renders visible windows into a framebuffer
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/window_manager.h"
#include "phantom/gui/framebuffer.h"
#include <memory>

namespace phantom::gui {

class Compositor {
public:
    Compositor() = default;

    // Set the output framebuffer dimensions
    void setOutputSize(int32_t width, int32_t height);
    void setOutputSize(const Size& size);

    int32_t getOutputWidth() const { return output_ ? output_->getWidth() : 0; }
    int32_t getOutputHeight() const { return output_ ? output_->getHeight() : 0; }

    // Set background color (cleared before compositing)
    void setBackgroundColor(const Color& color) { bgColor_ = color; }
    Color getBackgroundColor() const { return bgColor_; }

    // Compose all visible windows into the output framebuffer
    // Uses WindowManager singleton to get visible windows
    void compose();

    // Compose with a custom window list (for testing)
    void compose(const std::vector<Window*>& windows);

    // Get the output framebuffer for reading pixels
    const Framebuffer& getOutput() const { return *output_; }
    Framebuffer& getOutput() { return *output_; }

    // Check if a specific pixel matches expected color (for testing)
    bool verifyPixel(int32_t x, int32_t y, const Color& expected) const;

    // Count non-background pixels (for testing)
    int32_t countNonBackgroundPixels() const;

    // Stats from last composition
    int32_t getLastCompositedWindowCount() const { return lastWindowCount_; }
    int32_t getLastCompositedPixelCount() const { return lastPixelCount_; }

private:
    std::unique_ptr<Framebuffer> output_;
    Color bgColor_ = Color::Black;
    int32_t lastWindowCount_ = 0;
    int32_t lastPixelCount_ = 0;
};

}  // namespace phantom::gui
