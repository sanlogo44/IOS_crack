/*
 * Phantom OS - GUI Layout System
 * LinearLayout and FrameLayout for widget arrangement
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include <vector>

namespace phantom::gui {

enum class LayoutOrientation {
    VERTICAL = 0,
    HORIZONTAL = 1,
};

enum class LayoutGravity {
    TOP_LEFT = 0,
    TOP_CENTER = 1,
    TOP_RIGHT = 2,
    CENTER = 3,
    BOTTOM_CENTER = 4,
    FILL = 5,
};

// Base layout interface
class Layout {
public:
    virtual ~Layout() = default;

    // Measure the preferred size of a widget tree
    virtual Size measure(const Widget& container) const = 0;

    // Layout children within the container's bounds
    virtual void layout(Widget& container) = 0;
};

// LinearLayout: arranges children in a single direction (vertical or horizontal)
class LinearLayout : public Layout {
public:
    LinearLayout(LayoutOrientation orientation = LayoutOrientation::VERTICAL);

    void setOrientation(LayoutOrientation o) { orientation_ = o; }
    LayoutOrientation getOrientation() const { return orientation_; }

    void setSpacing(int32_t spacing) { spacing_ = spacing; }
    int32_t getSpacing() const { return spacing_; }

    void setGravity(LayoutGravity g) { gravity_ = g; }
    LayoutGravity getGravity() const { return gravity_; }

    Size measure(const Widget& container) const override;
    void layout(Widget& container) override;

private:
    LayoutOrientation orientation_ = LayoutOrientation::VERTICAL;
    int32_t spacing_ = 0;
    LayoutGravity gravity_ = LayoutGravity::TOP_LEFT;
};

// FrameLayout: stacks children on top of each other, optionally with gravity
class FrameLayout : public Layout {
public:
    FrameLayout() = default;

    void setGravity(LayoutGravity g) { gravity_ = g; }
    LayoutGravity getGravity() const { return gravity_; }

    Size measure(const Widget& container) const override;
    void layout(Widget& container) override;

private:
    LayoutGravity gravity_ = LayoutGravity::TOP_LEFT;

    Rect applyGravity(const Rect& childBounds, const Rect& containerInner, LayoutGravity gravity) const;
};

}  // namespace phantom::gui
