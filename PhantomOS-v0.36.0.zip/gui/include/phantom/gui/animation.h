/*
 * Phantom OS - Animation System
 * Easing functions, ValueAnimator, PropertyAnimator, Transition, AnimationManager
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include <functional>
#include <memory>
#include <vector>
#include <cmath>

namespace phantom::gui {

// ============================================================
// Easing Functions
// ============================================================

enum class EasingType {
    LINEAR = 0,
    EASE_IN_QUAD = 1,
    EASE_OUT_QUAD = 2,
    EASE_IN_OUT_QUAD = 3,
    EASE_IN_CUBIC = 4,
    EASE_OUT_CUBIC = 5,
    EASE_IN_OUT_CUBIC = 6,
    EASE_IN_BOUNCE = 7,
    EASE_OUT_BOUNCE = 8,
    EASE_IN_BACK = 9,
    EASE_OUT_BACK = 10,
};

class Easing {
public:
    // Apply easing function to normalized time t (0.0 to 1.0)
    // Input is clamped to [0, 1]
    static float apply(EasingType type, float t);
};

// ============================================================
// Animation State
// ============================================================

enum class AnimationState {
    IDLE = 0,
    RUNNING = 1,
    PAUSED = 2,
    COMPLETED = 3,
    CANCELLED = 4,
};

// ============================================================
// Animation Base Class
// ============================================================

class Animation {
public:
    using CompleteCallback = std::function<void()>;

    virtual ~Animation() = default;

    virtual void start();
    virtual void pause();
    virtual void resume();
    virtual void cancel();
    virtual void reset();

    // Update with delta time in ms. Returns true if still active (running or paused).
    virtual bool update(int32_t deltaMs) = 0;

    AnimationState getState() const { return state_; }
    float getProgress() const { return progress_; }
    int32_t getDuration() const { return durationMs_; }
    int32_t getElapsed() const { return elapsedMs_; }

    void setCompleteCallback(const CompleteCallback& cb) { completeCb_ = cb; }
    bool isLooping() const { return loop_; }
    void setLoop(bool loop) { loop_ = loop; }

protected:
    Animation(int32_t durationMs, EasingType easing);

    int32_t durationMs_;
    EasingType easing_;
    AnimationState state_ = AnimationState::IDLE;
    int32_t elapsedMs_ = 0;
    float progress_ = 0.0f;
    bool loop_ = false;
    bool completionFired_ = false;
    CompleteCallback completeCb_;

    float computeEasedProgress() const;
    void checkCompletion();
};

// ============================================================
// ValueAnimator: animates a float from start to end
// ============================================================

class ValueAnimator : public Animation {
public:
    using UpdateCallback = std::function<void(float value)>;

    ValueAnimator(float start, float end, int32_t durationMs,
                  EasingType easing = EasingType::LINEAR);

    void setUpdateCallback(const UpdateCallback& cb) { updateCb_ = cb; }

    float getStartValue() const { return startValue_; }
    float getEndValue() const { return endValue_; }
    float getCurrentValue() const { return currentValue_; }

    void reset() override;
    void start() override;
    bool update(int32_t deltaMs) override;

    // Reverse direction (swap start/end)
    void setReverse(bool reverse) { reverse_ = reverse; }
    bool isReversed() const { return reverse_; }

private:
    float startValue_;
    float endValue_;
    float currentValue_;
    bool reverse_ = false;
    UpdateCallback updateCb_;

    void updateValue();
};

// ============================================================
// PropertyAnimator: animates a Widget property
// ============================================================

class PropertyAnimator : public Animation {
public:
    enum class Property {
        X = 0,
        Y = 1,
        WIDTH = 2,
        HEIGHT = 3,
        ALPHA = 4,
    };

    PropertyAnimator(Widget* widget, Property prop, float start, float end,
                     int32_t durationMs, EasingType easing = EasingType::LINEAR);

    void start() override;
    bool update(int32_t deltaMs) override;

    // Convenience factory methods
    static std::shared_ptr<PropertyAnimator> animatePosition(
        Widget* widget, int32_t fromX, int32_t fromY,
        int32_t toX, int32_t toY, int32_t durationMs,
        EasingType easing = EasingType::EASE_IN_OUT_QUAD);

    static std::shared_ptr<PropertyAnimator> animateSize(
        Widget* widget, int32_t fromW, int32_t fromH,
        int32_t toW, int32_t toH, int32_t durationMs,
        EasingType easing = EasingType::EASE_IN_OUT_QUAD);

    static std::shared_ptr<PropertyAnimator> animateFade(
        Widget* widget, float fromAlpha, float toAlpha,
        int32_t durationMs,
        EasingType easing = EasingType::LINEAR);

    Widget* getWidget() const { return widget_; }
    Property getProperty() const { return property_; }

private:
    Widget* widget_;
    Property property_;
    std::shared_ptr<ValueAnimator> animator_;

    void applyValue(float value);
};

// ============================================================
// Transition: enter/exit transitions for widgets
// ============================================================

enum class TransitionType {
    NONE = 0,
    FADE_IN = 1,
    FADE_OUT = 2,
    SLIDE_IN_LEFT = 3,
    SLIDE_IN_RIGHT = 4,
    SLIDE_IN_TOP = 5,
    SLIDE_IN_BOTTOM = 6,
    SLIDE_OUT_LEFT = 7,
    SLIDE_OUT_RIGHT = 8,
    SLIDE_OUT_TOP = 9,
    SLIDE_OUT_BOTTOM = 10,
    SCALE_IN = 11,
    SCALE_OUT = 12,
};

class Transition : public Animation {
public:
    Transition(TransitionType type, int32_t durationMs = 300);

    void setWidget(Widget* widget) { widget_ = widget; }

    void start() override;
    bool update(int32_t deltaMs) override;

    TransitionType getType() const { return type_; }
    Widget* getWidget() const { return widget_; }

    static int32_t getDefaultDuration(TransitionType type);

private:
    TransitionType type_;
    Widget* widget_ = nullptr;
    std::shared_ptr<ValueAnimator> animator_;

    // Original bounds captured at start()
    int32_t originalX_ = 0;
    int32_t originalY_ = 0;
    int32_t originalW_ = 0;
    int32_t originalH_ = 0;

    void setupAnimator();
};

// ============================================================
// AnimationManager: singleton managing all active animations
// ============================================================

class AnimationManager {
public:
    static AnimationManager& getInstance();

    // Add an animation to the manager
    void add(std::shared_ptr<Animation> anim);

    // Update all active animations by delta time
    void update(int32_t deltaMs);

    // Remove completed/cancelled animations
    void cleanup();

    // Cancel all animations for a specific widget
    void cancelForWidget(Widget* widget);

    // Remove all animations
    void clear();

    // Get count of active (running/paused) animations
    size_t getActiveCount() const;

    // Get total count (including completed but not yet cleaned)
    size_t getTotalCount() const;

private:
    AnimationManager() = default;
    std::vector<std::shared_ptr<Animation>> animations_;
};

}  // namespace phantom::gui
