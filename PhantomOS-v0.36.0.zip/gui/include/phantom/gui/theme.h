/*
 * Phantom OS - Theme System
 * Dark/Light mode support with structured color palette
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/color.h"
#include "phantom/gui/widget.h"
#include <functional>
#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>

namespace phantom::gui {

// ============================================================
// Theme Type
// ============================================================

enum class ThemeType {
    LIGHT = 0,
    DARK = 1,
    CUSTOM = 2,
};

// ============================================================
// Theme Colors — structured palette for UI elements
// ============================================================

struct ThemeColors {
    // Core surface colors
    Color background;        // Window/app background
    Color surface;           // Card/panel background
    Color surfaceAlt;        // Alternate surface (e.g. list item)

    // Primary/Secondary/Accent
    Color primary;           // Primary action color (buttons, highlights)
    Color primaryDark;       // Darker variant of primary
    Color secondary;         // Secondary action color
    Color accent;            // Accent color for switches/checkboxes

    // Text colors
    Color textPrimary;       // Main text color
    Color textSecondary;     // Subtitle/hint text color
    Color textOnPrimary;     // Text on primary-colored surfaces

    // Borders and dividers
    Color border;            // Widget borders
    Color divider;           // Dividers between items

    // Status colors
    Color error;             // Error state
    Color warning;           // Warning state
    Color success;           // Success state

    // Widget-specific
    Color buttonBg;          // Button background
    Color buttonText;        // Button text
    Color inputBg;           // TextField/Slider background
    Color inputBorder;       // TextField/Slider border
    Color listBg;            // ListView background
    Color listSelectedBg;    // ListView selected item background
    Color listText;          // ListView item text
    Color listSelectedText;  // ListView selected item text
    Color progressBarFill;   // ProgressBar fill
    Color progressBarBg;     // ProgressBar background
    Color sliderTrack;       // Slider track
    Color sliderThumb;       // Slider thumb
    Color sliderFill;        // Slider fill portion
    Color checkBoxBox;       // CheckBox box border
    Color checkBoxCheck;     // CheckBox checkmark
    Color radioCircle;       // RadioButton circle
    Color radioDot;          // RadioButton selected dot
};

// ============================================================
// Theme — a complete color scheme
// ============================================================

class Theme {
public:
    Theme() = default;
    Theme(ThemeType type, const std::string& name, const ThemeColors& colors);

    ThemeType getType() const { return type_; }
    const std::string& getName() const { return name_; }
    const ThemeColors& getColors() const { return colors_; }

    // Factory methods
    static Theme createLight();
    static Theme createDark();

    // Get a color by role name (for custom lookups)
    const Color& getColor(const std::string& role) const;

private:
    ThemeType type_ = ThemeType::DARK;
    std::string name_;
    ThemeColors colors_;

    static std::unordered_map<std::string, Color ThemeColors::*> createRoleMap();
};

// ============================================================
// ThemeManager — singleton managing the current theme
// ============================================================

class ThemeManager {
public:
    using ListenerCallback = std::function<void(const Theme& newTheme)>;
    using ListenerId = uint32_t;

    static ThemeManager& getInstance();

    // Get current theme
    const Theme& getCurrentTheme() const { return currentTheme_; }
    ThemeType getCurrentType() const { return currentTheme_.getType(); }

    // Set theme
    void setTheme(const Theme& theme);

    // Convenience: set by type (creates default theme)
    void setThemeType(ThemeType type);

    // Toggle between light and dark
    void toggleTheme();

    // Listener management
    ListenerId addListener(const ListenerCallback& cb);
    void removeListener(ListenerId id);
    void clearListeners();

    // Apply current theme to a widget tree
    void applyTheme(Widget& root) const;

    // Reset to default (for tests)
    void reset();

private:
    ThemeManager();

    Theme currentTheme_;
    std::vector<std::pair<ListenerId, ListenerCallback>> listeners_;
    ListenerId nextListenerId_ = 1;

    void notifyListeners();
};

}  // namespace phantom::gui
