/*
 * Phantom OS - GUI Framebuffer
 * CPU-backed pixel buffer with drawing operations
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/geometry.h"
#include "phantom/gui/color.h"
#include <cstdint>
#include <vector>
#include <memory>

namespace phantom::gui {

class Framebuffer {
public:
    Framebuffer() = default;
    Framebuffer(int32_t width, int32_t height);
    Framebuffer(const Size& size);

    int32_t getWidth() const { return width_; }
    int32_t getHeight() const { return height_; }
    Size getSize() const { return Size(width_, height_); }
    bool isValid() const { return width_ > 0 && height_ > 0 && !pixels_.empty(); }
    int32_t getPixelCount() const { return static_cast<int32_t>(pixels_.size()); }

    // Pixel access (bounds-checked)
    bool setPixel(int32_t x, int32_t y, const Color& color);
    Color getPixel(int32_t x, int32_t y) const;

    // Unsafe pixel access (no bounds check — caller must ensure validity)
    void setPixelUnsafe(int32_t x, int32_t y, const Color& color);
    Color getPixelUnsafe(int32_t x, int32_t y) const;

    // Fill entire buffer with a color
    void clear(const Color& color = Color::Black);

    // Fill a rectangular region
    void fillRect(const Rect& rect, const Color& color);

    // Blit (copy) a source framebuffer region into this buffer at dest position
    // Source pixels with alpha < threshold are skipped (simple alpha test)
    void blit(const Framebuffer& src, int32_t destX, int32_t destY, uint8_t alphaThreshold = 0);

    // Blit with alpha blending
    void blitBlended(const Framebuffer& src, int32_t destX, int32_t destY);

    // Get raw pixel data (for testing/debugging)
    const uint32_t* getPixels() const { return pixels_.data(); }
    uint32_t* getPixels() { return pixels_.data(); }

    // Get raw pixel at linear index (for testing)
    uint32_t getPixelRaw(int32_t index) const;
    void setPixelRaw(int32_t index, uint32_t rgba);

private:
    int32_t width_ = 0;
    int32_t height_ = 0;
    std::vector<uint32_t> pixels_;  // RGBA32 format

    int32_t indexOf(int32_t x, int32_t y) const { return y * width_ + x; }
};

}  // namespace phantom::gui
