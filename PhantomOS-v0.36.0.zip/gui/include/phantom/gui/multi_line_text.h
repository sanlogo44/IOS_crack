/*
 * Phantom OS - Multi-Line Text Rendering
 * Text wrapping and multi-line layout utilities
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/geometry.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/color.h"
#include <string>
#include <vector>

namespace phantom::gui {

// Text alignment options
enum class TextAlignment {
    LEFT = 0,
    CENTER = 1,
    RIGHT = 2,
};

// A single line of wrapped text with its pixel width
struct TextLine {
    std::string text;
    int32_t width = 0;
};

// Multi-line text renderer and wrapper
class MultiLineText {
public:
    MultiLineText() = default;

    // Wrap text to fit within a given pixel width
    // Returns vector of wrapped lines
    std::vector<TextLine> wrapText(const std::string& text, int32_t maxWidth,
                                    const BitmapFont& font) const;

    // Wrap text to fit within a given rect
    std::vector<TextLine> wrapText(const std::string& text, const Rect& bounds,
                                    const BitmapFont& font) const;

    // Measure the total height of wrapped text
    int32_t measureHeight(const std::vector<TextLine>& lines, int32_t lineHeight) const;

    // Draw multiple lines of text into a framebuffer
    void drawLines(Framebuffer& fb, const std::vector<TextLine>& lines,
                   const Rect& bounds, const BitmapFont& font,
                   const Color& color, TextAlignment align = TextAlignment::LEFT) const;

    // Draw wrapped text directly
    void drawWrapped(Framebuffer& fb, const std::string& text,
                     const Rect& bounds, const BitmapFont& font,
                     const Color& color, TextAlignment align = TextAlignment::LEFT) const;

    // Get the number of lines that would be needed
    int32_t getLineCount(const std::string& text, int32_t maxWidth,
                          const BitmapFont& font) const;

    // Check if a character is a word boundary
    static bool isWordBoundary(char c);

    // Split text by explicit newlines first, then wrap each segment
    std::vector<std::string> splitByNewlines(const std::string& text) const;
};

}  // namespace phantom::gui
