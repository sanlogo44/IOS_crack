/*
 * Phantom OS - GUI Widgets
 * Button, Label, TextField, ListView
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include <string>
#include <vector>
#include <functional>

namespace phantom::gui {

// Label: displays non-editable text
class Label : public Widget {
public:
    Label() = default;
    Label(WidgetId id, const std::string& text = "");

    const std::string& getText() const { return text_; }
    void setText(const std::string& text);

    Color getTextColor() const { return textColor_; }
    void setTextColor(const Color& c) { textColor_ = c; }

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    void applyTheme(const Theme& theme) override;

private:
    std::string text_;
    Color textColor_ = Color::White;
};

// Button: clickable widget with text
class Button : public Widget {
public:
    Button() = default;
    Button(WidgetId id, const std::string& text = "");

    const std::string& getText() const { return text_; }
    void setText(const std::string& text);

    Color getTextColor() const { return textColor_; }
    void setTextColor(const Color& c) { textColor_ = c; }
    Color getBackgroundColor() const { return bgColor_; }
    void setBackgroundColor(const Color& c) { bgColor_ = c; }

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    bool onTouchUp(int32_t x, int32_t y) override;
    void applyTheme(const Theme& theme) override;

private:
    std::string text_;
    Color textColor_ = Color::White;
    Color bgColor_ = Color::Blue;
    bool pressed_ = false;
};

// TextField: single-line editable text input
class TextField : public Widget {
public:
    TextField() = default;
    TextField(WidgetId id, const std::string& text = "");

    const std::string& getText() const { return text_; }
    void setText(const std::string& text);

    void insertChar(char c);
    void deleteChar();
    void clear();

    size_t getCursorPosition() const { return cursorPos_; }
    void setCursorPosition(size_t pos);

    bool isFocused() const { return focused_; }
    void setFocused(bool f) { focused_ = f; }

    Color getTextColor() const { return textColor_; }
    void setTextColor(const Color& c) { textColor_ = c; }
    Color getBackgroundColor() const { return bgColor_; }
    void setBackgroundColor(const Color& c) { bgColor_ = c; }

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    void applyTheme(const Theme& theme) override;

private:
    std::string text_;
    size_t cursorPos_ = 0;
    bool focused_ = false;
    Color textColor_ = Color::Black;
    Color bgColor_ = Color::White;
};

// ListView: scrollable list of items
class ListView : public Widget {
public:
    using ItemCallback = std::function<void(size_t index)>;
    using ItemTextCallback = std::function<std::string(size_t index)>;

    ListView() = default;
    ListView(WidgetId id, size_t itemCount = 0);

    void setItemCount(size_t count) { itemCount_ = count; }
    size_t getItemCount() const { return itemCount_; }

    void setItemTextCallback(const ItemTextCallback& cb) { itemTextCb_ = cb; }
    void setItemClickCallback(const ItemCallback& cb) { itemClickCb_ = cb; }

    void setSelectedIndex(int32_t index);
    int32_t getSelectedIndex() const { return selectedIndex_; }

    void setScrollOffset(int32_t offset) { scrollOffset_ = offset; }
    int32_t getScrollOffset() const { return scrollOffset_; }

    void setItemHeight(int32_t h) { itemHeight_ = h; }
    int32_t getItemHeight() const { return itemHeight_; }

    int32_t getVisibleItemCount() const;
    void scrollBy(int32_t delta);
    void scrollTo(int32_t index);

    Size onMeasure() const override;
    void onLayout() override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    void applyTheme(const Theme& theme) override;

    // Themeable colors
    Color getBgColor() const { return bgColor_; }
    void setBgColor(const Color& c) { bgColor_ = c; }
    Color getSelectedBgColor() const { return selectedBgColor_; }
    void setSelectedBgColor(const Color& c) { selectedBgColor_ = c; }
    Color getItemTextColor() const { return itemTextColor_; }
    void setItemTextColor(const Color& c) { itemTextColor_ = c; }
    Color getSelectedTextColor() const { return selectedTextColor_; }
    void setSelectedTextColor(const Color& c) { selectedTextColor_ = c; }

private:
    size_t itemCount_ = 0;
    int32_t selectedIndex_ = -1;
    int32_t scrollOffset_ = 0;
    int32_t itemHeight_ = 12;

    Color bgColor_ = Color::Black;
    Color selectedBgColor_ = Color::Blue;
    Color itemTextColor_ = Color::LightGray;
    Color selectedTextColor_ = Color::White;

    ItemTextCallback itemTextCb_;
    ItemCallback itemClickCb_;
};

}  // namespace phantom::gui
