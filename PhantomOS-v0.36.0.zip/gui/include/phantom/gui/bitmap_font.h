/*
 * Phantom OS - GUI Bitmap Font
 * Fixed-width 5x7 bitmap font for basic text rendering
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/geometry.h"
#include "phantom/gui/color.h"
#include "phantom/gui/framebuffer.h"
#include <string>
#include <cstdint>

namespace phantom::gui {

// 5x7 bitmap font — each character is 5 columns x 7 rows
// Each column is a uint8_t where bits 0-6 represent rows 0-6
struct Glyph {
    uint8_t cols[5];  // 5 columns, each 7 bits (rows 0-6)
    int8_t advance;   // advance width (default 5 + 1 spacing = 6)
};

class BitmapFont {
public:
    static const int32_t GLYPH_WIDTH = 5;
    static const int32_t GLYPH_HEIGHT = 7;
    static const int32_t CHAR_SPACING = 1;
    static const int32_t LINE_SPACING = 1;
    static const int32_t MONO_ADVANCE = 6;  // 5 + 1 spacing

    BitmapFont();

    // Get glyph for a character (returns space for unknown)
    const Glyph& getGlyph(char c) const;

    // Check if a character has a glyph
    bool hasGlyph(char c) const;

    // Measure text dimensions
    int32_t measureTextWidth(const std::string& text) const;
    int32_t measureTextHeight() const { return GLYPH_HEIGHT; }

    // Get line height (glyph height + line spacing)
    int32_t getLineHeight() const { return GLYPH_HEIGHT + LINE_SPACING; }

    // Draw a single character into a framebuffer at position
    void drawChar(Framebuffer& fb, int32_t x, int32_t y, char c, const Color& color) const;

    // Draw a string into a framebuffer at position
    void drawText(Framebuffer& fb, int32_t x, int32_t y, const std::string& text, const Color& color) const;

    // Draw text within a clipping rect
    void drawTextClipped(Framebuffer& fb, const Rect& clip, int32_t x, int32_t y,
                         const std::string& text, const Color& color) const;

private:
    void initGlyphs();

    // ASCII range 32-126
    static const int FIRST_CHAR = 32;
    static const int LAST_CHAR = 126;
    static const int NUM_GLYPHS = LAST_CHAR - FIRST_CHAR + 1;

    Glyph glyphs_[NUM_GLYPHS];
    Glyph spaceGlyph_;
};

}  // namespace phantom::gui
