/*
 * Phantom OS - GUI Geometry
 * 2D geometry primitives: Point, Size, Rect
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>

namespace phantom::gui {

struct Point {
    int32_t x = 0;
    int32_t y = 0;

    Point() = default;
    Point(int32_t x, int32_t y) : x(x), y(y) {}

    bool operator==(const Point& other) const { return x == other.x && y == other.y; }
    bool operator!=(const Point& other) const { return !(*this == other); }
};

struct Size {
    int32_t width = 0;
    int32_t height = 0;

    Size() = default;
    Size(int32_t w, int32_t h) : width(w), height(h) {}

    bool isEmpty() const { return width <= 0 || height <= 0; }
    int32_t area() const { return width * height; }

    bool operator==(const Size& other) const { return width == other.width && height == other.height; }
    bool operator!=(const Size& other) const { return !(*this == other); }
};

struct Rect {
    int32_t x = 0;
    int32_t y = 0;
    int32_t width = 0;
    int32_t height = 0;

    Rect() = default;
    Rect(int32_t x, int32_t y, int32_t w, int32_t h) : x(x), y(y), width(w), height(h) {}

    int32_t left() const { return x; }
    int32_t top() const { return y; }
    int32_t right() const { return x + width; }
    int32_t bottom() const { return y + height; }

    Point origin() const { return Point(x, y); }
    Size size() const { return Size(width, height); }

    bool isEmpty() const { return width <= 0 || height <= 0; }
    bool isValid() const { return width > 0 && height > 0; }
    int32_t area() const { return width * height; }

    bool contains(const Point& p) const {
        return p.x >= x && p.x < right() && p.y >= y && p.y < bottom();
    }

    bool contains(int32_t px, int32_t py) const {
        return px >= x && px < right() && py >= y && py < bottom();
    }

    bool intersects(const Rect& other) const {
        return !(right() <= other.x || other.right() <= x ||
                 bottom() <= other.y || other.bottom() <= y);
    }

    Rect intersection(const Rect& other) const {
        int32_t ix = (x > other.x) ? x : other.x;
        int32_t iy = (y > other.y) ? y : other.y;
        int32_t ir = (right() < other.right()) ? right() : other.right();
        int32_t ib = (bottom() < other.bottom()) ? bottom() : other.bottom();
        if (ir <= ix || ib <= iy) return Rect(0, 0, 0, 0);
        return Rect(ix, iy, ir - ix, ib - iy);
    }

    Rect clampTo(const Rect& bounds) const {
        int32_t nx = (x < bounds.x) ? bounds.x : x;
        int32_t ny = (y < bounds.y) ? bounds.y : y;
        int32_t nr = (right() > bounds.right()) ? bounds.right() : right();
        int32_t nb = (bottom() > bounds.bottom()) ? bounds.bottom() : bottom();
        if (nr <= nx || nb <= ny) return Rect(0, 0, 0, 0);
        return Rect(nx, ny, nr - nx, nb - ny);
    }

    bool operator==(const Rect& other) const {
        return x == other.x && y == other.y && width == other.width && height == other.height;
    }
    bool operator!=(const Rect& other) const { return !(*this == other); }
};

}  // namespace phantom::gui
