/*
 * Phantom OS - GUI Input Dispatcher
 * Routes touch/input events to the appropriate window via hit-testing
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/window_manager.h"
#include "phantom/gui/geometry.h"
#include <functional>
#include <queue>
#include <string>

namespace phantom::gui {

enum class InputEventType {
    TOUCH_DOWN = 0,
    TOUCH_MOVE = 1,
    TOUCH_UP = 2,
    KEY_DOWN = 3,
    KEY_UP = 4,
};

struct InputEvent {
    InputEventType type;
    int32_t x = 0;
    int32_t y = 0;
    int32_t pointerId = 0;
    int32_t keyCode = 0;
    uint64_t timestamp = 0;
};

struct GuiEvent {
    InputEventType type;
    Window::WindowId targetWindowId = 0;
    int32_t x = 0;  // Window-local coordinates
    int32_t y = 0;
    int32_t screenX = 0;
    int32_t screenY = 0;
    uint64_t timestamp = 0;
};

using GuiEventCallback = std::function<void(const GuiEvent&)>;

class InputDispatcher {
public:
    static InputDispatcher& getInstance();

    // Dispatch a raw input event — routes to the appropriate window
    // Returns the window ID that received the event (0 if none)
    Window::WindowId dispatch(const InputEvent& event);

    // Dispatch with a callback for the resulting GUI event
    Window::WindowId dispatch(const InputEvent& event, const GuiEventCallback& callback);

    // Queue an event for later processing
    void queueEvent(const InputEvent& event);
    void queueEvent(InputEvent&& event);

    // Process all queued events
    void processQueue();
    void processQueue(const GuiEventCallback& callback);

    // Check if there are pending events
    size_t getPendingEventCount() const { return eventQueue_.size(); }
    bool hasPendingEvents() const { return !eventQueue_.empty(); }

    // Clear the event queue
    void clearQueue();

    // Set a default callback for all dispatched events
    void setDefaultCallback(const GuiEventCallback& callback) { defaultCallback_ = callback; }

    // Get the last window that received a touch-down (for tracking gesture state)
    Window::WindowId getActiveTouchWindow() const { return activeTouchWindow_; }
    void clearActiveTouch() { activeTouchWindow_ = 0; }

    // Stats
    int32_t getTotalEventsDispatched() const { return totalDispatched_; }
    int32_t getEventsDropped() const { return totalDropped_; }

private:
    InputDispatcher() = default;
    InputDispatcher(const InputDispatcher&) = delete;
    InputDispatcher& operator=(const InputDispatcher&) = delete;

    std::queue<InputEvent> eventQueue_;
    GuiEventCallback defaultCallback_;
    Window::WindowId activeTouchWindow_ = 0;
    int32_t totalDispatched_ = 0;
    int32_t totalDropped_ = 0;
};

}  // namespace phantom::gui
