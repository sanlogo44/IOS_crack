/*
 * Phantom OS - GUI Surface
 * Offscreen drawable surface with z-order and visibility
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/geometry.h"
#include "phantom/gui/framebuffer.h"
#include <cstdint>
#include <memory>
#include <string>

namespace phantom::gui {

enum class SurfaceVisibility {
    HIDDEN = 0,
    VISIBLE = 1,
};

class Surface {
public:
    using SurfaceId = uint32_t;

    Surface() = default;
    Surface(SurfaceId id, const Size& size);
    Surface(SurfaceId id, int32_t width, int32_t height);

    SurfaceId getId() const { return id_; }
    int32_t getWidth() const { return framebuffer_.getWidth(); }
    int32_t getHeight() const { return framebuffer_.getHeight(); }
    Size getSize() const { return framebuffer_.getSize(); }
    bool isValid() const { return framebuffer_.isValid(); }

    SurfaceVisibility getVisibility() const { return visibility_; }
    void setVisibility(SurfaceVisibility v) { visibility_ = v; }
    bool isVisible() const { return visibility_ == SurfaceVisibility::VISIBLE; }

    int32_t getZOrder() const { return zOrder_; }
    void setZOrder(int32_t z) { zOrder_ = z; }

    float getOpacity() const { return opacity_; }
    void setOpacity(float op) { opacity_ = (op < 0.0f) ? 0.0f : (op > 1.0f) ? 1.0f : op; }

    // Get the backing framebuffer for drawing
    Framebuffer& getFramebuffer() { return framebuffer_; }
    const Framebuffer& getFramebuffer() const { return framebuffer_; }

    // Convenience: fill entire surface with a color
    void fill(const Color& color) { framebuffer_.clear(color); }

    // Get the dirty rect (region that needs recomposition)
    Rect getDirtyRect() const { return dirtyRect_; }
    void markDirty(const Rect& rect) { dirtyRect_ = rect; }
    void clearDirty() { dirtyRect_ = Rect(0, 0, 0, 0); }

private:
    SurfaceId id_ = 0;
    Framebuffer framebuffer_;
    SurfaceVisibility visibility_ = SurfaceVisibility::VISIBLE;
    int32_t zOrder_ = 0;
    float opacity_ = 1.0f;
    Rect dirtyRect_;
};

}  // namespace phantom::gui
