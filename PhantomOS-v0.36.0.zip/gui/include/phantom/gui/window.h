/*
 * Phantom OS - GUI Window
 * Window metadata and state management
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/geometry.h"
#include "phantom/gui/surface.h"
#include <cstdint>
#include <memory>
#include <string>

namespace phantom::gui {

enum class WindowState {
    CREATED = 0,
    VISIBLE = 1,
    HIDDEN = 2,
    DESTROYED = 3,
};

enum class WindowFlags : uint32_t {
    NONE = 0,
    FOCUSABLE = 1 << 0,
    TOUCHABLE = 1 << 1,
    FULLSCREEN = 1 << 2,
    TRANSPARENT = 1 << 3,
    OPAQUE = 1 << 4,
};

inline WindowFlags operator|(WindowFlags a, WindowFlags b) {
    return static_cast<WindowFlags>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}

inline WindowFlags operator&(WindowFlags a, WindowFlags b) {
    return static_cast<WindowFlags>(static_cast<uint32_t>(a) & static_cast<uint32_t>(b));
}

inline bool hasFlag(WindowFlags flags, WindowFlags test) {
    return (static_cast<uint32_t>(flags) & static_cast<uint32_t>(test)) != 0;
}

class Window {
public:
    using WindowId = uint32_t;

    Window() = default;
    Window(WindowId id, const std::string& title, const std::string& appId,
           const Rect& bounds, WindowFlags flags = WindowFlags::FOCUSABLE | WindowFlags::TOUCHABLE);

    WindowId getId() const { return id_; }
    const std::string& getTitle() const { return title_; }
    const std::string& getAppId() const { return appId_; }

    Rect getBounds() const { return bounds_; }
    void setBounds(const Rect& bounds) { bounds_ = bounds; }

    Point getPosition() const { return Point(bounds_.x, bounds_.y); }
    void setPosition(int32_t x, int32_t y) { bounds_.x = x; bounds_.y = y; }

    Size getSize() const { return bounds_.size(); }
    void setSize(int32_t w, int32_t h) { bounds_.width = w; bounds_.height = h; }

    WindowState getState() const { return state_; }
    void setState(WindowState s) { state_ = s; }

    WindowFlags getFlags() const { return flags_; }
    void setFlags(WindowFlags f) { flags_ = f; }
    bool isFocusable() const { return hasFlag(flags_, WindowFlags::FOCUSABLE); }
    bool isTouchable() const { return hasFlag(flags_, WindowFlags::TOUCHABLE); }
    bool isFullscreen() const { return hasFlag(flags_, WindowFlags::FULLSCREEN); }
    bool isTransparent() const { return hasFlag(flags_, WindowFlags::TRANSPARENT); }

    Surface* getSurface() { return surface_.get(); }
    const Surface* getSurface() const { return surface_.get(); }
    void setSurface(std::unique_ptr<Surface> surface) { surface_ = std::move(surface); }

    bool hasSurface() const { return surface_ != nullptr; }

    // Create a backing surface for this window
    void createSurface();

    // Check if a point is within this window's bounds
    bool containsPoint(int32_t x, int32_t y) const { return bounds_.contains(x, y); }

    // Visibility helpers
    bool isVisible() const { return state_ == WindowState::VISIBLE; }
    void show() { state_ = WindowState::VISIBLE; }
    void hide() { state_ = WindowState::HIDDEN; }

    // Z-order
    int32_t getZOrder() const { return zOrder_; }
    void setZOrder(int32_t z) { zOrder_ = z; }

private:
    WindowId id_ = 0;
    std::string title_;
    std::string appId_;
    Rect bounds_;
    WindowState state_ = WindowState::CREATED;
    WindowFlags flags_ = WindowFlags::FOCUSABLE | WindowFlags::TOUCHABLE;
    std::unique_ptr<Surface> surface_;
    int32_t zOrder_ = 0;
};

}  // namespace phantom::gui
