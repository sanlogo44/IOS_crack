/*
 * Phantom OS - Extended Layout System
 * RelativeLayout and GridLayout for advanced widget arrangement
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/layout.h"
#include "phantom/gui/widget.h"
#include <unordered_map>
#include <string>

namespace phantom::gui {

// ============================================================
// RelativeLayout: positions children relative to parent edges
// or other children
// ============================================================
class RelativeLayout : public Layout {
public:
    // Rules for positioning a child
    struct LayoutParams {
        // Position relative to parent (use -1 for "not set")
        int32_t alignParentTop = -1;
        int32_t alignParentBottom = -1;
        int32_t alignParentLeft = -1;
        int32_t alignParentRight = -1;
        int32_t centerInParent = -1;
        int32_t centerHorizontal = -1;
        int32_t centerVertical = -1;

        // Position relative to other children (by tag)
        std::string above;      // Place bottom edge above this child
        std::string below;      // Place top edge below this child
        std::string toLeftOf;   // Place right edge to left of this child
        std::string toRightOf;  // Place left edge to right of this child

        // Margins
        int32_t marginTop = 0;
        int32_t marginBottom = 0;
        int32_t marginLeft = 0;
        int32_t marginRight = 0;
    };

    RelativeLayout() = default;

    // Set layout params for a specific child (by tag)
    void setLayoutParams(const std::string& tag, const LayoutParams& params);

    // Get layout params for a child
    const LayoutParams* getLayoutParams(const std::string& tag) const;

    Size measure(const Widget& container) const override;
    void layout(Widget& container) override;

private:
    std::unordered_map<std::string, LayoutParams> params_;

    // Find a child by tag
    Widget* findChildByTag(Widget& container, const std::string& tag) const;

    // Resolve a child's position based on rules
    Rect resolveChildBounds(Widget& container, Widget& child,
                            const LayoutParams& params,
                            const std::unordered_map<std::string, Rect>& resolved);
};

// ============================================================
// GridLayout: arranges children in a grid of rows and columns
// ============================================================
class GridLayout : public Layout {
public:
    GridLayout(int32_t rows = 0, int32_t columns = 0);

    void setRows(int32_t r) { rows_ = r; }
    int32_t getRows() const { return rows_; }

    void setColumns(int32_t c) { columns_ = c; }
    int32_t getColumns() const { return columns_; }

    void setSpacing(int32_t spacing) { spacing_ = spacing; }
    int32_t getSpacing() const { return spacing_; }

    // Set how children fill their cells
    enum class CellAlignment {
        TOP_LEFT = 0,
        CENTER = 1,
        FILL = 2,
    };

    void setCellAlignment(CellAlignment a) { alignment_ = a; }
    CellAlignment getCellAlignment() const { return alignment_; }

    // Set a child to span multiple cells
    void setSpan(const std::string& tag, int32_t rowSpan, int32_t colSpan);

    Size measure(const Widget& container) const override;
    void layout(Widget& container) override;

private:
    int32_t rows_ = 0;
    int32_t columns_ = 0;
    int32_t spacing_ = 0;
    CellAlignment alignment_ = CellAlignment::TOP_LEFT;

    struct Span {
        int32_t rowSpan = 1;
        int32_t colSpan = 1;
    };
    std::unordered_map<std::string, Span> spans_;

    // Auto-detect rows/columns if not set
    void autoDetect(Widget& container, int32_t& rows, int32_t& cols) const;
};

}  // namespace phantom::gui
