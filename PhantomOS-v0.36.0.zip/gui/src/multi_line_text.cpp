/*
 * Phantom OS - Multi-Line Text Rendering Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/multi_line_text.h"
#include <cctype>

namespace phantom::gui {

std::vector<std::string> MultiLineText::splitByNewlines(const std::string& text) const {
    std::vector<std::string> lines;
    std::string current;
    for (char c : text) {
        if (c == '\n') {
            lines.push_back(current);
            current.clear();
        } else {
            current += c;
        }
    }
    lines.push_back(current);
    return lines;
}

bool MultiLineText::isWordBoundary(char c) {
    return std::isspace(static_cast<unsigned char>(c)) || c == '-' || c == '/';
}

std::vector<TextLine> MultiLineText::wrapText(const std::string& text, int32_t maxWidth,
                                               const BitmapFont& font) const {
    std::vector<TextLine> lines;

    // First split by explicit newlines
    auto segments = splitByNewlines(text);

    for (const auto& segment : segments) {
        if (segment.empty()) {
            lines.push_back({"", 0});
            continue;
        }

        // Word-wrap the segment
        std::string currentLine;
        std::string currentWord;
        int32_t lineWidth = 0;

        for (size_t i = 0; i <= segment.length(); ++i) {
            char c = (i < segment.length()) ? segment[i] : ' ';
            bool isBoundary = (i >= segment.length()) || isWordBoundary(c);

            if (!isBoundary) {
                currentWord += c;
            } else {
                // We have a word (or space)
                if (!currentWord.empty()) {
                    int32_t wordWidth = font.measureTextWidth(currentWord);

                    if (lineWidth > 0 && lineWidth + font.MONO_ADVANCE + wordWidth > maxWidth) {
                        // Line is full, start a new line
                        lines.push_back({currentLine, lineWidth});
                        currentLine = currentWord;
                        lineWidth = wordWidth;
                    } else {
                        if (!currentLine.empty()) {
                            currentLine += ' ';
                            lineWidth += font.MONO_ADVANCE;
                        }
                        currentLine += currentWord;
                        lineWidth += wordWidth;
                    }
                    currentWord.clear();
                }

                // Handle spaces
                if (i < segment.length() && std::isspace(static_cast<unsigned char>(c))) {
                    if (lineWidth > 0 && lineWidth + font.MONO_ADVANCE <= maxWidth) {
                        currentLine += ' ';
                        lineWidth += font.MONO_ADVANCE;
                    }
                } else if (i < segment.length()) {
                    // Non-space boundary char (like '-' or '/')
                    currentWord += c;
                }
            }
        }

        // Add remaining line
        if (!currentLine.empty() || !currentWord.empty()) {
            if (!currentWord.empty() && !currentLine.empty()) {
                currentLine += ' ';
                lineWidth += font.MONO_ADVANCE;
            }
            currentLine += currentWord;
            lineWidth = font.measureTextWidth(currentLine);
            lines.push_back({currentLine, lineWidth});
        }
    }

    return lines;
}

std::vector<TextLine> MultiLineText::wrapText(const std::string& text, const Rect& bounds,
                                               const BitmapFont& font) const {
    return wrapText(text, bounds.width, font);
}

int32_t MultiLineText::measureHeight(const std::vector<TextLine>& lines, int32_t lineHeight) const {
    if (lines.empty()) return 0;
    return static_cast<int32_t>(lines.size()) * lineHeight;
}

void MultiLineText::drawLines(Framebuffer& fb, const std::vector<TextLine>& lines,
                               const Rect& bounds, const BitmapFont& font,
                               const Color& color, TextAlignment align) const {
    int32_t lineHeight = font.getLineHeight();
    int32_t y = bounds.y;

    for (const auto& line : lines) {
        int32_t x = bounds.x;
        if (align == TextAlignment::CENTER) {
            x = bounds.x + (bounds.width - line.width) / 2;
        } else if (align == TextAlignment::RIGHT) {
            x = bounds.x + bounds.width - line.width;
        }

        font.drawTextClipped(fb, bounds, x, y, line.text, color);
        y += lineHeight;
        if (y >= bounds.bottom()) break;
    }
}

void MultiLineText::drawWrapped(Framebuffer& fb, const std::string& text,
                                 const Rect& bounds, const BitmapFont& font,
                                 const Color& color, TextAlignment align) const {
    auto lines = wrapText(text, bounds, font);
    drawLines(fb, lines, bounds, font, color, align);
}

int32_t MultiLineText::getLineCount(const std::string& text, int32_t maxWidth,
                                     const BitmapFont& font) const {
    auto lines = wrapText(text, maxWidth, font);
    return static_cast<int32_t>(lines.size());
}

}  // namespace phantom::gui
