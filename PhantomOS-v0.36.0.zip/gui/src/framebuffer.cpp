/*
 * Phantom OS - GUI Framebuffer Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/framebuffer.h"
#include <cstring>

namespace phantom::gui {

// Color constants
const Color Color::Black(0, 0, 0, 255);
const Color Color::White(255, 255, 255, 255);
const Color Color::Red(255, 0, 0, 255);
const Color Color::Green(0, 255, 0, 255);
const Color Color::Blue(0, 0, 255, 255);
const Color Color::Transparent(0, 0, 0, 0);
const Color Color::DarkGray(64, 64, 64, 255);
const Color Color::LightGray(192, 192, 192, 255);

Framebuffer::Framebuffer(int32_t width, int32_t height)
    : width_(width), height_(height) {
    if (width > 0 && height > 0) {
        pixels_.resize(static_cast<size_t>(width) * height, 0);
    }
}

Framebuffer::Framebuffer(const Size& size)
    : Framebuffer(size.width, size.height) {}

bool Framebuffer::setPixel(int32_t x, int32_t y, const Color& color) {
    if (x < 0 || x >= width_ || y < 0 || y >= height_) return false;
    pixels_[indexOf(x, y)] = color.toRGBA32();
    return true;
}

Color Framebuffer::getPixel(int32_t x, int32_t y) const {
    if (x < 0 || x >= width_ || y < 0 || y >= height_) return Color::Transparent;
    return Color::fromRGBA32(pixels_[indexOf(x, y)]);
}

void Framebuffer::setPixelUnsafe(int32_t x, int32_t y, const Color& color) {
    pixels_[indexOf(x, y)] = color.toRGBA32();
}

Color Framebuffer::getPixelUnsafe(int32_t x, int32_t y) const {
    return Color::fromRGBA32(pixels_[indexOf(x, y)]);
}

void Framebuffer::clear(const Color& color) {
    uint32_t rgba = color.toRGBA32();
    for (auto& px : pixels_) {
        px = rgba;
    }
}

void Framebuffer::fillRect(const Rect& rect, const Color& color) {
    Rect clipped = rect.clampTo(Rect(0, 0, width_, height_));
    if (!clipped.isValid()) return;
    uint32_t rgba = color.toRGBA32();
    for (int32_t y = clipped.y; y < clipped.bottom(); ++y) {
        for (int32_t x = clipped.x; x < clipped.right(); ++x) {
            pixels_[indexOf(x, y)] = rgba;
        }
    }
}

void Framebuffer::blit(const Framebuffer& src, int32_t destX, int32_t destY, uint8_t alphaThreshold) {
    if (!src.isValid() || !isValid()) return;
    for (int32_t sy = 0; sy < src.height_; ++sy) {
        int32_t dy = destY + sy;
        if (dy < 0 || dy >= height_) continue;
        for (int32_t sx = 0; sx < src.width_; ++sx) {
            int32_t dx = destX + sx;
            if (dx < 0 || dx >= width_) continue;
            Color srcColor = src.getPixelUnsafe(sx, sy);
            if (srcColor.a <= alphaThreshold) continue;
            pixels_[indexOf(dx, dy)] = srcColor.toRGBA32();
        }
    }
}

void Framebuffer::blitBlended(const Framebuffer& src, int32_t destX, int32_t destY) {
    if (!src.isValid() || !isValid()) return;
    for (int32_t sy = 0; sy < src.height_; ++sy) {
        int32_t dy = destY + sy;
        if (dy < 0 || dy >= height_) continue;
        for (int32_t sx = 0; sx < src.width_; ++sx) {
            int32_t dx = destX + sx;
            if (dx < 0 || dx >= width_) continue;
            Color srcColor = src.getPixelUnsafe(sx, sy);
            if (srcColor.a == 0) continue;
            Color dstColor = getPixelUnsafe(dx, dy);
            Color blended = blend(srcColor, dstColor);
            pixels_[indexOf(dx, dy)] = blended.toRGBA32();
        }
    }
}

uint32_t Framebuffer::getPixelRaw(int32_t index) const {
    if (index < 0 || index >= static_cast<int32_t>(pixels_.size())) return 0;
    return pixels_[index];
}

void Framebuffer::setPixelRaw(int32_t index, uint32_t rgba) {
    if (index < 0 || index >= static_cast<int32_t>(pixels_.size())) return;
    pixels_[index] = rgba;
}

}  // namespace phantom::gui
