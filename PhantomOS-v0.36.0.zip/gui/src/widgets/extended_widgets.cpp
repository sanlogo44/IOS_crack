/*
 * Phantom OS - Extended Widgets Implementation
 * CheckBox, RadioButton, ProgressBar, Slider
 *
 * License: GPL-3.0
 */

#include "phantom/gui/widgets/extended_widgets.h"
#include <cmath>

namespace phantom::gui {

// ============================================================
// CheckBox
// ============================================================

std::vector<RadioButton*> RadioButton::registeredButtons_;

CheckBox::CheckBox(WidgetId id, const std::string& label)
    : Widget(id, "CheckBox"), label_(label) {
    flags_ = flags_ | WidgetFlags::CLICKABLE | WidgetFlags::FOCUSABLE;
}

void CheckBox::setChecked(bool checked) {
    if (checked_ != checked) {
        checked_ = checked;
        if (onChange_) onChange_(checked_);
    }
}

void CheckBox::toggle() {
    setChecked(!checked_);
}

Size CheckBox::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    int32_t textW = static_cast<int32_t>(label_.length()) * 6;
    int32_t w = BOX_SIZE + 2 * BOX_PADDING + textW + padding_.left + padding_.right;
    int32_t h = 7 + padding_.top + padding_.bottom + 4;
    if (h < BOX_SIZE + 2 * BOX_PADDING) h = BOX_SIZE + 2 * BOX_PADDING;
    return Size(w, h);
}

void CheckBox::onRender(Framebuffer& fb, const BitmapFont& font) const {
    int32_t boxX = bounds_.x + padding_.left + BOX_PADDING;
    int32_t boxY = bounds_.y + padding_.top + BOX_PADDING;
    int32_t boxSize = BOX_SIZE;

    // Draw box background
    fb.fillRect(Rect(boxX, boxY, boxSize, boxSize), boxColor_);

    // Draw border
    Color borderCol = pressed_ ? Color::White : Color::DarkGray;
    for (int32_t x = boxX; x < boxX + boxSize; ++x) {
        fb.setPixel(x, boxY, borderCol);
        fb.setPixel(x, boxY + boxSize - 1, borderCol);
    }
    for (int32_t y = boxY; y < boxY + boxSize; ++y) {
        fb.setPixel(boxX, y, borderCol);
        fb.setPixel(boxX + boxSize - 1, y, borderCol);
    }

    // Draw checkmark if checked
    if (checked_) {
        // Simple checkmark: diagonal line from bottom-left to center, then to top-right
        // Using pixel drawing within the box (minus 1px padding)
        for (int32_t i = 1; i <= 3; ++i) {
            int32_t px = boxX + i;
            int32_t py = boxY + boxSize - 1 - i;
            if (px >= boxX && px < boxX + boxSize && py >= boxY && py < boxY + boxSize) {
                fb.setPixel(px, py, checkColor_);
            }
        }
        for (int32_t i = 0; i < 5; ++i) {
            int32_t px = boxX + 3 + i;
            int32_t py = boxY + boxSize - 1 - 3 - i;
            if (px >= boxX && px < boxX + boxSize && py >= boxY && py < boxY + boxSize) {
                fb.setPixel(px, py, checkColor_);
            }
        }
    }

    // Draw label text
    int32_t textX = boxX + boxSize + BOX_PADDING + 2;
    int32_t textY = boxY + (boxSize - 7) / 2;
    font.drawTextClipped(fb, bounds_, textX, textY, label_, textColor_);
}

bool CheckBox::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    pressed_ = true;
    state_ = WidgetState::PRESSED;
    return true;
}

bool CheckBox::onTouchUp(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    bool wasPressed = pressed_;
    pressed_ = false;
    state_ = WidgetState::NORMAL;
    if (wasPressed) {
        toggle();
    }
    return true;
}

// ============================================================
// RadioButton
// ============================================================

RadioButton::RadioButton(WidgetId id, const std::string& label, int32_t groupId)
    : Widget(id, "RadioButton"), label_(label), groupId_(groupId) {
    flags_ = flags_ | WidgetFlags::CLICKABLE | WidgetFlags::FOCUSABLE;
    registerRadioButton(this);
}

void RadioButton::setSelected(bool selected) {
    if (selected_ != selected) {
        selected_ = selected;
        if (onChange_) onChange_(static_cast<int32_t>(id_), selected_);
    }
}

Size RadioButton::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    int32_t textW = static_cast<int32_t>(label_.length()) * 6;
    int32_t w = (CIRCLE_RADIUS * 2 + 2) + 4 + textW + padding_.left + padding_.right;
    int32_t h = 7 + padding_.top + padding_.bottom + 4;
    if (h < CIRCLE_RADIUS * 2 + 4) h = CIRCLE_RADIUS * 2 + 4;
    return Size(w, h);
}

void RadioButton::onRender(Framebuffer& fb, const BitmapFont& font) const {
    int32_t circleX = bounds_.x + padding_.left + CIRCLE_RADIUS + 1;
    int32_t circleY = bounds_.y + padding_.top + CIRCLE_RADIUS + 1;

    // Draw circle outline (simple Bresenham-like)
    int32_t r = CIRCLE_RADIUS;
    for (int32_t angle = 0; angle < 360; angle += 15) {
        float rad = angle * 3.14159265f / 180.0f;
        int32_t px = circleX + static_cast<int32_t>(r * cos(rad));
        int32_t py = circleY + static_cast<int32_t>(r * sin(rad));
        if (bounds_.contains(px, py)) {
            fb.setPixel(px, py, circleColor_);
        }
    }
    // Fill the circle with background
    for (int32_t dy = -r; dy <= r; ++dy) {
        for (int32_t dx = -r; dx <= r; ++dx) {
            if (dx * dx + dy * dy <= r * r - 1) {
                int32_t px = circleX + dx;
                int32_t py = circleY + dy;
                if (bounds_.contains(px, py)) {
                    fb.setPixel(px, py, Color::Black);
                }
            }
        }
    }
    // Redraw outline on top
    for (int32_t angle = 0; angle < 360; angle += 15) {
        float rad = angle * 3.14159265f / 180.0f;
        int32_t px = circleX + static_cast<int32_t>(r * cos(rad));
        int32_t py = circleY + static_cast<int32_t>(r * sin(rad));
        if (bounds_.contains(px, py)) {
            fb.setPixel(px, py, circleColor_);
        }
    }

    // Draw filled dot if selected
    if (selected_) {
        int32_t dotR = DOT_RADIUS;
        for (int32_t dy = -dotR; dy <= dotR; ++dy) {
            for (int32_t dx = -dotR; dx <= dotR; ++dx) {
                if (dx * dx + dy * dy <= dotR * dotR) {
                    int32_t px = circleX + dx;
                    int32_t py = circleY + dy;
                    if (bounds_.contains(px, py)) {
                        fb.setPixel(px, py, dotColor_);
                    }
                }
            }
        }
    }

    // Draw label
    int32_t textX = circleX + CIRCLE_RADIUS + 4;
    int32_t textY = circleY - 3;
    font.drawTextClipped(fb, bounds_, textX, textY, label_, textColor_);
}

bool RadioButton::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    pressed_ = true;
    state_ = WidgetState::PRESSED;
    return true;
}

bool RadioButton::onTouchUp(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    bool wasPressed = pressed_;
    pressed_ = false;
    state_ = WidgetState::NORMAL;
    if (wasPressed) {
        selectInGroup(groupId_, static_cast<int32_t>(id_));
    }
    return true;
}

void RadioButton::registerRadioButton(RadioButton* rb) {
    // Skip duplicates to avoid stale entries
    for (auto* existing : registeredButtons_) {
        if (existing == rb) return;
    }
    registeredButtons_.push_back(rb);
}

void RadioButton::unregisterRadioButton(RadioButton* rb) {
    for (auto it = registeredButtons_.begin(); it != registeredButtons_.end(); ++it) {
        if (*it == rb) {
            registeredButtons_.erase(it);
            return;
        }
    }
}

void RadioButton::selectInGroup(int32_t groupId, int32_t radioButtonId) {
    for (auto* rb : registeredButtons_) {
        if (rb->groupId_ == groupId) {
            if (static_cast<int32_t>(rb->id_) == radioButtonId) {
                rb->setSelected(true);
            } else {
                rb->setSelected(false);
            }
        }
    }
}

// ============================================================
// ProgressBar
// ============================================================

ProgressBar::ProgressBar(WidgetId id, int32_t min, int32_t max, int32_t value)
    : Widget(id, "ProgressBar"), min_(min), max_(max), value_(value) {
    clampValue();
}

void ProgressBar::clampValue() {
    if (value_ < min_) value_ = min_;
    if (value_ > max_) value_ = max_;
    if (min_ > max_) {
        int32_t tmp = min_;
        min_ = max_;
        max_ = tmp;
        clampValue();
    }
}

void ProgressBar::setValue(int32_t value) {
    value_ = value;
    clampValue();
}

int32_t ProgressBar::getPercentage() const {
    if (range() <= 0) return 0;
    return (value_ - min_) * 100 / range();
}

Size ProgressBar::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    if (orientation_ == Orientation::HORIZONTAL) {
        return Size(100 + padding_.left + padding_.right,
                    8 + padding_.top + padding_.bottom);
    } else {
        return Size(8 + padding_.left + padding_.right,
                    100 + padding_.top + padding_.bottom);
    }
}

void ProgressBar::onRender(Framebuffer& fb, const BitmapFont& font) const {
    // Background
    fb.fillRect(bounds_, bgColor_);

    if (indeterminate_) {
        // Indeterminate: draw a moving bar (static in prototype — center 30%)
        if (orientation_ == Orientation::HORIZONTAL) {
            int32_t barW = bounds_.width * 3 / 10;
            int32_t barX = bounds_.x + (bounds_.width - barW) / 2;
            fb.fillRect(Rect(barX, bounds_.y, barW, bounds_.height), fillColor_);
        } else {
            int32_t barH = bounds_.height * 3 / 10;
            int32_t barY = bounds_.y + (bounds_.height - barH) / 2;
            fb.fillRect(Rect(bounds_.x, barY, bounds_.width, barH), fillColor_);
        }
    } else {
        int32_t pct = getPercentage();
        if (orientation_ == Orientation::HORIZONTAL) {
            int32_t fillW = bounds_.width * pct / 100;
            if (fillW > 0) {
                fb.fillRect(Rect(bounds_.x, bounds_.y, fillW, bounds_.height), fillColor_);
            }
        } else {
            int32_t fillH = bounds_.height * pct / 100;
            int32_t fillY = bounds_.y + bounds_.height - fillH;
            if (fillH > 0) {
                fb.fillRect(Rect(bounds_.x, fillY, bounds_.width, fillH), fillColor_);
            }
        }
    }

    // Border
    for (int32_t x = bounds_.x; x < bounds_.right(); ++x) {
        fb.setPixel(x, bounds_.y, borderColor_);
        fb.setPixel(x, bounds_.bottom() - 1, borderColor_);
    }
    for (int32_t y = bounds_.y; y < bounds_.bottom(); ++y) {
        fb.setPixel(bounds_.x, y, borderColor_);
        fb.setPixel(bounds_.right() - 1, y, borderColor_);
    }
}

// ============================================================
// Slider
// ============================================================

Slider::Slider(WidgetId id, int32_t min, int32_t max, int32_t value)
    : Widget(id, "Slider"), min_(min), max_(max), value_(value) {
    flags_ = flags_ | WidgetFlags::CLICKABLE | WidgetFlags::FOCUSABLE;
    clampValue();
}

void Slider::clampValue() {
    if (value_ < min_) value_ = min_;
    if (value_ > max_) value_ = max_;
    if (min_ > max_) {
        int32_t tmp = min_;
        min_ = max_;
        max_ = tmp;
        clampValue();
    }
}

void Slider::setValue(int32_t value) {
    int32_t oldValue = value_;
    value_ = value;
    clampValue();
    if (value_ != oldValue) {
        if (onChange_) onChange_(value_);
    }
}

int32_t Slider::positionToValue(int32_t x) const {
    if (bounds_.width <= 2 * thumbSize_) return min_;
    int32_t relativeX = x - bounds_.x - thumbSize_;
    int32_t trackWidth = bounds_.width - 2 * thumbSize_;
    if (trackWidth <= 0) return min_;
    if (relativeX < 0) relativeX = 0;
    if (relativeX > trackWidth) relativeX = trackWidth;
    return min_ + (relativeX * range()) / trackWidth;
}

int32_t Slider::valueToPosition() const {
    if (range() <= 0) return bounds_.x + thumbSize_;
    int32_t trackWidth = bounds_.width - 2 * thumbSize_;
    if (trackWidth <= 0) return bounds_.x + thumbSize_;
    int32_t relativeX = ((value_ - min_) * trackWidth) / range();
    return bounds_.x + thumbSize_ + relativeX;
}

Size Slider::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    return Size(120 + padding_.left + padding_.right,
                12 + padding_.top + padding_.bottom);
}

void Slider::onRender(Framebuffer& fb, const BitmapFont& font) const {
    int32_t trackY = bounds_.y + bounds_.height / 2 - 1;
    int32_t trackHeight = 3;

    // Draw track
    fb.fillRect(Rect(bounds_.x + thumbSize_, trackY,
                     bounds_.width - 2 * thumbSize_, trackHeight), trackColor_);

    // Draw fill portion
    int32_t thumbX = valueToPosition();
    int32_t fillW = thumbX - bounds_.x - thumbSize_;
    if (fillW > 0) {
        fb.fillRect(Rect(bounds_.x + thumbSize_, trackY, fillW, trackHeight), fillColor_);
    }

    // Draw thumb (square, centered on track)
    int32_t thumbH = trackHeight + 4;  // thumb is slightly taller than track
    fb.fillRect(Rect(thumbX - thumbSize_, trackY - 2,
                     thumbSize_ * 2, thumbH), thumbColor_);
}

bool Slider::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    dragging_ = true;
    state_ = WidgetState::PRESSED;
    setValue(positionToValue(x));
    return true;
}

bool Slider::onTouchMove(int32_t x, int32_t y) {
    if (!isEnabled() || !dragging_) return false;
    setValue(positionToValue(x));
    return true;
}

bool Slider::onTouchUp(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    dragging_ = false;
    state_ = WidgetState::NORMAL;
    return true;
}

}  // namespace phantom::gui
