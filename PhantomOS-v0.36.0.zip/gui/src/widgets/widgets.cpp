/*
 * Phantom OS - GUI Widgets Implementation
 * Button, Label, TextField, ListView
 *
 * License: GPL-3.0
 */

#include "phantom/gui/widgets/widgets.h"

namespace phantom::gui {

// ============================================================
// Label
// ============================================================

Label::Label(WidgetId id, const std::string& text)
    : Widget(id, "Label"), text_(text) {
    flags_ = flags_ | WidgetFlags::VISIBLE;
}

void Label::setText(const std::string& text) {
    text_ = text;
}

Size Label::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    // Estimate: each char is 6px wide, 7px tall + padding
    int32_t w = static_cast<int32_t>(text_.length()) * 6 + padding_.left + padding_.right;
    int32_t h = 7 + padding_.top + padding_.bottom;
    return Size(w, h);
}

void Label::onRender(Framebuffer& fb, const BitmapFont& font) const {
    int32_t textX = bounds_.x + padding_.left;
    int32_t textY = bounds_.y + padding_.top;
    font.drawTextClipped(fb, bounds_, textX, textY, text_, textColor_);
}

// ============================================================
// Button
// ============================================================

Button::Button(WidgetId id, const std::string& text)
    : Widget(id, "Button"), text_(text) {
    flags_ = flags_ | WidgetFlags::CLICKABLE | WidgetFlags::FOCUSABLE;
}

void Button::setText(const std::string& text) {
    text_ = text;
}

Size Button::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    int32_t textW = static_cast<int32_t>(text_.length()) * 6;
    int32_t w = textW + padding_.left + padding_.right + 4;
    int32_t h = 7 + padding_.top + padding_.bottom + 4;
    return Size(w, h);
}

void Button::onRender(Framebuffer& fb, const BitmapFont& font) const {
    Color bg = bgColor_;
    if (pressed_) {
        // Darken background when pressed
        bg = Color(
            static_cast<uint8_t>(bg.r / 2),
            static_cast<uint8_t>(bg.g / 2),
            static_cast<uint8_t>(bg.b / 2),
            bg.a
        );
    }
    if (!isEnabled()) {
        bg = Color::DarkGray;
    }

    fb.fillRect(bounds_, bg);

    // Draw border
    Color borderColor = pressed_ ? Color::White : Color::LightGray;
    // Top and bottom borders
    for (int32_t x = bounds_.x; x < bounds_.right(); ++x) {
        fb.setPixel(x, bounds_.y, borderColor);
        fb.setPixel(x, bounds_.bottom() - 1, borderColor);
    }
    // Left and right borders
    for (int32_t y = bounds_.y; y < bounds_.bottom(); ++y) {
        fb.setPixel(bounds_.x, y, borderColor);
        fb.setPixel(bounds_.right() - 1, y, borderColor);
    }

    // Draw text centered
    int32_t textW = static_cast<int32_t>(text_.length()) * 6;
    int32_t textX = bounds_.x + (bounds_.width - textW) / 2;
    int32_t textY = bounds_.y + (bounds_.height - 7) / 2;

    font.drawTextClipped(fb, bounds_, textX, textY, text_, textColor_);
}

bool Button::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    pressed_ = true;
    state_ = WidgetState::PRESSED;
    return true;
}

bool Button::onTouchUp(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    bool wasPressed = pressed_;
    pressed_ = false;
    state_ = WidgetState::NORMAL;
    if (wasPressed) {
        performClick();
    }
    return true;
}

// ============================================================
// TextField
// ============================================================

TextField::TextField(WidgetId id, const std::string& text)
    : Widget(id, "TextField"), text_(text) {
    flags_ = flags_ | WidgetFlags::FOCUSABLE;
    cursorPos_ = text_.length();
}

void TextField::setText(const std::string& text) {
    text_ = text;
    if (cursorPos_ > text_.length()) {
        cursorPos_ = text_.length();
    }
}

void TextField::insertChar(char c) {
    if (cursorPos_ > text_.length()) cursorPos_ = text_.length();
    text_.insert(cursorPos_, 1, c);
    cursorPos_++;
}

void TextField::deleteChar() {
    if (cursorPos_ == 0 || text_.empty()) return;
    text_.erase(cursorPos_ - 1, 1);
    cursorPos_--;
}

void TextField::clear() {
    text_.clear();
    cursorPos_ = 0;
}

void TextField::setCursorPosition(size_t pos) {
    if (pos > text_.length()) pos = text_.length();
    cursorPos_ = pos;
}

Size TextField::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    int32_t w = 80 + padding_.left + padding_.right;
    int32_t h = 7 + padding_.top + padding_.bottom + 4;
    return Size(w, h);
}

void TextField::onRender(Framebuffer& fb, const BitmapFont& font) const {
    // Background
    fb.fillRect(bounds_, bgColor_);

    // Border
    Color borderColor = focused_ ? Color::Blue : Color::DarkGray;
    for (int32_t x = bounds_.x; x < bounds_.right(); ++x) {
        fb.setPixel(x, bounds_.y, borderColor);
        fb.setPixel(x, bounds_.bottom() - 1, borderColor);
    }
    for (int32_t y = bounds_.y; y < bounds_.bottom(); ++y) {
        fb.setPixel(bounds_.x, y, borderColor);
        fb.setPixel(bounds_.right() - 1, y, borderColor);
    }

    // Text
    int32_t textX = bounds_.x + padding_.left + 2;
    int32_t textY = bounds_.y + padding_.top + 2;
    font.drawTextClipped(fb, bounds_, textX, textY, text_, textColor_);

    // Cursor (if focused)
    if (focused_) {
        int32_t cursorX = textX + static_cast<int32_t>(cursorPos_) * 6;
        for (int32_t dy = 0; dy < 7; ++dy) {
            if (bounds_.contains(cursorX, textY + dy)) {
                fb.setPixel(cursorX, textY + dy, Color::Black);
            }
        }
    }
}

bool TextField::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;
    focused_ = true;
    state_ = WidgetState::FOCUSED;
    return true;
}

// ============================================================
// ListView
// ============================================================

ListView::ListView(WidgetId id, size_t itemCount)
    : Widget(id, "ListView"), itemCount_(itemCount) {
    flags_ = flags_ | WidgetFlags::CLICKABLE | WidgetFlags::FOCUSABLE;
}

void ListView::setSelectedIndex(int32_t index) {
    if (index < 0) {
        selectedIndex_ = -1;
        return;
    }
    if (static_cast<size_t>(index) >= itemCount_) return;
    selectedIndex_ = index;
}

int32_t ListView::getVisibleItemCount() const {
    if (bounds_.height <= 0 || itemHeight_ <= 0) return 0;
    int32_t visible = bounds_.height / itemHeight_;
    if (visible < 0) visible = 0;
    return visible;
}

void ListView::scrollBy(int32_t delta) {
    int32_t newOffset = scrollOffset_ + delta;
    // Clamp: don't scroll past content
    int32_t maxOffset = static_cast<int32_t>(itemCount_) * itemHeight_ - bounds_.height;
    if (maxOffset < 0) maxOffset = 0;
    if (newOffset < 0) newOffset = 0;
    if (newOffset > maxOffset) newOffset = maxOffset;
    scrollOffset_ = newOffset;
}

void ListView::scrollTo(int32_t index) {
    if (index < 0) index = 0;
    if (static_cast<size_t>(index) >= itemCount_) {
        index = static_cast<int32_t>(itemCount_) - 1;
    }
    scrollOffset_ = index * itemHeight_;
    // Clamp to max offset
    int32_t maxOffset = static_cast<int32_t>(itemCount_) * itemHeight_ - bounds_.height;
    if (maxOffset < 0) maxOffset = 0;
    if (scrollOffset_ > maxOffset) scrollOffset_ = maxOffset;
    if (scrollOffset_ < 0) scrollOffset_ = 0;
}

Size ListView::onMeasure() const {
    if (preferredSize_.width > 0 && preferredSize_.height > 0) {
        return preferredSize_;
    }
    // Default: 200x150
    return Size(200, 150);
}

void ListView::onLayout() {
    // Nothing special needed
}

void ListView::onRender(Framebuffer& fb, const BitmapFont& font) const {
    // Background
    fb.fillRect(bounds_, bgColor_);

    // Render visible items
    int32_t startY = bounds_.y - scrollOffset_;
    int32_t firstVisible = scrollOffset_ / itemHeight_;
    if (firstVisible < 0) firstVisible = 0;

    int32_t visibleCount = getVisibleItemCount() + 1;  // +1 for partial items

    for (int32_t i = firstVisible; i < firstVisible + visibleCount && static_cast<size_t>(i) < itemCount_; ++i) {
        int32_t itemY = startY + i * itemHeight_;
        if (itemY + itemHeight_ < bounds_.y) continue;
        if (itemY >= bounds_.bottom()) break;

        Rect itemRect(bounds_.x, itemY, bounds_.width, itemHeight_);

        // Highlight selected
        if (i == selectedIndex_) {
            fb.fillRect(itemRect, selectedBgColor_);
        }

        // Draw item text
        std::string itemText;
        if (itemTextCb_) {
            itemText = itemTextCb_(static_cast<size_t>(i));
        } else {
            itemText = "Item " + std::to_string(i);
        }

        Color textColor = (i == selectedIndex_) ? selectedTextColor_ : itemTextColor_;
        font.drawTextClipped(fb, bounds_, bounds_.x + 4, itemY + 2, itemText, textColor);
    }
}

bool ListView::onTouchDown(int32_t x, int32_t y) {
    if (!isEnabled()) return false;

    // Calculate which item was tapped
    int32_t relativeY = y - bounds_.y + scrollOffset_;
    int32_t itemIndex = relativeY / itemHeight_;

    if (itemIndex >= 0 && static_cast<size_t>(itemIndex) < itemCount_) {
        selectedIndex_ = itemIndex;
        if (itemClickCb_) {
            itemClickCb_(static_cast<size_t>(itemIndex));
        }
    }
    return true;
}

}  // namespace phantom::gui
