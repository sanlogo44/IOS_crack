/*
 * Phantom OS - GUI Window Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/window_manager.h"
#include <algorithm>

namespace phantom::gui {

WindowManager& WindowManager::getInstance() {
    static WindowManager instance;
    return instance;
}

Window::WindowId WindowManager::createWindow(const std::string& title, const std::string& appId,
                                              const Rect& bounds, WindowFlags flags) {
    if (bounds.isEmpty()) return 0;

    auto window = std::make_unique<Window>(nextWindowId_, title, appId, bounds, flags);
    window->createSurface();
    windows_.push_back(std::move(window));
    return nextWindowId_++;
}

WindowManager::Result WindowManager::destroyWindow(Window::WindowId id) {
    auto it = std::find_if(windows_.begin(), windows_.end(),
        [id](const std::unique_ptr<Window>& w) { return w->getId() == id; });
    if (it == windows_.end()) return Result::WINDOW_NOT_FOUND;
    if (focusedWindowId_ == id) focusedWindowId_ = 0;
    windows_.erase(it);
    return Result::SUCCESS;
}

Window* WindowManager::findWindow(Window::WindowId id) {
    for (auto& w : windows_) {
        if (w->getId() == id) return w.get();
    }
    return nullptr;
}

const Window* WindowManager::findWindow(Window::WindowId id) const {
    for (const auto& w : windows_) {
        if (w->getId() == id) return w.get();
    }
    return nullptr;
}

Window* WindowManager::getWindow(Window::WindowId id) { return findWindow(id); }
const Window* WindowManager::getWindow(Window::WindowId id) const { return findWindow(id); }

std::vector<Window::WindowId> WindowManager::getWindowIds() const {
    std::vector<Window::WindowId> ids;
    ids.reserve(windows_.size());
    for (const auto& w : windows_) ids.push_back(w->getId());
    return ids;
}

WindowManager::Result WindowManager::showWindow(Window::WindowId id) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    w->show();
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::hideWindow(Window::WindowId id) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    w->hide();
    if (focusedWindowId_ == id) focusedWindowId_ = 0;
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::focusWindow(Window::WindowId id) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    if (!w->isFocusable()) return Result::INVALID_PARAMETER;
    if (!w->isVisible()) return Result::INVALID_PARAMETER;
    focusedWindowId_ = id;
    // Bring to front by setting highest z-order
    int32_t maxZ = 0;
    for (const auto& win : windows_) {
        if (win->getZOrder() > maxZ) maxZ = win->getZOrder();
    }
    w->setZOrder(maxZ + 1);
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::setWindowPosition(Window::WindowId id, int32_t x, int32_t y) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    w->setPosition(x, y);
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::setWindowSize(Window::WindowId id, int32_t w, int32_t h) {
    Window* win = findWindow(id);
    if (!win) return Result::WINDOW_NOT_FOUND;
    win->setSize(w, h);
    // Recreate surface if size changed
    if (win->hasSurface()) {
        win->createSurface();
    }
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::setWindowBounds(Window::WindowId id, const Rect& bounds) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    w->setBounds(bounds);
    if (w->hasSurface()) {
        w->createSurface();
    }
    return Result::SUCCESS;
}

WindowManager::Result WindowManager::setZOrder(Window::WindowId id, int32_t z) {
    Window* w = findWindow(id);
    if (!w) return Result::WINDOW_NOT_FOUND;
    w->setZOrder(z);
    return Result::SUCCESS;
}

Window* WindowManager::getFocusedWindow() {
    if (focusedWindowId_ == 0) return nullptr;
    return findWindow(focusedWindowId_);
}

WindowManager::Result WindowManager::clearFocus() {
    focusedWindowId_ = 0;
    return Result::SUCCESS;
}

Window* WindowManager::hitTest(int32_t x, int32_t y) {
    auto visible = getVisibleWindows();
    // Iterate front-to-back (reverse z-order)
    for (auto it = visible.rbegin(); it != visible.rend(); ++it) {
        Window* w = *it;
        if (w->isTouchable() && w->containsPoint(x, y)) {
            return w;
        }
    }
    return nullptr;
}

const Window* WindowManager::hitTest(int32_t x, int32_t y) const {
    // Iterate front-to-back
    std::vector<const Window*> sorted;
    for (const auto& w : windows_) {
        if (w->isVisible() && w->isTouchable()) {
            sorted.push_back(w.get());
        }
    }
    std::sort(sorted.begin(), sorted.end(),
        [](const Window* a, const Window* b) { return a->getZOrder() < b->getZOrder(); });
    for (auto it = sorted.rbegin(); it != sorted.rend(); ++it) {
        if ((*it)->containsPoint(x, y)) return *it;
    }
    return nullptr;
}

std::vector<Window*> WindowManager::getVisibleWindows() {
    std::vector<Window*> visible;
    for (auto& w : windows_) {
        if (w->isVisible()) visible.push_back(w.get());
    }
    std::sort(visible.begin(), visible.end(),
        [](Window* a, Window* b) { return a->getZOrder() < b->getZOrder(); });
    return visible;
}

std::vector<Window*> WindowManager::getAllWindowsSorted() {
    std::vector<Window*> all;
    for (auto& w : windows_) {
        all.push_back(w.get());
    }
    std::sort(all.begin(), all.end(),
        [](Window* a, Window* b) { return a->getZOrder() < b->getZOrder(); });
    return all;
}

void WindowManager::clear() {
    windows_.clear();
    focusedWindowId_ = 0;
    nextWindowId_ = 1;
}

}  // namespace phantom::gui
