/*
 * Phantom OS - Theme System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/theme.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/widgets/extended_widgets.h"
#include <algorithm>

namespace phantom::gui {

// ============================================================
// Theme Factory Methods
// ============================================================

Theme::Theme(ThemeType type, const std::string& name, const ThemeColors& colors)
    : type_(type), name_(name), colors_(colors) {}

Theme Theme::createLight() {
    ThemeColors c;
    c.background = Color(0xF5, 0xF5, 0xF5);
    c.surface = Color(0xFF, 0xFF, 0xFF);
    c.surfaceAlt = Color(0xEE, 0xEE, 0xEE);

    c.primary = Color(0x21, 0x96, 0xF3);
    c.primaryDark = Color(0x19, 0x76, 0xD2);
    c.secondary = Color(0x7C, 0x4D, 0xFF);
    c.accent = Color(0x00, 0xBC, 0xD4);

    c.textPrimary = Color(0x21, 0x21, 0x21);
    c.textSecondary = Color(0x75, 0x75, 0x75);
    c.textOnPrimary = Color(0xFF, 0xFF, 0xFF);

    c.border = Color(0xBD, 0xBD, 0xBD);
    c.divider = Color(0xE0, 0xE0, 0xE0);

    c.error = Color(0xF4, 0x43, 0x36);
    c.warning = Color(0xFF, 0xC1, 0x07);
    c.success = Color(0x4C, 0xAF, 0x50);

    c.buttonBg = Color(0x21, 0x96, 0xF3);
    c.buttonText = Color(0xFF, 0xFF, 0xFF);
    c.inputBg = Color(0xFF, 0xFF, 0xFF);
    c.inputBorder = Color(0xBD, 0xBD, 0xBD);
    c.listBg = Color(0xFF, 0xFF, 0xFF);
    c.listSelectedBg = Color(0x21, 0x96, 0xF3);
    c.listText = Color(0x21, 0x21, 0x21);
    c.listSelectedText = Color(0xFF, 0xFF, 0xFF);
    c.progressBarFill = Color(0x4C, 0xAF, 0x50);
    c.progressBarBg = Color(0xE0, 0xE0, 0xE0);
    c.sliderTrack = Color(0xBD, 0xBD, 0xBD);
    c.sliderThumb = Color(0x21, 0x96, 0xF3);
    c.sliderFill = Color(0x21, 0x96, 0xF3);
    c.checkBoxBox = Color(0x75, 0x75, 0x75);
    c.checkBoxCheck = Color(0x4C, 0xAF, 0x50);
    c.radioCircle = Color(0x75, 0x75, 0x75);
    c.radioDot = Color(0x21, 0x96, 0xF3);

    return Theme(ThemeType::LIGHT, "Light", c);
}

Theme Theme::createDark() {
    ThemeColors c;
    c.background = Color(0x12, 0x12, 0x12);
    c.surface = Color(0x1E, 0x1E, 0x1E);
    c.surfaceAlt = Color(0x2A, 0x2A, 0x2A);

    c.primary = Color(0x21, 0x96, 0xF3);
    c.primaryDark = Color(0x19, 0x76, 0xD2);
    c.secondary = Color(0xBB, 0x86, 0xFC);
    c.accent = Color(0x03, 0xDA, 0xC6);

    c.textPrimary = Color(0xFF, 0xFF, 0xFF);
    c.textSecondary = Color(0xB0, 0xB0, 0xB0);
    c.textOnPrimary = Color(0xFF, 0xFF, 0xFF);

    c.border = Color(0x42, 0x42, 0x42);
    c.divider = Color(0x33, 0x33, 0x33);

    c.error = Color(0xEF, 0x53, 0x50);
    c.warning = Color(0xFF, 0xB7, 0x4C);
    c.success = Color(0x66, 0xBB, 0x6A);

    c.buttonBg = Color(0x2A, 0x2A, 0x2A);
    c.buttonText = Color(0x21, 0x96, 0xF3);
    c.inputBg = Color(0x1E, 0x1E, 0x1E);
    c.inputBorder = Color(0x42, 0x42, 0x42);
    c.listBg = Color(0x1E, 0x1E, 0x1E);
    c.listSelectedBg = Color(0x21, 0x96, 0xF3);
    c.listText = Color(0xFF, 0xFF, 0xFF);
    c.listSelectedText = Color(0xFF, 0xFF, 0xFF);
    c.progressBarFill = Color(0x66, 0xBB, 0x6A);
    c.progressBarBg = Color(0x33, 0x33, 0x33);
    c.sliderTrack = Color(0x42, 0x42, 0x42);
    c.sliderThumb = Color(0x21, 0x96, 0xF3);
    c.sliderFill = Color(0x21, 0x96, 0xF3);
    c.checkBoxBox = Color(0xB0, 0xB0, 0xB0);
    c.checkBoxCheck = Color(0x66, 0xBB, 0x6A);
    c.radioCircle = Color(0xB0, 0xB0, 0xB0);
    c.radioDot = Color(0x21, 0x96, 0xF3);

    return Theme(ThemeType::DARK, "Dark", c);
}

// Role map for dynamic color lookup
std::unordered_map<std::string, Color ThemeColors::*> Theme::createRoleMap() {
    return {
        {"background", &ThemeColors::background},
        {"surface", &ThemeColors::surface},
        {"surfaceAlt", &ThemeColors::surfaceAlt},
        {"primary", &ThemeColors::primary},
        {"primaryDark", &ThemeColors::primaryDark},
        {"secondary", &ThemeColors::secondary},
        {"accent", &ThemeColors::accent},
        {"textPrimary", &ThemeColors::textPrimary},
        {"textSecondary", &ThemeColors::textSecondary},
        {"textOnPrimary", &ThemeColors::textOnPrimary},
        {"border", &ThemeColors::border},
        {"divider", &ThemeColors::divider},
        {"error", &ThemeColors::error},
        {"warning", &ThemeColors::warning},
        {"success", &ThemeColors::success},
        {"buttonBg", &ThemeColors::buttonBg},
        {"buttonText", &ThemeColors::buttonText},
        {"inputBg", &ThemeColors::inputBg},
        {"inputBorder", &ThemeColors::inputBorder},
        {"listBg", &ThemeColors::listBg},
        {"listSelectedBg", &ThemeColors::listSelectedBg},
        {"listText", &ThemeColors::listText},
        {"listSelectedText", &ThemeColors::listSelectedText},
        {"progressBarFill", &ThemeColors::progressBarFill},
        {"progressBarBg", &ThemeColors::progressBarBg},
        {"sliderTrack", &ThemeColors::sliderTrack},
        {"sliderThumb", &ThemeColors::sliderThumb},
        {"sliderFill", &ThemeColors::sliderFill},
        {"checkBoxBox", &ThemeColors::checkBoxBox},
        {"checkBoxCheck", &ThemeColors::checkBoxCheck},
        {"radioCircle", &ThemeColors::radioCircle},
        {"radioDot", &ThemeColors::radioDot},
    };
}

const Color& Theme::getColor(const std::string& role) const {
    static Color fallback = Color::Black;
    static auto roleMap = createRoleMap();
    auto it = roleMap.find(role);
    if (it == roleMap.end()) return fallback;
    return colors_.*(it->second);
}

// ============================================================
// ThemeManager
// ============================================================

ThemeManager::ThemeManager() {
    currentTheme_ = Theme::createDark();
}

ThemeManager& ThemeManager::getInstance() {
    static ThemeManager instance;
    return instance;
}

void ThemeManager::setTheme(const Theme& theme) {
    // Compare full theme: type, name, and all colors
    if (currentTheme_.getType() == theme.getType() &&
        currentTheme_.getName() == theme.getName()) {
        const auto& cur = currentTheme_.getColors();
        const auto& in = theme.getColors();
        if (cur.background.toRGBA32() == in.background.toRGBA32() &&
            cur.surface.toRGBA32() == in.surface.toRGBA32() &&
            cur.primary.toRGBA32() == in.primary.toRGBA32() &&
            cur.textPrimary.toRGBA32() == in.textPrimary.toRGBA32() &&
            cur.buttonBg.toRGBA32() == in.buttonBg.toRGBA32()) {
            return;  // No change
        }
    }
    currentTheme_ = theme;
    notifyListeners();
}

void ThemeManager::setThemeType(ThemeType type) {
    if (type == ThemeType::LIGHT) {
        setTheme(Theme::createLight());
    } else if (type == ThemeType::DARK) {
        setTheme(Theme::createDark());
    }
    // CUSTOM type requires explicit setTheme() call
}

void ThemeManager::toggleTheme() {
    if (currentTheme_.getType() == ThemeType::LIGHT) {
        setTheme(Theme::createDark());
    } else {
        setTheme(Theme::createLight());
    }
}

ThemeManager::ListenerId ThemeManager::addListener(const ListenerCallback& cb) {
    ListenerId id = nextListenerId_++;
    listeners_.push_back({id, cb});
    return id;
}

void ThemeManager::removeListener(ListenerId id) {
    listeners_.erase(
        std::remove_if(listeners_.begin(), listeners_.end(),
            [id](const std::pair<ListenerId, ListenerCallback>& entry) {
                return entry.first == id;
            }),
        listeners_.end()
    );
}

void ThemeManager::clearListeners() {
    listeners_.clear();
}

void ThemeManager::notifyListeners() {
    for (const auto& entry : listeners_) {
        entry.second(currentTheme_);
    }
}

void ThemeManager::reset() {
    clearListeners();
    nextListenerId_ = 1;
    currentTheme_ = Theme::createDark();
}

// ============================================================
// Widget applyTheme — recursive application
// ============================================================

// Forward declaration of applyTheme for each widget type
// These are defined here to avoid circular dependencies

void Widget::applyTheme(const Theme& theme) {
    // Apply to children recursively
    for (auto& child : children_) {
        if (child) {
            child->applyTheme(theme);
        }
    }
}

// Label
void Label::applyTheme(const Theme& theme) {
    textColor_ = theme.getColors().textPrimary;
    Widget::applyTheme(theme);
}

// Button
void Button::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    bgColor_ = c.buttonBg;
    textColor_ = c.buttonText;
    Widget::applyTheme(theme);
}

// TextField
void TextField::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    bgColor_ = c.inputBg;
    textColor_ = c.textPrimary;
    Widget::applyTheme(theme);
}

// ListView
void ListView::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    bgColor_ = c.listBg;
    selectedBgColor_ = c.listSelectedBg;
    itemTextColor_ = c.listText;
    selectedTextColor_ = c.listSelectedText;
    Widget::applyTheme(theme);
}

// CheckBox
void CheckBox::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    textColor_ = c.textPrimary;
    boxColor_ = c.checkBoxBox;
    checkColor_ = c.checkBoxCheck;
    Widget::applyTheme(theme);
}

// RadioButton
void RadioButton::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    textColor_ = c.textPrimary;
    circleColor_ = c.radioCircle;
    dotColor_ = c.radioDot;
    Widget::applyTheme(theme);
}

// ProgressBar
void ProgressBar::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    bgColor_ = c.progressBarBg;
    fillColor_ = c.progressBarFill;
    borderColor_ = c.border;
    Widget::applyTheme(theme);
}

// Slider
void Slider::applyTheme(const Theme& theme) {
    const auto& c = theme.getColors();
    trackColor_ = c.sliderTrack;
    thumbColor_ = c.sliderThumb;
    fillColor_ = c.sliderFill;
    Widget::applyTheme(theme);
}

void ThemeManager::applyTheme(Widget& root) const {
    root.applyTheme(currentTheme_);
}

}  // namespace phantom::gui
