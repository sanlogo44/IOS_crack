/*
 * Phantom OS - GUI Compositor Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/compositor.h"

namespace phantom::gui {

void Compositor::setOutputSize(int32_t width, int32_t height) {
    output_ = std::make_unique<Framebuffer>(width, height);
}

void Compositor::setOutputSize(const Size& size) {
    setOutputSize(size.width, size.height);
}

void Compositor::compose() {
    auto& wm = WindowManager::getInstance();
    auto visible = wm.getVisibleWindows();
    compose(visible);
}

void Compositor::compose(const std::vector<Window*>& windows) {
    if (!output_) return;

    // Clear with background color
    output_->clear(bgColor_);
    lastWindowCount_ = 0;
    lastPixelCount_ = 0;

    // Windows are already sorted by z-order (ascending = back to front)
    for (Window* window : windows) {
        if (!window || !window->isVisible()) continue;
        if (!window->hasSurface()) continue;

        const Surface* surface = window->getSurface();
        if (!surface || !surface->isValid()) continue;

        // Blit the window's surface to the output at the window position
        Point pos = window->getPosition();
        if (window->isTransparent()) {
            output_->blitBlended(surface->getFramebuffer(), pos.x, pos.y);
        } else {
            output_->blit(surface->getFramebuffer(), pos.x, pos.y);
        }

        lastWindowCount_++;
    }

    // Count non-background pixels
    uint32_t bgRGBA = bgColor_.toRGBA32();
    for (int32_t i = 0; i < output_->getPixelCount(); ++i) {
        if (output_->getPixelRaw(i) != bgRGBA) {
            lastPixelCount_++;
        }
    }
}

bool Compositor::verifyPixel(int32_t x, int32_t y, const Color& expected) const {
    if (!output_) return false;
    Color actual = output_->getPixel(x, y);
    return actual == expected;
}

int32_t Compositor::countNonBackgroundPixels() const {
    if (!output_) return 0;
    uint32_t bgRGBA = bgColor_.toRGBA32();
    int32_t count = 0;
    for (int32_t i = 0; i < output_->getPixelCount(); ++i) {
        if (output_->getPixelRaw(i) != bgRGBA) count++;
    }
    return count;
}

}  // namespace phantom::gui
