/*
 * Phantom OS - GUI Layout System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/layout.h"

namespace phantom::gui {

// ============================================================
// LinearLayout
// ============================================================

LinearLayout::LinearLayout(LayoutOrientation orientation)
    : orientation_(orientation) {}

Size LinearLayout::measure(const Widget& container) const {
    auto children = container.getChildren();
    int32_t totalMajor = 0;
    int32_t maxMinor = 0;
    int32_t count = 0;

    for (const Widget* child : children) {
        if (!child || child->isGone()) continue;
        Size childSize = child->onMeasure();
        if (orientation_ == LayoutOrientation::VERTICAL) {
            totalMajor += childSize.height;
            if (childSize.width > maxMinor) maxMinor = childSize.width;
        } else {
            totalMajor += childSize.width;
            if (childSize.height > maxMinor) maxMinor = childSize.height;
        }
        count++;
    }

    // Add spacing between items
    if (count > 1) {
        totalMajor += spacing_ * (count - 1);
    }

    // Add padding
    auto pad = container.getPadding();
    int32_t padMajor = (orientation_ == LayoutOrientation::VERTICAL)
                        ? (pad.top + pad.bottom) : (pad.left + pad.right);
    int32_t padMinor = (orientation_ == LayoutOrientation::VERTICAL)
                       ? (pad.left + pad.right) : (pad.top + pad.bottom);

    if (orientation_ == LayoutOrientation::VERTICAL) {
        return Size(maxMinor + padMinor, totalMajor + padMajor);
    } else {
        return Size(totalMajor + padMajor, maxMinor + padMinor);
    }
}

void LinearLayout::layout(Widget& container) {
    auto children = container.getChildren();
    auto pad = container.getPadding();
    Rect bounds = container.getBounds();

    int32_t innerX = bounds.x + pad.left;
    int32_t innerY = bounds.y + pad.top;
    int32_t innerW = bounds.width - pad.left - pad.right;
    int32_t innerH = bounds.height - pad.top - pad.bottom;

    // Filter visible children
    std::vector<Widget*> visible;
    for (Widget* child : children) {
        if (child && !child->isGone()) {
            visible.push_back(child);
        }
    }

    if (visible.empty()) return;

    // Calculate total size of all children
    int32_t totalSize = 0;
    for (Widget* child : visible) {
        Size cs = child->onMeasure();
        totalSize += (orientation_ == LayoutOrientation::VERTICAL) ? cs.height : cs.width;
    }
    totalSize += spacing_ * (static_cast<int32_t>(visible.size()) - 1);

    // Starting position based on gravity
    int32_t startMajor;
    if (orientation_ == LayoutOrientation::VERTICAL) {
        int32_t available = innerH;
        if (gravity_ == LayoutGravity::CENTER) {
            startMajor = innerY + (available - totalSize) / 2;
        } else if (gravity_ == LayoutGravity::BOTTOM_CENTER) {
            startMajor = innerY + available - totalSize;
        } else {
            startMajor = innerY;  // TOP_LEFT
        }
    } else {
        int32_t available = innerW;
        if (gravity_ == LayoutGravity::CENTER) {
            startMajor = innerX + (available - totalSize) / 2;
        } else if (gravity_ == LayoutGravity::BOTTOM_CENTER) {
            startMajor = innerX + available - totalSize;
        } else {
            startMajor = innerX;
        }
    }

    // Layout each child
    int32_t pos = startMajor;
    for (Widget* child : visible) {
        Size cs = child->onMeasure();
        if (orientation_ == LayoutOrientation::VERTICAL) {
            int32_t childX = innerX;
            if (gravity_ == LayoutGravity::FILL) {
                child->setBounds(Rect(innerX, pos, innerW, cs.height));
            } else {
                child->setBounds(Rect(childX, pos, cs.width, cs.height));
            }
            pos += cs.height + spacing_;
        } else {
            int32_t childY = innerY;
            if (gravity_ == LayoutGravity::FILL) {
                child->setBounds(Rect(pos, innerY, cs.width, innerH));
            } else {
                child->setBounds(Rect(pos, childY, cs.width, cs.height));
            }
            pos += cs.width + spacing_;
        }
        child->onLayout();
    }
}

// ============================================================
// FrameLayout
// ============================================================

Size FrameLayout::measure(const Widget& container) const {
    auto children = container.getChildren();
    int32_t maxW = 0;
    int32_t maxH = 0;

    for (const Widget* child : children) {
        if (!child || child->isGone()) continue;
        Size cs = child->onMeasure();
        if (cs.width > maxW) maxW = cs.width;
        if (cs.height > maxH) maxH = cs.height;
    }

    auto pad = container.getPadding();
    return Size(maxW + pad.left + pad.right, maxH + pad.top + pad.bottom);
}

Rect FrameLayout::applyGravity(const Rect& childBounds, const Rect& containerInner, LayoutGravity gravity) const {
    int32_t x = containerInner.x;
    int32_t y = containerInner.y;

    switch (gravity) {
        case LayoutGravity::TOP_LEFT:
            x = containerInner.x;
            y = containerInner.y;
            break;
        case LayoutGravity::TOP_CENTER:
            x = containerInner.x + (containerInner.width - childBounds.width) / 2;
            y = containerInner.y;
            break;
        case LayoutGravity::TOP_RIGHT:
            x = containerInner.right() - childBounds.width;
            y = containerInner.y;
            break;
        case LayoutGravity::CENTER:
            x = containerInner.x + (containerInner.width - childBounds.width) / 2;
            y = containerInner.y + (containerInner.height - childBounds.height) / 2;
            break;
        case LayoutGravity::BOTTOM_CENTER:
            x = containerInner.x + (containerInner.width - childBounds.width) / 2;
            y = containerInner.bottom() - childBounds.height;
            break;
        case LayoutGravity::FILL:
            x = containerInner.x;
            y = containerInner.y;
            break;
    }

    return Rect(x, y, childBounds.width, childBounds.height);
}

void FrameLayout::layout(Widget& container) {
    auto children = container.getChildren();
    auto pad = container.getPadding();
    Rect bounds = container.getBounds();

    Rect inner(bounds.x + pad.left, bounds.y + pad.top,
               bounds.width - pad.left - pad.right,
               bounds.height - pad.top - pad.bottom);

    for (Widget* child : children) {
        if (!child || child->isGone()) continue;
        Size cs = child->onMeasure();

        Rect childBounds(0, 0, cs.width, cs.height);
        if (gravity_ == LayoutGravity::FILL) {
            childBounds = inner;
        } else {
            childBounds = applyGravity(childBounds, inner, gravity_);
        }

        child->setBounds(childBounds);
        child->onLayout();
    }
}

}  // namespace phantom::gui
