/*
 * Phantom OS - GUI Surface Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/surface.h"

namespace phantom::gui {

Surface::Surface(SurfaceId id, const Size& size)
    : id_(id), framebuffer_(size) {}

Surface::Surface(SurfaceId id, int32_t width, int32_t height)
    : id_(id), framebuffer_(width, height) {}

}  // namespace phantom::gui
