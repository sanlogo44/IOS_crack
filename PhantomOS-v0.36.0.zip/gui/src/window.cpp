/*
 * Phantom OS - GUI Window Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/window.h"

namespace phantom::gui {

Window::Window(WindowId id, const std::string& title, const std::string& appId,
               const Rect& bounds, WindowFlags flags)
    : id_(id), title_(title), appId_(appId), bounds_(bounds),
      state_(WindowState::CREATED), flags_(flags) {}

void Window::createSurface() {
    if (bounds_.isValid()) {
        surface_ = std::make_unique<Surface>(id_, bounds_.size());
    }
}

}  // namespace phantom::gui
