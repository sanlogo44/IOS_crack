/*
 * Phantom OS - GUI Input Dispatcher Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/input_dispatcher.h"

namespace phantom::gui {

InputDispatcher& InputDispatcher::getInstance() {
    static InputDispatcher instance;
    return instance;
}

Window::WindowId InputDispatcher::dispatch(const InputEvent& event) {
    return dispatch(event, defaultCallback_);
}

Window::WindowId InputDispatcher::dispatch(const InputEvent& event, const GuiEventCallback& callback) {
    auto& wm = WindowManager::getInstance();
    Window* target = nullptr;

    // For touch_down, hit-test to find the target window
    // For touch_move and touch_up, route to the active touch window
    if (event.type == InputEventType::TOUCH_DOWN) {
        target = wm.hitTest(event.x, event.y);
        if (target) {
            activeTouchWindow_ = target->getId();
        }
    } else if (event.type == InputEventType::TOUCH_MOVE || event.type == InputEventType::TOUCH_UP) {
        if (activeTouchWindow_ != 0) {
            target = wm.getWindow(activeTouchWindow_);
        }
        // If the touch_up ends, clear active touch
        if (event.type == InputEventType::TOUCH_UP) {
            activeTouchWindow_ = 0;
        }
    }

    if (!target) {
        totalDropped_++;
        return 0;
    }

    // Convert screen coordinates to window-local coordinates
    Point windowPos = target->getPosition();
    GuiEvent guiEvent;
    guiEvent.type = event.type;
    guiEvent.targetWindowId = target->getId();
    guiEvent.screenX = event.x;
    guiEvent.screenY = event.y;
    guiEvent.x = event.x - windowPos.x;
    guiEvent.y = event.y - windowPos.y;
    guiEvent.timestamp = event.timestamp;

    if (callback) {
        callback(guiEvent);
    }

    totalDispatched_++;
    return target->getId();
}

void InputDispatcher::queueEvent(const InputEvent& event) {
    eventQueue_.push(event);
}

void InputDispatcher::queueEvent(InputEvent&& event) {
    eventQueue_.push(std::move(event));
}

void InputDispatcher::processQueue() {
    processQueue(defaultCallback_);
}

void InputDispatcher::processQueue(const GuiEventCallback& callback) {
    while (!eventQueue_.empty()) {
        InputEvent event = eventQueue_.front();
        eventQueue_.pop();
        dispatch(event, callback);
    }
}

void InputDispatcher::clearQueue() {
    while (!eventQueue_.empty()) {
        eventQueue_.pop();
    }
}

}  // namespace phantom::gui
