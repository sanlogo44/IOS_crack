/*
 * Phantom OS - Animation System Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/gui/animation.h"
#include <algorithm>

namespace phantom::gui {

// ============================================================
// Easing Functions
// ============================================================

float Easing::apply(EasingType type, float t) {
    // Clamp input to [0, 1]
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    switch (type) {
        case EasingType::LINEAR:
            return t;

        case EasingType::EASE_IN_QUAD:
            return t * t;

        case EasingType::EASE_OUT_QUAD:
            return t * (2.0f - t);

        case EasingType::EASE_IN_OUT_QUAD:
            return (t < 0.5f) ? (2.0f * t * t) : (1.0f - 2.0f * (1.0f - t) * (1.0f - t));

        case EasingType::EASE_IN_CUBIC:
            return t * t * t;

        case EasingType::EASE_OUT_CUBIC: {
            float f = 1.0f - t;
            return 1.0f - f * f * f;
        }

        case EasingType::EASE_IN_OUT_CUBIC:
            return (t < 0.5f) ? (4.0f * t * t * t) : (1.0f - 4.0f * (1.0f - t) * (1.0f - t) * (1.0f - t));

        case EasingType::EASE_IN_BOUNCE:
            return 1.0f - Easing::apply(EasingType::EASE_OUT_BOUNCE, 1.0f - t);

        case EasingType::EASE_OUT_BOUNCE: {
            if (t < 1.0f / 2.75f) {
                return 7.5625f * t * t;
            } else if (t < 2.0f / 2.75f) {
                float f = t - 1.5f / 2.75f;
                return 7.5625f * f * f + 0.75f;
            } else if (t < 2.5f / 2.75f) {
                float f = t - 2.25f / 2.75f;
                return 7.5625f * f * f + 0.9375f;
            } else {
                float f = t - 2.625f / 2.75f;
                return 7.5625f * f * f + 0.984375f;
            }
        }

        case EasingType::EASE_IN_BACK: {
            const float s = 1.70158f;
            return t * t * ((s + 1.0f) * t - s);
        }

        case EasingType::EASE_OUT_BACK: {
            const float s = 1.70158f;
            float f = t - 1.0f;
            return f * f * ((s + 1.0f) * f + s) + 1.0f;
        }

        default:
            return t;
    }
}

// ============================================================
// Animation Base Class
// ============================================================

Animation::Animation(int32_t durationMs, EasingType easing)
    : durationMs_(durationMs), easing_(easing) {
    if (durationMs_ < 0) durationMs_ = 0;
}

float Animation::computeEasedProgress() const {
    return Easing::apply(easing_, progress_);
}

void Animation::checkCompletion() {
    if (state_ == AnimationState::RUNNING && progress_ >= 1.0f && !completionFired_) {
        if (!loop_) {
            state_ = AnimationState::COMPLETED;
            completionFired_ = true;
            if (completeCb_) completeCb_();
        } else {
            // Loop: reset elapsed for next cycle
            elapsedMs_ = 0;
            progress_ = 0.0f;
        }
    }
}

void Animation::start() {
    if (state_ == AnimationState::RUNNING) return;
    state_ = AnimationState::RUNNING;
    elapsedMs_ = 0;
    progress_ = 0.0f;
    completionFired_ = false;
}

void Animation::pause() {
    if (state_ == AnimationState::RUNNING) {
        state_ = AnimationState::PAUSED;
    }
}

void Animation::resume() {
    if (state_ == AnimationState::PAUSED) {
        state_ = AnimationState::RUNNING;
    }
}

void Animation::cancel() {
    state_ = AnimationState::CANCELLED;
}

void Animation::reset() {
    state_ = AnimationState::IDLE;
    elapsedMs_ = 0;
    progress_ = 0.0f;
    completionFired_ = false;
}

// ============================================================
// ValueAnimator
// ============================================================

ValueAnimator::ValueAnimator(float start, float end, int32_t durationMs, EasingType easing)
    : Animation(durationMs, easing), startValue_(start), endValue_(end), currentValue_(start) {}

void ValueAnimator::reset() {
    Animation::reset();
    currentValue_ = reverse_ ? endValue_ : startValue_;
}

void ValueAnimator::start() {
    Animation::start();
    currentValue_ = reverse_ ? endValue_ : startValue_;
}

void ValueAnimator::updateValue() {
    float easedProgress = computeEasedProgress();
    if (reverse_) {
        currentValue_ = endValue_ + (startValue_ - endValue_) * easedProgress;
    } else {
        currentValue_ = startValue_ + (endValue_ - startValue_) * easedProgress;
    }
    if (updateCb_) updateCb_(currentValue_);
}

bool ValueAnimator::update(int32_t deltaMs) {
    if (state_ != AnimationState::RUNNING) {
        return state_ == AnimationState::PAUSED;
    }

    // Handle zero-duration: immediately complete
    if (durationMs_ == 0) {
        progress_ = 1.0f;
        currentValue_ = reverse_ ? startValue_ : endValue_;
        if (updateCb_) updateCb_(currentValue_);
        checkCompletion();
        return state_ != AnimationState::COMPLETED || loop_;
    }

    elapsedMs_ += deltaMs;
    progress_ = static_cast<float>(elapsedMs_) / static_cast<float>(durationMs_);
    if (progress_ > 1.0f) progress_ = 1.0f;

    updateValue();
    checkCompletion();

    // Still active if running or paused (completed with loop)
    return state_ == AnimationState::RUNNING || state_ == AnimationState::PAUSED;
}

// ============================================================
// PropertyAnimator
// ============================================================

PropertyAnimator::PropertyAnimator(Widget* widget, Property prop, float start, float end,
                                    int32_t durationMs, EasingType easing)
    : Animation(durationMs, easing), widget_(widget), property_(prop) {
    animator_ = std::make_shared<ValueAnimator>(start, end, durationMs, easing);
}

void PropertyAnimator::applyValue(float value) {
    if (!widget_) return;

    Rect bounds = widget_->getBounds();

    switch (property_) {
        case Property::X:
            widget_->setPosition(static_cast<int32_t>(value), bounds.y);
            break;
        case Property::Y:
            widget_->setPosition(bounds.x, static_cast<int32_t>(value));
            break;
        case Property::WIDTH: {
            int32_t w = static_cast<int32_t>(value);
            if (w < 0) w = 0;
            widget_->setSize(w, bounds.height);
            break;
        }
        case Property::HEIGHT: {
            int32_t h = static_cast<int32_t>(value);
            if (h < 0) h = 0;
            widget_->setSize(bounds.width, h);
            break;
        }
        case Property::ALPHA:
            widget_->setAlpha(value);
            break;
    }
}

void PropertyAnimator::start() {
    Animation::start();
    animator_->start();
    applyValue(animator_->getCurrentValue());
}

bool PropertyAnimator::update(int32_t deltaMs) {
    if (state_ != AnimationState::RUNNING) {
        return state_ == AnimationState::PAUSED;
    }

    bool active = animator_->update(deltaMs);
    // Always apply the current value, including when inner animator just completed
    applyValue(animator_->getCurrentValue());

    // Sync state from inner animator
    if (animator_->getState() == AnimationState::COMPLETED && !completionFired_) {
        state_ = AnimationState::COMPLETED;
        progress_ = 1.0f;
        completionFired_ = true;
        if (completeCb_) completeCb_();
        return loop_;
    }

    progress_ = animator_->getProgress();
    elapsedMs_ = animator_->getElapsed();

    return active;
}

std::shared_ptr<PropertyAnimator> PropertyAnimator::animatePosition(
    Widget* widget, int32_t fromX, int32_t fromY,
    int32_t toX, int32_t toY, int32_t durationMs, EasingType easing) {
    // Set initial position
    if (widget) {
        widget->setPosition(fromX, fromY);
    }
    // Animate X; Y is set to toY immediately (single-property animation limitation)
    auto anim = std::make_shared<PropertyAnimator>(widget, Property::X,
                                                     static_cast<float>(fromX),
                                                     static_cast<float>(toX),
                                                     durationMs, easing);
    // Set Y to target immediately
    if (widget) {
        widget->setPosition(fromX, toY);
    }
    return anim;
}

std::shared_ptr<PropertyAnimator> PropertyAnimator::animateSize(
    Widget* widget, int32_t fromW, int32_t fromH,
    int32_t toW, int32_t toH, int32_t durationMs, EasingType easing) {
    // Set initial size
    if (widget) {
        widget->setSize(fromW, fromH);
    }
    // Animate width; height is set to toH immediately (single-property animation limitation)
    auto anim = std::make_shared<PropertyAnimator>(widget, Property::WIDTH,
                                                     static_cast<float>(fromW),
                                                     static_cast<float>(toW),
                                                     durationMs, easing);
    // Set height to target immediately
    if (widget) {
        widget->setSize(fromW, toH);
    }
    return anim;
}

std::shared_ptr<PropertyAnimator> PropertyAnimator::animateFade(
    Widget* widget, float fromAlpha, float toAlpha,
    int32_t durationMs, EasingType easing) {
    if (widget) {
        widget->setAlpha(fromAlpha);
    }
    auto anim = std::make_shared<PropertyAnimator>(widget, Property::ALPHA,
                                                     fromAlpha, toAlpha,
                                                     durationMs, easing);
    return anim;
}

// ============================================================
// Transition
// ============================================================

Transition::Transition(TransitionType type, int32_t durationMs)
    : Animation(durationMs, EasingType::LINEAR), type_(type) {
    if (durationMs_ <= 0) {
        durationMs_ = getDefaultDuration(type);
    }
}

int32_t Transition::getDefaultDuration(TransitionType type) {
    switch (type) {
        case TransitionType::FADE_IN:
        case TransitionType::FADE_OUT:
            return 300;
        case TransitionType::SLIDE_IN_LEFT:
        case TransitionType::SLIDE_IN_RIGHT:
        case TransitionType::SLIDE_IN_TOP:
        case TransitionType::SLIDE_IN_BOTTOM:
        case TransitionType::SLIDE_OUT_LEFT:
        case TransitionType::SLIDE_OUT_RIGHT:
        case TransitionType::SLIDE_OUT_TOP:
        case TransitionType::SLIDE_OUT_BOTTOM:
            return 250;
        case TransitionType::SCALE_IN:
        case TransitionType::SCALE_OUT:
            return 200;
        default:
            return 300;
    }
}

void Transition::setupAnimator() {
    if (!widget_) return;

    originalX_ = widget_->getBounds().x;
    originalY_ = widget_->getBounds().y;
    originalW_ = widget_->getBounds().width;
    originalH_ = widget_->getBounds().height;

    switch (type_) {
        case TransitionType::FADE_IN:
            widget_->setAlpha(0.0f);
            animator_ = std::make_shared<ValueAnimator>(0.0f, 1.0f, durationMs_, EasingType::LINEAR);
            break;

        case TransitionType::FADE_OUT:
            widget_->setAlpha(1.0f);
            animator_ = std::make_shared<ValueAnimator>(1.0f, 0.0f, durationMs_, EasingType::LINEAR);
            break;

        case TransitionType::SLIDE_IN_LEFT:
            widget_->setPosition(originalX_ - originalW_, originalY_);
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalX_ - originalW_),
                static_cast<float>(originalX_),
                durationMs_, EasingType::EASE_OUT_CUBIC);
            break;

        case TransitionType::SLIDE_IN_RIGHT:
            widget_->setPosition(originalX_ + originalW_, originalY_);
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalX_ + originalW_),
                static_cast<float>(originalX_),
                durationMs_, EasingType::EASE_OUT_CUBIC);
            break;

        case TransitionType::SLIDE_IN_TOP:
            widget_->setPosition(originalX_, originalY_ - originalH_);
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalY_ - originalH_),
                static_cast<float>(originalY_),
                durationMs_, EasingType::EASE_OUT_CUBIC);
            break;

        case TransitionType::SLIDE_IN_BOTTOM:
            widget_->setPosition(originalX_, originalY_ + originalH_);
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalY_ + originalH_),
                static_cast<float>(originalY_),
                durationMs_, EasingType::EASE_OUT_CUBIC);
            break;

        case TransitionType::SLIDE_OUT_LEFT:
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalX_),
                static_cast<float>(originalX_ - originalW_),
                durationMs_, EasingType::EASE_IN_CUBIC);
            break;

        case TransitionType::SLIDE_OUT_RIGHT:
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalX_),
                static_cast<float>(originalX_ + originalW_),
                durationMs_, EasingType::EASE_IN_CUBIC);
            break;

        case TransitionType::SLIDE_OUT_TOP:
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalY_),
                static_cast<float>(originalY_ - originalH_),
                durationMs_, EasingType::EASE_IN_CUBIC);
            break;

        case TransitionType::SLIDE_OUT_BOTTOM:
            animator_ = std::make_shared<ValueAnimator>(
                static_cast<float>(originalY_),
                static_cast<float>(originalY_ + originalH_),
                durationMs_, EasingType::EASE_IN_CUBIC);
            break;

        case TransitionType::SCALE_IN:
            widget_->setSize(0, 0);
            animator_ = std::make_shared<ValueAnimator>(0.0f, 1.0f, durationMs_, EasingType::EASE_OUT_BACK);
            break;

        case TransitionType::SCALE_OUT:
            animator_ = std::make_shared<ValueAnimator>(1.0f, 0.0f, durationMs_, EasingType::EASE_IN_BACK);
            break;

        default:
            break;
    }
}

void Transition::start() {
    Animation::start();
    setupAnimator();
    if (animator_) {
        animator_->start();

        // For slide transitions, set up update callback
        switch (type_) {
            case TransitionType::FADE_IN:
            case TransitionType::FADE_OUT:
                animator_->setUpdateCallback([this](float v) {
                    if (widget_) widget_->setAlpha(v);
                });
                break;
            case TransitionType::SLIDE_IN_LEFT:
            case TransitionType::SLIDE_OUT_LEFT:
            case TransitionType::SLIDE_IN_RIGHT:
            case TransitionType::SLIDE_OUT_RIGHT:
                animator_->setUpdateCallback([this](float v) {
                    if (widget_) widget_->setPosition(static_cast<int32_t>(v), originalY_);
                });
                break;
            case TransitionType::SLIDE_IN_TOP:
            case TransitionType::SLIDE_OUT_TOP:
            case TransitionType::SLIDE_IN_BOTTOM:
            case TransitionType::SLIDE_OUT_BOTTOM:
                animator_->setUpdateCallback([this](float v) {
                    if (widget_) widget_->setPosition(originalX_, static_cast<int32_t>(v));
                });
                break;
            case TransitionType::SCALE_IN:
            case TransitionType::SCALE_OUT:
                animator_->setUpdateCallback([this](float v) {
                    if (widget_) {
                        int32_t w = static_cast<int32_t>(originalW_ * v);
                        int32_t h = static_cast<int32_t>(originalH_ * v);
                        if (w < 0) w = 0;
                        if (h < 0) h = 0;
                        widget_->setSize(w, h);
                    }
                });
                break;
            default:
                break;
        }
    }
}

bool Transition::update(int32_t deltaMs) {
    if (state_ != AnimationState::RUNNING) {
        return state_ == AnimationState::PAUSED;
    }

    if (!animator_) {
        state_ = AnimationState::COMPLETED;
        completionFired_ = true;
        if (completeCb_) completeCb_();
        return false;
    }

    bool active = animator_->update(deltaMs);
    progress_ = animator_->getProgress();
    elapsedMs_ = animator_->getElapsed();

    if (animator_->getState() == AnimationState::COMPLETED && !completionFired_) {
        state_ = AnimationState::COMPLETED;
        completionFired_ = true;
        if (completeCb_) completeCb_();
        return loop_;
    }

    return active;
}

// ============================================================
// AnimationManager
// ============================================================

AnimationManager& AnimationManager::getInstance() {
    static AnimationManager instance;
    return instance;
}

void AnimationManager::add(std::shared_ptr<Animation> anim) {
    if (anim) {
        animations_.push_back(anim);
    }
}

void AnimationManager::update(int32_t deltaMs) {
    for (auto& anim : animations_) {
        if (anim) {
            anim->update(deltaMs);
        }
    }
}

void AnimationManager::cleanup() {
    animations_.erase(
        std::remove_if(animations_.begin(), animations_.end(),
            [](const std::shared_ptr<Animation>& anim) {
                return !anim ||
                       anim->getState() == AnimationState::COMPLETED ||
                       anim->getState() == AnimationState::CANCELLED;
            }),
        animations_.end()
    );
}

void AnimationManager::cancelForWidget(Widget* widget) {
    if (!widget) return;

    for (auto& anim : animations_) {
        if (!anim) continue;

        // Check PropertyAnimator
        auto* pa = dynamic_cast<PropertyAnimator*>(anim.get());
        if (pa && pa->getWidget() == widget) {
            anim->cancel();
            continue;
        }

        // Check Transition
        auto* trans = dynamic_cast<Transition*>(anim.get());
        if (trans && trans->getWidget() == widget) {
            anim->cancel();
        }
    }

    cleanup();
}

void AnimationManager::clear() {
    animations_.clear();
}

size_t AnimationManager::getActiveCount() const {
    size_t count = 0;
    for (const auto& anim : animations_) {
        if (anim && (anim->getState() == AnimationState::RUNNING ||
                     anim->getState() == AnimationState::PAUSED)) {
            count++;
        }
    }
    return count;
}

size_t AnimationManager::getTotalCount() const {
    return animations_.size();
}

}  // namespace phantom::gui
