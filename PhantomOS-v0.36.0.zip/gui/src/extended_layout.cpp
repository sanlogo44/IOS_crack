/*
 * Phantom OS - Extended Layout Implementation
 * RelativeLayout and GridLayout
 *
 * License: GPL-3.0
 */

#include "phantom/gui/extended_layout.h"
#include <cmath>
#include <algorithm>

namespace phantom::gui {

// ============================================================
// RelativeLayout
// ============================================================

void RelativeLayout::setLayoutParams(const std::string& tag, const LayoutParams& params) {
    params_[tag] = params;
}

const RelativeLayout::LayoutParams* RelativeLayout::getLayoutParams(const std::string& tag) const {
    auto it = params_.find(tag);
    if (it == params_.end()) return nullptr;
    return &it->second;
}

Widget* RelativeLayout::findChildByTag(Widget& container, const std::string& tag) const {
    auto children = container.getChildren();
    for (auto* child : children) {
        if (child->getTag() == tag) return child;
    }
    return nullptr;
}

Rect RelativeLayout::resolveChildBounds(Widget& container, Widget& child,
                                        const LayoutParams& params,
                                        const std::unordered_map<std::string, Rect>& resolved) {
    Rect bounds = container.getBounds();
    Size childSize = child.onMeasure();

    int32_t x = -1;
    int32_t y = -1;
    int32_t w = childSize.width;
    int32_t h = childSize.height;

    // Horizontal positioning
    if (params.alignParentLeft == 1) {
        x = bounds.x + params.marginLeft;
    } else if (params.alignParentRight == 1) {
        x = bounds.right() - w - params.marginRight;
    } else if (params.centerHorizontal == 1 || params.centerInParent == 1) {
        x = bounds.x + (bounds.width - w) / 2 + params.marginLeft - params.marginRight;
    } else if (!params.toRightOf.empty()) {
        auto it = resolved.find(params.toRightOf);
        if (it != resolved.end()) {
            x = it->second.right() + params.marginLeft;
        } else {
            Widget* ref = findChildByTag(container, params.toRightOf);
            if (ref) {
                Size refSize = ref->onMeasure();
                x = ref->getBounds().right() + params.marginLeft;
            }
        }
    } else if (!params.toLeftOf.empty()) {
        auto it = resolved.find(params.toLeftOf);
        if (it != resolved.end()) {
            x = it->second.x - w - params.marginRight;
        }
    }

    // Vertical positioning
    if (params.alignParentTop == 1) {
        y = bounds.y + params.marginTop;
    } else if (params.alignParentBottom == 1) {
        y = bounds.bottom() - h - params.marginBottom;
    } else if (params.centerVertical == 1 || params.centerInParent == 1) {
        y = bounds.y + (bounds.height - h) / 2 + params.marginTop - params.marginBottom;
    } else if (!params.below.empty()) {
        auto it = resolved.find(params.below);
        if (it != resolved.end()) {
            y = it->second.bottom() + params.marginTop;
        } else {
            Widget* ref = findChildByTag(container, params.below);
            if (ref) {
                y = ref->getBounds().bottom() + params.marginTop;
            }
        }
    } else if (!params.above.empty()) {
        auto it = resolved.find(params.above);
        if (it != resolved.end()) {
            y = it->second.y - h - params.marginBottom;
        }
    }

    // Default to top-left if nothing set
    if (x < 0) x = bounds.x + params.marginLeft;
    if (y < 0) y = bounds.y + params.marginTop;

    return Rect(x, y, w, h);
}

Size RelativeLayout::measure(const Widget& container) const {
    Size maxSize(0, 0);
    auto children = container.getChildren();
    for (auto* child : children) {
        if (child->isGone()) continue;
        Size s = child->onMeasure();
        // For relative layout, we need to account for margins
        auto it = params_.find(child->getTag());
        int32_t marginH = 0, marginV = 0;
        if (it != params_.end()) {
            marginH = it->second.marginLeft + it->second.marginRight;
            marginV = it->second.marginTop + it->second.marginBottom;
        }
        if (s.width + marginH > maxSize.width) maxSize.width = s.width + marginH;
        if (s.height + marginV > maxSize.height) maxSize.height = s.height + marginV;
    }
    return maxSize;
}

void RelativeLayout::layout(Widget& container) {
    std::unordered_map<std::string, Rect> resolved;
    auto children = container.getChildren();

    // First pass: resolve children with no dependencies on other children
    // (alignParent*, center*)
    for (auto* child : children) {
        if (child->isGone()) continue;
        const LayoutParams* params = getLayoutParams(child->getTag());
        if (!params) {
            // Default: place at top-left
            Size s = child->onMeasure();
            child->setBounds(Rect(container.getBounds().x,
                                   container.getBounds().y, s.width, s.height));
            resolved[child->getTag()] = child->getBounds();
            continue;
        }

        bool hasRelativeDeps = !params->above.empty() || !params->below.empty() ||
                               !params->toLeftOf.empty() || !params->toRightOf.empty();

        if (!hasRelativeDeps) {
            Rect r = resolveChildBounds(container, *child, *params, resolved);
            child->setBounds(r);
            resolved[child->getTag()] = r;
        }
    }

    // Second pass: resolve children that depend on other children
    // Multiple passes to handle chains
    bool changed = true;
    int32_t pass = 0;
    while (changed && pass < 10) {
        changed = false;
        for (auto* child : children) {
            if (child->isGone()) continue;
            if (resolved.count(child->getTag()) > 0) continue;

            const LayoutParams* params = getLayoutParams(child->getTag());
            if (!params) continue;

            // Check if all dependencies are resolved
            bool depsResolved = true;
            if (!params->above.empty() && resolved.count(params->above) == 0) depsResolved = false;
            if (!params->below.empty() && resolved.count(params->below) == 0) depsResolved = false;
            if (!params->toLeftOf.empty() && resolved.count(params->toLeftOf) == 0) depsResolved = false;
            if (!params->toRightOf.empty() && resolved.count(params->toRightOf) == 0) depsResolved = false;

            if (depsResolved) {
                Rect r = resolveChildBounds(container, *child, *params, resolved);
                child->setBounds(r);
                resolved[child->getTag()] = r;
                changed = true;
            }
        }
        pass++;
    }
}

// ============================================================
// GridLayout
// ============================================================

GridLayout::GridLayout(int32_t rows, int32_t columns)
    : rows_(rows), columns_(columns) {}

void GridLayout::setSpan(const std::string& tag, int32_t rowSpan, int32_t colSpan) {
    spans_[tag] = {rowSpan, colSpan};
}

void GridLayout::autoDetect(Widget& container, int32_t& rows, int32_t& cols) const {
    auto children = container.getChildren();
    int32_t visibleCount = 0;
    for (auto* child : children) {
        if (!child->isGone()) visibleCount++;
    }
    if (visibleCount == 0) {
        rows = 1;
        cols = 1;
        return;
    }
    if (cols > 0) {
        rows = (visibleCount + cols - 1) / cols;
    } else if (rows > 0) {
        cols = (visibleCount + rows - 1) / rows;
    } else {
        // Default: square grid
        cols = static_cast<int32_t>(std::ceil(std::sqrt(static_cast<double>(visibleCount))));
        rows = (visibleCount + cols - 1) / cols;
        if (rows < 1) rows = 1;
    }
}

Size GridLayout::measure(const Widget& container) const {
    auto children = container.getChildren();
    int32_t maxChildW = 0;
    int32_t maxChildH = 0;
    int32_t visibleCount = 0;

    for (auto* child : children) {
        if (child->isGone()) continue;
        Size s = child->onMeasure();
        if (s.width > maxChildW) maxChildW = s.width;
        if (s.height > maxChildH) maxChildH = s.height;
        visibleCount++;
    }

    if (visibleCount == 0) return Size(0, 0);

    int32_t r = rows_;
    int32_t c = columns_;
    if (r <= 0 && c <= 0) {
        c = static_cast<int32_t>(std::ceil(std::sqrt(static_cast<double>(visibleCount))));
        r = (visibleCount + c - 1) / c;
    } else if (r <= 0) {
        r = (visibleCount + c - 1) / c;
    } else if (c <= 0) {
        c = (visibleCount + r - 1) / r;
    }

    if (r < 1) r = 1;
    if (c < 1) c = 1;

    int32_t w = c * maxChildW + (c - 1) * spacing_;
    int32_t h = r * maxChildH + (r - 1) * spacing_;
    return Size(w, h);
}

void GridLayout::layout(Widget& container) {
    auto children = container.getChildren();
    Rect bounds = container.getBounds();

    int32_t r = rows_;
    int32_t c = columns_;
    autoDetect(container, r, c);

    if (r < 1) r = 1;
    if (c < 1) c = 1;

    // Calculate cell dimensions
    int32_t cellW = (bounds.width - (c - 1) * spacing_) / c;
    int32_t cellH = (bounds.height - (r - 1) * spacing_) / r;
    if (cellW < 1) cellW = 1;
    if (cellH < 1) cellH = 1;

    int32_t childIndex = 0;
    for (auto* child : children) {
        if (child->isGone()) continue;

        int32_t row = childIndex / c;
        int32_t col = childIndex % c;

        // Check for spans
        int32_t rowSpan = 1;
        int32_t colSpan = 1;
        auto spanIt = spans_.find(child->getTag());
        if (spanIt != spans_.end()) {
            rowSpan = spanIt->second.rowSpan;
            colSpan = spanIt->second.colSpan;
        }

        int32_t cellX = bounds.x + col * (cellW + spacing_);
        int32_t cellY = bounds.y + row * (cellH + spacing_);
        int32_t cellWidth = cellW * colSpan + (colSpan - 1) * spacing_;
        int32_t cellHeight = cellH * rowSpan + (rowSpan - 1) * spacing_;

        Size childSize = child->onMeasure();

        Rect childRect;
        if (alignment_ == CellAlignment::FILL) {
            childRect = Rect(cellX, cellY, cellWidth, cellHeight);
        } else if (alignment_ == CellAlignment::CENTER) {
            childRect = Rect(
                cellX + (cellWidth - childSize.width) / 2,
                cellY + (cellHeight - childSize.height) / 2,
                childSize.width, childSize.height
            );
        } else {
            childRect = Rect(cellX, cellY, childSize.width, childSize.height);
        }

        child->setBounds(childRect);
        childIndex++;
    }
}

}  // namespace phantom::gui
