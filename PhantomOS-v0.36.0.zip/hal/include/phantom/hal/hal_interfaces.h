/*
 * Phantom OS - HAL Interface Definitions
 * Abstract interfaces for all hardware components
 *
 * License: GPL-3.0
 */

#pragma once

#include "hal_types.h"

namespace phantom::hal {

// ============================================================
// Display HAL
// ============================================================
class IDisplayHal {
public:
    virtual ~IDisplayHal() = default;

    // Initialize display
    virtual HalResult init() = 0;

    // Get display info
    virtual HalResult getInfo(DisplayInfo* info) = 0;

    // Set brightness (0-255)
    virtual HalResult setBrightness(uint8_t brightness) = 0;

    // Get current brightness
    virtual HalResult getBrightness(uint8_t* brightness) = 0;

    // Present a framebuffer
    virtual HalResult presentFrame(const uint8_t* buffer, size_t size) = 0;

    // Set power state (on/off for display)
    virtual HalResult setPower(bool on) = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Input / Touch HAL
// ============================================================
class IInputHal {
public:
    virtual ~IInputHal() = default;

    // Initialize input subsystem
    virtual HalResult init() = 0;

    // Register callback for input events
    using InputCallback = std::function<void(const InputEvent&)>;
    virtual HalResult registerCallback(InputCallback callback) = 0;

    // Check if multi-touch is supported
    virtual HalResult supportsMultiTouch(bool* supported) = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Storage HAL
// ============================================================
class IStorageHal {
public:
    virtual ~IStorageHal() = default;

    // Initialize storage
    virtual HalResult init() = 0;

    // Get storage info
    virtual HalResult getInfo(StorageInfo* info) = 0;

    // Read from storage
    virtual HalResult read(uint64_t offset, void* buffer, size_t size) = 0;

    // Write to storage
    virtual HalResult write(uint64_t offset, const void* buffer, size_t size) = 0;

    // Flush (ensure data is written to disk)
    virtual HalResult flush() = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Network HAL
// ============================================================
class INetworkHal {
public:
    virtual ~INetworkHal() = default;

    // Initialize network subsystem
    virtual HalResult init() = 0;

    // Get network interfaces (protected by privacy layer)
    virtual HalResult getInterfaces(NetworkInterface* interfaces, size_t max_count, size_t* actual_count) = 0;

    // Wi-Fi operations
    virtual HalResult wifiScan(const char* ssid, bool* found) = 0;
    virtual HalResult wifiConnect(const char* ssid, const char* password) = 0;
    virtual HalResult wifiDisconnect() = 0;
    virtual HalResult wifiGetStatus(bool* connected) = 0;

    // Bluetooth operations
    virtual HalResult btScan(bool* found) = 0;
    virtual HalResult btConnect(const char* address) = 0;
    virtual HalResult btDisconnect() = 0;

    // Cellular operations
    virtual HalResult cellularGetStatus(bool* registered) = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Sensor HAL
// ============================================================
class ISensorHal {
public:
    virtual ~ISensorHal() = default;

    // Initialize sensors
    virtual HalResult init() = 0;

    // Check if sensor is available
    virtual HalResult hasSensor(SensorType type, bool* available) = 0;

    // Register callback for sensor data
    using SensorCallback = std::function<void(const SensorData&)>;
    virtual HalResult registerCallback(SensorType type, SensorCallback callback) = 0;

    // Set sensor accuracy (privacy: may reduce accuracy)
    virtual HalResult setAccuracy(SensorType type, uint8_t accuracy) = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Camera HAL
// ============================================================
class ICameraHal {
public:
    virtual ~ICameraHal() = default;

    // Initialize camera
    virtual HalResult init() = 0;

    // Open camera (front or rear)
    virtual HalResult open(bool front_camera) = 0;

    // Start preview/streaming
    using FrameCallback = std::function<void(const CameraFrame&)>;
    virtual HalResult startStreaming(FrameCallback callback) = 0;

    // Stop streaming
    virtual HalResult stopStreaming() = 0;

    // Capture single photo
    virtual HalResult capturePhoto(CameraFrame* frame) = 0;

    // Close camera
    virtual HalResult close() = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Audio HAL
// ============================================================
class IAudioHal {
public:
    virtual ~IAudioHal() = default;

    // Initialize audio
    virtual HalResult init() = 0;

    // Set output format
    virtual HalResult setOutputFormat(const AudioFormat& format) = 0;

    // Write audio data for playback
    virtual HalResult writeOutput(const uint8_t* data, size_t size) = 0;

    // Start recording
    using AudioCallback = std::function<void(const uint8_t* data, size_t size)>;
    virtual HalResult startRecording(AudioCallback callback) = 0;

    // Stop recording
    virtual HalResult stopRecording() = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// Power HAL
// ============================================================
class IPowerHal {
public:
    virtual ~IPowerHal() = default;

    // Initialize power management
    virtual HalResult init() = 0;

    // Get current power state
    virtual HalResult getPowerState(PowerState* state) = 0;

    // Set power state
    virtual HalResult setPowerState(PowerState state) = 0;

    // Get battery info
    virtual HalResult getBatteryInfo(BatteryInfo* info) = 0;

    // Reboot device
    virtual HalResult reboot() = 0;

    // Shutdown device
    virtual HalResult shutdown() = 0;

    // Deinitialize
    virtual HalResult deinit() = 0;
};

// ============================================================
// HAL Factory - creates HAL instances
// ============================================================
class IHalFactory {
public:
    virtual ~IHalFactory() = default;

    virtual HalResult createDisplay(IDisplayHal** out) = 0;
    virtual HalResult createInput(IInputHal** out) = 0;
    virtual HalResult createStorage(IStorageHal** out) = 0;
    virtual HalResult createNetwork(INetworkHal** out) = 0;
    virtual HalResult createSensor(ISensorHal** out) = 0;
    virtual HalResult createCamera(ICameraHal** out) = 0;
    virtual HalResult createAudio(IAudioHal** out) = 0;
    virtual HalResult createPower(IPowerHal** out) = 0;

    // Destroy HAL instances
    virtual void destroyDisplay(IDisplayHal* p) = 0;
    virtual void destroyInput(IInputHal* p) = 0;
    virtual void destroyStorage(IStorageHal* p) = 0;
    virtual void destroyNetwork(INetworkHal* p) = 0;
    virtual void destroySensor(ISensorHal* p) = 0;
    virtual void destroyCamera(ICameraHal* p) = 0;
    virtual void destroyAudio(IAudioHal* p) = 0;
    virtual void destroyPower(IPowerHal* p) = 0;
};

}  // namespace phantom::hal
