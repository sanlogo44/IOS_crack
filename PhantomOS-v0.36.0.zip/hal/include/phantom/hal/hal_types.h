/*
 * Phantom OS - HAL Types
 * Common type definitions for the Hardware Abstraction Layer
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <functional>
#include <string>

namespace phantom::hal {

// Result codes for HAL operations
enum class HalResult : int32_t {
    SUCCESS = 0,
    NOT_INITIALIZED = -1,
    NOT_SUPPORTED = -2,
    PERMISSION_DENIED = -3,
    INVALID_ARGUMENT = -4,
    HARDWARE_ERROR = -5,
    BUSY = -6,
    TIMEOUT = -7,
    NOT_FOUND = -8,
};

// Convert result to string
inline const char* halResultToString(HalResult r) {
    switch (r) {
        case HalResult::SUCCESS: return "SUCCESS";
        case HalResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case HalResult::NOT_SUPPORTED: return "NOT_SUPPORTED";
        case HalResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case HalResult::INVALID_ARGUMENT: return "INVALID_ARGUMENT";
        case HalResult::HARDWARE_ERROR: return "HARDWARE_ERROR";
        case HalResult::BUSY: return "BUSY";
        case HalResult::TIMEOUT: return "TIMEOUT";
        case HalResult::NOT_FOUND: return "NOT_FOUND";
        default: return "UNKNOWN";
    }
}

// Display resolution descriptor
struct DisplayResolution {
    uint32_t width;
    uint32_t height;
    uint32_t refresh_rate_hz;
    uint32_t dpi;
};

// Display info
struct DisplayInfo {
    DisplayResolution resolution;
    bool has_touch;
    bool has_3d_acceleration;
    char panel_type[32];  // e.g., "OLED", "LCD"
};

// Input event types
enum class InputEventType : uint8_t {
    TOUCH = 0,
    KEY = 1,
    GESTURE = 2,
};

// Input event
struct InputEvent {
    InputEventType type;
    int32_t x;           // For touch: x coordinate
    int32_t y;           // For touch: y coordinate
    int32_t pressure;    // For touch: pressure (0-255)
    int32_t key_code;    // For key: key code
    uint64_t timestamp;  // Nanoseconds since boot
};

// Storage info
struct StorageInfo {
    uint64_t total_bytes;
    uint64_t available_bytes;
    bool is_encrypted;
    char filesystem_type[16];
};

// Network interface info
struct NetworkInterface {
    char name[32];
    bool is_up;
    bool has_wifi;
    bool has_cellular;
    uint8_t mac_address[6];  // Hardware MAC (protected by privacy layer)
};

// Sensor types
enum class SensorType : uint8_t {
    ACCELEROMETER = 0,
    GYROSCOPE = 1,
    PROXIMITY = 2,
    AMBIENT_LIGHT = 3,
    MAGNETOMETER = 4,
    GPS = 5,
};

// Sensor data (generic 3-axis)
struct SensorData {
    SensorType type;
    float values[3];     // x, y, z (or lat, lng, alt for GPS)
    uint64_t timestamp;
    uint8_t accuracy;    // 0=none, 1=low, 2=medium, 3=high
};

// Camera frame format
enum class CameraFormat : uint8_t {
    YUV420 = 0,
    RGB888 = 1,
    JPEG = 2,
    RAW = 3,
};

// Camera frame
struct CameraFrame {
    CameraFormat format;
    uint32_t width;
    uint32_t height;
    uint32_t stride;
    const uint8_t* data;
    size_t data_size;
    uint64_t timestamp;
};

// Audio format
struct AudioFormat {
    uint32_t sample_rate;    // e.g., 44100
    uint8_t channels;        // 1=mono, 2=stereo
    uint8_t bits_per_sample; // 16, 24, 32
};

// Power state
enum class PowerState : uint8_t {
    ACTIVE = 0,
    SUSPEND = 1,
    DEEP_SLEEP = 2,
    SHUTDOWN = 3,
};

// Battery info
struct BatteryInfo {
    uint8_t level;           // 0-100
    bool is_charging;
    int32_t voltage_mv;     // millivolts
    int32_t temperature_dc; // tenths of degree Celsius
};

}  // namespace phantom::hal
