/*
 * Phantom OS - Mock HAL Factory Header
 * Declares the mock HAL factory function for test access
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/hal/hal_interfaces.h"

namespace phantom::hal {

// Create a mock HAL factory (for testing without real hardware)
IHalFactory* createMockHalFactory();

}  // namespace phantom::hal
