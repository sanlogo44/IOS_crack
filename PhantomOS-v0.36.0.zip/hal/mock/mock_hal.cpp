/*
 * Phantom OS - Mock HAL Implementation
 * Provides mock implementations for testing without real hardware
 *
 * License: GPL-3.0
 */

#include "phantom/hal/hal_interfaces.h"
#include "mock_hal_factory.h"
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <memory>
#include <vector>

namespace phantom::hal {

// ============================================================
// Mock Display HAL
// ============================================================
class MockDisplayHal : public IDisplayHal {
private:
    bool initialized_ = false;
    bool powered_on_ = false;
    uint8_t brightness_ = 128;

public:
    HalResult init() override {
        if (initialized_) return HalResult::SUCCESS;
        initialized_ = true;
        powered_on_ = true;
        return HalResult::SUCCESS;
    }

    HalResult getInfo(DisplayInfo* info) override {
        if (!initialized_ || !info) return HalResult::NOT_INITIALIZED;
        info->resolution = {2436, 1125, 60, 458};
        info->has_touch = true;
        info->has_3d_acceleration = false;  // UNKNOWN on real hardware
        strncpy(info->panel_type, "OLED", sizeof(info->panel_type));
        return HalResult::SUCCESS;
    }

    HalResult setBrightness(uint8_t brightness) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        brightness_ = brightness;
        return HalResult::SUCCESS;
    }

    HalResult getBrightness(uint8_t* brightness) override {
        if (!initialized_ || !brightness) return HalResult::NOT_INITIALIZED;
        *brightness = brightness_;
        return HalResult::SUCCESS;
    }

    HalResult presentFrame(const uint8_t* /*buffer*/, size_t /*size*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        return HalResult::SUCCESS;
    }

    HalResult setPower(bool on) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        powered_on_ = on;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        powered_on_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Input HAL
// ============================================================
class MockInputHal : public IInputHal {
private:
    bool initialized_ = false;
    InputCallback callback_;

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult registerCallback(InputCallback callback) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        callback_ = std::move(callback);
        return HalResult::SUCCESS;
    }

    HalResult supportsMultiTouch(bool* supported) override {
        if (!initialized_ || !supported) return HalResult::NOT_INITIALIZED;
        *supported = true;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        callback_ = nullptr;
        return HalResult::SUCCESS;
    }

    // Test helper: simulate an input event
    void simulateEvent(const InputEvent& event) {
        if (callback_) callback_(event);
    }
};

// ============================================================
// Mock Storage HAL
// ============================================================
class MockStorageHal : public IStorageHal {
private:
    bool initialized_ = false;
    std::vector<uint8_t> storage_;
    static constexpr size_t STORAGE_SIZE = 64 * 1024 * 1024;  // 64MB mock

public:
    HalResult init() override {
        if (initialized_) return HalResult::SUCCESS;
        storage_.resize(STORAGE_SIZE, 0);
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult getInfo(StorageInfo* info) override {
        if (!initialized_ || !info) return HalResult::NOT_INITIALIZED;
        info->total_bytes = STORAGE_SIZE;
        info->available_bytes = STORAGE_SIZE;
        info->is_encrypted = true;
        strncpy(info->filesystem_type, "ext4", sizeof(info->filesystem_type));
        return HalResult::SUCCESS;
    }

    HalResult read(uint64_t offset, void* buffer, size_t size) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (offset + size > STORAGE_SIZE) return HalResult::INVALID_ARGUMENT;
        memcpy(buffer, storage_.data() + offset, size);
        return HalResult::SUCCESS;
    }

    HalResult write(uint64_t offset, const void* buffer, size_t size) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (offset + size > STORAGE_SIZE) return HalResult::INVALID_ARGUMENT;
        memcpy(storage_.data() + offset, buffer, size);
        return HalResult::SUCCESS;
    }

    HalResult flush() override {
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        storage_.clear();
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Network HAL
// ============================================================
class MockNetworkHal : public INetworkHal {
private:
    bool initialized_ = false;
    bool wifi_connected_ = false;
    bool bt_connected_ = false;
    bool cellular_registered_ = false;

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult getInterfaces(NetworkInterface* interfaces, size_t max_count, size_t* actual_count) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (max_count < 1) return HalResult::INVALID_ARGUMENT;
        memset(&interfaces[0], 0, sizeof(NetworkInterface));
        strncpy(interfaces[0].name, "wlan0", sizeof(interfaces[0].name));
        interfaces[0].is_up = wifi_connected_;
        interfaces[0].has_wifi = true;
        interfaces[0].has_cellular = true;
        // MAC address is zeroed — privacy layer protects it
        memset(interfaces[0].mac_address, 0, 6);
        *actual_count = 1;
        return HalResult::SUCCESS;
    }

    HalResult wifiScan(const char* /*ssid*/, bool* found) override {
        if (!initialized_ || !found) return HalResult::NOT_INITIALIZED;
        *found = false;
        return HalResult::SUCCESS;
    }

    HalResult wifiConnect(const char* ssid, const char* /*password*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (!ssid) return HalResult::INVALID_ARGUMENT;
        wifi_connected_ = true;
        return HalResult::SUCCESS;
    }

    HalResult wifiDisconnect() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        wifi_connected_ = false;
        return HalResult::SUCCESS;
    }

    HalResult wifiGetStatus(bool* connected) override {
        if (!initialized_ || !connected) return HalResult::NOT_INITIALIZED;
        *connected = wifi_connected_;
        return HalResult::SUCCESS;
    }

    HalResult btScan(bool* found) override {
        if (!initialized_ || !found) return HalResult::NOT_INITIALIZED;
        *found = false;
        return HalResult::SUCCESS;
    }

    HalResult btConnect(const char* /*address*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        bt_connected_ = true;
        return HalResult::SUCCESS;
    }

    HalResult btDisconnect() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        bt_connected_ = false;
        return HalResult::SUCCESS;
    }

    HalResult cellularGetStatus(bool* registered) override {
        if (!initialized_ || !registered) return HalResult::NOT_INITIALIZED;
        *registered = cellular_registered_;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Sensor HAL
// ============================================================
class MockSensorHal : public ISensorHal {
private:
    bool initialized_ = false;
    bool sensor_available_[6] = {true, true, true, true, true, true};
    uint8_t sensor_accuracy_[6] = {3, 3, 3, 3, 3, 3};  // high accuracy by default

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult hasSensor(SensorType type, bool* available) override {
        if (!initialized_ || !available) return HalResult::NOT_INITIALIZED;
        *available = sensor_available_[static_cast<int>(type)];
        return HalResult::SUCCESS;
    }

    HalResult registerCallback(SensorType /*type*/, SensorCallback /*callback*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        return HalResult::SUCCESS;
    }

    HalResult setAccuracy(SensorType type, uint8_t accuracy) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (accuracy > 3) return HalResult::INVALID_ARGUMENT;
        sensor_accuracy_[static_cast<int>(type)] = accuracy;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Camera HAL
// ============================================================
class MockCameraHal : public ICameraHal {
private:
    bool initialized_ = false;
    bool camera_open_ = false;
    bool streaming_ = false;
    bool front_camera_ = false;

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult open(bool front_camera) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        if (camera_open_) return HalResult::BUSY;
        camera_open_ = true;
        front_camera_ = front_camera;
        return HalResult::SUCCESS;
    }

    HalResult startStreaming(FrameCallback /*callback*/) override {
        if (!initialized_ || !camera_open_) return HalResult::NOT_INITIALIZED;
        streaming_ = true;
        return HalResult::SUCCESS;
    }

    HalResult stopStreaming() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        streaming_ = false;
        return HalResult::SUCCESS;
    }

    HalResult capturePhoto(CameraFrame* frame) override {
        if (!initialized_ || !camera_open_ || !frame) return HalResult::NOT_INITIALIZED;
        // Return a dummy frame
        frame->format = CameraFormat::RGB888;
        frame->width = 4032;
        frame->height = 3024;
        frame->stride = 4032 * 3;
        frame->data = nullptr;
        frame->data_size = 0;
        frame->timestamp = 0;
        return HalResult::SUCCESS;
    }

    HalResult close() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        camera_open_ = false;
        streaming_ = false;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        camera_open_ = false;
        streaming_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Audio HAL
// ============================================================
class MockAudioHal : public IAudioHal {
private:
    bool initialized_ = false;
    bool recording_ = false;

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult setOutputFormat(const AudioFormat& /*format*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        return HalResult::SUCCESS;
    }

    HalResult writeOutput(const uint8_t* /*data*/, size_t /*size*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        return HalResult::SUCCESS;
    }

    HalResult startRecording(AudioCallback /*callback*/) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        recording_ = true;
        return HalResult::SUCCESS;
    }

    HalResult stopRecording() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        recording_ = false;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        recording_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock Power HAL
// ============================================================
class MockPowerHal : public IPowerHal {
private:
    bool initialized_ = false;
    PowerState state_ = PowerState::ACTIVE;
    BatteryInfo battery_ = {75, false, 3810, 250};

public:
    HalResult init() override {
        initialized_ = true;
        return HalResult::SUCCESS;
    }

    HalResult getPowerState(PowerState* state) override {
        if (!initialized_ || !state) return HalResult::NOT_INITIALIZED;
        *state = state_;
        return HalResult::SUCCESS;
    }

    HalResult setPowerState(PowerState state) override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        state_ = state;
        return HalResult::SUCCESS;
    }

    HalResult getBatteryInfo(BatteryInfo* info) override {
        if (!initialized_ || !info) return HalResult::NOT_INITIALIZED;
        *info = battery_;
        return HalResult::SUCCESS;
    }

    HalResult reboot() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        return HalResult::SUCCESS;
    }

    HalResult shutdown() override {
        if (!initialized_) return HalResult::NOT_INITIALIZED;
        state_ = PowerState::SHUTDOWN;
        return HalResult::SUCCESS;
    }

    HalResult deinit() override {
        initialized_ = false;
        return HalResult::SUCCESS;
    }
};

// ============================================================
// Mock HAL Factory
// ============================================================
class MockHalFactory : public IHalFactory {
public:
    HalResult createDisplay(IDisplayHal** out) override {
        *out = new MockDisplayHal();
        return HalResult::SUCCESS;
    }

    HalResult createInput(IInputHal** out) override {
        *out = new MockInputHal();
        return HalResult::SUCCESS;
    }

    HalResult createStorage(IStorageHal** out) override {
        *out = new MockStorageHal();
        return HalResult::SUCCESS;
    }

    HalResult createNetwork(INetworkHal** out) override {
        *out = new MockNetworkHal();
        return HalResult::SUCCESS;
    }

    HalResult createSensor(ISensorHal** out) override {
        *out = new MockSensorHal();
        return HalResult::SUCCESS;
    }

    HalResult createCamera(ICameraHal** out) override {
        *out = new MockCameraHal();
        return HalResult::SUCCESS;
    }

    HalResult createAudio(IAudioHal** out) override {
        *out = new MockAudioHal();
        return HalResult::SUCCESS;
    }

    HalResult createPower(IPowerHal** out) override {
        *out = new MockPowerHal();
        return HalResult::SUCCESS;
    }

    void destroyDisplay(IDisplayHal* p) override { delete p; }
    void destroyInput(IInputHal* p) override { delete p; }
    void destroyStorage(IStorageHal* p) override { delete p; }
    void destroyNetwork(INetworkHal* p) override { delete p; }
    void destroySensor(ISensorHal* p) override { delete p; }
    void destroyCamera(ICameraHal* p) override { delete p; }
    void destroyAudio(IAudioHal* p) override { delete p; }
    void destroyPower(IPowerHal* p) override { delete p; }
};

// Factory function
IHalFactory* createMockHalFactory() {
    return new MockHalFactory();
}

}  // namespace phantom::hal
