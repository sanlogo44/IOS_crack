/*
 * Phantom OS - Network Intrusion Detection System (NIDS)
 * Real-time network monitoring, attack detection, and firewall management
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <chrono>

namespace phantom::nids {

// ============================================================
// Enums
// ============================================================

enum class NidsState {
    IDLE,
    INITIALIZED,
    MONITORING,
    PAUSED,
    SHUTDOWN
};

enum class AlertSeverity {
    INFO = 0,
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3,
    CRITICAL = 4
};

enum class AlertType {
    PORT_SCAN,
    DDOS_ATTACK,
    UNAUTHORIZED_ACCESS,
    PACKET_FLOOD,
    SUSPICIOUS_PAYLOAD,
    RATE_ANOMALY,
    FIREWALL_BLOCK,
    FIREWALL_UNBLOCK,
    CUSTOM
};

enum class DetectionRuleType {
    PORT_SCAN,        // Detect port scanning (connection to many ports)
    DDOS,             // Detect DDoS (many connections from many IPs)
    FLOOD,            // Detect packet flood (high packet rate from single IP)
    UNAUTHORIZED,     // Detect unauthorized connection attempts
    RATE_ANOMALY,     // Detect unusual traffic rate
    PAYLOAD_INSPECTION // Detect suspicious payload patterns
};

enum class FirewallAction {
    BLOCK,
    UNBLOCK,
    ALLOW,
    DENY
};

enum class ConnectionState {
    NEW,
    ESTABLISHED,
    CLOSED,
    BLOCKED
};

// ============================================================
// Structs
// ============================================================

struct NetworkConnection {
    uint32_t id = 0;
    std::string sourceIp;
    std::string destIp;
    uint16_t sourcePort = 0;
    uint16_t destPort = 0;
    uint8_t protocol = 6;  // TCP=6, UDP=17
    ConnectionState state = ConnectionState::NEW;
    uint64_t packetCount = 0;
    uint64_t byteCount = 0;
    uint64_t timestamp = 0;
    bool isInbound = false;
};

struct SecurityAlert {
    uint32_t id = 0;
    AlertType type = AlertType::CUSTOM;
    AlertSeverity severity = AlertSeverity::INFO;
    std::string sourceIp;
    std::string description;
    std::string ruleName;
    uint64_t timestamp = 0;
    uint32_t connectionId = 0;
    bool acknowledged = false;
};

struct DetectionRule {
    uint32_t id = 0;
    std::string name;
    std::string description;
    DetectionRuleType type;
    AlertSeverity severity = AlertSeverity::MEDIUM;
    uint32_t threshold = 0;       // e.g., port count for port scan
    uint32_t timeWindowMs = 0;   // Time window for detection
    bool enabled = true;
};

struct FirewallRule {
    uint32_t id = 0;
    std::string ip;
    std::string portRange;   // e.g., "1-1024" or "0-65535"
    FirewallAction action = FirewallAction::BLOCK;
    std::string description;
    uint64_t timestamp = 0;
    bool active = true;
};

struct SecurityEvent {
    uint32_t id = 0;
    std::string message;
    AlertSeverity severity = AlertSeverity::INFO;
    uint64_t timestamp = 0;
    std::string source;
};

struct TrafficStats {
    uint64_t totalPackets = 0;
    uint64_t totalBytes = 0;
    uint64_t inboundPackets = 0;
    uint64_t outboundPackets = 0;
    uint64_t blockedPackets = 0;
    uint32_t activeConnections = 0;
    uint32_t totalConnections = 0;
    uint32_t alertsGenerated = 0;
};

// ============================================================
// NidsEngine - Core Detection Engine
// ============================================================

class NidsEngine {
public:
    NidsEngine() = default;
    ~NidsEngine() { shutdown(); }

    // Lifecycle
    void initialize();
    void startMonitoring();
    void pauseMonitoring();
    void shutdown();

    // State
    NidsState getState() const { return state_; }
    bool isInitialized() const { return state_ == NidsState::INITIALIZED || state_ == NidsState::MONITORING; }
    bool isMonitoring() const { return state_ == NidsState::MONITORING; }

    // Detection rules
    uint32_t addRule(const DetectionRule& rule);
    bool removeRule(uint32_t ruleId);
    bool enableRule(uint32_t ruleId);
    bool disableRule(uint32_t ruleId);
    std::vector<DetectionRule> getRules() const;
    DetectionRule getRule(uint32_t ruleId) const;
    size_t getRuleCount() const;
    size_t getActiveRuleCount() const;

    // Connection monitoring
    uint32_t registerConnection(const NetworkConnection& conn);
    bool updateConnection(uint32_t connId, const NetworkConnection& conn);
    bool closeConnection(uint32_t connId);
    std::vector<NetworkConnection> getActiveConnections() const;
    std::vector<NetworkConnection> getAllConnections() const;
    size_t getActiveConnectionCount() const;
    size_t getTotalConnectionCount() const;
    void clearConnections();

    // Alert management
    std::vector<SecurityAlert> getAlerts() const;
    std::vector<SecurityAlert> getAlertsBySeverity(AlertSeverity severity) const;
    std::vector<SecurityAlert> getUnacknowledgedAlerts() const;
    bool acknowledgeAlert(uint32_t alertId);
    bool acknowledgeAllAlerts();
    void clearAlerts();
    size_t getAlertCount() const;
    size_t getUnacknowledgedAlertCount() const;
    SecurityAlert getAlert(uint32_t alertId) const;

    // Firewall management
    uint32_t blockIp(const std::string& ip, const std::string& portRange = "0-65535", const std::string& description = "");
    bool unblockIp(uint32_t ruleId);
    bool unblockIp(const std::string& ip);
    std::vector<FirewallRule> getFirewallRules() const;
    std::vector<FirewallRule> getActiveFirewallRules() const;
    bool isIpBlocked(const std::string& ip) const;
    size_t getFirewallRuleCount() const;
    size_t getActiveFirewallRuleCount() const;
    void clearFirewallRules();

    // Event logging
    void logEvent(const std::string& message, AlertSeverity severity, const std::string& source = "NIDS");
    std::vector<SecurityEvent> getEvents() const;
    std::vector<SecurityEvent> getEventsBySeverity(AlertSeverity severity) const;
    size_t getEventCount() const;
    void clearEvents();

    // Traffic statistics
    TrafficStats getTrafficStats() const;
    void resetTrafficStats();

    // Detection simulation
    void simulatePortScan(const std::string& sourceIp, uint16_t startPort, uint16_t endPort);
    void simulateDdosAttack(const std::string& targetIp, uint32_t sourceCount);
    void simulatePacketFlood(const std::string& sourceIp, uint64_t packetCount);
    void simulateUnauthorizedAccess(const std::string& sourceIp, uint16_t port);
    void simulateNormalTraffic(uint32_t connectionCount);

    // Alert callback
    using AlertCallback = std::function<void(const SecurityAlert&)>;
    void setAlertCallback(AlertCallback cb) { alertCallback_ = cb; }

    // Event callback
    using EventCallback = std::function<void(const SecurityEvent&)>;
    void setEventCallback(EventCallback cb) { eventCallback_ = cb; }

    // String helpers
    static const char* alertTypeToString(AlertType type);
    static const char* alertSeverityToString(AlertSeverity severity);
    static const char* detectionRuleTypeToString(DetectionRuleType type);
    static const char* firewallActionToString(FirewallAction action);
    static const char* connectionStateToString(ConnectionState state);
    static const char* nidsStateToString(NidsState state);

    // Detection engine
    void runDetection();
    void detectPortScans();
    void detectDdos();
    void detectFloods();
    void detectUnauthorizedAccess();
    void detectRateAnomalies();

private:
    NidsState state_ = NidsState::IDLE;

    // Rules
    std::vector<DetectionRule> rules_;
    uint32_t nextRuleId_ = 1;

    // Connections
    std::vector<NetworkConnection> connections_;
    uint32_t nextConnectionId_ = 1;

    // Alerts
    std::vector<SecurityAlert> alerts_;
    uint32_t nextAlertId_ = 1;

    // Firewall rules
    std::vector<FirewallRule> firewallRules_;
    uint32_t nextFirewallRuleId_ = 1;

    // Events
    std::vector<SecurityEvent> events_;
    uint32_t nextEventId_ = 1;

    // Stats
    TrafficStats trafficStats_;

    // Callbacks
    AlertCallback alertCallback_;
    EventCallback eventCallback_;

    // Internal helpers
    uint32_t generateAlert(AlertType type, AlertSeverity severity,
                          const std::string& sourceIp,
                          const std::string& description,
                          const std::string& ruleName,
                          uint32_t connectionId = 0);
    void addEvent(const std::string& message, AlertSeverity severity, const std::string& source = "NIDS");
    bool isPortInRange(uint16_t port, const std::string& range) const;
    uint64_t getCurrentTimeMs() const;
};

}  // namespace phantom::nids
