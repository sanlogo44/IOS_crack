/*
 * Phantom OS - NIDS Engine Implementation
 * Network Intrusion Detection System core engine
 *
 * License: GPL-3.0
 */

#include "phantom/nids/nids_engine.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <random>
#include <sstream>
#include <unordered_map>
#include <set>

namespace phantom::nids {

// ============================================================
// String Helpers
// ============================================================

const char* NidsEngine::alertTypeToString(AlertType type) {
    switch (type) {
        case AlertType::PORT_SCAN: return "PORT_SCAN";
        case AlertType::DDOS_ATTACK: return "DDOS_ATTACK";
        case AlertType::UNAUTHORIZED_ACCESS: return "UNAUTHORIZED_ACCESS";
        case AlertType::PACKET_FLOOD: return "PACKET_FLOOD";
        case AlertType::SUSPICIOUS_PAYLOAD: return "SUSPICIOUS_PAYLOAD";
        case AlertType::RATE_ANOMALY: return "RATE_ANOMALY";
        case AlertType::FIREWALL_BLOCK: return "FIREWALL_BLOCK";
        case AlertType::FIREWALL_UNBLOCK: return "FIREWALL_UNBLOCK";
        case AlertType::CUSTOM: return "CUSTOM";
        default: return "UNKNOWN";
    }
}

const char* NidsEngine::alertSeverityToString(AlertSeverity severity) {
    switch (severity) {
        case AlertSeverity::INFO: return "INFO";
        case AlertSeverity::LOW: return "LOW";
        case AlertSeverity::MEDIUM: return "MEDIUM";
        case AlertSeverity::HIGH: return "HIGH";
        case AlertSeverity::CRITICAL: return "CRITICAL";
        default: return "UNKNOWN";
    }
}

const char* NidsEngine::detectionRuleTypeToString(DetectionRuleType type) {
    switch (type) {
        case DetectionRuleType::PORT_SCAN: return "PORT_SCAN";
        case DetectionRuleType::DDOS: return "DDOS";
        case DetectionRuleType::FLOOD: return "FLOOD";
        case DetectionRuleType::UNAUTHORIZED: return "UNAUTHORIZED";
        case DetectionRuleType::RATE_ANOMALY: return "RATE_ANOMALY";
        case DetectionRuleType::PAYLOAD_INSPECTION: return "PAYLOAD_INSPECTION";
        default: return "UNKNOWN";
    }
}

const char* NidsEngine::firewallActionToString(FirewallAction action) {
    switch (action) {
        case FirewallAction::BLOCK: return "BLOCK";
        case FirewallAction::UNBLOCK: return "UNBLOCK";
        case FirewallAction::ALLOW: return "ALLOW";
        case FirewallAction::DENY: return "DENY";
        default: return "UNKNOWN";
    }
}

const char* NidsEngine::connectionStateToString(ConnectionState state) {
    switch (state) {
        case ConnectionState::NEW: return "NEW";
        case ConnectionState::ESTABLISHED: return "ESTABLISHED";
        case ConnectionState::CLOSED: return "CLOSED";
        case ConnectionState::BLOCKED: return "BLOCKED";
        default: return "UNKNOWN";
    }
}

const char* NidsEngine::nidsStateToString(NidsState state) {
    switch (state) {
        case NidsState::IDLE: return "IDLE";
        case NidsState::INITIALIZED: return "INITIALIZED";
        case NidsState::MONITORING: return "MONITORING";
        case NidsState::PAUSED: return "PAUSED";
        case NidsState::SHUTDOWN: return "SHUTDOWN";
        default: return "UNKNOWN";
    }
}

// ============================================================
// Lifecycle
// ============================================================

void NidsEngine::initialize() {
    if (state_ != NidsState::IDLE && state_ != NidsState::SHUTDOWN) return;

    // Add default detection rules
    DetectionRule portScanRule;
    portScanRule.name = "Port Scan Detector";
    portScanRule.description = "Detects port scanning from a single source";
    portScanRule.type = DetectionRuleType::PORT_SCAN;
    portScanRule.severity = AlertSeverity::HIGH;
    portScanRule.threshold = 10;  // 10+ ports
    portScanRule.timeWindowMs = 5000;
    rules_.push_back(portScanRule);
    rules_.back().id = nextRuleId_++;

    DetectionRule ddosRule;
    ddosRule.name = "DDoS Detector";
    ddosRule.description = "Detects DDoS attacks from multiple sources";
    ddosRule.type = DetectionRuleType::DDOS;
    ddosRule.severity = AlertSeverity::CRITICAL;
    ddosRule.threshold = 50;  // 50+ connections
    ddosRule.timeWindowMs = 10000;
    rules_.push_back(ddosRule);
    rules_.back().id = nextRuleId_++;

    DetectionRule floodRule;
    floodRule.name = "Packet Flood Detector";
    floodRule.description = "Detects packet flooding from a single source";
    floodRule.type = DetectionRuleType::FLOOD;
    floodRule.severity = AlertSeverity::HIGH;
    floodRule.threshold = 1000;  // 1000+ packets
    floodRule.timeWindowMs = 5000;
    rules_.push_back(floodRule);
    rules_.back().id = nextRuleId_++;

    DetectionRule unauthorizedRule;
    unauthorizedRule.name = "Unauthorized Access Detector";
    unauthorizedRule.description = "Detects unauthorized connection attempts";
    unauthorizedRule.type = DetectionRuleType::UNAUTHORIZED;
    unauthorizedRule.severity = AlertSeverity::MEDIUM;
    unauthorizedRule.threshold = 3;  // 3+ failed attempts
    unauthorizedRule.timeWindowMs = 30000;
    rules_.push_back(unauthorizedRule);
    rules_.back().id = nextRuleId_++;

    DetectionRule anomalyRule;
    anomalyRule.name = "Rate Anomaly Detector";
    anomalyRule.description = "Detects unusual traffic rate anomalies";
    anomalyRule.type = DetectionRuleType::RATE_ANOMALY;
    anomalyRule.severity = AlertSeverity::LOW;
    anomalyRule.threshold = 500;  // 500+ packets per second
    anomalyRule.timeWindowMs = 1000;
    rules_.push_back(anomalyRule);
    rules_.back().id = nextRuleId_++;

    state_ = NidsState::INITIALIZED;

    addEvent("NIDS engine initialized", AlertSeverity::INFO);
}

void NidsEngine::startMonitoring() {
    if (state_ != NidsState::INITIALIZED && state_ != NidsState::PAUSED) return;
    state_ = NidsState::MONITORING;
    addEvent("NIDS monitoring started", AlertSeverity::INFO);
}

void NidsEngine::pauseMonitoring() {
    if (state_ != NidsState::MONITORING) return;
    state_ = NidsState::PAUSED;
    addEvent("NIDS monitoring paused", AlertSeverity::INFO);
}

void NidsEngine::shutdown() {
    if (state_ == NidsState::SHUTDOWN || state_ == NidsState::IDLE) return;

    rules_.clear();
    connections_.clear();
    alerts_.clear();
    firewallRules_.clear();
    events_.clear();
    trafficStats_ = TrafficStats{};
    nextRuleId_ = 1;
    nextConnectionId_ = 1;
    nextAlertId_ = 1;
    nextFirewallRuleId_ = 1;
    nextEventId_ = 1;
    alertCallback_ = nullptr;
    eventCallback_ = nullptr;

    state_ = NidsState::SHUTDOWN;
}

// ============================================================
// Detection Rules
// ============================================================

uint32_t NidsEngine::addRule(const DetectionRule& rule) {
    DetectionRule r = rule;
    r.id = nextRuleId_++;
    rules_.push_back(r);
    addEvent("Detection rule added: " + r.name, AlertSeverity::INFO);
    return r.id;
}

bool NidsEngine::removeRule(uint32_t ruleId) {
    auto it = std::find_if(rules_.begin(), rules_.end(),
                           [ruleId](const DetectionRule& r) { return r.id == ruleId; });
    if (it == rules_.end()) return false;
    addEvent("Detection rule removed: " + it->name, AlertSeverity::INFO);
    rules_.erase(it);
    return true;
}

bool NidsEngine::enableRule(uint32_t ruleId) {
    for (auto& r : rules_) {
        if (r.id == ruleId) {
            r.enabled = true;
            return true;
        }
    }
    return false;
}

bool NidsEngine::disableRule(uint32_t ruleId) {
    for (auto& r : rules_) {
        if (r.id == ruleId) {
            r.enabled = false;
            return true;
        }
    }
    return false;
}

std::vector<DetectionRule> NidsEngine::getRules() const {
    return rules_;
}

DetectionRule NidsEngine::getRule(uint32_t ruleId) const {
    for (const auto& r : rules_) {
        if (r.id == ruleId) return r;
    }
    return DetectionRule{};
}

size_t NidsEngine::getRuleCount() const {
    return rules_.size();
}

size_t NidsEngine::getActiveRuleCount() const {
    size_t count = 0;
    for (const auto& r : rules_) {
        if (r.enabled) count++;
    }
    return count;
}

// ============================================================
// Connection Monitoring
// ============================================================

uint32_t NidsEngine::registerConnection(const NetworkConnection& conn) {
    NetworkConnection c = conn;
    c.id = nextConnectionId_++;
    c.timestamp = getCurrentTimeMs();
    connections_.push_back(c);
    trafficStats_.totalConnections++;
    trafficStats_.activeConnections++;
    return c.id;
}

bool NidsEngine::updateConnection(uint32_t connId, const NetworkConnection& conn) {
    for (auto& c : connections_) {
        if (c.id == connId) {
            c.packetCount = conn.packetCount;
            c.byteCount = conn.byteCount;
            c.state = conn.state;
            trafficStats_.totalPackets += conn.packetCount - c.packetCount;
            trafficStats_.totalBytes += conn.byteCount - c.byteCount;
            if (c.isInbound) {
                trafficStats_.inboundPackets += conn.packetCount - c.packetCount;
            } else {
                trafficStats_.outboundPackets += conn.packetCount - c.packetCount;
            }
            return true;
        }
    }
    return false;
}

bool NidsEngine::closeConnection(uint32_t connId) {
    for (auto& c : connections_) {
        if (c.id == connId) {
            c.state = ConnectionState::CLOSED;
            if (trafficStats_.activeConnections > 0) {
                trafficStats_.activeConnections--;
            }
            return true;
        }
    }
    return false;
}

std::vector<NetworkConnection> NidsEngine::getActiveConnections() const {
    std::vector<NetworkConnection> result;
    for (const auto& c : connections_) {
        if (c.state == ConnectionState::NEW || c.state == ConnectionState::ESTABLISHED) {
            result.push_back(c);
        }
    }
    return result;
}

std::vector<NetworkConnection> NidsEngine::getAllConnections() const {
    return connections_;
}

size_t NidsEngine::getActiveConnectionCount() const {
    size_t count = 0;
    for (const auto& c : connections_) {
        if (c.state == ConnectionState::NEW || c.state == ConnectionState::ESTABLISHED) {
            count++;
        }
    }
    return count;
}

size_t NidsEngine::getTotalConnectionCount() const {
    return connections_.size();
}

void NidsEngine::clearConnections() {
    connections_.clear();
    trafficStats_.activeConnections = 0;
}

// ============================================================
// Alert Management
// ============================================================

std::vector<SecurityAlert> NidsEngine::getAlerts() const {
    return alerts_;
}

std::vector<SecurityAlert> NidsEngine::getAlertsBySeverity(AlertSeverity severity) const {
    std::vector<SecurityAlert> result;
    for (const auto& a : alerts_) {
        if (a.severity == severity) result.push_back(a);
    }
    return result;
}

std::vector<SecurityAlert> NidsEngine::getUnacknowledgedAlerts() const {
    std::vector<SecurityAlert> result;
    for (const auto& a : alerts_) {
        if (!a.acknowledged) result.push_back(a);
    }
    return result;
}

bool NidsEngine::acknowledgeAlert(uint32_t alertId) {
    for (auto& a : alerts_) {
        if (a.id == alertId) {
            a.acknowledged = true;
            return true;
        }
    }
    return false;
}

bool NidsEngine::acknowledgeAllAlerts() {
    bool any = false;
    for (auto& a : alerts_) {
        if (!a.acknowledged) {
            a.acknowledged = true;
            any = true;
        }
    }
    return any;
}

void NidsEngine::clearAlerts() {
    alerts_.clear();
}

size_t NidsEngine::getAlertCount() const {
    return alerts_.size();
}

size_t NidsEngine::getUnacknowledgedAlertCount() const {
    size_t count = 0;
    for (const auto& a : alerts_) {
        if (!a.acknowledged) count++;
    }
    return count;
}

SecurityAlert NidsEngine::getAlert(uint32_t alertId) const {
    for (const auto& a : alerts_) {
        if (a.id == alertId) return a;
    }
    return SecurityAlert{};
}

// ============================================================
// Firewall Management
// ============================================================

uint32_t NidsEngine::blockIp(const std::string& ip, const std::string& portRange,
                             const std::string& description) {
    // Check if already blocked
    for (const auto& r : firewallRules_) {
        if (r.ip == ip && r.action == FirewallAction::BLOCK && r.active) {
            return r.id;  // Already blocked
        }
    }

    FirewallRule rule;
    rule.id = nextFirewallRuleId_++;
    rule.ip = ip;
    rule.portRange = portRange;
    rule.action = FirewallAction::BLOCK;
    rule.description = description;
    rule.timestamp = getCurrentTimeMs();
    firewallRules_.push_back(rule);

    // Block any matching active connections
    for (auto& c : connections_) {
        if (c.sourceIp == ip) {
            c.state = ConnectionState::BLOCKED;
            trafficStats_.blockedPackets += c.packetCount;
        }
    }

    addEvent("IP blocked: " + ip, AlertSeverity::HIGH, "FIREWALL");
    generateAlert(AlertType::FIREWALL_BLOCK, AlertSeverity::HIGH, ip,
                  "IP " + ip + " blocked by firewall", "FirewallManager");

    return rule.id;
}

bool NidsEngine::unblockIp(uint32_t ruleId) {
    auto it = std::find_if(firewallRules_.begin(), firewallRules_.end(),
                           [ruleId](const FirewallRule& r) { return r.id == ruleId; });
    if (it == firewallRules_.end()) return false;

    it->active = false;
    addEvent("IP unblocked: " + it->ip, AlertSeverity::INFO, "FIREWALL");
    generateAlert(AlertType::FIREWALL_UNBLOCK, AlertSeverity::INFO, it->ip,
                  "IP " + it->ip + " unblocked", "FirewallManager");
    return true;
}

bool NidsEngine::unblockIp(const std::string& ip) {
    bool found = false;
    for (auto& r : firewallRules_) {
        if (r.ip == ip && r.action == FirewallAction::BLOCK && r.active) {
            r.active = false;
            found = true;
        }
    }
    if (found) {
        addEvent("IP unblocked: " + ip, AlertSeverity::INFO, "FIREWALL");
        generateAlert(AlertType::FIREWALL_UNBLOCK, AlertSeverity::INFO, ip,
                      "IP " + ip + " unblocked", "FirewallManager");
    }
    return found;
}

std::vector<FirewallRule> NidsEngine::getFirewallRules() const {
    return firewallRules_;
}

std::vector<FirewallRule> NidsEngine::getActiveFirewallRules() const {
    std::vector<FirewallRule> result;
    for (const auto& r : firewallRules_) {
        if (r.active) result.push_back(r);
    }
    return result;
}

bool NidsEngine::isIpBlocked(const std::string& ip) const {
    for (const auto& r : firewallRules_) {
        if (r.ip == ip && r.action == FirewallAction::BLOCK && r.active) {
            return true;
        }
    }
    return false;
}

size_t NidsEngine::getFirewallRuleCount() const {
    return firewallRules_.size();
}

size_t NidsEngine::getActiveFirewallRuleCount() const {
    size_t count = 0;
    for (const auto& r : firewallRules_) {
        if (r.active) count++;
    }
    return count;
}

void NidsEngine::clearFirewallRules() {
    firewallRules_.clear();
}

// ============================================================
// Event Logging
// ============================================================

void NidsEngine::logEvent(const std::string& message, AlertSeverity severity,
                          const std::string& source) {
    addEvent(message, severity, source);
}

std::vector<SecurityEvent> NidsEngine::getEvents() const {
    return events_;
}

std::vector<SecurityEvent> NidsEngine::getEventsBySeverity(AlertSeverity severity) const {
    std::vector<SecurityEvent> result;
    for (const auto& e : events_) {
        if (e.severity == severity) result.push_back(e);
    }
    return result;
}

size_t NidsEngine::getEventCount() const {
    return events_.size();
}

void NidsEngine::clearEvents() {
    events_.clear();
}

// ============================================================
// Traffic Statistics
// ============================================================

TrafficStats NidsEngine::getTrafficStats() const {
    return trafficStats_;
}

void NidsEngine::resetTrafficStats() {
    trafficStats_ = TrafficStats{};
}

// ============================================================
// Detection Simulation
// ============================================================

void NidsEngine::simulatePortScan(const std::string& sourceIp, uint16_t startPort, uint16_t endPort) {
    uint16_t portCount = endPort - startPort + 1;
    for (uint16_t p = startPort; p <= endPort; ++p) {
        NetworkConnection conn;
        conn.sourceIp = sourceIp;
        conn.destIp = "192.168.1.1";
        conn.sourcePort = 50000 + p;
        conn.destPort = p;
        conn.protocol = 6;
        conn.state = ConnectionState::NEW;
        conn.isInbound = true;
        conn.packetCount = 1;
        conn.byteCount = 64;
        registerConnection(conn);
        trafficStats_.totalPackets++;
        trafficStats_.inboundPackets++;
    }

    // Check if this triggers a port scan alert
    for (const auto& rule : rules_) {
        if (rule.type == DetectionRuleType::PORT_SCAN && rule.enabled) {
            if (portCount >= rule.threshold) {
                generateAlert(AlertType::PORT_SCAN, rule.severity, sourceIp,
                              "Port scan detected from " + sourceIp + " (" +
                              std::to_string(portCount) + " ports scanned)",
                              rule.name);
            }
        }
    }
}

void NidsEngine::simulateDdosAttack(const std::string& targetIp, uint32_t sourceCount) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> ipPart(1, 254);

    for (uint32_t i = 0; i < sourceCount; ++i) {
        std::string srcIp = "10." + std::to_string(ipPart(gen)) + "." +
                           std::to_string(ipPart(gen)) + "." + std::to_string(ipPart(gen));
        NetworkConnection conn;
        conn.sourceIp = srcIp;
        conn.destIp = targetIp;
        conn.sourcePort = 50000 + i;
        conn.destPort = 80;
        conn.protocol = 6;
        conn.state = ConnectionState::NEW;
        conn.isInbound = true;
        conn.packetCount = 10;
        conn.byteCount = 640;
        registerConnection(conn);
        trafficStats_.totalPackets += 10;
        trafficStats_.inboundPackets += 10;
    }

    // Check DDoS rules
    for (const auto& rule : rules_) {
        if (rule.type == DetectionRuleType::DDOS && rule.enabled) {
            if (sourceCount >= rule.threshold) {
                generateAlert(AlertType::DDOS_ATTACK, rule.severity, "multiple",
                              "DDoS attack detected: " + std::to_string(sourceCount) +
                              " sources targeting " + targetIp,
                              rule.name);
            }
        }
    }
}

void NidsEngine::simulatePacketFlood(const std::string& sourceIp, uint64_t packetCount) {
    NetworkConnection conn;
    conn.sourceIp = sourceIp;
    conn.destIp = "192.168.1.1";
    conn.sourcePort = 12345;
    conn.destPort = 80;
    conn.protocol = 6;
    conn.state = ConnectionState::NEW;
    conn.isInbound = true;
    conn.packetCount = packetCount;
    conn.byteCount = packetCount * 64;
    registerConnection(conn);
    trafficStats_.totalPackets += packetCount;
    trafficStats_.inboundPackets += packetCount;

    // Check flood rules
    for (const auto& rule : rules_) {
        if (rule.type == DetectionRuleType::FLOOD && rule.enabled) {
            if (packetCount >= rule.threshold) {
                generateAlert(AlertType::PACKET_FLOOD, rule.severity, sourceIp,
                              "Packet flood detected from " + sourceIp + " (" +
                              std::to_string(packetCount) + " packets)",
                              rule.name);
            }
        }
    }
}

void NidsEngine::simulateUnauthorizedAccess(const std::string& sourceIp, uint16_t port) {
    for (int i = 0; i < 5; ++i) {
        NetworkConnection conn;
        conn.sourceIp = sourceIp;
        conn.destIp = "192.168.1.1";
        conn.sourcePort = 40000 + i;
        conn.destPort = port;
        conn.protocol = 6;
        conn.state = ConnectionState::CLOSED;
        conn.isInbound = true;
        conn.packetCount = 1;
        conn.byteCount = 64;
        registerConnection(conn);
        trafficStats_.totalPackets++;
        trafficStats_.inboundPackets++;
    }

    // Check unauthorized access rules
    for (const auto& rule : rules_) {
        if (rule.type == DetectionRuleType::UNAUTHORIZED && rule.enabled) {
            if (5 >= rule.threshold) {
                generateAlert(AlertType::UNAUTHORIZED_ACCESS, rule.severity, sourceIp,
                              "Unauthorized access attempt from " + sourceIp +
                              " on port " + std::to_string(port),
                              rule.name);
            }
        }
    }
}

void NidsEngine::simulateNormalTraffic(uint32_t connectionCount) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> ipPart(1, 254);
    std::uniform_int_distribution<> portDist(1024, 65535);
    std::uniform_int_distribution<> packetDist(1, 100);

    for (uint32_t i = 0; i < connectionCount; ++i) {
        std::string srcIp = "192.168.1." + std::to_string(ipPart(gen));
        NetworkConnection conn;
        conn.sourceIp = srcIp;
        conn.destIp = "192.168.1.1";
        conn.sourcePort = portDist(gen);
        conn.destPort = 80;
        conn.protocol = 6;
        conn.state = ConnectionState::ESTABLISHED;
        conn.isInbound = false;
        conn.packetCount = packetDist(gen);
        conn.byteCount = conn.packetCount * 128;
        registerConnection(conn);
        trafficStats_.totalPackets += conn.packetCount;
        trafficStats_.outboundPackets += conn.packetCount;
    }
}

// ============================================================
// Detection Engine
// ============================================================

void NidsEngine::runDetection() {
    if (!isMonitoring()) return;

    detectPortScans();
    detectDdos();
    detectFloods();
    detectUnauthorizedAccess();
    detectRateAnomalies();
}

void NidsEngine::detectPortScans() {
    // Group connections by source IP
    std::unordered_map<std::string, std::set<uint16_t>> ipPorts;
    for (const auto& c : connections_) {
        if (c.state != ConnectionState::BLOCKED) {
            ipPorts[c.sourceIp].insert(c.destPort);
        }
    }

    for (const auto& rule : rules_) {
        if (rule.type != DetectionRuleType::PORT_SCAN || !rule.enabled) continue;
        for (const auto& [ip, ports] : ipPorts) {
            if (ports.size() >= rule.threshold) {
                // Check if we already alerted for this IP
                bool alreadyAlerted = false;
                for (const auto& a : alerts_) {
                    if (a.type == AlertType::PORT_SCAN && a.sourceIp == ip) {
                        alreadyAlerted = true;
                        break;
                    }
                }
                if (!alreadyAlerted) {
                    generateAlert(AlertType::PORT_SCAN, rule.severity, ip,
                                  "Port scan detected from " + ip + " (" +
                                  std::to_string(ports.size()) + " ports)",
                                  rule.name);
                }
            }
        }
    }
}

void NidsEngine::detectDdos() {
    // Count unique source IPs targeting the same destination
    std::unordered_map<std::string, std::set<std::string>> destSources;
    for (const auto& c : connections_) {
        if (c.state != ConnectionState::BLOCKED) {
            destSources[c.destIp].insert(c.sourceIp);
        }
    }

    for (const auto& rule : rules_) {
        if (rule.type != DetectionRuleType::DDOS || !rule.enabled) continue;
        for (const auto& [dest, sources] : destSources) {
            if (sources.size() >= rule.threshold) {
                bool alreadyAlerted = false;
                for (const auto& a : alerts_) {
                    if (a.type == AlertType::DDOS_ATTACK && a.sourceIp == "multiple") {
                        alreadyAlerted = true;
                        break;
                    }
                }
                if (!alreadyAlerted) {
                    generateAlert(AlertType::DDOS_ATTACK, rule.severity, "multiple",
                                  "DDoS attack detected: " + std::to_string(sources.size()) +
                                  " sources targeting " + dest,
                                  rule.name);
                }
            }
        }
    }
}

void NidsEngine::detectFloods() {
    for (const auto& rule : rules_) {
        if (rule.type != DetectionRuleType::FLOOD || !rule.enabled) continue;
        for (const auto& c : connections_) {
            if (c.packetCount >= rule.threshold) {
                bool alreadyAlerted = false;
                for (const auto& a : alerts_) {
                    if (a.type == AlertType::PACKET_FLOOD && a.sourceIp == c.sourceIp) {
                        alreadyAlerted = true;
                        break;
                    }
                }
                if (!alreadyAlerted) {
                    generateAlert(AlertType::PACKET_FLOOD, rule.severity, c.sourceIp,
                                  "Packet flood from " + c.sourceIp + " (" +
                                  std::to_string(c.packetCount) + " packets)",
                                  rule.name, c.id);
                }
            }
        }
    }
}

void NidsEngine::detectUnauthorizedAccess() {
    // Count failed connection attempts per source IP
    std::unordered_map<std::string, int> failedAttempts;
    for (const auto& c : connections_) {
        if (c.state == ConnectionState::CLOSED) {
            failedAttempts[c.sourceIp]++;
        }
    }

    for (const auto& rule : rules_) {
        if (rule.type != DetectionRuleType::UNAUTHORIZED || !rule.enabled) continue;
        for (const auto& [ip, count] : failedAttempts) {
            if (count >= static_cast<int>(rule.threshold)) {
                bool alreadyAlerted = false;
                for (const auto& a : alerts_) {
                    if (a.type == AlertType::UNAUTHORIZED_ACCESS && a.sourceIp == ip) {
                        alreadyAlerted = true;
                        break;
                    }
                }
                if (!alreadyAlerted) {
                    generateAlert(AlertType::UNAUTHORIZED_ACCESS, rule.severity, ip,
                                  "Unauthorized access from " + ip + " (" +
                                  std::to_string(count) + " attempts)",
                                  rule.name);
                }
            }
        }
    }
}

void NidsEngine::detectRateAnomalies() {
    for (const auto& rule : rules_) {
        if (rule.type != DetectionRuleType::RATE_ANOMALY || !rule.enabled) continue;
        if (trafficStats_.totalPackets >= rule.threshold) {
            bool alreadyAlerted = false;
            for (const auto& a : alerts_) {
                if (a.type == AlertType::RATE_ANOMALY) {
                    alreadyAlerted = true;
                    break;
                }
            }
            if (!alreadyAlerted) {
                generateAlert(AlertType::RATE_ANOMALY, rule.severity, "system",
                              "Traffic rate anomaly: " + std::to_string(trafficStats_.totalPackets) +
                              " total packets",
                              rule.name);
            }
        }
    }
}

// ============================================================
// Private Helpers
// ============================================================

uint32_t NidsEngine::generateAlert(AlertType type, AlertSeverity severity,
                                   const std::string& sourceIp,
                                   const std::string& description,
                                   const std::string& ruleName,
                                   uint32_t connectionId) {
    SecurityAlert alert;
    alert.id = nextAlertId_++;
    alert.type = type;
    alert.severity = severity;
    alert.sourceIp = sourceIp;
    alert.description = description;
    alert.ruleName = ruleName;
    alert.timestamp = getCurrentTimeMs();
    alert.connectionId = connectionId;
    alerts_.push_back(alert);
    trafficStats_.alertsGenerated++;

    // Also log as event
    addEvent("Alert: " + alert.description, alert.severity, "DETECTION");

    if (alertCallback_) alertCallback_(alert);

    return alert.id;
}

void NidsEngine::addEvent(const std::string& message, AlertSeverity severity,
                          const std::string& source) {
    SecurityEvent event;
    event.id = nextEventId_++;
    event.message = message;
    event.severity = severity;
    event.timestamp = getCurrentTimeMs();
    event.source = source;
    events_.push_back(event);

    if (eventCallback_) eventCallback_(event);
}

bool NidsEngine::isPortInRange(uint16_t port, const std::string& range) const {
    // Parse "start-end" format
    size_t dash = range.find('-');
    if (dash == std::string::npos) return false;
    uint16_t start = static_cast<uint16_t>(std::stoi(range.substr(0, dash)));
    uint16_t end = static_cast<uint16_t>(std::stoi(range.substr(dash + 1)));
    return port >= start && port <= end;
}

uint64_t NidsEngine::getCurrentTimeMs() const {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

}  // namespace phantom::nids
