/*
 * Phantom OS - Location Manager Implementation
 * v0.28.0 - License: GPL-3.0
 */

#include "phantom/location/location_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <cmath>
#include <algorithm>

namespace phantom {
namespace location {

// ============================================================
// Private helpers
// ============================================================

static const double EARTH_RADIUS_METERS = 6371000.0;
static const double DEG_TO_RAD = 3.14159265358979323846 / 180.0;

static const char* kProviderNames[] = {
    "GPS", "NETWORK", "PASSIVE", "FUSED_STUB", "MOCK"
};

static const char* kProviderStateNames[] = {
    "DISABLED", "IDLE", "SEARCHING", "AVAILABLE", "TEMP_UNAVAILABLE", "FAILED"
};

static const char* kAccuracyNames[] = {
    "NONE", "COARSE_CITY", "COARSE_AREA", "APPROXIMATE", "PRECISE"
};

static const char* kPermissionNames[] = {
    "DENY", "ALLOW_FOREGROUND", "ALLOW_ALWAYS", "ALLOW_ONCE"
};

static const char* kRequestStateNames[] = {
    "ACTIVE", "PAUSED", "EXPIRED", "CANCELLED"
};

static const char* kTransitionNames[] = {
    "ENTER", "EXIT", "DWELL"
};

static const char* kResultNames[] = {
    "SUCCESS", "NOT_INITIALIZED", "ALREADY_INITIALIZED", "INVALID_PARAMETER",
    "PERMISSION_DENIED", "PROVIDER_DISABLED", "LOCATION_UNAVAILABLE",
    "REQUEST_NOT_FOUND", "GEOFENCE_NOT_FOUND", "CAPACITY_EXCEEDED",
    "MOCK_NOT_ALLOWED", "RATE_LIMITED", "BAD_STATE", "OPERATION_FAILED",
    "SIMULATED_FAILURE"
};

static const char* kEventTypeNames[] = {
    "PROVIDER_ENABLED", "PROVIDER_DISABLED", "LOCATION_UPDATED",
    "LOCATION_DELIVERED", "LOCATION_DENIED", "PERMISSION_CHANGED",
    "REQUEST_STARTED", "REQUEST_CANCELLED", "REQUEST_EXPIRED",
    "GEOFENCE_ADDED", "GEOFENCE_REMOVED", "GEOFENCE_ENTER",
    "GEOFENCE_EXIT", "GEOFENCE_DWELL", "MOCK_LOCATION_SET",
    "HISTORY_CLEARED", "PRIVACY_APPLIED"
};

static size_t providerIndex(LocationProvider p) {
    return static_cast<size_t>(p);
}

static bool validProviderIndex(LocationProvider p) {
    return static_cast<size_t>(p) < 5;
}

uint64_t LocationManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    // Deterministic fallback for testing
    static uint64_t simTime = 1000000;
    simTime += 1000;
    return simTime;
}

bool LocationManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "System";
}

void LocationManager::recordEvent(LocationEventType type, LocationResult result,
                                    const std::string& appId, LocationProvider provider,
                                    uint64_t requestId, uint64_t geofenceId,
                                    const std::string& detail) {
    if (events_.size() >= maxEvents_) {
        eventHistory_.push_back(events_.back());
        if (eventHistory_.size() > maxEvents_) eventHistory_.erase(eventHistory_.begin());
        events_.pop_back();
    }
    LocationEvent ev;
    ev.id = nextEventId_++;
    ev.timestamp = getCurrentTimeMs();
    ev.type = type;
    ev.result = result;
    ev.appId = appId;
    ev.provider = provider;
    ev.requestId = requestId;
    ev.geofenceId = geofenceId;
    ev.detail = detail;
    events_.insert(events_.begin(), std::move(ev));

    // Update stats
    size_t ti = static_cast<size_t>(type);
    if (ti < 17) stats_.byEventType[ti]++;
    size_t ri = static_cast<size_t>(result);
    if (ri < 15) stats_.byResult[ri]++;
}

void LocationManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        // Log only metadata, never raw coordinates
        if (level == "ERROR" || level == "FATAL") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "LocationManager");
        } else if (level == "WARN") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "LocationManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "LocationManager");
        }
    }
}

void LocationManager::notifyCrashReporter(const std::string& reason) const {
    if (crashReporter_) {
        crashReporter_->captureAnr("LocationManager", "LocationManager", 0, reason);
    }
}

double LocationManager::snapToGrid(double value, double grid) {
    if (grid <= 0.0) return value;
    return std::round(value / grid) * grid;
}

Location LocationManager::coarseLocation(const Location& loc, double gridDegrees) {
    Location result = loc;
    result.latitude = snapToGrid(loc.latitude, gridDegrees);
    result.longitude = snapToGrid(loc.longitude, gridDegrees);
    result.altitude = 0.0;
    result.speedMps = 0.0;
    result.accuracyMeters = std::max(loc.accuracyMeters, gridDegrees * 111000.0);
    return result;
}

Location LocationManager::applyPrivacyTransform(const Location& location,
                                                  LocationAccuracy accuracy,
                                                  uint32_t privacyFlags) {
    Location result = location;

    // Apply accuracy-based coarsening
    if (accuracy == LocationAccuracy::COARSE_CITY) {
        result = coarseLocation(result, 0.1);  // ~11km grid
    } else if (accuracy == LocationAccuracy::COARSE_AREA) {
        result = coarseLocation(result, 0.05);  // ~5km grid
    } else if (accuracy == LocationAccuracy::APPROXIMATE) {
        result = coarseLocation(result, LOCATION_APPROXIMATE_GRID_DEGREES);
    }
    // PRECISE and NONE: no transform

    // Apply privacy flags
    if (privacyFlags & LOCATION_PRIVACY_APPROXIMATE_ONLY) {
        result = coarseLocation(result, LOCATION_APPROXIMATE_GRID_DEGREES);
    }
    if (privacyFlags & LOCATION_PRIVACY_REDACT_ALTITUDE) {
        result.altitude = 0.0;
    }
    if (privacyFlags & LOCATION_PRIVACY_REDACT_SPEED) {
        result.speedMps = 0.0;
    }

    result.privacyFlags = privacyFlags;
    return result;
}

double LocationManager::distanceMeters(double lat1, double lon1,
                                          double lat2, double lon2) {
    // Equirectangular approximation — deterministic, good for short distances
    double lat1Rad = lat1 * DEG_TO_RAD;
    double lat2Rad = lat2 * DEG_TO_RAD;
    double lonDiff = (lon2 - lon1) * DEG_TO_RAD;
    double x = lonDiff * std::cos((lat1Rad + lat2Rad) / 2.0);
    double y = (lat2 - lat1) * DEG_TO_RAD;
    return std::sqrt(x * x + y * y) * EARTH_RADIUS_METERS;
}

// ============================================================
// Lifecycle
// ============================================================

LocationResult LocationManager::initialize(size_t maxHistory, size_t maxEvents,
                                              size_t maxRequests, size_t maxGeofences) {
    if (initialized_) return LocationResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxRequests == 0 || maxGeofences == 0)
        return LocationResult::INVALID_PARAMETER;

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxRequests_ = maxRequests;
    maxGeofences_ = maxGeofences;

    // Initialize providers
    for (size_t i = 0; i < 5; ++i) {
        providers_[i].provider = static_cast<LocationProvider>(i);
        providers_[i].state = LocationProviderState::DISABLED;
        providers_[i].enabled = false;
        providers_[i].lastFixAt = 0;
        providers_[i].accuracyMeters = 0.0;
        providers_[i].supportsAltitude = (i == 0 || i == 3);  // GPS, FUSED
        providers_[i].supportsSpeed = (i == 0 || i == 3);
    }

    // Enable GPS and NETWORK by default
    providers_[0].enabled = true;
    providers_[0].state = LocationProviderState::IDLE;
    providers_[1].enabled = true;
    providers_[1].state = LocationProviderState::IDLE;

    mockLocationEnabled_ = false;
    initialized_ = true;
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::shutdown() {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;

    appPolicies_.clear();
    requests_.clear();
    geofences_.clear();
    history_.clear();
    events_.clear();
    eventHistory_.clear();
    nextRequestId_ = 1;
    nextGeofenceId_ = 1;
    nextEventId_ = 1;
    // Reset providers
    for (size_t i = 0; i < 5; ++i) {
        providers_[i] = LocationProviderInfo{};
        providers_[i].provider = static_cast<LocationProvider>(i);
        providerLocations_[i] = Location{};
        mockLocations_[i] = Location{};
    }
    mockLocationEnabled_ = false;
    stats_ = LocationStats{};
    initialized_ = false;
    return LocationResult::SUCCESS;
}

// ============================================================
// Provider control
// ============================================================

LocationResult LocationManager::setProviderEnabled(LocationProvider provider, bool enabled,
                                                     const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;

    size_t idx = providerIndex(provider);
    if (providers_[idx].enabled == enabled) return LocationResult::SUCCESS;

    providers_[idx].enabled = enabled;
    if (enabled) {
        providers_[idx].state = LocationProviderState::IDLE;
        recordEvent(LocationEventType::PROVIDER_ENABLED, LocationResult::SUCCESS,
                     "", provider, 0, 0, kProviderNames[idx]);
    } else {
        providers_[idx].state = LocationProviderState::DISABLED;
        recordEvent(LocationEventType::PROVIDER_DISABLED, LocationResult::SUCCESS,
                     "", provider, 0, 0, kProviderNames[idx]);
    }

    logToServer("INFO", std::string("Provider ") + kProviderNames[idx] +
                (enabled ? " enabled" : " disabled"));
    return LocationResult::SUCCESS;
}

bool LocationManager::isProviderEnabled(LocationProvider provider) const {
    if (!validProviderIndex(provider)) return false;
    return providers_[providerIndex(provider)].enabled;
}

LocationProviderInfo LocationManager::getProviderInfo(LocationProvider provider) const {
    if (!validProviderIndex(provider)) return LocationProviderInfo{};
    return providers_[providerIndex(provider)];
}

std::vector<LocationProviderInfo> LocationManager::getProviders() const {
    std::vector<LocationProviderInfo> result;
    for (size_t i = 0; i < 5; ++i) {
        result.push_back(providers_[i]);
    }
    return result;
}

// ============================================================
// Permission / policy
// ============================================================

LocationResult LocationManager::setAppLocationPolicy(const std::string& appId,
                                                       LocationPermission permission,
                                                       LocationAccuracy accuracy,
                                                       uint32_t privacyFlags,
                                                       const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (appId.empty()) return LocationResult::INVALID_PARAMETER;
    if (static_cast<size_t>(permission) > 3) return LocationResult::INVALID_PARAMETER;
    if (static_cast<size_t>(accuracy) > 4) return LocationResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;

    LocationPolicy& policy = appPolicies_[appId];
    bool wasNew = (policy.appId.empty());
    policy.appId = appId;
    policy.permission = permission;
    policy.accuracy = accuracy;
    policy.privacyFlags = privacyFlags;
    if (permission != LocationPermission::DENY) {
        policy.lastGrantedAt = getCurrentTimeMs();
    }
    policy.oneShotUsed = false;
    policy.foreground = false;

    if (wasNew) {
        stats_.permissionsChanged++;
        if (privacyFlags != LOCATION_PRIVACY_NONE) stats_.privacyApplications++;
    } else {
        stats_.permissionsChanged++;
    }

    recordEvent(LocationEventType::PERMISSION_CHANGED, LocationResult::SUCCESS,
                 appId, LocationProvider::GPS, 0, 0,
                 kPermissionNames[static_cast<size_t>(permission)]);
    logToServer("INFO", std::string("Policy set for ") + appId +
                ": " + kPermissionNames[static_cast<size_t>(permission)]);
    return LocationResult::SUCCESS;
}

LocationPolicy LocationManager::getAppLocationPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) {
        LocationPolicy empty;
        empty.appId = appId;
        return empty;
    }
    return it->second;
}

LocationResult LocationManager::clearAppLocationPolicy(const std::string& appId,
                                                         const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return LocationResult::INVALID_PARAMETER;
    appPolicies_.erase(it);
    stats_.permissionsChanged++;
    recordEvent(LocationEventType::PERMISSION_CHANGED, LocationResult::SUCCESS,
                 appId, LocationProvider::GPS, 0, 0, "CLEARED");
    return LocationResult::SUCCESS;
}

bool LocationManager::checkAppAccess(const std::string& appId, LocationProvider provider) const {
    if (isSystemOwner(appId)) return true;
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const LocationPolicy& policy = it->second;
    if (policy.permission == LocationPermission::DENY) return false;
    if (policy.permission == LocationPermission::ALLOW_FOREGROUND && !policy.foreground)
        return false;
    if (policy.permission == LocationPermission::ALLOW_ONCE && policy.oneShotUsed)
        return false;

    if (!validProviderIndex(provider)) return false;
    if (!providers_[providerIndex(provider)].enabled) return false;

    return true;
}

LocationResult LocationManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (appId.empty()) return LocationResult::INVALID_PARAMETER;
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return LocationResult::INVALID_PARAMETER;
    it->second.foreground = foreground;
    return LocationResult::SUCCESS;
}

// ============================================================
// Location update
// ============================================================

LocationResult LocationManager::updateProviderLocation(LocationProvider provider,
                                                         const Location& location,
                                                         const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;

    size_t idx = providerIndex(provider);
    if (!providers_[idx].enabled) return LocationResult::PROVIDER_DISABLED;

    Location loc = location;
    loc.provider = provider;
    loc.timestamp = getCurrentTimeMs();
    loc.mock = mockLocationEnabled_;

    if (mockLocationEnabled_ && (mockLocations_[idx].latitude != 0.0 ||
                                  mockLocations_[idx].longitude != 0.0)) {
        loc = mockLocations_[idx];
        loc.provider = provider;
        loc.timestamp = getCurrentTimeMs();
        loc.mock = true;
    }

    providerLocations_[idx] = loc;
    providers_[idx].state = LocationProviderState::AVAILABLE;
    providers_[idx].lastFixAt = loc.timestamp;
    providers_[idx].accuracyMeters = loc.accuracyMeters;
    stats_.locationUpdates++;
    stats_.byProvider[idx]++;

    recordEvent(LocationEventType::LOCATION_UPDATED, LocationResult::SUCCESS,
                 "", provider, 0, 0, kProviderNames[idx]);

    // Add to history
    if (!(loc.privacyFlags & LOCATION_PRIVACY_NO_HISTORY)) {
        if (history_.size() >= maxHistory_) {
            history_.pop_back();
        }
        history_.insert(history_.begin(), loc);
    }

    // Deliver to active requests
    for (auto& req : requests_) {
        if (req.state != LocationRequestState::ACTIVE) continue;
        if (req.provider != provider) continue;

        // Distance filter
        if (req.minDistanceMeters > 0.0 && req.lastDeliveredAt > 0) {
            double dist = distanceMeters(req.lastRawLocation.latitude,
                                          req.lastRawLocation.longitude,
                                          loc.latitude, loc.longitude);
            if (dist < req.minDistanceMeters) continue;
        }

        // Interval filter
        if (req.minIntervalMs > 0 && req.lastDeliveredAt > 0) {
            if (loc.timestamp - req.lastDeliveredAt < req.minIntervalMs) continue;
        }

        deliverLocationToRequest(req, loc);
    }

    // Check geofences
    for (auto& fence : geofences_) {
        if (!fence.active) continue;
        checkGeofence(fence, loc);
    }

    if (locationCallback_) {
        locationCallback_(loc, "");
    }

    return LocationResult::SUCCESS;
}

LocationResult LocationManager::deliverLocationToRequest(LocationRequest& request,
                                                            const Location& location) {
    Location delivered = applyPrivacyTransform(location, request.desiredAccuracy,
                                                  getAppLocationPolicy(request.appId).privacyFlags);

    request.lastLocation = delivered;
    request.lastRawLocation = location;
    request.lastDeliveredAt = getCurrentTimeMs();
    stats_.deliveredUpdates++;

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(request.appId);
    if (it != appPolicies_.end() && it->second.permission == LocationPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    recordEvent(LocationEventType::LOCATION_DELIVERED, LocationResult::SUCCESS,
                 request.appId, request.provider, request.id, 0, "");
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::getLastKnownLocation(const std::string& appId,
                                                       LocationProvider provider,
                                                       Location& out) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId, provider)) {
        stats_.deniedRequests++;
        recordEvent(LocationEventType::LOCATION_DENIED, LocationResult::PERMISSION_DENIED,
                     appId, provider, 0, 0, "");
        if (accessCallback_) accessCallback_(appId, LocationResult::PERMISSION_DENIED);
        return LocationResult::PERMISSION_DENIED;
    }

    size_t idx = providerIndex(provider);
    if (providerLocations_[idx].timestamp == 0) {
        return LocationResult::LOCATION_UNAVAILABLE;
    }

    out = applyPrivacyTransform(providerLocations_[idx],
                                  getAppLocationPolicy(appId).accuracy,
                                  getAppLocationPolicy(appId).privacyFlags);
    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == LocationPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }
    stats_.deliveredUpdates++;
    recordEvent(LocationEventType::LOCATION_DELIVERED, LocationResult::SUCCESS,
                 appId, provider, 0, 0, "LAST_KNOWN");
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::requestSingleLocation(const std::string& appId,
                                                        LocationProvider provider,
                                                        LocationAccuracy accuracy,
                                                        uint64_t timeoutMs) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (appId.empty()) return LocationResult::INVALID_PARAMETER;
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId, provider)) {
        stats_.deniedRequests++;
        recordEvent(LocationEventType::LOCATION_DENIED, LocationResult::PERMISSION_DENIED,
                     appId, provider, 0, 0, "");
        if (accessCallback_) accessCallback_(appId, LocationResult::PERMISSION_DENIED);
        return LocationResult::PERMISSION_DENIED;
    }

    // Check if we have a recent location
    size_t idx = providerIndex(provider);
    if (providerLocations_[idx].timestamp > 0) {
        Location out = applyPrivacyTransform(providerLocations_[idx], accuracy,
                                               getAppLocationPolicy(appId).privacyFlags);
        // Consume ALLOW_ONCE
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == LocationPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
        stats_.deliveredUpdates++;
        recordEvent(LocationEventType::LOCATION_DELIVERED, LocationResult::SUCCESS,
                     appId, provider, 0, 0, "SINGLE");
        if (locationCallback_) locationCallback_(out, appId);
        return LocationResult::SUCCESS;
    }

    // No location available yet
    return LocationResult::LOCATION_UNAVAILABLE;
}

LocationResult LocationManager::startLocationUpdates(const std::string& appId,
                                                       LocationProvider provider,
                                                       LocationAccuracy accuracy,
                                                       uint64_t minIntervalMs,
                                                       double minDistanceMeters,
                                                       uint64_t timeoutMs,
                                                       uint64_t* outRequestId) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (appId.empty()) return LocationResult::INVALID_PARAMETER;
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;
    if (requests_.size() >= maxRequests_) return LocationResult::CAPACITY_EXCEEDED;

    if (!checkAppAccess(appId, provider)) {
        stats_.deniedRequests++;
        recordEvent(LocationEventType::LOCATION_DENIED, LocationResult::PERMISSION_DENIED,
                     appId, provider, 0, 0, "");
        if (accessCallback_) accessCallback_(appId, LocationResult::PERMISSION_DENIED);
        return LocationResult::PERMISSION_DENIED;
    }

    LocationRequest req;
    req.id = nextRequestId_++;
    req.appId = appId;
    req.provider = provider;
    req.desiredAccuracy = accuracy;
    req.minIntervalMs = minIntervalMs;
    req.minDistanceMeters = minDistanceMeters;
    req.createdAt = getCurrentTimeMs();
    req.expiresAt = (timeoutMs > 0) ? (req.createdAt + timeoutMs) :
                   (req.createdAt + LOCATION_DEFAULT_REQUEST_TIMEOUT_MS);
    req.state = LocationRequestState::ACTIVE;

    requests_.push_back(std::move(req));
    stats_.requestsStarted++;

    if (outRequestId) *outRequestId = requests_.back().id;

    recordEvent(LocationEventType::REQUEST_STARTED, LocationResult::SUCCESS,
                 appId, provider, requests_.back().id, 0, "");
    logToServer("INFO", std::string("Location updates started for ") + appId);
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::cancelLocationUpdates(uint64_t requestId,
                                                        const std::string& appId) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }

    for (auto& req : requests_) {
        if (req.id == requestId) {
            if (req.appId != appId && !isSystemOwner(appId))
                return LocationResult::PERMISSION_DENIED;
            if (req.state == LocationRequestState::CANCELLED)
                return LocationResult::BAD_STATE;
            req.state = LocationRequestState::CANCELLED;
            stats_.requestsCancelled++;
            recordEvent(LocationEventType::REQUEST_CANCELLED, LocationResult::SUCCESS,
                         appId, req.provider, requestId, 0, "");
            return LocationResult::SUCCESS;
        }
    }
    return LocationResult::REQUEST_NOT_FOUND;
}

LocationResult LocationManager::processLocationRequests() {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    uint64_t now = getCurrentTimeMs();
    for (auto& req : requests_) {
        if (req.state != LocationRequestState::ACTIVE) continue;
        if (req.expiresAt > 0 && now >= req.expiresAt) {
            req.state = LocationRequestState::EXPIRED;
            stats_.requestsExpired++;
            recordEvent(LocationEventType::REQUEST_EXPIRED, LocationResult::SUCCESS,
                         req.appId, req.provider, req.id, 0, "");
        }
    }
    return LocationResult::SUCCESS;
}

// ============================================================
// Geofencing
// ============================================================

LocationResult LocationManager::addGeofence(const std::string& appId,
                                              double latitude, double longitude,
                                              double radiusMeters,
                                              uint8_t transitions,
                                              uint64_t dwellMs,
                                              uint64_t* outGeofenceId) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }
    if (appId.empty()) return LocationResult::INVALID_PARAMETER;
    if (latitude < -90.0 || latitude > 90.0) return LocationResult::INVALID_PARAMETER;
    if (longitude < -180.0 || longitude > 180.0) return LocationResult::INVALID_PARAMETER;
    if (radiusMeters <= 0.0) return LocationResult::INVALID_PARAMETER;
    if (transitions == 0) return LocationResult::INVALID_PARAMETER;
    if (geofences_.size() >= maxGeofences_) return LocationResult::CAPACITY_EXCEEDED;

    Geofence fence;
    fence.id = nextGeofenceId_++;
    fence.appId = appId;
    fence.latitude = latitude;
    fence.longitude = longitude;
    fence.radiusMeters = radiusMeters;
    fence.transitions = transitions;
    fence.dwellMs = dwellMs;
    fence.active = true;
    fence.inside = false;
    fence.createdAt = getCurrentTimeMs();
    fence.lastTransitionAt = 0;
    fence.enteredAt = 0;

    geofences_.push_back(std::move(fence));
    stats_.geofencesAdded++;

    if (outGeofenceId) *outGeofenceId = geofences_.back().id;

    recordEvent(LocationEventType::GEOFENCE_ADDED, LocationResult::SUCCESS,
                 appId, LocationProvider::GPS, 0, geofences_.back().id, "");
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::removeGeofence(uint64_t geofenceId,
                                                 const std::string& appId) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (failNextOperation_) {
        failNextOperation_ = false;
        return LocationResult::SIMULATED_FAILURE;
    }

    for (auto it = geofences_.begin(); it != geofences_.end(); ++it) {
        if (it->id == geofenceId) {
            if (it->appId != appId && !isSystemOwner(appId))
                return LocationResult::PERMISSION_DENIED;
            geofences_.erase(it);
            stats_.geofencesRemoved++;
            recordEvent(LocationEventType::GEOFENCE_REMOVED, LocationResult::SUCCESS,
                         appId, LocationProvider::GPS, 0, geofenceId, "");
            return LocationResult::SUCCESS;
        }
    }
    return LocationResult::GEOFENCE_NOT_FOUND;
}

LocationResult LocationManager::getGeofence(uint64_t geofenceId, Geofence& out) const {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    for (const auto& fence : geofences_) {
        if (fence.id == geofenceId) {
            out = fence;
            return LocationResult::SUCCESS;
        }
    }
    return LocationResult::GEOFENCE_NOT_FOUND;
}

std::vector<Geofence> LocationManager::getGeofencesForApp(const std::string& appId) const {
    std::vector<Geofence> result;
    if (!initialized_) return result;
    bool isSystem = isSystemOwner(appId);
    for (const auto& fence : geofences_) {
        if (isSystem || fence.appId == appId) {
            result.push_back(fence);
        }
    }
    return result;
}

void LocationManager::checkGeofence(Geofence& fence, const Location& location) {
    double dist = distanceMeters(location.latitude, location.longitude,
                                   fence.latitude, fence.longitude);
    bool wasInside = fence.inside;
    bool isInside = (dist <= fence.radiusMeters);

    if (!wasInside && isInside) {
        // ENTER transition
        if (fence.transitions & static_cast<uint8_t>(1)) {
            fence.inside = true;
            fence.enteredAt = location.timestamp;
            fence.lastTransitionAt = location.timestamp;
            stats_.geofenceTransitions++;
            recordEvent(LocationEventType::GEOFENCE_ENTER, LocationResult::SUCCESS,
                         fence.appId, LocationProvider::GPS, 0, fence.id, "");
        }
    } else if (wasInside && !isInside) {
        // EXIT transition
        if (fence.transitions & static_cast<uint8_t>(2)) {
            fence.inside = false;
            fence.lastTransitionAt = location.timestamp;
            fence.enteredAt = 0;
            stats_.geofenceTransitions++;
            recordEvent(LocationEventType::GEOFENCE_EXIT, LocationResult::SUCCESS,
                         fence.appId, LocationProvider::GPS, 0, fence.id, "");
        }
    } else if (wasInside && isInside && fence.dwellMs > 0 && fence.enteredAt > 0) {
        // DWELL transition
        if (fence.transitions & static_cast<uint8_t>(4)) {
            if (location.timestamp - fence.enteredAt >= fence.dwellMs) {
                fence.lastTransitionAt = location.timestamp;
                stats_.geofenceTransitions++;
                recordEvent(LocationEventType::GEOFENCE_DWELL, LocationResult::SUCCESS,
                             fence.appId, LocationProvider::GPS, 0, fence.id, "");
                // Reset enteredAt to avoid repeated dwell events
                fence.enteredAt = location.timestamp;
            }
        }
    }
}

LocationResult LocationManager::processGeofences() {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    // Check all geofences against all provider locations
    for (auto& fence : geofences_) {
        if (!fence.active) continue;
        for (size_t i = 0; i < 5; ++i) {
            if (providers_[i].enabled && providerLocations_[i].timestamp > 0) {
                checkGeofence(fence, providerLocations_[i]);
            }
        }
    }
    return LocationResult::SUCCESS;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<Location> LocationManager::getHistory(const std::string& appId,
                                                     size_t limit,
                                                     bool includeMock) const {
    std::vector<Location> result;
    if (!initialized_) return result;
    bool isSystem = isSystemOwner(appId);
    for (const auto& loc : history_) {
        if (!includeMock && loc.mock) continue;
        // System can see all; apps only see their own (simplified: all non-system see all
        // since we don't tag history entries per-app in this version)
        if (isSystem || true) {
            result.push_back(loc);
        }
    }
    if (limit > 0 && result.size() > limit) {
        result.resize(limit);
    }
    return result;
}

LocationResult LocationManager::clearHistory(const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;
    history_.clear();
    stats_.historyClears++;
    recordEvent(LocationEventType::HISTORY_CLEARED, LocationResult::SUCCESS,
                 "", LocationProvider::GPS, 0, 0, "");
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::clearAppHistory(const std::string& appId,
                                                  const std::string& requester) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (appId != requester && !isSystemOwner(requester))
        return LocationResult::PERMISSION_DENIED;
    // In this version, history is not per-app tagged, so clear all
    history_.clear();
    stats_.historyClears++;
    recordEvent(LocationEventType::HISTORY_CLEARED, LocationResult::SUCCESS,
                 appId, LocationProvider::GPS, 0, 0, "");
    return LocationResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

LocationResult LocationManager::setMockLocationEnabled(bool enabled,
                                                         const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;
    mockLocationEnabled_ = enabled;
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::setMockLocation(LocationProvider provider,
                                                  const Location& location,
                                                  const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;
    if (!mockLocationEnabled_) return LocationResult::MOCK_NOT_ALLOWED;

    size_t idx = providerIndex(provider);
    mockLocations_[idx] = location;
    mockLocations_[idx].provider = provider;
    mockLocations_[idx].mock = true;
    stats_.mockLocationsSet++;

    recordEvent(LocationEventType::MOCK_LOCATION_SET, LocationResult::SUCCESS,
                 "", provider, 0, 0, kProviderNames[idx]);
    return LocationResult::SUCCESS;
}

LocationResult LocationManager::clearMockLocation(LocationProvider provider,
                                                    const std::string& owner) {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    if (!validProviderIndex(provider)) return LocationResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return LocationResult::PERMISSION_DENIED;
    if (!mockLocationEnabled_) return LocationResult::MOCK_NOT_ALLOWED;

    size_t idx = providerIndex(provider);
    mockLocations_[idx] = Location{};
    return LocationResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<LocationEvent> LocationManager::getEvents(size_t limit) const {
    std::vector<LocationEvent> result;
    if (!initialized_) return result;
    for (const auto& ev : events_) {
        result.push_back(ev);
        if (limit > 0 && result.size() >= limit) break;
    }
    return result;
}

std::vector<LocationEvent> LocationManager::getEventsByType(LocationEventType type) const {
    std::vector<LocationEvent> result;
    if (!initialized_) return result;
    for (const auto& ev : events_) {
        if (ev.type == type) result.push_back(ev);
    }
    return result;
}

LocationResult LocationManager::clearEvents() {
    if (!initialized_) return LocationResult::NOT_INITIALIZED;
    for (const auto& ev : events_) {
        eventHistory_.push_back(ev);
        if (eventHistory_.size() > maxEvents_) eventHistory_.erase(eventHistory_.begin());
    }
    events_.clear();
    return LocationResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void LocationManager::resetStats() {
    stats_ = LocationStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* LocationManager::locationProviderToString(LocationProvider provider) {
    size_t idx = static_cast<size_t>(provider);
    if (idx < 5) return kProviderNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::providerStateToString(LocationProviderState state) {
    size_t idx = static_cast<size_t>(state);
    if (idx < 6) return kProviderStateNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::locationAccuracyToString(LocationAccuracy accuracy) {
    size_t idx = static_cast<size_t>(accuracy);
    if (idx < 5) return kAccuracyNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::locationPermissionToString(LocationPermission permission) {
    size_t idx = static_cast<size_t>(permission);
    if (idx < 4) return kPermissionNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::requestStateToString(LocationRequestState state) {
    size_t idx = static_cast<size_t>(state);
    if (idx < 4) return kRequestStateNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::geofenceTransitionToString(GeofenceTransition transition) {
    size_t idx = static_cast<size_t>(transition);
    if (idx < 3) return kTransitionNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::locationResultToString(LocationResult result) {
    size_t idx = static_cast<size_t>(result);
    if (idx < 15) return kResultNames[idx];
    return "UNKNOWN";
}

const char* LocationManager::locationEventTypeToString(LocationEventType type) {
    size_t idx = static_cast<size_t>(type);
    if (idx < 17) return kEventTypeNames[idx];
    return "UNKNOWN";
}

LocationProvider LocationManager::stringToLocationProvider(const std::string& str) {
    for (size_t i = 0; i < 5; ++i) {
        if (str == kProviderNames[i]) return static_cast<LocationProvider>(i);
    }
    return LocationProvider::GPS;
}

LocationResult LocationManager::stringToLocationResult(const std::string& str) {
    for (size_t i = 0; i < 15; ++i) {
        if (str == kResultNames[i]) return static_cast<LocationResult>(i);
    }
    return LocationResult::SUCCESS;
}

}  // namespace location
}  // namespace phantom
