/*
 * Phantom OS - Location Manager
 * v0.28.0 - License: GPL-3.0
 *
 * Privacy-first location service: provider management (GPS, NETWORK,
 * PASSIVE, FUSED_STUB, MOCK), per-app location access control with
 * foreground-only and approximate-location enforcement, location
 * requests with interval/distance filtering, geofencing with
 * enter/exit/dwell transitions, mock location for testing, location
 * history with per-app isolation and privacy redaction, events, stats,
 * callbacks and optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Location coordinates are
 * deterministic mock values, not real GPS fixes. Approximate/coarse
 * transforms are deterministic (grid-snapping), not random.
 */

#ifndef PHANTOM_LOCATION_LOCATION_MANAGER_H
#define PHANTOM_LOCATION_LOCATION_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace location {

// ============================================================
// Constants
// ============================================================

static const uint32_t LOCATION_PRIVACY_NONE = 0;
static const uint32_t LOCATION_PRIVACY_APPROXIMATE_ONLY = 1 << 0;
static const uint32_t LOCATION_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t LOCATION_PRIVACY_REDACT_ALTITUDE = 1 << 2;
static const uint32_t LOCATION_PRIVACY_REDACT_SPEED = 1 << 3;
static const uint32_t LOCATION_PRIVACY_REQUIRE_FOREGROUND = 1 << 4;
static const uint32_t LOCATION_PRIVACY_MOCK_LOCATION = 1 << 5;

static const uint64_t LOCATION_DEFAULT_REQUEST_TIMEOUT_MS = 60000;
static const double LOCATION_APPROXIMATE_GRID_DEGREES = 0.05;  // ~5km grid

// ============================================================
// Enums
// ============================================================

enum class LocationProvider : uint8_t {
    GPS = 0,
    NETWORK,
    PASSIVE,
    FUSED_STUB,
    MOCK
};

enum class LocationProviderState : uint8_t {
    DISABLED = 0,
    IDLE,
    SEARCHING,
    AVAILABLE,
    TEMP_UNAVAILABLE,
    FAILED
};

enum class LocationAccuracy : uint8_t {
    NONE = 0,
    COARSE_CITY,
    COARSE_AREA,
    APPROXIMATE,
    PRECISE
};

enum class LocationPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class LocationRequestState : uint8_t {
    ACTIVE = 0,
    PAUSED,
    EXPIRED,
    CANCELLED
};

enum class GeofenceTransition : uint8_t {
    ENTER = 0,
    EXIT,
    DWELL
};

enum class LocationResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    PROVIDER_DISABLED,
    LOCATION_UNAVAILABLE,
    REQUEST_NOT_FOUND,
    GEOFENCE_NOT_FOUND,
    CAPACITY_EXCEEDED,
    MOCK_NOT_ALLOWED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class LocationEventType : uint8_t {
    PROVIDER_ENABLED = 0,
    PROVIDER_DISABLED,
    LOCATION_UPDATED,
    LOCATION_DELIVERED,
    LOCATION_DENIED,
    PERMISSION_CHANGED,
    REQUEST_STARTED,
    REQUEST_CANCELLED,
    REQUEST_EXPIRED,
    GEOFENCE_ADDED,
    GEOFENCE_REMOVED,
    GEOFENCE_ENTER,
    GEOFENCE_EXIT,
    GEOFENCE_DWELL,
    MOCK_LOCATION_SET,
    HISTORY_CLEARED,
    PRIVACY_APPLIED
};

// ============================================================
// Data structures
// ============================================================

struct Location {
    double latitude = 0.0;
    double longitude = 0.0;
    double altitude = 0.0;
    double accuracyMeters = 0.0;
    double speedMps = 0.0;
    double bearingDegrees = 0.0;
    LocationProvider provider = LocationProvider::GPS;
    uint64_t timestamp = 0;
    uint32_t privacyFlags = LOCATION_PRIVACY_NONE;
    bool mock = false;
};

struct LocationProviderInfo {
    LocationProvider provider = LocationProvider::GPS;
    LocationProviderState state = LocationProviderState::DISABLED;
    bool enabled = false;
    uint64_t lastFixAt = 0;
    double accuracyMeters = 0.0;
    bool supportsAltitude = false;
    bool supportsSpeed = false;
};

struct LocationPolicy {
    std::string appId;
    LocationPermission permission = LocationPermission::DENY;
    LocationAccuracy accuracy = LocationAccuracy::NONE;
    uint32_t privacyFlags = LOCATION_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
};

struct LocationRequest {
    uint64_t id = 0;
    std::string appId;
    LocationProvider provider = LocationProvider::GPS;
    LocationAccuracy desiredAccuracy = LocationAccuracy::PRECISE;
    uint64_t minIntervalMs = 0;
    double minDistanceMeters = 0.0;
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;
    uint64_t lastDeliveredAt = 0;
    Location lastLocation;        // Privacy-transformed last delivered
    Location lastRawLocation;     // Raw last delivered for distance filter
    LocationRequestState state = LocationRequestState::ACTIVE;
};

struct Geofence {
    uint64_t id = 0;
    std::string appId;
    double latitude = 0.0;
    double longitude = 0.0;
    double radiusMeters = 0.0;
    uint8_t transitions = 0;  // Bitmask of GeofenceTransition
    uint64_t dwellMs = 0;
    bool active = true;
    bool inside = false;
    uint64_t createdAt = 0;
    uint64_t lastTransitionAt = 0;
    uint64_t enteredAt = 0;  // For dwell detection
};

struct LocationEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    LocationEventType type = LocationEventType::LOCATION_UPDATED;
    LocationResult result = LocationResult::SUCCESS;
    std::string appId;
    LocationProvider provider = LocationProvider::GPS;
    uint64_t requestId = 0;
    uint64_t geofenceId = 0;
    std::string detail;  // Metadata only — never raw coordinates
};

struct LocationStats {
    uint64_t locationUpdates = 0;
    uint64_t deliveredUpdates = 0;
    uint64_t deniedRequests = 0;
    uint64_t permissionsChanged = 0;
    uint64_t requestsStarted = 0;
    uint64_t requestsCancelled = 0;
    uint64_t requestsExpired = 0;
    uint64_t geofencesAdded = 0;
    uint64_t geofencesRemoved = 0;
    uint64_t geofenceTransitions = 0;
    uint64_t mockLocationsSet = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t byProvider[5] = {0, 0, 0, 0, 0};
    uint64_t byEventType[17] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Location Manager
// ============================================================

class LocationManager {
public:
    LocationManager() = default;
    ~LocationManager() = default;

    LocationManager(const LocationManager&) = delete;
    LocationManager& operator=(const LocationManager&) = delete;

    // ---- Lifecycle ----
    LocationResult initialize(size_t maxHistory = 128, size_t maxEvents = 256,
                               size_t maxRequests = 64, size_t maxGeofences = 32);
    LocationResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Provider control ----
    LocationResult setProviderEnabled(LocationProvider provider, bool enabled,
                                       const std::string& owner = "system");
    bool isProviderEnabled(LocationProvider provider) const;
    LocationProviderInfo getProviderInfo(LocationProvider provider) const;
    std::vector<LocationProviderInfo> getProviders() const;

    // ---- Permission / policy ----
    LocationResult setAppLocationPolicy(const std::string& appId,
                                         LocationPermission permission,
                                         LocationAccuracy accuracy,
                                         uint32_t privacyFlags = LOCATION_PRIVACY_NONE,
                                         const std::string& owner = "system");
    LocationPolicy getAppLocationPolicy(const std::string& appId) const;
    LocationResult clearAppLocationPolicy(const std::string& appId,
                                           const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId, LocationProvider provider) const;
    LocationResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Location update ----
    LocationResult updateProviderLocation(LocationProvider provider,
                                           const Location& location,
                                           const std::string& owner = "system");
    LocationResult getLastKnownLocation(const std::string& appId,
                                         LocationProvider provider,
                                         Location& out);
    LocationResult requestSingleLocation(const std::string& appId,
                                           LocationProvider provider,
                                           LocationAccuracy accuracy,
                                           uint64_t timeoutMs = 0);
    LocationResult startLocationUpdates(const std::string& appId,
                                          LocationProvider provider,
                                          LocationAccuracy accuracy,
                                          uint64_t minIntervalMs,
                                          double minDistanceMeters,
                                          uint64_t timeoutMs = 0,
                                          uint64_t* outRequestId = nullptr);
    LocationResult cancelLocationUpdates(uint64_t requestId,
                                           const std::string& appId);
    LocationResult processLocationRequests();

    // ---- Geofencing ----
    LocationResult addGeofence(const std::string& appId,
                                 double latitude, double longitude,
                                 double radiusMeters,
                                 uint8_t transitions,
                                 uint64_t dwellMs = 0,
                                 uint64_t* outGeofenceId = nullptr);
    LocationResult removeGeofence(uint64_t geofenceId,
                                    const std::string& appId);
    LocationResult getGeofence(uint64_t geofenceId, Geofence& out) const;
    std::vector<Geofence> getGeofencesForApp(const std::string& appId) const;
    LocationResult processGeofences();

    // ---- History / privacy ----
    std::vector<Location> getHistory(const std::string& appId,
                                      size_t limit = 0,
                                      bool includeMock = false) const;
    LocationResult clearHistory(const std::string& owner = "system");
    LocationResult clearAppHistory(const std::string& appId,
                                    const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    LocationResult setMockLocationEnabled(bool enabled,
                                            const std::string& owner = "system");
    LocationResult setMockLocation(LocationProvider provider,
                                     const Location& location,
                                     const std::string& owner = "system");
    LocationResult clearMockLocation(LocationProvider provider,
                                       const std::string& owner = "system");
    bool isMockLocationEnabled() const { return mockLocationEnabled_; }

    // ---- Events ----
    std::vector<LocationEvent> getEvents(size_t limit = 0) const;
    std::vector<LocationEvent> getEventsByType(LocationEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    LocationResult clearEvents();

    // ---- Stats ----
    LocationStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setLocationCallback(std::function<void(const Location&, const std::string&)> cb) {
        locationCallback_ = cb;
    }
    void setAccessCallback(std::function<void(const std::string&, LocationResult)> cb) {
        accessCallback_ = cb;
    }
    void setEventCallback(std::function<void(const LocationEvent&)> cb) { eventCallback_ = cb; }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* locationProviderToString(LocationProvider provider);
    static const char* providerStateToString(LocationProviderState state);
    static const char* locationAccuracyToString(LocationAccuracy accuracy);
    static const char* locationPermissionToString(LocationPermission permission);
    static const char* requestStateToString(LocationRequestState state);
    static const char* geofenceTransitionToString(GeofenceTransition transition);
    static const char* locationResultToString(LocationResult result);
    static const char* locationEventTypeToString(LocationEventType type);
    static LocationProvider stringToLocationProvider(const std::string& str);
    static LocationResult stringToLocationResult(const std::string& str);

    // ---- Privacy helpers ----
    static Location applyPrivacyTransform(const Location& location,
                                            LocationAccuracy accuracy,
                                            uint32_t privacyFlags);
    static double distanceMeters(double lat1, double lon1,
                                   double lat2, double lon2);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(LocationEventType type, LocationResult result,
                     const std::string& appId, LocationProvider provider,
                     uint64_t requestId, uint64_t geofenceId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    LocationResult deliverLocationToRequest(LocationRequest& request,
                                              const Location& location);
    void checkGeofence(Geofence& fence, const Location& location);
    static double snapToGrid(double value, double grid);
    static Location coarseLocation(const Location& loc, double gridDegrees);

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;
    size_t maxRequests_ = 64;
    size_t maxGeofences_ = 32;

    LocationProviderInfo providers_[5];
    Location providerLocations_[5];

    std::map<std::string, LocationPolicy> appPolicies_;

    std::vector<LocationRequest> requests_;
    uint64_t nextRequestId_ = 1;

    std::vector<Geofence> geofences_;
    uint64_t nextGeofenceId_ = 1;

    std::vector<Location> history_;   // Newest first, per-app tagged
    std::vector<LocationEvent> events_;
    std::vector<LocationEvent> eventHistory_;
    uint64_t nextEventId_ = 1;

    bool mockLocationEnabled_ = false;
    Location mockLocations_[5];

    LocationStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const Location&, const std::string&)> locationCallback_;
    std::function<void(const std::string&, LocationResult)> accessCallback_;
    std::function<void(const LocationEvent&)> eventCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace location
}  // namespace phantom

#endif  // PHANTOM_LOCATION_LOCATION_MANAGER_H
