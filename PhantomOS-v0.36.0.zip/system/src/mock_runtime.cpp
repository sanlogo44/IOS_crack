/*
 * Phantom OS - Mock Runtime
 * Demonstrates the Phantom OS framework, privacy layer, and HAL working together
 *
 * License: GPL-3.0
 */

#include "phantom/service_manager.h"
#include "phantom/service.h"
#include "phantom/privacy/permission_manager.h"
#include "phantom/privacy/identity_manager.h"
#include "phantom/privacy/data_sanitizer.h"
#include "phantom/hal/hal_interfaces.h"
#include "mock_hal_factory.h"
#include <cstdio>
#include <memory>
#include <vector>
#include <string>

using namespace phantom;

// ============================================================
// Phantom System Service (wraps HAL + Privacy)
// ============================================================
class PhantomSystemService : public framework::IService {
private:
    std::string name_;
    hal::IHalFactory* hal_factory_ = nullptr;
    hal::IDisplayHal* display_ = nullptr;
    hal::IStorageHal* storage_ = nullptr;
    hal::IPowerHal* power_ = nullptr;

public:
    PhantomSystemService() : name_("PhantomSystemService") {}

    const char* getName() const override { return name_.c_str(); }
    const char* getDescription() const override { return "Core Phantom OS system service"; }
    framework::ServiceState getState() const override {
        return display_ ? framework::ServiceState::RUNNING : framework::ServiceState::CREATED;
    }
    framework::ServicePriority getPriority() const override {
        return framework::ServicePriority::CRITICAL;
    }

    bool onStart() override {
        // Create HAL factory
        hal_factory_ = hal::createMockHalFactory();
        if (!hal_factory_) return false;

        // Initialize display
        hal_factory_->createDisplay(&display_);
        if (display_) display_->init();

        // Initialize storage
        hal_factory_->createStorage(&storage_);
        if (storage_) storage_->init();

        // Initialize power
        hal_factory_->createPower(&power_);
        if (power_) power_->init();

        return true;
    }

    bool onStop() override {
        if (display_) { display_->deinit(); hal_factory_->destroyDisplay(display_); display_ = nullptr; }
        if (storage_) { storage_->deinit(); hal_factory_->destroyStorage(storage_); storage_ = nullptr; }
        if (power_) { power_->deinit(); hal_factory_->destroyPower(power_); power_ = nullptr; }
        delete hal_factory_;
        hal_factory_ = nullptr;
        return true;
    }

    bool isHealthy() const override {
        return display_ != nullptr && storage_ != nullptr && power_ != nullptr;
    }

    // Get display info
    void printDisplayInfo() {
        if (!display_) { printf("Display not initialized\n"); return; }
        hal::DisplayInfo info;
        if (display_->getInfo(&info) == hal::HalResult::SUCCESS) {
            printf("  Display: %dx%d @ %dHz, %d DPI, %s\n",
                   info.resolution.width, info.resolution.height,
                   info.resolution.refresh_rate_hz, info.resolution.dpi,
                   info.panel_type);
        }
    }

    // Get battery info
    void printBatteryInfo() {
        if (!power_) { printf("Power not initialized\n"); return; }
        hal::BatteryInfo battery;
        if (power_->getBatteryInfo(&battery) == hal::HalResult::SUCCESS) {
            printf("  Battery: %d%%, %s, %d mV, %.1f°C\n",
                   battery.level,
                   battery.is_charging ? "charging" : "not charging",
                   battery.voltage_mv,
                   battery.temperature_dc / 10.0f);
        }
    }
};

// ============================================================
// Privacy Audit Service
// ============================================================
class PrivacyAuditService : public framework::IService {
public:
    const char* getName() const override { return "PrivacyAuditService"; }
    const char* getDescription() const override { return "Privacy audit and reporting service"; }
    framework::ServiceState getState() const override { return framework::ServiceState::RUNNING; }
    framework::ServicePriority getPriority() const override { return framework::ServicePriority::HIGH; }

    bool onStart() override { return true; }
    bool onStop() override { return true; }
    bool isHealthy() const override { return true; }

    void runAudit() {
        auto& pm = privacy::PermissionManager::getInstance();
        auto& im = privacy::IdentityManager::getInstance();

        printf("\n");
        printf("┌──────────────────────────────────┐\n");
        printf("│         PRIVACY CENTER           │\n");
        printf("├──────────────────────────────────┤\n");

        // Show registered apps
        auto apps = pm.getRegisteredApps();
        printf("│ Registered apps: %-16d│\n", static_cast<int>(apps.size()));

        // Show privacy profile
        auto profile = pm.getPrivacyProfile();
        const char* profile_str = "Normal";
        if (profile == privacy::PrivacyProfile::PRIVACY) profile_str = "Privacy";
        else if (profile == privacy::PrivacyProfile::MAXIMUM_PRIVACY) profile_str = "Max Privacy";
        else if (profile == privacy::PrivacyProfile::DEVELOPER) profile_str = "Developer";
        else if (profile == privacy::PrivacyProfile::CUSTOM) profile_str = "Custom";
        printf("│ Privacy profile: %-15s│\n", profile_str);

        // Show protected hardware IDs
        printf("│ Hardware IDs: PROTECTED          │\n");
        printf("│ Telemetry: OFF                   │\n");
        printf("│ Analytics: OFF                   │\n");
        printf("│ Tracking: OFF                    │\n");

        // Show recent access log
        auto log = pm.getAccessLog();
        printf("├──────────────────────────────────┤\n");
        printf("│ Recent Access (%d entries)        │\n", static_cast<int>(log.size()));
        for (const auto& entry : log) {
            printf("│  %s → %-12s          │\n",
                   entry.app_id.c_str(),
                   privacy::permissionToString(entry.permission));
        }
        printf("└──────────────────────────────────┘\n");
    }
};

// ============================================================
// Main - Mock Runtime
// ============================================================
int main() {
    printf("╔══════════════════════════════════════════════╗\n");
    printf("║       Phantom OS v0.2.0 — Mock Runtime       ║\n");
    printf("║       Framework + Privacy + HAL Prototype     ║\n");
    printf("╚══════════════════════════════════════════════╝\n\n");

    // 1. Initialize Service Manager
    auto& sm = framework::ServiceManager::getInstance();
    printf("[1/5] Initializing Service Manager...\n");

    auto system_service = std::make_unique<PhantomSystemService>();
    auto privacy_service = std::make_unique<PrivacyAuditService>();

    sm.registerService(std::move(system_service));
    sm.registerService(std::move(privacy_service));

    // 2. Start all services
    printf("[2/5] Starting all services...\n");
    sm.startAll();

    auto running = sm.getRunningServices();
    printf("  Running services: %d\n", static_cast<int>(running.size()));
    for (const auto& name : running) {
        printf("    ✓ %s\n", name.c_str());
    }

    // 3. Display hardware info
    printf("\n[3/5] Hardware Info (via HAL):\n");
    // Get display info through the service manager
    // (In a real system, this would go through IPC)
    PhantomSystemService* sys_svc = nullptr;
    // For demo purposes, create a temporary instance to show HAL capabilities
    {
        auto factory = std::unique_ptr<hal::IHalFactory>(hal::createMockHalFactory());
        hal::IDisplayHal* display = nullptr;
        hal::IPowerHal* power = nullptr;
        factory->createDisplay(&display);
        factory->createPower(&power);
        if (display) {
            display->init();
            hal::DisplayInfo info;
            if (display->getInfo(&info) == hal::HalResult::SUCCESS) {
                printf("  Display: %dx%d @ %dHz, %d DPI, %s\n",
                       info.resolution.width, info.resolution.height,
                       info.resolution.refresh_rate_hz, info.resolution.dpi,
                       info.panel_type);
            }
            display->deinit();
            factory->destroyDisplay(display);
        }
        if (power) {
            power->init();
            hal::BatteryInfo battery;
            if (power->getBatteryInfo(&battery) == hal::HalResult::SUCCESS) {
                printf("  Battery: %d%%, %s, %d mV, %.1f°C\n",
                       battery.level,
                       battery.is_charging ? "charging" : "not charging",
                       battery.voltage_mv,
                       battery.temperature_dc / 10.0f);
            }
            power->deinit();
            factory->destroyPower(power);
        }
    }

    // 4. Privacy Layer demonstration
    printf("\n[4/5] Privacy Layer Demonstration:\n");
    auto& pm = privacy::PermissionManager::getInstance();
    auto& im = privacy::IdentityManager::getInstance();

    // Register a test app
    pm.registerApp("com.example.camera_app");
    printf("  Registered app: com.example.camera_app\n");

    // App-specific identifier
    std::string app_id = im.getAppIdentifier("com.example.camera_app");
    printf("  App-specific ID: %s\n", app_id.c_str());

    // Different app gets different ID
    std::string app_id2 = im.getAppIdentifier("com.example.maps_app");
    printf("  Maps app ID:     %s\n", app_id2.c_str());
    printf("  IDs match: %s\n", app_id == app_id2 ? "YES (BAD!)" : "NO (GOOD)");

    // Permission demonstration
    printf("\n  Permission states:\n");
    printf("  Camera (default): %s\n",
           pm.checkPermission("com.example.camera_app", privacy::Permission::CAMERA)
           == privacy::PermissionCheckResult::GRANTED ? "GRANTED" : "DENIED");

    pm.grantPermission("com.example.camera_app", privacy::Permission::CAMERA,
                       privacy::GrantType::ALLOW_WHILE_USING);
    printf("  Camera (after grant): %s\n",
           pm.checkPermission("com.example.camera_app", privacy::Permission::CAMERA)
           == privacy::PermissionCheckResult::GRANTED ? "GRANTED" : "DENIED");

    // Location with privacy profile
    pm.grantPermission("com.example.camera_app", privacy::Permission::LOCATION,
                       privacy::GrantType::ALLOW_ALWAYS, privacy::LocationAccuracy::PRECISE);
    printf("  Location accuracy (Normal): %s\n",
           privacy::locationAccuracyToString(pm.getEffectiveLocationAccuracy("com.example.camera_app")));

    pm.setPrivacyProfile(privacy::PrivacyProfile::PRIVACY);
    printf("  Location accuracy (Privacy): %s\n",
           privacy::locationAccuracyToString(pm.getEffectiveLocationAccuracy("com.example.camera_app")));

    pm.setPrivacyProfile(privacy::PrivacyProfile::MAXIMUM_PRIVACY);
    printf("  Location accuracy (Max): %s\n",
           privacy::locationAccuracyToString(pm.getEffectiveLocationAccuracy("com.example.camera_app")));

    pm.setPrivacyProfile(privacy::PrivacyProfile::NORMAL);

    // Hardware ID protection
    printf("\n  Hardware ID protection:\n");
    printf("  IMEI request: %s\n",
           privacy::IdentityManager::shouldDenyHardwareId("IMEI") ? "DENIED" : "ALLOWED (BAD!)");
    printf("  WIFI_MAC request: %s\n",
           privacy::IdentityManager::shouldDenyHardwareId("WIFI_MAC") ? "DENIED" : "ALLOWED (BAD!)");

    // Log access
    pm.logAccess("com.example.camera_app", privacy::Permission::CAMERA, 5000, "Photo capture");

    // 5. Privacy Center
    printf("\n[5/5] Privacy Center:\n");
    auto privacy_svc = std::make_unique<PrivacyAuditService>();
    privacy_svc->onStart();
    privacy_svc->runAudit();

    // Cleanup
    printf("\nShutting down...\n");
    sm.stopAll();
    printf("All services stopped.\n");

    printf("\nPhantom OS Mock Runtime completed successfully.\n");
    return 0;
}
