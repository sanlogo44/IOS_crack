/*
 * Phantom OS - Clipboard Manager
 * v0.27.0 - License: GPL-3.0
 */

#include "phantom/clipboard/clipboard_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cctype>

namespace phantom {
namespace clipboard {

namespace {

std::string toLower(const std::string& s) {
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}

bool contains16DigitRun(const std::string& s) {
    size_t run = 0;
    for (char c : s) {
        if (c >= '0' && c <= '9') {
            run++;
            if (run >= 16) return true;
        } else {
            run = 0;
        }
    }
    return false;
}

}  // namespace

// ============================================================
// Private helpers
// ============================================================

uint64_t ClipboardManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ != 0) {
        return timeOverrideMs_;
    }
    auto now = std::chrono::system_clock::now();
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count());
}

bool ClipboardManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "phantos.system";
}

void ClipboardManager::recordEvent(ClipboardEventType type, ClipboardResult result,
                                   const std::string& owner, const std::string& requester,
                                   uint64_t clipId, const std::string& detail) {
    ClipboardEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.owner = owner;
    event.requester = requester;
    event.clipId = clipId;
    event.detail = detail;  // Metadata only

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        events_.erase(events_.begin());
    }

    size_t typeIdx = static_cast<size_t>(type);
    if (typeIdx < 14) stats_.byEventType[typeIdx]++;
    size_t resultIdx = static_cast<size_t>(result);
    if (resultIdx < 15) stats_.byResult[resultIdx]++;

    if (eventCallback_) eventCallback_(event);
}

void ClipboardManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(logging::LogSource::SYSTEM_SERVER, message,
                                  "ClipboardManager");
        } else if (level == "warn") {
            logServer_->logWarn(logging::LogSource::SYSTEM_SERVER, message,
                                "ClipboardManager");
        } else {
            logServer_->logInfo(logging::LogSource::SYSTEM_SERVER, message,
                                "ClipboardManager");
        }
    }
}

void ClipboardManager::notifyCrashReporter(const std::string& reason) const {
    if (crashReporter_) {
        crashReporter_->captureAnr("clipboard_manager", "clipboard_manager", 0, reason);
    }
}

ClipboardItem* ClipboardManager::findClip(uint64_t id) {
    for (auto& item : history_) {
        if (item.id == id) return &item;
    }
    return nullptr;
}

const ClipboardItem* ClipboardManager::findClip(uint64_t id) const {
    for (const auto& item : history_) {
        if (item.id == id) return &item;
    }
    return nullptr;
}

void ClipboardManager::expireClip(ClipboardItem& item, uint64_t clipId) {
    if (item.pinned || item.state == ClipState::EXPIRED) {
        return;
    }
    item.state = ClipState::EXPIRED;
    stats_.clipsExpired++;
    if (primaryClipId_ == clipId) {
        primaryClipId_ = 0;
    }
    recordEvent(ClipboardEventType::CLIP_EXPIRED, ClipboardResult::SUCCESS, item.ownerApp,
                "", clipId, std::string("Clip expired (policy=") +
                clipExpiryPolicyToString(item.expiryPolicy) + ")");
    logToServer("info", "Clip expired: id=" + std::to_string(clipId));
}

void ClipboardManager::trimHistoryForNewClip() {
    // Trim the oldest non-pinned, non-primary clip to make room.
    // history_ is newest-first, so index size-1 is the oldest entry.
    for (size_t i = history_.size(); i > 0; i--) {
        ClipboardItem& candidate = history_[i - 1];
        if (candidate.pinned || candidate.id == primaryClipId_) {
            continue;
        }
        uint64_t id = candidate.id;
        std::string owner = candidate.ownerApp;
        history_.erase(history_.begin() + (i - 1));
        stats_.historyTrims++;
        recordEvent(ClipboardEventType::HISTORY_TRIMMED, ClipboardResult::SUCCESS,
                    owner, "", id, "Oldest clip trimmed (history full)");
        return;
    }
}

// ============================================================
// Lifecycle
// ============================================================

ClipboardResult ClipboardManager::initialize(size_t maxHistory, size_t maxEvents,
                                             size_t maxClipBytes) {
    if (initialized_) {
        return ClipboardResult::ALREADY_INITIALIZED;
    }
    if (maxHistory == 0 || maxEvents == 0 || maxClipBytes == 0) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxClipBytes_ = maxClipBytes;
    initialized_ = true;
    logToServer("info", "ClipboardManager initialized (maxHistory=" +
                std::to_string(maxHistory) + ", maxEvents=" + std::to_string(maxEvents) +
                ", maxClipBytes=" + std::to_string(maxClipBytes) + ")");
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::shutdown() {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    history_.clear();
    events_.clear();
    eventHistory_.clear();
    grants_.clear();
    appPolicies_.clear();
    primaryClipId_ = 0;
    primaryCopy_ = ClipboardItem{};
    initialized_ = false;
    logToServer("info", "ClipboardManager shut down");
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Primary clip
// ============================================================

ClipboardResult ClipboardManager::setPrimaryClip(const std::string& ownerApp,
                                                 const std::string& data,
                                                 ClipboardDataType type,
                                                 const std::string& mimeType,
                                                 uint32_t privacyFlags,
                                                 ClipExpiryPolicy expiryPolicy,
                                                 uint64_t timeoutMs) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        stats_.totalFailures++;
        recordEvent(ClipboardEventType::CLIP_SET, ClipboardResult::SIMULATED_FAILURE,
                    ownerApp, "", 0, "Simulated set failure");
        notifyCrashReporter("clipboard_set_failed");
        return ClipboardResult::SIMULATED_FAILURE;
    }
    if (ownerApp.empty() || data.empty()) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::INVALID_PARAMETER)]++;
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (type == ClipboardDataType::UNKNOWN) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::UNSUPPORTED_TYPE)]++;
        return ClipboardResult::UNSUPPORTED_TYPE;
    }
    if (data.size() > maxClipBytes_) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::CAPACITY_EXCEEDED)]++;
        return ClipboardResult::CAPACITY_EXCEEDED;
    }
    if (expiryPolicy == ClipExpiryPolicy::AFTER_TIMEOUT && timeoutMs == 0) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::INVALID_PARAMETER)]++;
        return ClipboardResult::INVALID_PARAMETER;
    }

    // Sensitive-data heuristics
    bool sensitive = isSensitiveData(data);
    if (sensitive) {
        privacyFlags |= CLIPBOARD_PRIVACY_SENSITIVE |
                        CLIPBOARD_PRIVACY_REDACT_ON_CROSS_APP |
                        CLIPBOARD_PRIVACY_REQUIRE_CONFIRMATION;
        if (expiryPolicy == ClipExpiryPolicy::NEVER && timeoutMs == 0) {
            expiryPolicy = ClipExpiryPolicy::AFTER_TIMEOUT;
            timeoutMs = CLIPBOARD_DEFAULT_TIMEOUT_MS;
        }
    }

    bool noHistory = (privacyFlags & CLIPBOARD_PRIVACY_NO_HISTORY) != 0;

    // Capacity check for history insertion
    if (!noHistory && history_.size() >= maxHistory_) {
        bool canTrim = false;
        for (const auto& item : history_) {
            if (!item.pinned && item.id != primaryClipId_) {
                canTrim = true;
                break;
            }
        }
        if (!canTrim) {
            stats_.byResult[static_cast<size_t>(ClipboardResult::CAPACITY_EXCEEDED)]++;
            return ClipboardResult::CAPACITY_EXCEEDED;
        }
    }

    // Superseded primary clips are marked CLEARED; pinned clips stay PINNED
    if (primaryClipId_ != 0) {
        ClipboardItem* prev = findClip(primaryClipId_);
        if (prev && prev->state == ClipState::ACTIVE) {
            prev->state = ClipState::CLEARED;
        }
    }

    ClipboardItem item;
    item.id = nextClipId_++;
    item.ownerApp = ownerApp;
    item.data = data;
    item.mimeType = mimeType.empty() ? "text/plain" : mimeType;
    item.type = type;
    item.state = ClipState::ACTIVE;
    item.privacyFlags = privacyFlags;
    item.expiryPolicy = expiryPolicy;
    item.createdAt = getCurrentTimeMs();
    item.expiresAt = (expiryPolicy == ClipExpiryPolicy::AFTER_TIMEOUT)
                         ? item.createdAt + timeoutMs
                         : 0;
    primaryClipId_ = item.id;
    primaryCopy_ = item;  // Copy kept for NO_HISTORY primary clips

    if (!noHistory) {
        if (history_.size() >= maxHistory_) {
            trimHistoryForNewClip();
        }
        history_.insert(history_.begin(), item);
    }

    stats_.clipsSet++;
    stats_.bytesStored += data.size();
    size_t typeIdx = static_cast<size_t>(type);
    if (typeIdx < 8) stats_.byDataType[typeIdx]++;
    recordEvent(ClipboardEventType::CLIP_SET, ClipboardResult::SUCCESS, ownerApp, "",
                item.id, "clip=" + std::to_string(item.id) + " type=" +
                clipboardDataTypeToString(type) + " size=" + std::to_string(data.size()));
    if (sensitive) {
        recordEvent(ClipboardEventType::SENSITIVE_DETECTED, ClipboardResult::SUCCESS,
                    ownerApp, "", item.id,
                    "Sensitive pattern detected; flags applied");
    }
    logToServer("info", "Clip set: id=" + std::to_string(item.id) + " type=" +
                clipboardDataTypeToString(type) + " size=" + std::to_string(data.size()));
    if (clipCallback_) clipCallback_(item);
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::getPrimaryClip(const std::string& requesterApp,
                                                 ClipboardItem& out) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        stats_.totalFailures++;
        recordEvent(ClipboardEventType::CLIP_READ, ClipboardResult::SIMULATED_FAILURE,
                    "", requesterApp, 0, "Simulated read failure");
        notifyCrashReporter("clipboard_read_failed");
        return ClipboardResult::SIMULATED_FAILURE;
    }
    if (requesterApp.empty()) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::INVALID_PARAMETER)]++;
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (primaryClipId_ == 0) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::CLIP_EMPTY)]++;
        return ClipboardResult::CLIP_EMPTY;
    }
    ClipboardItem* item = findClip(primaryClipId_);
    if (!item && primaryCopy_.id == primaryClipId_) {
        item = &primaryCopy_;  // NO_HISTORY primary clip
    }
    if (!item) {
        primaryClipId_ = 0;
        stats_.byResult[static_cast<size_t>(ClipboardResult::CLIP_EMPTY)]++;
        return ClipboardResult::CLIP_EMPTY;
    }
    if (item->state == ClipState::EXPIRED) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::CLIP_EXPIRED)]++;
        return ClipboardResult::CLIP_EXPIRED;
    }

    bool ownerOrSystem = (requesterApp == item->ownerApp) || isSystemOwner(requesterApp);

    if (!ownerOrSystem) {
        // App-level policy takes precedence
        bool policyAllowed = false;
        auto policyIt = appPolicies_.find(requesterApp);
        if (policyIt != appPolicies_.end()) {
            if (policyIt->second == PasteGrantType::DENY_ALWAYS) {
                stats_.readsDenied++;
                recordEvent(ClipboardEventType::CLIP_DENIED, ClipboardResult::PERMISSION_DENIED,
                            item->ownerApp, requesterApp, item->id, "App policy DENY_ALWAYS");
                logToServer("warn", "Clipboard read denied (app policy): " + requesterApp);
                if (accessCallback_) {
                    accessCallback_(requesterApp, ClipboardResult::PERMISSION_DENIED);
                }
                return ClipboardResult::PERMISSION_DENIED;
            }
            if (policyIt->second == PasteGrantType::ALLOW_ALWAYS) {
                policyAllowed = true;
            } else if (policyIt->second == PasteGrantType::ALLOW_ONCE) {
                // Consume the one-shot policy
                policyIt->second = PasteGrantType::NONE;
                policyAllowed = true;
            }
        }

        if (!policyAllowed) {
            // Check explicit grants
            auto grantIt = grants_.find({item->ownerApp, requesterApp});
            if (grantIt != grants_.end()) {
                if (grantIt->second.grantType == PasteGrantType::DENY_ALWAYS) {
                    stats_.readsDenied++;
                    recordEvent(ClipboardEventType::CLIP_DENIED, ClipboardResult::PERMISSION_DENIED,
                                item->ownerApp, requesterApp, item->id, "Grant DENY_ALWAYS");
                    logToServer("warn", "Clipboard read denied (grant): " + requesterApp);
                    if (accessCallback_) {
                        accessCallback_(requesterApp, ClipboardResult::PERMISSION_DENIED);
                    }
                    return ClipboardResult::PERMISSION_DENIED;
                }
                if (grantIt->second.grantType == PasteGrantType::ALLOW_ONCE) {
                    // One-shot grant: consumed by this read
                    grants_.erase(grantIt);
                }
                // ALLOW_ONCE (consumed above) and ALLOW_ALWAYS: proceed to read
            } else {
                // Default: cross-app reads require confirmation
                stats_.confirmationsRequested++;
                recordEvent(ClipboardEventType::CONFIRMATION_REQUESTED,
                            ClipboardResult::CONFIRMATION_REQUIRED, item->ownerApp,
                            requesterApp, item->id,
                            "Cross-app read requires confirmation");
                logToServer("info", "Paste confirmation requested by: " + requesterApp);
                if (accessCallback_) {
                    accessCallback_(requesterApp, ClipboardResult::CONFIRMATION_REQUIRED);
                }
                return ClipboardResult::CONFIRMATION_REQUIRED;
            }
        }
    }

    // Read path
    item->readCount++;
    item->lastReadAt = getCurrentTimeMs();
    stats_.clipsRead++;
    stats_.bytesRead += item->data.size();

    bool redact = !ownerOrSystem &&
                  (item->privacyFlags & CLIPBOARD_PRIVACY_REDACT_ON_CROSS_APP) != 0;

    ClipboardResult result = ClipboardResult::SUCCESS;
    if (redact) {
        out = *item;
        out.data = redactData(item->data);
        out.state = ClipState::REDACTED;
        result = ClipboardResult::SENSITIVE_REDACTED;
        stats_.redactions++;
        recordEvent(ClipboardEventType::REDACTION_APPLIED, ClipboardResult::SENSITIVE_REDACTED,
                    item->ownerApp, requesterApp, item->id,
                    "Sensitive content redacted for cross-app read");
        logToServer("info", "Clip redacted for cross-app read: " + requesterApp);
    } else {
        out = *item;
    }

    recordEvent(ClipboardEventType::CLIP_READ, result, item->ownerApp, requesterApp,
                item->id, "clip=" + std::to_string(item->id));

    // AFTER_READ expiry (pinned clips never expire)
    if (item->expiryPolicy == ClipExpiryPolicy::AFTER_READ && !item->pinned) {
        expireClip(*item, item->id);
    }

    if (accessCallback_) accessCallback_(requesterApp, result);
    return result;
}

ClipboardResult ClipboardManager::peekPrimaryClipMetadata(const std::string& requesterApp,
                                                           ClipboardItem& out) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (requesterApp.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (primaryClipId_ == 0) {
        return ClipboardResult::CLIP_EMPTY;
    }
    const ClipboardItem* item = findClip(primaryClipId_);
    if (!item && primaryCopy_.id == primaryClipId_) {
        item = &primaryCopy_;  // NO_HISTORY primary clip
    }
    if (!item) {
        return ClipboardResult::CLIP_EMPTY;
    }
    if (item->state == ClipState::EXPIRED) {
        return ClipboardResult::CLIP_EXPIRED;
    }
    out = *item;
    out.data.clear();  // Metadata only — never expose content
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::clearPrimaryClip(const std::string& requesterApp) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        stats_.totalFailures++;
        recordEvent(ClipboardEventType::CLIP_CLEARED, ClipboardResult::SIMULATED_FAILURE,
                    requesterApp, "", 0, "Simulated clear failure");
        notifyCrashReporter("clipboard_clear_failed");
        return ClipboardResult::SIMULATED_FAILURE;
    }
    if (primaryClipId_ == 0) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::CLIP_EMPTY)]++;
        return ClipboardResult::CLIP_EMPTY;
    }
    ClipboardItem* item = findClip(primaryClipId_);
    if (!item && primaryCopy_.id == primaryClipId_) {
        item = &primaryCopy_;  // NO_HISTORY primary clip
    }
    if (!item) {
        primaryClipId_ = 0;
        return ClipboardResult::CLIP_EMPTY;
    }
    if (requesterApp != item->ownerApp && !isSystemOwner(requesterApp)) {
        stats_.byResult[static_cast<size_t>(ClipboardResult::PERMISSION_DENIED)]++;
        return ClipboardResult::PERMISSION_DENIED;
    }
    item->state = ClipState::CLEARED;
    uint64_t id = item->id;
    primaryClipId_ = 0;
    stats_.clipsCleared++;
    recordEvent(ClipboardEventType::CLIP_CLEARED, ClipboardResult::SUCCESS, item->ownerApp,
                requesterApp, id, "Primary clip cleared");
    logToServer("info", "Primary clip cleared: id=" + std::to_string(id));
    if (clipCallback_) clipCallback_(*item);
    return ClipboardResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<ClipboardItem> ClipboardManager::getHistory(const std::string& requesterApp,
                                                        size_t limit,
                                                        bool includeExpired) const {
    std::vector<ClipboardItem> result;
    if (!initialized_ || requesterApp.empty()) {
        return result;
    }
    bool system = isSystemOwner(requesterApp);
    for (const auto& item : history_) {  // Newest first
        if (!includeExpired && item.state == ClipState::EXPIRED) {
            continue;
        }
        if (!system && item.ownerApp != requesterApp) {
            continue;
        }
        result.push_back(item);
        if (limit > 0 && result.size() >= limit) {
            break;
        }
    }
    return result;
}

ClipboardResult ClipboardManager::getClipById(uint64_t id, const std::string& requesterApp,
                                              ClipboardItem& out) const {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (requesterApp.empty() || id == 0) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    const ClipboardItem* item = findClip(id);
    if (!item) {
        return ClipboardResult::CLIP_NOT_FOUND;
    }
    if (item->state == ClipState::EXPIRED) {
        return ClipboardResult::CLIP_EXPIRED;
    }
    if (requesterApp != item->ownerApp && !isSystemOwner(requesterApp)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    out = *item;
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::clearOwnerClips(const std::string& ownerApp,
                                                   const std::string& requesterApp) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (ownerApp.empty() || requesterApp.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (requesterApp != ownerApp && !isSystemOwner(requesterApp)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    bool any = false;
    for (auto it = history_.begin(); it != history_.end();) {
        if (it->ownerApp == ownerApp) {
            any = true;
            if (primaryClipId_ == it->id) {
                primaryClipId_ = 0;
            }
            recordEvent(ClipboardEventType::CLIP_CLEARED, ClipboardResult::SUCCESS, ownerApp,
                        requesterApp, it->id, "Owner clips cleared");
            it = history_.erase(it);
        } else {
            ++it;
        }
    }
    if (!any) {
        return ClipboardResult::CLIP_NOT_FOUND;
    }
    stats_.clipsCleared++;
    logToServer("info", "Clips cleared for owner: " + ownerApp);
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::clearAllClips(const std::string& owner) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    size_t count = history_.size();
    history_.clear();
    primaryClipId_ = 0;
    stats_.clipsCleared += count;
    recordEvent(ClipboardEventType::CLIP_CLEARED, ClipboardResult::SUCCESS, "system", owner,
                0, "All clips cleared (" + std::to_string(count) + ")");
    logToServer("info", "All clips cleared: " + std::to_string(count));
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Access control
// ============================================================

ClipboardResult ClipboardManager::grantPasteAccess(const std::string& sourceOwner,
                                                   const std::string& requesterApp,
                                                   PasteGrantType grantType,
                                                   const std::string& owner) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (sourceOwner.empty() || requesterApp.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (grantType == PasteGrantType::NONE) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (owner != sourceOwner && !isSystemOwner(owner)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    PasteGrant grant;
    grant.sourceOwner = sourceOwner;
    grant.requesterApp = requesterApp;
    grant.grantType = grantType;
    grant.createdAt = getCurrentTimeMs();
    grants_[{sourceOwner, requesterApp}] = grant;
    stats_.confirmationsGranted++;
    recordEvent(ClipboardEventType::APP_POLICY_CHANGED, ClipboardResult::SUCCESS, sourceOwner,
                requesterApp, 0,
                std::string("Paste grant: ") + pasteGrantTypeToString(grantType));
    logToServer("info", "Paste grant set: " + sourceOwner + " -> " + requesterApp + " (" +
                pasteGrantTypeToString(grantType) + ")");
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::denyPasteAccess(const std::string& sourceOwner,
                                                  const std::string& requesterApp,
                                                  const std::string& owner) {
    return grantPasteAccess(sourceOwner, requesterApp, PasteGrantType::DENY_ALWAYS, owner);
}

ClipboardResult ClipboardManager::revokePasteAccess(const std::string& sourceOwner,
                                                    const std::string& requesterApp,
                                                    const std::string& owner) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (sourceOwner.empty() || requesterApp.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (owner != sourceOwner && !isSystemOwner(owner)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    auto it = grants_.find({sourceOwner, requesterApp});
    if (it == grants_.end()) {
        return ClipboardResult::CLIP_NOT_FOUND;
    }
    grants_.erase(it);
    recordEvent(ClipboardEventType::APP_POLICY_CHANGED, ClipboardResult::SUCCESS, sourceOwner,
                requesterApp, 0, "Paste grant revoked");
    logToServer("info", "Paste grant revoked: " + sourceOwner + " -> " + requesterApp);
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::setAppClipboardPolicy(const std::string& app,
                                                        PasteGrantType policy,
                                                        const std::string& owner) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (app.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    if (!isSystemOwner(owner)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    if (policy == PasteGrantType::NONE) {
        appPolicies_.erase(app);
    } else {
        appPolicies_[app] = policy;
    }
    recordEvent(ClipboardEventType::APP_POLICY_CHANGED, ClipboardResult::SUCCESS, app, owner,
                0, std::string("App clipboard policy: ") + pasteGrantTypeToString(policy));
    logToServer("info", "App clipboard policy: " + app + " -> " +
                pasteGrantTypeToString(policy));
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Pin / expiry
// ============================================================

ClipboardResult ClipboardManager::pinClip(uint64_t id, const std::string& requesterApp) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (requesterApp.empty() || id == 0) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    ClipboardItem* item = findClip(id);
    if (!item) {
        return ClipboardResult::CLIP_NOT_FOUND;
    }
    if (requesterApp != item->ownerApp && !isSystemOwner(requesterApp)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    if (item->state == ClipState::EXPIRED) {
        return ClipboardResult::BAD_STATE;
    }
    if (item->pinned) {
        return ClipboardResult::BAD_STATE;
    }
    item->pinned = true;
    item->state = ClipState::PINNED;
    stats_.clipsPinned++;
    recordEvent(ClipboardEventType::CLIP_PINNED, ClipboardResult::SUCCESS, item->ownerApp,
                requesterApp, id, "Clip pinned");
    logToServer("info", "Clip pinned: id=" + std::to_string(id));
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::unpinClip(uint64_t id, const std::string& requesterApp) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (requesterApp.empty() || id == 0) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    ClipboardItem* item = findClip(id);
    if (!item) {
        return ClipboardResult::CLIP_NOT_FOUND;
    }
    if (requesterApp != item->ownerApp && !isSystemOwner(requesterApp)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    if (!item->pinned) {
        return ClipboardResult::BAD_STATE;
    }
    item->pinned = false;
    item->state = ClipState::ACTIVE;
    stats_.clipsUnpinned++;
    recordEvent(ClipboardEventType::CLIP_UNPINNED, ClipboardResult::SUCCESS, item->ownerApp,
                requesterApp, id, "Clip unpinned");
    logToServer("info", "Clip unpinned: id=" + std::to_string(id));
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::processExpiredClips() {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    uint64_t now = getCurrentTimeMs();
    for (auto& item : history_) {
        if (item.expiryPolicy == ClipExpiryPolicy::AFTER_TIMEOUT && item.expiresAt != 0 &&
            now >= item.expiresAt) {
            expireClip(item, item.id);
        }
    }
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::handleOwnerExit(const std::string& ownerApp) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (ownerApp.empty()) {
        return ClipboardResult::INVALID_PARAMETER;
    }
    for (auto& item : history_) {
        if (item.ownerApp == ownerApp && item.expiryPolicy == ClipExpiryPolicy::ON_OWNER_EXIT) {
            expireClip(item, item.id);
        }
    }
    logToServer("info", "Owner exit handled: " + ownerApp);
    return ClipboardResult::SUCCESS;
}

ClipboardResult ClipboardManager::handleSystemLock(const std::string& owner) {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return ClipboardResult::PERMISSION_DENIED;
    }
    for (auto& item : history_) {
        if (item.expiryPolicy == ClipExpiryPolicy::ON_SYSTEM_LOCK) {
            expireClip(item, item.id);
        }
    }
    recordEvent(ClipboardEventType::CLIP_EXPIRED, ClipboardResult::SUCCESS, "system", owner,
                0, "System lock: ON_SYSTEM_LOCK clips expired");
    logToServer("info", "System lock: ON_SYSTEM_LOCK clips expired");
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<ClipboardEvent> ClipboardManager::getEvents(size_t limit) const {
    std::vector<ClipboardEvent> result;
    if (limit == 0 || limit >= events_.size()) {
        result = events_;
    } else {
        result.assign(events_.end() - limit, events_.end());
    }
    return result;
}

std::vector<ClipboardEvent> ClipboardManager::getEventsByType(ClipboardEventType type) const {
    std::vector<ClipboardEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
        }
    }
    return result;
}

ClipboardResult ClipboardManager::clearEvents() {
    if (!initialized_) {
        return ClipboardResult::NOT_INITIALIZED;
    }
    for (const auto& event : events_) {
        eventHistory_.push_back(event);
    }
    events_.clear();
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void ClipboardManager::resetStats() {
    stats_ = ClipboardStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* ClipboardManager::clipboardDataTypeToString(ClipboardDataType type) {
    switch (type) {
        case ClipboardDataType::TEXT: return "TEXT";
        case ClipboardDataType::URL: return "URL";
        case ClipboardDataType::HTML: return "HTML";
        case ClipboardDataType::IMAGE_STUB: return "IMAGE_STUB";
        case ClipboardDataType::FILE_LIST_STUB: return "FILE_LIST_STUB";
        case ClipboardDataType::RICH_TEXT_STUB: return "RICH_TEXT_STUB";
        case ClipboardDataType::BINARY_STUB: return "BINARY_STUB";
        case ClipboardDataType::UNKNOWN: return "UNKNOWN";
    }
    return "UNKNOWN";
}

const char* ClipboardManager::clipStateToString(ClipState state) {
    switch (state) {
        case ClipState::EMPTY: return "EMPTY";
        case ClipState::ACTIVE: return "ACTIVE";
        case ClipState::EXPIRED: return "EXPIRED";
        case ClipState::PINNED: return "PINNED";
        case ClipState::CLEARED: return "CLEARED";
        case ClipState::REDACTED: return "REDACTED";
    }
    return "EMPTY";
}

const char* ClipboardManager::clipExpiryPolicyToString(ClipExpiryPolicy policy) {
    switch (policy) {
        case ClipExpiryPolicy::NEVER: return "NEVER";
        case ClipExpiryPolicy::AFTER_TIMEOUT: return "AFTER_TIMEOUT";
        case ClipExpiryPolicy::AFTER_READ: return "AFTER_READ";
        case ClipExpiryPolicy::ON_OWNER_EXIT: return "ON_OWNER_EXIT";
        case ClipExpiryPolicy::ON_SYSTEM_LOCK: return "ON_SYSTEM_LOCK";
    }
    return "NEVER";
}

const char* ClipboardManager::pasteGrantTypeToString(PasteGrantType grant) {
    switch (grant) {
        case PasteGrantType::NONE: return "NONE";
        case PasteGrantType::ALLOW_ONCE: return "ALLOW_ONCE";
        case PasteGrantType::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case PasteGrantType::DENY_ALWAYS: return "DENY_ALWAYS";
    }
    return "NONE";
}

const char* ClipboardManager::clipboardResultToString(ClipboardResult result) {
    switch (result) {
        case ClipboardResult::SUCCESS: return "SUCCESS";
        case ClipboardResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case ClipboardResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case ClipboardResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case ClipboardResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case ClipboardResult::CLIP_NOT_FOUND: return "CLIP_NOT_FOUND";
        case ClipboardResult::CLIP_EXPIRED: return "CLIP_EXPIRED";
        case ClipboardResult::CLIP_EMPTY: return "CLIP_EMPTY";
        case ClipboardResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case ClipboardResult::CONFIRMATION_REQUIRED: return "CONFIRMATION_REQUIRED";
        case ClipboardResult::SENSITIVE_REDACTED: return "SENSITIVE_REDACTED";
        case ClipboardResult::UNSUPPORTED_TYPE: return "UNSUPPORTED_TYPE";
        case ClipboardResult::BAD_STATE: return "BAD_STATE";
        case ClipboardResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case ClipboardResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
    }
    return "SUCCESS";
}

const char* ClipboardManager::clipboardEventTypeToString(ClipboardEventType type) {
    switch (type) {
        case ClipboardEventType::CLIP_SET: return "CLIP_SET";
        case ClipboardEventType::CLIP_READ: return "CLIP_READ";
        case ClipboardEventType::CLIP_DENIED: return "CLIP_DENIED";
        case ClipboardEventType::CLIP_CLEARED: return "CLIP_CLEARED";
        case ClipboardEventType::CLIP_EXPIRED: return "CLIP_EXPIRED";
        case ClipboardEventType::CLIP_PINNED: return "CLIP_PINNED";
        case ClipboardEventType::CLIP_UNPINNED: return "CLIP_UNPINNED";
        case ClipboardEventType::HISTORY_TRIMMED: return "HISTORY_TRIMMED";
        case ClipboardEventType::APP_POLICY_CHANGED: return "APP_POLICY_CHANGED";
        case ClipboardEventType::CONFIRMATION_REQUESTED: return "CONFIRMATION_REQUESTED";
        case ClipboardEventType::CONFIRMATION_GRANTED: return "CONFIRMATION_GRANTED";
        case ClipboardEventType::CONFIRMATION_DENIED: return "CONFIRMATION_DENIED";
        case ClipboardEventType::SENSITIVE_DETECTED: return "SENSITIVE_DETECTED";
        case ClipboardEventType::REDACTION_APPLIED: return "REDACTION_APPLIED";
    }
    return "CLIP_SET";
}

ClipboardDataType ClipboardManager::stringToClipboardDataType(const std::string& str) {
    if (str == "TEXT") return ClipboardDataType::TEXT;
    if (str == "URL") return ClipboardDataType::URL;
    if (str == "HTML") return ClipboardDataType::HTML;
    if (str == "IMAGE_STUB") return ClipboardDataType::IMAGE_STUB;
    if (str == "FILE_LIST_STUB") return ClipboardDataType::FILE_LIST_STUB;
    if (str == "RICH_TEXT_STUB") return ClipboardDataType::RICH_TEXT_STUB;
    if (str == "BINARY_STUB") return ClipboardDataType::BINARY_STUB;
    return ClipboardDataType::UNKNOWN;
}

ClipboardResult ClipboardManager::stringToClipboardResult(const std::string& str) {
    if (str == "SUCCESS") return ClipboardResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return ClipboardResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return ClipboardResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return ClipboardResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return ClipboardResult::PERMISSION_DENIED;
    if (str == "CLIP_NOT_FOUND") return ClipboardResult::CLIP_NOT_FOUND;
    if (str == "CLIP_EXPIRED") return ClipboardResult::CLIP_EXPIRED;
    if (str == "CLIP_EMPTY") return ClipboardResult::CLIP_EMPTY;
    if (str == "CAPACITY_EXCEEDED") return ClipboardResult::CAPACITY_EXCEEDED;
    if (str == "CONFIRMATION_REQUIRED") return ClipboardResult::CONFIRMATION_REQUIRED;
    if (str == "SENSITIVE_REDACTED") return ClipboardResult::SENSITIVE_REDACTED;
    if (str == "UNSUPPORTED_TYPE") return ClipboardResult::UNSUPPORTED_TYPE;
    if (str == "BAD_STATE") return ClipboardResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return ClipboardResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return ClipboardResult::SIMULATED_FAILURE;
    return ClipboardResult::SUCCESS;
}

// ============================================================
// Sensitive-data helpers
// ============================================================

bool ClipboardManager::isSensitiveData(const std::string& data) {
    if (data.empty()) {
        return false;
    }
    std::string lower = toLower(data);
    if (lower.find("password=") != std::string::npos) return true;
    if (lower.find("token=") != std::string::npos) return true;
    if (lower.find("api_key") != std::string::npos) return true;
    if (lower.find("secret") != std::string::npos) return true;
    if (contains16DigitRun(data)) return true;
    return false;
}

std::string ClipboardManager::redactData(const std::string& data) {
    (void)data;
    return "[REDACTED]";
}

}  // namespace clipboard
}  // namespace phantom
