/*
 * Phantom OS - Clipboard Manager
 * v0.27.0 - License: GPL-3.0
 *
 * Privacy-first clipboard service: primary clip with per-app access
 * control (cross-app reads require confirmation by default, iOS-style),
 * clip history with pinning and capacity trimming, sensitive-data
 * detection with cross-app redaction, expiry policies (timeout,
 * after-read, owner-exit, system-lock), events, stats, callbacks and
 * optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Sensitive-data detection is a
 * deterministic heuristic, not real DLP.
 */

#ifndef PHANTOM_CLIPBOARD_CLIPBOARD_MANAGER_H
#define PHANTOM_CLIPBOARD_CLIPBOARD_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace clipboard {

// ============================================================
// Constants
// ============================================================

static const uint32_t CLIPBOARD_PRIVACY_NONE = 0;
static const uint32_t CLIPBOARD_PRIVACY_SENSITIVE = 1 << 0;
static const uint32_t CLIPBOARD_PRIVACY_REDACT_ON_CROSS_APP = 1 << 1;
static const uint32_t CLIPBOARD_PRIVACY_REQUIRE_CONFIRMATION = 1 << 2;
static const uint32_t CLIPBOARD_PRIVACY_NO_HISTORY = 1 << 3;
static const uint32_t CLIPBOARD_PRIVACY_ENCRYPTED_STUB = 1 << 4;

static const uint64_t CLIPBOARD_DEFAULT_TIMEOUT_MS = 60000;  // Sensitive auto-expiry

// ============================================================
// Enums
// ============================================================

enum class ClipboardDataType : uint8_t {
    TEXT = 0,
    URL,
    HTML,
    IMAGE_STUB,
    FILE_LIST_STUB,
    RICH_TEXT_STUB,
    BINARY_STUB,
    UNKNOWN
};

enum class ClipState : uint8_t {
    EMPTY = 0,
    ACTIVE,
    EXPIRED,
    PINNED,
    CLEARED,
    REDACTED
};

enum class ClipExpiryPolicy : uint8_t {
    NEVER = 0,
    AFTER_TIMEOUT,
    AFTER_READ,
    ON_OWNER_EXIT,
    ON_SYSTEM_LOCK
};

enum class PasteGrantType : uint8_t {
    NONE = 0,
    ALLOW_ONCE,
    ALLOW_ALWAYS,
    DENY_ALWAYS
};

enum class ClipboardResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    CLIP_NOT_FOUND,
    CLIP_EXPIRED,
    CLIP_EMPTY,
    CAPACITY_EXCEEDED,
    CONFIRMATION_REQUIRED,
    SENSITIVE_REDACTED,
    UNSUPPORTED_TYPE,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class ClipboardEventType : uint8_t {
    CLIP_SET = 0,
    CLIP_READ,
    CLIP_DENIED,
    CLIP_CLEARED,
    CLIP_EXPIRED,
    CLIP_PINNED,
    CLIP_UNPINNED,
    HISTORY_TRIMMED,
    APP_POLICY_CHANGED,
    CONFIRMATION_REQUESTED,
    CONFIRMATION_GRANTED,
    CONFIRMATION_DENIED,
    SENSITIVE_DETECTED,
    REDACTION_APPLIED
};

// ============================================================
// Data structures
// ============================================================

struct ClipboardItem {
    uint64_t id = 0;
    std::string ownerApp;
    std::string data;         // Raw content (empty in metadata peeks)
    std::string mimeType = "text/plain";
    ClipboardDataType type = ClipboardDataType::UNKNOWN;
    ClipState state = ClipState::EMPTY;
    uint32_t privacyFlags = CLIPBOARD_PRIVACY_NONE;
    ClipExpiryPolicy expiryPolicy = ClipExpiryPolicy::NEVER;
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;   // 0 = no timeout-based expiry
    uint64_t lastReadAt = 0;
    uint32_t readCount = 0;
    bool pinned = false;
    size_t dataSize() const { return data.size(); }
};

struct PasteGrant {
    std::string sourceOwner;
    std::string requesterApp;
    PasteGrantType grantType = PasteGrantType::NONE;
    uint64_t createdAt = 0;
    bool used = false;
};

struct ClipboardEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    ClipboardEventType type = ClipboardEventType::CLIP_SET;
    ClipboardResult result = ClipboardResult::SUCCESS;
    std::string owner;
    std::string requester;
    uint64_t clipId = 0;
    std::string detail;  // Metadata only — never raw clip content
};

struct ClipboardStats {
    uint64_t clipsSet = 0;
    uint64_t clipsRead = 0;
    uint64_t readsDenied = 0;
    uint64_t clipsCleared = 0;
    uint64_t clipsExpired = 0;
    uint64_t clipsPinned = 0;
    uint64_t clipsUnpinned = 0;
    uint64_t redactions = 0;
    uint64_t confirmationsRequested = 0;
    uint64_t confirmationsGranted = 0;
    uint64_t confirmationsDenied = 0;
    uint64_t historyTrims = 0;
    uint64_t totalFailures = 0;
    uint64_t bytesStored = 0;
    uint64_t bytesRead = 0;
    uint64_t byDataType[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byEventType[14] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Clipboard Manager
// ============================================================

class ClipboardManager {
public:
    ClipboardManager() = default;
    ~ClipboardManager() = default;

    ClipboardManager(const ClipboardManager&) = delete;
    ClipboardManager& operator=(const ClipboardManager&) = delete;

    // ---- Lifecycle ----
    ClipboardResult initialize(size_t maxHistory = 64, size_t maxEvents = 256,
                               size_t maxClipBytes = 1048576);
    ClipboardResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Primary clip ----
    ClipboardResult setPrimaryClip(const std::string& ownerApp,
                                   const std::string& data,
                                   ClipboardDataType type,
                                   const std::string& mimeType = "text/plain",
                                   uint32_t privacyFlags = CLIPBOARD_PRIVACY_NONE,
                                   ClipExpiryPolicy expiryPolicy = ClipExpiryPolicy::NEVER,
                                   uint64_t timeoutMs = 0);
    ClipboardResult getPrimaryClip(const std::string& requesterApp, ClipboardItem& out);
    ClipboardResult peekPrimaryClipMetadata(const std::string& requesterApp, ClipboardItem& out);
    ClipboardResult clearPrimaryClip(const std::string& requesterApp);

    // ---- History ----
    std::vector<ClipboardItem> getHistory(const std::string& requesterApp,
                                          size_t limit = 0,
                                          bool includeExpired = false) const;
    ClipboardResult getClipById(uint64_t id, const std::string& requesterApp,
                                ClipboardItem& out) const;
    ClipboardResult clearOwnerClips(const std::string& ownerApp,
                                    const std::string& requesterApp);
    ClipboardResult clearAllClips(const std::string& owner = "system");
    size_t getClipCount() const { return history_.size(); }

    // ---- Access control ----
    ClipboardResult grantPasteAccess(const std::string& sourceOwner,
                                      const std::string& requesterApp,
                                      PasteGrantType grantType,
                                      const std::string& owner = "system");
    ClipboardResult denyPasteAccess(const std::string& sourceOwner,
                                     const std::string& requesterApp,
                                     const std::string& owner = "system");
    ClipboardResult revokePasteAccess(const std::string& sourceOwner,
                                      const std::string& requesterApp,
                                      const std::string& owner = "system");
    ClipboardResult setAppClipboardPolicy(const std::string& app,
                                          PasteGrantType policy,
                                          const std::string& owner = "system");

    // ---- Pin / expiry ----
    ClipboardResult pinClip(uint64_t id, const std::string& requesterApp);
    ClipboardResult unpinClip(uint64_t id, const std::string& requesterApp);
    ClipboardResult processExpiredClips();
    ClipboardResult handleOwnerExit(const std::string& ownerApp);
    ClipboardResult handleSystemLock(const std::string& owner = "system");

    // ---- Events ----
    std::vector<ClipboardEvent> getEvents(size_t limit = 0) const;
    std::vector<ClipboardEvent> getEventsByType(ClipboardEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    ClipboardResult clearEvents();

    // ---- Stats ----
    ClipboardStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setClipCallback(std::function<void(const ClipboardItem&)> cb) { clipCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, ClipboardResult)> cb) {
        accessCallback_ = cb;
    }
    void setEventCallback(std::function<void(const ClipboardEvent&)> cb) { eventCallback_ = cb; }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* clipboardDataTypeToString(ClipboardDataType type);
    static const char* clipStateToString(ClipState state);
    static const char* clipExpiryPolicyToString(ClipExpiryPolicy policy);
    static const char* pasteGrantTypeToString(PasteGrantType grant);
    static const char* clipboardResultToString(ClipboardResult result);
    static const char* clipboardEventTypeToString(ClipboardEventType type);
    static ClipboardDataType stringToClipboardDataType(const std::string& str);
    static ClipboardResult stringToClipboardResult(const std::string& str);

    // ---- Sensitive-data helpers (deterministic heuristics) ----
    static bool isSensitiveData(const std::string& data);
    static std::string redactData(const std::string& data);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(ClipboardEventType type, ClipboardResult result,
                    const std::string& owner, const std::string& requester,
                    uint64_t clipId, const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void expireClip(ClipboardItem& item, uint64_t clipId);
    ClipboardItem* findClip(uint64_t id);
    const ClipboardItem* findClip(uint64_t id) const;
    void trimHistoryForNewClip();

    bool initialized_ = false;
    size_t maxHistory_ = 64;
    size_t maxEvents_ = 256;
    size_t maxClipBytes_ = 1048576;

    std::vector<ClipboardItem> history_;   // Newest first
    ClipboardItem primaryCopy_;            // Copy for NO_HISTORY primary clips
    uint64_t primaryClipId_ = 0;
    uint64_t nextClipId_ = 1;
    uint64_t nextEventId_ = 1;

    std::map<std::pair<std::string, std::string>, PasteGrant> grants_;
    std::map<std::string, PasteGrantType> appPolicies_;

    std::vector<ClipboardEvent> events_;
    std::vector<ClipboardEvent> eventHistory_;

    ClipboardStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const ClipboardItem&)> clipCallback_;
    std::function<void(const std::string&, ClipboardResult)> accessCallback_;
    std::function<void(const ClipboardEvent&)> eventCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace clipboard
}  // namespace phantom

#endif  // PHANTOM_CLIPBOARD_CLIPBOARD_MANAGER_H
