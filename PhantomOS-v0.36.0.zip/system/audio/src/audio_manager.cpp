/*
 * Phantom OS - Audio / Microphone Manager
 * v0.31.0 - License: GPL-3.0
 *
 * Implementation of AudioManager: privacy-first audio/microphone service
 * with device management, per-app policy, recording sessions with
 * start/stop/pause/resume, audio routing, mock audio support, privacy
 * indicator, history with privacy redaction, events, stats, callbacks
 * and optional LogServer/CrashReporter integration.
 */

#include "phantom/audio/audio_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <chrono>
#include <algorithm>
#include <cstring>

namespace phantom {
namespace audio {

// ============================================================
// Private helpers
// ============================================================

int AudioManager::deviceIndex(AudioDevice device) {
    return static_cast<int>(device);
}

uint64_t AudioManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

uint64_t AudioManager::getCurrentTimeNanos() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_ * 1000000ULL;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool AudioManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "android" || app == "com.android.system";
}

AudioRoute AudioManager::deviceToRoute(AudioDevice device) const {
    switch (device) {
        case AudioDevice::SPEAKER: return AudioRoute::SPEAKER;
        case AudioDevice::RECEIVER: return AudioRoute::RECEIVER;
        case AudioDevice::WIRED_HEADSET: return AudioRoute::WIRED_HEADSET;
        case AudioDevice::BLUETOOTH: return AudioRoute::BLUETOOTH;
        default: return AudioRoute::SPEAKER;
    }
}

void AudioManager::initDeviceCapabilities() {
    // Built-in Mic
    devices_[0] = {};
    devices_[0].device = AudioDevice::BUILT_IN_MIC;
    devices_[0].state = AudioState::IDLE;
    devices_[0].isInput = true;
    devices_[0].isOutput = false;
    devices_[0].maxSampleRate = 48000;
    devices_[0].maxChannels = 2;
    devices_[0].latencyMs = 20;
    devices_[0].name = "Built-in Microphone";
    devices_[0].vendor = "PhantomOS";

    // Speaker
    devices_[1] = {};
    devices_[1].device = AudioDevice::SPEAKER;
    devices_[1].state = AudioState::IDLE;
    devices_[1].isInput = false;
    devices_[1].isOutput = true;
    devices_[1].maxSampleRate = 48000;
    devices_[1].maxChannels = 2;
    devices_[1].latencyMs = 15;
    devices_[1].name = "Speaker";
    devices_[1].vendor = "PhantomOS";

    // Receiver
    devices_[2] = {};
    devices_[2].device = AudioDevice::RECEIVER;
    devices_[2].state = AudioState::IDLE;
    devices_[2].isInput = false;
    devices_[2].isOutput = true;
    devices_[2].maxSampleRate = 16000;
    devices_[2].maxChannels = 1;
    devices_[2].latencyMs = 10;
    devices_[2].name = "Earpiece Receiver";
    devices_[2].vendor = "PhantomOS";

    // Wired Headset
    devices_[3] = {};
    devices_[3].device = AudioDevice::WIRED_HEADSET;
    devices_[3].state = AudioState::IDLE;
    devices_[3].isInput = true;
    devices_[3].isOutput = true;
    devices_[3].maxSampleRate = 48000;
    devices_[3].maxChannels = 2;
    devices_[3].latencyMs = 12;
    devices_[3].name = "Wired Headset";
    devices_[3].vendor = "PhantomOS";

    // Bluetooth
    devices_[4] = {};
    devices_[4].device = AudioDevice::BLUETOOTH;
    devices_[4].state = AudioState::IDLE;
    devices_[4].isInput = true;
    devices_[4].isOutput = true;
    devices_[4].maxSampleRate = 44100;
    devices_[4].maxChannels = 2;
    devices_[4].latencyMs = 100;
    devices_[4].name = "Bluetooth Audio";
    devices_[4].vendor = "PhantomOS";

    // Mock
    devices_[5] = {};
    devices_[5].device = AudioDevice::MOCK;
    devices_[5].state = AudioState::IDLE;
    devices_[5].isInput = true;
    devices_[5].isOutput = true;
    devices_[5].maxSampleRate = 48000;
    devices_[5].maxChannels = 2;
    devices_[5].latencyMs = 0;
    devices_[5].name = "Mock Audio Device";
    devices_[5].vendor = "PhantomOS";
}

void AudioManager::setStubFrameData(AudioFrame& frame, AudioDevice device) {
    // Deterministic stub pattern, not real audio samples
    int idx = deviceIndex(device);
    for (int i = 0; i < 16; ++i) {
        frame.stubData[i] = static_cast<uint8_t>((idx * 16 + i) % 256);
    }
}

void AudioManager::updatePrivacyIndicator() {
    lastAccessTime_ = getCurrentTimeMs();
}

void AudioManager::recordEvent(AudioEventType type, AudioResult result,
                                const std::string& appId, AudioDevice device,
                                uint64_t sessionId, const std::string& detail) {
    AudioEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.device = device;
    event.sessionId = sessionId;
    event.detail = detail;

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        eventHistory_.push_back(events_.front());
        events_.erase(events_.begin());
    }

    int di = deviceIndex(device);
    if (di >= 0 && di < 6) stats_.byDevice[di]++;
    int et = static_cast<int>(type);
    if (et >= 0 && et < 17) stats_.byEventType[et]++;
    int ri = static_cast<int>(result);
    if (ri >= 0 && ri < 15) stats_.byResult[ri]++;

    if (eventCallback_) eventCallback_(event);
}

void AudioManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    // Never log raw audio sample data — only metadata
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "AudioManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "AudioManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "AudioManager");
    }
}

void AudioManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("AudioManager", "AudioManager", 0, reason);
}

// ============================================================
// Lifecycle
// ============================================================

AudioResult AudioManager::initialize(size_t maxHistory, size_t maxEvents,
                                        size_t maxSessions) {
    if (initialized_) return AudioResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxSessions == 0) {
        return AudioResult::INVALID_PARAMETER;
    }

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxSessions_ = maxSessions;

    initDeviceCapabilities();

    // Enable default devices: built-in mic, speaker, receiver
    devices_[0].enabled = true;  // Built-in Mic
    devices_[1].enabled = true;  // Speaker
    devices_[2].enabled = true;  // Receiver
    // Wired headset, Bluetooth, Mock disabled by default

    currentRoute_ = AudioRoute::SPEAKER;
    muted_ = false;
    volume_ = 50;

    initialized_ = true;

    logToServer("INFO", "AudioManager initialized");
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::shutdown() {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;

    appPolicies_.clear();
    sessions_.clear();
    history_.clear();
    events_.clear();
    eventHistory_.clear();
    nextSessionId_ = 1;
    nextEventId_ = 1;
    activeMicUsers_.clear();
    lastAccessTime_ = 0;

    for (size_t i = 0; i < 6; ++i) {
        devices_[i] = AudioDeviceInfo{};
        devices_[i].device = static_cast<AudioDevice>(i);
        lastFrames_[i] = AudioFrame{};
        mockFrames_[i] = AudioFrame{};
    }
    mockEnabled_ = false;
    currentRoute_ = AudioRoute::SPEAKER;
    muted_ = false;
    volume_ = 50;
    stats_ = AudioStats{};
    initialized_ = false;
    return AudioResult::SUCCESS;
}

// ============================================================
// Device control
// ============================================================

AudioResult AudioManager::setDeviceEnabled(AudioDevice device, bool enabled,
                                              const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;

    if (devices_[idx].enabled == enabled) return AudioResult::SUCCESS;

    devices_[idx].enabled = enabled;
    if (!enabled) {
        devices_[idx].state = AudioState::CLOSED;
    }

    recordEvent(enabled ? AudioEventType::DEVICE_OPENED : AudioEventType::DEVICE_CLOSED,
                 AudioResult::SUCCESS, "system", device, 0,
                 enabled ? "ENABLED" : "DISABLED");
    logToServer("INFO", std::string("Device ") + audioDeviceToString(device) +
                (enabled ? " enabled" : " disabled"));
    return AudioResult::SUCCESS;
}

bool AudioManager::isDeviceEnabled(AudioDevice device) const {
    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return false;
    return devices_[idx].enabled;
}

AudioDeviceInfo AudioManager::getDeviceInfo(AudioDevice device) const {
    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioDeviceInfo{};
    return devices_[idx];
}

std::vector<AudioDeviceInfo> AudioManager::getDevices() const {
    std::vector<AudioDeviceInfo> result;
    for (size_t i = 0; i < 6; ++i) {
        result.push_back(devices_[i]);
    }
    return result;
}

std::vector<AudioDevice> AudioManager::getAvailableDevices() const {
    std::vector<AudioDevice> result;
    for (size_t i = 0; i < 6; ++i) {
        if (devices_[i].enabled) {
            result.push_back(static_cast<AudioDevice>(i));
        }
    }
    return result;
}

// ============================================================
// Routing
// ============================================================

AudioResult AudioManager::setRoute(AudioRoute route, const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    if (currentRoute_ == route) return AudioResult::SUCCESS;

    currentRoute_ = route;
    stats_.routeChanges++;
    recordEvent(AudioEventType::ROUTE_CHANGED, AudioResult::SUCCESS, "system",
                 AudioDevice::BUILT_IN_MIC, 0, audioRouteToString(route));
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::setMuted(bool muted, const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;
    muted_ = muted;
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::setVolume(uint8_t volume, const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;
    if (volume > 100) return AudioResult::INVALID_PARAMETER;
    volume_ = volume;
    return AudioResult::SUCCESS;
}

// ============================================================
// Permission / policy
// ============================================================

AudioResult AudioManager::setAppAudioPolicy(const std::string& appId,
                                               AudioPermission permission,
                                               AudioPrivacyMode privacyMode,
                                               uint32_t privacyFlags,
                                               uint32_t captureRateLimit,
                                               const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }
    if (appId.empty()) return AudioResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    // Check Bluetooth restrictions
    if (privacyFlags & AUDIO_PRIVACY_DISABLE_BLUETOOTH) {
        devices_[4].enabled = false;  // Bluetooth
        devices_[4].state = AudioState::CLOSED;
    }

    AudioPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.lastGrantedAt = getCurrentTimeMs();
    policy.captureRateLimit = captureRateLimit;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(AudioEventType::PERMISSION_CHANGED, AudioResult::SUCCESS,
                 appId, AudioDevice::BUILT_IN_MIC, 0, "POLICY_SET");
    logToServer("INFO", "Policy set for app: " + appId);
    return AudioResult::SUCCESS;
}

AudioPolicy AudioManager::getAppAudioPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return AudioPolicy{};
}

AudioResult AudioManager::clearAppAudioPolicy(const std::string& appId,
                                                 const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return AudioResult::SUCCESS;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    recordEvent(AudioEventType::PERMISSION_CHANGED, AudioResult::SUCCESS,
                 appId, AudioDevice::BUILT_IN_MIC, 0, "POLICY_CLEARED");
    return AudioResult::SUCCESS;
}

bool AudioManager::checkAppAccess(const std::string& appId, AudioDevice device) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    // Check Bluetooth restriction
    if (device == AudioDevice::BLUETOOTH && (policy.privacyFlags & AUDIO_PRIVACY_DISABLE_BLUETOOTH)) {
        return false;
    }

    switch (policy.permission) {
        case AudioPermission::DENY:
            return false;
        case AudioPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case AudioPermission::ALLOW_ALWAYS:
            return true;
        case AudioPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

AudioResult AudioManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return AudioResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return AudioResult::SUCCESS;
}

// ============================================================
// Session lifecycle
// ============================================================

AudioResult AudioManager::openSession(const std::string& appId, AudioDevice device,
                                         AudioCaptureMode mode, uint64_t timeoutMs,
                                         uint64_t* outSessionId) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }
    if (appId.empty()) return AudioResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId, device)) {
        stats_.capturesDenied++;
        if (accessCallback_) accessCallback_(appId, AudioResult::PERMISSION_DENIED);
        recordEvent(AudioEventType::CAPTURE_DENIED, AudioResult::PERMISSION_DENIED,
                     appId, device, 0, "ACCESS_DENIED");
        return AudioResult::PERMISSION_DENIED;
    }

    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;
    if (!devices_[idx].enabled) return AudioResult::DEVICE_NOT_AVAILABLE;

    // Check if device is already in use by another active session (exclusive capture)
    for (const auto& s : sessions_) {
        if (s.device == device && s.requestState == AudioRequestState::ACTIVE) {
            return AudioResult::DEVICE_BUSY;
        }
    }

    if (sessions_.size() >= maxSessions_) return AudioResult::CAPACITY_EXCEEDED;

    AudioSession session;
    session.id = nextSessionId_++;
    session.appId = appId;
    session.device = device;
    session.state = AudioState::RECORDING;
    session.captureMode = mode;
    session.createdAt = getCurrentTimeMs();
    session.expiresAt = timeoutMs > 0 ? session.createdAt + timeoutMs : 0;
    session.requestState = AudioRequestState::ACTIVE;
    session.currentRoute = deviceToRoute(device);
    session.muted = muted_;
    session.volume = volume_;

    if (outSessionId) *outSessionId = session.id;
    sessions_.push_back(session);
    devices_[idx].state = AudioState::RECORDING;
    stats_.sessionsStarted++;

    // Update privacy indicator (only for input/mic devices)
    if (devices_[idx].isInput) {
        if (std::find(activeMicUsers_.begin(), activeMicUsers_.end(), appId) ==
            activeMicUsers_.end()) {
            activeMicUsers_.push_back(appId);
            recordEvent(AudioEventType::INDICATOR_ON, AudioResult::SUCCESS,
                         appId, device, session.id, "INDICATOR_ON");
            stats_.indicatorToggleCount++;
        }
        updatePrivacyIndicator();
    }

    recordEvent(AudioEventType::SESSION_STARTED, AudioResult::SUCCESS,
                 appId, device, session.id, "OPEN");
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::closeSession(uint64_t sessionId, const std::string& appId) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return AudioResult::PERMISSION_DENIED;
        if (session.requestState == AudioRequestState::CANCELLED) return AudioResult::BAD_STATE;

        session.requestState = AudioRequestState::CANCELLED;
        session.state = AudioState::CLOSED;

        int idx = deviceIndex(session.device);
        if (idx >= 0 && idx < 6) devices_[idx].state = AudioState::IDLE;

        stats_.sessionsEnded++;

        // Update privacy indicator: check if app has other active mic sessions
        if (idx >= 0 && idx < 6 && devices_[idx].isInput) {
            bool hasOtherActive = false;
            for (const auto& s : sessions_) {
                if (s.appId == session.appId && s.id != sessionId &&
                    s.requestState == AudioRequestState::ACTIVE) {
                    int oidx = deviceIndex(s.device);
                    if (oidx >= 0 && oidx < 6 && devices_[oidx].isInput) {
                        hasOtherActive = true;
                        break;
                    }
                }
            }
            if (!hasOtherActive) {
                auto userIt = std::find(activeMicUsers_.begin(), activeMicUsers_.end(),
                                         session.appId);
                if (userIt != activeMicUsers_.end()) {
                    activeMicUsers_.erase(userIt);
                    recordEvent(AudioEventType::INDICATOR_OFF, AudioResult::SUCCESS,
                                 session.appId, session.device, sessionId, "INDICATOR_OFF");
                    stats_.indicatorToggleCount++;
                }
            }
        }

        recordEvent(AudioEventType::SESSION_ENDED, AudioResult::SUCCESS,
                     session.appId, session.device, sessionId, "CLOSE");
        return AudioResult::SUCCESS;
    }
    return AudioResult::SESSION_NOT_FOUND;
}

AudioResult AudioManager::pauseSession(uint64_t sessionId, const std::string& appId) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return AudioResult::PERMISSION_DENIED;
        if (session.requestState != AudioRequestState::ACTIVE) return AudioResult::BAD_STATE;

        session.requestState = AudioRequestState::PAUSED;
        session.state = AudioState::PAUSED;
        return AudioResult::SUCCESS;
    }
    return AudioResult::SESSION_NOT_FOUND;
}

AudioResult AudioManager::resumeSession(uint64_t sessionId, const std::string& appId) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return AudioResult::PERMISSION_DENIED;
        if (session.requestState != AudioRequestState::PAUSED) return AudioResult::BAD_STATE;

        session.requestState = AudioRequestState::ACTIVE;
        session.state = AudioState::RECORDING;
        return AudioResult::SUCCESS;
    }
    return AudioResult::SESSION_NOT_FOUND;
}

AudioResult AudioManager::processSessions() {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    uint64_t now = getCurrentTimeMs();

    for (auto& session : sessions_) {
        if (session.requestState != AudioRequestState::ACTIVE) continue;
        if (session.expiresAt > 0 && now >= session.expiresAt) {
            session.requestState = AudioRequestState::EXPIRED;
            session.state = AudioState::CLOSED;

            int idx = deviceIndex(session.device);
            if (idx >= 0 && idx < 6) devices_[idx].state = AudioState::IDLE;

            stats_.sessionsExpired++;

            // Update privacy indicator
            if (idx >= 0 && idx < 6 && devices_[idx].isInput) {
                bool hasOtherActive = false;
                for (const auto& s : sessions_) {
                    if (s.appId == session.appId && s.id != session.id &&
                        s.requestState == AudioRequestState::ACTIVE) {
                        int oidx = deviceIndex(s.device);
                        if (oidx >= 0 && oidx < 6 && devices_[oidx].isInput) {
                            hasOtherActive = true;
                            break;
                        }
                    }
                }
                if (!hasOtherActive) {
                    auto userIt = std::find(activeMicUsers_.begin(), activeMicUsers_.end(),
                                             session.appId);
                    if (userIt != activeMicUsers_.end()) {
                        activeMicUsers_.erase(userIt);
                        stats_.indicatorToggleCount++;
                    }
                }
            }

            recordEvent(AudioEventType::SESSION_EXPIRED, AudioResult::SUCCESS,
                         session.appId, session.device, session.id, "EXPIRED");
        }
    }
    return AudioResult::SUCCESS;
}

size_t AudioManager::getActiveSessionCount() const {
    size_t count = 0;
    for (const auto& s : sessions_) {
        if (s.requestState == AudioRequestState::ACTIVE) count++;
    }
    return count;
}

std::vector<AudioSession> AudioManager::getActiveSessions() const {
    std::vector<AudioSession> result;
    for (const auto& s : sessions_) {
        if (s.requestState == AudioRequestState::ACTIVE) result.push_back(s);
    }
    return result;
}

// ============================================================
// Capture
// ============================================================

AudioResult AudioManager::captureFrame(uint64_t sessionId, const std::string& appId) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::CAPTURE_FAILED; }

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return AudioResult::PERMISSION_DENIED;
        if (session.requestState != AudioRequestState::ACTIVE) return AudioResult::BAD_STATE;

        int idx = deviceIndex(session.device);
        if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;
        if (!devices_[idx].enabled) return AudioResult::DEVICE_NOT_AVAILABLE;

        // Rate limiting
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.captureRateLimit > 0 &&
            session.lastCaptureAt > 0) {
            uint64_t minIntervalMs = 1000 / policyIt->second.captureRateLimit;
            if (getCurrentTimeMs() - session.lastCaptureAt < minIntervalMs) {
                return AudioResult::RATE_LIMITED;
            }
        }

        recordEvent(AudioEventType::CAPTURE_STARTED, AudioResult::SUCCESS,
                     appId, session.device, sessionId, "CAPTURE_START");
        stats_.capturesStarted++;

        AudioFrame frame;
        // Use mock frame if enabled
        if (mockEnabled_ && mockFrames_[idx].timestamp > 0) {
            frame = mockFrames_[idx];
            frame.mock = true;
        } else {
            frame.sampleRate = devices_[idx].maxSampleRate;
            frame.channels = devices_[idx].maxChannels;
            frame.frameSize = AUDIO_DEFAULT_FRAME_SIZE;
            setStubFrameData(frame, session.device);
        }
        frame.device = session.device;
        frame.frameId = session.captureCount + 1;
        frame.timestamp = getCurrentTimeMs();
        frame.timestampNanos = getCurrentTimeNanos();

        deliverFrameToSession(session, frame);

        session.captureCount += 1;
        session.totalFrames += 1;
        session.lastCaptureAt = getCurrentTimeMs();
        updatePrivacyIndicator();

        recordEvent(AudioEventType::CAPTURE_COMPLETED, AudioResult::SUCCESS,
                     appId, session.device, sessionId, "CAPTURE_DONE");
        stats_.capturesCompleted++;

        // Consume ALLOW_ONCE
        if (policyIt != appPolicies_.end() && policyIt->second.permission == AudioPermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }

        return AudioResult::SUCCESS;
    }
    return AudioResult::SESSION_NOT_FOUND;
}

AudioResult AudioManager::getLastFrame(const std::string& appId, AudioDevice device,
                                          AudioFrame& out) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::SIMULATED_FAILURE; }

    if (!checkAppAccess(appId, device)) {
        stats_.capturesDenied++;
        if (accessCallback_) accessCallback_(appId, AudioResult::PERMISSION_DENIED);
        recordEvent(AudioEventType::CAPTURE_DENIED, AudioResult::PERMISSION_DENIED,
                     appId, device, 0, "ACCESS_DENIED");
        return AudioResult::PERMISSION_DENIED;
    }

    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;
    if (lastFrames_[idx].timestamp == 0) return AudioResult::DEVICE_NOT_AVAILABLE;

    auto policy = getAppAudioPolicy(appId);
    out = applyPrivacyTransform(lastFrames_[idx], policy.privacyMode, policy.privacyFlags);

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == AudioPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    return AudioResult::SUCCESS;
}

AudioResult AudioManager::requestSingleCapture(const std::string& appId, AudioDevice device,
                                                  uint64_t timeoutMs) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return AudioResult::CAPTURE_FAILED; }

    uint64_t sessionId = 0;
    AudioResult openResult = openSession(appId, device, AudioCaptureMode::RECORD, timeoutMs, &sessionId);
    if (openResult != AudioResult::SUCCESS) return openResult;

    AudioResult captureResult = captureFrame(sessionId, appId);
    closeSession(sessionId, appId);
    return captureResult;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<AudioFrame> AudioManager::getHistory(const std::string& appId,
                                                    size_t limit, bool includeMock) const {
    std::vector<AudioFrame> result;
    for (const auto& frame : history_) {
        if (!includeMock && frame.mock) continue;
        result.push_back(frame);
        if (limit > 0 && result.size() >= limit) break;
    }
    return result;
}

AudioResult AudioManager::clearHistory(const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(AudioEventType::HISTORY_CLEARED, AudioResult::SUCCESS,
                 "system", AudioDevice::BUILT_IN_MIC, 0, "CLEAR_ALL");
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::clearAppHistory(const std::string& appId,
                                             const std::string& requester) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (appId != requester && !isSystemOwner(requester)) return AudioResult::PERMISSION_DENIED;

    stats_.historyClears++;
    recordEvent(AudioEventType::HISTORY_CLEARED, AudioResult::SUCCESS,
                 appId, AudioDevice::BUILT_IN_MIC, 0, "CLEAR_APP");
    return AudioResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

AudioResult AudioManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;
    mockEnabled_ = enabled;
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::setMockFrame(AudioDevice device, const AudioFrame& frame,
                                          const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) {
        auto policy = getAppAudioPolicy(owner);
        if (!(policy.privacyFlags & AUDIO_PRIVACY_MOCK_ALLOWED)) {
            return AudioResult::MOCK_NOT_ALLOWED;
        }
    }

    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;

    mockFrames_[idx] = frame;
    mockFrames_[idx].device = device;
    mockFrames_[idx].mock = true;
    mockFrames_[idx].timestamp = getCurrentTimeMs();
    stats_.mockFramesSet++;
    recordEvent(AudioEventType::MOCK_FRAME_SET, AudioResult::SUCCESS,
                 "system", device, 0, "MOCK_SET");
    return AudioResult::SUCCESS;
}

AudioResult AudioManager::clearMockFrame(AudioDevice device, const std::string& owner) {
    if (!initialized_) return AudioResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return AudioResult::PERMISSION_DENIED;

    int idx = deviceIndex(device);
    if (idx < 0 || idx >= 6) return AudioResult::INVALID_PARAMETER;
    mockFrames_[idx] = AudioFrame{};
    return AudioResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<AudioEvent> AudioManager::getEvents(size_t limit) const {
    if (limit == 0 || limit >= events_.size()) return events_;
    return std::vector<AudioEvent>(events_.end() - limit, events_.end());
}

std::vector<AudioEvent> AudioManager::getEventsByType(AudioEventType type) const {
    std::vector<AudioEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) result.push_back(event);
    }
    return result;
}

AudioResult AudioManager::clearEvents() {
    for (const auto& event : events_) {
        eventHistory_.push_back(event);
    }
    events_.clear();
    return AudioResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void AudioManager::resetStats() {
    stats_ = AudioStats{};
}

// ============================================================
// Privacy helpers
// ============================================================

AudioFrame AudioManager::applyPrivacyTransform(const AudioFrame& frame,
                                                AudioPrivacyMode mode,
                                                uint32_t privacyFlags) {
    AudioFrame result = frame;

    if (mode == AudioPrivacyMode::FULL && privacyFlags == AUDIO_PRIVACY_NONE) {
        return result;
    }

    // REDACTED mode or MUTE_STUB flag: zero out samples to simulate mute
    if (mode == AudioPrivacyMode::REDACTED || (privacyFlags & AUDIO_PRIVACY_MUTE_STUB)) {
        for (int i = 0; i < 16; ++i) result.stubData[i] = 0;
    }

    // LOW_SAMPLE_RATE: reduce sample rate to simulate quality reduction
    if (privacyFlags & AUDIO_PRIVACY_LOW_SAMPLE_RATE) {
        result.sampleRate = result.sampleRate / 4;
    }

    // METADATA_ONLY mode or flag: zero out all sample-like data
    if (mode == AudioPrivacyMode::METADATA_ONLY || (privacyFlags & AUDIO_PRIVACY_METADATA_ONLY)) {
        result.sampleRate = 0;
        result.channels = 0;
        result.frameSize = 0;
        for (int i = 0; i < 16; ++i) result.stubData[i] = 0;
    }

    // REDACT_METADATA: clear channel info
    if (privacyFlags & AUDIO_PRIVACY_REDACT_METADATA) {
        result.channels = 0;
    }

    result.privacyFlags = privacyFlags;
    return result;
}

// ============================================================
// Private: deliver frame to session
// ============================================================

AudioResult AudioManager::deliverFrameToSession(AudioSession& session,
                                                   const AudioFrame& frame) {
    auto policy = getAppAudioPolicy(session.appId);
    AudioFrame delivered = applyPrivacyTransform(frame, policy.privacyMode, policy.privacyFlags);

    if (policy.privacyMode != AudioPrivacyMode::FULL || policy.privacyFlags != AUDIO_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    session.lastFrame = delivered;
    session.lastRawFrame = frame;

    int idx = deviceIndex(session.device);
    if (idx >= 0 && idx < 6) {
        lastFrames_[idx] = frame;
    }

    // Add to history (unless NO_HISTORY flag)
    if (!(policy.privacyFlags & AUDIO_PRIVACY_NO_HISTORY)) {
        history_.insert(history_.begin(), delivered);
        if (history_.size() > maxHistory_) {
            history_.resize(maxHistory_);
        }
    }

    if (frameCallback_) {
        frameCallback_(delivered, session.appId);
    }

    return AudioResult::SUCCESS;
}

// ============================================================
// String helpers
// ============================================================

const char* AudioManager::audioDeviceToString(AudioDevice device) {
    switch (device) {
        case AudioDevice::BUILT_IN_MIC: return "BUILT_IN_MIC";
        case AudioDevice::SPEAKER: return "SPEAKER";
        case AudioDevice::RECEIVER: return "RECEIVER";
        case AudioDevice::WIRED_HEADSET: return "WIRED_HEADSET";
        case AudioDevice::BLUETOOTH: return "BLUETOOTH";
        case AudioDevice::MOCK: return "MOCK";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioRouteToString(AudioRoute route) {
    switch (route) {
        case AudioRoute::SPEAKER: return "SPEAKER";
        case AudioRoute::RECEIVER: return "RECEIVER";
        case AudioRoute::WIRED_HEADSET: return "WIRED_HEADSET";
        case AudioRoute::BLUETOOTH: return "BLUETOOTH";
        case AudioRoute::EARPIECE: return "EARPIECE";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioStateToString(AudioState state) {
    switch (state) {
        case AudioState::IDLE: return "IDLE";
        case AudioState::OPENING: return "OPENING";
        case AudioState::RECORDING: return "RECORDING";
        case AudioState::PAUSED: return "PAUSED";
        case AudioState::STOPPED: return "STOPPED";
        case AudioState::ERROR_STATE: return "ERROR_STATE";
        case AudioState::CLOSED: return "CLOSED";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioPermissionToString(AudioPermission permission) {
    switch (permission) {
        case AudioPermission::DENY: return "DENY";
        case AudioPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case AudioPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case AudioPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::requestStateToString(AudioRequestState state) {
    switch (state) {
        case AudioRequestState::ACTIVE: return "ACTIVE";
        case AudioRequestState::PAUSED: return "PAUSED";
        case AudioRequestState::EXPIRED: return "EXPIRED";
        case AudioRequestState::CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioPrivacyModeToString(AudioPrivacyMode mode) {
    switch (mode) {
        case AudioPrivacyMode::FULL: return "FULL";
        case AudioPrivacyMode::REDACTED: return "REDACTED";
        case AudioPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::captureModeToString(AudioCaptureMode mode) {
    switch (mode) {
        case AudioCaptureMode::RECORD: return "RECORD";
        case AudioCaptureMode::STREAM: return "STREAM";
        case AudioCaptureMode::VOICE_COMMUNICATION: return "VOICE_COMMUNICATION";
        case AudioCaptureMode::BACKGROUND_CAPTURE: return "BACKGROUND_CAPTURE";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioResultToString(AudioResult result) {
    switch (result) {
        case AudioResult::SUCCESS: return "SUCCESS";
        case AudioResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case AudioResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case AudioResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case AudioResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case AudioResult::DEVICE_BUSY: return "DEVICE_BUSY";
        case AudioResult::DEVICE_NOT_AVAILABLE: return "DEVICE_NOT_AVAILABLE";
        case AudioResult::SESSION_NOT_FOUND: return "SESSION_NOT_FOUND";
        case AudioResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case AudioResult::MOCK_NOT_ALLOWED: return "MOCK_NOT_ALLOWED";
        case AudioResult::RATE_LIMITED: return "RATE_LIMITED";
        case AudioResult::BAD_STATE: return "BAD_STATE";
        case AudioResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case AudioResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        case AudioResult::CAPTURE_FAILED: return "CAPTURE_FAILED";
        default: return "UNKNOWN";
    }
}

const char* AudioManager::audioEventTypeToString(AudioEventType type) {
    switch (type) {
        case AudioEventType::DEVICE_OPENED: return "DEVICE_OPENED";
        case AudioEventType::DEVICE_CLOSED: return "DEVICE_CLOSED";
        case AudioEventType::SESSION_STARTED: return "SESSION_STARTED";
        case AudioEventType::SESSION_ENDED: return "SESSION_ENDED";
        case AudioEventType::CAPTURE_STARTED: return "CAPTURE_STARTED";
        case AudioEventType::CAPTURE_COMPLETED: return "CAPTURE_COMPLETED";
        case AudioEventType::CAPTURE_DENIED: return "CAPTURE_DENIED";
        case AudioEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case AudioEventType::SESSION_EXPIRED: return "SESSION_EXPIRED";
        case AudioEventType::MOCK_FRAME_SET: return "MOCK_FRAME_SET";
        case AudioEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        case AudioEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case AudioEventType::DEVICE_ERROR: return "DEVICE_ERROR";
        case AudioEventType::DEVICE_RECOVERED: return "DEVICE_RECOVERED";
        case AudioEventType::INDICATOR_ON: return "INDICATOR_ON";
        case AudioEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case AudioEventType::ROUTE_CHANGED: return "ROUTE_CHANGED";
        default: return "UNKNOWN";
    }
}

AudioDevice AudioManager::stringToAudioDevice(const std::string& str) {
    if (str == "BUILT_IN_MIC") return AudioDevice::BUILT_IN_MIC;
    if (str == "SPEAKER") return AudioDevice::SPEAKER;
    if (str == "RECEIVER") return AudioDevice::RECEIVER;
    if (str == "WIRED_HEADSET") return AudioDevice::WIRED_HEADSET;
    if (str == "BLUETOOTH") return AudioDevice::BLUETOOTH;
    if (str == "MOCK") return AudioDevice::MOCK;
    return AudioDevice::BUILT_IN_MIC;
}

AudioResult AudioManager::stringToAudioResult(const std::string& str) {
    if (str == "SUCCESS") return AudioResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return AudioResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return AudioResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return AudioResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return AudioResult::PERMISSION_DENIED;
    if (str == "DEVICE_BUSY") return AudioResult::DEVICE_BUSY;
    if (str == "DEVICE_NOT_AVAILABLE") return AudioResult::DEVICE_NOT_AVAILABLE;
    if (str == "SESSION_NOT_FOUND") return AudioResult::SESSION_NOT_FOUND;
    if (str == "CAPACITY_EXCEEDED") return AudioResult::CAPACITY_EXCEEDED;
    if (str == "MOCK_NOT_ALLOWED") return AudioResult::MOCK_NOT_ALLOWED;
    if (str == "RATE_LIMITED") return AudioResult::RATE_LIMITED;
    if (str == "BAD_STATE") return AudioResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return AudioResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return AudioResult::SIMULATED_FAILURE;
    if (str == "CAPTURE_FAILED") return AudioResult::CAPTURE_FAILED;
    return AudioResult::SUCCESS;
}

}  // namespace audio
}  // namespace phantom
