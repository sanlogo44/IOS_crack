/*
 * Phantom OS - Audio / Microphone Manager
 * v0.31.0 - License: GPL-3.0
 *
 * Privacy-first audio/microphone service: device management (built-in mic,
 * speaker, receiver, wired headset, Bluetooth, mock), per-app microphone
 * access control with foreground-only and privacy-indicator enforcement,
 * recording sessions with start/stop/pause/resume, audio focus and routing,
 * mock audio frames for testing, privacy-transformed history, events, stats,
 * callbacks and optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Audio frames are deterministic stub
 * data, not real audio samples. Privacy transforms are deterministic. The
 * LogServer must never log raw audio sample payloads.
 */

#ifndef PHANTOM_AUDIO_AUDIO_MANAGER_H
#define PHANTOM_AUDIO_AUDIO_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace audio {

// ============================================================
// Constants
// ============================================================

static const uint32_t AUDIO_PRIVACY_NONE = 0;
static const uint32_t AUDIO_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t AUDIO_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t AUDIO_PRIVACY_MUTE_STUB = 1 << 2;
static const uint32_t AUDIO_PRIVACY_LOW_SAMPLE_RATE = 1 << 3;
static const uint32_t AUDIO_PRIVACY_REDACT_METADATA = 1 << 4;
static const uint32_t AUDIO_PRIVACY_METADATA_ONLY = 1 << 5;
static const uint32_t AUDIO_PRIVACY_MOCK_ALLOWED = 1 << 6;
static const uint32_t AUDIO_PRIVACY_INDICATOR_REQUIRED = 1 << 7;
static const uint32_t AUDIO_PRIVACY_DISABLE_BLUETOOTH = 1 << 8;

static const uint64_t AUDIO_DEFAULT_SESSION_TIMEOUT_MS = 60000;
static const uint32_t AUDIO_DEFAULT_MAX_SESSIONS = 4;
static const uint32_t AUDIO_DEFAULT_SAMPLE_RATE = 48000;
static const uint32_t AUDIO_DEFAULT_CHANNELS = 2;
static const uint32_t AUDIO_DEFAULT_FRAME_SIZE = 1024;

// ============================================================
// Enums
// ============================================================

enum class AudioDevice : uint8_t {
    BUILT_IN_MIC = 0,
    SPEAKER,
    RECEIVER,
    WIRED_HEADSET,
    BLUETOOTH,
    MOCK,
    COUNT
};

enum class AudioRoute : uint8_t {
    SPEAKER = 0,
    RECEIVER,
    WIRED_HEADSET,
    BLUETOOTH,
    EARPIECE
};

enum class AudioState : uint8_t {
    IDLE = 0,
    OPENING,
    RECORDING,
    PAUSED,
    STOPPED,
    ERROR_STATE,
    CLOSED
};

enum class AudioPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class AudioRequestState : uint8_t {
    ACTIVE = 0,
    PAUSED,
    EXPIRED,
    CANCELLED
};

enum class AudioPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class AudioCaptureMode : uint8_t {
    RECORD = 0,
    STREAM,
    VOICE_COMMUNICATION,
    BACKGROUND_CAPTURE
};

enum class AudioResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    DEVICE_BUSY,
    DEVICE_NOT_AVAILABLE,
    SESSION_NOT_FOUND,
    CAPACITY_EXCEEDED,
    MOCK_NOT_ALLOWED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE,
    CAPTURE_FAILED
};

enum class AudioEventType : uint8_t {
    DEVICE_OPENED = 0,
    DEVICE_CLOSED,
    SESSION_STARTED,
    SESSION_ENDED,
    CAPTURE_STARTED,
    CAPTURE_COMPLETED,
    CAPTURE_DENIED,
    PERMISSION_CHANGED,
    SESSION_EXPIRED,
    MOCK_FRAME_SET,
    HISTORY_CLEARED,
    PRIVACY_APPLIED,
    DEVICE_ERROR,
    DEVICE_RECOVERED,
    INDICATOR_ON,
    INDICATOR_OFF,
    ROUTE_CHANGED
};

// ============================================================
// Data structures
// ============================================================

struct AudioFrame {
    uint32_t sampleRate = 0;
    uint32_t channels = 0;
    uint32_t frameSize = 0;
    uint64_t frameId = 0;
    uint64_t timestamp = 0;
    uint64_t timestampNanos = 0;
    AudioDevice device = AudioDevice::BUILT_IN_MIC;
    uint32_t privacyFlags = AUDIO_PRIVACY_NONE;
    bool mock = false;
    uint8_t stubData[16] = {0};  // Deterministic stub, not real audio
};

struct AudioDeviceInfo {
    AudioDevice device = AudioDevice::BUILT_IN_MIC;
    AudioState state = AudioState::IDLE;
    bool enabled = false;
    bool isInput = false;       // Microphone vs output
    bool isOutput = false;
    uint32_t maxSampleRate = 0;
    uint32_t maxChannels = 0;
    uint32_t latencyMs = 0;
    std::string name;
    std::string vendor;
};

struct AudioPolicy {
    std::string appId;
    AudioPermission permission = AudioPermission::DENY;
    AudioPrivacyMode privacyMode = AudioPrivacyMode::FULL;
    uint32_t privacyFlags = AUDIO_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
    uint32_t captureRateLimit = 0;  // 0 = unlimited
};

struct AudioSession {
    uint64_t id = 0;
    std::string appId;
    AudioDevice device = AudioDevice::BUILT_IN_MIC;
    AudioState state = AudioState::IDLE;
    AudioCaptureMode captureMode = AudioCaptureMode::RECORD;
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;
    uint64_t lastCaptureAt = 0;
    uint32_t captureCount = 0;
    uint32_t totalFrames = 0;
    AudioRequestState requestState = AudioRequestState::ACTIVE;
    AudioRoute currentRoute = AudioRoute::SPEAKER;
    bool muted = false;
    uint8_t volume = 0;
    AudioFrame lastFrame;
    AudioFrame lastRawFrame;
};

struct AudioEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    AudioEventType type = AudioEventType::DEVICE_OPENED;
    AudioResult result = AudioResult::SUCCESS;
    std::string appId;
    AudioDevice device = AudioDevice::BUILT_IN_MIC;
    uint64_t sessionId = 0;
    std::string detail;  // Metadata only — never raw audio data
};

struct AudioStats {
    uint64_t sessionsStarted = 0;
    uint64_t sessionsEnded = 0;
    uint64_t capturesStarted = 0;
    uint64_t capturesCompleted = 0;
    uint64_t capturesDenied = 0;
    uint64_t permissionsChanged = 0;
    uint64_t sessionsExpired = 0;
    uint64_t mockFramesSet = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t routeChanges = 0;
    uint64_t byDevice[6] = {0, 0, 0, 0, 0, 0};
    uint64_t byEventType[17] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Audio Manager
// ============================================================

class AudioManager {
public:
    AudioManager() = default;
    ~AudioManager() = default;

    AudioManager(const AudioManager&) = delete;
    AudioManager& operator=(const AudioManager&) = delete;

    // ---- Lifecycle ----
    AudioResult initialize(size_t maxHistory = 128, size_t maxEvents = 256,
                              size_t maxSessions = 4);
    AudioResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Device control ----
    AudioResult setDeviceEnabled(AudioDevice device, bool enabled,
                                   const std::string& owner = "system");
    bool isDeviceEnabled(AudioDevice device) const;
    AudioDeviceInfo getDeviceInfo(AudioDevice device) const;
    std::vector<AudioDeviceInfo> getDevices() const;
    std::vector<AudioDevice> getAvailableDevices() const;

    // ---- Routing ----
    AudioResult setRoute(AudioRoute route, const std::string& owner = "system");
    AudioRoute getCurrentRoute() const { return currentRoute_; }
    AudioResult setMuted(bool muted, const std::string& owner = "system");
    bool isMuted() const { return muted_; }
    AudioResult setVolume(uint8_t volume, const std::string& owner = "system");
    uint8_t getVolume() const { return volume_; }

    // ---- Permission / policy ----
    AudioResult setAppAudioPolicy(const std::string& appId,
                                    AudioPermission permission,
                                    AudioPrivacyMode privacyMode,
                                    uint32_t privacyFlags = AUDIO_PRIVACY_NONE,
                                    uint32_t captureRateLimit = 0,
                                    const std::string& owner = "system");
    AudioPolicy getAppAudioPolicy(const std::string& appId) const;
    AudioResult clearAppAudioPolicy(const std::string& appId,
                                      const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId, AudioDevice device) const;
    AudioResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Session lifecycle ----
    AudioResult openSession(const std::string& appId, AudioDevice device,
                              AudioCaptureMode mode = AudioCaptureMode::RECORD,
                              uint64_t timeoutMs = 0,
                              uint64_t* outSessionId = nullptr);
    AudioResult closeSession(uint64_t sessionId, const std::string& appId);
    AudioResult pauseSession(uint64_t sessionId, const std::string& appId);
    AudioResult resumeSession(uint64_t sessionId, const std::string& appId);
    AudioResult processSessions();
    size_t getActiveSessionCount() const;
    std::vector<AudioSession> getActiveSessions() const;

    // ---- Capture ----
    AudioResult captureFrame(uint64_t sessionId, const std::string& appId);
    AudioResult getLastFrame(const std::string& appId, AudioDevice device,
                               AudioFrame& out);
    AudioResult requestSingleCapture(const std::string& appId, AudioDevice device,
                                       uint64_t timeoutMs = 0);

    // ---- History / privacy ----
    std::vector<AudioFrame> getHistory(const std::string& appId,
                                         size_t limit = 0,
                                         bool includeMock = false) const;
    AudioResult clearHistory(const std::string& owner = "system");
    AudioResult clearAppHistory(const std::string& appId,
                                  const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    AudioResult setMockEnabled(bool enabled, const std::string& owner = "system");
    AudioResult setMockFrame(AudioDevice device, const AudioFrame& frame,
                               const std::string& owner = "system");
    AudioResult clearMockFrame(AudioDevice device,
                                 const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeMicUsers_.empty(); }
    std::vector<std::string> getActiveMicUsers() const { return activeMicUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<AudioEvent> getEvents(size_t limit = 0) const;
    std::vector<AudioEvent> getEventsByType(AudioEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    AudioResult clearEvents();

    // ---- Stats ----
    AudioStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setFrameCallback(std::function<void(const AudioFrame&, const std::string&)> cb) {
        frameCallback_ = cb;
    }
    void setAccessCallback(std::function<void(const std::string&, AudioResult)> cb) {
        accessCallback_ = cb;
    }
    void setEventCallback(std::function<void(const AudioEvent&)> cb) { eventCallback_ = cb; }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* audioDeviceToString(AudioDevice device);
    static const char* audioRouteToString(AudioRoute route);
    static const char* audioStateToString(AudioState state);
    static const char* audioPermissionToString(AudioPermission permission);
    static const char* requestStateToString(AudioRequestState state);
    static const char* audioPrivacyModeToString(AudioPrivacyMode mode);
    static const char* captureModeToString(AudioCaptureMode mode);
    static const char* audioResultToString(AudioResult result);
    static const char* audioEventTypeToString(AudioEventType type);
    static AudioDevice stringToAudioDevice(const std::string& str);
    static AudioResult stringToAudioResult(const std::string& str);

    // ---- Privacy helpers ----
    static AudioFrame applyPrivacyTransform(const AudioFrame& frame,
                                             AudioPrivacyMode mode,
                                             uint32_t privacyFlags);

private:
    uint64_t getCurrentTimeMs() const;
    uint64_t getCurrentTimeNanos() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(AudioEventType type, AudioResult result,
                     const std::string& appId, AudioDevice device,
                     uint64_t sessionId, const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    AudioResult deliverFrameToSession(AudioSession& session,
                                        const AudioFrame& frame);
    static int deviceIndex(AudioDevice device);
    void initDeviceCapabilities();
    void updatePrivacyIndicator();
    void setStubFrameData(AudioFrame& frame, AudioDevice device);
    AudioRoute deviceToRoute(AudioDevice device) const;

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;
    size_t maxSessions_ = 4;

    AudioDeviceInfo devices_[6];
    AudioFrame lastFrames_[6];

    std::map<std::string, AudioPolicy> appPolicies_;

    std::vector<AudioSession> sessions_;
    uint64_t nextSessionId_ = 1;

    std::vector<AudioFrame> history_;
    std::vector<AudioEvent> events_;
    std::vector<AudioEvent> eventHistory_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    AudioFrame mockFrames_[6];

    std::vector<std::string> activeMicUsers_;
    uint64_t lastAccessTime_ = 0;

    AudioRoute currentRoute_ = AudioRoute::SPEAKER;
    bool muted_ = false;
    uint8_t volume_ = 50;

    AudioStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const AudioFrame&, const std::string&)> frameCallback_;
    std::function<void(const std::string&, AudioResult)> accessCallback_;
    std::function<void(const AudioEvent&)> eventCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace audio
}  // namespace phantom

#endif  // PHANTOM_AUDIO_AUDIO_MANAGER_H
