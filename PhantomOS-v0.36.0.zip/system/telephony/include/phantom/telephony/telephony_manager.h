/*
 * Phantom OS - Telephony / Cellular Identity Manager
 * v0.32.0 - License: GPL-3.0
 *
 * Privacy-first telephony service: SIM/Subscription management, cellular
 * identity control (IMEI/IMSI/ICCID/MSISDN stubs), cell identity/signal
 * information, per-app telephony policy with foreground-only and privacy-
 * indicator enforcement, call-state stubs, SMS metadata stubs, mock SIM/cell
 * data for testing, privacy-transformed history, events, stats, callbacks
 * and optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Identifiers are deterministic stubs,
 * not real telephony identifiers. Privacy transforms are deterministic.
 * The LogServer must never log raw identifiers, phone numbers, SMS bodies
 * or precise cell IDs.
 */

#ifndef PHANTOM_TELEPHONY_TELEPHONY_MANAGER_H
#define PHANTOM_TELEPHONY_TELEPHONY_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace telephony {

// ============================================================
// Constants
// ============================================================

static const uint32_t TELEPHONY_PRIVACY_NONE = 0;
static const uint32_t TELEPHONY_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t TELEPHONY_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t TELEPHONY_PRIVACY_REDACT_IDENTIFIERS = 1 << 2;
static const uint32_t TELEPHONY_PRIVACY_PSEUDONYMIZE = 1 << 3;
static const uint32_t TELEPHONY_PRIVACY_COARSE_CELL = 1 << 4;
static const uint32_t TELEPHONY_PRIVACY_METADATA_ONLY = 1 << 5;
static const uint32_t TELEPHONY_PRIVACY_DISABLE_ROAMING = 1 << 6;
static const uint32_t TELEPHONY_PRIVACY_MOCK_ALLOWED = 1 << 7;
static const uint32_t TELEPHONY_PRIVACY_INDICATOR_REQUIRED = 1 << 8;

static const uint32_t TELEPHONY_DEFAULT_MAX_CALLS = 4;
static const uint32_t TELEPHONY_DEFAULT_MAX_SMS = 100;
static const uint32_t TELEPHONY_DEFAULT_MAX_HISTORY = 128;

// ============================================================
// Enums
// ============================================================

enum class TelephonyRadioTech : uint8_t {
    UNKNOWN = 0,
    GPRS,
    EDGE,
    UMTS,
    HSDPA,
    HSUPA,
    HSPA,
    LTE,
    NR
};

enum class SimState : uint8_t {
    ABSENT = 0,
    READY,
    PIN_LOCKED,
    PUK_LOCKED,
    NETWORK_LOCKED,
    ERROR_STATE
};

enum class NetworkRegistrationState : uint8_t {
    NOT_REGISTERED = 0,
    HOME,
    SEARCHING,
    DENIED,
    UNKNOWN,
    ROAMING
};

enum class DataConnectionState : uint8_t {
    DISCONNECTED = 0,
    CONNECTING,
    CONNECTED,
    SUSPENDED
};

enum class CallState : uint8_t {
    IDLE = 0,
    RINGING,
    DIALING,
    ACTIVE,
    HOLDING,
    DISCONNECTED
};

enum class SmsState : uint8_t {
    NONE = 0,
    RECEIVED,
    SENT,
    BLOCKED,
    FAILED
};

enum class TelephonyPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class TelephonyPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class TelephonyResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    SIM_NOT_READY,
    NOT_REGISTERED,
    CALL_IN_PROGRESS,
    CAPACITY_EXCEEDED,
    MOCK_NOT_ALLOWED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE,
    NO_SUBSCRIPTION
};

enum class TelephonyEventType : uint8_t {
    SIM_STATE_CHANGED = 0,
    NETWORK_REGISTERED,
    NETWORK_DEREGISTERED,
    DATA_CONNECTED,
    DATA_DISCONNECTED,
    CALL_INCOMING,
    CALL_OUTGOING,
    CALL_ACTIVE,
    CALL_ENDED,
    SMS_RECEIVED,
    SMS_SENT,
    SMS_BLOCKED,
    PERMISSION_CHANGED,
    SIM_EXPIRED,
    CELL_INFO_UPDATED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF
};

// ============================================================
// Data structures
// ============================================================

struct SimInfo {
    uint32_t slotIndex = 0;
    SimState state = SimState::ABSENT;
    std::string carrierName;
    std::string mcc;       // Mobile Country Code
    std::string mnc;       // Mobile Network Code
    std::string iccid;     // Integrated Circuit Card Identifier (stub)
    std::string imsi;      // International Mobile Subscriber Identity (stub)
    std::string msisdn;    // Phone number (stub)
    bool roaming = false;
    bool dataEnabled = false;
};

struct SubscriptionInfo {
    uint32_t subscriptionId = 0;
    uint32_t slotIndex = 0;
    std::string carrierName;
    std::string mcc;
    std::string mnc;
    std::string displayName;
    bool dataRoaming = false;
    bool mobileData = false;
};

struct CellIdentity {
    TelephonyRadioTech radioTech = TelephonyRadioTech::UNKNOWN;
    uint32_t mcc = 0;
    uint32_t mnc = 0;
    uint32_t tac = 0;       // Tracking Area Code
    uint32_t ci = 0;        // Cell Identity
    uint32_t pci = 0;       // Physical Cell ID (LTE/NR)
    uint32_t lac = 0;       // Location Area Code (GSM/UMTS)
    uint32_t cid = 0;       // Cell ID (GSM/UMTS)
};

struct CellSignal {
    int32_t signalStrength = 0;  // dBm
    uint32_t level = 0;          // 0-4
    uint32_t rsrp = 0;           // LTE/NR Reference Signal Received Power
    uint32_t rsrq = 0;           // Reference Signal Received Quality
    uint32_t rssi = 0;           // Received Signal Strength Indicator
    uint32_t snr = 0;            // Signal-to-Noise Ratio
};

struct TelephonyPolicy {
    std::string appId;
    TelephonyPermission permission = TelephonyPermission::DENY;
    TelephonyPrivacyMode privacyMode = TelephonyPrivacyMode::FULL;
    uint32_t privacyFlags = TELEPHONY_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
    std::string pseudonym;   // Per-app pseudonym for identifiers
};

struct CallSession {
    uint64_t id = 0;
    std::string appId;
    std::string number;     // Phone number (stub)
    CallState state = CallState::IDLE;
    uint64_t createdAt = 0;
    uint64_t endedAt = 0;
    bool incoming = false;
    uint64_t durationMs = 0;
};

struct SmsMessageStub {
    uint64_t id = 0;
    std::string appId;
    std::string sender;     // Sender (stub)
    std::string body;       // Message body (stub, only if allowed)
    uint64_t timestamp = 0;
    SmsState state = SmsState::NONE;
    bool incoming = false;
};

struct TelephonyEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    TelephonyEventType type = TelephonyEventType::SIM_STATE_CHANGED;
    TelephonyResult result = TelephonyResult::SUCCESS;
    std::string appId;
    uint64_t sessionId = 0;
    std::string detail;     // Metadata only — never raw identifiers
};

struct TelephonyStats {
    uint64_t callsStarted = 0;
    uint64_t callsEnded = 0;
    uint64_t smsReceived = 0;
    uint64_t smsSent = 0;
    uint64_t smsBlocked = 0;
    uint64_t permissionsChanged = 0;
    uint64_t cellInfoUpdates = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t dataConnections = 0;
    uint64_t byEventType[18] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Telephony Manager
// ============================================================

class TelephonyManager {
public:
    TelephonyManager() = default;
    ~TelephonyManager() = default;

    TelephonyManager(const TelephonyManager&) = delete;
    TelephonyManager& operator=(const TelephonyManager&) = delete;

    // ---- Lifecycle ----
    TelephonyResult initialize(size_t maxHistory = 128, size_t maxEvents = 256,
                                 size_t maxCalls = 4, size_t maxSms = 100);
    TelephonyResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- SIM / Subscription ----
    TelephonyResult setSimState(uint32_t slotIndex, SimState state,
                                  const std::string& owner = "system");
    SimInfo getSimInfo(uint32_t slotIndex) const;
    std::vector<SimInfo> getAllSimInfo() const;
    TelephonyResult setSubscription(const SubscriptionInfo& sub,
                                      const std::string& owner = "system");
    SubscriptionInfo getSubscription(uint32_t subscriptionId) const;
    std::vector<SubscriptionInfo> getActiveSubscriptions() const;
    bool isSimReady() const;
    bool isDataEnabled() const;

    // ---- Network registration ----
    TelephonyResult setNetworkRegistration(NetworkRegistrationState state,
                                             const std::string& owner = "system");
    NetworkRegistrationState getNetworkRegistration() const { return networkRegState_; }
    TelephonyResult setDataConnection(DataConnectionState state,
                                       const std::string& owner = "system");
    DataConnectionState getDataConnection() const { return dataConnState_; }
    bool isRegistered() const;

    // ---- Cell info / signal ----
    TelephonyResult setCellIdentity(const CellIdentity& cell,
                                     const std::string& owner = "system");
    CellIdentity getCellIdentity() const { return cellIdentity_; }
    TelephonyResult setCellSignal(const CellSignal& signal,
                                   const std::string& owner = "system");
    CellSignal getCellSignal() const { return cellSignal_; }
    TelephonyRadioTech getRadioTech() const { return cellIdentity_.radioTech; }

    // ---- Permission / policy ----
    TelephonyResult setAppTelephonyPolicy(const std::string& appId,
                                            TelephonyPermission permission,
                                            TelephonyPrivacyMode privacyMode,
                                            uint32_t privacyFlags = TELEPHONY_PRIVACY_NONE,
                                            const std::string& pseudonym = "",
                                            const std::string& owner = "system");
    TelephonyPolicy getAppTelephonyPolicy(const std::string& appId) const;
    TelephonyResult clearAppTelephonyPolicy(const std::string& appId,
                                             const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    TelephonyResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Call stubs ----
    TelephonyResult startCall(const std::string& appId, const std::string& number,
                                bool incoming, uint64_t* outCallId = nullptr);
    TelephonyResult endCall(uint64_t callId, const std::string& appId);
    TelephonyResult setCallState(uint64_t callId, CallState state,
                                   const std::string& appId);
    std::vector<CallSession> getActiveCalls() const;
    size_t getActiveCallCount() const;

    // ---- SMS stubs ----
    TelephonyResult receiveSms(const std::string& appId, const std::string& sender,
                                 const std::string& body);
    TelephonyResult sendSms(const std::string& appId, const std::string& recipient,
                              const std::string& body);
    std::vector<SmsMessageStub> getSmsHistory(const std::string& appId,
                                                size_t limit = 0) const;
    size_t getSmsCount() const { return smsHistory_.size(); }

    // ---- Identifier access ----
    TelephonyResult getSimIdentifiers(const std::string& appId, SimInfo& out);
    TelephonyResult getCellInfo(const std::string& appId, CellIdentity& out);
    TelephonyResult getCellSignal(const std::string& appId, CellSignal& out);

    // ---- History / privacy ----
    std::vector<TelephonyEvent> getHistory(const std::string& appId,
                                             size_t limit = 0) const;
    TelephonyResult clearHistory(const std::string& owner = "system");
    TelephonyResult clearAppHistory(const std::string& appId,
                                      const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    TelephonyResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    TelephonyResult setMockSim(const SimInfo& sim, const std::string& owner = "system");
    TelephonyResult setMockCell(const CellIdentity& cell, const CellSignal& signal,
                                 const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeTelephonyUsers_.empty(); }
    std::vector<std::string> getActiveTelephonyUsers() const { return activeTelephonyUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<TelephonyEvent> getEvents(size_t limit = 0) const;
    std::vector<TelephonyEvent> getEventsByType(TelephonyEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    TelephonyResult clearEvents();

    // ---- Stats ----
    TelephonyStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const TelephonyEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, TelephonyResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* radioTechToString(TelephonyRadioTech tech);
    static const char* simStateToString(SimState state);
    static const char* networkRegToString(NetworkRegistrationState state);
    static const char* dataConnToString(DataConnectionState state);
    static const char* callStateToString(CallState state);
    static const char* smsStateToString(SmsState state);
    static const char* permissionToString(TelephonyPermission permission);
    static const char* privacyModeToString(TelephonyPrivacyMode mode);
    static const char* resultToString(TelephonyResult result);
    static const char* eventTypeToString(TelephonyEventType type);
    static TelephonyRadioTech stringToRadioTech(const std::string& str);
    static TelephonyResult stringToResult(const std::string& str);

    // ---- Privacy helpers ----
    static SimInfo applyPrivacyTransform(const SimInfo& sim, TelephonyPrivacyMode mode,
                                           uint32_t privacyFlags,
                                           const std::string& pseudonym = "");
    static CellIdentity applyCellPrivacyTransform(const CellIdentity& cell,
                                                    TelephonyPrivacyMode mode,
                                                    uint32_t privacyFlags);
    static SmsMessageStub applySmsPrivacyTransform(const SmsMessageStub& sms,
                                                     TelephonyPrivacyMode mode,
                                                     uint32_t privacyFlags);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(TelephonyEventType type, TelephonyResult result,
                     const std::string& appId, uint64_t sessionId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void setStubSimData();
    void setStubCellData();

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;
    size_t maxCalls_ = 4;
    size_t maxSms_ = 100;

    SimInfo sims_[2];           // Up to 2 SIM slots
    SubscriptionInfo subscriptions_[2];
    NetworkRegistrationState networkRegState_ = NetworkRegistrationState::NOT_REGISTERED;
    DataConnectionState dataConnState_ = DataConnectionState::DISCONNECTED;
    CellIdentity cellIdentity_;
    CellSignal cellSignal_;

    std::map<std::string, TelephonyPolicy> appPolicies_;

    std::vector<CallSession> calls_;
    uint64_t nextCallId_ = 1;

    std::vector<SmsMessageStub> smsHistory_;
    uint64_t nextSmsId_ = 1;

    std::vector<TelephonyEvent> history_;
    std::vector<TelephonyEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;

    std::vector<std::string> activeTelephonyUsers_;
    uint64_t lastAccessTime_ = 0;

    TelephonyStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const TelephonyEvent&)> eventCallback_;
    std::function<void(const std::string&, TelephonyResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace telephony
}  // namespace phantom

#endif  // PHANTOM_TELEPHONY_TELEPHONY_MANAGER_H
