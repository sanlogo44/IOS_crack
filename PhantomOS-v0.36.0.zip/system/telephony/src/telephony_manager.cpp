/*
 * Phantom OS - Telephony / Cellular Identity Manager
 * v0.32.0 - License: GPL-3.0
 *
 * Implementation of TelephonyManager: privacy-first telephony service
 * with SIM/Subscription management, cellular identity control, cell info,
 * per-app policy, call/SMS stubs, mock support, privacy-transformed
 * history, events, stats, callbacks and optional LogServer/CrashReporter
 * integration.
 */

#include "phantom/telephony/telephony_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <chrono>
#include <algorithm>
#include <cstring>

namespace phantom {
namespace telephony {

// ============================================================
// Private helpers
// ============================================================

uint64_t TelephonyManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool TelephonyManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "android" || app == "com.android.system";
}

void TelephonyManager::setStubSimData() {
    // SIM slot 0: ready with stub carrier
    sims_[0] = {};
    sims_[0].slotIndex = 0;
    sims_[0].state = SimState::READY;
    sims_[0].carrierName = "PhantomMobile";
    sims_[0].mcc = "262";
    sims_[0].mnc = "42";
    sims_[0].iccid = "8949010000000000001";
    sims_[0].imsi = "262420000000001";
    sims_[0].msisdn = "+4915112345678";
    sims_[0].roaming = false;
    sims_[0].dataEnabled = true;

    // SIM slot 1: absent
    sims_[1] = {};
    sims_[1].slotIndex = 1;
    sims_[1].state = SimState::ABSENT;

    // Subscriptions
    subscriptions_[0] = {};
    subscriptions_[0].subscriptionId = 1;
    subscriptions_[0].slotIndex = 0;
    subscriptions_[0].carrierName = "PhantomMobile";
    subscriptions_[0].mcc = "262";
    subscriptions_[0].mnc = "42";
    subscriptions_[0].displayName = "PhantomMobile";
    subscriptions_[0].mobileData = true;

    subscriptions_[1] = {};
    subscriptions_[1].subscriptionId = 0;
    subscriptions_[1].slotIndex = 1;
}

void TelephonyManager::setStubCellData() {
    cellIdentity_ = {};
    cellIdentity_.radioTech = TelephonyRadioTech::LTE;
    cellIdentity_.mcc = 262;
    cellIdentity_.mnc = 42;
    cellIdentity_.tac = 1234;
    cellIdentity_.ci = 56789;
    cellIdentity_.pci = 100;
    cellIdentity_.lac = 0;
    cellIdentity_.cid = 0;

    cellSignal_ = {};
    cellSignal_.signalStrength = -85;
    cellSignal_.level = 3;
    cellSignal_.rsrp = 95;
    cellSignal_.rsrq = 12;
    cellSignal_.rssi = 85;
    cellSignal_.snr = 15;
}

void TelephonyManager::updatePrivacyIndicator() {
    lastAccessTime_ = getCurrentTimeMs();
}

void TelephonyManager::recordEvent(TelephonyEventType type, TelephonyResult result,
                                     const std::string& appId, uint64_t sessionId,
                                     const std::string& detail) {
    TelephonyEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.sessionId = sessionId;
    event.detail = detail;

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        events_.erase(events_.begin());
    }

    // Also add to history (privacy-filtered)
    if (!(appPolicies_.count(appId) > 0 &&
          (appPolicies_.at(appId).privacyFlags & TELEPHONY_PRIVACY_NO_HISTORY))) {
        history_.insert(history_.begin(), event);
        if (history_.size() > maxHistory_) {
            history_.resize(maxHistory_);
        }
    }

    int et = static_cast<int>(type);
    if (et >= 0 && et < 18) stats_.byEventType[et]++;
    int ri = static_cast<int>(result);
    if (ri >= 0 && ri < 15) stats_.byResult[ri]++;

    if (eventCallback_) eventCallback_(event);
}

void TelephonyManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    // Never log raw identifiers, phone numbers, SMS bodies, or precise cell IDs
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "TelephonyManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "TelephonyManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "TelephonyManager");
    }
}

void TelephonyManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("TelephonyManager", "TelephonyManager", 0, reason);
}

// ============================================================
// Lifecycle
// ============================================================

TelephonyResult TelephonyManager::initialize(size_t maxHistory, size_t maxEvents,
                                                 size_t maxCalls, size_t maxSms) {
    if (initialized_) return TelephonyResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxCalls == 0 || maxSms == 0) {
        return TelephonyResult::INVALID_PARAMETER;
    }

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxCalls_ = maxCalls;
    maxSms_ = maxSms;

    setStubSimData();
    setStubCellData();

    networkRegState_ = NetworkRegistrationState::HOME;
    dataConnState_ = DataConnectionState::CONNECTED;
    stats_.dataConnections = 1;

    initialized_ = true;

    logToServer("INFO", "TelephonyManager initialized");
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::shutdown() {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;

    appPolicies_.clear();
    calls_.clear();
    smsHistory_.clear();
    history_.clear();
    events_.clear();
    nextCallId_ = 1;
    nextSmsId_ = 1;
    nextEventId_ = 1;
    activeTelephonyUsers_.clear();
    lastAccessTime_ = 0;

    for (size_t i = 0; i < 2; ++i) {
        sims_[i] = SimInfo{};
        subscriptions_[i] = SubscriptionInfo{};
    }
    cellIdentity_ = CellIdentity{};
    cellSignal_ = CellSignal{};
    networkRegState_ = NetworkRegistrationState::NOT_REGISTERED;
    dataConnState_ = DataConnectionState::DISCONNECTED;
    mockEnabled_ = false;
    stats_ = TelephonyStats{};
    initialized_ = false;
    return TelephonyResult::SUCCESS;
}

// ============================================================
// SIM / Subscription
// ============================================================

TelephonyResult TelephonyManager::setSimState(uint32_t slotIndex, SimState state,
                                                 const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (slotIndex >= 2) return TelephonyResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    SimState oldState = sims_[slotIndex].state;
    sims_[slotIndex].state = state;
    sims_[slotIndex].slotIndex = slotIndex;

    recordEvent(TelephonyEventType::SIM_STATE_CHANGED, TelephonyResult::SUCCESS,
                 "system", 0, std::string("SIM") + std::to_string(slotIndex) + ":" + simStateToString(state));
    logToServer("INFO", std::string("SIM slot ") + std::to_string(slotIndex) +
                " state: " + simStateToString(state));
    return TelephonyResult::SUCCESS;
}

SimInfo TelephonyManager::getSimInfo(uint32_t slotIndex) const {
    if (slotIndex >= 2) return SimInfo{};
    return sims_[slotIndex];
}

std::vector<SimInfo> TelephonyManager::getAllSimInfo() const {
    std::vector<SimInfo> result;
    for (size_t i = 0; i < 2; ++i) {
        result.push_back(sims_[i]);
    }
    return result;
}

TelephonyResult TelephonyManager::setSubscription(const SubscriptionInfo& sub,
                                                    const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;
    if (sub.slotIndex >= 2) return TelephonyResult::INVALID_PARAMETER;

    subscriptions_[sub.slotIndex] = sub;
    return TelephonyResult::SUCCESS;
}

SubscriptionInfo TelephonyManager::getSubscription(uint32_t subscriptionId) const {
    for (size_t i = 0; i < 2; ++i) {
        if (subscriptions_[i].subscriptionId == subscriptionId) {
            return subscriptions_[i];
        }
    }
    return SubscriptionInfo{};
}

std::vector<SubscriptionInfo> TelephonyManager::getActiveSubscriptions() const {
    std::vector<SubscriptionInfo> result;
    for (size_t i = 0; i < 2; ++i) {
        if (sims_[i].state == SimState::READY) {
            result.push_back(subscriptions_[i]);
        }
    }
    return result;
}

bool TelephonyManager::isSimReady() const {
    for (size_t i = 0; i < 2; ++i) {
        if (sims_[i].state == SimState::READY) return true;
    }
    return false;
}

bool TelephonyManager::isDataEnabled() const {
    for (size_t i = 0; i < 2; ++i) {
        if (sims_[i].state == SimState::READY && sims_[i].dataEnabled) return true;
    }
    return false;
}

// ============================================================
// Network registration
// ============================================================

TelephonyResult TelephonyManager::setNetworkRegistration(NetworkRegistrationState state,
                                                             const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    NetworkRegistrationState oldState = networkRegState_;
    networkRegState_ = state;

    if (state == NetworkRegistrationState::HOME || state == NetworkRegistrationState::ROAMING) {
        recordEvent(TelephonyEventType::NETWORK_REGISTERED, TelephonyResult::SUCCESS,
                     "system", 0, networkRegToString(state));
    } else {
        recordEvent(TelephonyEventType::NETWORK_DEREGISTERED, TelephonyResult::SUCCESS,
                     "system", 0, networkRegToString(state));
    }
    logToServer("INFO", std::string("Network registration: ") + networkRegToString(state));
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::setDataConnection(DataConnectionState state,
                                                       const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    DataConnectionState oldState = dataConnState_;
    dataConnState_ = state;

    if (state == DataConnectionState::CONNECTED) {
        stats_.dataConnections++;
        recordEvent(TelephonyEventType::DATA_CONNECTED, TelephonyResult::SUCCESS,
                     "system", 0, "DATA_UP");
    } else if (oldState == DataConnectionState::CONNECTED) {
        recordEvent(TelephonyEventType::DATA_DISCONNECTED, TelephonyResult::SUCCESS,
                     "system", 0, "DATA_DOWN");
    }
    return TelephonyResult::SUCCESS;
}

bool TelephonyManager::isRegistered() const {
    return networkRegState_ == NetworkRegistrationState::HOME ||
           networkRegState_ == NetworkRegistrationState::ROAMING;
}

// ============================================================
// Cell info / signal
// ============================================================

TelephonyResult TelephonyManager::setCellIdentity(const CellIdentity& cell,
                                                     const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    cellIdentity_ = cell;
    stats_.cellInfoUpdates++;
    recordEvent(TelephonyEventType::CELL_INFO_UPDATED, TelephonyResult::SUCCESS,
                 "system", 0, "CELL_UPDATE");
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::setCellSignal(const CellSignal& signal,
                                                  const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    cellSignal_ = signal;
    return TelephonyResult::SUCCESS;
}

// ============================================================
// Permission / policy
// ============================================================

TelephonyResult TelephonyManager::setAppTelephonyPolicy(const std::string& appId,
                                                            TelephonyPermission permission,
                                                            TelephonyPrivacyMode privacyMode,
                                                            uint32_t privacyFlags,
                                                            const std::string& pseudonym,
                                                            const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (appId.empty()) return TelephonyResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    TelephonyPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.lastGrantedAt = getCurrentTimeMs();
    policy.pseudonym = pseudonym;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(TelephonyEventType::PERMISSION_CHANGED, TelephonyResult::SUCCESS,
                 appId, 0, "POLICY_SET");
    logToServer("INFO", "Policy set for app: " + appId);
    return TelephonyResult::SUCCESS;
}

TelephonyPolicy TelephonyManager::getAppTelephonyPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return TelephonyPolicy{};
}

TelephonyResult TelephonyManager::clearAppTelephonyPolicy(const std::string& appId,
                                                            const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return TelephonyResult::SUCCESS;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    recordEvent(TelephonyEventType::PERMISSION_CHANGED, TelephonyResult::SUCCESS,
                 appId, 0, "POLICY_CLEARED");
    return TelephonyResult::SUCCESS;
}

bool TelephonyManager::checkAppAccess(const std::string& appId) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    switch (policy.permission) {
        case TelephonyPermission::DENY:
            return false;
        case TelephonyPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case TelephonyPermission::ALLOW_ALWAYS:
            return true;
        case TelephonyPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

TelephonyResult TelephonyManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return TelephonyResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return TelephonyResult::SUCCESS;
}

// ============================================================
// Call stubs
// ============================================================

TelephonyResult TelephonyManager::startCall(const std::string& appId, const std::string& number,
                                              bool incoming, uint64_t* outCallId) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (appId.empty()) return TelephonyResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId)) {
        stats_.totalFailures++;
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        recordEvent(incoming ? TelephonyEventType::CALL_INCOMING : TelephonyEventType::CALL_OUTGOING,
                     TelephonyResult::PERMISSION_DENIED, appId, 0, "ACCESS_DENIED");
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isSimReady()) return TelephonyResult::SIM_NOT_READY;
    if (!isRegistered()) return TelephonyResult::NOT_REGISTERED;

    // Check if too many active calls
    size_t activeCalls = 0;
    for (const auto& c : calls_) {
        if (c.state != CallState::IDLE && c.state != CallState::DISCONNECTED) {
            activeCalls++;
        }
    }
    if (activeCalls >= maxCalls_) return TelephonyResult::CAPACITY_EXCEEDED;

    CallSession call;
    call.id = nextCallId_++;
    call.appId = appId;
    call.number = number;
    call.state = incoming ? CallState::RINGING : CallState::DIALING;
    call.createdAt = getCurrentTimeMs();
    call.incoming = incoming;

    if (outCallId) *outCallId = call.id;
    calls_.push_back(call);
    stats_.callsStarted++;

    // Update privacy indicator
    if (std::find(activeTelephonyUsers_.begin(), activeTelephonyUsers_.end(), appId) ==
        activeTelephonyUsers_.end()) {
        activeTelephonyUsers_.push_back(appId);
        recordEvent(TelephonyEventType::INDICATOR_ON, TelephonyResult::SUCCESS,
                     appId, call.id, "INDICATOR_ON");
        stats_.indicatorToggleCount++;
    }
    updatePrivacyIndicator();

    recordEvent(incoming ? TelephonyEventType::CALL_INCOMING : TelephonyEventType::CALL_OUTGOING,
                 TelephonyResult::SUCCESS, appId, call.id,
                 incoming ? "INCOMING" : "OUTGOING");
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::endCall(uint64_t callId, const std::string& appId) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }

    for (auto& call : calls_) {
        if (call.id != callId) continue;
        if (call.appId != appId && !isSystemOwner(appId)) return TelephonyResult::PERMISSION_DENIED;
        if (call.state == CallState::DISCONNECTED) return TelephonyResult::BAD_STATE;

        call.state = CallState::DISCONNECTED;
        call.endedAt = getCurrentTimeMs();
        call.durationMs = call.endedAt - call.createdAt;
        stats_.callsEnded++;

        // Update privacy indicator
        bool hasOtherActive = false;
        for (const auto& c : calls_) {
            if (c.appId == call.appId && c.id != callId &&
                c.state != CallState::IDLE && c.state != CallState::DISCONNECTED) {
                hasOtherActive = true;
                break;
            }
        }
        if (!hasOtherActive) {
            // Also check SMS activity
            bool hasSmsActivity = false;
            for (const auto& s : smsHistory_) {
                if (s.appId == call.appId && s.state != SmsState::NONE) {
                    hasSmsActivity = true;
                    break;
                }
            }
            if (!hasSmsActivity) {
                auto userIt = std::find(activeTelephonyUsers_.begin(), activeTelephonyUsers_.end(),
                                         call.appId);
                if (userIt != activeTelephonyUsers_.end()) {
                    activeTelephonyUsers_.erase(userIt);
                    recordEvent(TelephonyEventType::INDICATOR_OFF, TelephonyResult::SUCCESS,
                                 call.appId, callId, "INDICATOR_OFF");
                    stats_.indicatorToggleCount++;
                }
            }
        }

        recordEvent(TelephonyEventType::CALL_ENDED, TelephonyResult::SUCCESS,
                     call.appId, callId, "CALL_END");
        return TelephonyResult::SUCCESS;
    }
    return TelephonyResult::INVALID_PARAMETER;
}

TelephonyResult TelephonyManager::setCallState(uint64_t callId, CallState state,
                                                 const std::string& appId) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;

    for (auto& call : calls_) {
        if (call.id != callId) continue;
        if (call.appId != appId && !isSystemOwner(appId)) return TelephonyResult::PERMISSION_DENIED;
        if (call.state == CallState::DISCONNECTED) return TelephonyResult::BAD_STATE;

        call.state = state;
        if (state == CallState::ACTIVE) {
            recordEvent(TelephonyEventType::CALL_ACTIVE, TelephonyResult::SUCCESS,
                         appId, callId, "ACTIVE");
        }
        return TelephonyResult::SUCCESS;
    }
    return TelephonyResult::INVALID_PARAMETER;
}

std::vector<CallSession> TelephonyManager::getActiveCalls() const {
    std::vector<CallSession> result;
    for (const auto& c : calls_) {
        if (c.state != CallState::IDLE && c.state != CallState::DISCONNECTED) {
            result.push_back(c);
        }
    }
    return result;
}

size_t TelephonyManager::getActiveCallCount() const {
    size_t count = 0;
    for (const auto& c : calls_) {
        if (c.state != CallState::IDLE && c.state != CallState::DISCONNECTED) {
            count++;
        }
    }
    return count;
}

// ============================================================
// SMS stubs
// ============================================================

TelephonyResult TelephonyManager::receiveSms(const std::string& appId, const std::string& sender,
                                                const std::string& body) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (!checkAppAccess(appId)) {
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        recordEvent(TelephonyEventType::SMS_BLOCKED, TelephonyResult::PERMISSION_DENIED,
                     appId, 0, "ACCESS_DENIED");
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isSimReady()) return TelephonyResult::SIM_NOT_READY;
    if (smsHistory_.size() >= maxSms_) return TelephonyResult::CAPACITY_EXCEEDED;

    SmsMessageStub sms;
    sms.id = nextSmsId_++;
    sms.appId = appId;
    sms.sender = sender;
    sms.body = body;
    sms.timestamp = getCurrentTimeMs();
    sms.state = SmsState::RECEIVED;
    sms.incoming = true;

    // Apply privacy transform
    auto policy = getAppTelephonyPolicy(appId);
    sms = applySmsPrivacyTransform(sms, policy.privacyMode, policy.privacyFlags);

    smsHistory_.push_back(sms);
    stats_.smsReceived++;

    // Update privacy indicator
    if (std::find(activeTelephonyUsers_.begin(), activeTelephonyUsers_.end(), appId) ==
        activeTelephonyUsers_.end()) {
        activeTelephonyUsers_.push_back(appId);
        stats_.indicatorToggleCount++;
    }
    updatePrivacyIndicator();

    recordEvent(TelephonyEventType::SMS_RECEIVED, TelephonyResult::SUCCESS,
                 appId, sms.id, "SMS_RX");
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::sendSms(const std::string& appId, const std::string& recipient,
                                            const std::string& body) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (!checkAppAccess(appId)) {
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        recordEvent(TelephonyEventType::SMS_BLOCKED, TelephonyResult::PERMISSION_DENIED,
                     appId, 0, "ACCESS_DENIED");
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isSimReady()) return TelephonyResult::SIM_NOT_READY;
    if (!isRegistered()) return TelephonyResult::NOT_REGISTERED;
    if (smsHistory_.size() >= maxSms_) return TelephonyResult::CAPACITY_EXCEEDED;

    SmsMessageStub sms;
    sms.id = nextSmsId_++;
    sms.appId = appId;
    sms.sender = recipient;
    sms.body = body;
    sms.timestamp = getCurrentTimeMs();
    sms.state = SmsState::SENT;
    sms.incoming = false;

    // Apply privacy transform
    auto policy = getAppTelephonyPolicy(appId);
    sms = applySmsPrivacyTransform(sms, policy.privacyMode, policy.privacyFlags);

    smsHistory_.push_back(sms);
    stats_.smsSent++;

    // Update privacy indicator
    if (std::find(activeTelephonyUsers_.begin(), activeTelephonyUsers_.end(), appId) ==
        activeTelephonyUsers_.end()) {
        activeTelephonyUsers_.push_back(appId);
        stats_.indicatorToggleCount++;
    }
    updatePrivacyIndicator();

    recordEvent(TelephonyEventType::SMS_SENT, TelephonyResult::SUCCESS,
                 appId, sms.id, "SMS_TX");
    return TelephonyResult::SUCCESS;
}

std::vector<SmsMessageStub> TelephonyManager::getSmsHistory(const std::string& appId,
                                                                size_t limit) const {
    std::vector<SmsMessageStub> result;
    for (const auto& sms : smsHistory_) {
        if (sms.appId == appId) {
            result.push_back(sms);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

// ============================================================
// Identifier access
// ============================================================

TelephonyResult TelephonyManager::getSimIdentifiers(const std::string& appId, SimInfo& out) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return TelephonyResult::SIMULATED_FAILURE; }
    if (!checkAppAccess(appId)) {
        stats_.totalFailures++;
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        recordEvent(TelephonyEventType::PRIVACY_APPLIED, TelephonyResult::PERMISSION_DENIED,
                     appId, 0, "ACCESS_DENIED");
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isSimReady()) return TelephonyResult::SIM_NOT_READY;

    SimInfo sim = sims_[0];  // Return first ready SIM
    auto policy = getAppTelephonyPolicy(appId);
    out = applyPrivacyTransform(sim, policy.privacyMode, policy.privacyFlags, policy.pseudonym);

    if (policy.privacyMode != TelephonyPrivacyMode::FULL || policy.privacyFlags != TELEPHONY_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == TelephonyPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    updatePrivacyIndicator();
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::getCellInfo(const std::string& appId, CellIdentity& out) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId)) {
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isRegistered()) return TelephonyResult::NOT_REGISTERED;

    auto policy = getAppTelephonyPolicy(appId);
    out = applyCellPrivacyTransform(cellIdentity_, policy.privacyMode, policy.privacyFlags);

    if (policy.privacyMode != TelephonyPrivacyMode::FULL || policy.privacyFlags != TELEPHONY_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    updatePrivacyIndicator();
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::getCellSignal(const std::string& appId, CellSignal& out) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId)) {
        if (accessCallback_) accessCallback_(appId, TelephonyResult::PERMISSION_DENIED);
        return TelephonyResult::PERMISSION_DENIED;
    }

    if (!isRegistered()) return TelephonyResult::NOT_REGISTERED;

    auto policy = getAppTelephonyPolicy(appId);
    out = cellSignal_;

    // METADATA_ONLY or COARSE_CELL: zero out precise signal
    if (policy.privacyMode == TelephonyPrivacyMode::METADATA_ONLY ||
        (policy.privacyFlags & TELEPHONY_PRIVACY_COARSE_CELL)) {
        out.rsrp = 0;
        out.rsrq = 0;
        out.snr = 0;
        // Keep only level (coarse)
        out.signalStrength = 0;
    }

    updatePrivacyIndicator();
    return TelephonyResult::SUCCESS;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<TelephonyEvent> TelephonyManager::getHistory(const std::string& appId,
                                                              size_t limit) const {
    std::vector<TelephonyEvent> result;
    for (const auto& event : history_) {
        if (event.appId == appId || isSystemOwner(appId)) {
            result.push_back(event);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

TelephonyResult TelephonyManager::clearHistory(const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    // Record event only to events_, not to history_ (already cleared)
    TelephonyEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = TelephonyEventType::PRIVACY_APPLIED;
    event.result = TelephonyResult::SUCCESS;
    event.appId = "system";
    event.detail = "CLEAR_ALL";
    events_.push_back(event);
    if (events_.size() > maxEvents_) events_.erase(events_.begin());
    int et = static_cast<int>(TelephonyEventType::PRIVACY_APPLIED);
    if (et >= 0 && et < 18) stats_.byEventType[et]++;
    if (eventCallback_) eventCallback_(event);
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::clearAppHistory(const std::string& appId,
                                                     const std::string& requester) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (appId != requester && !isSystemOwner(requester)) return TelephonyResult::PERMISSION_DENIED;

    stats_.historyClears++;
    recordEvent(TelephonyEventType::PRIVACY_APPLIED, TelephonyResult::SUCCESS,
                 appId, 0, "CLEAR_APP");
    return TelephonyResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

TelephonyResult TelephonyManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;
    mockEnabled_ = enabled;
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::setMockSim(const SimInfo& sim, const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) {
        auto policy = getAppTelephonyPolicy(owner);
        if (!(policy.privacyFlags & TELEPHONY_PRIVACY_MOCK_ALLOWED)) {
            return TelephonyResult::MOCK_NOT_ALLOWED;
        }
    }
    if (sim.slotIndex >= 2) return TelephonyResult::INVALID_PARAMETER;
    sims_[sim.slotIndex] = sim;
    return TelephonyResult::SUCCESS;
}

TelephonyResult TelephonyManager::setMockCell(const CellIdentity& cell, const CellSignal& signal,
                                                 const std::string& owner) {
    if (!initialized_) return TelephonyResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return TelephonyResult::PERMISSION_DENIED;
    cellIdentity_ = cell;
    cellSignal_ = signal;
    stats_.cellInfoUpdates++;
    return TelephonyResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<TelephonyEvent> TelephonyManager::getEvents(size_t limit) const {
    if (limit == 0 || limit >= events_.size()) return events_;
    return std::vector<TelephonyEvent>(events_.end() - limit, events_.end());
}

std::vector<TelephonyEvent> TelephonyManager::getEventsByType(TelephonyEventType type) const {
    std::vector<TelephonyEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) result.push_back(event);
    }
    return result;
}

TelephonyResult TelephonyManager::clearEvents() {
    events_.clear();
    return TelephonyResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void TelephonyManager::resetStats() {
    stats_ = TelephonyStats{};
}

// ============================================================
// Privacy helpers
// ============================================================

SimInfo TelephonyManager::applyPrivacyTransform(const SimInfo& sim, TelephonyPrivacyMode mode,
                                                  uint32_t privacyFlags,
                                                  const std::string& pseudonym) {
    SimInfo result = sim;

    if (mode == TelephonyPrivacyMode::FULL && privacyFlags == TELEPHONY_PRIVACY_NONE) {
        return result;
    }

    // REDACTED mode or REDACT_IDENTIFIERS flag: clear sensitive identifiers
    if (mode == TelephonyPrivacyMode::REDACTED || (privacyFlags & TELEPHONY_PRIVACY_REDACT_IDENTIFIERS)) {
        result.iccid.clear();
        result.imsi.clear();
        result.msisdn.clear();
    }

    // PSEUDONYMIZE: replace identifiers with pseudonym
    if (privacyFlags & TELEPHONY_PRIVACY_PSEUDONYMIZE) {
        if (!pseudonym.empty()) {
            result.imsi = "pseudonym:" + pseudonym;
            result.msisdn = "pseudonym:" + pseudonym;
            result.iccid = "pseudonym:" + pseudonym;
        } else {
            result.imsi.clear();
            result.msisdn.clear();
            result.iccid.clear();
        }
    }

    // METADATA_ONLY mode: clear all identifiers, keep only carrier/MCC/MNC
    if (mode == TelephonyPrivacyMode::METADATA_ONLY || (privacyFlags & TELEPHONY_PRIVACY_METADATA_ONLY)) {
        result.iccid.clear();
        result.imsi.clear();
        result.msisdn.clear();
    }

    // DISABLE_ROAMING: clear roaming info
    if (privacyFlags & TELEPHONY_PRIVACY_DISABLE_ROAMING) {
        result.roaming = false;
    }

    return result;
}

CellIdentity TelephonyManager::applyCellPrivacyTransform(const CellIdentity& cell,
                                                            TelephonyPrivacyMode mode,
                                                            uint32_t privacyFlags) {
    CellIdentity result = cell;

    if (mode == TelephonyPrivacyMode::FULL && privacyFlags == TELEPHONY_PRIVACY_NONE) {
        return result;
    }

    // COARSE_CELL: zero out precise cell IDs
    if (privacyFlags & TELEPHONY_PRIVACY_COARSE_CELL) {
        result.ci = 0;
        result.pci = 0;
        result.cid = 0;
        result.tac = 0;
        result.lac = 0;
    }

    // METADATA_ONLY: zero out everything except radio tech
    if (mode == TelephonyPrivacyMode::METADATA_ONLY || (privacyFlags & TELEPHONY_PRIVACY_METADATA_ONLY)) {
        result.mcc = 0;
        result.mnc = 0;
        result.tac = 0;
        result.ci = 0;
        result.pci = 0;
        result.lac = 0;
        result.cid = 0;
    }

    return result;
}

SmsMessageStub TelephonyManager::applySmsPrivacyTransform(const SmsMessageStub& sms,
                                                            TelephonyPrivacyMode mode,
                                                            uint32_t privacyFlags) {
    SmsMessageStub result = sms;

    if (mode == TelephonyPrivacyMode::FULL && privacyFlags == TELEPHONY_PRIVACY_NONE) {
        return result;
    }

    // REDACTED mode: clear body
    if (mode == TelephonyPrivacyMode::REDACTED) {
        result.body.clear();
    }

    // METADATA_ONLY: clear body and sender
    if (mode == TelephonyPrivacyMode::METADATA_ONLY || (privacyFlags & TELEPHONY_PRIVACY_METADATA_ONLY)) {
        result.body.clear();
        result.sender.clear();
    }

    return result;
}

// ============================================================
// String helpers
// ============================================================

const char* TelephonyManager::radioTechToString(TelephonyRadioTech tech) {
    switch (tech) {
        case TelephonyRadioTech::UNKNOWN: return "UNKNOWN";
        case TelephonyRadioTech::GPRS: return "GPRS";
        case TelephonyRadioTech::EDGE: return "EDGE";
        case TelephonyRadioTech::UMTS: return "UMTS";
        case TelephonyRadioTech::HSDPA: return "HSDPA";
        case TelephonyRadioTech::HSUPA: return "HSUPA";
        case TelephonyRadioTech::HSPA: return "HSPA";
        case TelephonyRadioTech::LTE: return "LTE";
        case TelephonyRadioTech::NR: return "NR";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::simStateToString(SimState state) {
    switch (state) {
        case SimState::ABSENT: return "ABSENT";
        case SimState::READY: return "READY";
        case SimState::PIN_LOCKED: return "PIN_LOCKED";
        case SimState::PUK_LOCKED: return "PUK_LOCKED";
        case SimState::NETWORK_LOCKED: return "NETWORK_LOCKED";
        case SimState::ERROR_STATE: return "ERROR_STATE";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::networkRegToString(NetworkRegistrationState state) {
    switch (state) {
        case NetworkRegistrationState::NOT_REGISTERED: return "NOT_REGISTERED";
        case NetworkRegistrationState::HOME: return "HOME";
        case NetworkRegistrationState::SEARCHING: return "SEARCHING";
        case NetworkRegistrationState::DENIED: return "DENIED";
        case NetworkRegistrationState::UNKNOWN: return "UNKNOWN";
        case NetworkRegistrationState::ROAMING: return "ROAMING";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::dataConnToString(DataConnectionState state) {
    switch (state) {
        case DataConnectionState::DISCONNECTED: return "DISCONNECTED";
        case DataConnectionState::CONNECTING: return "CONNECTING";
        case DataConnectionState::CONNECTED: return "CONNECTED";
        case DataConnectionState::SUSPENDED: return "SUSPENDED";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::callStateToString(CallState state) {
    switch (state) {
        case CallState::IDLE: return "IDLE";
        case CallState::RINGING: return "RINGING";
        case CallState::DIALING: return "DIALING";
        case CallState::ACTIVE: return "ACTIVE";
        case CallState::HOLDING: return "HOLDING";
        case CallState::DISCONNECTED: return "DISCONNECTED";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::smsStateToString(SmsState state) {
    switch (state) {
        case SmsState::NONE: return "NONE";
        case SmsState::RECEIVED: return "RECEIVED";
        case SmsState::SENT: return "SENT";
        case SmsState::BLOCKED: return "BLOCKED";
        case SmsState::FAILED: return "FAILED";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::permissionToString(TelephonyPermission permission) {
    switch (permission) {
        case TelephonyPermission::DENY: return "DENY";
        case TelephonyPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case TelephonyPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case TelephonyPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::privacyModeToString(TelephonyPrivacyMode mode) {
    switch (mode) {
        case TelephonyPrivacyMode::FULL: return "FULL";
        case TelephonyPrivacyMode::REDACTED: return "REDACTED";
        case TelephonyPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::resultToString(TelephonyResult result) {
    switch (result) {
        case TelephonyResult::SUCCESS: return "SUCCESS";
        case TelephonyResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case TelephonyResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case TelephonyResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case TelephonyResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case TelephonyResult::SIM_NOT_READY: return "SIM_NOT_READY";
        case TelephonyResult::NOT_REGISTERED: return "NOT_REGISTERED";
        case TelephonyResult::CALL_IN_PROGRESS: return "CALL_IN_PROGRESS";
        case TelephonyResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case TelephonyResult::MOCK_NOT_ALLOWED: return "MOCK_NOT_ALLOWED";
        case TelephonyResult::RATE_LIMITED: return "RATE_LIMITED";
        case TelephonyResult::BAD_STATE: return "BAD_STATE";
        case TelephonyResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case TelephonyResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        case TelephonyResult::NO_SUBSCRIPTION: return "NO_SUBSCRIPTION";
        default: return "UNKNOWN";
    }
}

const char* TelephonyManager::eventTypeToString(TelephonyEventType type) {
    switch (type) {
        case TelephonyEventType::SIM_STATE_CHANGED: return "SIM_STATE_CHANGED";
        case TelephonyEventType::NETWORK_REGISTERED: return "NETWORK_REGISTERED";
        case TelephonyEventType::NETWORK_DEREGISTERED: return "NETWORK_DEREGISTERED";
        case TelephonyEventType::DATA_CONNECTED: return "DATA_CONNECTED";
        case TelephonyEventType::DATA_DISCONNECTED: return "DATA_DISCONNECTED";
        case TelephonyEventType::CALL_INCOMING: return "CALL_INCOMING";
        case TelephonyEventType::CALL_OUTGOING: return "CALL_OUTGOING";
        case TelephonyEventType::CALL_ACTIVE: return "CALL_ACTIVE";
        case TelephonyEventType::CALL_ENDED: return "CALL_ENDED";
        case TelephonyEventType::SMS_RECEIVED: return "SMS_RECEIVED";
        case TelephonyEventType::SMS_SENT: return "SMS_SENT";
        case TelephonyEventType::SMS_BLOCKED: return "SMS_BLOCKED";
        case TelephonyEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case TelephonyEventType::SIM_EXPIRED: return "SIM_EXPIRED";
        case TelephonyEventType::CELL_INFO_UPDATED: return "CELL_INFO_UPDATED";
        case TelephonyEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case TelephonyEventType::INDICATOR_ON: return "INDICATOR_ON";
        case TelephonyEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        default: return "UNKNOWN";
    }
}

TelephonyRadioTech TelephonyManager::stringToRadioTech(const std::string& str) {
    if (str == "GPRS") return TelephonyRadioTech::GPRS;
    if (str == "EDGE") return TelephonyRadioTech::EDGE;
    if (str == "UMTS") return TelephonyRadioTech::UMTS;
    if (str == "HSDPA") return TelephonyRadioTech::HSDPA;
    if (str == "HSUPA") return TelephonyRadioTech::HSUPA;
    if (str == "HSPA") return TelephonyRadioTech::HSPA;
    if (str == "LTE") return TelephonyRadioTech::LTE;
    if (str == "NR") return TelephonyRadioTech::NR;
    return TelephonyRadioTech::UNKNOWN;
}

TelephonyResult TelephonyManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return TelephonyResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return TelephonyResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return TelephonyResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return TelephonyResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return TelephonyResult::PERMISSION_DENIED;
    if (str == "SIM_NOT_READY") return TelephonyResult::SIM_NOT_READY;
    if (str == "NOT_REGISTERED") return TelephonyResult::NOT_REGISTERED;
    if (str == "CALL_IN_PROGRESS") return TelephonyResult::CALL_IN_PROGRESS;
    if (str == "CAPACITY_EXCEEDED") return TelephonyResult::CAPACITY_EXCEEDED;
    if (str == "MOCK_NOT_ALLOWED") return TelephonyResult::MOCK_NOT_ALLOWED;
    if (str == "RATE_LIMITED") return TelephonyResult::RATE_LIMITED;
    if (str == "BAD_STATE") return TelephonyResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return TelephonyResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return TelephonyResult::SIMULATED_FAILURE;
    if (str == "NO_SUBSCRIPTION") return TelephonyResult::NO_SUBSCRIPTION;
    return TelephonyResult::SUCCESS;
}

}  // namespace telephony
}  // namespace phantom
