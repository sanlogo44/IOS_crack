/*
 * Phantom OS - Display Manager
 * v0.34.0 - License: GPL-3.0
 *
 * Privacy-first display service: brightness control (manual, auto, adaptive),
 * display state management (ON/OFF/DIM/SUSPEND), rotation control, color
 * profiles and True Tone simulation, refresh rate management, per-app
 * display policy with foreground-only enforcement, screen content protection
 * (secure display flag), privacy indicator, mock display data for testing,
 * events, stats, callbacks and optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Brightness and sensor values are
 * deterministic stubs. The LogServer must never log screen content or
 * per-app display preferences.
 */

#ifndef PHANTOM_DISPLAY_DISPLAY_MANAGER_H
#define PHANTOM_DISPLAY_DISPLAY_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace display {

// ============================================================
// Constants
// ============================================================

static const uint32_t DISPLAY_PRIVACY_NONE = 0;
static const uint32_t DISPLAY_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t DISPLAY_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t DISPLAY_PRIVACY_SECURE_DISPLAY = 1 << 2;
static const uint32_t DISPLAY_PRIVACY_BLOCK_SCREENSHOT = 1 << 3;
static const uint32_t DISPLAY_PRIVACY_BLOCK_MIRROR = 1 << 4;
static const uint32_t DISPLAY_PRIVACY_MOCK_ALLOWED = 1 << 5;
static const uint32_t DISPLAY_PRIVACY_INDICATOR_REQUIRED = 1 << 6;

static const uint32_t DISPLAY_DEFAULT_MAX_BRIGHTNESS = 255;
static const uint32_t DISPLAY_DEFAULT_MIN_BRIGHTNESS = 1;
static const uint32_t DISPLAY_DEFAULT_MAX_HISTORY = 128;
static const uint32_t DISPLAY_DEFAULT_MAX_EVENTS = 256;

// ============================================================
// Enums
// ============================================================

enum class DisplayState : uint8_t {
    OFF = 0,
    DIM,
    ON,
    SUSPENDED
};

enum class DisplayRotation : uint8_t {
    PORTRAIT = 0,
    LANDSCAPE,
    PORTRAIT_REVERSE,
    LANDSCAPE_REVERSE
};

enum class ColorProfile : uint8_t {
    STANDARD = 0,
    VIVID,
    TRUE_TONE,
    NIGHT_SHIFT,
    CUSTOM
};

enum class RefreshRate : uint8_t {
    REFRESH_60HZ = 0,
    REFRESH_90HZ,
    REFRESH_120HZ,
    REFRESH_ADAPTIVE
};

enum class BrightnessMode : uint8_t {
    MANUAL = 0,
    AUTO,
    ADAPTIVE
};

enum class DisplayPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class DisplayPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class DisplayResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    DISPLAY_OFF,
    BRIGHTNESS_OUT_OF_RANGE,
    PROFILE_NOT_SUPPORTED,
    CAPACITY_EXCEEDED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class DisplayEventType : uint8_t {
    DISPLAY_STATE_CHANGED = 0,
    BRIGHTNESS_CHANGED,
    BRIGHTNESS_MODE_CHANGED,
    ROTATION_CHANGED,
    COLOR_PROFILE_CHANGED,
    REFRESH_RATE_CHANGED,
    SECURE_DISPLAY_ENABLED,
    SECURE_DISPLAY_DISABLED,
    SCREENSHOT_BLOCKED,
    MIRROR_BLOCKED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    MOCK_DATA_SET,
    HISTORY_CLEARED
};

// ============================================================
// Data structures
// ============================================================

struct DisplayInfo {
    uint32_t width = 2436;
    uint32_t height = 1125;
    uint32_t dpi = 458;
    uint32_t maxBrightness = 255;
    uint32_t minBrightness = 1;
    std::string panelType = "OLED";
    bool trueToneSupported = true;
    bool nightShiftSupported = true;
    bool adaptiveRefreshSupported = true;
    std::vector<RefreshRate> supportedRefreshRates = {RefreshRate::REFRESH_60HZ, RefreshRate::REFRESH_120HZ};
};

struct BrightnessConfig {
    uint32_t brightness = 128;
    BrightnessMode mode = BrightnessMode::MANUAL;
    uint32_t autoMin = 20;
    uint32_t autoMax = 255;
    uint32_t dimThreshold = 15;
    uint32_t dimBrightness = 10;
    bool autoDimEnabled = true;
};

struct TrueToneConfig {
    bool enabled = false;
    uint32_t colorTemperature = 6500;  // Kelvin
    uint32_t minTemperature = 4500;
    uint32_t maxTemperature = 8500;
};

struct NightShiftConfig {
    bool enabled = false;
    uint32_t intensity = 50;  // 0-100
    uint32_t startHour = 22;
    uint32_t endHour = 6;
    bool scheduled = false;
};

struct DisplayPolicy {
    std::string appId;
    DisplayPermission permission = DisplayPermission::DENY;
    DisplayPrivacyMode privacyMode = DisplayPrivacyMode::FULL;
    uint32_t privacyFlags = DISPLAY_PRIVACY_NONE;
    uint32_t preferredBrightness = 128;
    DisplayRotation preferredRotation = DisplayRotation::PORTRAIT;
    bool secureDisplay = false;
    bool blockScreenshot = false;
    bool blockMirror = false;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
};

struct DisplayEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    DisplayEventType type = DisplayEventType::DISPLAY_STATE_CHANGED;
    DisplayResult result = DisplayResult::SUCCESS;
    std::string appId;
    std::string detail;
};

struct DisplayStats {
    uint64_t stateChanges = 0;
    uint64_t brightnessChanges = 0;
    uint64_t modeChanges = 0;
    uint64_t rotationChanges = 0;
    uint64_t profileChanges = 0;
    uint64_t refreshRateChanges = 0;
    uint64_t secureDisplayCount = 0;
    uint64_t screenshotBlocks = 0;
    uint64_t mirrorBlocks = 0;
    uint64_t permissionsChanged = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t mockDataSet = 0;
    uint64_t byEventType[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[13] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Display Manager
// ============================================================

class DisplayManager {
public:
    DisplayManager() = default;
    ~DisplayManager() = default;

    DisplayManager(const DisplayManager&) = delete;
    DisplayManager& operator=(const DisplayManager&) = delete;

    // ---- Lifecycle ----
    DisplayResult initialize(size_t maxHistory = 128, size_t maxEvents = 256);
    DisplayResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Display state ----
    DisplayResult setDisplayState(DisplayState state, const std::string& owner = "system");
    DisplayState getDisplayState() const { return displayState_; }
    bool isDisplayOn() const { return displayState_ == DisplayState::ON; }
    bool isDisplayOff() const { return displayState_ == DisplayState::OFF; }

    // ---- Brightness ----
    DisplayResult setBrightness(uint32_t brightness, const std::string& owner = "system");
    uint32_t getBrightness() const { return brightnessConfig_.brightness; }
    uint32_t getMaxBrightness() const { return displayInfo_.maxBrightness; }
    uint32_t getMinBrightness() const { return displayInfo_.minBrightness; }
    DisplayResult setBrightnessMode(BrightnessMode mode, const std::string& owner = "system");
    BrightnessMode getBrightnessMode() const { return brightnessConfig_.mode; }
    DisplayResult setAutoBrightnessRange(uint32_t min, uint32_t max,
                                           const std::string& owner = "system");
    DisplayResult setDimThreshold(uint32_t threshold, uint32_t dimBrightness,
                                     const std::string& owner = "system");
    DisplayResult setAutoDimEnabled(bool enabled, const std::string& owner = "system");
    BrightnessConfig getBrightnessConfig() const { return brightnessConfig_; }
    DisplayResult updateAutoBrightness(uint32_t ambientLightLevel,
                                         const std::string& owner = "system");

    // ---- Rotation ----
    DisplayResult setRotation(DisplayRotation rotation, const std::string& owner = "system");
    DisplayRotation getRotation() const { return rotation_; }
    DisplayResult setAutoRotateEnabled(bool enabled, const std::string& owner = "system");
    bool isAutoRotateEnabled() const { return autoRotate_; }

    // ---- Color profiles / True Tone ----
    DisplayResult setColorProfile(ColorProfile profile, const std::string& owner = "system");
    ColorProfile getColorProfile() const { return colorProfile_; }
    DisplayResult setTrueToneConfig(const TrueToneConfig& config,
                                      const std::string& owner = "system");
    TrueToneConfig getTrueToneConfig() const { return trueToneConfig_; }
    DisplayResult setNightShiftConfig(const NightShiftConfig& config,
                                        const std::string& owner = "system");
    NightShiftConfig getNightShiftConfig() const { return nightShiftConfig_; }

    // ---- Refresh rate ----
    DisplayResult setRefreshRate(RefreshRate rate, const std::string& owner = "system");
    RefreshRate getRefreshRate() const { return refreshRate_; }
    std::vector<RefreshRate> getSupportedRefreshRates() const { return displayInfo_.supportedRefreshRates; }

    // ---- Display info ----
    DisplayInfo getDisplayInfo() const { return displayInfo_; }
    DisplayResult setDisplayInfo(const DisplayInfo& info, const std::string& owner = "system");

    // ---- Permission / policy ----
    DisplayResult setAppDisplayPolicy(const std::string& appId,
                                        DisplayPermission permission,
                                        DisplayPrivacyMode privacyMode,
                                        uint32_t privacyFlags = DISPLAY_PRIVACY_NONE,
                                        uint32_t preferredBrightness = 128,
                                        DisplayRotation preferredRotation = DisplayRotation::PORTRAIT,
                                        bool secureDisplay = false,
                                        bool blockScreenshot = false,
                                        bool blockMirror = false,
                                        const std::string& owner = "system");
    DisplayPolicy getAppDisplayPolicy(const std::string& appId) const;
    DisplayResult clearAppDisplayPolicy(const std::string& appId,
                                          const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    DisplayResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Secure display ----
    bool isSecureDisplayActive() const;
    bool shouldBlockScreenshot(const std::string& appId) const;
    bool shouldBlockMirror(const std::string& appId) const;
    std::vector<std::string> getSecureDisplayApps() const;

    // ---- History ----
    std::vector<DisplayEvent> getHistory(const std::string& appId,
                                           size_t limit = 0) const;
    DisplayResult clearHistory(const std::string& owner = "system");
    DisplayResult clearAppHistory(const std::string& appId,
                                    const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    DisplayResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    DisplayResult setMockBrightness(uint32_t brightness,
                                      const std::string& owner = "system");
    DisplayResult setMockAmbientLight(uint32_t level,
                                        const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeDisplayUsers_.empty(); }
    std::vector<std::string> getActiveDisplayUsers() const { return activeDisplayUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<DisplayEvent> getEvents(size_t limit = 0) const;
    std::vector<DisplayEvent> getEventsByType(DisplayEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    DisplayResult clearEvents();

    // ---- Stats ----
    DisplayStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const DisplayEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, DisplayResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* displayStateToString(DisplayState state);
    static const char* rotationToString(DisplayRotation rotation);
    static const char* colorProfileToString(ColorProfile profile);
    static const char* refreshRateToString(RefreshRate rate);
    static const char* brightnessModeToString(BrightnessMode mode);
    static const char* permissionToString(DisplayPermission permission);
    static const char* privacyModeToString(DisplayPrivacyMode mode);
    static const char* resultToString(DisplayResult result);
    static const char* eventTypeToString(DisplayEventType type);
    static DisplayResult stringToResult(const std::string& str);
    static ColorProfile stringToColorProfile(const std::string& str);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(DisplayEventType type, DisplayResult result,
                     const std::string& appId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void setStubDisplayInfo();
    void applyAutoBrightness(uint32_t ambientLight);

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;

    DisplayInfo displayInfo_;
    DisplayState displayState_ = DisplayState::OFF;
    BrightnessConfig brightnessConfig_;
    DisplayRotation rotation_ = DisplayRotation::PORTRAIT;
    ColorProfile colorProfile_ = ColorProfile::STANDARD;
    TrueToneConfig trueToneConfig_;
    NightShiftConfig nightShiftConfig_;
    RefreshRate refreshRate_ = RefreshRate::REFRESH_60HZ;
    bool autoRotate_ = true;

    std::map<std::string, DisplayPolicy> appPolicies_;

    std::vector<DisplayEvent> history_;
    std::vector<DisplayEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    uint32_t mockAmbientLight_ = 500;

    std::vector<std::string> activeDisplayUsers_;
    uint64_t lastAccessTime_ = 0;

    DisplayStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const DisplayEvent&)> eventCallback_;
    std::function<void(const std::string&, DisplayResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace display
}  // namespace phantom

#endif  // PHANTOM_DISPLAY_DISPLAY_MANAGER_H
