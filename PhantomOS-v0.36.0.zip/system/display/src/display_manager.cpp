/*
 * Phantom OS - Display Manager Implementation
 * v0.34.0 - License: GPL-3.0
 *
 * Implementation of the privacy-first display service.
 * All data is simulated in-memory. Privacy transforms are deterministic.
 */

#include "phantom/display/display_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cstring>

namespace phantom {
namespace display {

// ============================================================
// FNV-1a hash (deterministic, same as other Phantom OS components)
// ============================================================

static uint32_t fnv1a(const std::string& str) {
    uint32_t hash = 2166136261u;
    for (char c : str) {
        hash ^= static_cast<uint32_t>(static_cast<unsigned char>(c));
        hash *= 16777619u;
    }
    return hash;
}

// ============================================================
// Lifecycle
// ============================================================

DisplayResult DisplayManager::initialize(size_t maxHistory, size_t maxEvents) {
    if (initialized_) return DisplayResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0)
        return DisplayResult::INVALID_PARAMETER;

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;

    initialized_ = true;
    displayState_ = DisplayState::OFF;
    rotation_ = DisplayRotation::PORTRAIT;
    colorProfile_ = ColorProfile::STANDARD;
    refreshRate_ = RefreshRate::REFRESH_60HZ;
    autoRotate_ = true;
    mockEnabled_ = false;
    mockAmbientLight_ = 500;

    setStubDisplayInfo();

    brightnessConfig_.brightness = 128;
    brightnessConfig_.mode = BrightnessMode::MANUAL;
    brightnessConfig_.autoMin = 20;
    brightnessConfig_.autoMax = 255;
    brightnessConfig_.dimThreshold = 15;
    brightnessConfig_.dimBrightness = 10;
    brightnessConfig_.autoDimEnabled = true;

    trueToneConfig_.enabled = false;
    trueToneConfig_.colorTemperature = 6500;
    trueToneConfig_.minTemperature = 4500;
    trueToneConfig_.maxTemperature = 8500;

    nightShiftConfig_.enabled = false;
    nightShiftConfig_.intensity = 50;
    nightShiftConfig_.startHour = 22;
    nightShiftConfig_.endHour = 6;
    nightShiftConfig_.scheduled = false;

    stats_ = DisplayStats{};

    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::shutdown() {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;

    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeDisplayUsers_.clear();

    displayState_ = DisplayState::OFF;
    mockEnabled_ = false;
    initialized_ = false;

    return DisplayResult::SUCCESS;
}

// ============================================================
// Display state
// ============================================================

DisplayResult DisplayManager::setDisplayState(DisplayState state, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    if (state == displayState_) return DisplayResult::BAD_STATE;

    DisplayState oldState = displayState_;
    displayState_ = state;

    stats_.stateChanges++;
    recordEvent(DisplayEventType::DISPLAY_STATE_CHANGED, DisplayResult::SUCCESS,
                owner, std::string("State: ") + displayStateToString(oldState) + " -> " + displayStateToString(state));

    logToServer("INFO", "Display state changed: " + std::string(displayStateToString(state)));

    if (state == DisplayState::OFF || state == DisplayState::SUSPENDED) {
        activeDisplayUsers_.clear();
        updatePrivacyIndicator();
    }

    return DisplayResult::SUCCESS;
}

// ============================================================
// Brightness
// ============================================================

DisplayResult DisplayManager::setBrightness(uint32_t brightness, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    if (brightness < displayInfo_.minBrightness || brightness > displayInfo_.maxBrightness)
        return DisplayResult::BRIGHTNESS_OUT_OF_RANGE;

    uint32_t oldBrightness = brightnessConfig_.brightness;
    brightnessConfig_.brightness = brightness;

    stats_.brightnessChanges++;
    recordEvent(DisplayEventType::BRIGHTNESS_CHANGED, DisplayResult::SUCCESS,
                owner, "Brightness: " + std::to_string(oldBrightness) + " -> " + std::to_string(brightness));

    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setBrightnessMode(BrightnessMode mode, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    if (mode == brightnessConfig_.mode) return DisplayResult::BAD_STATE;

    brightnessConfig_.mode = mode;
    stats_.modeChanges++;
    recordEvent(DisplayEventType::BRIGHTNESS_MODE_CHANGED, DisplayResult::SUCCESS,
                owner, std::string("Mode: ") + brightnessModeToString(mode));

    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setAutoBrightnessRange(uint32_t min, uint32_t max,
                                                       const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;
    if (min >= max) return DisplayResult::INVALID_PARAMETER;
    if (min < displayInfo_.minBrightness || max > displayInfo_.maxBrightness)
        return DisplayResult::BRIGHTNESS_OUT_OF_RANGE;

    brightnessConfig_.autoMin = min;
    brightnessConfig_.autoMax = max;
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setDimThreshold(uint32_t threshold, uint32_t dimBrightness,
                                                 const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    brightnessConfig_.dimThreshold = threshold;
    brightnessConfig_.dimBrightness = dimBrightness;
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setAutoDimEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    brightnessConfig_.autoDimEnabled = enabled;
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::updateAutoBrightness(uint32_t ambientLightLevel,
                                                     const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;
    if (brightnessConfig_.mode != BrightnessMode::AUTO && brightnessConfig_.mode != BrightnessMode::ADAPTIVE)
        return DisplayResult::BAD_STATE;

    applyAutoBrightness(ambientLightLevel);
    return DisplayResult::SUCCESS;
}

void DisplayManager::applyAutoBrightness(uint32_t ambientLight) {
    // Map ambient light (0-1000) to brightness range
    uint32_t range = brightnessConfig_.autoMax - brightnessConfig_.autoMin;
    uint32_t clampedAmbient = std::min(ambientLight, 1000u);
    uint32_t target = brightnessConfig_.autoMin + (clampedAmbient * range) / 1000;

    // Check for dim threshold
    if (brightnessConfig_.autoDimEnabled && clampedAmbient < brightnessConfig_.dimThreshold) {
        target = brightnessConfig_.dimBrightness;
    }

    if (target != brightnessConfig_.brightness) {
        uint32_t old = brightnessConfig_.brightness;
        brightnessConfig_.brightness = target;
        stats_.brightnessChanges++;
        recordEvent(DisplayEventType::BRIGHTNESS_CHANGED, DisplayResult::SUCCESS,
                    "system", "Auto brightness: " + std::to_string(old) + " -> " + std::to_string(target));
    }
}

// ============================================================
// Rotation
// ============================================================

DisplayResult DisplayManager::setRotation(DisplayRotation rotation, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    if (rotation == rotation_) return DisplayResult::BAD_STATE;

    DisplayRotation old = rotation_;
    rotation_ = rotation;
    stats_.rotationChanges++;
    recordEvent(DisplayEventType::ROTATION_CHANGED, DisplayResult::SUCCESS,
                owner, std::string("Rotation: ") + rotationToString(old) + " -> " + rotationToString(rotation));

    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setAutoRotateEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    autoRotate_ = enabled;
    return DisplayResult::SUCCESS;
}

// ============================================================
// Color profiles / True Tone
// ============================================================

DisplayResult DisplayManager::setColorProfile(ColorProfile profile, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    if (profile == colorProfile_) return DisplayResult::BAD_STATE;

    ColorProfile old = colorProfile_;
    colorProfile_ = profile;
    stats_.profileChanges++;
    recordEvent(DisplayEventType::COLOR_PROFILE_CHANGED, DisplayResult::SUCCESS,
                owner, std::string("Profile: ") + colorProfileToString(old) + " -> " + colorProfileToString(profile));

    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setTrueToneConfig(const TrueToneConfig& config,
                                                  const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;
    if (config.minTemperature >= config.maxTemperature)
        return DisplayResult::INVALID_PARAMETER;
    if (config.colorTemperature < config.minTemperature ||
        config.colorTemperature > config.maxTemperature)
        return DisplayResult::INVALID_PARAMETER;

    trueToneConfig_ = config;
    if (config.enabled && colorProfile_ != ColorProfile::TRUE_TONE) {
        colorProfile_ = ColorProfile::TRUE_TONE;
        stats_.profileChanges++;
        recordEvent(DisplayEventType::COLOR_PROFILE_CHANGED, DisplayResult::SUCCESS,
                    owner, "True Tone enabled");
    }
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setNightShiftConfig(const NightShiftConfig& config,
                                                    const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;
    if (config.intensity > 100) return DisplayResult::INVALID_PARAMETER;
    if (config.startHour > 23 || config.endHour > 23)
        return DisplayResult::INVALID_PARAMETER;

    nightShiftConfig_ = config;
    return DisplayResult::SUCCESS;
}

// ============================================================
// Refresh rate
// ============================================================

DisplayResult DisplayManager::setRefreshRate(RefreshRate rate, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return DisplayResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    // Check if supported
    bool supported = false;
    for (auto r : displayInfo_.supportedRefreshRates) {
        if (r == rate) { supported = true; break; }
    }
    if (!supported) return DisplayResult::PROFILE_NOT_SUPPORTED;

    if (rate == refreshRate_) return DisplayResult::BAD_STATE;

    RefreshRate old = refreshRate_;
    refreshRate_ = rate;
    stats_.refreshRateChanges++;
    recordEvent(DisplayEventType::REFRESH_RATE_CHANGED, DisplayResult::SUCCESS,
                owner, std::string("Refresh: ") + refreshRateToString(old) + " -> " + refreshRateToString(rate));

    return DisplayResult::SUCCESS;
}

// ============================================================
// Display info
// ============================================================

DisplayResult DisplayManager::setDisplayInfo(const DisplayInfo& info, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    displayInfo_ = info;
    return DisplayResult::SUCCESS;
}

// ============================================================
// Permission / policy
// ============================================================

DisplayResult DisplayManager::setAppDisplayPolicy(const std::string& appId,
                                                    DisplayPermission permission,
                                                    DisplayPrivacyMode privacyMode,
                                                    uint32_t privacyFlags,
                                                    uint32_t preferredBrightness,
                                                    DisplayRotation preferredRotation,
                                                    bool secureDisplay,
                                                    bool blockScreenshot,
                                                    bool blockMirror,
                                                    const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;
    if (appId.empty()) return DisplayResult::INVALID_PARAMETER;

    DisplayPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.preferredBrightness = preferredBrightness;
    policy.preferredRotation = preferredRotation;
    policy.secureDisplay = secureDisplay;
    policy.blockScreenshot = blockScreenshot;
    policy.blockMirror = blockMirror;
    policy.lastGrantedAt = (permission != DisplayPermission::DENY) ? getCurrentTimeMs() : 0;
    policy.oneShotUsed = false;
    policy.foreground = false;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(DisplayEventType::PERMISSION_CHANGED, DisplayResult::SUCCESS,
                owner, "Policy set for " + appId);

    return DisplayResult::SUCCESS;
}

DisplayPolicy DisplayManager::getAppDisplayPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return DisplayPolicy{};
}

DisplayResult DisplayManager::clearAppDisplayPolicy(const std::string& appId,
                                                      const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return DisplayResult::INVALID_PARAMETER;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    auto uit = std::find(activeDisplayUsers_.begin(), activeDisplayUsers_.end(), appId);
    if (uit != activeDisplayUsers_.end()) {
        activeDisplayUsers_.erase(uit);
        updatePrivacyIndicator();
    }

    return DisplayResult::SUCCESS;
}

bool DisplayManager::checkAppAccess(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    switch (policy.permission) {
        case DisplayPermission::DENY:
            return false;
        case DisplayPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case DisplayPermission::ALLOW_ALWAYS:
            return true;
        case DisplayPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

DisplayResult DisplayManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return DisplayResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return DisplayResult::SUCCESS;
}

// ============================================================
// Secure display
// ============================================================

bool DisplayManager::isSecureDisplayActive() const {
    for (const auto& [appId, policy] : appPolicies_) {
        if (policy.secureDisplay && checkAppAccess(appId)) return true;
    }
    return false;
}

bool DisplayManager::shouldBlockScreenshot(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;
    return it->second.blockScreenshot && checkAppAccess(appId);
}

bool DisplayManager::shouldBlockMirror(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;
    return it->second.blockMirror && checkAppAccess(appId);
}

std::vector<std::string> DisplayManager::getSecureDisplayApps() const {
    std::vector<std::string> apps;
    for (const auto& [appId, policy] : appPolicies_) {
        if (policy.secureDisplay && checkAppAccess(appId)) {
            apps.push_back(appId);
        }
    }
    return apps;
}

// ============================================================
// History
// ============================================================

std::vector<DisplayEvent> DisplayManager::getHistory(const std::string& appId,
                                                        size_t limit) const {
    std::vector<DisplayEvent> result;
    for (auto it = history_.rbegin(); it != history_.rend(); ++it) {
        if (it->appId == appId || isSystemOwner(appId)) {
            result.push_back(*it);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

DisplayResult DisplayManager::clearHistory(const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(DisplayEventType::HISTORY_CLEARED, DisplayResult::SUCCESS,
                owner, "History cleared");
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::clearAppHistory(const std::string& appId,
                                                const std::string& requester) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(requester) && requester != appId) return DisplayResult::PERMISSION_DENIED;

    auto it = std::remove_if(history_.begin(), history_.end(),
        [&appId](const DisplayEvent& e) { return e.appId == appId; });
    history_.erase(it, history_.end());

    return DisplayResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

DisplayResult DisplayManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setMockBrightness(uint32_t brightness,
                                                 const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    mockAmbientLight_ = brightness;
    if (brightnessConfig_.mode == BrightnessMode::AUTO || brightnessConfig_.mode == BrightnessMode::ADAPTIVE) {
        applyAutoBrightness(brightness);
    }
    return DisplayResult::SUCCESS;
}

DisplayResult DisplayManager::setMockAmbientLight(uint32_t level,
                                                   const std::string& owner) {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return DisplayResult::PERMISSION_DENIED;

    mockAmbientLight_ = level;
    return DisplayResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<DisplayEvent> DisplayManager::getEvents(size_t limit) const {
    if (limit == 0) return events_;
    std::vector<DisplayEvent> result;
    for (auto it = events_.rbegin(); it != events_.rend() && result.size() < limit; ++it) {
        result.push_back(*it);
    }
    return result;
}

std::vector<DisplayEvent> DisplayManager::getEventsByType(DisplayEventType type) const {
    std::vector<DisplayEvent> result;
    for (const auto& e : events_) {
        if (e.type == type) result.push_back(e);
    }
    return result;
}

DisplayResult DisplayManager::clearEvents() {
    if (!initialized_) return DisplayResult::NOT_INITIALIZED;

    for (const auto& e : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(e);
    }
    events_.clear();
    return DisplayResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void DisplayManager::resetStats() {
    stats_ = DisplayStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* DisplayManager::displayStateToString(DisplayState state) {
    switch (state) {
        case DisplayState::OFF: return "OFF";
        case DisplayState::DIM: return "DIM";
        case DisplayState::ON: return "ON";
        case DisplayState::SUSPENDED: return "SUSPENDED";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::rotationToString(DisplayRotation rotation) {
    switch (rotation) {
        case DisplayRotation::PORTRAIT: return "PORTRAIT";
        case DisplayRotation::LANDSCAPE: return "LANDSCAPE";
        case DisplayRotation::PORTRAIT_REVERSE: return "PORTRAIT_REVERSE";
        case DisplayRotation::LANDSCAPE_REVERSE: return "LANDSCAPE_REVERSE";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::colorProfileToString(ColorProfile profile) {
    switch (profile) {
        case ColorProfile::STANDARD: return "STANDARD";
        case ColorProfile::VIVID: return "VIVID";
        case ColorProfile::TRUE_TONE: return "TRUE_TONE";
        case ColorProfile::NIGHT_SHIFT: return "NIGHT_SHIFT";
        case ColorProfile::CUSTOM: return "CUSTOM";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::refreshRateToString(RefreshRate rate) {
    switch (rate) {
        case RefreshRate::REFRESH_60HZ: return "60HZ";
        case RefreshRate::REFRESH_90HZ: return "90HZ";
        case RefreshRate::REFRESH_120HZ: return "120HZ";
        case RefreshRate::REFRESH_ADAPTIVE: return "ADAPTIVE";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::brightnessModeToString(BrightnessMode mode) {
    switch (mode) {
        case BrightnessMode::MANUAL: return "MANUAL";
        case BrightnessMode::AUTO: return "AUTO";
        case BrightnessMode::ADAPTIVE: return "ADAPTIVE";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::permissionToString(DisplayPermission permission) {
    switch (permission) {
        case DisplayPermission::DENY: return "DENY";
        case DisplayPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case DisplayPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case DisplayPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::privacyModeToString(DisplayPrivacyMode mode) {
    switch (mode) {
        case DisplayPrivacyMode::FULL: return "FULL";
        case DisplayPrivacyMode::REDACTED: return "REDACTED";
        case DisplayPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::resultToString(DisplayResult result) {
    switch (result) {
        case DisplayResult::SUCCESS: return "SUCCESS";
        case DisplayResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case DisplayResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case DisplayResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case DisplayResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case DisplayResult::DISPLAY_OFF: return "DISPLAY_OFF";
        case DisplayResult::BRIGHTNESS_OUT_OF_RANGE: return "BRIGHTNESS_OUT_OF_RANGE";
        case DisplayResult::PROFILE_NOT_SUPPORTED: return "PROFILE_NOT_SUPPORTED";
        case DisplayResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case DisplayResult::RATE_LIMITED: return "RATE_LIMITED";
        case DisplayResult::BAD_STATE: return "BAD_STATE";
        case DisplayResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case DisplayResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* DisplayManager::eventTypeToString(DisplayEventType type) {
    switch (type) {
        case DisplayEventType::DISPLAY_STATE_CHANGED: return "DISPLAY_STATE_CHANGED";
        case DisplayEventType::BRIGHTNESS_CHANGED: return "BRIGHTNESS_CHANGED";
        case DisplayEventType::BRIGHTNESS_MODE_CHANGED: return "BRIGHTNESS_MODE_CHANGED";
        case DisplayEventType::ROTATION_CHANGED: return "ROTATION_CHANGED";
        case DisplayEventType::COLOR_PROFILE_CHANGED: return "COLOR_PROFILE_CHANGED";
        case DisplayEventType::REFRESH_RATE_CHANGED: return "REFRESH_RATE_CHANGED";
        case DisplayEventType::SECURE_DISPLAY_ENABLED: return "SECURE_DISPLAY_ENABLED";
        case DisplayEventType::SECURE_DISPLAY_DISABLED: return "SECURE_DISPLAY_DISABLED";
        case DisplayEventType::SCREENSHOT_BLOCKED: return "SCREENSHOT_BLOCKED";
        case DisplayEventType::MIRROR_BLOCKED: return "MIRROR_BLOCKED";
        case DisplayEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case DisplayEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case DisplayEventType::INDICATOR_ON: return "INDICATOR_ON";
        case DisplayEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case DisplayEventType::MOCK_DATA_SET: return "MOCK_DATA_SET";
        case DisplayEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

DisplayResult DisplayManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return DisplayResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return DisplayResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return DisplayResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return DisplayResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return DisplayResult::PERMISSION_DENIED;
    if (str == "DISPLAY_OFF") return DisplayResult::DISPLAY_OFF;
    if (str == "BRIGHTNESS_OUT_OF_RANGE") return DisplayResult::BRIGHTNESS_OUT_OF_RANGE;
    if (str == "PROFILE_NOT_SUPPORTED") return DisplayResult::PROFILE_NOT_SUPPORTED;
    if (str == "CAPACITY_EXCEEDED") return DisplayResult::CAPACITY_EXCEEDED;
    if (str == "RATE_LIMITED") return DisplayResult::RATE_LIMITED;
    if (str == "BAD_STATE") return DisplayResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return DisplayResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return DisplayResult::SIMULATED_FAILURE;
    return DisplayResult::OPERATION_FAILED;
}

ColorProfile DisplayManager::stringToColorProfile(const std::string& str) {
    if (str == "STANDARD") return ColorProfile::STANDARD;
    if (str == "VIVID") return ColorProfile::VIVID;
    if (str == "TRUE_TONE") return ColorProfile::TRUE_TONE;
    if (str == "NIGHT_SHIFT") return ColorProfile::NIGHT_SHIFT;
    if (str == "CUSTOM") return ColorProfile::CUSTOM;
    return ColorProfile::STANDARD;
}

// ============================================================
// Private helpers
// ============================================================

uint64_t DisplayManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool DisplayManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "system_server";
}

void DisplayManager::recordEvent(DisplayEventType type, DisplayResult result,
                                   const std::string& appId,
                                   const std::string& detail) {
    DisplayEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.detail = detail;

    if (events_.size() >= maxEvents_) {
        events_.erase(events_.begin());
    }
    events_.push_back(event);

    uint8_t typeIdx = static_cast<uint8_t>(type);
    uint8_t resultIdx = static_cast<uint8_t>(result);
    if (typeIdx < 16) stats_.byEventType[typeIdx]++;
    if (resultIdx < 13) stats_.byResult[resultIdx]++;

    if (result != DisplayResult::SUCCESS) {
        stats_.totalFailures++;
    }

    if (eventCallback_) eventCallback_(event);
}

void DisplayManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "DisplayManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "DisplayManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "DisplayManager");
    }
}

void DisplayManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("DisplayManager", "DisplayManager", 0, reason);
}

void DisplayManager::updatePrivacyIndicator() {
    bool wasOn = !activeDisplayUsers_.empty();
    bool isOn = !activeDisplayUsers_.empty();

    if (wasOn && !isOn) {
        recordEvent(DisplayEventType::INDICATOR_OFF, DisplayResult::SUCCESS,
                    "system", "Privacy indicator off");
    } else if (!wasOn && isOn) {
        recordEvent(DisplayEventType::INDICATOR_ON, DisplayResult::SUCCESS,
                    "system", "Privacy indicator on");
    }
}

void DisplayManager::setStubDisplayInfo() {
    displayInfo_.width = 2436;
    displayInfo_.height = 1125;
    displayInfo_.dpi = 458;
    displayInfo_.maxBrightness = 255;
    displayInfo_.minBrightness = 1;
    displayInfo_.panelType = "OLED";
    displayInfo_.trueToneSupported = true;
    displayInfo_.nightShiftSupported = true;
    displayInfo_.adaptiveRefreshSupported = true;
    displayInfo_.supportedRefreshRates = {RefreshRate::REFRESH_60HZ, RefreshRate::REFRESH_120HZ};
}

}  // namespace display
}  // namespace phantom
