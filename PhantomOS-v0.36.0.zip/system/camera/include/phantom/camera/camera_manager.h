/*
 * Phantom OS - Camera Manager
 * v0.30.0 - License: GPL-3.0
 *
 * Privacy-first camera service: camera management (front, rear, depth,
 * IR, mock), per-app camera access control with foreground-only and
 * privacy-indicator enforcement, capture sessions with single/burst
 * capture, mock camera frames for testing, camera access history with
 * per-app isolation and privacy redaction, events, stats, callbacks and
 * optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Camera frames are deterministic stub
 * data, not real image data. Privacy transforms are deterministic. The
 * LogServer must never log raw frame data or image-like payloads.
 */

#ifndef PHANTOM_CAMERA_CAMERA_MANAGER_H
#define PHANTOM_CAMERA_CAMERA_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace camera {

// ============================================================
// Constants
// ============================================================

static const uint32_t CAMERA_PRIVACY_NONE = 0;
static const uint32_t CAMERA_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t CAMERA_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t CAMERA_PRIVACY_BLUR_STUB = 1 << 2;
static const uint32_t CAMERA_PRIVACY_LOW_RES_STUB = 1 << 3;
static const uint32_t CAMERA_PRIVACY_REDACT_METADATA = 1 << 4;
static const uint32_t CAMERA_PRIVACY_DISABLE_DEPTH = 1 << 5;
static const uint32_t CAMERA_PRIVACY_DISABLE_IR = 1 << 6;
static const uint32_t CAMERA_PRIVACY_MOCK_ALLOWED = 1 << 7;
static const uint32_t CAMERA_PRIVACY_INDICATOR_REQUIRED = 1 << 8;

static const uint64_t CAMERA_DEFAULT_SESSION_TIMEOUT_MS = 60000;
static const uint32_t CAMERA_DEFAULT_BURST_LIMIT = 10;
static const uint32_t CAMERA_DEFAULT_MAX_SESSIONS = 4;

// ============================================================
// Enums
// ============================================================

enum class CameraId : uint8_t {
    FRONT = 0,
    REAR,
    DEPTH,
    IR,
    MOCK,
    COUNT
};

enum class CameraState : uint8_t {
    CLOSED = 0,
    OPENING,
    OPEN,
    PREVIEWING,
    CAPTURING,
    ERROR_STATE,
    CLOSED_FORCE
};

enum class CameraFacing : uint8_t {
    FRONT = 0,
    BACK,
    EXTERNAL
};

enum class CameraPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class CameraRequestState : uint8_t {
    ACTIVE = 0,
    PAUSED,
    EXPIRED,
    CANCELLED
};

enum class CameraPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class CaptureMode : uint8_t {
    SINGLE = 0,
    BURST,
    VIDEO_STUB,
    CONTINUOUS
};

enum class CameraResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    CAMERA_BUSY,
    CAMERA_NOT_AVAILABLE,
    SESSION_NOT_FOUND,
    CAPACITY_EXCEEDED,
    MOCK_NOT_ALLOWED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE,
    CAPTURE_FAILED
};

enum class CameraEventType : uint8_t {
    CAMERA_OPENED = 0,
    CAMERA_CLOSED,
    SESSION_STARTED,
    SESSION_ENDED,
    CAPTURE_STARTED,
    CAPTURE_COMPLETED,
    CAPTURE_DENIED,
    PERMISSION_CHANGED,
    SESSION_EXPIRED,
    MOCK_FRAME_SET,
    HISTORY_CLEARED,
    PRIVACY_APPLIED,
    CAMERA_ERROR,
    CAMERA_RECOVERED,
    INDICATOR_ON,
    INDICATOR_OFF,
    BURST_COMPLETED
};

// ============================================================
// Data structures
// ============================================================

struct CameraFrame {
    uint32_t width = 0;
    uint32_t height = 0;
    uint32_t format = 0;       // Stub format ID
    uint64_t frameId = 0;
    uint64_t timestamp = 0;
    uint64_t timestampNanos = 0;
    CameraId camera = CameraId::FRONT;
    uint32_t privacyFlags = CAMERA_PRIVACY_NONE;
    bool mock = false;
    uint8_t stubData[16] = {0};  // Deterministic stub, not real image
};

struct CameraInfo {
    CameraId camera = CameraId::FRONT;
    CameraState state = CameraState::CLOSED;
    CameraFacing facing = CameraFacing::FRONT;
    bool enabled = false;
    bool supportsDepth = false;
    bool supportsIR = false;
    uint32_t maxResolutionW = 0;
    uint32_t maxResolutionH = 0;
    uint32_t maxFps = 0;
    uint32_t sensorOrientation = 0;
    std::string name;
    std::string vendor;
};

struct CameraPolicy {
    std::string appId;
    CameraPermission permission = CameraPermission::DENY;
    CameraPrivacyMode privacyMode = CameraPrivacyMode::FULL;
    uint32_t privacyFlags = CAMERA_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
    uint32_t captureRateLimit = 0;  // 0 = unlimited
};

struct CameraSession {
    uint64_t id = 0;
    std::string appId;
    CameraId camera = CameraId::FRONT;
    CameraState state = CameraState::CLOSED;
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;
    uint64_t lastCaptureAt = 0;
    uint32_t captureCount = 0;
    uint32_t burstRemaining = 0;
    CameraFrame lastFrame;
    CameraFrame lastRawFrame;
    CameraRequestState requestState = CameraRequestState::ACTIVE;
};

struct CameraEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    CameraEventType type = CameraEventType::CAMERA_OPENED;
    CameraResult result = CameraResult::SUCCESS;
    std::string appId;
    CameraId camera = CameraId::FRONT;
    uint64_t sessionId = 0;
    std::string detail;  // Metadata only — never raw frame data
};

struct CameraStats {
    uint64_t sessionsStarted = 0;
    uint64_t sessionsEnded = 0;
    uint64_t capturesStarted = 0;
    uint64_t capturesCompleted = 0;
    uint64_t capturesDenied = 0;
    uint64_t permissionsChanged = 0;
    uint64_t sessionsExpired = 0;
    uint64_t mockFramesSet = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t burstCaptures = 0;
    uint64_t byCamera[5] = {0, 0, 0, 0, 0};
    uint64_t byEventType[17] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Camera Manager
// ============================================================

class CameraManager {
public:
    CameraManager() = default;
    ~CameraManager() = default;

    CameraManager(const CameraManager&) = delete;
    CameraManager& operator=(const CameraManager&) = delete;

    // ---- Lifecycle ----
    CameraResult initialize(size_t maxHistory = 128, size_t maxEvents = 256,
                              size_t maxSessions = 4, size_t maxBurst = 10);
    CameraResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Camera control ----
    CameraResult setCameraEnabled(CameraId camera, bool enabled,
                                    const std::string& owner = "system");
    bool isCameraEnabled(CameraId camera) const;
    CameraInfo getCameraInfo(CameraId camera) const;
    std::vector<CameraInfo> getCameras() const;
    std::vector<CameraId> getAvailableCameras() const;

    // ---- Permission / policy ----
    CameraResult setAppCameraPolicy(const std::string& appId,
                                     CameraPermission permission,
                                     CameraPrivacyMode privacyMode,
                                     uint32_t privacyFlags = CAMERA_PRIVACY_NONE,
                                     uint32_t captureRateLimit = 0,
                                     const std::string& owner = "system");
    CameraPolicy getAppCameraPolicy(const std::string& appId) const;
    CameraResult clearAppCameraPolicy(const std::string& appId,
                                       const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId, CameraId camera) const;
    CameraResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Session lifecycle ----
    CameraResult openSession(const std::string& appId, CameraId camera,
                               uint64_t timeoutMs = 0,
                               uint64_t* outSessionId = nullptr);
    CameraResult closeSession(uint64_t sessionId, const std::string& appId);
    CameraResult processSessions();
    size_t getActiveSessionCount() const;
    std::vector<CameraSession> getActiveSessions() const;

    // ---- Capture ----
    CameraResult capture(uint64_t sessionId, const std::string& appId,
                           CaptureMode mode = CaptureMode::SINGLE,
                           uint32_t burstCount = 1);
    CameraResult getLastFrame(const std::string& appId, CameraId camera,
                                CameraFrame& out);
    CameraResult requestSingleCapture(const std::string& appId, CameraId camera,
                                       uint64_t timeoutMs = 0);

    // ---- History / privacy ----
    std::vector<CameraFrame> getHistory(const std::string& appId,
                                          size_t limit = 0,
                                          bool includeMock = false) const;
    CameraResult clearHistory(const std::string& owner = "system");
    CameraResult clearAppHistory(const std::string& appId,
                                   const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    CameraResult setMockEnabled(bool enabled, const std::string& owner = "system");
    CameraResult setMockFrame(CameraId camera, const CameraFrame& frame,
                                const std::string& owner = "system");
    CameraResult clearMockFrame(CameraId camera,
                                  const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeCameraUsers_.empty(); }
    std::vector<std::string> getActiveCameraUsers() const { return activeCameraUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<CameraEvent> getEvents(size_t limit = 0) const;
    std::vector<CameraEvent> getEventsByType(CameraEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    CameraResult clearEvents();

    // ---- Stats ----
    CameraStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setFrameCallback(std::function<void(const CameraFrame&, const std::string&)> cb) {
        frameCallback_ = cb;
    }
    void setAccessCallback(std::function<void(const std::string&, CameraResult)> cb) {
        accessCallback_ = cb;
    }
    void setEventCallback(std::function<void(const CameraEvent&)> cb) { eventCallback_ = cb; }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* cameraIdToString(CameraId camera);
    static const char* cameraStateToString(CameraState state);
    static const char* cameraFacingToString(CameraFacing facing);
    static const char* cameraPermissionToString(CameraPermission permission);
    static const char* requestStateToString(CameraRequestState state);
    static const char* cameraPrivacyModeToString(CameraPrivacyMode mode);
    static const char* captureModeToString(CaptureMode mode);
    static const char* cameraResultToString(CameraResult result);
    static const char* cameraEventTypeToString(CameraEventType type);
    static CameraId stringToCameraId(const std::string& str);
    static CameraResult stringToCameraResult(const std::string& str);

    // ---- Privacy helpers ----
    static CameraFrame applyPrivacyTransform(const CameraFrame& frame,
                                               CameraPrivacyMode mode,
                                               uint32_t privacyFlags);

private:
    uint64_t getCurrentTimeMs() const;
    uint64_t getCurrentTimeNanos() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(CameraEventType type, CameraResult result,
                     const std::string& appId, CameraId camera,
                     uint64_t sessionId, const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    CameraResult deliverFrameToSession(CameraSession& session,
                                         const CameraFrame& frame);
    static int cameraIndex(CameraId camera);
    void initCameraCapabilities();
    void updatePrivacyIndicator();
    void setStubFrameData(CameraFrame& frame, CameraId camera);

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;
    size_t maxSessions_ = 4;
    size_t maxBurst_ = 10;

    CameraInfo cameras_[5];
    CameraFrame lastFrames_[5];

    std::map<std::string, CameraPolicy> appPolicies_;

    std::vector<CameraSession> sessions_;
    uint64_t nextSessionId_ = 1;

    std::vector<CameraFrame> history_;
    std::vector<CameraEvent> events_;
    std::vector<CameraEvent> eventHistory_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    CameraFrame mockFrames_[5];

    std::vector<std::string> activeCameraUsers_;
    uint64_t lastAccessTime_ = 0;

    CameraStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const CameraFrame&, const std::string&)> frameCallback_;
    std::function<void(const std::string&, CameraResult)> accessCallback_;
    std::function<void(const CameraEvent&)> eventCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace camera
}  // namespace phantom

#endif  // PHANTOM_CAMERA_CAMERA_MANAGER_H
