/*
 * Phantom OS - Camera Manager
 * v0.30.0 - License: GPL-3.0
 *
 * Implementation of CameraManager: privacy-first camera service with
 * camera management, per-app policy, capture sessions with single/burst
 * capture, mock camera support, privacy indicator, history with privacy
 * redaction, events, stats, callbacks and optional LogServer/CrashReporter
 * integration.
 */

#include "phantom/camera/camera_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <chrono>
#include <algorithm>
#include <cstring>

namespace phantom {
namespace camera {

// ============================================================
// Private helpers
// ============================================================

int CameraManager::cameraIndex(CameraId camera) {
    return static_cast<int>(camera);
}

uint64_t CameraManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

uint64_t CameraManager::getCurrentTimeNanos() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_ * 1000000ULL;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool CameraManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "android" || app == "com.android.system";
}

void CameraManager::initCameraCapabilities() {
    // Front camera
    cameras_[0] = {};
    cameras_[0].camera = CameraId::FRONT;
    cameras_[0].state = CameraState::CLOSED;
    cameras_[0].facing = CameraFacing::FRONT;
    cameras_[0].supportsDepth = false;
    cameras_[0].supportsIR = true;  // Face ID style
    cameras_[0].maxResolutionW = 3088;
    cameras_[0].maxResolutionH = 2320;
    cameras_[0].maxFps = 60;
    cameras_[0].sensorOrientation = 0;
    cameras_[0].name = "Front Camera";
    cameras_[0].vendor = "PhantomOS";

    // Rear camera
    cameras_[1] = {};
    cameras_[1].camera = CameraId::REAR;
    cameras_[1].state = CameraState::CLOSED;
    cameras_[1].facing = CameraFacing::BACK;
    cameras_[1].supportsDepth = true;
    cameras_[1].supportsIR = false;
    cameras_[1].maxResolutionW = 4032;
    cameras_[1].maxResolutionH = 3024;
    cameras_[1].maxFps = 60;
    cameras_[1].sensorOrientation = 90;
    cameras_[1].name = "Rear Camera";
    cameras_[1].vendor = "PhantomOS";

    // Depth camera
    cameras_[2] = {};
    cameras_[2].camera = CameraId::DEPTH;
    cameras_[2].state = CameraState::CLOSED;
    cameras_[2].facing = CameraFacing::BACK;
    cameras_[2].supportsDepth = true;
    cameras_[2].supportsIR = false;
    cameras_[2].maxResolutionW = 640;
    cameras_[2].maxResolutionH = 480;
    cameras_[2].maxFps = 30;
    cameras_[2].sensorOrientation = 90;
    cameras_[2].name = "Depth Camera";
    cameras_[2].vendor = "PhantomOS";

    // IR camera
    cameras_[3] = {};
    cameras_[3].camera = CameraId::IR;
    cameras_[3].state = CameraState::CLOSED;
    cameras_[3].facing = CameraFacing::FRONT;
    cameras_[3].supportsDepth = false;
    cameras_[3].supportsIR = true;
    cameras_[3].maxResolutionW = 640;
    cameras_[3].maxResolutionH = 480;
    cameras_[3].maxFps = 30;
    cameras_[3].sensorOrientation = 0;
    cameras_[3].name = "IR Camera";
    cameras_[3].vendor = "PhantomOS";

    // Mock camera
    cameras_[4] = {};
    cameras_[4].camera = CameraId::MOCK;
    cameras_[4].state = CameraState::CLOSED;
    cameras_[4].facing = CameraFacing::FRONT;
    cameras_[4].supportsDepth = true;
    cameras_[4].supportsIR = true;
    cameras_[4].maxResolutionW = 1920;
    cameras_[4].maxResolutionH = 1080;
    cameras_[4].maxFps = 30;
    cameras_[4].sensorOrientation = 0;
    cameras_[4].name = "Mock Camera";
    cameras_[4].vendor = "PhantomOS";
}

void CameraManager::setStubFrameData(CameraFrame& frame, CameraId camera) {
    // Deterministic stub pattern, not real image data
    int idx = cameraIndex(camera);
    for (int i = 0; i < 16; ++i) {
        frame.stubData[i] = static_cast<uint8_t>((idx * 16 + i) % 256);
    }
}

void CameraManager::updatePrivacyIndicator() {
    lastAccessTime_ = getCurrentTimeMs();
}

void CameraManager::recordEvent(CameraEventType type, CameraResult result,
                                 const std::string& appId, CameraId camera,
                                 uint64_t sessionId, const std::string& detail) {
    CameraEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.camera = camera;
    event.sessionId = sessionId;
    event.detail = detail;

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        eventHistory_.push_back(events_.front());
        events_.erase(events_.begin());
    }

    int ci = cameraIndex(camera);
    if (ci >= 0 && ci < 5) stats_.byCamera[ci]++;
    int et = static_cast<int>(type);
    if (et >= 0 && et < 17) stats_.byEventType[et]++;
    int ri = static_cast<int>(result);
    if (ri >= 0 && ri < 15) stats_.byResult[ri]++;

    if (eventCallback_) eventCallback_(event);
}

void CameraManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    // Never log raw frame data — only metadata
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "CameraManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "CameraManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "CameraManager");
    }
}

void CameraManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("CameraManager", "CameraManager", 0, reason);
}

// ============================================================
// Lifecycle
// ============================================================

CameraResult CameraManager::initialize(size_t maxHistory, size_t maxEvents,
                                         size_t maxSessions, size_t maxBurst) {
    if (initialized_) return CameraResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxSessions == 0 || maxBurst == 0) {
        return CameraResult::INVALID_PARAMETER;
    }

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxSessions_ = maxSessions;
    maxBurst_ = maxBurst;

    initCameraCapabilities();

    // Enable default cameras: front, rear
    cameras_[0].enabled = true;  // Front
    cameras_[1].enabled = true;  // Rear
    // Depth, IR, Mock disabled by default

    initialized_ = true;

    logToServer("INFO", "CameraManager initialized");
    return CameraResult::SUCCESS;
}

CameraResult CameraManager::shutdown() {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;

    appPolicies_.clear();
    sessions_.clear();
    history_.clear();
    events_.clear();
    eventHistory_.clear();
    nextSessionId_ = 1;
    nextEventId_ = 1;
    activeCameraUsers_.clear();
    lastAccessTime_ = 0;

    for (size_t i = 0; i < 5; ++i) {
        cameras_[i] = CameraInfo{};
        cameras_[i].camera = static_cast<CameraId>(i);
        lastFrames_[i] = CameraFrame{};
        mockFrames_[i] = CameraFrame{};
    }
    mockEnabled_ = false;
    stats_ = CameraStats{};
    initialized_ = false;
    return CameraResult::SUCCESS;
}

// ============================================================
// Camera control
// ============================================================

CameraResult CameraManager::setCameraEnabled(CameraId camera, bool enabled,
                                               const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;

    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;

    if (cameras_[idx].enabled == enabled) return CameraResult::SUCCESS;

    cameras_[idx].enabled = enabled;
    if (!enabled) {
        cameras_[idx].state = CameraState::CLOSED;
    }

    recordEvent(enabled ? CameraEventType::CAMERA_OPENED : CameraEventType::CAMERA_CLOSED,
                 CameraResult::SUCCESS, "system", camera, 0,
                 enabled ? "ENABLED" : "DISABLED");
    logToServer("INFO", std::string("Camera ") + cameraIdToString(camera) +
                (enabled ? " enabled" : " disabled"));
    return CameraResult::SUCCESS;
}

bool CameraManager::isCameraEnabled(CameraId camera) const {
    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return false;
    return cameras_[idx].enabled;
}

CameraInfo CameraManager::getCameraInfo(CameraId camera) const {
    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraInfo{};
    return cameras_[idx];
}

std::vector<CameraInfo> CameraManager::getCameras() const {
    std::vector<CameraInfo> result;
    for (size_t i = 0; i < 5; ++i) {
        result.push_back(cameras_[i]);
    }
    return result;
}

std::vector<CameraId> CameraManager::getAvailableCameras() const {
    std::vector<CameraId> result;
    for (size_t i = 0; i < 5; ++i) {
        if (cameras_[i].enabled) {
            result.push_back(static_cast<CameraId>(i));
        }
    }
    return result;
}

// ============================================================
// Permission / policy
// ============================================================

CameraResult CameraManager::setAppCameraPolicy(const std::string& appId,
                                                CameraPermission permission,
                                                CameraPrivacyMode privacyMode,
                                                uint32_t privacyFlags,
                                                uint32_t captureRateLimit,
                                                const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::SIMULATED_FAILURE; }
    if (appId.empty()) return CameraResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;

    // Check depth/IR restrictions
    if (privacyFlags & CAMERA_PRIVACY_DISABLE_DEPTH) {
        cameras_[2].enabled = false;  // Depth
        cameras_[2].state = CameraState::CLOSED;
    }
    if (privacyFlags & CAMERA_PRIVACY_DISABLE_IR) {
        cameras_[3].enabled = false;  // IR
        cameras_[3].state = CameraState::CLOSED;
    }

    CameraPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.lastGrantedAt = getCurrentTimeMs();
    policy.captureRateLimit = captureRateLimit;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(CameraEventType::PERMISSION_CHANGED, CameraResult::SUCCESS,
                 appId, CameraId::FRONT, 0, "POLICY_SET");
    logToServer("INFO", "Policy set for app: " + appId);
    return CameraResult::SUCCESS;
}

CameraPolicy CameraManager::getAppCameraPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return CameraPolicy{};
}

CameraResult CameraManager::clearAppCameraPolicy(const std::string& appId,
                                                   const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return CameraResult::SUCCESS;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    recordEvent(CameraEventType::PERMISSION_CHANGED, CameraResult::SUCCESS,
                 appId, CameraId::FRONT, 0, "POLICY_CLEARED");
    return CameraResult::SUCCESS;
}

bool CameraManager::checkAppAccess(const std::string& appId, CameraId camera) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    // Check depth/IR restrictions
    if (camera == CameraId::DEPTH && (policy.privacyFlags & CAMERA_PRIVACY_DISABLE_DEPTH)) {
        return false;
    }
    if (camera == CameraId::IR && (policy.privacyFlags & CAMERA_PRIVACY_DISABLE_IR)) {
        return false;
    }

    switch (policy.permission) {
        case CameraPermission::DENY:
            return false;
        case CameraPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case CameraPermission::ALLOW_ALWAYS:
            return true;
        case CameraPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

CameraResult CameraManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return CameraResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return CameraResult::SUCCESS;
}

// ============================================================
// Session lifecycle
// ============================================================

CameraResult CameraManager::openSession(const std::string& appId, CameraId camera,
                                          uint64_t timeoutMs,
                                          uint64_t* outSessionId) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::SIMULATED_FAILURE; }
    if (appId.empty()) return CameraResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId, camera)) {
        stats_.capturesDenied++;
        if (accessCallback_) accessCallback_(appId, CameraResult::PERMISSION_DENIED);
        recordEvent(CameraEventType::CAPTURE_DENIED, CameraResult::PERMISSION_DENIED,
                     appId, camera, 0, "ACCESS_DENIED");
        return CameraResult::PERMISSION_DENIED;
    }

    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;
    if (!cameras_[idx].enabled) return CameraResult::CAMERA_NOT_AVAILABLE;

    // Check if camera is already in use by another session
    for (const auto& s : sessions_) {
        if (s.camera == camera && s.requestState == CameraRequestState::ACTIVE) {
            return CameraResult::CAMERA_BUSY;
        }
    }

    if (sessions_.size() >= maxSessions_) return CameraResult::CAPACITY_EXCEEDED;

    CameraSession session;
    session.id = nextSessionId_++;
    session.appId = appId;
    session.camera = camera;
    session.state = CameraState::OPEN;
    session.createdAt = getCurrentTimeMs();
    session.expiresAt = timeoutMs > 0 ? session.createdAt + timeoutMs : 0;
    session.requestState = CameraRequestState::ACTIVE;
    session.burstRemaining = 0;

    if (outSessionId) *outSessionId = session.id;
    sessions_.push_back(session);
    cameras_[idx].state = CameraState::OPEN;
    stats_.sessionsStarted++;

    // Update privacy indicator
    if (std::find(activeCameraUsers_.begin(), activeCameraUsers_.end(), appId) ==
        activeCameraUsers_.end()) {
        activeCameraUsers_.push_back(appId);
        recordEvent(CameraEventType::INDICATOR_ON, CameraResult::SUCCESS,
                     appId, camera, session.id, "INDICATOR_ON");
        stats_.indicatorToggleCount++;
    }
    updatePrivacyIndicator();

    recordEvent(CameraEventType::SESSION_STARTED, CameraResult::SUCCESS,
                 appId, camera, session.id, "OPEN");
    return CameraResult::SUCCESS;
}

CameraResult CameraManager::closeSession(uint64_t sessionId, const std::string& appId) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::SIMULATED_FAILURE; }

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return CameraResult::PERMISSION_DENIED;
        if (session.requestState == CameraRequestState::CANCELLED) return CameraResult::BAD_STATE;

        session.requestState = CameraRequestState::CANCELLED;
        session.state = CameraState::CLOSED;

        int idx = cameraIndex(session.camera);
        if (idx >= 0 && idx < 5) cameras_[idx].state = CameraState::CLOSED;

        stats_.sessionsEnded++;

        // Update privacy indicator: check if app has other active sessions
        bool hasOtherActive = false;
        for (const auto& s : sessions_) {
            if (s.appId == session.appId && s.id != sessionId &&
                s.requestState == CameraRequestState::ACTIVE) {
                hasOtherActive = true;
                break;
            }
        }
        if (!hasOtherActive) {
            auto userIt = std::find(activeCameraUsers_.begin(), activeCameraUsers_.end(),
                                     session.appId);
            if (userIt != activeCameraUsers_.end()) {
                activeCameraUsers_.erase(userIt);
                recordEvent(CameraEventType::INDICATOR_OFF, CameraResult::SUCCESS,
                             session.appId, session.camera, sessionId, "INDICATOR_OFF");
                stats_.indicatorToggleCount++;
            }
        }

        recordEvent(CameraEventType::SESSION_ENDED, CameraResult::SUCCESS,
                     session.appId, session.camera, sessionId, "CLOSE");
        return CameraResult::SUCCESS;
    }
    return CameraResult::SESSION_NOT_FOUND;
}

CameraResult CameraManager::processSessions() {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    uint64_t now = getCurrentTimeMs();

    for (auto& session : sessions_) {
        if (session.requestState != CameraRequestState::ACTIVE) continue;
        if (session.expiresAt > 0 && now >= session.expiresAt) {
            session.requestState = CameraRequestState::EXPIRED;
            session.state = CameraState::CLOSED;

            int idx = cameraIndex(session.camera);
            if (idx >= 0 && idx < 5) cameras_[idx].state = CameraState::CLOSED;

            stats_.sessionsExpired++;

            // Update privacy indicator
            bool hasOtherActive = false;
            for (const auto& s : sessions_) {
                if (s.appId == session.appId && s.id != session.id &&
                    s.requestState == CameraRequestState::ACTIVE) {
                    hasOtherActive = true;
                    break;
                }
            }
            if (!hasOtherActive) {
                auto userIt = std::find(activeCameraUsers_.begin(), activeCameraUsers_.end(),
                                         session.appId);
                if (userIt != activeCameraUsers_.end()) {
                    activeCameraUsers_.erase(userIt);
                    stats_.indicatorToggleCount++;
                }
            }

            recordEvent(CameraEventType::SESSION_EXPIRED, CameraResult::SUCCESS,
                         session.appId, session.camera, session.id, "EXPIRED");
        }
    }
    return CameraResult::SUCCESS;
}

size_t CameraManager::getActiveSessionCount() const {
    size_t count = 0;
    for (const auto& s : sessions_) {
        if (s.requestState == CameraRequestState::ACTIVE) count++;
    }
    return count;
}

std::vector<CameraSession> CameraManager::getActiveSessions() const {
    std::vector<CameraSession> result;
    for (const auto& s : sessions_) {
        if (s.requestState == CameraRequestState::ACTIVE) result.push_back(s);
    }
    return result;
}

// ============================================================
// Capture
// ============================================================

CameraResult CameraManager::capture(uint64_t sessionId, const std::string& appId,
                                      CaptureMode mode, uint32_t burstCount) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::CAPTURE_FAILED; }

    for (auto& session : sessions_) {
        if (session.id != sessionId) continue;
        if (session.appId != appId && !isSystemOwner(appId)) return CameraResult::PERMISSION_DENIED;
        if (session.requestState != CameraRequestState::ACTIVE) return CameraResult::BAD_STATE;

        int idx = cameraIndex(session.camera);
        if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;
        if (!cameras_[idx].enabled) return CameraResult::CAMERA_NOT_AVAILABLE;

        // Rate limiting
        auto policyIt = appPolicies_.find(appId);
        if (policyIt != appPolicies_.end() && policyIt->second.captureRateLimit > 0 &&
            session.lastCaptureAt > 0) {
            uint64_t minIntervalMs = 1000 / policyIt->second.captureRateLimit;
            if (getCurrentTimeMs() - session.lastCaptureAt < minIntervalMs) {
                return CameraResult::RATE_LIMITED;
            }
        }

        uint32_t count = (mode == CaptureMode::BURST) ? std::min(burstCount, static_cast<uint32_t>(maxBurst_)) : 1;
        session.state = CameraState::CAPTURING;

        recordEvent(CameraEventType::CAPTURE_STARTED, CameraResult::SUCCESS,
                     appId, session.camera, sessionId, "CAPTURE_START");
        stats_.capturesStarted++;

        CameraFrame frame;
        for (uint32_t i = 0; i < count; ++i) {
            frame = CameraFrame{};
            // Use mock frame if enabled
            if (mockEnabled_ && mockFrames_[idx].timestamp > 0) {
                frame = mockFrames_[idx];
                frame.mock = true;
            } else {
                frame.width = cameras_[idx].maxResolutionW;
                frame.height = cameras_[idx].maxResolutionH;
                frame.format = 1;  // Stub format
                setStubFrameData(frame, session.camera);
            }
            frame.camera = session.camera;
            frame.frameId = session.captureCount + i + 1;
            frame.timestamp = getCurrentTimeMs();
            frame.timestampNanos = getCurrentTimeNanos();

            deliverFrameToSession(session, frame);
        }

        session.captureCount += count;
        session.lastCaptureAt = getCurrentTimeMs();
        session.state = CameraState::OPEN;
        updatePrivacyIndicator();

        if (mode == CaptureMode::BURST) {
            stats_.burstCaptures++;
            recordEvent(CameraEventType::BURST_COMPLETED, CameraResult::SUCCESS,
                         appId, session.camera, sessionId, "BURST:" + std::to_string(count));
        }

        recordEvent(CameraEventType::CAPTURE_COMPLETED, CameraResult::SUCCESS,
                     appId, session.camera, sessionId, "CAPTURE_DONE");
        stats_.capturesCompleted++;

        // Consume ALLOW_ONCE
        if (policyIt != appPolicies_.end() && policyIt->second.permission == CameraPermission::ALLOW_ONCE) {
            policyIt->second.oneShotUsed = true;
        }

        return CameraResult::SUCCESS;
    }
    return CameraResult::SESSION_NOT_FOUND;
}

CameraResult CameraManager::getLastFrame(const std::string& appId, CameraId camera,
                                           CameraFrame& out) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::SIMULATED_FAILURE; }

    if (!checkAppAccess(appId, camera)) {
        stats_.capturesDenied++;
        if (accessCallback_) accessCallback_(appId, CameraResult::PERMISSION_DENIED);
        recordEvent(CameraEventType::CAPTURE_DENIED, CameraResult::PERMISSION_DENIED,
                     appId, camera, 0, "ACCESS_DENIED");
        return CameraResult::PERMISSION_DENIED;
    }

    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;
    if (lastFrames_[idx].timestamp == 0) return CameraResult::CAMERA_NOT_AVAILABLE;

    auto policy = getAppCameraPolicy(appId);
    out = applyPrivacyTransform(lastFrames_[idx], policy.privacyMode, policy.privacyFlags);

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == CameraPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    return CameraResult::SUCCESS;
}

CameraResult CameraManager::requestSingleCapture(const std::string& appId, CameraId camera,
                                                    uint64_t timeoutMs) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return CameraResult::CAPTURE_FAILED; }

    uint64_t sessionId = 0;
    CameraResult openResult = openSession(appId, camera, timeoutMs, &sessionId);
    if (openResult != CameraResult::SUCCESS) return openResult;

    CameraResult captureResult = capture(sessionId, appId, CaptureMode::SINGLE, 1);
    closeSession(sessionId, appId);
    return captureResult;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<CameraFrame> CameraManager::getHistory(const std::string& appId,
                                                     size_t limit, bool includeMock) const {
    std::vector<CameraFrame> result;
    for (const auto& frame : history_) {
        if (!includeMock && frame.mock) continue;
        result.push_back(frame);
        if (limit > 0 && result.size() >= limit) break;
    }
    return result;
}

CameraResult CameraManager::clearHistory(const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(CameraEventType::HISTORY_CLEARED, CameraResult::SUCCESS,
                 "system", CameraId::FRONT, 0, "CLEAR_ALL");
    return CameraResult::SUCCESS;
}

CameraResult CameraManager::clearAppHistory(const std::string& appId,
                                              const std::string& requester) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (appId != requester && !isSystemOwner(requester)) return CameraResult::PERMISSION_DENIED;

    stats_.historyClears++;
    recordEvent(CameraEventType::HISTORY_CLEARED, CameraResult::SUCCESS,
                 appId, CameraId::FRONT, 0, "CLEAR_APP");
    return CameraResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

CameraResult CameraManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;
    mockEnabled_ = enabled;
    return CameraResult::SUCCESS;
}

CameraResult CameraManager::setMockFrame(CameraId camera, const CameraFrame& frame,
                                           const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) {
        auto policy = getAppCameraPolicy(owner);
        if (!(policy.privacyFlags & CAMERA_PRIVACY_MOCK_ALLOWED)) {
            return CameraResult::MOCK_NOT_ALLOWED;
        }
    }

    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;

    mockFrames_[idx] = frame;
    mockFrames_[idx].camera = camera;
    mockFrames_[idx].mock = true;
    mockFrames_[idx].timestamp = getCurrentTimeMs();
    stats_.mockFramesSet++;
    recordEvent(CameraEventType::MOCK_FRAME_SET, CameraResult::SUCCESS,
                 "system", camera, 0, "MOCK_SET");
    return CameraResult::SUCCESS;
}

CameraResult CameraManager::clearMockFrame(CameraId camera, const std::string& owner) {
    if (!initialized_) return CameraResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return CameraResult::PERMISSION_DENIED;

    int idx = cameraIndex(camera);
    if (idx < 0 || idx >= 5) return CameraResult::INVALID_PARAMETER;
    mockFrames_[idx] = CameraFrame{};
    return CameraResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<CameraEvent> CameraManager::getEvents(size_t limit) const {
    if (limit == 0 || limit >= events_.size()) return events_;
    return std::vector<CameraEvent>(events_.end() - limit, events_.end());
}

std::vector<CameraEvent> CameraManager::getEventsByType(CameraEventType type) const {
    std::vector<CameraEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) result.push_back(event);
    }
    return result;
}

CameraResult CameraManager::clearEvents() {
    for (const auto& event : events_) {
        eventHistory_.push_back(event);
    }
    events_.clear();
    return CameraResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void CameraManager::resetStats() {
    stats_ = CameraStats{};
}

// ============================================================
// Privacy helpers
// ============================================================

CameraFrame CameraManager::applyPrivacyTransform(const CameraFrame& frame,
                                                   CameraPrivacyMode mode,
                                                   uint32_t privacyFlags) {
    CameraFrame result = frame;

    if (mode == CameraPrivacyMode::FULL && privacyFlags == CAMERA_PRIVACY_NONE) {
        return result;
    }

    // REDACTED mode or BLUR_STUB flag: reduce resolution to simulate blur
    if (mode == CameraPrivacyMode::REDACTED || (privacyFlags & CAMERA_PRIVACY_BLUR_STUB)) {
        result.width = result.width / 8;
        result.height = result.height / 8;
        // Zero out stub data to simulate blur
        for (int i = 0; i < 16; ++i) result.stubData[i] = 0;
    }

    // LOW_RES_STUB: reduce resolution
    if (privacyFlags & CAMERA_PRIVACY_LOW_RES_STUB) {
        result.width = result.width / 4;
        result.height = result.height / 4;
    }

    // METADATA_ONLY mode: zero out all pixel-like data
    if (mode == CameraPrivacyMode::METADATA_ONLY) {
        result.width = 0;
        result.height = 0;
        for (int i = 0; i < 16; ++i) result.stubData[i] = 0;
    }

    // REDACT_METADATA: clear format info
    if (privacyFlags & CAMERA_PRIVACY_REDACT_METADATA) {
        result.format = 0;
    }

    result.privacyFlags = privacyFlags;
    return result;
}

// ============================================================
// Private: deliver frame to session
// ============================================================

CameraResult CameraManager::deliverFrameToSession(CameraSession& session,
                                                     const CameraFrame& frame) {
    auto policy = getAppCameraPolicy(session.appId);
    CameraFrame delivered = applyPrivacyTransform(frame, policy.privacyMode, policy.privacyFlags);

    if (policy.privacyMode != CameraPrivacyMode::FULL || policy.privacyFlags != CAMERA_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    session.lastFrame = delivered;
    session.lastRawFrame = frame;

    int idx = cameraIndex(session.camera);
    if (idx >= 0 && idx < 5) {
        lastFrames_[idx] = frame;
    }

    // Add to history (unless NO_HISTORY flag)
    if (!(policy.privacyFlags & CAMERA_PRIVACY_NO_HISTORY)) {
        history_.insert(history_.begin(), delivered);
        if (history_.size() > maxHistory_) {
            history_.resize(maxHistory_);
        }
    }

    if (frameCallback_) {
        frameCallback_(delivered, session.appId);
    }

    return CameraResult::SUCCESS;
}

// ============================================================
// String helpers
// ============================================================

const char* CameraManager::cameraIdToString(CameraId camera) {
    switch (camera) {
        case CameraId::FRONT: return "FRONT";
        case CameraId::REAR: return "REAR";
        case CameraId::DEPTH: return "DEPTH";
        case CameraId::IR: return "IR";
        case CameraId::MOCK: return "MOCK";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraStateToString(CameraState state) {
    switch (state) {
        case CameraState::CLOSED: return "CLOSED";
        case CameraState::OPENING: return "OPENING";
        case CameraState::OPEN: return "OPEN";
        case CameraState::PREVIEWING: return "PREVIEWING";
        case CameraState::CAPTURING: return "CAPTURING";
        case CameraState::ERROR_STATE: return "ERROR_STATE";
        case CameraState::CLOSED_FORCE: return "CLOSED_FORCE";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraFacingToString(CameraFacing facing) {
    switch (facing) {
        case CameraFacing::FRONT: return "FRONT";
        case CameraFacing::BACK: return "BACK";
        case CameraFacing::EXTERNAL: return "EXTERNAL";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraPermissionToString(CameraPermission permission) {
    switch (permission) {
        case CameraPermission::DENY: return "DENY";
        case CameraPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case CameraPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case CameraPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::requestStateToString(CameraRequestState state) {
    switch (state) {
        case CameraRequestState::ACTIVE: return "ACTIVE";
        case CameraRequestState::PAUSED: return "PAUSED";
        case CameraRequestState::EXPIRED: return "EXPIRED";
        case CameraRequestState::CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraPrivacyModeToString(CameraPrivacyMode mode) {
    switch (mode) {
        case CameraPrivacyMode::FULL: return "FULL";
        case CameraPrivacyMode::REDACTED: return "REDACTED";
        case CameraPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::captureModeToString(CaptureMode mode) {
    switch (mode) {
        case CaptureMode::SINGLE: return "SINGLE";
        case CaptureMode::BURST: return "BURST";
        case CaptureMode::VIDEO_STUB: return "VIDEO_STUB";
        case CaptureMode::CONTINUOUS: return "CONTINUOUS";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraResultToString(CameraResult result) {
    switch (result) {
        case CameraResult::SUCCESS: return "SUCCESS";
        case CameraResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case CameraResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case CameraResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case CameraResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case CameraResult::CAMERA_BUSY: return "CAMERA_BUSY";
        case CameraResult::CAMERA_NOT_AVAILABLE: return "CAMERA_NOT_AVAILABLE";
        case CameraResult::SESSION_NOT_FOUND: return "SESSION_NOT_FOUND";
        case CameraResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case CameraResult::MOCK_NOT_ALLOWED: return "MOCK_NOT_ALLOWED";
        case CameraResult::RATE_LIMITED: return "RATE_LIMITED";
        case CameraResult::BAD_STATE: return "BAD_STATE";
        case CameraResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case CameraResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        case CameraResult::CAPTURE_FAILED: return "CAPTURE_FAILED";
        default: return "UNKNOWN";
    }
}

const char* CameraManager::cameraEventTypeToString(CameraEventType type) {
    switch (type) {
        case CameraEventType::CAMERA_OPENED: return "CAMERA_OPENED";
        case CameraEventType::CAMERA_CLOSED: return "CAMERA_CLOSED";
        case CameraEventType::SESSION_STARTED: return "SESSION_STARTED";
        case CameraEventType::SESSION_ENDED: return "SESSION_ENDED";
        case CameraEventType::CAPTURE_STARTED: return "CAPTURE_STARTED";
        case CameraEventType::CAPTURE_COMPLETED: return "CAPTURE_COMPLETED";
        case CameraEventType::CAPTURE_DENIED: return "CAPTURE_DENIED";
        case CameraEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case CameraEventType::SESSION_EXPIRED: return "SESSION_EXPIRED";
        case CameraEventType::MOCK_FRAME_SET: return "MOCK_FRAME_SET";
        case CameraEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        case CameraEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case CameraEventType::CAMERA_ERROR: return "CAMERA_ERROR";
        case CameraEventType::CAMERA_RECOVERED: return "CAMERA_RECOVERED";
        case CameraEventType::INDICATOR_ON: return "INDICATOR_ON";
        case CameraEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case CameraEventType::BURST_COMPLETED: return "BURST_COMPLETED";
        default: return "UNKNOWN";
    }
}

CameraId CameraManager::stringToCameraId(const std::string& str) {
    if (str == "FRONT") return CameraId::FRONT;
    if (str == "REAR") return CameraId::REAR;
    if (str == "DEPTH") return CameraId::DEPTH;
    if (str == "IR") return CameraId::IR;
    if (str == "MOCK") return CameraId::MOCK;
    return CameraId::FRONT;
}

CameraResult CameraManager::stringToCameraResult(const std::string& str) {
    if (str == "SUCCESS") return CameraResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return CameraResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return CameraResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return CameraResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return CameraResult::PERMISSION_DENIED;
    if (str == "CAMERA_BUSY") return CameraResult::CAMERA_BUSY;
    if (str == "CAMERA_NOT_AVAILABLE") return CameraResult::CAMERA_NOT_AVAILABLE;
    if (str == "SESSION_NOT_FOUND") return CameraResult::SESSION_NOT_FOUND;
    if (str == "CAPACITY_EXCEEDED") return CameraResult::CAPACITY_EXCEEDED;
    if (str == "MOCK_NOT_ALLOWED") return CameraResult::MOCK_NOT_ALLOWED;
    if (str == "RATE_LIMITED") return CameraResult::RATE_LIMITED;
    if (str == "BAD_STATE") return CameraResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return CameraResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return CameraResult::SIMULATED_FAILURE;
    if (str == "CAPTURE_FAILED") return CameraResult::CAPTURE_FAILED;
    return CameraResult::SUCCESS;
}

}  // namespace camera
}  // namespace phantom
