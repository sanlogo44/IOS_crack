/*
 * Phantom OS - Network / Connectivity Manager
 * Radio control, scanning, profiles, connections, policies, data usage (simulated)
 *
 * v0.25.0
 * License: GPL-3.0
 *
 * All network operations are simulated stubs for prototype use.
 * No real Wi-Fi/cellular stack is implemented; scan results, IPs and
 * MAC addresses are generated deterministically (FNV-1a based).
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}
namespace phantom::nids {
class NidsEngine;
}

namespace phantom::network {

// ============================================================
// Enums
// ============================================================

enum class NetworkType {
    WIFI,           // Wi-Fi (IEEE 802.11)
    CELLULAR,       // Cellular / LTE
    BLUETOOTH_PAN,  // Bluetooth PAN tethering
    USB_TETHER,     // USB tethering
    LOOPBACK        // Local loopback (always on)
};

enum class NetworkState {
    DISABLED,        // Radio disabled
    DISCONNECTED,    // Radio on, no connection
    SCANNING,        // Scan in progress (transient)
    CONNECTING,      // Connection attempt in progress
    CONNECTED,       // Fully connected
    CAPTIVE_PORTAL,  // Connected but behind captive portal
    LIMITED,         // Connected but no internet
    ROAMING,         // Cellular roaming
    FAILED           // Last connection attempt failed
};

enum class SecurityType {
    OPEN,            // No encryption
    WPA2,            // WPA2-PSK
    WPA3,            // WPA3-SAE
    ENTERPRISE_STUB  // 802.1X enterprise (simulated)
};

enum class NetworkPolicy {
    NORMAL,     // Default behavior
    METERED,    // Connections of this type count as metered
    DATA_SAVER, // Metered + background restrictions
    PRIVACY,    // MAC randomization + DNS privacy enforced
    BLOCKED     // No connections of this type allowed
};

enum class NetworkResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PROFILE_NOT_FOUND,
    NETWORK_NOT_FOUND,
    PROFILE_EXISTS,
    CAPACITY_EXCEEDED,
    ALREADY_CONNECTED,
    NOT_CONNECTED,
    CONNECTION_FAILED,
    AUTH_FAILED,
    RADIO_DISABLED,
    PERMISSION_DENIED,
    BAD_STATE,
    OPERATION_FAILED
};

enum class NetworkEventType {
    SCAN_STARTED,            // Network scan requested
    NETWORK_FOUND,           // Network discovered in scan
    CONNECTED,               // Connection established
    DISCONNECTED,            // Connection dropped/closed
    POLICY_CHANGED,          // Network policy changed
    APP_ACCESS_BLOCKED,       // App blocked from network access
    CAPTIVE_PORTAL_DETECTED, // Captive portal detected
    FIREWALL_BLOCKED,        // Connection blocked by firewall
    RADIO_CHANGED            // Radio or airplane mode toggled
};

// ============================================================
// Structs
// ============================================================

struct NetworkInfo {
    std::string ssid;
    std::string bssid;
    NetworkType type = NetworkType::WIFI;
    SecurityType security = SecurityType::WPA2;
    uint32_t signalStrength = 0;   // 0-100
    uint32_t frequencyMhz = 0;
    uint64_t timestamp = 0;
};

struct NetworkProfile {
    uint64_t id = 0;
    std::string ssid;
    std::string bssid;             // Optional BSSID pin
    NetworkType type = NetworkType::WIFI;
    SecurityType security = SecurityType::WPA2;
    bool hidden = false;
    bool autoConnect = false;
    int32_t priority = 0;
    bool metered = false;          // Manually marked metered
    uint64_t createdAt = 0;
    uint64_t lastConnectedAt = 0;
    uint32_t connectCount = 0;
    // Stored as salted FNV-1a hash; no plaintext is ever kept.
    // Note: hash/salt are part of the struct and thus visible to callers
    // holding a NetworkProfile copy; they are not a secret storage boundary.
    uint64_t passwordHash = 0;
    uint64_t passwordSalt = 0;
};

struct ConnectionInfo {
    NetworkType type = NetworkType::WIFI;
    std::string ssid;
    std::string bssid;
    NetworkState state = NetworkState::DISCONNECTED;
    uint32_t signalStrength = 0;
    std::string ipAddress;      // Simulated local IP
    std::string gateway;       // Simulated gateway
    std::string dnsPrimary;    // Simulated DNS
    std::string dnsSecondary;
    std::string macAddress;    // Simulated MAC (randomized if enabled)
    bool metered = false;
    bool roaming = false;
    bool captivePortal = false;
    bool dnsPrivacy = false;   // DNS-over-HTTPS stub flag
    uint64_t connectedAt = 0;
    uint64_t profileId = 0;
};

struct AppNetworkAccess {
    std::string appId;
    bool allowed = true;        // Default: allowed (block-list pattern)
    bool allowMetered = false;  // Default: metered networks denied (privacy default)
};

struct DataUsage {
    uint64_t bytesRx = 0;
    uint64_t bytesTx = 0;
    uint64_t totalBytes = 0;
    uint64_t meteredBytes = 0;
};

struct NetworkEvent {
    uint64_t id = 0;
    NetworkEventType type = NetworkEventType::SCAN_STARTED;
    NetworkResult result = NetworkResult::SUCCESS;
    std::string ssid;
    std::string appId;
    std::string detail;
    uint64_t timestamp = 0;
};

struct NetworkManagerStats {
    uint64_t scansRequested = 0;
    uint64_t networksFound = 0;
    uint64_t connectAttempts = 0;
    uint64_t successfulConnections = 0;
    uint64_t failedConnections = 0;
    uint64_t authFailures = 0;
    uint64_t disconnects = 0;
    uint64_t reconnects = 0;
    uint64_t captivePortals = 0;
    uint64_t firewallBlocks = 0;
    uint64_t bytesRx = 0;
    uint64_t bytesTx = 0;
    uint64_t meteredBytes = 0;
    uint64_t profilesSaved = 0;
    uint64_t profilesRemoved = 0;
    uint64_t appsBlocked = 0;
    uint64_t totalFailures = 0;
    uint64_t byNetworkType[5] = {};      // Per NetworkType connect attempts
    uint64_t byEventType[9] = {};        // Per NetworkEventType
    uint64_t byResult[16] = {};          // Per NetworkResult
};

// ============================================================
// NetworkManager - Radio, scan, profile and connection service
// ============================================================

class NetworkManager {
public:
    NetworkManager() = default;
    ~NetworkManager() { shutdown(); }

    // Lifecycle
    NetworkResult initialize(size_t maxProfiles = 32, size_t maxEvents = 500,
                             size_t maxHistory = 500, size_t maxApps = 256);
    NetworkResult shutdown();
    bool isInitialized() const { return initialized_; }
    size_t getMaxProfiles() const { return maxProfiles_; }
    size_t getMaxEvents() const { return maxEvents_; }
    size_t getMaxHistory() const { return maxHistory_; }
    size_t getMaxApps() const { return maxApps_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }
    void setNidsEngine(phantom::nids::NidsEngine* engine) { nidsEngine_ = engine; }
    phantom::nids::NidsEngine* getNidsEngine() const { return nidsEngine_; }

    // Test hooks
    void setFailNextConnection(bool fail) { failNextConnection_ = fail; }
    bool getFailNextConnection() const { return failNextConnection_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // Radio control
    NetworkResult setRadioEnabled(NetworkType type, bool enabled);
    bool isRadioEnabled(NetworkType type) const;
    NetworkResult setAirplaneMode(bool enabled, const std::string& owner);
    bool isAirplaneMode() const { return airplaneMode_; }

    // Scanning
    NetworkResult requestScan(NetworkType type);
    std::vector<NetworkInfo> getScanResults(NetworkType type, uint64_t maxAgeMs = 0) const;
    bool hasNetwork(const std::string& ssid, NetworkType type) const;

    // Profiles
    uint64_t addProfile(const std::string& ssid, const std::string& password,
                        NetworkType type, SecurityType security,
                        bool autoConnect = false, int32_t priority = 0,
                        bool metered = false);
    NetworkResult removeProfile(uint64_t profileId);
    NetworkResult updateProfile(uint64_t profileId, const std::string& password = "",
                                int32_t priority = -1, bool autoConnect = false,
                                bool metered = false);
    NetworkProfile getProfile(uint64_t profileId) const;
    uint64_t getProfileBySsid(const std::string& ssid, NetworkType type) const;
    std::vector<NetworkProfile> getSavedProfiles() const;
    size_t getProfileCount() const { return profiles_.size(); }

    // Connection
    NetworkResult connect(uint64_t profileId, const std::string& appId = "",
                          const std::string& password = "");
    NetworkResult disconnect();
    NetworkResult reconnect();
    ConnectionInfo getActiveConnection() const { return connection_; }
    NetworkState getConnectionState() const { return connection_.state; }
    bool isConnected() const;
    NetworkResult checkConnectivity();  // Refresh state (captive/limited detection)
    DataUsage getDataUsage() const { return dataUsage_; }
    NetworkResult updateDataUsage(const std::string& appId, uint64_t bytesRx, uint64_t bytesTx);
    NetworkResult resetDataUsage();

    // Policies
    NetworkResult setNetworkPolicy(NetworkType type, NetworkPolicy policy,
                                    const std::string& owner);
    NetworkPolicy getNetworkPolicy(NetworkType type) const;
    NetworkResult setAppNetworkAccess(const std::string& appId, bool allowed,
                                      bool allowMetered = false);
    AppNetworkAccess getAppNetworkAccess(const std::string& appId) const;
    bool isAppAllowed(const std::string& appId, bool metered) const;
    bool isMeteredConnection() const { return connection_.metered; }

    // Privacy
    void setMacRandomizationEnabled(bool enabled) { macRandomization_ = enabled; }
    bool isMacRandomizationEnabled() const { return macRandomization_; }
    void setDnsPrivacyEnabled(bool enabled) { dnsPrivacy_ = enabled; }
    bool isDnsPrivacyEnabled() const { return dnsPrivacy_; }
    std::string getCurrentMacAddress() const { return connection_.macAddress; }

    // Events, stats and history
    std::vector<NetworkEvent> getEvents(size_t limit = 0) const;
    std::vector<NetworkEvent> getEventsByType(NetworkEventType type, size_t limit = 0) const;
    NetworkResult clearEvents();
    NetworkManagerStats getStats() const;
    void resetStats();

    // Callbacks
    using ConnectionStateCallback = std::function<void(NetworkState oldState, NetworkState newState)>;
    using NetworkEventCallback = std::function<void(const NetworkEvent&)>;
    void setConnectionStateCallback(ConnectionStateCallback cb) { connectionStateCb_ = cb; }
    void setNetworkEventCallback(NetworkEventCallback cb) { networkEventCb_ = cb; }

    // String helpers
    static const char* networkTypeToString(NetworkType type);
    static const char* networkStateToString(NetworkState state);
    static const char* securityTypeToString(SecurityType security);
    static const char* networkPolicyToString(NetworkPolicy policy);
    static const char* networkResultToString(NetworkResult result);
    static const char* networkEventTypeToString(NetworkEventType type);
    static NetworkType stringToNetworkType(const std::string& str);
    static NetworkState stringToNetworkState(const std::string& str);
    static NetworkResult stringToNetworkResult(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxProfiles_ = 32;
    size_t maxEvents_ = 500;
    size_t maxHistory_ = 500;
    size_t maxApps_ = 256;
    uint64_t nextProfileId_ = 1;
    uint64_t nextEventId_ = 1;
    uint32_t nextNidsConnectionId_ = 0;

    bool airplaneMode_ = false;
    bool radios_[5] = {true, true, false, false, true};  // WIFI, CELLULAR, BT_PAN, USB, LOOPBACK
    NetworkPolicy policies_[5] = {
        NetworkPolicy::NORMAL,    // WIFI
        NetworkPolicy::METERED,  // CELLULAR (metered by default)
        NetworkPolicy::METERED,  // BLUETOOTH_PAN
        NetworkPolicy::NORMAL,   // USB_TETHER
        NetworkPolicy::NORMAL    // LOOPBACK
    };

    bool macRandomization_ = true;  // Privacy default: on
    bool dnsPrivacy_ = false;       // Privacy default: off

    ConnectionInfo connection_;
    DataUsage dataUsage_;
    uint64_t lastProfileId_ = 0;
    std::string lastAppId_;

    std::map<uint64_t, NetworkProfile> profiles_;
    std::map<NetworkType, std::vector<NetworkInfo>> scanResults_;
    std::map<std::string, AppNetworkAccess> appAccess_;
    std::vector<NetworkEvent> events_;
    std::vector<NetworkEvent> history_;

    bool failNextConnection_ = false;
    uint64_t timeOverrideMs_ = 0;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;
    phantom::nids::NidsEngine* nidsEngine_ = nullptr;

    ConnectionStateCallback connectionStateCb_;
    NetworkEventCallback networkEventCb_;

    // Stats
    uint64_t scansRequested_ = 0;
    uint64_t networksFound_ = 0;
    uint64_t connectAttempts_ = 0;
    uint64_t successfulConnections_ = 0;
    uint64_t failedConnections_ = 0;
    uint64_t authFailures_ = 0;
    uint64_t disconnects_ = 0;
    uint64_t reconnects_ = 0;
    uint64_t captivePortals_ = 0;
    uint64_t firewallBlocks_ = 0;
    uint64_t profilesSaved_ = 0;
    uint64_t profilesRemoved_ = 0;
    uint64_t appsBlocked_ = 0;
    uint64_t totalFailures_ = 0;
    uint64_t byNetworkType_[5] = {};
    uint64_t byEventType_[9] = {};
    uint64_t byResult_[16] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    uint64_t computeFNV1a(const std::string& data) const;
    uint64_t hashSecret(const std::string& secret, uint64_t salt) const;
    void changeConnectionState(NetworkState newState);
    void recordEvent(NetworkEventType type, NetworkResult result, const std::string& ssid,
                    const std::string& appId, const std::string& detail);
    void moveToHistory(const NetworkEvent& event);
    std::vector<NetworkInfo> generateMockScan(NetworkType type) const;
    std::string generateMacAddress(const std::string& seed) const;
    std::string generateIpAddress(const std::string& seed) const;
    bool isSystemOwner(const std::string& owner) const;
    bool isCaptivePortalSsid(const std::string& ssid) const;
    void registerWithNids();
    void closeNidsConnection();
};

}  // namespace phantom::network
