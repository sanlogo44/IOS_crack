/*
 * Phantom OS - Network / Connectivity Manager Implementation
 *
 * v0.25.0
 * License: GPL-3.0
 *
 * All network operations are simulated stubs (FNV-1a based) for
 * prototype purposes. Scan results, IP and MAC addresses are
 * generated deterministically. No real radio stack is involved.
 */

#include "phantom/network/network_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include "phantom/nids/nids_engine.h"

#include <algorithm>
#include <sstream>
#include <cstring>
#include <cstdio>

namespace phantom::network {

// FNV-1a constants (matching project convention)
static constexpr uint64_t FNV_OFFSET_BASIS = 14695981039346656037ULL;
static constexpr uint64_t FNV_PRIME = 1099511628211ULL;

// Fixed device MAC (used when randomization is disabled)
static const char* DEVICE_MAC = "F4:96:34:11:22:33";

// ============================================================
// Helpers
// ============================================================

uint64_t NetworkManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ != 0) {
        return timeOverrideMs_;
    }
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

void NetworkManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::NETWORK, message, "NetworkManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::NETWORK, message, "NetworkManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::NETWORK, message, "NetworkManager");
        }
    }
}

void NetworkManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId.empty() ? "network_manager" : appId,
                                   "network_manager", 0, message);
    }
}

uint64_t NetworkManager::computeFNV1a(const std::string& data) const {
    uint64_t hash = FNV_OFFSET_BASIS;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    return hash;
}

uint64_t NetworkManager::hashSecret(const std::string& secret, uint64_t salt) const {
    uint64_t hash = FNV_OFFSET_BASIS ^ salt;
    for (unsigned char c : secret) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    std::string saltStr = std::to_string(salt);
    for (unsigned char c : saltStr) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    return hash;
}

void NetworkManager::changeConnectionState(NetworkState newState) {
    if (connection_.state == newState) {
        return;
    }
    NetworkState old = connection_.state;
    connection_.state = newState;
    if (connectionStateCb_) {
        connectionStateCb_(old, newState);
    }
}

void NetworkManager::recordEvent(NetworkEventType type, NetworkResult result,
                                 const std::string& ssid, const std::string& appId,
                                 const std::string& detail) {
    NetworkEvent event;
    event.id = nextEventId_++;
    event.type = type;
    event.result = result;
    event.ssid = ssid;
    event.appId = appId;
    event.detail = detail;
    event.timestamp = getCurrentTimeMs();

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        events_.erase(events_.begin());
    }
    byEventType_[static_cast<size_t>(type)]++;

    if (networkEventCb_) {
        networkEventCb_(event);
    }
}

void NetworkManager::moveToHistory(const NetworkEvent& event) {
    history_.push_back(event);
    if (history_.size() > maxHistory_) {
        history_.erase(history_.begin());
    }
}

bool NetworkManager::isSystemOwner(const std::string& owner) const {
    return owner == "system" || owner == "phantos.system";
}

std::string NetworkManager::generateMacAddress(const std::string& seed) const {
    if (!macRandomization_) {
        return DEVICE_MAC;
    }
    uint64_t hash = computeFNV1a(seed + std::to_string(successfulConnections_));
    char buf[18];
    std::snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                  static_cast<int>(0x02),  // Locally administered, unicast
                  static_cast<int>((hash >> 40) & 0xFF),
                  static_cast<int>((hash >> 32) & 0xFF),
                  static_cast<int>((hash >> 24) & 0xFF),
                  static_cast<int>((hash >> 16) & 0xFF),
                  static_cast<int>((hash >> 8) & 0xFF));
    return std::string(buf);
}

std::string NetworkManager::generateIpAddress(const std::string& seed) const {
    uint64_t hash = computeFNV1a(seed);
    char buf[16];
    std::snprintf(buf, sizeof(buf), "10.%d.%d.%d",
                  static_cast<int>((hash >> 32) & 0xFF),
                  static_cast<int>((hash >> 24) & 0xFF),
                  static_cast<int>((hash >> 16) & 0xFF) + 1);
    return std::string(buf);
}

bool NetworkManager::isCaptivePortalSsid(const std::string& ssid) const {
    return ssid == "CoffeeShop_Free";
}

std::vector<NetworkInfo> NetworkManager::generateMockScan(NetworkType type) const {
    // Deterministic simulated networks per type
    struct MockNet {
        const char* ssid;
        SecurityType security;
        uint32_t freq;
    };
    std::vector<MockNet> mocks;
    if (type == NetworkType::WIFI) {
        mocks = {
            {"PhantomNet", SecurityType::WPA3, 5180},
            {"HomeNet", SecurityType::WPA2, 2437},
            {"CoffeeShop_Free", SecurityType::OPEN, 2437},
            {"DeadEnd_NoInet", SecurityType::OPEN, 2462},
            {"Neighbor_5G", SecurityType::WPA2, 5220},
            {"Enterprise-Corp", SecurityType::ENTERPRISE_STUB, 5240},
        };
    } else if (type == NetworkType::CELLULAR) {
        mocks = {
            {"PhantomTelecom", SecurityType::OPEN, 0},
            {"RoamNet", SecurityType::OPEN, 0},
        };
    } else if (type == NetworkType::BLUETOOTH_PAN) {
        mocks = {{"PhantomBT-PAN", SecurityType::OPEN, 0}};
    } else if (type == NetworkType::USB_TETHER) {
        mocks = {{"PhantomUSB", SecurityType::OPEN, 0}};
    } else {
        mocks = {{"lo", SecurityType::OPEN, 0}};
    }

    std::vector<NetworkInfo> results;
    for (const auto& mock : mocks) {
        NetworkInfo info;
        info.ssid = mock.ssid;
        info.type = type;
        info.security = mock.security;
        info.frequencyMhz = mock.freq;
        // Deterministic signal strength 40-100 from SSID hash
        info.signalStrength = 40 + computeFNV1a(std::string(mock.ssid) +
                                                std::to_string(static_cast<int>(type))) % 61;
        // Deterministic BSSID from SSID hash
        uint64_t hash = computeFNV1a(std::string("bssid:") + mock.ssid);
        char buf[18];
        std::snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
                      static_cast<int>((hash >> 40) & 0xFF),
                      static_cast<int>((hash >> 32) & 0xFF),
                      static_cast<int>((hash >> 24) & 0xFF),
                      static_cast<int>((hash >> 16) & 0xFF),
                      static_cast<int>((hash >> 8) & 0xFF),
                      static_cast<int>(hash & 0xFF));
        info.bssid = std::string(buf);
        info.timestamp = getCurrentTimeMs();
        results.push_back(info);
    }
    return results;
}

void NetworkManager::registerWithNids() {
    if (!nidsEngine_ || !nidsEngine_->isInitialized()) {
        return;
    }
    phantom::nids::NetworkConnection conn;
    conn.sourceIp = connection_.ipAddress;
    conn.destIp = connection_.gateway;
    conn.sourcePort = 49152 + static_cast<uint16_t>(successfulConnections_ % 16000);
    conn.destPort = 443;
    conn.protocol = 6;  // TCP
    conn.state = phantom::nids::ConnectionState::ESTABLISHED;
    conn.timestamp = getCurrentTimeMs();
    conn.isInbound = false;
    nextNidsConnectionId_ = nidsEngine_->registerConnection(conn);
}

void NetworkManager::closeNidsConnection() {
    if (nidsEngine_ && nextNidsConnectionId_ != 0) {
        nidsEngine_->closeConnection(nextNidsConnectionId_);
        nextNidsConnectionId_ = 0;
    }
}

// ============================================================
// Lifecycle
// ============================================================

NetworkResult NetworkManager::initialize(size_t maxProfiles, size_t maxEvents,
                                         size_t maxHistory, size_t maxApps) {
    if (initialized_) {
        return NetworkResult::ALREADY_INITIALIZED;
    }
    if (maxProfiles == 0 || maxEvents == 0 || maxHistory == 0 || maxApps == 0) {
        return NetworkResult::INVALID_PARAMETER;
    }
    maxProfiles_ = maxProfiles;
    maxEvents_ = maxEvents;
    maxHistory_ = maxHistory;
    maxApps_ = maxApps;
    connection_ = ConnectionInfo{};
    connection_.state = NetworkState::DISCONNECTED;
    dataUsage_ = DataUsage{};
    initialized_ = true;
    logToServer("info", "NetworkManager initialized (maxProfiles=" +
                        std::to_string(maxProfiles) + ")");
    return NetworkResult::SUCCESS;
}

NetworkResult NetworkManager::shutdown() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    closeNidsConnection();
    profiles_.clear();
    scanResults_.clear();
    appAccess_.clear();
    events_.clear();
    history_.clear();
    connection_ = ConnectionInfo{};
    connection_.state = NetworkState::DISCONNECTED;
    dataUsage_ = DataUsage{};
    lastProfileId_ = 0;
    lastAppId_.clear();
    nextNidsConnectionId_ = 0;
    initialized_ = false;
    logToServer("info", "NetworkManager shut down");
    return NetworkResult::SUCCESS;
}

// ============================================================
// Radio control
// ============================================================

NetworkResult NetworkManager::setRadioEnabled(NetworkType type, bool enabled) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (type == NetworkType::LOOPBACK) {
        return NetworkResult::INVALID_PARAMETER;  // Loopback cannot be disabled
    }
    radios_[static_cast<size_t>(type)] = enabled;
    recordEvent(NetworkEventType::RADIO_CHANGED, NetworkResult::SUCCESS, "", "",
                std::string(networkTypeToString(type)) + (enabled ? " enabled" : " disabled"));
    logToServer("info", std::string("Radio ") + networkTypeToString(type) +
                        (enabled ? " enabled" : " disabled"));
    return NetworkResult::SUCCESS;
}

bool NetworkManager::isRadioEnabled(NetworkType type) const {
    if (type == NetworkType::LOOPBACK) {
        return true;  // Always on
    }
    if (airplaneMode_) {
        return false;
    }
    return radios_[static_cast<size_t>(type)];
}

NetworkResult NetworkManager::setAirplaneMode(bool enabled, const std::string& owner) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return NetworkResult::PERMISSION_DENIED;
    }
    if (airplaneMode_ == enabled) {
        return NetworkResult::BAD_STATE;
    }
    airplaneMode_ = enabled;
    if (enabled) {
        // Airplane mode tears down any active connection
        if (connection_.state == NetworkState::CONNECTED ||
            connection_.state == NetworkState::CAPTIVE_PORTAL ||
            connection_.state == NetworkState::LIMITED) {
            closeNidsConnection();
            disconnects_++;
            recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::SUCCESS,
                        connection_.ssid, "", "Airplane mode enabled");
            changeConnectionState(NetworkState::DISCONNECTED);
            connection_ = ConnectionInfo{};
            connection_.state = NetworkState::DISCONNECTED;
        }
    }
    recordEvent(NetworkEventType::RADIO_CHANGED, NetworkResult::SUCCESS, "", "",
                enabled ? "Airplane mode on" : "Airplane mode off");
    logToServer("info", std::string("Airplane mode ") + (enabled ? "enabled" : "disabled"));
    return NetworkResult::SUCCESS;
}

// ============================================================
// Scanning
// ============================================================

NetworkResult NetworkManager::requestScan(NetworkType type) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (type == NetworkType::LOOPBACK) {
        return NetworkResult::INVALID_PARAMETER;  // Nothing to scan
    }
    if (!isRadioEnabled(type)) {
        return NetworkResult::RADIO_DISABLED;
    }
    scansRequested_++;
    std::vector<NetworkInfo> results = generateMockScan(type);
    networksFound_ += results.size();
    for (const auto& net : results) {
        recordEvent(NetworkEventType::NETWORK_FOUND, NetworkResult::SUCCESS, net.ssid, "",
                    "Signal " + std::to_string(net.signalStrength));
    }
    scanResults_[type] = results;
    recordEvent(NetworkEventType::SCAN_STARTED, NetworkResult::SUCCESS, "", "",
                std::string("Scan ") + networkTypeToString(type) + ": " +
                std::to_string(results.size()) + " networks");
    logToServer("info", std::string("Scan ") + networkTypeToString(type) + " found " +
                        std::to_string(results.size()) + " networks");
    return NetworkResult::SUCCESS;
}

std::vector<NetworkInfo> NetworkManager::getScanResults(NetworkType type,
                                                        uint64_t maxAgeMs) const {
    auto it = scanResults_.find(type);
    if (it == scanResults_.end()) {
        return {};
    }
    if (maxAgeMs == 0) {
        return it->second;
    }
    // Note: uses real current time (const method)
    uint64_t now = 0;
    std::vector<NetworkInfo> fresh;
    for (const auto& net : it->second) {
        if (now == 0) {
            NetworkManager* self = const_cast<NetworkManager*>(this);
            now = self->getCurrentTimeMs();
        }
        if (net.timestamp + maxAgeMs >= now) {
            fresh.push_back(net);
        }
    }
    return fresh;
}

bool NetworkManager::hasNetwork(const std::string& ssid, NetworkType type) const {
    auto it = scanResults_.find(type);
    if (it == scanResults_.end()) {
        return false;
    }
    for (const auto& net : it->second) {
        if (net.ssid == ssid) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Profiles
// ============================================================

uint64_t NetworkManager::addProfile(const std::string& ssid, const std::string& password,
                                     NetworkType type, SecurityType security,
                                     bool autoConnect, int32_t priority, bool metered) {
    if (!initialized_) {
        return 0;
    }
    if (ssid.empty()) {
        return 0;
    }
    if (getProfileBySsid(ssid, type) != 0) {
        return 0;  // Duplicate profile for this type
    }
    if (profiles_.size() >= maxProfiles_) {
        return 0;  // Capacity exceeded
    }
    NetworkProfile profile;
    profile.id = nextProfileId_++;
    profile.ssid = ssid;
    profile.type = type;
    profile.security = security;
    profile.autoConnect = autoConnect;
    profile.priority = priority;
    profile.metered = metered;
    profile.createdAt = getCurrentTimeMs();
    profile.passwordSalt = profile.id * FNV_PRIME ^ profile.createdAt;
    profile.passwordHash = hashSecret(password, profile.passwordSalt);
    profiles_[profile.id] = profile;
    profilesSaved_++;
    logToServer("info", "Profile saved: " + ssid);
    return profile.id;
}

NetworkResult NetworkManager::removeProfile(uint64_t profileId) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    auto it = profiles_.find(profileId);
    if (it == profiles_.end()) {
        return NetworkResult::PROFILE_NOT_FOUND;
    }
    // Cannot remove the profile of the active connection
    if (connection_.profileId == profileId && isConnected()) {
        return NetworkResult::BAD_STATE;
    }
    profiles_.erase(it);
    profilesRemoved_++;
    logToServer("info", "Profile removed: " + std::to_string(profileId));
    return NetworkResult::SUCCESS;
}

NetworkResult NetworkManager::updateProfile(uint64_t profileId, const std::string& password,
                                            int32_t priority, bool autoConnect, bool metered) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    auto it = profiles_.find(profileId);
    if (it == profiles_.end()) {
        return NetworkResult::PROFILE_NOT_FOUND;
    }
    if (!password.empty()) {
        it->second.passwordSalt = it->second.id * FNV_PRIME ^ getCurrentTimeMs();
        it->second.passwordHash = hashSecret(password, it->second.passwordSalt);
    }
    if (priority >= 0) {
        it->second.priority = priority;
    }
    it->second.autoConnect = autoConnect;
    it->second.metered = metered;
    logToServer("info", "Profile updated: " + it->second.ssid);
    return NetworkResult::SUCCESS;
}

NetworkProfile NetworkManager::getProfile(uint64_t profileId) const {
    auto it = profiles_.find(profileId);
    if (it == profiles_.end()) {
        return NetworkProfile{};
    }
    return it->second;
}

uint64_t NetworkManager::getProfileBySsid(const std::string& ssid, NetworkType type) const {
    for (const auto& pair : profiles_) {
        if (pair.second.ssid == ssid && pair.second.type == type) {
            return pair.first;
        }
    }
    return 0;
}

std::vector<NetworkProfile> NetworkManager::getSavedProfiles() const {
    std::vector<NetworkProfile> result;
    for (const auto& pair : profiles_) {
        result.push_back(pair.second);
    }
    return result;
}

// ============================================================
// Connection
// ============================================================

bool NetworkManager::isConnected() const {
    return connection_.state == NetworkState::CONNECTED ||
           connection_.state == NetworkState::CAPTIVE_PORTAL ||
           connection_.state == NetworkState::LIMITED ||
           connection_.state == NetworkState::ROAMING;
}

NetworkResult NetworkManager::connect(uint64_t profileId, const std::string& appId,
                                      const std::string& password) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    connectAttempts_++;

    auto it = profiles_.find(profileId);
    if (it == profiles_.end()) {
        byResult_[static_cast<size_t>(NetworkResult::PROFILE_NOT_FOUND)]++;
        return NetworkResult::PROFILE_NOT_FOUND;
    }
    NetworkProfile& profile = it->second;

    byNetworkType_[static_cast<size_t>(profile.type)]++;

    if (isConnected()) {
        byResult_[static_cast<size_t>(NetworkResult::ALREADY_CONNECTED)]++;
        return NetworkResult::ALREADY_CONNECTED;
    }
    if (!isRadioEnabled(profile.type)) {
        byResult_[static_cast<size_t>(NetworkResult::RADIO_DISABLED)]++;
        recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::RADIO_DISABLED,
                    profile.ssid, appId, "Radio disabled");
        return NetworkResult::RADIO_DISABLED;
    }
    NetworkPolicy policy = policies_[static_cast<size_t>(profile.type)];
    if (policy == NetworkPolicy::BLOCKED) {
        byResult_[static_cast<size_t>(NetworkResult::PERMISSION_DENIED)]++;
        recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::PERMISSION_DENIED,
                    profile.ssid, appId, "Network type blocked by policy");
        return NetworkResult::PERMISSION_DENIED;
    }

    // Metered determination for app access check
    bool willBeMetered = profile.metered || policy == NetworkPolicy::METERED ||
                         policy == NetworkPolicy::DATA_SAVER;
    if (!appId.empty() && !isAppAllowed(appId, willBeMetered)) {
        appsBlocked_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(NetworkResult::PERMISSION_DENIED)]++;
        recordEvent(NetworkEventType::APP_ACCESS_BLOCKED, NetworkResult::PERMISSION_DENIED,
                    profile.ssid, appId, willBeMetered ? "App blocked (metered)" : "App blocked");
        logToServer("warn", "Network access blocked for app " + appId);
        return NetworkResult::PERMISSION_DENIED;
    }

    // Firewall check (NIDS)
    std::string gateway = generateIpAddress("gw:" + profile.ssid);
    if (nidsEngine_ && nidsEngine_->isInitialized() && nidsEngine_->isIpBlocked(gateway)) {
        firewallBlocks_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(NetworkResult::CONNECTION_FAILED)]++;
        changeConnectionState(NetworkState::FAILED);
        recordEvent(NetworkEventType::FIREWALL_BLOCKED, NetworkResult::CONNECTION_FAILED,
                    profile.ssid, appId, "Gateway blocked by firewall: " + gateway);
        logToServer("warn", "Connection blocked by firewall: " + profile.ssid);
        return NetworkResult::CONNECTION_FAILED;
    }

    // Connecting
    changeConnectionState(NetworkState::CONNECTING);

    // Failure simulation hook
    if (failNextConnection_) {
        failNextConnection_ = false;
        failedConnections_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(NetworkResult::CONNECTION_FAILED)]++;
        changeConnectionState(NetworkState::FAILED);
        recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::CONNECTION_FAILED,
                    profile.ssid, appId, "Simulated connection failure");
        return NetworkResult::CONNECTION_FAILED;
    }

    // Password verification (if provided; empty = use stored credentials)
    if (profile.security != SecurityType::OPEN && !password.empty()) {
        if (hashSecret(password, profile.passwordSalt) != profile.passwordHash) {
            authFailures_++;
            failedConnections_++;
            totalFailures_++;
            byResult_[static_cast<size_t>(NetworkResult::AUTH_FAILED)]++;
            changeConnectionState(NetworkState::FAILED);
            recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::AUTH_FAILED,
                        profile.ssid, appId, "Wrong password");
            logToServer("warn", "Auth failed for " + profile.ssid);
            notifyCrashReporter(appId, "network_auth_failed");
            return NetworkResult::AUTH_FAILED;
        }
    }

    // Build the connection
    ConnectionInfo info;
    info.type = profile.type;
    info.ssid = profile.ssid;
    info.bssid = profile.bssid;
    info.signalStrength = 40 + computeFNV1a(profile.ssid + "sig") % 61;
    info.ipAddress = generateIpAddress("ip:" + profile.ssid);
    info.gateway = gateway;
    info.dnsPrimary = generateIpAddress("dns1:" + profile.ssid);
    info.dnsSecondary = generateIpAddress("dns2:" + profile.ssid);
    info.macAddress = generateMacAddress("mac:" + profile.ssid);
    info.metered = willBeMetered;
    info.roaming = (profile.ssid == "RoamNet");
    info.dnsPrivacy = dnsPrivacy_ || policy == NetworkPolicy::PRIVACY;
    info.connectedAt = getCurrentTimeMs();
    info.profileId = profile.id;
    if (policy == NetworkPolicy::PRIVACY) {
        info.macAddress = generateMacAddress("privmac:" + profile.ssid);
    }

    // Determine final state
    if (isCaptivePortalSsid(profile.ssid)) {
        info.captivePortal = true;
        info.state = NetworkState::CAPTIVE_PORTAL;
        captivePortals_++;
    } else if (profile.ssid == "DeadEnd_NoInet") {
        info.state = NetworkState::LIMITED;
    } else if (info.roaming) {
        info.state = NetworkState::ROAMING;
    } else {
        info.state = NetworkState::CONNECTED;
    }

    connection_ = info;
    if (connectionStateCb_) {
        connectionStateCb_(NetworkState::CONNECTING, info.state);
    }

    profile.connectCount++;
    profile.lastConnectedAt = getCurrentTimeMs();
    successfulConnections_++;
    byResult_[static_cast<size_t>(NetworkResult::SUCCESS)]++;
    lastProfileId_ = profile.id;
    lastAppId_ = appId;

    if (info.captivePortal) {
        recordEvent(NetworkEventType::CAPTIVE_PORTAL_DETECTED, NetworkResult::SUCCESS,
                    profile.ssid, appId, "Captive portal detected");
    }
    recordEvent(NetworkEventType::CONNECTED, NetworkResult::SUCCESS, profile.ssid, appId,
                std::string(networkTypeToString(profile.type)) + " connected");
    registerWithNids();
    logToServer("info", "Connected to " + profile.ssid);
    return NetworkResult::SUCCESS;
}

NetworkResult NetworkManager::disconnect() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (!isConnected()) {
        return NetworkResult::NOT_CONNECTED;
    }
    closeNidsConnection();
    disconnects_++;
    changeConnectionState(NetworkState::DISCONNECTED);
    std::string ssid = connection_.ssid;
    connection_ = ConnectionInfo{};
    connection_.state = NetworkState::DISCONNECTED;
    recordEvent(NetworkEventType::DISCONNECTED, NetworkResult::SUCCESS, ssid, "",
                "Disconnected");
    logToServer("info", "Disconnected from " + ssid);
    return NetworkResult::SUCCESS;
}

NetworkResult NetworkManager::reconnect() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (lastProfileId_ == 0) {
        return NetworkResult::NOT_CONNECTED;
    }
    if (isConnected()) {
        disconnect();
    }
    reconnects_++;
    return connect(lastProfileId_, lastAppId_);
}

NetworkResult NetworkManager::checkConnectivity() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    switch (connection_.state) {
        case NetworkState::CONNECTED:
        case NetworkState::ROAMING:
            return NetworkResult::SUCCESS;
        case NetworkState::CAPTIVE_PORTAL:
            recordEvent(NetworkEventType::CAPTIVE_PORTAL_DETECTED, NetworkResult::AUTH_FAILED,
                        connection_.ssid, "", "Portal sign-in required");
            return NetworkResult::AUTH_FAILED;
        case NetworkState::LIMITED:
            return NetworkResult::CONNECTION_FAILED;
        default:
            return NetworkResult::BAD_STATE;
    }
}

NetworkResult NetworkManager::updateDataUsage(const std::string& appId, uint64_t bytesRx,
                                               uint64_t bytesTx) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (!isConnected()) {
        return NetworkResult::NOT_CONNECTED;
    }
    if (!appId.empty() && !isAppAllowed(appId, connection_.metered)) {
        appsBlocked_++;
        byResult_[static_cast<size_t>(NetworkResult::PERMISSION_DENIED)]++;
        recordEvent(NetworkEventType::APP_ACCESS_BLOCKED, NetworkResult::PERMISSION_DENIED,
                    connection_.ssid, appId, "Data usage blocked");
        return NetworkResult::PERMISSION_DENIED;
    }
    dataUsage_.bytesRx += bytesRx;
    dataUsage_.bytesTx += bytesTx;
    dataUsage_.totalBytes = dataUsage_.bytesRx + dataUsage_.bytesTx;
    if (connection_.metered) {
        dataUsage_.meteredBytes += bytesRx + bytesTx;
    }
    return NetworkResult::SUCCESS;
}

NetworkResult NetworkManager::resetDataUsage() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    dataUsage_ = DataUsage{};
    return NetworkResult::SUCCESS;
}

// ============================================================
// Policies
// ============================================================

NetworkResult NetworkManager::setNetworkPolicy(NetworkType type, NetworkPolicy policy,
                                                const std::string& owner) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return NetworkResult::PERMISSION_DENIED;
    }
    policies_[static_cast<size_t>(type)] = policy;
    recordEvent(NetworkEventType::POLICY_CHANGED, NetworkResult::SUCCESS, "", "",
                std::string(networkTypeToString(type)) + " -> " + networkPolicyToString(policy));
    logToServer("info", std::string("Policy for ") + networkTypeToString(type) + " set to " +
                        networkPolicyToString(policy));
    return NetworkResult::SUCCESS;
}

NetworkPolicy NetworkManager::getNetworkPolicy(NetworkType type) const {
    return policies_[static_cast<size_t>(type)];
}

NetworkResult NetworkManager::setAppNetworkAccess(const std::string& appId, bool allowed,
                                                   bool allowMetered) {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    if (appId.empty()) {
        return NetworkResult::INVALID_PARAMETER;
    }
    auto it = appAccess_.find(appId);
    if (it == appAccess_.end() && appAccess_.size() >= maxApps_) {
        return NetworkResult::CAPACITY_EXCEEDED;
    }
    AppNetworkAccess& access = appAccess_[appId];
    access.appId = appId;
    access.allowed = allowed;
    access.allowMetered = allowMetered;
    return NetworkResult::SUCCESS;
}

AppNetworkAccess NetworkManager::getAppNetworkAccess(const std::string& appId) const {
    auto it = appAccess_.find(appId);
    if (it == appAccess_.end()) {
        AppNetworkAccess def;
        def.appId = appId;
        return def;  // Defaults: allowed, metered denied
    }
    return it->second;
}

bool NetworkManager::isAppAllowed(const std::string& appId, bool metered) const {
    AppNetworkAccess access = getAppNetworkAccess(appId);
    if (!access.allowed) {
        return false;
    }
    if (metered && !access.allowMetered) {
        return false;
    }
    return true;
}

// ============================================================
// Events, stats and history
// ============================================================

std::vector<NetworkEvent> NetworkManager::getEvents(size_t limit) const {
    std::vector<NetworkEvent> result;
    if (limit == 0 || limit >= events_.size()) {
        result = events_;
    } else {
        result.assign(events_.end() - static_cast<std::ptrdiff_t>(limit), events_.end());
    }
    return result;
}

std::vector<NetworkEvent> NetworkManager::getEventsByType(NetworkEventType type,
                                                          size_t limit) const {
    std::vector<NetworkEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
            if (limit != 0 && result.size() >= limit) {
                break;
            }
        }
    }
    return result;
}

NetworkResult NetworkManager::clearEvents() {
    if (!initialized_) {
        return NetworkResult::NOT_INITIALIZED;
    }
    for (const auto& event : events_) {
        moveToHistory(event);
    }
    events_.clear();
    return NetworkResult::SUCCESS;
}

NetworkManagerStats NetworkManager::getStats() const {
    NetworkManagerStats stats;
    stats.scansRequested = scansRequested_;
    stats.networksFound = networksFound_;
    stats.connectAttempts = connectAttempts_;
    stats.successfulConnections = successfulConnections_;
    stats.failedConnections = failedConnections_;
    stats.authFailures = authFailures_;
    stats.disconnects = disconnects_;
    stats.reconnects = reconnects_;
    stats.captivePortals = captivePortals_;
    stats.firewallBlocks = firewallBlocks_;
    stats.bytesRx = dataUsage_.bytesRx;
    stats.bytesTx = dataUsage_.bytesTx;
    stats.meteredBytes = dataUsage_.meteredBytes;
    stats.profilesSaved = profilesSaved_;
    stats.profilesRemoved = profilesRemoved_;
    stats.appsBlocked = appsBlocked_;
    stats.totalFailures = totalFailures_;
    for (size_t i = 0; i < 5; i++) {
        stats.byNetworkType[i] = byNetworkType_[i];
    }
    for (size_t i = 0; i < 9; i++) {
        stats.byEventType[i] = byEventType_[i];
    }
    for (size_t i = 0; i < 16; i++) {
        stats.byResult[i] = byResult_[i];
    }
    return stats;
}

void NetworkManager::resetStats() {
    scansRequested_ = 0;
    networksFound_ = 0;
    connectAttempts_ = 0;
    successfulConnections_ = 0;
    failedConnections_ = 0;
    authFailures_ = 0;
    disconnects_ = 0;
    reconnects_ = 0;
    captivePortals_ = 0;
    firewallBlocks_ = 0;
    profilesSaved_ = 0;
    profilesRemoved_ = 0;
    appsBlocked_ = 0;
    totalFailures_ = 0;
    for (size_t i = 0; i < 5; i++) {
        byNetworkType_[i] = 0;
    }
    for (size_t i = 0; i < 9; i++) {
        byEventType_[i] = 0;
    }
    for (size_t i = 0; i < 16; i++) {
        byResult_[i] = 0;
    }
}

// ============================================================
// String helpers
// ============================================================

const char* NetworkManager::networkTypeToString(NetworkType type) {
    switch (type) {
        case NetworkType::WIFI: return "WIFI";
        case NetworkType::CELLULAR: return "CELLULAR";
        case NetworkType::BLUETOOTH_PAN: return "BLUETOOTH_PAN";
        case NetworkType::USB_TETHER: return "USB_TETHER";
        case NetworkType::LOOPBACK: return "LOOPBACK";
    }
    return "UNKNOWN";
}

const char* NetworkManager::networkStateToString(NetworkState state) {
    switch (state) {
        case NetworkState::DISABLED: return "DISABLED";
        case NetworkState::DISCONNECTED: return "DISCONNECTED";
        case NetworkState::SCANNING: return "SCANNING";
        case NetworkState::CONNECTING: return "CONNECTING";
        case NetworkState::CONNECTED: return "CONNECTED";
        case NetworkState::CAPTIVE_PORTAL: return "CAPTIVE_PORTAL";
        case NetworkState::LIMITED: return "LIMITED";
        case NetworkState::ROAMING: return "ROAMING";
        case NetworkState::FAILED: return "FAILED";
    }
    return "UNKNOWN";
}

const char* NetworkManager::securityTypeToString(SecurityType security) {
    switch (security) {
        case SecurityType::OPEN: return "OPEN";
        case SecurityType::WPA2: return "WPA2";
        case SecurityType::WPA3: return "WPA3";
        case SecurityType::ENTERPRISE_STUB: return "ENTERPRISE_STUB";
    }
    return "UNKNOWN";
}

const char* NetworkManager::networkPolicyToString(NetworkPolicy policy) {
    switch (policy) {
        case NetworkPolicy::NORMAL: return "NORMAL";
        case NetworkPolicy::METERED: return "METERED";
        case NetworkPolicy::DATA_SAVER: return "DATA_SAVER";
        case NetworkPolicy::PRIVACY: return "PRIVACY";
        case NetworkPolicy::BLOCKED: return "BLOCKED";
    }
    return "UNKNOWN";
}

const char* NetworkManager::networkResultToString(NetworkResult result) {
    switch (result) {
        case NetworkResult::SUCCESS: return "SUCCESS";
        case NetworkResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case NetworkResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case NetworkResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case NetworkResult::PROFILE_NOT_FOUND: return "PROFILE_NOT_FOUND";
        case NetworkResult::NETWORK_NOT_FOUND: return "NETWORK_NOT_FOUND";
        case NetworkResult::PROFILE_EXISTS: return "PROFILE_EXISTS";
        case NetworkResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case NetworkResult::ALREADY_CONNECTED: return "ALREADY_CONNECTED";
        case NetworkResult::NOT_CONNECTED: return "NOT_CONNECTED";
        case NetworkResult::CONNECTION_FAILED: return "CONNECTION_FAILED";
        case NetworkResult::AUTH_FAILED: return "AUTH_FAILED";
        case NetworkResult::RADIO_DISABLED: return "RADIO_DISABLED";
        case NetworkResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case NetworkResult::BAD_STATE: return "BAD_STATE";
        case NetworkResult::OPERATION_FAILED: return "OPERATION_FAILED";
    }
    return "UNKNOWN";
}

const char* NetworkManager::networkEventTypeToString(NetworkEventType type) {
    switch (type) {
        case NetworkEventType::SCAN_STARTED: return "SCAN_STARTED";
        case NetworkEventType::NETWORK_FOUND: return "NETWORK_FOUND";
        case NetworkEventType::CONNECTED: return "CONNECTED";
        case NetworkEventType::DISCONNECTED: return "DISCONNECTED";
        case NetworkEventType::POLICY_CHANGED: return "POLICY_CHANGED";
        case NetworkEventType::APP_ACCESS_BLOCKED: return "APP_ACCESS_BLOCKED";
        case NetworkEventType::CAPTIVE_PORTAL_DETECTED: return "CAPTIVE_PORTAL_DETECTED";
        case NetworkEventType::FIREWALL_BLOCKED: return "FIREWALL_BLOCKED";
        case NetworkEventType::RADIO_CHANGED: return "RADIO_CHANGED";
    }
    return "UNKNOWN";
}

NetworkType NetworkManager::stringToNetworkType(const std::string& str) {
    if (str == "WIFI") return NetworkType::WIFI;
    if (str == "CELLULAR") return NetworkType::CELLULAR;
    if (str == "BLUETOOTH_PAN") return NetworkType::BLUETOOTH_PAN;
    if (str == "USB_TETHER") return NetworkType::USB_TETHER;
    if (str == "LOOPBACK") return NetworkType::LOOPBACK;
    return NetworkType::WIFI;
}

NetworkState NetworkManager::stringToNetworkState(const std::string& str) {
    if (str == "DISABLED") return NetworkState::DISABLED;
    if (str == "DISCONNECTED") return NetworkState::DISCONNECTED;
    if (str == "SCANNING") return NetworkState::SCANNING;
    if (str == "CONNECTING") return NetworkState::CONNECTING;
    if (str == "CONNECTED") return NetworkState::CONNECTED;
    if (str == "CAPTIVE_PORTAL") return NetworkState::CAPTIVE_PORTAL;
    if (str == "LIMITED") return NetworkState::LIMITED;
    if (str == "ROAMING") return NetworkState::ROAMING;
    if (str == "FAILED") return NetworkState::FAILED;
    return NetworkState::DISCONNECTED;
}

NetworkResult NetworkManager::stringToNetworkResult(const std::string& str) {
    if (str == "SUCCESS") return NetworkResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return NetworkResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return NetworkResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return NetworkResult::INVALID_PARAMETER;
    if (str == "PROFILE_NOT_FOUND") return NetworkResult::PROFILE_NOT_FOUND;
    if (str == "NETWORK_NOT_FOUND") return NetworkResult::NETWORK_NOT_FOUND;
    if (str == "PROFILE_EXISTS") return NetworkResult::PROFILE_EXISTS;
    if (str == "CAPACITY_EXCEEDED") return NetworkResult::CAPACITY_EXCEEDED;
    if (str == "ALREADY_CONNECTED") return NetworkResult::ALREADY_CONNECTED;
    if (str == "NOT_CONNECTED") return NetworkResult::NOT_CONNECTED;
    if (str == "CONNECTION_FAILED") return NetworkResult::CONNECTION_FAILED;
    if (str == "AUTH_FAILED") return NetworkResult::AUTH_FAILED;
    if (str == "RADIO_DISABLED") return NetworkResult::RADIO_DISABLED;
    if (str == "PERMISSION_DENIED") return NetworkResult::PERMISSION_DENIED;
    if (str == "BAD_STATE") return NetworkResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return NetworkResult::OPERATION_FAILED;
    return NetworkResult::SUCCESS;
}

}  // namespace phantom::network
