/*
 * Phantom OS - Crash Reporter Implementation
 * v0.19.0
 * License: GPL-3.0
 */

#include "phantom/crashreporter/crash_reporter.h"
#include "phantom/logging/log_server.h"
#include <algorithm>
#include <regex>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <cstring>

namespace phantom::crashreporter {

// ============================================================
// Private helpers
// ============================================================

uint64_t CrashReporter::getCurrentTimeMs() const {
    auto now = std::chrono::steady_clock::now();
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count());
}

int CrashReporter::findActiveIndex(uint64_t id) const {
    for (size_t i = 0; i < activeQueue_.size(); ++i) {
        if (activeQueue_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

int CrashReporter::findArchiveIndex(uint64_t id) const {
    for (size_t i = 0; i < archive_.size(); ++i) {
        if (archive_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

void CrashReporter::removeFromActive(uint64_t id) {
    activeQueue_.erase(
        std::remove_if(activeQueue_.begin(), activeQueue_.end(),
                       [id](const CrashReport& r) { return r.id == id; }),
        activeQueue_.end());
}

void CrashReporter::moveToArchive(uint64_t id, CrashState newState) {
    int idx = findActiveIndex(id);
    if (idx >= 0) {
        CrashReport report = activeQueue_[idx];
        report.state = newState;
        if (archive_.size() >= maxArchiveSize_) {
            archive_.erase(archive_.begin());
        }
        archive_.push_back(report);
        removeFromActive(id);
    }
}

uint64_t CrashReporter::fnv1aHash(const std::string& data) const {
    // FNV-1a 64-bit hash
    uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    return hash;
}

void CrashReporter::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::FRAMEWORK, message, "CrashReporter");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::FRAMEWORK, message, "CrashReporter");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::FRAMEWORK, message, "CrashReporter");
        }
    }
}

void CrashReporter::pruneRecentCrashTimes() {
    uint64_t now = getCurrentTimeMs();
    if (now < 3600000) return;  // Clock hasn't been running for 1 hour, nothing to prune
    uint64_t cutoff = now - 3600000;  // 1 hour ago
    recentCrashTimes_.erase(
        std::remove_if(recentCrashTimes_.begin(), recentCrashTimes_.end(),
                       [cutoff](uint64_t t) { return t < cutoff; }),
        recentCrashTimes_.end());
}

bool CrashReporter::isRateLimited() const {
    return recentCrashTimes_.size() >= maxCrashesPerHour_;
}

void CrashReporter::addToGroup(const CrashReport& report) {
    if (report.crashHash.empty()) return;

    auto it = groups_.find(report.crashHash);
    if (it == groups_.end()) {
        CrashGroup group;
        group.groupId = nextGroupId_++;
        group.crashHash = report.crashHash;
        group.appId = report.appId;
        group.type = report.type;
        if (!report.stackTrace.empty()) {
            group.topFrame = report.stackTrace[0].function;
            if (group.topFrame.empty()) {
                group.topFrame = report.stackTrace[0].library;
            }
        }
        group.count = 1;
        group.firstSeen = report.timestamp;
        group.lastSeen = report.timestamp;
        group.highestSeverity = report.severity;
        group.crashIds.push_back(report.id);
        groups_[report.crashHash] = group;
    } else {
        it->second.count++;
        it->second.lastSeen = report.timestamp;
        it->second.crashIds.push_back(report.id);
        if (static_cast<int>(report.severity) < static_cast<int>(it->second.highestSeverity)) {
            it->second.highestSeverity = report.severity;
        }
    }
}

// ============================================================
// Lifecycle
// ============================================================

CrashResult CrashReporter::initialize(size_t maxQueueSize, size_t maxArchiveSize) {
    if (initialized_) return CrashResult::ALREADY_INITIALIZED;
    initialized_ = true;
    maxQueueSize_ = maxQueueSize;
    maxArchiveSize_ = maxArchiveSize;
    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::shutdown() {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    activeQueue_.clear();
    archive_.clear();
    groups_.clear();
    recentCrashTimes_.clear();
    totalCaptured_ = 0;
    totalProcessed_ = 0;
    totalDeduplicated_ = 0;
    totalUploaded_ = 0;
    totalFailed_ = 0;
    totalArchived_ = 0;
    totalDismissed_ = 0;
    totalRetrying_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalBySeverity_, 0, sizeof(totalBySeverity_));
    initialized_ = false;
    return CrashResult::SUCCESS;
}

// ============================================================
// Crash capture
// ============================================================

uint64_t CrashReporter::captureCrash(const CrashReport& report) {
    if (!initialized_) return 0;
    if (privacyLevel_ == CrashPrivacyLevel::DISABLED) return 0;
    if (report.appId.empty()) return 0;

    // Rate limiting
    pruneRecentCrashTimes();
    if (isRateLimited()) {
        logToServer("warn", "Crash capture rate limited for app: " + report.appId);
        return 0;
    }

    // Queue capacity
    if (activeQueue_.size() >= maxQueueSize_) {
        // Remove oldest non-archived
        moveToArchive(activeQueue_.front().id, CrashState::ARCHIVED);
        totalArchived_++;
    }

    CrashReport crash = report;
    crash.id = nextId_++;
    crash.capturedAt = getCurrentTimeMs();
    if (crash.timestamp == 0) crash.timestamp = crash.capturedAt;
    crash.state = CrashState::CAPTURED;

    // Compute crash hash for deduplication
    crash.crashHash = computeCrashHash(crash);

    // Check for duplicate
    for (const auto& existing : activeQueue_) {
        if (existing.crashHash == crash.crashHash) {
            totalDeduplicated_++;
            logToServer("info", "Duplicate crash detected for app: " + crash.appId);
            // Still add to group but mark as duplicate
            addToGroup(crash);
            return 0;  // Duplicate, not added to queue
        }
    }

    // Apply privacy scrubbing
    crash = applyPrivacyScrubbing(crash);

    activeQueue_.push_back(crash);
    totalCaptured_++;
    totalByType_[static_cast<int>(crash.type)]++;
    totalBySeverity_[static_cast<int>(crash.severity)]++;

    recentCrashTimes_.push_back(crash.capturedAt);

    // Add to group
    addToGroup(crash);

    logToServer("error", "Crash captured: " + crash.appId + " (" + crashTypeToString(crash.type) + ")");

    if (capturedCb_) capturedCb_(crash);

    // Auto-upload if enabled
    if (autoUpload_ && uploadPolicy_ != CrashUploadPolicy::NEVER) {
        queueForUpload(crash.id);
    }

    return crash.id;
}

uint64_t CrashReporter::captureSignalCrash(const std::string& appId, const std::string& processName,
                                            uint32_t pid, int32_t signal, int32_t signalCode,
                                            const std::string& crashReason,
                                            const std::vector<StackFrame>& stackTrace,
                                            const std::string& appVersion,
                                            uint64_t memoryUsage) {
    CrashReport report;
    report.appId = appId;
    report.processName = processName;
    report.appVersion = appVersion;
    report.pid = pid;
    report.signal = signal;
    report.signalCode = signalCode;
    report.type = signalToCrashType(signal);
    report.severity = CrashSeverity::FATAL;
    report.crashReason = crashReason;
    report.stackTrace = stackTrace;
    report.memoryUsage = memoryUsage;
    return captureCrash(report);
}

uint64_t CrashReporter::captureAnr(const std::string& appId, const std::string& processName,
                                    uint32_t pid, const std::string& reason,
                                    const std::string& appVersion) {
    CrashReport report;
    report.appId = appId;
    report.processName = processName;
    report.appVersion = appVersion;
    report.pid = pid;
    report.type = CrashType::ANR;
    report.severity = CrashSeverity::MAJOR;
    report.crashReason = reason;
    return captureCrash(report);
}

uint64_t CrashReporter::captureOom(const std::string& appId, const std::string& processName,
                                   uint32_t pid, uint64_t memoryUsage,
                                   const std::string& appVersion) {
    CrashReport report;
    report.appId = appId;
    report.processName = processName;
    report.appVersion = appVersion;
    report.pid = pid;
    report.type = CrashType::OOM;
    report.severity = CrashSeverity::CRITICAL;
    report.crashReason = "Out of memory";
    report.memoryUsage = memoryUsage;
    return captureCrash(report);
}

// ============================================================
// Crash processing
// ============================================================

void CrashReporter::processPending() {
    for (auto& report : activeQueue_) {
        if (report.state == CrashState::CAPTURED) {
            report.state = CrashState::PROCESSING;
            if (processCrash(report.id) == CrashResult::SUCCESS) {
                totalProcessed_++;
            }
        }
    }
}

CrashResult CrashReporter::processCrash(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    int idx = findActiveIndex(id);
    if (idx < 0) return CrashResult::NOT_FOUND;

    CrashReport& report = activeQueue_[idx];
    if (report.state != CrashState::CAPTURED && report.state != CrashState::PROCESSING) {
        return CrashResult::ALREADY_PROCESSED;
    }

    // Re-compute hash if empty
    if (report.crashHash.empty()) {
        report.crashHash = computeCrashHash(report);
    }

    // Privacy scrubbing already applied at capture, but re-apply if level changed
    report = applyPrivacyScrubbing(report);

    report.state = CrashState::QUEUED;
    if (processedCb_) processedCb_(report);

    return CrashResult::SUCCESS;
}

void CrashReporter::processRetries(uint64_t currentTimeMs) {
    if (currentTimeMs == 0) currentTimeMs = getCurrentTimeMs();

    // Collect IDs first to avoid iterator invalidation
    std::vector<uint64_t> toRetry;
    for (const auto& report : activeQueue_) {
        if (report.state == CrashState::RETRYING && report.nextRetryAt > 0 &&
            report.nextRetryAt <= currentTimeMs) {
            toRetry.push_back(report.id);
        }
    }

    for (uint64_t id : toRetry) {
        int idx = findActiveIndex(id);
        if (idx < 0) continue;

        CrashReport& report = activeQueue_[idx];
        if (report.retryCount >= maxRetries_) {
            report.state = CrashState::FAILED;
            totalFailed_++;
            if (failedCb_) failedCb_(report);
        } else {
            report.state = CrashState::QUEUED;
            // Attempt upload via processUploadQueue (safe: collects IDs first)
            processUploadQueue();
        }
    }
}

// ============================================================
// Deduplication
// ============================================================

std::string CrashReporter::computeCrashHash(const CrashReport& report) const {
    std::string hashInput = report.appId + "|" + crashTypeToString(report.type) + "|";

    // Use top 5 stack frames for fingerprinting
    size_t frameCount = std::min(report.stackTrace.size(), static_cast<size_t>(5));
    for (size_t i = 0; i < frameCount; ++i) {
        hashInput += report.stackTrace[i].library + ":" +
                     report.stackTrace[i].function + "|";
    }

    if (!report.crashReason.empty()) {
        hashInput += report.crashReason;
    }

    uint64_t hash = fnv1aHash(hashInput);

    std::ostringstream ss;
    ss << std::hex << std::setfill('0') << std::setw(16) << hash;
    return ss.str();
}

CrashGroup CrashReporter::getGroup(const std::string& crashHash) const {
    auto it = groups_.find(crashHash);
    if (it != groups_.end()) return it->second;
    return CrashGroup{};
}

std::vector<CrashGroup> CrashReporter::getGroups() const {
    std::vector<CrashGroup> result;
    for (const auto& [hash, group] : groups_) {
        result.push_back(group);
    }
    return result;
}

size_t CrashReporter::getGroupCrashCount(const std::string& crashHash) const {
    auto it = groups_.find(crashHash);
    if (it == groups_.end()) return 0;
    return it->second.count;
}

// ============================================================
// Upload (simulated)
// ============================================================

CrashResult CrashReporter::queueForUpload(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    if (uploadPolicy_ == CrashUploadPolicy::NEVER) return CrashResult::PRIVACY_DISABLED;

    int idx = findActiveIndex(id);
    if (idx < 0) return CrashResult::NOT_FOUND;

    activeQueue_[idx].state = CrashState::QUEUED;
    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::markUploaded(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    int idx = findActiveIndex(id);
    if (idx < 0) return CrashResult::NOT_FOUND;

    activeQueue_[idx].state = CrashState::UPLOADED;
    totalUploaded_++;

    logToServer("info", "Crash report uploaded: " + activeQueue_[idx].appId);

    if (uploadedCb_) uploadedCb_(activeQueue_[idx]);

    // Move to archive
    moveToArchive(id, CrashState::UPLOADED);
    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::markUploadFailed(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    int idx = findActiveIndex(id);
    if (idx < 0) return CrashResult::NOT_FOUND;

    CrashReport& report = activeQueue_[idx];
    report.retryCount++;

    if (report.retryCount >= maxRetries_) {
        report.state = CrashState::FAILED;
        totalFailed_++;
        if (failedCb_) failedCb_(report);
    } else {
        report.state = CrashState::RETRYING;
        totalRetrying_++;
        // Exponential backoff
        uint64_t delay = retryBaseDelayMs_ * (1ULL << report.retryCount);
        report.nextRetryAt = getCurrentTimeMs() + delay;
    }

    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::processUploadQueue() {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;

    // Collect IDs first to avoid iterator invalidation
    std::vector<uint64_t> toUpload;
    for (const auto& report : activeQueue_) {
        if (report.state == CrashState::QUEUED) {
            toUpload.push_back(report.id);
        }
    }
    for (uint64_t id : toUpload) {
        markUploaded(id);
    }
    return CrashResult::SUCCESS;
}

// ============================================================
// Archive management
// ============================================================

CrashResult CrashReporter::archive(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    int idx = findActiveIndex(id);
    if (idx < 0) {
        // Check archive
        int aIdx = findArchiveIndex(id);
        if (aIdx >= 0) return CrashResult::ALREADY_PROCESSED;
        return CrashResult::NOT_FOUND;
    }

    moveToArchive(id, CrashState::ARCHIVED);
    totalArchived_++;

    if (archivedCb_ && !archive_.empty()) archivedCb_(archive_.back());

    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::dismiss(uint64_t id) {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    int idx = findActiveIndex(id);
    if (idx < 0) return CrashResult::NOT_FOUND;

    moveToArchive(id, CrashState::DISMISSED);
    totalDismissed_++;
    return CrashResult::SUCCESS;
}

CrashResult CrashReporter::clearArchive() {
    if (!initialized_) return CrashResult::NOT_INITIALIZED;
    archive_.clear();
    return CrashResult::SUCCESS;
}

void CrashReporter::clearAll() {
    activeQueue_.clear();
    archive_.clear();
    groups_.clear();
    recentCrashTimes_.clear();
}

// ============================================================
// Query
// ============================================================

std::vector<CrashReport> CrashReporter::getActive() const {
    return activeQueue_;
}

std::vector<CrashReport> CrashReporter::getArchive() const {
    return archive_;
}

std::vector<CrashReport> CrashReporter::getRecent(size_t count) const {
    std::vector<CrashReport> all = activeQueue_;
    std::sort(all.begin(), all.end(),
              [](const CrashReport& a, const CrashReport& b) { return a.capturedAt > b.capturedAt; });
    if (all.size() > count) all.resize(count);
    return all;
}

std::vector<CrashReport> CrashReporter::getByApp(const std::string& appId) const {
    std::vector<CrashReport> result;
    for (const auto& r : activeQueue_) {
        if (r.appId == appId) result.push_back(r);
    }
    for (const auto& r : archive_) {
        if (r.appId == appId) result.push_back(r);
    }
    return result;
}

std::vector<CrashReport> CrashReporter::getByType(CrashType type) const {
    std::vector<CrashReport> result;
    for (const auto& r : activeQueue_) {
        if (r.type == type) result.push_back(r);
    }
    for (const auto& r : archive_) {
        if (r.type == type) result.push_back(r);
    }
    return result;
}

std::vector<CrashReport> CrashReporter::getBySeverity(CrashSeverity severity) const {
    std::vector<CrashReport> result;
    for (const auto& r : activeQueue_) {
        if (r.severity == severity) result.push_back(r);
    }
    for (const auto& r : archive_) {
        if (r.severity == severity) result.push_back(r);
    }
    return result;
}

std::vector<CrashReport> CrashReporter::getByState(CrashState state) const {
    std::vector<CrashReport> result;
    for (const auto& r : activeQueue_) {
        if (r.state == state) result.push_back(r);
    }
    for (const auto& r : archive_) {
        if (r.state == state) result.push_back(r);
    }
    return result;
}

std::vector<CrashReport> CrashReporter::getByGroup(const std::string& crashHash) const {
    std::vector<CrashReport> result;
    for (const auto& r : activeQueue_) {
        if (r.crashHash == crashHash) result.push_back(r);
    }
    for (const auto& r : archive_) {
        if (r.crashHash == crashHash) result.push_back(r);
    }
    return result;
}

std::vector<CrashReport> CrashReporter::getRetrying() const {
    return getByState(CrashState::RETRYING);
}

CrashReport CrashReporter::getById(uint64_t id) const {
    int idx = findActiveIndex(id);
    if (idx >= 0) return activeQueue_[idx];
    int aIdx = findArchiveIndex(id);
    if (aIdx >= 0) return archive_[aIdx];
    return CrashReport{};
}

size_t CrashReporter::getCountByApp(const std::string& appId) const {
    size_t count = 0;
    for (const auto& r : activeQueue_) {
        if (r.appId == appId) ++count;
    }
    for (const auto& r : archive_) {
        if (r.appId == appId) ++count;
    }
    return count;
}

size_t CrashReporter::getCountByType(CrashType type) const {
    size_t count = 0;
    for (const auto& r : activeQueue_) {
        if (r.type == type) ++count;
    }
    for (const auto& r : archive_) {
        if (r.type == type) ++count;
    }
    return count;
}

size_t CrashReporter::getCountBySeverity(CrashSeverity severity) const {
    size_t count = 0;
    for (const auto& r : activeQueue_) {
        if (r.severity == severity) ++count;
    }
    for (const auto& r : archive_) {
        if (r.severity == severity) ++count;
    }
    return count;
}

// ============================================================
// Privacy scrubbing
// ============================================================

std::string CrashReporter::scrubPath(const std::string& path) const {
    // Replace absolute paths with <path>
    std::string result = path;
    // Match /home/user, /data, /sdcard, /system, /var, /tmp paths
    std::regex pathRegex(R"((/(?:home|data|sdcard|system|var|tmp|Users)[^\s]*))");
    result = std::regex_replace(result, pathRegex, "<path>");
    return result;
}

std::string CrashReporter::scrubEmail(const std::string& text) const {
    std::string result = text;
    std::regex emailRegex(R"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})");
    result = std::regex_replace(result, emailRegex, "<email>");
    return result;
}

std::string CrashReporter::scrubIpAddress(const std::string& text) const {
    std::string result = text;
    std::regex ipRegex(R"(\b(?:\d{1,3}\.){3}\d{1,3}\b)");
    result = std::regex_replace(result, ipRegex, "<ip>");
    return result;
}

std::string CrashReporter::scrubMemoryAddress(const std::string& text) const {
    std::string result = text;
    // Match 0x followed by hex digits (at least 4)
    std::regex addrRegex(R"(0x[0-9a-fA-F]{4,})");
    result = std::regex_replace(result, addrRegex, "<addr>");
    return result;
}

std::string CrashReporter::scrubDeviceId(const std::string& text) const {
    std::string result = text;
    // Match UUID-like strings
    std::regex uuidRegex(R"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})");
    result = std::regex_replace(result, uuidRegex, "<uuid>");
    return result;
}

std::string CrashReporter::scrubUsername(const std::string& text) const {
    std::string result = text;
    // Replace /home/username/ patterns
    std::regex userRegex(R"(/home/([a-zA-Z0-9_-]+)/)");
    result = std::regex_replace(result, userRegex, "/home/<user>/");
    return result;
}

std::string CrashReporter::scrubAll(const std::string& text) const {
    std::string result = text;
    result = scrubEmail(result);
    result = scrubIpAddress(result);
    result = scrubMemoryAddress(result);
    result = scrubDeviceId(result);
    result = scrubUsername(result);
    result = scrubPath(result);
    return result;
}

std::string CrashReporter::scrubStackTrace(const std::vector<StackFrame>& trace) const {
    std::ostringstream ss;
    for (size_t i = 0; i < trace.size(); ++i) {
        ss << "#" << i << " " << trace[i].library << " " << trace[i].function;
        if (trace[i].address > 0) {
            ss << " <addr>";
        }
        if (!trace[i].filename.empty()) {
            ss << " " << scrubPath(trace[i].filename);
        }
        ss << "\n";
    }
    return ss.str();
}

CrashReport CrashReporter::applyPrivacyScrubbing(const CrashReport& report) const {
    CrashReport scrubbed = report;

    switch (privacyLevel_) {
        case CrashPrivacyLevel::FULL:
            // No scrubbing
            break;
        case CrashPrivacyLevel::ANONYMIZED:
            scrubbed.crashReason = scrubAll(scrubbed.crashReason);
            scrubbed.crashLog = scrubAll(scrubbed.crashLog);
            scrubbed.deviceState = scrubAll(scrubbed.deviceState);
            for (auto& frame : scrubbed.stackTrace) {
                frame.filename = scrubPath(frame.filename);
            }
            // Clear memory usage (could leak heap info)
            scrubbed.memoryUsage = 0;
            break;
        case CrashPrivacyLevel::MINIMAL:
            // Keep crash type, app, stack trace hash, pid, signal; strip PII-heavy fields
            scrubbed.crashReason.clear();
            scrubbed.crashLog.clear();
            scrubbed.deviceState.clear();
            scrubbed.memoryUsage = 0;
            scrubbed.processName.clear();
            scrubbed.extras.clear();
            for (auto& frame : scrubbed.stackTrace) {
                frame.filename.clear();
                frame.address = 0;
            }
            break;
        case CrashPrivacyLevel::DISABLED:
            // Should never reach here (captureCrash checks first)
            break;
    }

    return scrubbed;
}

// ============================================================
// Export
// ============================================================

std::string CrashReporter::exportReport(uint64_t id, const std::string& format) const {
    CrashReport report = getById(id);
    if (report.id == 0) return "Report not found";

    std::ostringstream ss;

    if (format == "csv") {
        ss << "id,appId,processName,pid,type,severity,state,signal,crashReason,timestamp,retryCount\n";
        ss << report.id << ","
           << report.appId << ","
           << report.processName << ","
           << report.pid << ","
           << crashTypeToString(report.type) << ","
           << crashSeverityToString(report.severity) << ","
           << crashStateToString(report.state) << ","
           << report.signal << ","
           << "\"" << report.crashReason << "\","
           << report.timestamp << ","
           << report.retryCount << "\n";
    } else {
        // Text format
        ss << "=== Crash Report #" << report.id << " ===\n";
        ss << "App: " << report.appId << "\n";
        if (!report.processName.empty())
            ss << "Process: " << report.processName << "\n";
        if (!report.appVersion.empty())
            ss << "Version: " << report.appVersion << "\n";
        ss << "PID: " << report.pid << "\n";
        ss << "Type: " << crashTypeToString(report.type) << "\n";
        ss << "Severity: " << crashSeverityToString(report.severity) << "\n";
        ss << "State: " << crashStateToString(report.state) << "\n";
        if (report.signal > 0)
            ss << "Signal: " << report.signal << " (code " << report.signalCode << ")\n";
        if (!report.crashReason.empty())
            ss << "Reason: " << report.crashReason << "\n";
        ss << "Timestamp: " << report.timestamp << "\n";
        ss << "Hash: " << report.crashHash << "\n";
        if (report.memoryUsage > 0)
            ss << "Memory: " << report.memoryUsage << " bytes\n";
        if (report.retryCount > 0)
            ss << "Retries: " << report.retryCount << "\n";
        if (!report.stackTrace.empty()) {
            ss << "\nStack Trace:\n";
            ss << scrubStackTrace(report.stackTrace);
        }
        if (!report.crashLog.empty())
            ss << "\nLog:\n" << report.crashLog << "\n";
    }

    return ss.str();
}

std::string CrashReporter::exportAll(const std::string& format) const {
    std::ostringstream ss;

    if (format == "csv") {
        ss << "id,appId,processName,pid,type,severity,state,signal,crashReason,timestamp,retryCount\n";
        for (const auto& report : activeQueue_) {
            ss << report.id << ","
               << report.appId << ","
               << report.processName << ","
               << report.pid << ","
               << crashTypeToString(report.type) << ","
               << crashSeverityToString(report.severity) << ","
               << crashStateToString(report.state) << ","
               << report.signal << ","
               << "\"" << report.crashReason << "\","
               << report.timestamp << ","
               << report.retryCount << "\n";
        }
    } else {
        for (const auto& report : activeQueue_) {
            ss << exportReport(report.id, "text") << "\n";
        }
    }

    return ss.str();
}

bool CrashReporter::saveReportToFile(uint64_t id, const std::string& path) const {
    std::string content = exportReport(id, "text");
    if (content == "Report not found") return false;

    FILE* file = fopen(path.c_str(), "w");
    if (!file) return false;
    fputs(content.c_str(), file);
    fclose(file);
    return true;
}

// ============================================================
// Stats
// ============================================================

CrashStats CrashReporter::getStats() const {
    CrashStats stats;
    stats.totalCaptured = totalCaptured_;
    stats.totalProcessed = totalProcessed_;
    stats.totalDeduplicated = totalDeduplicated_;
    stats.totalUploaded = totalUploaded_;
    stats.totalFailed = totalFailed_;
    stats.totalArchived = totalArchived_;
    stats.totalDismissed = totalDismissed_;
    stats.totalRetrying = totalRetrying_;
    stats.activeQueueSize = activeQueue_.size();
    stats.archiveSize = archive_.size();
    stats.totalGroups = groups_.size();

    memcpy(stats.totalByType, totalByType_, sizeof(totalByType_));
    memcpy(stats.totalBySeverity, totalBySeverity_, sizeof(totalBySeverity_));

    for (const auto& r : activeQueue_) {
        stats.perAppCounts[r.appId]++;
    }
    for (const auto& r : archive_) {
        stats.perAppCounts[r.appId]++;
    }

    return stats;
}

void CrashReporter::resetStats() {
    totalCaptured_ = 0;
    totalProcessed_ = 0;
    totalDeduplicated_ = 0;
    totalUploaded_ = 0;
    totalFailed_ = 0;
    totalArchived_ = 0;
    totalDismissed_ = 0;
    totalRetrying_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalBySeverity_, 0, sizeof(totalBySeverity_));
}

// ============================================================
// String helpers
// ============================================================

const char* CrashReporter::crashTypeToString(CrashType type) {
    switch (type) {
        case CrashType::SIGSEGV: return "SIGSEGV";
        case CrashType::SIGABRT: return "SIGABRT";
        case CrashType::SIGFPE: return "SIGFPE";
        case CrashType::SIGILL: return "SIGILL";
        case CrashType::SIGBUS: return "SIGBUS";
        case CrashType::SIGPIPE: return "SIGPIPE";
        case CrashType::SIGTERM: return "SIGTERM";
        case CrashType::SIGKILL: return "SIGKILL";
        case CrashType::OOM: return "OOM";
        case CrashType::ANR: return "ANR";
        case CrashType::NATIVE_CRASH: return "NATIVE_CRASH";
        case CrashType::JAVA_EXCEPTION: return "JAVA_EXCEPTION";
        case CrashType::UNKNOWN: return "UNKNOWN";
    }
    return "UNKNOWN";
}

const char* CrashReporter::crashSeverityToString(CrashSeverity severity) {
    switch (severity) {
        case CrashSeverity::FATAL: return "FATAL";
        case CrashSeverity::CRITICAL: return "CRITICAL";
        case CrashSeverity::MAJOR: return "MAJOR";
        case CrashSeverity::MINOR: return "MINOR";
    }
    return "UNKNOWN";
}

const char* CrashReporter::crashStateToString(CrashState state) {
    switch (state) {
        case CrashState::CAPTURED: return "CAPTURED";
        case CrashState::PROCESSING: return "PROCESSING";
        case CrashState::QUEUED: return "QUEUED";
        case CrashState::UPLOADED: return "UPLOADED";
        case CrashState::FAILED: return "FAILED";
        case CrashState::RETRYING: return "RETRYING";
        case CrashState::ARCHIVED: return "ARCHIVED";
        case CrashState::DISMISSED: return "DISMISSED";
    }
    return "UNKNOWN";
}

const char* CrashReporter::crashResultToString(CrashResult result) {
    switch (result) {
        case CrashResult::SUCCESS: return "SUCCESS";
        case CrashResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case CrashResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case CrashResult::INVALID_REPORT: return "INVALID_REPORT";
        case CrashResult::NOT_FOUND: return "NOT_FOUND";
        case CrashResult::DUPLICATE_CRASH: return "DUPLICATE_CRASH";
        case CrashResult::RATE_LIMITED: return "RATE_LIMITED";
        case CrashResult::QUEUE_FULL: return "QUEUE_FULL";
        case CrashResult::PRIVACY_DISABLED: return "PRIVACY_DISABLED";
        case CrashResult::MAX_RETRIES_EXCEEDED: return "MAX_RETRIES_EXCEEDED";
        case CrashResult::ALREADY_PROCESSED: return "ALREADY_PROCESSED";
        case CrashResult::ARCHIVE_FULL: return "ARCHIVE_FULL";
        case CrashResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
    }
    return "UNKNOWN";
}

const char* CrashReporter::privacyLevelToString(CrashPrivacyLevel level) {
    switch (level) {
        case CrashPrivacyLevel::FULL: return "FULL";
        case CrashPrivacyLevel::ANONYMIZED: return "ANONYMIZED";
        case CrashPrivacyLevel::MINIMAL: return "MINIMAL";
        case CrashPrivacyLevel::DISABLED: return "DISABLED";
    }
    return "UNKNOWN";
}

const char* CrashReporter::uploadPolicyToString(CrashUploadPolicy policy) {
    switch (policy) {
        case CrashUploadPolicy::NEVER: return "NEVER";
        case CrashUploadPolicy::WIFI_ONLY: return "WIFI_ONLY";
        case CrashUploadPolicy::ALWAYS: return "ALWAYS";
    }
    return "UNKNOWN";
}

CrashType CrashReporter::stringToCrashType(const std::string& str) {
    if (str == "SIGSEGV") return CrashType::SIGSEGV;
    if (str == "SIGABRT") return CrashType::SIGABRT;
    if (str == "SIGFPE") return CrashType::SIGFPE;
    if (str == "SIGILL") return CrashType::SIGILL;
    if (str == "SIGBUS") return CrashType::SIGBUS;
    if (str == "SIGPIPE") return CrashType::SIGPIPE;
    if (str == "SIGTERM") return CrashType::SIGTERM;
    if (str == "SIGKILL") return CrashType::SIGKILL;
    if (str == "OOM") return CrashType::OOM;
    if (str == "ANR") return CrashType::ANR;
    if (str == "NATIVE_CRASH") return CrashType::NATIVE_CRASH;
    if (str == "JAVA_EXCEPTION") return CrashType::JAVA_EXCEPTION;
    return CrashType::UNKNOWN;
}

CrashSeverity CrashReporter::stringToCrashSeverity(const std::string& str) {
    if (str == "FATAL") return CrashSeverity::FATAL;
    if (str == "CRITICAL") return CrashSeverity::CRITICAL;
    if (str == "MAJOR") return CrashSeverity::MAJOR;
    if (str == "MINOR") return CrashSeverity::MINOR;
    return CrashSeverity::MAJOR;
}

CrashState CrashReporter::stringToCrashState(const std::string& str) {
    if (str == "CAPTURED") return CrashState::CAPTURED;
    if (str == "PROCESSING") return CrashState::PROCESSING;
    if (str == "QUEUED") return CrashState::QUEUED;
    if (str == "UPLOADED") return CrashState::UPLOADED;
    if (str == "FAILED") return CrashState::FAILED;
    if (str == "RETRYING") return CrashState::RETRYING;
    if (str == "ARCHIVED") return CrashState::ARCHIVED;
    if (str == "DISMISSED") return CrashState::DISMISSED;
    return CrashState::CAPTURED;
}

CrashPrivacyLevel CrashReporter::stringToPrivacyLevel(const std::string& str) {
    if (str == "FULL") return CrashPrivacyLevel::FULL;
    if (str == "ANONYMIZED") return CrashPrivacyLevel::ANONYMIZED;
    if (str == "MINIMAL") return CrashPrivacyLevel::MINIMAL;
    if (str == "DISABLED") return CrashPrivacyLevel::DISABLED;
    return CrashPrivacyLevel::MINIMAL;
}

CrashType CrashReporter::signalToCrashType(int32_t signal) {
    switch (signal) {
        case 11: return CrashType::SIGSEGV;
        case 6: return CrashType::SIGABRT;
        case 8: return CrashType::SIGFPE;
        case 4: return CrashType::SIGILL;
        case 7: return CrashType::SIGBUS;
        case 13: return CrashType::SIGPIPE;
        case 15: return CrashType::SIGTERM;
        case 9: return CrashType::SIGKILL;
        default: return CrashType::UNKNOWN;
    }
}

}  // namespace phantom::crashreporter
