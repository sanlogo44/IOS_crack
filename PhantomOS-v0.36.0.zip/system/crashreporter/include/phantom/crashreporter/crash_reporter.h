/*
 * Phantom OS - Crash Reporter
 * Crash capture, deduplication, privacy scrubbing, retry, and reporting
 *
 * v0.19.0
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <functional>
#include <chrono>

// Forward declaration for optional LogServer integration
namespace phantom::logging {
class LogServer;
}

namespace phantom::crashreporter {

// ============================================================
// Enums
// ============================================================

enum class CrashType {
    SIGSEGV,        // Segmentation fault
    SIGABRT,        // Abort signal
    SIGFPE,         // Floating point exception
    SIGILL,         // Illegal instruction
    SIGBUS,         // Bus error
    SIGPIPE,        // Broken pipe
    SIGTERM,        // Termination signal
    SIGKILL,        // Kill signal
    OOM,            // Out of memory
    ANR,            // Application not responding
    NATIVE_CRASH,   // Native crash (unspecified)
    JAVA_EXCEPTION, // Java exception
    UNKNOWN         // Unknown crash type
};

enum class CrashSeverity {
    FATAL,      // Process terminated, unrecoverable
    CRITICAL,   // Severe crash, data loss possible
    MAJOR,      // Significant crash
    MINOR       // Minor crash, recoverable
};

enum class CrashState {
    CAPTURED,   // Just captured, not yet processed
    PROCESSING, // Being processed (dedup, scrub)
    QUEUED,     // Queued for upload
    UPLOADED,   // Successfully uploaded (simulated)
    FAILED,     // Upload failed permanently
    RETRYING,   // Upload failed, retrying
    ARCHIVED,   // Archived locally
    DISMISSED   // User dismissed
};

enum class CrashResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_REPORT,
    NOT_FOUND,
    DUPLICATE_CRASH,
    RATE_LIMITED,
    QUEUE_FULL,
    PRIVACY_DISABLED,
    MAX_RETRIES_EXCEEDED,
    ALREADY_PROCESSED,
    ARCHIVE_FULL,
    INVALID_PARAMETER
};

enum class CrashPrivacyLevel {
    FULL,        // Full crash data including memory
    ANONYMIZED,  // Anonymized: paths scrubbed, PII removed
    MINIMAL,     // Minimal: only crash type, app, stack trace hash
    DISABLED     // No crash data captured at all
};

enum class CrashUploadPolicy {
    NEVER,      // Never upload crash reports
    WIFI_ONLY,  // Upload on Wi-Fi only (simulated)
    ALWAYS      // Always upload (when enabled)
};

// ============================================================
// Structs
// ============================================================

struct StackFrame {
    std::string library;
    std::string function;
    uint64_t address = 0;
    std::string filename;
    uint32_t line = 0;
    uint32_t column = 0;
};

struct CrashReport {
    uint64_t id = 0;
    std::string appId;
    std::string processName;
    std::string appVersion;
    uint32_t pid = 0;
    uint32_t threadId = 0;
    CrashType type = CrashType::UNKNOWN;
    CrashSeverity severity = CrashSeverity::MAJOR;
    CrashState state = CrashState::CAPTURED;
    int32_t signal = 0;
    int32_t signalCode = 0;
    std::string crashReason;
    std::vector<StackFrame> stackTrace;
    std::string crashLog;           // Additional log output
    std::string crashHash;          // Fingerprint for dedup
    uint64_t timestamp = 0;         // When crash occurred (ms)
    uint64_t capturedAt = 0;        // When captured (ms)
    uint32_t retryCount = 0;
    uint64_t nextRetryAt = 0;       // Next retry time (ms)
    uint64_t memoryUsage = 0;      // Memory at crash (bytes)
    std::string deviceState;        // Device state info
    std::map<std::string, std::string> extras;
    bool userReported = false;      // User-initiated report
};

struct CrashGroup {
    uint64_t groupId = 0;
    std::string crashHash;
    std::string appId;
    CrashType type = CrashType::UNKNOWN;
    std::string topFrame;           // Top stack frame for display
    uint32_t count = 0;             // Number of crashes in group
    uint64_t firstSeen = 0;
    uint64_t lastSeen = 0;
    CrashSeverity highestSeverity = CrashSeverity::MINOR;
    std::vector<uint64_t> crashIds;
};

struct CrashStats {
    uint64_t totalCaptured = 0;
    uint64_t totalProcessed = 0;
    uint64_t totalDeduplicated = 0;
    uint64_t totalUploaded = 0;
    uint64_t totalFailed = 0;
    uint64_t totalArchived = 0;
    uint64_t totalDismissed = 0;
    uint64_t totalRetrying = 0;
    uint64_t activeQueueSize = 0;
    uint64_t archiveSize = 0;
    uint64_t totalGroups = 0;
    uint64_t totalByType[13] = {};  // One per CrashType
    uint64_t totalBySeverity[4] = {};  // One per CrashSeverity
    std::map<std::string, uint64_t> perAppCounts;
};

// ============================================================
// CrashReporter - Central crash reporting service
// ============================================================

class CrashReporter {
public:
    CrashReporter() = default;
    ~CrashReporter() { shutdown(); }

    // Lifecycle
    CrashResult initialize(size_t maxQueueSize = 500, size_t maxArchiveSize = 1000);
    CrashResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxQueueSize(size_t size) { maxQueueSize_ = size; }
    size_t getMaxQueueSize() const { return maxQueueSize_; }
    void setMaxArchiveSize(size_t size) { maxArchiveSize_ = size; }
    size_t getMaxArchiveSize() const { return maxArchiveSize_; }

    // LogServer integration (optional)
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }

    // Privacy
    void setPrivacyLevel(CrashPrivacyLevel level) { privacyLevel_ = level; }
    CrashPrivacyLevel getPrivacyLevel() const { return privacyLevel_; }
    void setUploadPolicy(CrashUploadPolicy policy) { uploadPolicy_ = policy; }
    CrashUploadPolicy getUploadPolicy() const { return uploadPolicy_; }
    void setAutoUpload(bool enabled) { autoUpload_ = enabled; }
    bool isAutoUpload() const { return autoUpload_; }

    // Rate limiting
    void setMaxCrashesPerHour(uint32_t max) { maxCrashesPerHour_ = max; }
    uint32_t getMaxCrashesPerHour() const { return maxCrashesPerHour_; }
    bool isRateLimited() const;

    // Retry policy
    void setMaxRetries(uint32_t max) { maxRetries_ = max; }
    uint32_t getMaxRetries() const { return maxRetries_; }
    void setRetryBaseDelayMs(uint64_t delay) { retryBaseDelayMs_ = delay; }
    uint64_t getRetryBaseDelayMs() const { return retryBaseDelayMs_; }

    // Crash capture
    uint64_t captureCrash(const CrashReport& report);
    uint64_t captureSignalCrash(const std::string& appId, const std::string& processName,
                                uint32_t pid, int32_t signal, int32_t signalCode,
                                const std::string& crashReason,
                                const std::vector<StackFrame>& stackTrace,
                                const std::string& appVersion = "",
                                uint64_t memoryUsage = 0);
    uint64_t captureAnr(const std::string& appId, const std::string& processName,
                        uint32_t pid, const std::string& reason,
                        const std::string& appVersion = "");
    uint64_t captureOom(const std::string& appId, const std::string& processName,
                        uint32_t pid, uint64_t memoryUsage,
                        const std::string& appVersion = "");

    // Crash processing
    void processPending();
    void processRetries(uint64_t currentTimeMs = 0);
    CrashResult processCrash(uint64_t id);

    // Deduplication
    std::string computeCrashHash(const CrashReport& report) const;
    CrashGroup getGroup(const std::string& crashHash) const;
    std::vector<CrashGroup> getGroups() const;
    size_t getGroupCount() const { return groups_.size(); }
    size_t getGroupCrashCount(const std::string& crashHash) const;

    // Upload (simulated)
    CrashResult queueForUpload(uint64_t id);
    CrashResult markUploaded(uint64_t id);
    CrashResult markUploadFailed(uint64_t id);
    CrashResult processUploadQueue();

    // Archive management
    CrashResult archive(uint64_t id);
    CrashResult dismiss(uint64_t id);
    CrashResult clearArchive();
    void clearAll();

    // Query
    std::vector<CrashReport> getActive() const;
    std::vector<CrashReport> getArchive() const;
    std::vector<CrashReport> getRecent(size_t count) const;
    std::vector<CrashReport> getByApp(const std::string& appId) const;
    std::vector<CrashReport> getByType(CrashType type) const;
    std::vector<CrashReport> getBySeverity(CrashSeverity severity) const;
    std::vector<CrashReport> getByState(CrashState state) const;
    std::vector<CrashReport> getByGroup(const std::string& crashHash) const;
    std::vector<CrashReport> getRetrying() const;
    CrashReport getById(uint64_t id) const;
    size_t getActiveCount() const { return activeQueue_.size(); }
    size_t getArchiveCount() const { return archive_.size(); }
    size_t getCountByApp(const std::string& appId) const;
    size_t getCountByType(CrashType type) const;
    size_t getCountBySeverity(CrashSeverity severity) const;

    // Privacy scrubbing
    std::string scrubPath(const std::string& path) const;
    std::string scrubEmail(const std::string& text) const;
    std::string scrubIpAddress(const std::string& text) const;
    std::string scrubMemoryAddress(const std::string& text) const;
    std::string scrubDeviceId(const std::string& text) const;
    std::string scrubUsername(const std::string& text) const;
    std::string scrubAll(const std::string& text) const;
    CrashReport applyPrivacyScrubbing(const CrashReport& report) const;
    std::string scrubStackTrace(const std::vector<StackFrame>& trace) const;

    // Export
    std::string exportReport(uint64_t id, const std::string& format = "text") const;
    std::string exportAll(const std::string& format = "text") const;

    // File operations
    bool saveReportToFile(uint64_t id, const std::string& path) const;

    // Callbacks
    using CrashCallback = std::function<void(const CrashReport&)>;
    void setCapturedCallback(CrashCallback cb) { capturedCb_ = cb; }
    void setProcessedCallback(CrashCallback cb) { processedCb_ = cb; }
    void setUploadedCallback(CrashCallback cb) { uploadedCb_ = cb; }
    void setFailedCallback(CrashCallback cb) { failedCb_ = cb; }
    void setArchivedCallback(CrashCallback cb) { archivedCb_ = cb; }

    // Stats
    CrashStats getStats() const;
    void resetStats();

    // String helpers
    static const char* crashTypeToString(CrashType type);
    static const char* crashSeverityToString(CrashSeverity severity);
    static const char* crashStateToString(CrashState state);
    static const char* crashResultToString(CrashResult result);
    static const char* privacyLevelToString(CrashPrivacyLevel level);
    static const char* uploadPolicyToString(CrashUploadPolicy policy);
    static CrashType stringToCrashType(const std::string& str);
    static CrashSeverity stringToCrashSeverity(const std::string& str);
    static CrashState stringToCrashState(const std::string& str);
    static CrashPrivacyLevel stringToPrivacyLevel(const std::string& str);
    static CrashType signalToCrashType(int32_t signal);

private:
    bool initialized_ = false;
    size_t maxQueueSize_ = 500;
    size_t maxArchiveSize_ = 1000;

    std::vector<CrashReport> activeQueue_;
    std::vector<CrashReport> archive_;
    uint64_t nextId_ = 1;
    uint64_t nextGroupId_ = 1;

    std::map<std::string, CrashGroup> groups_;  // key = crashHash

    CrashPrivacyLevel privacyLevel_ = CrashPrivacyLevel::MINIMAL;
    CrashUploadPolicy uploadPolicy_ = CrashUploadPolicy::NEVER;
    bool autoUpload_ = false;
    uint32_t maxCrashesPerHour_ = 50;
    uint32_t maxRetries_ = 3;
    uint64_t retryBaseDelayMs_ = 5000;  // 5 seconds base

    // Rate limiting tracking
    std::vector<uint64_t> recentCrashTimes_;  // Timestamps of recent crashes

    phantom::logging::LogServer* logServer_ = nullptr;

    // Callbacks
    CrashCallback capturedCb_;
    CrashCallback processedCb_;
    CrashCallback uploadedCb_;
    CrashCallback failedCb_;
    CrashCallback archivedCb_;

    // Stats counters
    uint64_t totalCaptured_ = 0;
    uint64_t totalProcessed_ = 0;
    uint64_t totalDeduplicated_ = 0;
    uint64_t totalUploaded_ = 0;
    uint64_t totalFailed_ = 0;
    uint64_t totalArchived_ = 0;
    uint64_t totalDismissed_ = 0;
    uint64_t totalRetrying_ = 0;
    uint64_t totalByType_[13] = {};
    uint64_t totalBySeverity_[4] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    int findActiveIndex(uint64_t id) const;
    int findArchiveIndex(uint64_t id) const;
    void removeFromActive(uint64_t id);
    void moveToArchive(uint64_t id, CrashState newState);
    void addToGroup(const CrashReport& report);
    void pruneRecentCrashTimes();
    uint64_t fnv1aHash(const std::string& data) const;
    void logToServer(const std::string& level, const std::string& message) const;
};

}  // namespace phantom::crashreporter
