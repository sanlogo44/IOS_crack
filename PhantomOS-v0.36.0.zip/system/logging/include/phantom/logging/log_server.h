/*
 * Phantom OS - Logging & Telemetry Server
 * Central system logging, log rotation, filtering, and telemetry collection
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <functional>
#include <chrono>
#include <atomic>

namespace phantom::logging {

// ============================================================
// Enums
// ============================================================

enum class LogLevel {
    TRACE,
    DEBUG,
    INFO,
    WARN,
    ERROR,
    FATAL,
    NONE
};

enum class LogSource {
    KERNEL,
    DRIVER,
    SERVICE,
    APP,
    SECURITY,
    NETWORK,
    HAL,
    SYSTEM_SERVER,
    NIDS,
    FRAMEWORK,
    UNKNOWN
};

enum class LogCategory {
    BOOT,
    SHUTDOWN,
    DRIVER_EVENT,
    SERVICE_EVENT,
    SECURITY_EVENT,
    NETWORK_EVENT,
    USER_ACTION,
    SYSTEM_ERROR,
    PERFORMANCE,
    CONFIG_CHANGE,
    APP_EVENT,
    GENERAL
};

enum class TelemetryType {
    CPU_USAGE,
    MEMORY_USAGE,
    DISK_USAGE,
    NETWORK_STATS,
    BATTERY_STATUS,
    PROCESS_COUNT,
    UPTIME,
    TEMPERATURE,
    CUSTOM
};

enum class TelemetryPrivacyLevel {
    FULL,           // Full telemetry (opt-in)
    ANONYMIZED,     // Anonymized data only
    MINIMAL,        // Minimal essential data
    DISABLED        // No telemetry
};

enum class LogResult {
    SUCCESS,
    ALREADY_INITIALIZED,
    NOT_INITIALIZED,
    BUFFER_FULL,
    FILTER_NOT_FOUND,
    INVALID_LEVEL,
    EXPORT_FAILED,
    PERMISSION_DENIED
};

// ============================================================
// Structs
// ============================================================

struct LogEntry {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    LogLevel level = LogLevel::INFO;
    LogSource source = LogSource::UNKNOWN;
    LogCategory category = LogCategory::GENERAL;
    std::string message;
    std::string tag;
    std::string component;
    uint32_t pid = 0;
    uint32_t threadId = 0;
    bool exported = false;
};

struct LogFilter {
    uint32_t id = 0;
    std::string name;
    LogLevel minLevel = LogLevel::TRACE;
    LogSource source = LogSource::UNKNOWN;  // UNKNOWN = any
    LogCategory category = LogCategory::GENERAL;  // GENERAL = any
    std::string tagFilter;                   // Empty = any
    std::string componentFilter;             // Empty = any
    bool enabled = true;
};

struct TelemetryMetric {
    uint32_t id = 0;
    TelemetryType type = TelemetryType::CUSTOM;
    std::string name;
    std::string unit;
    double value = 0.0;
    uint64_t timestamp = 0;
    TelemetryPrivacyLevel privacy = TelemetryPrivacyLevel::DISABLED;
};

struct TelemetrySnapshot {
    uint64_t timestamp = 0;
    double cpuUsage = 0.0;          // Percentage
    double memoryUsage = 0.0;       // Percentage
    double diskUsage = 0.0;         // Percentage
    uint64_t networkBytesSent = 0;
    uint64_t networkBytesRecv = 0;
    uint32_t processCount = 0;
    uint64_t uptime = 0;            // Seconds
    double temperature = 0.0;       // Celsius
    double batteryLevel = 0.0;      // Percentage
    bool charging = false;
};

struct LogStats {
    uint64_t totalEntries = 0;
    uint64_t bufferSize = 0;
    uint64_t maxBufferSize = 0;
    uint64_t entriesDropped = 0;
    uint64_t exportsCount = 0;
    uint32_t activeFilters = 0;
    uint32_t telemetryMetrics = 0;
    uint64_t telemetrySnapshots = 0;
    uint64_t entriesByLevel[6] = {};  // TRACE, DEBUG, INFO, WARN, ERROR, FATAL
};

// ============================================================
// LogServer - Central logging and telemetry service
// ============================================================

class LogServer {
public:
    LogServer() = default;
    ~LogServer() { shutdown(); }

    // Lifecycle
    LogResult initialize(uint64_t maxBufferSize = 10000);
    LogResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxBufferSize(uint64_t size) { maxBufferSize_ = size; }
    uint64_t getMaxBufferSize() const { return maxBufferSize_; }

    // Logging
    uint64_t log(LogLevel level, LogSource source, LogCategory category,
                 const std::string& message, const std::string& tag = "",
                 const std::string& component = "", uint32_t pid = 0);
    uint64_t logTrace(LogSource source, const std::string& msg, const std::string& tag = "");
    uint64_t logDebug(LogSource source, const std::string& msg, const std::string& tag = "");
    uint64_t logInfo(LogSource source, const std::string& msg, const std::string& tag = "");
    uint64_t logWarn(LogSource source, const std::string& msg, const std::string& tag = "");
    uint64_t logError(LogSource source, const std::string& msg, const std::string& tag = "");
    uint64_t logFatal(LogSource source, const std::string& msg, const std::string& tag = "");

    // Log access
    std::vector<LogEntry> getLogs() const;
    std::vector<LogEntry> getLogsByLevel(LogLevel level) const;
    std::vector<LogEntry> getLogsBySource(LogSource source) const;
    std::vector<LogEntry> getLogsByCategory(LogCategory category) const;
    std::vector<LogEntry> getLogsByTag(const std::string& tag) const;
    std::vector<LogEntry> getLogsByComponent(const std::string& component) const;
    std::vector<LogEntry> getFilteredLogs(const LogFilter& filter) const;
    std::vector<LogEntry> getRecentLogs(size_t count) const;
    std::vector<LogEntry> getLogsInRange(uint64_t startTimestamp, uint64_t endTimestamp) const;
    size_t getLogCount() const;
    size_t getLogCountByLevel(LogLevel level) const;
    LogEntry getLogById(uint64_t id) const;

    // Log management
    void clearLogs();
    void trimLogs(uint64_t maxAge);  // Remove entries older than maxAge (ms)
    void setMinLogLevel(LogLevel level) { minLogLevel_ = level; }
    LogLevel getMinLogLevel() const { return minLogLevel_; }

    // Filters
    uint32_t addFilter(const LogFilter& filter);
    bool removeFilter(uint32_t id);
    LogFilter getFilter(uint32_t id) const;
    std::vector<LogFilter> getFilters() const;
    bool enableFilter(uint32_t id);
    bool disableFilter(uint32_t id);
    size_t getActiveFilterCount() const;

    // Telemetry
    void setTelemetryPrivacy(TelemetryPrivacyLevel level) { telemetryPrivacy_ = level; }
    TelemetryPrivacyLevel getTelemetryPrivacy() const { return telemetryPrivacy_; }
    uint32_t registerTelemetryMetric(const TelemetryMetric& metric);
    bool updateTelemetryMetric(uint32_t id, double value);
    std::vector<TelemetryMetric> getTelemetryMetrics() const;
    TelemetryMetric getTelemetryMetric(uint32_t id) const;
    size_t getTelemetryMetricCount() const;

    // Telemetry snapshots
    void collectTelemetrySnapshot(const TelemetrySnapshot& snapshot);
    std::vector<TelemetrySnapshot> getTelemetrySnapshots() const;
    std::vector<TelemetrySnapshot> getRecentSnapshots(size_t count) const;
    size_t getSnapshotCount() const;
    void clearSnapshots();

    // Export
    std::string exportLogs(const std::string& format = "text") const;
    std::string exportFilteredLogs(const LogFilter& filter, const std::string& format = "text") const;
    std::string exportTelemetry(const std::string& format = "text") const;
    uint64_t getExportCount() const { return exportsCount_; }

    // Callbacks
    using LogCallback = std::function<void(const LogEntry&)>;
    void setLogCallback(LogCallback cb) { logCb_ = cb; }
    using TelemetryCallback = std::function<void(const TelemetrySnapshot&)>;
    void setTelemetryCallback(TelemetryCallback cb) { telemetryCb_ = cb; }

    // Stats
    LogStats getStats() const;
    void resetStats();

    // String helpers
    static const char* logLevelToString(LogLevel level);
    static const char* logSourceToString(LogSource source);
    static const char* logCategoryToString(LogCategory category);
    static const char* telemetryTypeToString(TelemetryType type);
    static const char* telemetryPrivacyToString(TelemetryPrivacyLevel level);
    static const char* logResultToString(LogResult result);
    static LogLevel stringToLogLevel(const std::string& str);

private:
    bool initialized_ = false;
    std::vector<LogEntry> logBuffer_;
    uint64_t maxBufferSize_ = 10000;
    uint64_t nextLogId_ = 1;
    LogLevel minLogLevel_ = LogLevel::TRACE;
    uint64_t entriesDropped_ = 0;
    mutable uint64_t exportsCount_ = 0;

    std::vector<LogFilter> filters_;
    uint32_t nextFilterId_ = 1;

    std::vector<TelemetryMetric> telemetryMetrics_;
    uint32_t nextTelemetryId_ = 1;

    std::vector<TelemetrySnapshot> telemetrySnapshots_;
    TelemetryPrivacyLevel telemetryPrivacy_ = TelemetryPrivacyLevel::DISABLED;

    LogCallback logCb_;
    TelemetryCallback telemetryCb_;

    // Stats counters
    uint64_t entriesByLevel_[6] = {};

    bool passesFilter(const LogEntry& entry, const LogFilter& filter) const;
    uint64_t getCurrentTimeMs() const;
    const char* levelTag(LogLevel level) const;
};

}  // namespace phantom::logging
