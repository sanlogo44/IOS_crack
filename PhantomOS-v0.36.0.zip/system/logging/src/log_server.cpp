/*
 * Phantom OS - Logging & Telemetry Server Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/logging/log_server.h"
#include <algorithm>
#include <sstream>
#include <cstring>

namespace phantom::logging {

// ============================================================
// String Helpers
// ============================================================

const char* LogServer::logLevelToString(LogLevel level) {
    switch (level) {
        case LogLevel::TRACE: return "TRACE";
        case LogLevel::DEBUG: return "DEBUG";
        case LogLevel::INFO: return "INFO";
        case LogLevel::WARN: return "WARN";
        case LogLevel::ERROR: return "ERROR";
        case LogLevel::FATAL: return "FATAL";
        case LogLevel::NONE: return "NONE";
        default: return "UNKNOWN";
    }
}

const char* LogServer::logSourceToString(LogSource source) {
    switch (source) {
        case LogSource::KERNEL: return "KERNEL";
        case LogSource::DRIVER: return "DRIVER";
        case LogSource::SERVICE: return "SERVICE";
        case LogSource::APP: return "APP";
        case LogSource::SECURITY: return "SECURITY";
        case LogSource::NETWORK: return "NETWORK";
        case LogSource::HAL: return "HAL";
        case LogSource::SYSTEM_SERVER: return "SYSTEM_SERVER";
        case LogSource::NIDS: return "NIDS";
        case LogSource::FRAMEWORK: return "FRAMEWORK";
        default: return "UNKNOWN";
    }
}

const char* LogServer::logCategoryToString(LogCategory category) {
    switch (category) {
        case LogCategory::BOOT: return "BOOT";
        case LogCategory::SHUTDOWN: return "SHUTDOWN";
        case LogCategory::DRIVER_EVENT: return "DRIVER_EVENT";
        case LogCategory::SERVICE_EVENT: return "SERVICE_EVENT";
        case LogCategory::SECURITY_EVENT: return "SECURITY_EVENT";
        case LogCategory::NETWORK_EVENT: return "NETWORK_EVENT";
        case LogCategory::USER_ACTION: return "USER_ACTION";
        case LogCategory::SYSTEM_ERROR: return "SYSTEM_ERROR";
        case LogCategory::PERFORMANCE: return "PERFORMANCE";
        case LogCategory::CONFIG_CHANGE: return "CONFIG_CHANGE";
        case LogCategory::APP_EVENT: return "APP_EVENT";
        default: return "GENERAL";
    }
}

const char* LogServer::telemetryTypeToString(TelemetryType type) {
    switch (type) {
        case TelemetryType::CPU_USAGE: return "CPU_USAGE";
        case TelemetryType::MEMORY_USAGE: return "MEMORY_USAGE";
        case TelemetryType::DISK_USAGE: return "DISK_USAGE";
        case TelemetryType::NETWORK_STATS: return "NETWORK_STATS";
        case TelemetryType::BATTERY_STATUS: return "BATTERY_STATUS";
        case TelemetryType::PROCESS_COUNT: return "PROCESS_COUNT";
        case TelemetryType::UPTIME: return "UPTIME";
        case TelemetryType::TEMPERATURE: return "TEMPERATURE";
        case TelemetryType::CUSTOM: return "CUSTOM";
        default: return "UNKNOWN";
    }
}

const char* LogServer::telemetryPrivacyToString(TelemetryPrivacyLevel level) {
    switch (level) {
        case TelemetryPrivacyLevel::FULL: return "FULL";
        case TelemetryPrivacyLevel::ANONYMIZED: return "ANONYMIZED";
        case TelemetryPrivacyLevel::MINIMAL: return "MINIMAL";
        case TelemetryPrivacyLevel::DISABLED: return "DISABLED";
        default: return "UNKNOWN";
    }
}

const char* LogServer::logResultToString(LogResult result) {
    switch (result) {
        case LogResult::SUCCESS: return "SUCCESS";
        case LogResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case LogResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case LogResult::BUFFER_FULL: return "BUFFER_FULL";
        case LogResult::FILTER_NOT_FOUND: return "FILTER_NOT_FOUND";
        case LogResult::INVALID_LEVEL: return "INVALID_LEVEL";
        case LogResult::EXPORT_FAILED: return "EXPORT_FAILED";
        case LogResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        default: return "UNKNOWN";
    }
}

LogLevel LogServer::stringToLogLevel(const std::string& str) {
    if (str == "TRACE") return LogLevel::TRACE;
    if (str == "DEBUG") return LogLevel::DEBUG;
    if (str == "INFO") return LogLevel::INFO;
    if (str == "WARN") return LogLevel::WARN;
    if (str == "ERROR") return LogLevel::ERROR;
    if (str == "FATAL") return LogLevel::FATAL;
    if (str == "NONE") return LogLevel::NONE;
    return LogLevel::INFO;
}

// ============================================================
// Lifecycle
// ============================================================

LogResult LogServer::initialize(uint64_t maxBufferSize) {
    if (initialized_) return LogResult::ALREADY_INITIALIZED;

    logBuffer_.clear();
    filters_.clear();
    telemetryMetrics_.clear();
    telemetrySnapshots_.clear();

    maxBufferSize_ = maxBufferSize;
    nextLogId_ = 1;
    nextFilterId_ = 1;
    nextTelemetryId_ = 1;
    entriesDropped_ = 0;
    exportsCount_ = 0;
    minLogLevel_ = LogLevel::TRACE;
    telemetryPrivacy_ = TelemetryPrivacyLevel::DISABLED;

    for (int i = 0; i < 6; i++) entriesByLevel_[i] = 0;

    initialized_ = true;

    return LogResult::SUCCESS;
}

LogResult LogServer::shutdown() {
    if (!initialized_) return LogResult::SUCCESS;

    logBuffer_.clear();
    filters_.clear();
    telemetryMetrics_.clear();
    telemetrySnapshots_.clear();
    logCb_ = nullptr;
    telemetryCb_ = nullptr;

    initialized_ = false;
    return LogResult::SUCCESS;
}

// ============================================================
// Logging
// ============================================================

uint64_t LogServer::log(LogLevel level, LogSource source, LogCategory category,
                         const std::string& message, const std::string& tag,
                         const std::string& component, uint32_t pid) {
    if (!initialized_) return 0;
    if (level == LogLevel::NONE) return 0;
    if (level < minLogLevel_) return 0;

    LogEntry entry;
    entry.id = nextLogId_++;
    entry.timestamp = getCurrentTimeMs();
    entry.level = level;
    entry.source = source;
    entry.category = category;
    entry.message = message;
    entry.tag = tag;
    entry.component = component;
    entry.pid = pid;

    // Update stats
    int levelIdx = static_cast<int>(level);
    if (levelIdx >= 0 && levelIdx < 6) {
        entriesByLevel_[levelIdx]++;
    }

    // Check buffer capacity (circular buffer behavior)
    if (logBuffer_.size() >= maxBufferSize_) {
        logBuffer_.erase(logBuffer_.begin());
        entriesDropped_++;
    }

    logBuffer_.push_back(entry);

    if (logCb_) logCb_(entry);

    return entry.id;
}

uint64_t LogServer::logTrace(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::TRACE, source, LogCategory::GENERAL, msg, tag);
}

uint64_t LogServer::logDebug(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::DEBUG, source, LogCategory::GENERAL, msg, tag);
}

uint64_t LogServer::logInfo(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::INFO, source, LogCategory::GENERAL, msg, tag);
}

uint64_t LogServer::logWarn(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::WARN, source, LogCategory::GENERAL, msg, tag);
}

uint64_t LogServer::logError(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::ERROR, source, LogCategory::SYSTEM_ERROR, msg, tag);
}

uint64_t LogServer::logFatal(LogSource source, const std::string& msg, const std::string& tag) {
    return log(LogLevel::FATAL, source, LogCategory::SYSTEM_ERROR, msg, tag);
}

// ============================================================
// Log Access
// ============================================================

std::vector<LogEntry> LogServer::getLogs() const {
    return logBuffer_;
}

std::vector<LogEntry> LogServer::getLogsByLevel(LogLevel level) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.level == level) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getLogsBySource(LogSource source) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.source == source) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getLogsByCategory(LogCategory category) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.category == category) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getLogsByTag(const std::string& tag) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.tag == tag) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getLogsByComponent(const std::string& component) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.component == component) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getFilteredLogs(const LogFilter& filter) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (passesFilter(e, filter)) result.push_back(e);
    }
    return result;
}

std::vector<LogEntry> LogServer::getRecentLogs(size_t count) const {
    std::vector<LogEntry> result;
    size_t start = logBuffer_.size() > count ? logBuffer_.size() - count : 0;
    for (size_t i = start; i < logBuffer_.size(); i++) {
        result.push_back(logBuffer_[i]);
    }
    return result;
}

std::vector<LogEntry> LogServer::getLogsInRange(uint64_t startTimestamp, uint64_t endTimestamp) const {
    std::vector<LogEntry> result;
    for (const auto& e : logBuffer_) {
        if (e.timestamp >= startTimestamp && e.timestamp <= endTimestamp) {
            result.push_back(e);
        }
    }
    return result;
}

size_t LogServer::getLogCount() const {
    return logBuffer_.size();
}

size_t LogServer::getLogCountByLevel(LogLevel level) const {
    size_t count = 0;
    for (const auto& e : logBuffer_) {
        if (e.level == level) count++;
    }
    return count;
}

LogEntry LogServer::getLogById(uint64_t id) const {
    for (const auto& e : logBuffer_) {
        if (e.id == id) return e;
    }
    return LogEntry{};
}

// ============================================================
// Log Management
// ============================================================

void LogServer::clearLogs() {
    logBuffer_.clear();
    for (int i = 0; i < 6; i++) entriesByLevel_[i] = 0;
}

void LogServer::trimLogs(uint64_t maxAge) {
    uint64_t now = getCurrentTimeMs();
    uint64_t cutoff = now > maxAge ? now - maxAge : 0;

    logBuffer_.erase(
        std::remove_if(logBuffer_.begin(), logBuffer_.end(),
                       [cutoff](const LogEntry& e) { return e.timestamp < cutoff; }),
        logBuffer_.end());
}

// ============================================================
// Filters
// ============================================================

uint32_t LogServer::addFilter(const LogFilter& filter) {
    LogFilter f = filter;
    f.id = nextFilterId_++;
    filters_.push_back(f);
    return f.id;
}

bool LogServer::removeFilter(uint32_t id) {
    auto it = std::find_if(filters_.begin(), filters_.end(),
                           [id](const LogFilter& f) { return f.id == id; });
    if (it == filters_.end()) return false;
    filters_.erase(it);
    return true;
}

LogFilter LogServer::getFilter(uint32_t id) const {
    for (const auto& f : filters_) {
        if (f.id == id) return f;
    }
    return LogFilter{};
}

std::vector<LogFilter> LogServer::getFilters() const {
    return filters_;
}

bool LogServer::enableFilter(uint32_t id) {
    for (auto& f : filters_) {
        if (f.id == id) {
            f.enabled = true;
            return true;
        }
    }
    return false;
}

bool LogServer::disableFilter(uint32_t id) {
    for (auto& f : filters_) {
        if (f.id == id) {
            f.enabled = false;
            return true;
        }
    }
    return false;
}

size_t LogServer::getActiveFilterCount() const {
    size_t count = 0;
    for (const auto& f : filters_) {
        if (f.enabled) count++;
    }
    return count;
}

// ============================================================
// Telemetry
// ============================================================

uint32_t LogServer::registerTelemetryMetric(const TelemetryMetric& metric) {
    TelemetryMetric m = metric;
    m.id = nextTelemetryId_++;
    telemetryMetrics_.push_back(m);
    return m.id;
}

bool LogServer::updateTelemetryMetric(uint32_t id, double value) {
    for (auto& m : telemetryMetrics_) {
        if (m.id == id) {
            m.value = value;
            m.timestamp = getCurrentTimeMs();
            return true;
        }
    }
    return false;
}

std::vector<TelemetryMetric> LogServer::getTelemetryMetrics() const {
    return telemetryMetrics_;
}

TelemetryMetric LogServer::getTelemetryMetric(uint32_t id) const {
    for (const auto& m : telemetryMetrics_) {
        if (m.id == id) return m;
    }
    return TelemetryMetric{};
}

size_t LogServer::getTelemetryMetricCount() const {
    return telemetryMetrics_.size();
}

// ============================================================
// Telemetry Snapshots
// ============================================================

void LogServer::collectTelemetrySnapshot(const TelemetrySnapshot& snapshot) {
    if (telemetryPrivacy_ == TelemetryPrivacyLevel::DISABLED) return;

    TelemetrySnapshot s = snapshot;
    s.timestamp = getCurrentTimeMs();

    // Anonymize if needed
    if (telemetryPrivacy_ == TelemetryPrivacyLevel::MINIMAL) {
        s.networkBytesSent = 0;
        s.networkBytesRecv = 0;
        s.processCount = 0;
    } else if (telemetryPrivacy_ == TelemetryPrivacyLevel::ANONYMIZED) {
        s.processCount = 0;
    }

    telemetrySnapshots_.push_back(s);

    // Limit snapshots to 1000
    if (telemetrySnapshots_.size() > 1000) {
        telemetrySnapshots_.erase(telemetrySnapshots_.begin());
    }

    if (telemetryCb_) telemetryCb_(s);
}

std::vector<TelemetrySnapshot> LogServer::getTelemetrySnapshots() const {
    return telemetrySnapshots_;
}

std::vector<TelemetrySnapshot> LogServer::getRecentSnapshots(size_t count) const {
    std::vector<TelemetrySnapshot> result;
    size_t start = telemetrySnapshots_.size() > count ? telemetrySnapshots_.size() - count : 0;
    for (size_t i = start; i < telemetrySnapshots_.size(); i++) {
        result.push_back(telemetrySnapshots_[i]);
    }
    return result;
}

size_t LogServer::getSnapshotCount() const {
    return telemetrySnapshots_.size();
}

void LogServer::clearSnapshots() {
    telemetrySnapshots_.clear();
}

// ============================================================
// Export
// ============================================================

std::string LogServer::exportLogs(const std::string& format) const {
    std::ostringstream oss;

    if (format == "text") {
        for (const auto& e : logBuffer_) {
            oss << "[" << logLevelToString(e.level) << "] "
                << "[" << logSourceToString(e.source) << "] "
                << "[" << logCategoryToString(e.category) << "] ";
            if (!e.tag.empty()) oss << "[" << e.tag << "] ";
            oss << e.message;
            if (!e.component.empty()) oss << " (" << e.component << ")";
            oss << "\n";
        }
    } else if (format == "csv") {
        oss << "id,timestamp,level,source,category,tag,component,message\n";
        for (const auto& e : logBuffer_) {
            oss << e.id << ","
                << e.timestamp << ","
                << logLevelToString(e.level) << ","
                << logSourceToString(e.source) << ","
                << logCategoryToString(e.category) << ","
                << e.tag << ","
                << e.component << ","
                << e.message << "\n";
        }
    }

    exportsCount_++;
    return oss.str();
}

std::string LogServer::exportFilteredLogs(const LogFilter& filter, const std::string& format) const {
    auto filtered = getFilteredLogs(filter);

    std::ostringstream oss;

    if (format == "text") {
        for (const auto& e : filtered) {
            oss << "[" << logLevelToString(e.level) << "] "
                << "[" << logSourceToString(e.source) << "] ";
            oss << e.message << "\n";
        }
    } else if (format == "csv") {
        oss << "id,timestamp,level,source,category,message\n";
        for (const auto& e : filtered) {
            oss << e.id << ","
                << e.timestamp << ","
                << logLevelToString(e.level) << ","
                << logSourceToString(e.source) << ","
                << logCategoryToString(e.category) << ","
                << e.message << "\n";
        }
    }

    exportsCount_++;
    return oss.str();
}

std::string LogServer::exportTelemetry(const std::string& format) const {
    std::ostringstream oss;

    if (format == "text") {
        oss << "Telemetry Metrics:\n";
        for (const auto& m : telemetryMetrics_) {
            oss << "  " << m.name << ": " << m.value << " " << m.unit
                << " [" << telemetryPrivacyToString(m.privacy) << "]\n";
        }
        oss << "\nTelemetry Snapshots: " << telemetrySnapshots_.size() << "\n";
        for (const auto& s : telemetrySnapshots_) {
            oss << "  [" << s.timestamp << "] CPU=" << s.cpuUsage
                << "% MEM=" << s.memoryUsage << "% DISK=" << s.diskUsage
                << "% Processes=" << s.processCount
                << " Uptime=" << s.uptime << "s\n";
        }
    }

    exportsCount_++;
    return oss.str();
}

// ============================================================
// Stats
// ============================================================

LogStats LogServer::getStats() const {
    LogStats stats;
    stats.totalEntries = nextLogId_ - 1;
    stats.bufferSize = logBuffer_.size();
    stats.maxBufferSize = maxBufferSize_;
    stats.entriesDropped = entriesDropped_;
    stats.exportsCount = exportsCount_;
    stats.activeFilters = getActiveFilterCount();
    stats.telemetryMetrics = telemetryMetrics_.size();
    stats.telemetrySnapshots = telemetrySnapshots_.size();

    for (int i = 0; i < 6; i++) {
        stats.entriesByLevel[i] = entriesByLevel_[i];
    }

    return stats;
}

void LogServer::resetStats() {
    entriesDropped_ = 0;
    exportsCount_ = 0;
    for (int i = 0; i < 6; i++) entriesByLevel_[i] = 0;
}

// ============================================================
// Private Helpers
// ============================================================

bool LogServer::passesFilter(const LogEntry& entry, const LogFilter& filter) const {
    if (!filter.enabled) return false;

    if (entry.level < filter.minLevel) return false;

    if (filter.source != LogSource::UNKNOWN && entry.source != filter.source) return false;

    if (filter.category != LogCategory::GENERAL && entry.category != filter.category) return false;

    if (!filter.tagFilter.empty() && entry.tag != filter.tagFilter) return false;

    if (!filter.componentFilter.empty() && entry.component != filter.componentFilter) return false;

    return true;
}

uint64_t LogServer::getCurrentTimeMs() const {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

const char* LogServer::levelTag(LogLevel level) const {
    switch (level) {
        case LogLevel::TRACE: return "T";
        case LogLevel::DEBUG: return "D";
        case LogLevel::INFO: return "I";
        case LogLevel::WARN: return "W";
        case LogLevel::ERROR: return "E";
        case LogLevel::FATAL: return "F";
        default: return "?";
    }
}

}  // namespace phantom::logging
