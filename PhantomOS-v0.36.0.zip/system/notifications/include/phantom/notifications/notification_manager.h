/*
 * Phantom OS - Notification Manager
 * System-wide notification management, channels, DND, grouping, and privacy
 *
 * v0.18.0
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <functional>
#include <chrono>

namespace phantom::notifications {

// ============================================================
// Enums
// ============================================================

enum class NotificationPriority {
    MIN,        // Lowest priority, non-intrusive
    LOW,        // Low priority
    DEFAULT,    // Default priority
    HIGH,       // High priority, heads-up
    MAX,        // Highest priority, urgent
    NONE        // For filtering / unset
};

enum class NotificationCategory {
    MESSAGE,
    CALL,
    EMAIL,
    SOCIAL,
    ALARM,
    REMINDER,
    ERROR,
    SYSTEM,
    SECURITY,
    UPDATE,
    TRANSPORT,
    MEDIA,
    OTHER
};

enum class ChannelImportance {
    NONE,       // Not shown to user
    MIN,        // Silent, no UI
    LOW,        // Low importance
    DEFAULT,    // Default importance
    HIGH,       // High importance, heads-up
    URGENT      // Urgent, full-screen
};

enum class NotificationState {
    PENDING,    // Posted but not yet delivered
    ACTIVE,     // Currently visible
    SNOOZED,    // Snoozed, will re-appear
    DISMISSED,  // User dismissed
    EXPIRED,    // Auto-expired
    CANCELLED,  // App cancelled
    BLOCKED     // Suppressed by DND or policy
};

enum class NotificationResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    NOT_FOUND,
    PERMISSION_DENIED,
    CHANNEL_NOT_FOUND,
    CHANNEL_ALREADY_EXISTS,
    INVALID_PARAMETER,
    QUEUE_FULL,
    APP_NOT_ALLOWED,
    DND_ACTIVE,
    STATE_ERROR,
    MAX_REACHED
};

enum class DndMode {
    OFF,            // DND disabled
    PRIORITY_ONLY,  // Only priority notifications
    TOTAL_SILENCE,  // No notifications at all
    ALARMS_ONLY     // Only alarm notifications
};

enum class PrivacyMode {
    SHOW_ALL,       // Show full content on lock screen
    HIDE_CONTENT,   // Hide content, show "Notification"
    REDACT,         // Redact sensitive fields
    HIDE_ALL        // Don't show on lock screen at all
};

enum class GroupAlertBehavior {
    CHILDREN,       // Alert for each child notification
    SUMMARY,        // Alert only for summary
    ALL             // Alert for both children and summary
};

// ============================================================
// Structs
// ============================================================

struct NotificationAction {
    std::string id;
    std::string label;
    bool destructive = false;
    bool remoteInput = false;  // Allows text input reply
};

struct Notification {
    uint64_t id = 0;
    std::string appId;
    std::string channel;
    std::string title;
    std::string body;
    std::string summary;          // For grouped notifications
    std::string groupKey;          // Group identifier
    std::string tag;              // App-defined tag for updates
    NotificationPriority priority = NotificationPriority::DEFAULT;
    NotificationCategory category = NotificationCategory::OTHER;
    NotificationState state = NotificationState::PENDING;
    ChannelImportance importance = ChannelImportance::DEFAULT;
    uint64_t timestamp = 0;        // Posted time (ms)
    uint64_t expiryTime = 0;      // Auto-expire time (0 = never)
    uint64_t snoozeUntil = 0;     // Snooze wake time (0 = not snoozed)
    bool ongoing = false;          // Non-dismissable (e.g., call, download)
    bool autoCancel = true;        // Auto-dismiss on tap
    bool showOnLockScreen = true;
    PrivacyMode privacyMode = PrivacyMode::SHOW_ALL;
    GroupAlertBehavior groupAlert = GroupAlertBehavior::CHILDREN;
    std::vector<NotificationAction> actions;
    std::map<std::string, std::string> extras;
    int32_t badgeCount = -1;       // App badge count (-1 = unchanged)
};

struct NotificationChannel {
    std::string id;
    std::string appId;
    std::string name;
    std::string description;
    ChannelImportance importance = ChannelImportance::DEFAULT;
    bool enabled = true;
    bool showBadge = true;
    bool lockScreenVisibility = true;
    bool vibration = true;
    bool lights = true;
    bool sound = true;
    std::string soundUri;
    int32_t lightColor = 0;        // ARGB
    DndMode dndOverride = DndMode::OFF;  // Can this channel bypass DND?
};

struct NotificationGroup {
    std::string key;
    std::string appId;
    std::string summaryTitle;
    NotificationPriority priority = NotificationPriority::DEFAULT;
    uint64_t summaryId = 0;        // ID of the summary notification
    std::vector<uint64_t> childIds;
    GroupAlertBehavior alertBehavior = GroupAlertBehavior::CHILDREN;
};

struct NotificationStats {
    uint64_t totalPosted = 0;
    uint64_t totalActive = 0;
    uint64_t totalDismissed = 0;
    uint64_t totalExpired = 0;
    uint64_t totalCancelled = 0;
    uint64_t totalBlocked = 0;
    uint64_t totalSnoozed = 0;
    uint64_t totalChannels = 0;
    uint64_t totalGroups = 0;
    uint64_t allowedApps = 0;
    uint64_t blockedApps = 0;
    std::map<std::string, uint64_t> perAppCounts;
};

// ============================================================
// NotificationManager - Central notification service
// ============================================================

class NotificationManager {
public:
    NotificationManager() = default;
    ~NotificationManager() { shutdown(); }

    // Lifecycle
    NotificationResult initialize(size_t maxQueueSize = 1000);
    NotificationResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxQueueSize(size_t size) { maxQueueSize_ = size; }
    size_t getMaxQueueSize() const { return maxQueueSize_; }

    // App permissions
    bool isAppAllowed(const std::string& appId) const;
    void setAppAllowed(const std::string& appId, bool allowed);
    size_t getAllowedAppCount() const { return allowedApps_.size(); }
    size_t getBlockedAppCount() const { return blockedApps_.size(); }

    // Channels
    NotificationResult createChannel(const NotificationChannel& channel);
    NotificationResult updateChannel(const std::string& appId, const std::string& channelId,
                                     const NotificationChannel& channel);
    NotificationResult deleteChannel(const std::string& appId, const std::string& channelId);
    NotificationChannel getChannel(const std::string& appId, const std::string& channelId) const;
    std::vector<NotificationChannel> getChannels(const std::string& appId) const;
    std::vector<NotificationChannel> getAllChannels() const;
    NotificationResult enableChannel(const std::string& appId, const std::string& channelId, bool enabled);
    size_t getChannelCount() const;
    size_t getChannelCountForApp(const std::string& appId) const;
    bool channelExists(const std::string& appId, const std::string& channelId) const;

    // Post / Update / Cancel
    uint64_t post(const Notification& notification);
    bool update(uint64_t id, const Notification& notification);
    bool cancel(uint64_t id);
    bool cancelAll(const std::string& appId);
    bool cancelTagged(const std::string& appId, const std::string& tag);
    bool dismiss(uint64_t id);
    bool snooze(uint64_t id, uint64_t durationMs);
    bool unsnooze(uint64_t id);

    // Expiry
    void processExpiry(uint64_t currentTimeMs = 0);
    size_t expireNotifications(uint64_t maxAge);

    // Query
    std::vector<Notification> getActive() const;
    std::vector<Notification> getHistory(size_t limit = 100) const;
    std::vector<Notification> getRecent(size_t count) const;
    std::vector<Notification> getByApp(const std::string& appId) const;
    std::vector<Notification> getByCategory(NotificationCategory category) const;
    std::vector<Notification> getByPriority(NotificationPriority priority) const;
    std::vector<Notification> getByChannel(const std::string& appId, const std::string& channelId) const;
    std::vector<Notification> getByState(NotificationState state) const;
    std::vector<Notification> getSnoozed() const;
    Notification getById(uint64_t id) const;
    size_t getActiveCount() const;
    size_t getHistoryCount() const;
    size_t getCountByApp(const std::string& appId) const;
    size_t getCountByCategory(NotificationCategory category) const;
    size_t getCountByPriority(NotificationPriority priority) const;

    // Groups
    NotificationResult createGroup(const NotificationGroup& group);
    NotificationGroup getGroup(const std::string& key) const;
    std::vector<NotificationGroup> getGroups() const;
    NotificationResult addToGroup(uint64_t notificationId, const std::string& groupKey);
    NotificationResult removeFromGroup(uint64_t notificationId, const std::string& groupKey);
    size_t getGroupCount() const;
    size_t getGroupChildCount(const std::string& groupKey) const;

    // Do Not Disturb
    void setDndMode(DndMode mode) { dndMode_ = mode; }
    DndMode getDndMode() const { return dndMode_; }
    bool isDndActive() const { return dndMode_ != DndMode::OFF; }
    void setDndStart(uint32_t hour, uint32_t minute);
    void setDndEnd(uint32_t hour, uint32_t minute);
    uint32_t getDndStartHour() const { return dndStartHour_; }
    uint32_t getDndStartMinute() const { return dndStartMinute_; }
    uint32_t getDndEndHour() const { return dndEndHour_; }
    uint32_t getDndEndMinute() const { return dndEndMinute_; }
    void setDndScheduled(bool enabled) { dndScheduled_ = enabled; }
    bool isDndScheduled() const { return dndScheduled_; }
    bool shouldSuppress(const Notification& notif, const NotificationChannel& channel) const;

    // Privacy
    void setPrivacyMode(PrivacyMode mode) { privacyMode_ = mode; }
    PrivacyMode getPrivacyMode() const { return privacyMode_; }
    Notification redactNotification(const Notification& notif) const;
    std::string redactText(const std::string& text) const;

    // Badge management
    int32_t getBadgeCount(const std::string& appId) const;
    void setBadgeCount(const std::string& appId, int32_t count);
    void clearBadge(const std::string& appId);
    std::map<std::string, int32_t> getAllBadges() const;

    // Callbacks
    using NotificationCallback = std::function<void(const Notification&)>;
    void setPostedCallback(NotificationCallback cb) { postedCb_ = cb; }
    void setUpdatedCallback(NotificationCallback cb) { updatedCb_ = cb; }
    void setDismissedCallback(NotificationCallback cb) { dismissedCb_ = cb; }
    void setCancelledCallback(NotificationCallback cb) { cancelledCb_ = cb; }
    void setExpiredCallback(NotificationCallback cb) { expiredCb_ = cb; }
    void setBlockedCallback(NotificationCallback cb) { blockedCb_ = cb; }

    // Stats
    NotificationStats getStats() const;
    void resetStats();

    // Management
    void clearHistory();
    void clearAll();
    void clearForApp(const std::string& appId);

    // String helpers
    static const char* priorityToString(NotificationPriority priority);
    static const char* categoryToString(NotificationCategory category);
    static const char* importanceToString(ChannelImportance importance);
    static const char* stateToString(NotificationState state);
    static const char* resultToString(NotificationResult result);
    static const char* dndModeToString(DndMode mode);
    static const char* privacyModeToString(PrivacyMode mode);
    static const char* groupAlertToString(GroupAlertBehavior behavior);
    static NotificationPriority stringToPriority(const std::string& str);
    static NotificationState stringToState(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxQueueSize_ = 1000;

    std::vector<Notification> activeQueue_;
    std::vector<Notification> history_;
    uint64_t nextId_ = 1;

    std::set<std::string> allowedApps_;
    std::set<std::string> blockedApps_;

    std::map<std::string, NotificationChannel> channels_;  // key = appId:channelId
    std::map<std::string, NotificationGroup> groups_;      // key = groupKey
    std::map<std::string, int32_t> badges_;                // key = appId

    DndMode dndMode_ = DndMode::OFF;
    bool dndScheduled_ = false;
    uint32_t dndStartHour_ = 22;
    uint32_t dndStartMinute_ = 0;
    uint32_t dndEndHour_ = 7;
    uint32_t dndEndMinute_ = 0;

    PrivacyMode privacyMode_ = PrivacyMode::SHOW_ALL;

    NotificationCallback postedCb_;
    NotificationCallback updatedCb_;
    NotificationCallback dismissedCb_;
    NotificationCallback cancelledCb_;
    NotificationCallback expiredCb_;
    NotificationCallback blockedCb_;

    // Stats counters
    uint64_t totalPosted_ = 0;
    uint64_t totalDismissed_ = 0;
    uint64_t totalExpired_ = 0;
    uint64_t totalCancelled_ = 0;
    uint64_t totalBlocked_ = 0;
    uint64_t totalSnoozed_ = 0;

    // Helpers
    std::string channelKey(const std::string& appId, const std::string& channelId) const;
    uint64_t getCurrentTimeMs() const;
    bool canPost(const Notification& notif, const NotificationChannel& channel) const;
    void moveToHistory(uint64_t id, NotificationState newState);
    void removeFromActive(uint64_t id);
    int findActiveIndex(uint64_t id) const;
    int findHistoryIndex(uint64_t id) const;
    void updateBadgeForApp(const std::string& appId, int32_t delta);
};

}  // namespace phantom::notifications
