/*
 * Phantom OS - Notification Manager Implementation
 * v0.18.0
 * License: GPL-3.0
 */

#include "phantom/notifications/notification_manager.h"
#include <algorithm>
#include <chrono>
#include <cstring>

namespace phantom::notifications {

// ============================================================
// Private helpers
// ============================================================

std::string NotificationManager::channelKey(const std::string& appId, const std::string& channelId) const {
    return appId + ":" + channelId;
}

uint64_t NotificationManager::getCurrentTimeMs() const {
    auto now = std::chrono::steady_clock::now();
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count());
}

int NotificationManager::findActiveIndex(uint64_t id) const {
    for (size_t i = 0; i < activeQueue_.size(); ++i) {
        if (activeQueue_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

int NotificationManager::findHistoryIndex(uint64_t id) const {
    for (size_t i = 0; i < history_.size(); ++i) {
        if (history_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

void NotificationManager::removeFromActive(uint64_t id) {
    activeQueue_.erase(
        std::remove_if(activeQueue_.begin(), activeQueue_.end(),
                       [id](const Notification& n) { return n.id == id; }),
        activeQueue_.end());
}

void NotificationManager::moveToHistory(uint64_t id, NotificationState newState) {
    int idx = findActiveIndex(id);
    if (idx >= 0) {
        Notification notif = activeQueue_[idx];
        notif.state = newState;
        history_.push_back(notif);
        removeFromActive(id);
    }
}

void NotificationManager::updateBadgeForApp(const std::string& appId, int32_t delta) {
    if (delta == 0) return;
    int32_t current = badges_[appId];
    current += delta;
    if (current < 0) current = 0;
    badges_[appId] = current;
}

bool NotificationManager::canPost(const Notification& notif, const NotificationChannel& channel) const {
    // Check DND
    if (shouldSuppress(notif, channel)) return false;
    return true;
}

// ============================================================
// Lifecycle
// ============================================================

NotificationResult NotificationManager::initialize(size_t maxQueueSize) {
    if (initialized_) return NotificationResult::ALREADY_INITIALIZED;
    initialized_ = true;
    maxQueueSize_ = maxQueueSize;
    return NotificationResult::SUCCESS;
}

NotificationResult NotificationManager::shutdown() {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    activeQueue_.clear();
    history_.clear();
    channels_.clear();
    groups_.clear();
    badges_.clear();
    allowedApps_.clear();
    blockedApps_.clear();
    totalPosted_ = 0;
    totalDismissed_ = 0;
    totalExpired_ = 0;
    totalCancelled_ = 0;
    totalBlocked_ = 0;
    totalSnoozed_ = 0;
    initialized_ = false;
    return NotificationResult::SUCCESS;
}

// ============================================================
// App permissions
// ============================================================

bool NotificationManager::isAppAllowed(const std::string& appId) const {
    if (blockedApps_.count(appId)) return false;
    return true;  // Default allow unless explicitly blocked
}

void NotificationManager::setAppAllowed(const std::string& appId, bool allowed) {
    if (allowed) {
        allowedApps_.insert(appId);
        blockedApps_.erase(appId);
    } else {
        blockedApps_.insert(appId);
        allowedApps_.erase(appId);
    }
}

// ============================================================
// Channels
// ============================================================

NotificationResult NotificationManager::createChannel(const NotificationChannel& channel) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    if (channel.id.empty() || channel.appId.empty()) return NotificationResult::INVALID_PARAMETER;

    std::string key = channelKey(channel.appId, channel.id);
    if (channels_.count(key)) return NotificationResult::CHANNEL_ALREADY_EXISTS;

    channels_[key] = channel;
    return NotificationResult::SUCCESS;
}

NotificationResult NotificationManager::updateChannel(const std::string& appId, const std::string& channelId,
                                                      const NotificationChannel& channel) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    std::string key = channelKey(appId, channelId);
    auto it = channels_.find(key);
    if (it == channels_.end()) return NotificationResult::CHANNEL_NOT_FOUND;

    NotificationChannel updated = channel;
    updated.id = channelId;
    updated.appId = appId;
    it->second = updated;
    return NotificationResult::SUCCESS;
}

NotificationResult NotificationManager::deleteChannel(const std::string& appId, const std::string& channelId) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    std::string key = channelKey(appId, channelId);
    auto it = channels_.find(key);
    if (it == channels_.end()) return NotificationResult::CHANNEL_NOT_FOUND;

    channels_.erase(it);
    return NotificationResult::SUCCESS;
}

NotificationChannel NotificationManager::getChannel(const std::string& appId, const std::string& channelId) const {
    std::string key = channelKey(appId, channelId);
    auto it = channels_.find(key);
    if (it != channels_.end()) return it->second;
    return NotificationChannel{};
}

std::vector<NotificationChannel> NotificationManager::getChannels(const std::string& appId) const {
    std::vector<NotificationChannel> result;
    for (const auto& [key, channel] : channels_) {
        if (channel.appId == appId) result.push_back(channel);
    }
    return result;
}

std::vector<NotificationChannel> NotificationManager::getAllChannels() const {
    std::vector<NotificationChannel> result;
    for (const auto& [key, channel] : channels_) {
        result.push_back(channel);
    }
    return result;
}

NotificationResult NotificationManager::enableChannel(const std::string& appId, const std::string& channelId, bool enabled) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    std::string key = channelKey(appId, channelId);
    auto it = channels_.find(key);
    if (it == channels_.end()) return NotificationResult::CHANNEL_NOT_FOUND;
    it->second.enabled = enabled;
    return NotificationResult::SUCCESS;
}

size_t NotificationManager::getChannelCount() const {
    return channels_.size();
}

size_t NotificationManager::getChannelCountForApp(const std::string& appId) const {
    size_t count = 0;
    for (const auto& [key, channel] : channels_) {
        if (channel.appId == appId) ++count;
    }
    return count;
}

bool NotificationManager::channelExists(const std::string& appId, const std::string& channelId) const {
    return channels_.count(channelKey(appId, channelId)) > 0;
}

// ============================================================
// Post / Update / Cancel
// ============================================================

uint64_t NotificationManager::post(const Notification& notification) {
    if (!initialized_) return 0;

    // Check app permission
    if (!isAppAllowed(notification.appId)) {
        totalBlocked_++;
        Notification blocked = notification;
        blocked.id = nextId_++;
        blocked.state = NotificationState::BLOCKED;
        if (blockedCb_) blockedCb_(blocked);
        return 0;
    }

    // Check channel exists and is enabled
    NotificationChannel channel;
    bool hasChannel = false;
    if (!notification.channel.empty()) {
        std::string key = channelKey(notification.appId, notification.channel);
        auto it = channels_.find(key);
        if (it != channels_.end()) {
            channel = it->second;
            hasChannel = true;
            if (!channel.enabled) {
                totalBlocked_++;
                Notification blocked = notification;
                blocked.id = nextId_++;
                blocked.state = NotificationState::BLOCKED;
                if (blockedCb_) blockedCb_(blocked);
                return 0;
            }
        }
    }

    // Check DND (works even without a channel)
    NotificationChannel defaultChannel;
    const NotificationChannel& dndChannel = hasChannel ? channel : defaultChannel;
    if (shouldSuppress(notification, dndChannel)) {
        totalBlocked_++;
        Notification blocked = notification;
        blocked.id = nextId_++;
        blocked.state = NotificationState::BLOCKED;
        if (blockedCb_) blockedCb_(blocked);
        return 0;
    }

    // Check queue capacity
    if (activeQueue_.size() >= maxQueueSize_) {
        // Remove oldest non-ongoing
        for (auto it = activeQueue_.begin(); it != activeQueue_.end(); ++it) {
            if (!it->ongoing) {
                moveToHistory(it->id, NotificationState::EXPIRED);
                totalExpired_++;
                break;
            }
        }
        // If still full, drop oldest
        if (activeQueue_.size() >= maxQueueSize_) {
            moveToHistory(activeQueue_.front().id, NotificationState::EXPIRED);
            totalExpired_++;
        }
    }

    Notification notif = notification;
    notif.id = nextId_++;
    notif.timestamp = getCurrentTimeMs();
    notif.state = NotificationState::ACTIVE;

    // Apply channel defaults if channel exists
    if (hasChannel) {
        notif.importance = channel.importance;
        if (!channel.lockScreenVisibility) notif.showOnLockScreen = false;
    }

    activeQueue_.push_back(notif);
    totalPosted_++;

    // Update badge
    if (notif.badgeCount >= 0) {
        badges_[notif.appId] = notif.badgeCount;
    } else {
        updateBadgeForApp(notif.appId, 1);
    }

    // Add to group if specified
    if (!notif.groupKey.empty()) {
        auto it = groups_.find(notif.groupKey);
        if (it != groups_.end()) {
            it->second.childIds.push_back(notif.id);
        }
    }

    if (postedCb_) postedCb_(notif);

    return notif.id;
}

bool NotificationManager::update(uint64_t id, const Notification& notification) {
    if (!initialized_) return false;
    int idx = findActiveIndex(id);
    if (idx < 0) return false;

    Notification updated = notification;
    updated.id = id;
    updated.timestamp = activeQueue_[idx].timestamp;
    updated.state = NotificationState::ACTIVE;
    activeQueue_[idx] = updated;

    if (updatedCb_) updatedCb_(updated);
    return true;
}

bool NotificationManager::cancel(uint64_t id) {
    if (!initialized_) return false;
    int idx = findActiveIndex(id);
    if (idx < 0) return false;

    Notification notif = activeQueue_[idx];
    notif.state = NotificationState::CANCELLED;
    history_.push_back(notif);
    removeFromActive(id);
    totalCancelled_++;

    updateBadgeForApp(notif.appId, -1);

    if (cancelledCb_) cancelledCb_(notif);
    return true;
}

bool NotificationManager::cancelAll(const std::string& appId) {
    if (!initialized_) return false;
    bool any = false;
    std::vector<uint64_t> toCancel;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId) {
            toCancel.push_back(notif.id);
            any = true;
        }
    }
    for (uint64_t id : toCancel) {
        cancel(id);
    }
    return any;
}

bool NotificationManager::cancelTagged(const std::string& appId, const std::string& tag) {
    if (!initialized_) return false;
    bool any = false;
    std::vector<uint64_t> toCancel;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId && notif.tag == tag) {
            toCancel.push_back(notif.id);
            any = true;
        }
    }
    for (uint64_t id : toCancel) {
        cancel(id);
    }
    return any;
}

bool NotificationManager::dismiss(uint64_t id) {
    if (!initialized_) return false;
    int idx = findActiveIndex(id);
    if (idx < 0) return false;

    Notification notif = activeQueue_[idx];
    notif.state = NotificationState::DISMISSED;
    history_.push_back(notif);
    removeFromActive(id);
    totalDismissed_++;

    updateBadgeForApp(notif.appId, -1);

    if (dismissedCb_) dismissedCb_(notif);
    return true;
}

bool NotificationManager::snooze(uint64_t id, uint64_t durationMs) {
    if (!initialized_) return false;
    int idx = findActiveIndex(id);
    if (idx < 0) return false;

    activeQueue_[idx].state = NotificationState::SNOOZED;
    activeQueue_[idx].snoozeUntil = getCurrentTimeMs() + durationMs;
    totalSnoozed_++;
    return true;
}

bool NotificationManager::unsnooze(uint64_t id) {
    if (!initialized_) return false;
    int idx = findActiveIndex(id);
    if (idx < 0) return false;
    if (activeQueue_[idx].state != NotificationState::SNOOZED) return false;

    activeQueue_[idx].state = NotificationState::ACTIVE;
    activeQueue_[idx].snoozeUntil = 0;
    return true;
}

// ============================================================
// Expiry
// ============================================================

void NotificationManager::processExpiry(uint64_t currentTimeMs) {
    if (currentTimeMs == 0) currentTimeMs = getCurrentTimeMs();

    std::vector<uint64_t> toExpire;
    for (const auto& notif : activeQueue_) {
        if (notif.expiryTime > 0 && notif.expiryTime <= currentTimeMs &&
            notif.state == NotificationState::ACTIVE && !notif.ongoing) {
            toExpire.push_back(notif.id);
        }
        // Check snooze wake - auto-reactivate snoozed notifications
        if (notif.state == NotificationState::SNOOZED && notif.snoozeUntil > 0 &&
            notif.snoozeUntil <= currentTimeMs) {
            // Will be reactivated below
        }
    }

    // Reactivate snoozed notifications whose wake time has passed
    for (auto& notif : activeQueue_) {
        if (notif.state == NotificationState::SNOOZED && notif.snoozeUntil > 0 &&
            notif.snoozeUntil <= currentTimeMs) {
            notif.state = NotificationState::ACTIVE;
            notif.snoozeUntil = 0;
        }
    }

    for (uint64_t id : toExpire) {
        moveToHistory(id, NotificationState::EXPIRED);
        totalExpired_++;
    }
}

size_t NotificationManager::expireNotifications(uint64_t maxAge) {
    uint64_t cutoff = getCurrentTimeMs() - maxAge;
    std::vector<uint64_t> toExpire;

    for (const auto& notif : activeQueue_) {
        if (notif.timestamp <= cutoff && !notif.ongoing) {
            toExpire.push_back(notif.id);
        }
    }

    for (uint64_t id : toExpire) {
        moveToHistory(id, NotificationState::EXPIRED);
        totalExpired_++;
    }

    return toExpire.size();
}

// ============================================================
// Query
// ============================================================

std::vector<Notification> NotificationManager::getActive() const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.state == NotificationState::ACTIVE) {
            result.push_back(notif);
        }
    }
    return result;
}

std::vector<Notification> NotificationManager::getHistory(size_t limit) const {
    if (history_.size() <= limit) return history_;
    return std::vector<Notification>(history_.end() - limit, history_.end());
}

std::vector<Notification> NotificationManager::getRecent(size_t count) const {
    std::vector<Notification> all = activeQueue_;
    // Sort by timestamp descending
    std::sort(all.begin(), all.end(),
              [](const Notification& a, const Notification& b) { return a.timestamp > b.timestamp; });
    if (all.size() > count) all.resize(count);
    return all;
}

std::vector<Notification> NotificationManager::getByApp(const std::string& appId) const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId) result.push_back(notif);
    }
    return result;
}

std::vector<Notification> NotificationManager::getByCategory(NotificationCategory category) const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.category == category) result.push_back(notif);
    }
    return result;
}

std::vector<Notification> NotificationManager::getByPriority(NotificationPriority priority) const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.priority == priority) result.push_back(notif);
    }
    return result;
}

std::vector<Notification> NotificationManager::getByChannel(const std::string& appId, const std::string& channelId) const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId && notif.channel == channelId) result.push_back(notif);
    }
    return result;
}

std::vector<Notification> NotificationManager::getByState(NotificationState state) const {
    std::vector<Notification> result;
    for (const auto& notif : activeQueue_) {
        if (notif.state == state) result.push_back(notif);
    }
    return result;
}

std::vector<Notification> NotificationManager::getSnoozed() const {
    return getByState(NotificationState::SNOOZED);
}

Notification NotificationManager::getById(uint64_t id) const {
    int idx = findActiveIndex(id);
    if (idx >= 0) return activeQueue_[idx];

    int hIdx = findHistoryIndex(id);
    if (hIdx >= 0) return history_[hIdx];

    return Notification{};
}

size_t NotificationManager::getActiveCount() const {
    return activeQueue_.size();
}

size_t NotificationManager::getHistoryCount() const {
    return history_.size();
}

size_t NotificationManager::getCountByApp(const std::string& appId) const {
    size_t count = 0;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId) ++count;
    }
    return count;
}

size_t NotificationManager::getCountByCategory(NotificationCategory category) const {
    size_t count = 0;
    for (const auto& notif : activeQueue_) {
        if (notif.category == category) ++count;
    }
    return count;
}

size_t NotificationManager::getCountByPriority(NotificationPriority priority) const {
    size_t count = 0;
    for (const auto& notif : activeQueue_) {
        if (notif.priority == priority) ++count;
    }
    return count;
}

// ============================================================
// Groups
// ============================================================

NotificationResult NotificationManager::createGroup(const NotificationGroup& group) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    if (group.key.empty()) return NotificationResult::INVALID_PARAMETER;
    if (groups_.count(group.key)) return NotificationResult::CHANNEL_ALREADY_EXISTS;

    groups_[group.key] = group;
    return NotificationResult::SUCCESS;
}

NotificationGroup NotificationManager::getGroup(const std::string& key) const {
    auto it = groups_.find(key);
    if (it != groups_.end()) return it->second;
    return NotificationGroup{};
}

std::vector<NotificationGroup> NotificationManager::getGroups() const {
    std::vector<NotificationGroup> result;
    for (const auto& [key, group] : groups_) {
        result.push_back(group);
    }
    return result;
}

NotificationResult NotificationManager::addToGroup(uint64_t notificationId, const std::string& groupKey) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    auto it = groups_.find(groupKey);
    if (it == groups_.end()) return NotificationResult::NOT_FOUND;

    // Check notification exists
    int idx = findActiveIndex(notificationId);
    if (idx < 0) return NotificationResult::NOT_FOUND;

    // Check if already in group (idempotent)
    for (uint64_t childId : it->second.childIds) {
        if (childId == notificationId) return NotificationResult::SUCCESS;
    }

    it->second.childIds.push_back(notificationId);
    activeQueue_[idx].groupKey = groupKey;
    return NotificationResult::SUCCESS;
}

NotificationResult NotificationManager::removeFromGroup(uint64_t notificationId, const std::string& groupKey) {
    if (!initialized_) return NotificationResult::NOT_INITIALIZED;
    auto it = groups_.find(groupKey);
    if (it == groups_.end()) return NotificationResult::NOT_FOUND;

    auto& childIds = it->second.childIds;
    auto childIt = std::find(childIds.begin(), childIds.end(), notificationId);
    if (childIt == childIds.end()) return NotificationResult::NOT_FOUND;

    childIds.erase(childIt);

    // Clear groupKey on notification
    int idx = findActiveIndex(notificationId);
    if (idx >= 0) activeQueue_[idx].groupKey.clear();

    return NotificationResult::SUCCESS;
}

size_t NotificationManager::getGroupCount() const {
    return groups_.size();
}

size_t NotificationManager::getGroupChildCount(const std::string& groupKey) const {
    auto it = groups_.find(groupKey);
    if (it == groups_.end()) return 0;
    return it->second.childIds.size();
}

// ============================================================
// Do Not Disturb
// ============================================================

void NotificationManager::setDndStart(uint32_t hour, uint32_t minute) {
    dndStartHour_ = hour;
    dndStartMinute_ = minute;
}

void NotificationManager::setDndEnd(uint32_t hour, uint32_t minute) {
    dndEndHour_ = hour;
    dndEndMinute_ = minute;
}

bool NotificationManager::shouldSuppress(const Notification& notif, const NotificationChannel& channel) const {
    if (dndMode_ == DndMode::OFF) return false;
    if (dndMode_ == DndMode::TOTAL_SILENCE) return true;

    // Channel DND override
    if (channel.dndOverride != DndMode::OFF) {
        // If channel can bypass current DND, don't suppress
        if (dndMode_ == DndMode::PRIORITY_ONLY) {
            if (channel.dndOverride == DndMode::PRIORITY_ONLY || channel.dndOverride == DndMode::TOTAL_SILENCE) {
                // Channel allows itself through
            }
        }
    }

    if (dndMode_ == DndMode::ALARMS_ONLY) {
        return notif.category != NotificationCategory::ALARM;
    }

    if (dndMode_ == DndMode::PRIORITY_ONLY) {
        return notif.priority < NotificationPriority::HIGH;
    }

    return false;
}

// ============================================================
// Privacy
// ============================================================

Notification NotificationManager::redactNotification(const Notification& notif) const {
    Notification redacted = notif;

    switch (privacyMode_) {
        case PrivacyMode::HIDE_ALL:
            redacted.title.clear();
            redacted.body.clear();
            redacted.summary.clear();
            break;
        case PrivacyMode::REDACT:
            redacted.title = redactText(redacted.title);
            redacted.body = redactText(redacted.body);
            redacted.summary = redactText(redacted.summary);
            break;
        case PrivacyMode::HIDE_CONTENT:
            redacted.title = "Benachrichtigung";
            redacted.body.clear();
            redacted.summary.clear();
            break;
        case PrivacyMode::SHOW_ALL:
            // No changes
            break;
    }

    // Also respect notification-level privacy
    if (notif.privacyMode == PrivacyMode::HIDE_CONTENT) {
        redacted.title = "Benachrichtigung";
        redacted.body.clear();
    } else if (notif.privacyMode == PrivacyMode::REDACT) {
        redacted.title = redactText(redacted.title);
        redacted.body = redactText(redacted.body);
    }

    return redacted;
}

std::string NotificationManager::redactText(const std::string& text) const {
    if (text.empty()) return text;
    if (text.length() <= 3) return "***";
    return text.substr(0, 2) + std::string(text.length() - 4, '*') + text.substr(text.length() - 2);
}

// ============================================================
// Badge management
// ============================================================

int32_t NotificationManager::getBadgeCount(const std::string& appId) const {
    auto it = badges_.find(appId);
    if (it != badges_.end()) return it->second;
    return 0;
}

void NotificationManager::setBadgeCount(const std::string& appId, int32_t count) {
    badges_[appId] = count < 0 ? 0 : count;
}

void NotificationManager::clearBadge(const std::string& appId) {
    badges_[appId] = 0;
}

std::map<std::string, int32_t> NotificationManager::getAllBadges() const {
    return badges_;
}

// ============================================================
// Stats
// ============================================================

NotificationStats NotificationManager::getStats() const {
    NotificationStats stats;
    stats.totalPosted = totalPosted_;
    stats.totalActive = activeQueue_.size();
    stats.totalDismissed = totalDismissed_;
    stats.totalExpired = totalExpired_;
    stats.totalCancelled = totalCancelled_;
    stats.totalBlocked = totalBlocked_;
    stats.totalSnoozed = totalSnoozed_;
    stats.totalChannels = channels_.size();
    stats.totalGroups = groups_.size();
    stats.allowedApps = allowedApps_.size();
    stats.blockedApps = blockedApps_.size();

    // Per-app counts
    for (const auto& notif : activeQueue_) {
        stats.perAppCounts[notif.appId]++;
    }

    return stats;
}

void NotificationManager::resetStats() {
    totalPosted_ = 0;
    totalDismissed_ = 0;
    totalExpired_ = 0;
    totalCancelled_ = 0;
    totalBlocked_ = 0;
    totalSnoozed_ = 0;
}

// ============================================================
// Management
// ============================================================

void NotificationManager::clearHistory() {
    history_.clear();
}

void NotificationManager::clearAll() {
    activeQueue_.clear();
    history_.clear();
    badges_.clear();
    groups_.clear();
    // Don't clear channels or app permissions
}

void NotificationManager::clearForApp(const std::string& appId) {
    std::vector<uint64_t> toRemove;
    for (const auto& notif : activeQueue_) {
        if (notif.appId == appId) toRemove.push_back(notif.id);
    }
    for (uint64_t id : toRemove) {
        cancel(id);
    }
    badges_.erase(appId);
}

// ============================================================
// String helpers
// ============================================================

const char* NotificationManager::priorityToString(NotificationPriority priority) {
    switch (priority) {
        case NotificationPriority::MIN: return "MIN";
        case NotificationPriority::LOW: return "LOW";
        case NotificationPriority::DEFAULT: return "DEFAULT";
        case NotificationPriority::HIGH: return "HIGH";
        case NotificationPriority::MAX: return "MAX";
        case NotificationPriority::NONE: return "NONE";
    }
    return "UNKNOWN";
}

const char* NotificationManager::categoryToString(NotificationCategory category) {
    switch (category) {
        case NotificationCategory::MESSAGE: return "MESSAGE";
        case NotificationCategory::CALL: return "CALL";
        case NotificationCategory::EMAIL: return "EMAIL";
        case NotificationCategory::SOCIAL: return "SOCIAL";
        case NotificationCategory::ALARM: return "ALARM";
        case NotificationCategory::REMINDER: return "REMINDER";
        case NotificationCategory::ERROR: return "ERROR";
        case NotificationCategory::SYSTEM: return "SYSTEM";
        case NotificationCategory::SECURITY: return "SECURITY";
        case NotificationCategory::UPDATE: return "UPDATE";
        case NotificationCategory::TRANSPORT: return "TRANSPORT";
        case NotificationCategory::MEDIA: return "MEDIA";
        case NotificationCategory::OTHER: return "OTHER";
    }
    return "UNKNOWN";
}

const char* NotificationManager::importanceToString(ChannelImportance importance) {
    switch (importance) {
        case ChannelImportance::NONE: return "NONE";
        case ChannelImportance::MIN: return "MIN";
        case ChannelImportance::LOW: return "LOW";
        case ChannelImportance::DEFAULT: return "DEFAULT";
        case ChannelImportance::HIGH: return "HIGH";
        case ChannelImportance::URGENT: return "URGENT";
    }
    return "UNKNOWN";
}

const char* NotificationManager::stateToString(NotificationState state) {
    switch (state) {
        case NotificationState::PENDING: return "PENDING";
        case NotificationState::ACTIVE: return "ACTIVE";
        case NotificationState::SNOOZED: return "SNOOZED";
        case NotificationState::DISMISSED: return "DISMISSED";
        case NotificationState::EXPIRED: return "EXPIRED";
        case NotificationState::CANCELLED: return "CANCELLED";
        case NotificationState::BLOCKED: return "BLOCKED";
    }
    return "UNKNOWN";
}

const char* NotificationManager::resultToString(NotificationResult result) {
    switch (result) {
        case NotificationResult::SUCCESS: return "SUCCESS";
        case NotificationResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case NotificationResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case NotificationResult::NOT_FOUND: return "NOT_FOUND";
        case NotificationResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case NotificationResult::CHANNEL_NOT_FOUND: return "CHANNEL_NOT_FOUND";
        case NotificationResult::CHANNEL_ALREADY_EXISTS: return "CHANNEL_ALREADY_EXISTS";
        case NotificationResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case NotificationResult::QUEUE_FULL: return "QUEUE_FULL";
        case NotificationResult::APP_NOT_ALLOWED: return "APP_NOT_ALLOWED";
        case NotificationResult::DND_ACTIVE: return "DND_ACTIVE";
        case NotificationResult::STATE_ERROR: return "STATE_ERROR";
        case NotificationResult::MAX_REACHED: return "MAX_REACHED";
    }
    return "UNKNOWN";
}

const char* NotificationManager::dndModeToString(DndMode mode) {
    switch (mode) {
        case DndMode::OFF: return "OFF";
        case DndMode::PRIORITY_ONLY: return "PRIORITY_ONLY";
        case DndMode::TOTAL_SILENCE: return "TOTAL_SILENCE";
        case DndMode::ALARMS_ONLY: return "ALARMS_ONLY";
    }
    return "UNKNOWN";
}

const char* NotificationManager::privacyModeToString(PrivacyMode mode) {
    switch (mode) {
        case PrivacyMode::SHOW_ALL: return "SHOW_ALL";
        case PrivacyMode::HIDE_CONTENT: return "HIDE_CONTENT";
        case PrivacyMode::REDACT: return "REDACT";
        case PrivacyMode::HIDE_ALL: return "HIDE_ALL";
    }
    return "UNKNOWN";
}

const char* NotificationManager::groupAlertToString(GroupAlertBehavior behavior) {
    switch (behavior) {
        case GroupAlertBehavior::CHILDREN: return "CHILDREN";
        case GroupAlertBehavior::SUMMARY: return "SUMMARY";
        case GroupAlertBehavior::ALL: return "ALL";
    }
    return "UNKNOWN";
}

NotificationPriority NotificationManager::stringToPriority(const std::string& str) {
    if (str == "MIN") return NotificationPriority::MIN;
    if (str == "LOW") return NotificationPriority::LOW;
    if (str == "DEFAULT") return NotificationPriority::DEFAULT;
    if (str == "HIGH") return NotificationPriority::HIGH;
    if (str == "MAX") return NotificationPriority::MAX;
    if (str == "NONE") return NotificationPriority::NONE;
    return NotificationPriority::DEFAULT;
}

NotificationState NotificationManager::stringToState(const std::string& str) {
    if (str == "PENDING") return NotificationState::PENDING;
    if (str == "ACTIVE") return NotificationState::ACTIVE;
    if (str == "SNOOZED") return NotificationState::SNOOZED;
    if (str == "DISMISSED") return NotificationState::DISMISSED;
    if (str == "EXPIRED") return NotificationState::EXPIRED;
    if (str == "CANCELLED") return NotificationState::CANCELLED;
    if (str == "BLOCKED") return NotificationState::BLOCKED;
    return NotificationState::PENDING;
}

}  // namespace phantom::notifications
