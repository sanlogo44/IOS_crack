/*
 * Phantom OS - Vibrator Manager Implementation
 * v0.36.0 - License: GPL-3.0
 *
 * Implementation of the privacy-first haptic feedback service.
 * All data is simulated in-memory.
 */

#include "phantom/vibrator/vibrator_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <numeric>

namespace phantom {
namespace vibrator {

// ============================================================
// Lifecycle
// ============================================================

VibratorResult VibratorManager::initialize(size_t maxHistory, size_t maxEvents) {
    if (initialized_) return VibratorResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0)
        return VibratorResult::INVALID_PARAMETER;

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;

    initialized_ = true;
    vibratorState_ = VibratorState::OFF;
    intensity_ = 128;
    vibrating_ = false;
    currentDurationMs_ = 0;
    mockEnabled_ = false;
    mockDuration_ = 100;

    registeredPatterns_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeVibrationUsers_.clear();

    createDefaultPatterns();

    stats_ = VibratorStats{};

    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::shutdown() {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;

    registeredPatterns_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeVibrationUsers_.clear();

    vibratorState_ = VibratorState::OFF;
    vibrating_ = false;
    mockEnabled_ = false;
    initialized_ = false;

    return VibratorResult::SUCCESS;
}

// ============================================================
// Vibrator state
// ============================================================

VibratorResult VibratorManager::enableVibrator(const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;
    if (vibratorState_ == VibratorState::ON) return VibratorResult::BAD_STATE;

    vibratorState_ = VibratorState::ON;
    stats_.stateChanges++;
    recordEvent(VibratorEventType::VIBRATOR_STATE_CHANGED, VibratorResult::SUCCESS,
                owner, "Vibrator ON");
    logToServer("INFO", "Vibrator enabled");

    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::disableVibrator(const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;
    if (vibratorState_ == VibratorState::OFF) return VibratorResult::BAD_STATE;

    vibratorState_ = VibratorState::OFF;
    vibrating_ = false;
    currentDurationMs_ = 0;
    activeVibrationUsers_.clear();
    updatePrivacyIndicator();

    stats_.stateChanges++;
    recordEvent(VibratorEventType::VIBRATOR_STATE_CHANGED, VibratorResult::SUCCESS,
                owner, "Vibrator OFF");
    logToServer("INFO", "Vibrator disabled");

    return VibratorResult::SUCCESS;
}

// ============================================================
// Intensity
// ============================================================

VibratorResult VibratorManager::setIntensity(uint32_t intensity, const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    if (intensity < VIBRATOR_DEFAULT_MIN_INTENSITY || intensity > VIBRATOR_DEFAULT_MAX_INTENSITY)
        return VibratorResult::INTENSITY_OUT_OF_RANGE;

    uint32_t old = intensity_;
    intensity_ = intensity;
    stats_.intensityChanges++;
    recordEvent(VibratorEventType::INTENSITY_CHANGED, VibratorResult::SUCCESS,
                owner, "Intensity: " + std::to_string(old) + " -> " + std::to_string(intensity));

    return VibratorResult::SUCCESS;
}

// ============================================================
// Vibration control
// ============================================================

VibratorResult VibratorManager::vibrate(uint32_t durationMs, const std::string& appId) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (vibratorState_ != VibratorState::ON) return VibratorResult::VIBRATOR_OFF;
    if (durationMs == 0) return VibratorResult::INVALID_PARAMETER;
    if (durationMs > VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS) return VibratorResult::PATTERN_TOO_LONG;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return VibratorResult::PERMISSION_DENIED;

    vibrating_ = true;
    currentDurationMs_ = durationMs;

    stats_.vibrationsStarted++;
    recordEvent(VibratorEventType::VIBRATION_STARTED, VibratorResult::SUCCESS,
                appId, "Duration: " + std::to_string(durationMs) + "ms");

    if (std::find(activeVibrationUsers_.begin(), activeVibrationUsers_.end(), appId) == activeVibrationUsers_.end()) {
        activeVibrationUsers_.push_back(appId);
        updatePrivacyIndicator();
    }
    lastAccessTime_ = getCurrentTimeMs();

    // Consume ALLOW_ONCE
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == VibrationPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
    }

    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::vibratePattern(const VibrationPattern& pattern, const std::string& appId) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (vibratorState_ != VibratorState::ON) return VibratorResult::VIBRATOR_OFF;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return VibratorResult::PERMISSION_DENIED;

    if (!validatePattern(pattern)) return VibratorResult::PATTERN_EMPTY;

    uint32_t totalDuration = calculatePatternDuration(pattern);
    if (totalDuration > VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS) return VibratorResult::PATTERN_TOO_LONG;

    // Custom pattern permission check for non-system apps
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it == appPolicies_.end() || !it->second.allowCustomPatterns) {
            return VibratorResult::PERMISSION_DENIED;
        }
    }

    vibrating_ = true;
    currentDurationMs_ = totalDuration;

    stats_.patternsPlayed++;
    recordEvent(VibratorEventType::PATTERN_PLAYED, VibratorResult::SUCCESS,
                appId, "Pattern: " + pattern.name);

    if (std::find(activeVibrationUsers_.begin(), activeVibrationUsers_.end(), appId) == activeVibrationUsers_.end()) {
        activeVibrationUsers_.push_back(appId);
        updatePrivacyIndicator();
    }
    lastAccessTime_ = getCurrentTimeMs();

    // Consume ALLOW_ONCE
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == VibrationPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
    }

    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::vibrateHaptic(HapticType type, const std::string& appId) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (vibratorState_ != VibratorState::ON) return VibratorResult::VIBRATOR_OFF;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return VibratorResult::PERMISSION_DENIED;

    // System haptics permission check for non-system apps
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it == appPolicies_.end() || !it->second.allowSystemHaptics) {
            return VibratorResult::PERMISSION_DENIED;
        }
    }

    vibrating_ = true;
    currentDurationMs_ = 20; // Haptic feedback is typically short

    stats_.hapticFeedbacks++;
    recordEvent(VibratorEventType::HAPTIC_FEEDBACK, VibratorResult::SUCCESS,
                appId, std::string("Haptic: ") + hapticTypeToString(type));

    if (std::find(activeVibrationUsers_.begin(), activeVibrationUsers_.end(), appId) == activeVibrationUsers_.end()) {
        activeVibrationUsers_.push_back(appId);
        updatePrivacyIndicator();
    }
    lastAccessTime_ = getCurrentTimeMs();

    // Consume ALLOW_ONCE
    if (!isSystemOwner(appId)) {
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == VibrationPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
    }

    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::stopVibration(const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return VibratorResult::SIMULATED_FAILURE; }
    if (!vibrating_) return VibratorResult::BAD_STATE;

    vibrating_ = false;
    currentDurationMs_ = 0;

    stats_.vibrationsStopped++;
    recordEvent(VibratorEventType::VIBRATION_STOPPED, VibratorResult::SUCCESS,
                owner, "Vibration stopped");

    auto it = std::find(activeVibrationUsers_.begin(), activeVibrationUsers_.end(), owner);
    if (it != activeVibrationUsers_.end()) {
        activeVibrationUsers_.erase(it);
        updatePrivacyIndicator();
    }

    return VibratorResult::SUCCESS;
}

// ============================================================
// Pattern management
// ============================================================

VibratorResult VibratorManager::registerPattern(const VibrationPattern& pattern, const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;
    if (pattern.name.empty()) return VibratorResult::INVALID_PARAMETER;
    if (!validatePattern(pattern)) return VibratorResult::PATTERN_EMPTY;

    VibrationPattern p = pattern;
    p.totalDurationMs = calculatePatternDuration(pattern);
    if (p.totalDurationMs > VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS)
        return VibratorResult::PATTERN_TOO_LONG;

    registeredPatterns_[pattern.name] = p;
    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::unregisterPattern(const std::string& name, const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    auto it = registeredPatterns_.find(name);
    if (it == registeredPatterns_.end()) return VibratorResult::INVALID_PARAMETER;

    registeredPatterns_.erase(it);
    return VibratorResult::SUCCESS;
}

std::vector<VibrationPattern> VibratorManager::getRegisteredPatterns() const {
    std::vector<VibrationPattern> result;
    for (const auto& [name, pattern] : registeredPatterns_) {
        result.push_back(pattern);
    }
    return result;
}

bool VibratorManager::getPattern(const std::string& name, VibrationPattern& outPattern) const {
    auto it = registeredPatterns_.find(name);
    if (it == registeredPatterns_.end()) return false;
    outPattern = it->second;
    return true;
}

// ============================================================
// Permission / policy
// ============================================================

VibratorResult VibratorManager::setAppVibrationPolicy(const std::string& appId,
                                                          VibrationPermission permission,
                                                          VibrationPrivacyMode privacyMode,
                                                          uint32_t privacyFlags,
                                                          uint32_t preferredIntensity,
                                                          bool allowCustomPatterns,
                                                          bool allowSystemHaptics,
                                                          const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;
    if (appId.empty()) return VibratorResult::INVALID_PARAMETER;

    VibrationPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.preferredIntensity = preferredIntensity;
    policy.allowCustomPatterns = allowCustomPatterns;
    policy.allowSystemHaptics = allowSystemHaptics;
    policy.lastGrantedAt = (permission != VibrationPermission::DENY) ? getCurrentTimeMs() : 0;
    policy.oneShotUsed = false;
    policy.foreground = false;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(VibratorEventType::PERMISSION_CHANGED, VibratorResult::SUCCESS,
                owner, "Policy set for " + appId);

    return VibratorResult::SUCCESS;
}

VibrationPolicy VibratorManager::getAppVibrationPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return VibrationPolicy{};
}

VibratorResult VibratorManager::clearAppVibrationPolicy(const std::string& appId,
                                                            const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return VibratorResult::INVALID_PARAMETER;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    auto uit = std::find(activeVibrationUsers_.begin(), activeVibrationUsers_.end(), appId);
    if (uit != activeVibrationUsers_.end()) {
        activeVibrationUsers_.erase(uit);
        updatePrivacyIndicator();
    }

    return VibratorResult::SUCCESS;
}

bool VibratorManager::checkAppAccess(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    switch (policy.permission) {
        case VibrationPermission::DENY:
            return false;
        case VibrationPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case VibrationPermission::ALLOW_ALWAYS:
            return true;
        case VibrationPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

VibratorResult VibratorManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return VibratorResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return VibratorResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<VibratorEvent> VibratorManager::getHistory(const std::string& appId,
                                                          size_t limit) const {
    std::vector<VibratorEvent> result;
    for (auto it = history_.rbegin(); it != history_.rend(); ++it) {
        if (it->appId == appId || isSystemOwner(appId)) {
            result.push_back(*it);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

VibratorResult VibratorManager::clearHistory(const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    recordEvent(VibratorEventType::HISTORY_CLEARED, VibratorResult::SUCCESS,
                owner, "History cleared");
    history_.clear();
    stats_.historyClears++;
    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::clearAppHistory(const std::string& appId,
                                                   const std::string& requester) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(requester) && requester != appId) return VibratorResult::PERMISSION_DENIED;

    auto it = std::remove_if(history_.begin(), history_.end(),
        [&appId](const VibratorEvent& e) { return e.appId == appId; });
    history_.erase(it, history_.end());

    return VibratorResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

VibratorResult VibratorManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    return VibratorResult::SUCCESS;
}

VibratorResult VibratorManager::setMockDuration(uint32_t durationMs,
                                                   const std::string& owner) {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return VibratorResult::PERMISSION_DENIED;

    mockDuration_ = durationMs;
    stats_.mockVibrations++;
    recordEvent(VibratorEventType::MOCK_VIBRATION_SET, VibratorResult::SUCCESS,
                owner, "Mock duration: " + std::to_string(durationMs) + "ms");

    return VibratorResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<VibratorEvent> VibratorManager::getEvents(size_t limit) const {
    if (limit == 0) return events_;
    std::vector<VibratorEvent> result;
    for (auto it = events_.rbegin(); it != events_.rend() && result.size() < limit; ++it) {
        result.push_back(*it);
    }
    return result;
}

std::vector<VibratorEvent> VibratorManager::getEventsByType(VibratorEventType type) const {
    std::vector<VibratorEvent> result;
    for (const auto& e : events_) {
        if (e.type == type) result.push_back(e);
    }
    return result;
}

VibratorResult VibratorManager::clearEvents() {
    if (!initialized_) return VibratorResult::NOT_INITIALIZED;

    for (const auto& e : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(e);
    }
    events_.clear();
    return VibratorResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void VibratorManager::resetStats() {
    stats_ = VibratorStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* VibratorManager::vibratorStateToString(VibratorState state) {
    switch (state) {
        case VibratorState::OFF: return "OFF";
        case VibratorState::ON: return "ON";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::hapticTypeToString(HapticType type) {
    switch (type) {
        case HapticType::CLICK: return "CLICK";
        case HapticType::DOUBLE_CLICK: return "DOUBLE_CLICK";
        case HapticType::HEAVY_CLICK: return "HEAVY_CLICK";
        case HapticType::MEDIUM_CLICK: return "MEDIUM_CLICK";
        case HapticType::LIGHT_CLICK: return "LIGHT_CLICK";
        case HapticType::SOFT_TICK: return "SOFT_TICK";
        case HapticType::RIGID_TICK: return "RIGID_TICK";
        case HapticType::TICK: return "TICK";
        case HapticType::LONG_PRESS: return "LONG_PRESS";
        case HapticType::REJECT: return "REJECT";
        case HapticType::SELECTION: return "SELECTION";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::waveformTypeToString(WaveformType type) {
    switch (type) {
        case WaveformType::SINE: return "SINE";
        case WaveformType::SQUARE: return "SQUARE";
        case WaveformType::SAWTOOTH: return "SAWTOOTH";
        case WaveformType::TRIANGLE: return "TRIANGLE";
        case WaveformType::PULSE: return "PULSE";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::permissionToString(VibrationPermission permission) {
    switch (permission) {
        case VibrationPermission::DENY: return "DENY";
        case VibrationPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case VibrationPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case VibrationPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::privacyModeToString(VibrationPrivacyMode mode) {
    switch (mode) {
        case VibrationPrivacyMode::FULL: return "FULL";
        case VibrationPrivacyMode::REDACTED: return "REDACTED";
        case VibrationPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::resultToString(VibratorResult result) {
    switch (result) {
        case VibratorResult::SUCCESS: return "SUCCESS";
        case VibratorResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case VibratorResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case VibratorResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case VibratorResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case VibratorResult::VIBRATOR_OFF: return "VIBRATOR_OFF";
        case VibratorResult::PATTERN_TOO_LONG: return "PATTERN_TOO_LONG";
        case VibratorResult::PATTERN_EMPTY: return "PATTERN_EMPTY";
        case VibratorResult::INTENSITY_OUT_OF_RANGE: return "INTENSITY_OUT_OF_RANGE";
        case VibratorResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case VibratorResult::BAD_STATE: return "BAD_STATE";
        case VibratorResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case VibratorResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* VibratorManager::eventTypeToString(VibratorEventType type) {
    switch (type) {
        case VibratorEventType::VIBRATOR_STATE_CHANGED: return "VIBRATOR_STATE_CHANGED";
        case VibratorEventType::VIBRATION_STARTED: return "VIBRATION_STARTED";
        case VibratorEventType::VIBRATION_STOPPED: return "VIBRATION_STOPPED";
        case VibratorEventType::HAPTIC_FEEDBACK: return "HAPTIC_FEEDBACK";
        case VibratorEventType::PATTERN_PLAYED: return "PATTERN_PLAYED";
        case VibratorEventType::INTENSITY_CHANGED: return "INTENSITY_CHANGED";
        case VibratorEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case VibratorEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case VibratorEventType::INDICATOR_ON: return "INDICATOR_ON";
        case VibratorEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case VibratorEventType::MOCK_VIBRATION_SET: return "MOCK_VIBRATION_SET";
        case VibratorEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

VibratorResult VibratorManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return VibratorResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return VibratorResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return VibratorResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return VibratorResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return VibratorResult::PERMISSION_DENIED;
    if (str == "VIBRATOR_OFF") return VibratorResult::VIBRATOR_OFF;
    if (str == "PATTERN_TOO_LONG") return VibratorResult::PATTERN_TOO_LONG;
    if (str == "PATTERN_EMPTY") return VibratorResult::PATTERN_EMPTY;
    if (str == "INTENSITY_OUT_OF_RANGE") return VibratorResult::INTENSITY_OUT_OF_RANGE;
    if (str == "CAPACITY_EXCEEDED") return VibratorResult::CAPACITY_EXCEEDED;
    if (str == "BAD_STATE") return VibratorResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return VibratorResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return VibratorResult::SIMULATED_FAILURE;
    return VibratorResult::OPERATION_FAILED;
}

HapticType VibratorManager::stringToHapticType(const std::string& str) {
    if (str == "CLICK") return HapticType::CLICK;
    if (str == "DOUBLE_CLICK") return HapticType::DOUBLE_CLICK;
    if (str == "HEAVY_CLICK") return HapticType::HEAVY_CLICK;
    if (str == "MEDIUM_CLICK") return HapticType::MEDIUM_CLICK;
    if (str == "LIGHT_CLICK") return HapticType::LIGHT_CLICK;
    if (str == "SOFT_TICK") return HapticType::SOFT_TICK;
    if (str == "RIGID_TICK") return HapticType::RIGID_TICK;
    if (str == "TICK") return HapticType::TICK;
    if (str == "LONG_PRESS") return HapticType::LONG_PRESS;
    if (str == "REJECT") return HapticType::REJECT;
    if (str == "SELECTION") return HapticType::SELECTION;
    return HapticType::CLICK;
}

// ============================================================
// Private helpers
// ============================================================

uint64_t VibratorManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool VibratorManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "system_server";
}

void VibratorManager::recordEvent(VibratorEventType type, VibratorResult result,
                                    const std::string& appId,
                                    const std::string& detail) {
    VibratorEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.detail = detail;

    if (events_.size() >= maxEvents_) {
        events_.erase(events_.begin());
    }
    events_.push_back(event);

    if (history_.size() >= maxHistory_) {
        history_.erase(history_.begin());
    }
    history_.push_back(event);

    uint8_t typeIdx = static_cast<uint8_t>(type);
    uint8_t resultIdx = static_cast<uint8_t>(result);
    if (typeIdx < 12) stats_.byEventType[typeIdx]++;
    if (resultIdx < 12) stats_.byResult[resultIdx]++;

    if (result != VibratorResult::SUCCESS) {
        stats_.totalFailures++;
    }

    if (eventCallback_) eventCallback_(event);
}

void VibratorManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "VibratorManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "VibratorManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "VibratorManager");
    }
}

void VibratorManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("VibratorManager", "VibratorManager", 0, reason);
}

void VibratorManager::updatePrivacyIndicator() {
    bool isOn = !activeVibrationUsers_.empty();

    if (!prevIndicatorOn_ && isOn) {
        recordEvent(VibratorEventType::INDICATOR_ON, VibratorResult::SUCCESS,
                    "system", "Privacy indicator on");
        stats_.indicatorToggleCount++;
    } else if (prevIndicatorOn_ && !isOn) {
        recordEvent(VibratorEventType::INDICATOR_OFF, VibratorResult::SUCCESS,
                    "system", "Privacy indicator off");
        stats_.indicatorToggleCount++;
    }
    prevIndicatorOn_ = isOn;
}

void VibratorManager::createDefaultPatterns() {
    VibrationPattern shortPulse;
    shortPulse.name = "short_pulse";
    shortPulse.timings = {0, 50};
    shortPulse.amplitudes = {200};
    shortPulse.repeating = false;
    shortPulse.totalDurationMs = calculatePatternDuration(shortPulse);
    registeredPatterns_[shortPulse.name] = shortPulse;

    VibrationPattern doublePulse;
    doublePulse.name = "double_pulse";
    doublePulse.timings = {0, 50, 100, 50};
    doublePulse.amplitudes = {200, 200};
    doublePulse.repeating = false;
    doublePulse.totalDurationMs = calculatePatternDuration(doublePulse);
    registeredPatterns_[doublePulse.name] = doublePulse;

    VibrationPattern notification;
    notification.name = "notification";
    notification.timings = {0, 100, 100, 100, 100, 200};
    notification.amplitudes = {150, 200, 255};
    notification.repeating = false;
    notification.totalDurationMs = calculatePatternDuration(notification);
    registeredPatterns_[notification.name] = notification;
}

uint32_t VibratorManager::calculatePatternDuration(const VibrationPattern& pattern) const {
    return std::accumulate(pattern.timings.begin(), pattern.timings.end(), 0u);
}

bool VibratorManager::validatePattern(const VibrationPattern& pattern) const {
    if (pattern.timings.empty()) return false;
    // amplitudes count should match number of ON segments (odd indices)
    size_t onSegments = pattern.timings.size() / 2;
    if (!pattern.amplitudes.empty() && pattern.amplitudes.size() != onSegments) return false;
    return true;
}

}  // namespace vibrator
}  // namespace phantom
