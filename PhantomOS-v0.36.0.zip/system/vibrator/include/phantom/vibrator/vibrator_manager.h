/*
 * Phantom OS - Vibrator Manager (Haptic Feedback)
 * v0.36.0 - License: GPL-3.0
 *
 * Privacy-first haptic service: vibration pattern management,
 * intensity control, haptic feedback types (click, double-click,
 * heavy, medium, light, soft, rigid, tick), per-app vibration
 * policy with foreground-only enforcement, privacy indicator,
 * mock vibration for testing, events, stats, callbacks and
 * optional LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Vibration patterns are deterministic
 * stubs. The LogServer must never log per-app vibration preferences.
 */

#ifndef PHANTOM_VIBRATOR_VIBRATOR_MANAGER_H
#define PHANTOM_VIBRATOR_VIBRATOR_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace vibrator {

// ============================================================
// Constants
// ============================================================

static const uint32_t VIBRATOR_PRIVACY_NONE = 0;
static const uint32_t VIBRATOR_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t VIBRATOR_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t VIBRATOR_PRIVACY_MOCK_ALLOWED = 1 << 2;
static const uint32_t VIBRATOR_PRIVACY_INDICATOR_REQUIRED = 1 << 3;
static const uint32_t VIBRATOR_PRIVACY_DISABLE_INTENSITY_CONTROL = 1 << 4;

static const uint32_t VIBRATOR_DEFAULT_MAX_INTENSITY = 255;
static const uint32_t VIBRATOR_DEFAULT_MIN_INTENSITY = 1;
static const uint32_t VIBRATOR_DEFAULT_MAX_HISTORY = 128;
static const uint32_t VIBRATOR_DEFAULT_MAX_EVENTS = 256;
static const uint32_t VIBRATOR_DEFAULT_MAX_PATTERN_DURATION_MS = 60000;

// ============================================================
// Enums
// ============================================================

enum class VibratorState : uint8_t {
    OFF = 0,
    ON
};

enum class HapticType : uint8_t {
    CLICK = 0,
    DOUBLE_CLICK,
    HEAVY_CLICK,
    MEDIUM_CLICK,
    LIGHT_CLICK,
    SOFT_TICK,
    RIGID_TICK,
    TICK,
    LONG_PRESS,
    REJECT,
    SELECTION
};

enum class WaveformType : uint8_t {
    SINE = 0,
    SQUARE,
    SAWTOOTH,
    TRIANGLE,
    PULSE
};

enum class VibrationPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class VibrationPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class VibratorResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    VIBRATOR_OFF,
    PATTERN_TOO_LONG,
    PATTERN_EMPTY,
    INTENSITY_OUT_OF_RANGE,
    CAPACITY_EXCEEDED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class VibratorEventType : uint8_t {
    VIBRATOR_STATE_CHANGED = 0,
    VIBRATION_STARTED,
    VIBRATION_STOPPED,
    HAPTIC_FEEDBACK,
    PATTERN_PLAYED,
    INTENSITY_CHANGED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    MOCK_VIBRATION_SET,
    HISTORY_CLEARED
};

// ============================================================
// Data structures
// ============================================================

struct VibrationPattern {
    std::string name;
    std::vector<uint32_t> timings;   // alternating off/on durations in ms
    std::vector<uint8_t> amplitudes; // amplitude for each ON segment (0-255)
    bool repeating = false;
    uint32_t totalDurationMs = 0;
};

struct VibrationPolicy {
    std::string appId;
    VibrationPermission permission = VibrationPermission::DENY;
    VibrationPrivacyMode privacyMode = VibrationPrivacyMode::FULL;
    uint32_t privacyFlags = VIBRATOR_PRIVACY_NONE;
    uint32_t preferredIntensity = 128;
    bool allowCustomPatterns = false;
    bool allowSystemHaptics = true;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
};

struct VibratorEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    VibratorEventType type = VibratorEventType::VIBRATOR_STATE_CHANGED;
    VibratorResult result = VibratorResult::SUCCESS;
    std::string appId;
    std::string detail;
};

struct VibratorStats {
    uint64_t stateChanges = 0;
    uint64_t vibrationsStarted = 0;
    uint64_t vibrationsStopped = 0;
    uint64_t hapticFeedbacks = 0;
    uint64_t patternsPlayed = 0;
    uint64_t intensityChanges = 0;
    uint64_t permissionsChanged = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t mockVibrations = 0;
    uint64_t byEventType[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Vibrator Manager
// ============================================================

class VibratorManager {
public:
    VibratorManager() = default;
    ~VibratorManager() = default;

    VibratorManager(const VibratorManager&) = delete;
    VibratorManager& operator=(const VibratorManager&) = delete;

    // ---- Lifecycle ----
    VibratorResult initialize(size_t maxHistory = 128, size_t maxEvents = 256);
    VibratorResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Vibrator state ----
    VibratorResult enableVibrator(const std::string& owner = "system");
    VibratorResult disableVibrator(const std::string& owner = "system");
    VibratorState getVibratorState() const { return vibratorState_; }
    bool isVibratorEnabled() const { return vibratorState_ == VibratorState::ON; }

    // ---- Intensity ----
    VibratorResult setIntensity(uint32_t intensity, const std::string& owner = "system");
    uint32_t getIntensity() const { return intensity_; }
    uint32_t getMaxIntensity() const { return VIBRATOR_DEFAULT_MAX_INTENSITY; }
    uint32_t getMinIntensity() const { return VIBRATOR_DEFAULT_MIN_INTENSITY; }

    // ---- Vibration control ----
    VibratorResult vibrate(uint32_t durationMs, const std::string& appId = "system");
    VibratorResult vibratePattern(const VibrationPattern& pattern, const std::string& appId = "system");
    VibratorResult vibrateHaptic(HapticType type, const std::string& appId = "system");
    VibratorResult stopVibration(const std::string& owner = "system");
    bool isVibrating() const { return vibrating_; }
    uint32_t getCurrentVibrationDuration() const { return currentDurationMs_; }

    // ---- Pattern management ----
    VibratorResult registerPattern(const VibrationPattern& pattern, const std::string& owner = "system");
    VibratorResult unregisterPattern(const std::string& name, const std::string& owner = "system");
    std::vector<VibrationPattern> getRegisteredPatterns() const;
    bool getPattern(const std::string& name, VibrationPattern& outPattern) const;

    // ---- Permission / policy ----
    VibratorResult setAppVibrationPolicy(const std::string& appId,
                                            VibrationPermission permission,
                                            VibrationPrivacyMode privacyMode,
                                            uint32_t privacyFlags = VIBRATOR_PRIVACY_NONE,
                                            uint32_t preferredIntensity = 128,
                                            bool allowCustomPatterns = false,
                                            bool allowSystemHaptics = true,
                                            const std::string& owner = "system");
    VibrationPolicy getAppVibrationPolicy(const std::string& appId) const;
    VibratorResult clearAppVibrationPolicy(const std::string& appId,
                                               const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    VibratorResult setAppForeground(const std::string& appId, bool foreground);

    // ---- History ----
    std::vector<VibratorEvent> getHistory(const std::string& appId,
                                            size_t limit = 0) const;
    VibratorResult clearHistory(const std::string& owner = "system");
    VibratorResult clearAppHistory(const std::string& appId,
                                       const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    VibratorResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    VibratorResult setMockDuration(uint32_t durationMs,
                                     const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeVibrationUsers_.empty(); }
    std::vector<std::string> getActiveVibrationUsers() const { return activeVibrationUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<VibratorEvent> getEvents(size_t limit = 0) const;
    std::vector<VibratorEvent> getEventsByType(VibratorEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    VibratorResult clearEvents();

    // ---- Stats ----
    VibratorStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const VibratorEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, VibratorResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* vibratorStateToString(VibratorState state);
    static const char* hapticTypeToString(HapticType type);
    static const char* waveformTypeToString(WaveformType type);
    static const char* permissionToString(VibrationPermission permission);
    static const char* privacyModeToString(VibrationPrivacyMode mode);
    static const char* resultToString(VibratorResult result);
    static const char* eventTypeToString(VibratorEventType type);
    static VibratorResult stringToResult(const std::string& str);
    static HapticType stringToHapticType(const std::string& str);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(VibratorEventType type, VibratorResult result,
                     const std::string& appId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void createDefaultPatterns();
    uint32_t calculatePatternDuration(const VibrationPattern& pattern) const;
    bool validatePattern(const VibrationPattern& pattern) const;

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;

    VibratorState vibratorState_ = VibratorState::OFF;
    uint32_t intensity_ = 128;
    bool vibrating_ = false;
    uint32_t currentDurationMs_ = 0;

    std::map<std::string, VibrationPattern> registeredPatterns_;
    std::map<std::string, VibrationPolicy> appPolicies_;

    std::vector<VibratorEvent> history_;
    std::vector<VibratorEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    uint32_t mockDuration_ = 100;
    bool prevIndicatorOn_ = false;

    std::vector<std::string> activeVibrationUsers_;
    uint64_t lastAccessTime_ = 0;

    VibratorStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const VibratorEvent&)> eventCallback_;
    std::function<void(const std::string&, VibratorResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace vibrator
}  // namespace phantom

#endif  // PHANTOM_VIBRATOR_VIBRATOR_MANAGER_H
