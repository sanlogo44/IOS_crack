/*
 * Phantom OS - Backup & Restore Manager Implementation
 * v0.21.0
 * License: GPL-3.0
 */

#include "phantom/backup/backup_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <algorithm>
#include <sstream>
#include <cstring>
#include <cstdio>

namespace phantom::backup {

// ============================================================
// Private helpers
// ============================================================

uint64_t BackupManager::getCurrentTimeMs() const {
    auto now = std::chrono::steady_clock::now();
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count());
}

int BackupManager::findBackupIndex(uint64_t id) const {
    for (size_t i = 0; i < backups_.size(); ++i) {
        if (backups_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

bool BackupManager::isBackupActive(BackupState state) const {
    return state == BackupState::SCANNING ||
           state == BackupState::BACKING_UP ||
           state == BackupState::VERIFYING ||
           state == BackupState::RESTORING;
}

void BackupManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "BackupManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "BackupManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "BackupManager");
        }
    }
}

void BackupManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId, "backup_manager", 0, message);
    }
}

void BackupManager::moveToHistory(uint64_t id, BackupState finalState) {
    int idx = findBackupIndex(id);
    if (idx >= 0) {
        BackupEntry entry = backups_[idx];
        entry.state = finalState;
        entry.completionTime = getCurrentTimeMs();
        if (history_.size() >= maxHistorySize_) {
            history_.erase(history_.begin());
        }
        history_.push_back(entry);
    }
}

void BackupManager::updateProgressState(uint64_t id, BackupState state, uint32_t percent) {
    auto it = progress_.find(id);
    if (it == progress_.end()) {
        BackupProgress p;
        p.backupId = id;
        p.state = state;
        p.progressPercent = std::min(percent, 100u);
        p.lastUpdated = getCurrentTimeMs();
        progress_[id] = p;
    } else {
        it->second.state = state;
        it->second.progressPercent = std::min(percent, 100u);
        it->second.lastUpdated = getCurrentTimeMs();
    }
}

void BackupManager::applyPrivacyScrubbing(BackupEntry& entry) const {
    if (backupPrivacy_ == BackupPrivacy::DISABLED) return;
    if (backupPrivacy_ == BackupPrivacy::FULL) return;

    // ANONYMIZED: scrub device ID and clear included app names
    if (backupPrivacy_ == BackupPrivacy::ANONYMIZED) {
        entry.deviceId = "anonymized";
        // Keep included app names but anonymize paths
        for (auto& path : entry.includedPaths) {
            // Replace user home with generic placeholder
            size_t pos = path.find("/home/user");
            if (pos != std::string::npos) {
                path.replace(pos, 10, "/home/USER");
            }
        }
        for (auto& path : entry.excludedPaths) {
            size_t pos = path.find("/home/user");
            if (pos != std::string::npos) {
                path.replace(pos, 10, "/home/USER");
            }
        }
    }

    // MINIMAL: strip PII-heavy fields entirely
    if (backupPrivacy_ == BackupPrivacy::MINIMAL) {
        entry.deviceId.clear();
        entry.includedApps.clear();
        entry.sourcePath.clear();
        entry.includedPaths.clear();
        entry.excludedPaths.clear();
    }
}

void BackupManager::pruneIfNeeded() {
    if (!retentionPolicy_.autoPrune) return;
    size_t effectiveMax = std::min(retentionPolicy_.maxBackups, static_cast<uint32_t>(maxBackups_));
    if (backups_.size() <= effectiveMax) return;

    // Sort by timestamp (oldest first) but respect keepLatestPerType and minBackupsPerType
    std::vector<size_t> indices;
    for (size_t i = 0; i < backups_.size(); ++i) {
        indices.push_back(i);
    }
    std::sort(indices.begin(), indices.end(), [this](size_t a, size_t b) {
        return backups_[a].timestamp < backups_[b].timestamp;
    });

    // Identify latest backup per type
    std::map<BackupType, uint64_t> latestPerType;
    for (const auto& entry : backups_) {
        auto it = latestPerType.find(entry.type);
        if (it == latestPerType.end() || entry.timestamp > it->second) {
            latestPerType[entry.type] = entry.timestamp;
        }
    }

    // Count backups per type (to enforce minBackupsPerType)
    std::map<BackupType, size_t> countPerType;
    for (const auto& entry : backups_) {
        countPerType[entry.type]++;
    }

    size_t toRemove = backups_.size() - effectiveMax;
    for (size_t idx : indices) {
        if (toRemove == 0) break;
        const BackupEntry& entry = backups_[idx];

        // Skip if this is the latest backup for its type and keepLatestPerType is true
        if (retentionPolicy_.keepLatestPerType) {
            auto it = latestPerType.find(entry.type);
            if (it != latestPerType.end() && entry.timestamp == it->second) {
                continue;
            }
        }

        // Skip if removing would violate minBackupsPerType
        if (countPerType[entry.type] <= static_cast<size_t>(retentionPolicy_.minBackupsPerType)) {
            continue;
        }

        // Check age constraint
        if (retentionPolicy_.maxAgeDays > 0) {
            uint64_t ageMs = getCurrentTimeMs() - entry.timestamp;
            uint64_t ageDays = ageMs / (24ULL * 3600ULL * 1000ULL);
            if (ageDays < retentionPolicy_.maxAgeDays) {
                continue;  // Not old enough yet
            }
        }

        // Move to history and mark for removal
        moveToHistory(entry.id, BackupState::FAILED);
        countPerType[entry.type]--;
        totalPruned_++;
        toRemove--;
    }

    // Remove pruned entries from backups_
    backups_.erase(
        std::remove_if(backups_.begin(), backups_.end(),
            [this](const BackupEntry& e) {
                // Check if this entry was moved to history
                for (const auto& h : history_) {
                    if (h.id == e.id) return true;
                }
                return false;
            }),
        backups_.end());
}

// ============================================================
// Lifecycle
// ============================================================

BackupResult BackupManager::initialize(size_t maxBackups, size_t maxHistorySize) {
    if (initialized_) return BackupResult::ALREADY_INITIALIZED;
    initialized_ = true;
    maxBackups_ = maxBackups;
    maxHistorySize_ = maxHistorySize;
    return BackupResult::SUCCESS;
}

BackupResult BackupManager::shutdown() {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    backups_.clear();
    progress_.clear();
    history_.clear();
    totalBackupsCreated_ = 0;
    totalBackupsCompleted_ = 0;
    totalBackupsFailed_ = 0;
    totalBackupsCancelled_ = 0;
    totalRestoresAttempted_ = 0;
    totalRestoresSucceeded_ = 0;
    totalRestoresFailed_ = 0;
    totalBytesBackedUp_ = 0;
    totalBytesRestored_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalByDestination_, 0, sizeof(totalByDestination_));
    totalVerifications_ = 0;
    totalVerificationFailures_ = 0;
    totalPruned_ = 0;
    totalCancelled_ = 0;
    initialized_ = false;
    return BackupResult::SUCCESS;
}

// ============================================================
// Schedule
// ============================================================

bool BackupManager::shouldAutoBackup(uint64_t currentTimeMs) const {
    if (!schedule_.autoBackupEnabled) return false;
    if (currentTimeMs == 0) currentTimeMs = getCurrentTimeMs();
    if (schedule_.nextBackupTime == 0) return true;  // Never backed up before
    return currentTimeMs >= schedule_.nextBackupTime;
}

// ============================================================
// Backup management
// ============================================================

BackupResult BackupManager::createBackup(const BackupEntry& entry) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    if (entry.name.empty()) return BackupResult::INVALID_BACKUP;

    // Check if encryption is required but not set
    if (requireEncryption_ && !entry.encrypted) {
        return BackupResult::ENCRYPTION_REQUIRED;
    }

    // Check quota
    if (backups_.size() >= maxBackups_) {
        pruneIfNeeded();
        if (backups_.size() >= maxBackups_) {
            return BackupResult::QUOTA_EXCEEDED;
        }
    }

    BackupEntry newEntry = entry;
    newEntry.id = nextId_++;
    newEntry.timestamp = getCurrentTimeMs();
    newEntry.state = BackupState::SCANNING;
    applyPrivacyScrubbing(newEntry);

    // Simulate scanning and backup process
    newEntry.state = BackupState::BACKING_UP;

    // If failNextBackup is set, simulate failure
    if (failNextBackup_) {
        failNextBackup_ = false;
        newEntry.state = BackupState::FAILED;
        newEntry.completionTime = getCurrentTimeMs();
        backups_.push_back(newEntry);
        updateProgressState(newEntry.id, BackupState::FAILED, 0);
        totalBackupsCreated_++;
        totalBackupsFailed_++;
        totalByType_[static_cast<int>(newEntry.type)]++;
        totalByDestination_[static_cast<int>(newEntry.destination)]++;
        logToServer("error", "Backup failed (simulated): " + newEntry.name);
        notifyCrashReporter("backup_manager", "Backup failed (simulated): " + newEntry.name);
        if (backupFailedCb_) backupFailedCb_(newEntry);
        return BackupResult::BACKUP_FAILED;
    }

    // Simulate successful backup
    // Generate checksum from name + type + timestamp
    std::string payload = newEntry.name + std::to_string(static_cast<int>(newEntry.type)) +
                          std::to_string(newEntry.timestamp);
    newEntry.checksum = computeChecksum(payload);
    newEntry.state = BackupState::COMPLETED;
    newEntry.completionTime = getCurrentTimeMs();
    newEntry.verified = false;

    // Simulate size and items if not set
    if (newEntry.sizeBytes == 0) {
        newEntry.sizeBytes = 1024 * 1024 * 100;  // 100MB simulated
    }
    if (newEntry.itemCount == 0) {
        newEntry.itemCount = 1000;  // Simulated
    }

    backups_.push_back(newEntry);
    updateProgressState(newEntry.id, BackupState::COMPLETED, 100);
    totalBackupsCreated_++;
    totalBackupsCompleted_++;
    totalBytesBackedUp_ += newEntry.sizeBytes;
    totalByType_[static_cast<int>(newEntry.type)]++;
    totalByDestination_[static_cast<int>(newEntry.destination)]++;

    logToServer("info", "Backup created: " + newEntry.name);

    if (backupCompleteCb_) backupCompleteCb_(newEntry);

    return BackupResult::SUCCESS;
}

BackupResult BackupManager::cancelBackup(uint64_t id) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    BackupEntry& entry = backups_[idx];
    if (!isBackupActive(entry.state)) {
        return BackupResult::BAD_STATE;
    }

    entry.state = BackupState::CANCELLED;
    entry.completionTime = getCurrentTimeMs();
    updateProgressState(id, BackupState::CANCELLED, 0);
    totalBackupsCancelled_++;
    totalCancelled_++;
    logToServer("info", "Backup cancelled: " + entry.name);

    return BackupResult::SUCCESS;
}

std::vector<BackupEntry> BackupManager::getBackups() const {
    return backups_;
}

std::vector<BackupEntry> BackupManager::getBackupsByType(BackupType type) const {
    std::vector<BackupEntry> result;
    for (const auto& entry : backups_) {
        if (entry.type == type) result.push_back(entry);
    }
    return result;
}

std::vector<BackupEntry> BackupManager::getBackupsByDestination(BackupDestination dest) const {
    std::vector<BackupEntry> result;
    for (const auto& entry : backups_) {
        if (entry.destination == dest) result.push_back(entry);
    }
    return result;
}

std::vector<BackupEntry> BackupManager::getBackupsByState(BackupState state) const {
    std::vector<BackupEntry> result;
    for (const auto& entry : backups_) {
        if (entry.state == state) result.push_back(entry);
    }
    return result;
}

BackupEntry BackupManager::getBackupById(uint64_t id) const {
    for (const auto& entry : backups_) {
        if (entry.id == id) return entry;
    }
    return BackupEntry{};
}

BackupResult BackupManager::deleteBackup(uint64_t id) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    BackupEntry& entry = backups_[idx];
    if (isBackupActive(entry.state)) {
        return BackupResult::IN_PROGRESS;
    }

    moveToHistory(id, entry.state);
    backups_.erase(backups_.begin() + idx);
    progress_.erase(id);
    logToServer("info", "Backup deleted: " + entry.name);

    return BackupResult::SUCCESS;
}

BackupResult BackupManager::deleteAllBackups() {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    for (const auto& entry : backups_) {
        if (isBackupActive(entry.state)) {
            return BackupResult::IN_PROGRESS;
        }
    }
    for (const auto& entry : backups_) {
        moveToHistory(entry.id, entry.state);
    }
    backups_.clear();
    progress_.clear();
    logToServer("info", "All backups deleted");
    return BackupResult::SUCCESS;
}

// ============================================================
// Incremental backup
// ============================================================

BackupResult BackupManager::createIncrementalBackup(uint64_t baseBackupId, const BackupEntry& entry) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;

    int baseIdx = findBackupIndex(baseBackupId);
    if (baseIdx < 0) return BackupResult::NOT_FOUND;

    BackupEntry baseBackup = backups_[baseIdx];
    if (baseBackup.state != BackupState::COMPLETED) {
        return BackupResult::BAD_STATE;
    }

    BackupEntry newEntry = entry;
    newEntry.incremental = true;
    newEntry.baseBackupId = baseBackupId;
    return createBackup(newEntry);
}

// ============================================================
// Progress
// ============================================================

BackupProgress BackupManager::getBackupProgress(uint64_t id) const {
    auto it = progress_.find(id);
    if (it != progress_.end()) {
        return it->second;
    }
    return BackupProgress{};
}

std::vector<BackupProgress> BackupManager::getActiveBackups() const {
    std::vector<BackupProgress> result;
    for (const auto& [id, prog] : progress_) {
        if (isBackupActive(prog.state)) {
            result.push_back(prog);
        }
    }
    return result;
}

BackupResult BackupManager::updateBackupProgress(uint64_t id, uint64_t processedBytes,
                                                 uint64_t processedItems, uint32_t speedBps) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    auto it = progress_.find(id);
    if (it == progress_.end()) return BackupResult::NOT_FOUND;

    it->second.processedBytes = processedBytes;
    it->second.processedItems = processedItems;
    it->second.speedBps = speedBps;

    // Calculate progress percentage
    BackupEntry& entry = backups_[idx];
    if (entry.sizeBytes > 0) {
        uint32_t percent = static_cast<uint32_t>((processedBytes * 100) / entry.sizeBytes);
        it->second.progressPercent = std::min(percent, 100u);
    }

    // Auto-transition to COMPLETED when fully processed
    if (entry.sizeBytes > 0 && processedBytes >= entry.sizeBytes) {
        it->second.state = BackupState::COMPLETED;
        it->second.progressPercent = 100;
        entry.state = BackupState::COMPLETED;
        entry.completionTime = getCurrentTimeMs();
        totalBackupsCompleted_++;
        if (backupCompleteCb_) backupCompleteCb_(entry);
    } else {
        it->second.state = BackupState::BACKING_UP;
    }

    it->second.lastUpdated = getCurrentTimeMs();

    if (progressCb_) progressCb_(it->second);

    return BackupResult::SUCCESS;
}

// ============================================================
// Verification
// ============================================================

std::string BackupManager::computeChecksum(const std::string& data) const {
    // FNV-1a based checksum model (not cryptographic SHA-256).
    uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    std::ostringstream ss;
    ss << std::hex << hash;
    return ss.str();
}

bool BackupManager::verifyChecksum(const std::string& data, const std::string& expected) const {
    if (expected.empty()) return false;
    return computeChecksum(data) == expected;
}

BackupResult BackupManager::verifyBackup(uint64_t id) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    BackupEntry& entry = backups_[idx];
    if (entry.state != BackupState::COMPLETED) {
        return BackupResult::BAD_STATE;
    }

    updateProgressState(id, BackupState::VERIFYING, 0);
    totalVerifications_++;

    // Verify checksum
    std::string payload = entry.name + std::to_string(static_cast<int>(entry.type)) +
                          std::to_string(entry.timestamp);
    std::string computed = computeChecksum(payload);

    if (!entry.checksum.empty() && computed != entry.checksum) {
        entry.verified = false;
        entry.state = BackupState::FAILED;
        updateProgressState(id, BackupState::FAILED, 0);
        totalVerificationFailures_++;
        logToServer("error", "Checksum verification failed for " + entry.name);
        notifyCrashReporter("backup_manager", "Checksum verification failed for " + entry.name);
        if (backupFailedCb_) backupFailedCb_(entry);
        return BackupResult::CHECKSUM_FAILED;
    }

    entry.verified = true;
    updateProgressState(id, BackupState::COMPLETED, 100);
    logToServer("info", "Verification passed for " + entry.name);

    return BackupResult::SUCCESS;
}

BackupResult BackupManager::setChecksum(uint64_t id, const std::string& checksum) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;
    backups_[idx].checksum = checksum;
    return BackupResult::SUCCESS;
}

// ============================================================
// Restore
// ============================================================

RestorePlan BackupManager::planRestore(uint64_t id, RestoreMode mode,
                                       const std::vector<std::string>& restorePaths,
                                       const std::vector<std::string>& restoreApps) const {
    RestorePlan plan;
    plan.backupId = id;
    plan.mode = mode;
    plan.restorePaths = restorePaths;
    plan.restoreApps = restoreApps;
    plan.overwriteExisting = (mode == RestoreMode::FULL);

    int idx = findBackupIndex(id);
    if (idx < 0) {
        plan.planSummary = "Backup not found";
        return plan;
    }

    const BackupEntry& entry = backups_[idx];

    if (restorePaths.empty()) {
        plan.restorePaths = entry.includedPaths;
    }
    if (restoreApps.empty()) {
        plan.restoreApps = entry.includedApps;
    }

    plan.estimatedSize = entry.sizeBytes;
    plan.estimatedTime = entry.sizeBytes / (10 * 1024 * 1024);  // ~10MB/s simulated
    plan.requiresReboot = (entry.type == BackupType::FULL_SYSTEM);

    std::ostringstream ss;
    ss << "Restore plan for '" << entry.name << "' (mode: " << restoreModeToString(mode)
       << ", size: " << entry.sizeBytes << " bytes, items: " << entry.itemCount << ")";
    plan.planSummary = ss.str();

    return plan;
}

BackupResult BackupManager::executeRestore(uint64_t id, RestoreMode mode,
                                           const std::vector<std::string>& restorePaths,
                                           const std::vector<std::string>& restoreApps,
                                           bool overwriteExisting) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    BackupEntry& entry = backups_[idx];
    if (entry.state != BackupState::COMPLETED) {
        return BackupResult::BAD_STATE;
    }

    // Check if backup is verified
    if (!entry.verified) {
        // Auto-verify before restore
        BackupResult verifyResult = verifyBackup(id);
        if (verifyResult != BackupResult::SUCCESS) {
            return BackupResult::VERIFICATION_FAILED;
        }
    }

    if (mode == RestoreMode::DRY_RUN) {
        // Simulate dry run - just plan, don't execute
        updateProgressState(id, BackupState::RESTORING, 0);
        updateProgressState(id, BackupState::RESTORED, 100);
        logToServer("info", "Dry-run restore completed for " + entry.name);
        return BackupResult::SUCCESS;
    }

    updateProgressState(id, BackupState::RESTORING, 0);
    totalRestoresAttempted_++;

    // If failNextRestore is set, simulate failure
    if (failNextRestore_) {
        failNextRestore_ = false;
        entry.state = BackupState::RESTORE_FAILED;
        updateProgressState(id, BackupState::RESTORE_FAILED, 0);
        totalRestoresFailed_++;
        logToServer("error", "Restore failed (simulated): " + entry.name);
        notifyCrashReporter("backup_manager", "Restore failed (simulated): " + entry.name);
        if (restoreFailedCb_) restoreFailedCb_(entry);
        return BackupResult::RESTORE_FAILED;
    }

    // Simulate successful restore
    entry.state = BackupState::RESTORED;
    updateProgressState(id, BackupState::RESTORED, 100);
    totalRestoresSucceeded_++;
    totalBytesRestored_ += entry.sizeBytes;
    logToServer("info", "Restore completed for " + entry.name);

    if (restoreCompleteCb_) restoreCompleteCb_(entry);

    return BackupResult::SUCCESS;
}

BackupResult BackupManager::executeRestoreFromPlan(const RestorePlan& plan) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    return executeRestore(plan.backupId, plan.mode, plan.restorePaths,
                         plan.restoreApps, plan.overwriteExisting);
}

BackupResult BackupManager::cancelRestore(uint64_t id) {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    int idx = findBackupIndex(id);
    if (idx < 0) return BackupResult::NOT_FOUND;

    BackupEntry& entry = backups_[idx];
    if (entry.state != BackupState::RESTORING) {
        return BackupResult::BAD_STATE;
    }

    entry.state = BackupState::RESTORE_FAILED;
    updateProgressState(id, BackupState::RESTORE_FAILED, 0);
    totalRestoresFailed_++;
    totalCancelled_++;
    logToServer("info", "Restore cancelled: " + entry.name);
    notifyCrashReporter("backup_manager", "Restore cancelled: " + entry.name);

    return BackupResult::SUCCESS;
}

// ============================================================
// Retention
// ============================================================

std::vector<BackupEntry> BackupManager::getExpiredBackups() const {
    std::vector<BackupEntry> expired;
    if (retentionPolicy_.maxAgeDays == 0) return expired;

    uint64_t currentTime = getCurrentTimeMs();
    uint64_t maxAgeMs = static_cast<uint64_t>(retentionPolicy_.maxAgeDays) * 24ULL * 3600ULL * 1000ULL;

    // Find latest per type
    std::map<BackupType, uint64_t> latestPerType;
    for (const auto& entry : backups_) {
        auto it = latestPerType.find(entry.type);
        if (it == latestPerType.end() || entry.timestamp > it->second) {
            latestPerType[entry.type] = entry.timestamp;
        }
    }

    for (const auto& entry : backups_) {
        uint64_t age = currentTime - entry.timestamp;
        if (age >= maxAgeMs) {
            // Check if this is the latest for its type
            if (retentionPolicy_.keepLatestPerType) {
                auto it = latestPerType.find(entry.type);
                if (it != latestPerType.end() && entry.timestamp == it->second) {
                    continue;  // Don't expire latest per type
                }
            }
            expired.push_back(entry);
        }
    }

    return expired;
}

uint64_t BackupManager::getExpiredCount() const {
    return getExpiredBackups().size();
}

BackupResult BackupManager::pruneBackups() {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;

    std::vector<BackupEntry> expired = getExpiredBackups();
    for (const auto& entry : expired) {
        moveToHistory(entry.id, BackupState::FAILED);
        totalPruned_++;
    }

    // Remove pruned entries
    std::vector<uint64_t> expiredIds;
    for (const auto& e : expired) {
        expiredIds.push_back(e.id);
    }

    backups_.erase(
        std::remove_if(backups_.begin(), backups_.end(),
            [&expiredIds](const BackupEntry& e) {
                return std::find(expiredIds.begin(), expiredIds.end(), e.id) != expiredIds.end();
            }),
        backups_.end());

    // Also prune if exceeding max backups
    pruneIfNeeded();

    logToServer("info", "Pruned " + std::to_string(expired.size()) + " expired backups");
    return BackupResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<BackupEntry> BackupManager::getHistory() const {
    return history_;
}

BackupResult BackupManager::clearHistory() {
    if (!initialized_) return BackupResult::NOT_INITIALIZED;
    history_.clear();
    return BackupResult::SUCCESS;
}

// ============================================================
// Query
// ============================================================

size_t BackupManager::getCountByType(BackupType type) const {
    size_t count = 0;
    for (const auto& entry : backups_) {
        if (entry.type == type) ++count;
    }
    return count;
}

size_t BackupManager::getCountByDestination(BackupDestination dest) const {
    size_t count = 0;
    for (const auto& entry : backups_) {
        if (entry.destination == dest) ++count;
    }
    return count;
}

size_t BackupManager::getCountByState(BackupState state) const {
    size_t count = 0;
    for (const auto& entry : backups_) {
        if (entry.state == state) ++count;
    }
    return count;
}

// ============================================================
// Stats
// ============================================================

BackupStats BackupManager::getStats() const {
    BackupStats stats;
    stats.totalBackupsCreated = totalBackupsCreated_;
    stats.totalBackupsCompleted = totalBackupsCompleted_;
    stats.totalBackupsFailed = totalBackupsFailed_;
    stats.totalBackupsCancelled = totalBackupsCancelled_;
    stats.totalRestoresAttempted = totalRestoresAttempted_;
    stats.totalRestoresSucceeded = totalRestoresSucceeded_;
    stats.totalRestoresFailed = totalRestoresFailed_;
    stats.totalBytesBackedUp = totalBytesBackedUp_;
    stats.totalBytesRestored = totalBytesRestored_;
    stats.activeBackups = getActiveBackups().size();
    stats.totalVerifications = totalVerifications_;
    stats.totalVerificationFailures = totalVerificationFailures_;
    stats.totalPruned = totalPruned_;
    stats.totalCancelled = totalCancelled_;

    memcpy(stats.totalByType, totalByType_, sizeof(totalByType_));
    memcpy(stats.totalByDestination, totalByDestination_, sizeof(totalByDestination_));

    return stats;
}

void BackupManager::resetStats() {
    totalBackupsCreated_ = 0;
    totalBackupsCompleted_ = 0;
    totalBackupsFailed_ = 0;
    totalBackupsCancelled_ = 0;
    totalRestoresAttempted_ = 0;
    totalRestoresSucceeded_ = 0;
    totalRestoresFailed_ = 0;
    totalBytesBackedUp_ = 0;
    totalBytesRestored_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalByDestination_, 0, sizeof(totalByDestination_));
    totalVerifications_ = 0;
    totalVerificationFailures_ = 0;
    totalPruned_ = 0;
    totalCancelled_ = 0;
}

// ============================================================
// String helpers
// ============================================================

const char* BackupManager::backupTypeToString(BackupType type) {
    switch (type) {
        case BackupType::FULL_SYSTEM: return "FULL_SYSTEM";
        case BackupType::APP_DATA: return "APP_DATA";
        case BackupType::SETTINGS: return "SETTINGS";
        case BackupType::MEDIA: return "MEDIA";
        case BackupType::CONFIG: return "CONFIG";
        case BackupType::SECURITY_KEYS: return "SECURITY_KEYS";
    }
    return "UNKNOWN";
}

const char* BackupManager::backupStateToString(BackupState state) {
    switch (state) {
        case BackupState::IDLE: return "IDLE";
        case BackupState::SCANNING: return "SCANNING";
        case BackupState::BACKING_UP: return "BACKING_UP";
        case BackupState::VERIFYING: return "VERIFYING";
        case BackupState::COMPLETED: return "COMPLETED";
        case BackupState::FAILED: return "FAILED";
        case BackupState::CANCELLED: return "CANCELLED";
        case BackupState::RESTORING: return "RESTORING";
        case BackupState::RESTORED: return "RESTORED";
        case BackupState::RESTORE_FAILED: return "RESTORE_FAILED";
    }
    return "UNKNOWN";
}

const char* BackupManager::backupDestinationToString(BackupDestination dest) {
    switch (dest) {
        case BackupDestination::LOCAL: return "LOCAL";
        case BackupDestination::EXTERNAL: return "EXTERNAL";
        case BackupDestination::ENCRYPTED_ARCHIVE: return "ENCRYPTED_ARCHIVE";
        case BackupDestination::CLOUD_STUB: return "CLOUD_STUB";
    }
    return "UNKNOWN";
}

const char* BackupManager::backupPrivacyToString(BackupPrivacy privacy) {
    switch (privacy) {
        case BackupPrivacy::FULL: return "FULL";
        case BackupPrivacy::ANONYMIZED: return "ANONYMIZED";
        case BackupPrivacy::MINIMAL: return "MINIMAL";
        case BackupPrivacy::DISABLED: return "DISABLED";
    }
    return "UNKNOWN";
}

const char* BackupManager::restoreModeToString(RestoreMode mode) {
    switch (mode) {
        case RestoreMode::FULL: return "FULL";
        case RestoreMode::SELECTIVE: return "SELECTIVE";
        case RestoreMode::MERGE: return "MERGE";
        case RestoreMode::DRY_RUN: return "DRY_RUN";
    }
    return "UNKNOWN";
}

const char* BackupManager::backupResultToString(BackupResult result) {
    switch (result) {
        case BackupResult::SUCCESS: return "SUCCESS";
        case BackupResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case BackupResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case BackupResult::INVALID_BACKUP: return "INVALID_BACKUP";
        case BackupResult::NOT_FOUND: return "NOT_FOUND";
        case BackupResult::BAD_STATE: return "BAD_STATE";
        case BackupResult::CHECKSUM_FAILED: return "CHECKSUM_FAILED";
        case BackupResult::VERIFICATION_FAILED: return "VERIFICATION_FAILED";
        case BackupResult::BACKUP_FAILED: return "BACKUP_FAILED";
        case BackupResult::RESTORE_FAILED: return "RESTORE_FAILED";
        case BackupResult::POLICY_BLOCKED: return "POLICY_BLOCKED";
        case BackupResult::QUOTA_EXCEEDED: return "QUOTA_EXCEEDED";
        case BackupResult::ALREADY_EXISTS: return "ALREADY_EXISTS";
        case BackupResult::CANCELLED: return "CANCELLED";
        case BackupResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case BackupResult::ENCRYPTION_REQUIRED: return "ENCRYPTION_REQUIRED";
        case BackupResult::RETENTION_EXCEEDED: return "RETENTION_EXCEEDED";
        case BackupResult::IN_PROGRESS: return "IN_PROGRESS";
        case BackupResult::NO_BACKUP_AVAILABLE: return "NO_BACKUP_AVAILABLE";
    }
    return "UNKNOWN";
}

BackupType BackupManager::stringToBackupType(const std::string& str) {
    if (str == "FULL_SYSTEM") return BackupType::FULL_SYSTEM;
    if (str == "APP_DATA") return BackupType::APP_DATA;
    if (str == "SETTINGS") return BackupType::SETTINGS;
    if (str == "MEDIA") return BackupType::MEDIA;
    if (str == "CONFIG") return BackupType::CONFIG;
    if (str == "SECURITY_KEYS") return BackupType::SECURITY_KEYS;
    return BackupType::FULL_SYSTEM;
}

BackupDestination BackupManager::stringToBackupDestination(const std::string& str) {
    if (str == "LOCAL") return BackupDestination::LOCAL;
    if (str == "EXTERNAL") return BackupDestination::EXTERNAL;
    if (str == "ENCRYPTED_ARCHIVE") return BackupDestination::ENCRYPTED_ARCHIVE;
    if (str == "CLOUD_STUB") return BackupDestination::CLOUD_STUB;
    return BackupDestination::LOCAL;
}

BackupPrivacy BackupManager::stringToBackupPrivacy(const std::string& str) {
    if (str == "FULL") return BackupPrivacy::FULL;
    if (str == "ANONYMIZED") return BackupPrivacy::ANONYMIZED;
    if (str == "MINIMAL") return BackupPrivacy::MINIMAL;
    if (str == "DISABLED") return BackupPrivacy::DISABLED;
    return BackupPrivacy::ANONYMIZED;
}

RestoreMode BackupManager::stringToRestoreMode(const std::string& str) {
    if (str == "FULL") return RestoreMode::FULL;
    if (str == "SELECTIVE") return RestoreMode::SELECTIVE;
    if (str == "MERGE") return RestoreMode::MERGE;
    if (str == "DRY_RUN") return RestoreMode::DRY_RUN;
    return RestoreMode::FULL;
}

}  // namespace phantom::backup
