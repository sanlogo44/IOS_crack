/*
 * Phantom OS - Backup & Restore Manager
 * System-wide backup creation, verification, restore, and retention management
 *
 * v0.21.0
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::backup {

// ============================================================
// Enums
// ============================================================

enum class BackupType {
    FULL_SYSTEM,     // Complete system backup
    APP_DATA,        // Application data backup
    SETTINGS,        // Settings and configuration backup
    MEDIA,           // Media files backup
    CONFIG,          // System configuration backup
    SECURITY_KEYS    // Security keys backup (policy-restricted)
};

enum class BackupState {
    IDLE,            // No activity
    SCANNING,        // Scanning for data to back up
    BACKING_UP,      // Backup in progress
    VERIFYING,       // Verifying backup integrity
    COMPLETED,       // Backup completed successfully
    FAILED,          // Backup failed
    CANCELLED,       // Backup cancelled by user
    RESTORING,       // Restore in progress
    RESTORED,        // Restore completed successfully
    RESTORE_FAILED   // Restore failed
};

enum class BackupDestination {
    LOCAL,            // Local storage (device)
    EXTERNAL,         // External storage (USB/SD)
    ENCRYPTED_ARCHIVE,// Encrypted archive file
    CLOUD_STUB        // Cloud backup (simulated stub)
};

enum class BackupPrivacy {
    FULL,             // No scrubbing
    ANONYMIZED,       // Scrub PII from backup metadata
    MINIMAL,          // Strip PII-heavy fields
    DISABLED          // Backup disabled for this type
};

enum class RestoreMode {
    FULL,             // Full restore (overwrite everything)
    SELECTIVE,        // Selective restore (specific items only)
    MERGE,            // Merge with existing data
    DRY_RUN           // Simulate restore without changes
};

enum class BackupResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_BACKUP,
    NOT_FOUND,
    BAD_STATE,
    CHECKSUM_FAILED,
    VERIFICATION_FAILED,
    BACKUP_FAILED,
    RESTORE_FAILED,
    POLICY_BLOCKED,
    QUOTA_EXCEEDED,
    ALREADY_EXISTS,
    CANCELLED,
    INVALID_PARAMETER,
    ENCRYPTION_REQUIRED,
    RETENTION_EXCEEDED,
    IN_PROGRESS,
    NO_BACKUP_AVAILABLE
};

// ============================================================
// Structs
// ============================================================

struct BackupEntry {
    uint64_t id = 0;
    std::string name;
    std::string description;
    BackupType type = BackupType::FULL_SYSTEM;
    BackupDestination destination = BackupDestination::LOCAL;
    BackupState state = BackupState::IDLE;
    uint64_t sizeBytes = 0;          // Backup size in bytes
    uint64_t itemCount = 0;          // Number of items backed up
    uint64_t timestamp = 0;          // Creation timestamp (ms)
    uint64_t completionTime = 0;     // Completion timestamp (ms)
    std::string checksum;           // FNV-1a-based checksum
    std::string encryptionKey;      // Encryption key reference (simulated)
    bool encrypted = false;
    bool verified = false;
    bool incremental = false;       // Is this an incremental backup?
    uint64_t baseBackupId = 0;      // Base backup ID for incremental
    std::string sourcePath;         // Source path backed up
    std::vector<std::string> includedPaths;
    std::vector<std::string> excludedPaths;
    std::vector<std::string> includedApps;
    std::string version;            // OS version at backup time
    std::string deviceId;           // Device identifier (anonymized)
};

struct BackupProgress {
    uint64_t backupId = 0;
    BackupState state = BackupState::IDLE;
    uint32_t progressPercent = 0;   // 0-100
    uint64_t processedBytes = 0;
    uint64_t totalBytes = 0;
    uint64_t processedItems = 0;
    uint64_t totalItems = 0;
    uint32_t speedBps = 0;         // Bytes/sec (simulated)
    uint64_t etaSeconds = 0;        // Estimated time remaining
    std::string errorMessage;
    uint64_t lastUpdated = 0;
};

struct RestorePlan {
    uint64_t backupId = 0;
    RestoreMode mode = RestoreMode::FULL;
    std::vector<std::string> restorePaths;
    std::vector<std::string> restoreApps;
    bool overwriteExisting = false;
    bool requiresReboot = false;
    uint64_t estimatedSize = 0;
    uint64_t estimatedTime = 0;
    std::string planSummary;
};

struct RetentionPolicy {
    uint32_t maxBackups = 10;         // Max backups to keep
    uint32_t maxAgeDays = 90;        // Max age in days
    bool autoPrune = true;           // Auto-delete old backups
    bool keepLatestPerType = true;  // Always keep latest per type
    uint32_t minBackupsPerType = 1;  // Min backups to keep per type
};

struct BackupSchedule {
    bool autoBackupEnabled = false;
    uint32_t intervalHours = 24;     // Hours between auto-backups
    uint64_t lastBackupTime = 0;     // Last backup timestamp (ms)
    uint64_t nextBackupTime = 0;     // Next scheduled backup (ms)
    BackupType scheduledType = BackupType::FULL_SYSTEM;
    BackupDestination scheduledDestination = BackupDestination::LOCAL;
};

struct BackupStats {
    uint64_t totalBackupsCreated = 0;
    uint64_t totalBackupsCompleted = 0;
    uint64_t totalBackupsFailed = 0;
    uint64_t totalBackupsCancelled = 0;
    uint64_t totalRestoresAttempted = 0;
    uint64_t totalRestoresSucceeded = 0;
    uint64_t totalRestoresFailed = 0;
    uint64_t totalBytesBackedUp = 0;
    uint64_t totalBytesRestored = 0;
    uint64_t totalByType[6] = {};        // One per BackupType
    uint64_t totalByDestination[4] = {}; // One per BackupDestination
    uint64_t activeBackups = 0;
    uint64_t totalVerifications = 0;
    uint64_t totalVerificationFailures = 0;
    uint64_t totalPruned = 0;
    uint64_t totalCancelled = 0;
};

// ============================================================
// BackupManager - Central backup & restore management service
// ============================================================

class BackupManager {
public:
    BackupManager() = default;
    ~BackupManager() { shutdown(); }

    // Lifecycle
    BackupResult initialize(size_t maxBackups = 50, size_t maxHistorySize = 200);
    BackupResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxBackups(size_t max) { maxBackups_ = max; }
    size_t getMaxBackups() const { return maxBackups_; }
    void setMaxHistorySize(size_t max) { maxHistorySize_ = max; }
    size_t getMaxHistorySize() const { return maxHistorySize_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Policy
    void setRetentionPolicy(const RetentionPolicy& policy) { retentionPolicy_ = policy; }
    RetentionPolicy getRetentionPolicy() const { return retentionPolicy_; }
    void setBackupPrivacy(BackupPrivacy privacy) { backupPrivacy_ = privacy; }
    BackupPrivacy getBackupPrivacy() const { return backupPrivacy_; }
    void setRequireEncryption(bool required) { requireEncryption_ = required; }
    bool isRequireEncryption() const { return requireEncryption_; }

    // Test hook: force next createBackup to fail (prototype simulation)
    void setFailNextBackup(bool fail) { failNextBackup_ = fail; }
    bool getFailNextBackup() const { return failNextBackup_; }
    void setFailNextRestore(bool fail) { failNextRestore_ = fail; }
    bool getFailNextRestore() const { return failNextRestore_; }

    // Schedule
    void setSchedule(const BackupSchedule& schedule) { schedule_ = schedule; }
    BackupSchedule getSchedule() const { return schedule_; }
    bool shouldAutoBackup(uint64_t currentTimeMs = 0) const;

    // Backup management
    BackupResult createBackup(const BackupEntry& entry);
    BackupResult cancelBackup(uint64_t id);
    std::vector<BackupEntry> getBackups() const;
    std::vector<BackupEntry> getBackupsByType(BackupType type) const;
    std::vector<BackupEntry> getBackupsByDestination(BackupDestination dest) const;
    std::vector<BackupEntry> getBackupsByState(BackupState state) const;
    BackupEntry getBackupById(uint64_t id) const;
    size_t getBackupCount() const { return backups_.size(); }
    BackupResult deleteBackup(uint64_t id);
    BackupResult deleteAllBackups();

    // Incremental backup
    BackupResult createIncrementalBackup(uint64_t baseBackupId, const BackupEntry& entry);

    // Progress
    BackupProgress getBackupProgress(uint64_t id) const;
    std::vector<BackupProgress> getActiveBackups() const;
    BackupResult updateBackupProgress(uint64_t id, uint64_t processedBytes, uint64_t processedItems, uint32_t speedBps = 0);

    // Verification
    BackupResult verifyBackup(uint64_t id);
    std::string computeChecksum(const std::string& data) const;
    bool verifyChecksum(const std::string& data, const std::string& expected) const;
    BackupResult setChecksum(uint64_t id, const std::string& checksum);

    // Restore
    RestorePlan planRestore(uint64_t id, RestoreMode mode = RestoreMode::FULL,
                           const std::vector<std::string>& restorePaths = {},
                           const std::vector<std::string>& restoreApps = {}) const;
    BackupResult executeRestore(uint64_t id, RestoreMode mode = RestoreMode::FULL,
                               const std::vector<std::string>& restorePaths = {},
                               const std::vector<std::string>& restoreApps = {},
                               bool overwriteExisting = false);
    BackupResult executeRestoreFromPlan(const RestorePlan& plan);
    BackupResult cancelRestore(uint64_t id);

    // Retention
    BackupResult pruneBackups();
    std::vector<BackupEntry> getExpiredBackups() const;
    uint64_t getExpiredCount() const;

    // History
    std::vector<BackupEntry> getHistory() const;
    BackupResult clearHistory();

    // Query
    size_t getCountByType(BackupType type) const;
    size_t getCountByDestination(BackupDestination dest) const;
    size_t getCountByState(BackupState state) const;

    // Callbacks
    using BackupCallback = std::function<void(const BackupEntry&)>;
    using ProgressCallback = std::function<void(const BackupProgress&)>;
    using RestoreCallback = std::function<void(const BackupEntry&)>;
    void setBackupCompleteCallback(BackupCallback cb) { backupCompleteCb_ = cb; }
    void setBackupFailedCallback(BackupCallback cb) { backupFailedCb_ = cb; }
    void setProgressCallback(ProgressCallback cb) { progressCb_ = cb; }
    void setRestoreCompleteCallback(RestoreCallback cb) { restoreCompleteCb_ = cb; }
    void setRestoreFailedCallback(RestoreCallback cb) { restoreFailedCb_ = cb; }

    // Stats
    BackupStats getStats() const;
    void resetStats();

    // String helpers
    static const char* backupTypeToString(BackupType type);
    static const char* backupStateToString(BackupState state);
    static const char* backupDestinationToString(BackupDestination dest);
    static const char* backupPrivacyToString(BackupPrivacy privacy);
    static const char* restoreModeToString(RestoreMode mode);
    static const char* backupResultToString(BackupResult result);
    static BackupType stringToBackupType(const std::string& str);
    static BackupDestination stringToBackupDestination(const std::string& str);
    static BackupPrivacy stringToBackupPrivacy(const std::string& str);
    static RestoreMode stringToRestoreMode(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxBackups_ = 50;
    size_t maxHistorySize_ = 200;
    uint64_t nextId_ = 1;

    std::vector<BackupEntry> backups_;
    std::map<uint64_t, BackupProgress> progress_;
    std::vector<BackupEntry> history_;

    RetentionPolicy retentionPolicy_;
    BackupPrivacy backupPrivacy_ = BackupPrivacy::ANONYMIZED;
    bool requireEncryption_ = false;
    bool failNextBackup_ = false;
    bool failNextRestore_ = false;

    BackupSchedule schedule_;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    // Callbacks
    BackupCallback backupCompleteCb_;
    BackupCallback backupFailedCb_;
    ProgressCallback progressCb_;
    RestoreCallback restoreCompleteCb_;
    RestoreCallback restoreFailedCb_;

    // Stats
    uint64_t totalBackupsCreated_ = 0;
    uint64_t totalBackupsCompleted_ = 0;
    uint64_t totalBackupsFailed_ = 0;
    uint64_t totalBackupsCancelled_ = 0;
    uint64_t totalRestoresAttempted_ = 0;
    uint64_t totalRestoresSucceeded_ = 0;
    uint64_t totalRestoresFailed_ = 0;
    uint64_t totalBytesBackedUp_ = 0;
    uint64_t totalBytesRestored_ = 0;
    uint64_t totalByType_[6] = {};
    uint64_t totalByDestination_[4] = {};
    uint64_t totalVerifications_ = 0;
    uint64_t totalVerificationFailures_ = 0;
    uint64_t totalPruned_ = 0;
    uint64_t totalCancelled_ = 0;

    // Helpers
    uint64_t getCurrentTimeMs() const;
    int findBackupIndex(uint64_t id) const;
    bool isBackupActive(BackupState state) const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    void moveToHistory(uint64_t id, BackupState finalState);
    void updateProgressState(uint64_t id, BackupState state, uint32_t percent);
    void applyPrivacyScrubbing(BackupEntry& entry) const;
    void pruneIfNeeded();
};

}  // namespace phantom::backup
