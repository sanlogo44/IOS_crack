/*
 * Phantom OS - NFC Manager Implementation
 * v0.35.0 - License: GPL-3.0
 *
 * Implementation of the privacy-first NFC service.
 * All data is simulated in-memory. Privacy transforms are deterministic.
 */

#include "phantom/nfc/nfc_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <sstream>
#include <iomanip>

namespace phantom {
namespace nfc {

// ============================================================
// FNV-1a hash (deterministic, same as other Phantom OS components)
// ============================================================

static uint32_t fnv1a(const std::string& str) {
    uint32_t hash = 2166136261u;
    for (char c : str) {
        hash ^= static_cast<uint32_t>(static_cast<unsigned char>(c));
        hash *= 16777619u;
    }
    return hash;
}

static std::string toHex(uint32_t value, int width) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0') << std::setw(width) << value;
    return oss.str();
}

// ============================================================
// Lifecycle
// ============================================================

NfcResult NfcManager::initialize(size_t maxTags, size_t maxHistory, size_t maxEvents) {
    if (initialized_) return NfcResult::ALREADY_INITIALIZED;
    if (maxTags == 0 || maxHistory == 0 || maxEvents == 0)
        return NfcResult::INVALID_PARAMETER;

    maxTags_ = maxTags;
    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;

    initialized_ = true;
    adapterState_ = NfcAdapterState::OFF;
    discoveryMode_ = NfcDiscoveryMode::IDLE;
    mockEnabled_ = false;

    tags_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeNfcUsers_.clear();

    createStubTags();

    stats_ = NfcStats{};

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::shutdown() {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;

    tags_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    activeNfcUsers_.clear();

    adapterState_ = NfcAdapterState::OFF;
    discoveryMode_ = NfcDiscoveryMode::IDLE;
    mockEnabled_ = false;
    initialized_ = false;

    return NfcResult::SUCCESS;
}

// ============================================================
// Adapter state
// ============================================================

NfcResult NfcManager::enableAdapter(const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;
    if (adapterState_ == NfcAdapterState::ON) return NfcResult::BAD_STATE;

    adapterState_ = NfcAdapterState::ON;
    stats_.adapterOnCount++;
    recordEvent(NfcEventType::ADAPTER_STATE_CHANGED, NfcResult::SUCCESS,
                owner, "Adapter ON");
    logToServer("INFO", "NFC adapter enabled");

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::disableAdapter(const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;
    if (adapterState_ == NfcAdapterState::OFF) return NfcResult::BAD_STATE;

    adapterState_ = NfcAdapterState::OFF;
    discoveryMode_ = NfcDiscoveryMode::IDLE;
    for (auto& tag : tags_) tag.connected = false;
    activeNfcUsers_.clear();
    updatePrivacyIndicator();

    stats_.adapterOffCount++;
    recordEvent(NfcEventType::ADAPTER_STATE_CHANGED, NfcResult::SUCCESS,
                owner, "Adapter OFF");
    logToServer("INFO", "NFC adapter disabled");

    return NfcResult::SUCCESS;
}

// ============================================================
// Discovery
// ============================================================

NfcResult NfcManager::startDiscovery(NfcDiscoveryMode mode, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (adapterState_ != NfcAdapterState::ON) return NfcResult::ADAPTER_OFF;
    if (mode == NfcDiscoveryMode::IDLE) return NfcResult::INVALID_PARAMETER;
    if (discoveryMode_ != NfcDiscoveryMode::IDLE) return NfcResult::DISCOVERY_ACTIVE;

    if (!checkAppAccess(owner) && !isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    discoveryMode_ = mode;
    stats_.discoveryCount++;
    recordEvent(NfcEventType::DISCOVERY_STARTED, NfcResult::SUCCESS,
                owner, std::string("Mode: ") + discoveryModeToString(mode));

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::stopDiscovery(const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (discoveryMode_ == NfcDiscoveryMode::IDLE) return NfcResult::NO_DISCOVERY;

    discoveryMode_ = NfcDiscoveryMode::IDLE;
    recordEvent(NfcEventType::DISCOVERY_STOPPED, NfcResult::SUCCESS,
                owner, "Discovery stopped");

    return NfcResult::SUCCESS;
}

// ============================================================
// Tag management
// ============================================================

NfcResult NfcManager::findTag(const std::string& tagId, NfcTag*& outTag) {
    for (auto& tag : tags_) {
        if (tag.tagId == tagId) { outTag = &tag; return NfcResult::SUCCESS; }
    }
    outTag = nullptr;
    return NfcResult::TAG_NOT_FOUND;
}

NfcResult NfcManager::findTagConst(const std::string& tagId, const NfcTag*& outTag) const {
    for (const auto& tag : tags_) {
        if (tag.tagId == tagId) { outTag = &tag; return NfcResult::SUCCESS; }
    }
    outTag = nullptr;
    return NfcResult::TAG_NOT_FOUND;
}

NfcResult NfcManager::connectTag(const std::string& tagId, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (adapterState_ != NfcAdapterState::ON) return NfcResult::ADAPTER_OFF;

    NfcTag* tag = nullptr;
    NfcResult found = findTag(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;

    tag->connected = true;
    tag->discoveredAt = getCurrentTimeMs();

    stats_.tagsDiscovered++;
    recordEvent(NfcEventType::TAG_DISCOVERED, NfcResult::SUCCESS, owner,
                "Tag connected: " + redactTagId(tagId));

    if (std::find(activeNfcUsers_.begin(), activeNfcUsers_.end(), owner) == activeNfcUsers_.end()) {
        activeNfcUsers_.push_back(owner);
        updatePrivacyIndicator();
    }
    lastAccessTime_ = getCurrentTimeMs();

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::disconnectTag(const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }

    bool anyConnected = false;
    for (auto& tag : tags_) {
        if (tag.connected) {
            tag.connected = false;
            anyConnected = true;
            recordEvent(NfcEventType::TAG_REMOVED, NfcResult::SUCCESS, owner,
                        "Tag disconnected: " + redactTagId(tag.tagId));
        }
    }
    if (!anyConnected) return NfcResult::TAG_NOT_FOUND;

    stats_.tagsRemoved++;

    auto it = std::find(activeNfcUsers_.begin(), activeNfcUsers_.end(), owner);
    if (it != activeNfcUsers_.end()) {
        activeNfcUsers_.erase(it);
        updatePrivacyIndicator();
    }

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::getTag(const std::string& tagId, NfcTag& outTag) const {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    const NfcTag* tag = nullptr;
    NfcResult found = findTagConst(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;
    outTag = *tag;
    return NfcResult::SUCCESS;
}

std::vector<NfcTag> NfcManager::getAllTags() const {
    return tags_;
}

std::vector<NfcTag> NfcManager::getConnectedTags() const {
    std::vector<NfcTag> result;
    for (const auto& tag : tags_) {
        if (tag.connected) result.push_back(tag);
    }
    return result;
}

NfcResult NfcManager::removeTag(const std::string& tagId, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    auto it = std::find_if(tags_.begin(), tags_.end(),
        [&tagId](const NfcTag& t) { return t.tagId == tagId; });
    if (it == tags_.end()) return NfcResult::TAG_NOT_FOUND;

    tags_.erase(it);
    stats_.tagsRemoved++;
    recordEvent(NfcEventType::TAG_REMOVED, NfcResult::SUCCESS, owner,
                "Tag removed: " + redactTagId(tagId));

    return NfcResult::SUCCESS;
}

// ============================================================
// NDEF
// ============================================================

NfcResult NfcManager::readNdef(const std::string& tagId, std::vector<uint8_t>& outData,
                                 const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (adapterState_ != NfcAdapterState::ON) return NfcResult::ADAPTER_OFF;
    if (!checkAppAccess(owner) && !isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    NfcTag* tag = nullptr;
    NfcResult found = findTag(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;
    if (!tag->connected) return NfcResult::TAG_IO_ERROR;

    outData = tag->ndefContent;
    stats_.ndefReads++;
    recordEvent(NfcEventType::NDEF_READ, NfcResult::SUCCESS, owner,
                "NDEF read from " + redactTagId(tagId));
    lastAccessTime_ = getCurrentTimeMs();

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::writeNdef(const std::string& tagId, const std::vector<uint8_t>& data,
                                  const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (adapterState_ != NfcAdapterState::ON) return NfcResult::ADAPTER_OFF;
    if (!checkAppAccess(owner) && !isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    NfcTag* tag = nullptr;
    NfcResult found = findTag(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;
    if (!tag->connected) return NfcResult::TAG_IO_ERROR;
    if (tag->readOnly) return NfcResult::NDEF_INVALID;
    if (data.size() > tag->maxSize) return NfcResult::NDEF_INVALID;

    tag->ndefContent = data;
    stats_.ndefWrites++;
    recordEvent(NfcEventType::NDEF_WRITE, NfcResult::SUCCESS, owner,
                "NDEF written to " + redactTagId(tagId));
    lastAccessTime_ = getCurrentTimeMs();

    return NfcResult::SUCCESS;
}

bool NfcManager::isTagReadOnly(const std::string& tagId) const {
    const NfcTag* tag = nullptr;
    if (findTagConst(tagId, tag) != NfcResult::SUCCESS) return true;
    return tag->readOnly;
}

// ============================================================
// Card emulation / HCE
// ============================================================

NfcResult NfcManager::registerAidRoute(const std::string& appId, const std::string& aid,
                                          const std::string& description,
                                          const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner) && owner != appId) return NfcResult::PERMISSION_DENIED;
    if (aid.empty()) return NfcResult::INVALID_PARAMETER;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return NfcResult::PERMISSION_DENIED;
    if (!it->second.allowCardEmulation) return NfcResult::PERMISSION_DENIED;

    // Check for AID conflict with another app
    for (const auto& [otherApp, policy] : appPolicies_) {
        if (otherApp == appId) continue;
        for (const auto& route : policy.aidRoutes) {
            if (route.aid == aid) return NfcResult::AID_CONFLICT;
        }
    }

    // Check for duplicate within same app
    for (const auto& route : it->second.aidRoutes) {
        if (route.aid == aid) return NfcResult::AID_CONFLICT;
    }

    AidRoute route;
    route.appId = appId;
    route.aid = aid;
    route.description = description;
    route.active = false;

    it->second.aidRoutes.push_back(route);

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::unregisterAidRoute(const std::string& appId, const std::string& aid,
                                           const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner) && owner != appId) return NfcResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return NfcResult::INVALID_PARAMETER;

    auto& routes = it->second.aidRoutes;
    auto routeIt = std::remove_if(routes.begin(), routes.end(),
        [&aid](const AidRoute& r) { return r.aid == aid; });
    if (routeIt == routes.end()) return NfcResult::INVALID_PARAMETER;

    routes.erase(routeIt, routes.end());
    return NfcResult::SUCCESS;
}

std::vector<AidRoute> NfcManager::getAidRoutes() const {
    std::vector<AidRoute> result;
    for (const auto& [appId, policy] : appPolicies_) {
        for (const auto& route : policy.aidRoutes) {
            result.push_back(route);
        }
    }
    return result;
}

std::vector<AidRoute> NfcManager::getAidRoutesForApp(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return {};
    return it->second.aidRoutes;
}

NfcResult NfcManager::setCardEmulationActive(const std::string& appId, bool active,
                                                const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return NfcResult::SIMULATED_FAILURE; }
    if (adapterState_ != NfcAdapterState::ON) return NfcResult::ADAPTER_OFF;
    if (!isSystemOwner(owner) && owner != appId) return NfcResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return NfcResult::PERMISSION_DENIED;
    if (!it->second.allowCardEmulation) return NfcResult::PERMISSION_DENIED;
    if (it->second.aidRoutes.empty()) return NfcResult::BAD_STATE;

    for (auto& route : it->second.aidRoutes) {
        route.active = active;
    }

    if (active) {
        stats_.cardEmulationActivations++;
        recordEvent(NfcEventType::CARD_EMULATION_ACTIVATED, NfcResult::SUCCESS,
                    appId, "Card emulation activated");
    } else {
        stats_.cardEmulationDeactivations++;
        recordEvent(NfcEventType::CARD_EMULATION_DEACTIVATED, NfcResult::SUCCESS,
                    appId, "Card emulation deactivated");
    }

    return NfcResult::SUCCESS;
}

bool NfcManager::isCardEmulationActive() const {
    for (const auto& [appId, policy] : appPolicies_) {
        for (const auto& route : policy.aidRoutes) {
            if (route.active) return true;
        }
    }
    return false;
}

// ============================================================
// Permission / policy
// ============================================================

NfcResult NfcManager::setAppNfcPolicy(const std::string& appId,
                                        NfcPermission permission,
                                        NfcPrivacyMode privacyMode,
                                        uint32_t privacyFlags,
                                        bool allowReader,
                                        bool allowWriter,
                                        bool allowP2P,
                                        bool allowCardEmulation,
                                        const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;
    if (appId.empty()) return NfcResult::INVALID_PARAMETER;

    NfcPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.allowReaderMode = allowReader;
    policy.allowWriterMode = allowWriter;
    policy.allowP2P = allowP2P;
    policy.allowCardEmulation = allowCardEmulation;
    policy.lastGrantedAt = (permission != NfcPermission::DENY) ? getCurrentTimeMs() : 0;
    policy.oneShotUsed = false;
    policy.foreground = false;

    // Preserve AID routes if updating existing policy
    auto existing = appPolicies_.find(appId);
    if (existing != appPolicies_.end()) {
        policy.aidRoutes = existing->second.aidRoutes;
    }

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(NfcEventType::PERMISSION_CHANGED, NfcResult::SUCCESS,
                owner, "Policy set for " + appId);

    return NfcResult::SUCCESS;
}

NfcPolicy NfcManager::getAppNfcPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return NfcPolicy{};
}

NfcResult NfcManager::clearAppNfcPolicy(const std::string& appId,
                                          const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return NfcResult::INVALID_PARAMETER;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    auto uit = std::find(activeNfcUsers_.begin(), activeNfcUsers_.end(), appId);
    if (uit != activeNfcUsers_.end()) {
        activeNfcUsers_.erase(uit);
        updatePrivacyIndicator();
    }

    return NfcResult::SUCCESS;
}

bool NfcManager::checkAppAccess(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    switch (policy.permission) {
        case NfcPermission::DENY:
            return false;
        case NfcPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case NfcPermission::ALLOW_ALWAYS:
            return true;
        case NfcPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

NfcResult NfcManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return NfcResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return NfcResult::SUCCESS;
}

// ============================================================
// Identifier access
// ============================================================

NfcResult NfcManager::getTagId(const std::string& appId, const std::string& tagId,
                                  std::string& outId) const {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return NfcResult::PERMISSION_DENIED;

    const NfcTag* tag = nullptr;
    NfcResult found = findTagConst(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;

    auto it = appPolicies_.find(appId);
    NfcPrivacyMode mode = NfcPrivacyMode::FULL;
    if (it != appPolicies_.end()) mode = it->second.privacyMode;

    if (isSystemOwner(appId)) {
        outId = tagId;
    } else if (mode == NfcPrivacyMode::FULL) {
        outId = tagId;
    } else if (mode == NfcPrivacyMode::REDACTED) {
        outId = redactTagId(tagId);
    } else {
        outId = "METADATA_ONLY";
    }

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::getTagProtocol(const std::string& appId, const std::string& tagId,
                                        NfcProtocol& outProtocol) const {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return NfcResult::PERMISSION_DENIED;

    const NfcTag* tag = nullptr;
    NfcResult found = findTagConst(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;

    outProtocol = tag->protocol;
    return NfcResult::SUCCESS;
}

NfcResult NfcManager::getTagRssi(const std::string& appId, const std::string& tagId,
                                    int32_t& outRssi) const {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId) && !isSystemOwner(appId)) return NfcResult::PERMISSION_DENIED;

    const NfcTag* tag = nullptr;
    NfcResult found = findTagConst(tagId, tag);
    if (found != NfcResult::SUCCESS) return found;

    auto it = appPolicies_.find(appId);
    NfcPrivacyMode mode = NfcPrivacyMode::FULL;
    if (it != appPolicies_.end()) mode = it->second.privacyMode;

    if (!isSystemOwner(appId) && mode == NfcPrivacyMode::METADATA_ONLY) {
        outRssi = 0;
    } else {
        outRssi = tag->rssi;
    }

    return NfcResult::SUCCESS;
}

// ============================================================
// History
// ============================================================

std::vector<NfcEvent> NfcManager::getHistory(const std::string& appId,
                                                size_t limit) const {
    std::vector<NfcEvent> result;
    for (auto it = history_.rbegin(); it != history_.rend(); ++it) {
        if (it->appId == appId || isSystemOwner(appId)) {
            result.push_back(*it);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

NfcResult NfcManager::clearHistory(const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(NfcEventType::HISTORY_CLEARED, NfcResult::SUCCESS,
                owner, "History cleared");
    return NfcResult::SUCCESS;
}

NfcResult NfcManager::clearAppHistory(const std::string& appId,
                                        const std::string& requester) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(requester) && requester != appId) return NfcResult::PERMISSION_DENIED;

    auto it = std::remove_if(history_.begin(), history_.end(),
        [&appId](const NfcEvent& e) { return e.appId == appId; });
    history_.erase(it, history_.end());

    return NfcResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

NfcResult NfcManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    return NfcResult::SUCCESS;
}

NfcResult NfcManager::setMockTag(const std::string& tagId, NfcProtocol protocol,
                                    NfcTagType type,
                                    const std::vector<uint8_t>& ndefContent,
                                    uint32_t maxSize, bool readOnly,
                                    const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    NfcTag* tag = nullptr;
    NfcResult found = findTag(tagId, tag);
    if (found == NfcResult::SUCCESS) {
        tag->protocol = protocol;
        tag->type = type;
        tag->ndefContent = ndefContent;
        tag->maxSize = maxSize;
        tag->readOnly = readOnly;
    } else {
        if (tags_.size() >= maxTags_) return NfcResult::CAPACITY_EXCEEDED;
        NfcTag newTag;
        newTag.tagId = tagId;
        newTag.protocol = protocol;
        newTag.type = type;
        newTag.ndefContent = ndefContent;
        newTag.maxSize = maxSize;
        newTag.readOnly = readOnly;
        newTag.connected = false;
        newTag.rssi = -50;
        tags_.push_back(newTag);
    }

    stats_.mockTagsSet++;
    recordEvent(NfcEventType::MOCK_TAG_SET, NfcResult::SUCCESS, owner,
                "Mock tag set: " + redactTagId(tagId));

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::addMockTag(const NfcTag& tag, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;
    if (tags_.size() >= maxTags_) return NfcResult::CAPACITY_EXCEEDED;

    for (const auto& existing : tags_) {
        if (existing.tagId == tag.tagId) return NfcResult::INVALID_PARAMETER;
    }

    tags_.push_back(tag);
    stats_.mockTagsSet++;
    recordEvent(NfcEventType::MOCK_TAG_SET, NfcResult::SUCCESS, owner,
                "Mock tag added: " + redactTagId(tag.tagId));

    return NfcResult::SUCCESS;
}

NfcResult NfcManager::removeMockTag(const std::string& tagId, const std::string& owner) {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return NfcResult::PERMISSION_DENIED;

    auto it = std::find_if(tags_.begin(), tags_.end(),
        [&tagId](const NfcTag& t) { return t.tagId == tagId; });
    if (it == tags_.end()) return NfcResult::TAG_NOT_FOUND;

    tags_.erase(it);
    return NfcResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<NfcEvent> NfcManager::getEvents(size_t limit) const {
    if (limit == 0) return events_;
    std::vector<NfcEvent> result;
    for (auto it = events_.rbegin(); it != events_.rend() && result.size() < limit; ++it) {
        result.push_back(*it);
    }
    return result;
}

std::vector<NfcEvent> NfcManager::getEventsByType(NfcEventType type) const {
    std::vector<NfcEvent> result;
    for (const auto& e : events_) {
        if (e.type == type) result.push_back(e);
    }
    return result;
}

NfcResult NfcManager::clearEvents() {
    if (!initialized_) return NfcResult::NOT_INITIALIZED;

    for (const auto& e : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(e);
    }
    events_.clear();
    return NfcResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void NfcManager::resetStats() {
    stats_ = NfcStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* NfcManager::adapterStateToString(NfcAdapterState state) {
    switch (state) {
        case NfcAdapterState::OFF: return "OFF";
        case NfcAdapterState::TURNING_ON: return "TURNING_ON";
        case NfcAdapterState::ON: return "ON";
        case NfcAdapterState::TURNING_OFF: return "TURNING_OFF";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::discoveryModeToString(NfcDiscoveryMode mode) {
    switch (mode) {
        case NfcDiscoveryMode::IDLE: return "IDLE";
        case NfcDiscoveryMode::READER: return "READER";
        case NfcDiscoveryMode::WRITER: return "WRITER";
        case NfcDiscoveryMode::P2P: return "P2P";
        case NfcDiscoveryMode::CARD_EMULATION: return "CARD_EMULATION";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::protocolToString(NfcProtocol protocol) {
    switch (protocol) {
        case NfcProtocol::UNKNOWN: return "UNKNOWN";
        case NfcProtocol::ISO_14443_A: return "ISO_14443_A";
        case NfcProtocol::ISO_14443_B: return "ISO_14443_B";
        case NfcProtocol::ISO_15693: return "ISO_15693";
        case NfcProtocol::MIFARE_CLASSIC: return "MIFARE_CLASSIC";
        case NfcProtocol::MIFARE_ULTRALIGHT: return "MIFARE_ULTRALIGHT";
        case NfcProtocol::FELICA: return "FELICA";
        case NfcProtocol::NFC_BARCODE: return "NFC_BARCODE";
        case NfcProtocol::NDEF: return "NDEF";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::tagTypeToString(NfcTagType type) {
    switch (type) {
        case NfcTagType::UNKNOWN: return "UNKNOWN";
        case NfcTagType::NDEF: return "NDEF";
        case NfcTagType::MIFARE_CLASSIC: return "MIFARE_CLASSIC";
        case NfcTagType::MIFARE_ULTRALIGHT: return "MIFARE_ULTRALIGHT";
        case NfcTagType::FELICA: return "FELICA";
        case NfcTagType::ISO_14443_4: return "ISO_14443_4";
        case NfcTagType::ISO_15693: return "ISO_15693";
        case NfcTagType::NFC_BARCODE: return "NFC_BARCODE";
        case NfcTagType::NDEF_FORMATABLE: return "NDEF_FORMATABLE";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::permissionToString(NfcPermission permission) {
    switch (permission) {
        case NfcPermission::DENY: return "DENY";
        case NfcPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case NfcPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case NfcPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::privacyModeToString(NfcPrivacyMode mode) {
    switch (mode) {
        case NfcPrivacyMode::FULL: return "FULL";
        case NfcPrivacyMode::REDACTED: return "REDACTED";
        case NfcPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::resultToString(NfcResult result) {
    switch (result) {
        case NfcResult::SUCCESS: return "SUCCESS";
        case NfcResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case NfcResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case NfcResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case NfcResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case NfcResult::ADAPTER_OFF: return "ADAPTER_OFF";
        case NfcResult::DISCOVERY_ACTIVE: return "DISCOVERY_ACTIVE";
        case NfcResult::NO_DISCOVERY: return "NO_DISCOVERY";
        case NfcResult::TAG_NOT_FOUND: return "TAG_NOT_FOUND";
        case NfcResult::TAG_IO_ERROR: return "TAG_IO_ERROR";
        case NfcResult::NDEF_INVALID: return "NDEF_INVALID";
        case NfcResult::AID_CONFLICT: return "AID_CONFLICT";
        case NfcResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case NfcResult::BAD_STATE: return "BAD_STATE";
        case NfcResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case NfcResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* NfcManager::eventTypeToString(NfcEventType type) {
    switch (type) {
        case NfcEventType::ADAPTER_STATE_CHANGED: return "ADAPTER_STATE_CHANGED";
        case NfcEventType::DISCOVERY_STARTED: return "DISCOVERY_STARTED";
        case NfcEventType::DISCOVERY_STOPPED: return "DISCOVERY_STOPPED";
        case NfcEventType::TAG_DISCOVERED: return "TAG_DISCOVERED";
        case NfcEventType::TAG_REMOVED: return "TAG_REMOVED";
        case NfcEventType::NDEF_READ: return "NDEF_READ";
        case NfcEventType::NDEF_WRITE: return "NDEF_WRITE";
        case NfcEventType::CARD_EMULATION_ACTIVATED: return "CARD_EMULATION_ACTIVATED";
        case NfcEventType::CARD_EMULATION_DEACTIVATED: return "CARD_EMULATION_DEACTIVATED";
        case NfcEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case NfcEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case NfcEventType::INDICATOR_ON: return "INDICATOR_ON";
        case NfcEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case NfcEventType::MOCK_TAG_SET: return "MOCK_TAG_SET";
        case NfcEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

NfcResult NfcManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return NfcResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return NfcResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return NfcResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return NfcResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return NfcResult::PERMISSION_DENIED;
    if (str == "ADAPTER_OFF") return NfcResult::ADAPTER_OFF;
    if (str == "DISCOVERY_ACTIVE") return NfcResult::DISCOVERY_ACTIVE;
    if (str == "NO_DISCOVERY") return NfcResult::NO_DISCOVERY;
    if (str == "TAG_NOT_FOUND") return NfcResult::TAG_NOT_FOUND;
    if (str == "TAG_IO_ERROR") return NfcResult::TAG_IO_ERROR;
    if (str == "NDEF_INVALID") return NfcResult::NDEF_INVALID;
    if (str == "AID_CONFLICT") return NfcResult::AID_CONFLICT;
    if (str == "CAPACITY_EXCEEDED") return NfcResult::CAPACITY_EXCEEDED;
    if (str == "BAD_STATE") return NfcResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return NfcResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return NfcResult::SIMULATED_FAILURE;
    return NfcResult::OPERATION_FAILED;
}

NfcProtocol NfcManager::stringToProtocol(const std::string& str) {
    if (str == "UNKNOWN") return NfcProtocol::UNKNOWN;
    if (str == "ISO_14443_A") return NfcProtocol::ISO_14443_A;
    if (str == "ISO_14443_B") return NfcProtocol::ISO_14443_B;
    if (str == "ISO_15693") return NfcProtocol::ISO_15693;
    if (str == "MIFARE_CLASSIC") return NfcProtocol::MIFARE_CLASSIC;
    if (str == "MIFARE_ULTRALIGHT") return NfcProtocol::MIFARE_ULTRALIGHT;
    if (str == "FELICA") return NfcProtocol::FELICA;
    if (str == "NFC_BARCODE") return NfcProtocol::NFC_BARCODE;
    if (str == "NDEF") return NfcProtocol::NDEF;
    return NfcProtocol::UNKNOWN;
}

// ============================================================
// Private helpers
// ============================================================

uint64_t NfcManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool NfcManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "system_server";
}

void NfcManager::recordEvent(NfcEventType type, NfcResult result,
                               const std::string& appId,
                               const std::string& detail) {
    NfcEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.detail = detail;

    if (events_.size() >= maxEvents_) {
        events_.erase(events_.begin());
    }
    events_.push_back(event);

    uint8_t typeIdx = static_cast<uint8_t>(type);
    uint8_t resultIdx = static_cast<uint8_t>(result);
    if (typeIdx < 16) stats_.byEventType[typeIdx]++;
    if (resultIdx < 15) stats_.byResult[resultIdx]++;

    if (result != NfcResult::SUCCESS) {
        stats_.totalFailures++;
    }

    if (eventCallback_) eventCallback_(event);
}

void NfcManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "NfcManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "NfcManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "NfcManager");
    }
}

void NfcManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("NfcManager", "NfcManager", 0, reason);
}

void NfcManager::updatePrivacyIndicator() {
    bool wasOn = !activeNfcUsers_.empty();
    bool isOn = !activeNfcUsers_.empty();

    if (wasOn && !isOn) {
        recordEvent(NfcEventType::INDICATOR_OFF, NfcResult::SUCCESS,
                    "system", "Privacy indicator off");
    } else if (!wasOn && isOn) {
        recordEvent(NfcEventType::INDICATOR_ON, NfcResult::SUCCESS,
                    "system", "Privacy indicator on");
    }
}

void NfcManager::createStubTags() {
    NfcTag tag1;
    tag1.tagId = "04:A1:B2:C3:D4:E5:F6";
    tag1.protocol = NfcProtocol::ISO_14443_A;
    tag1.type = NfcTagType::NDEF;
    tag1.ndefContent = {0x03, 0x0A, 0xD1, 0x01, 0x06, 0x55, 0x01,
                         'p', 'h', 'a', 'n', 't', 'o', 'm'};
    tag1.maxSize = 144;
    tag1.readOnly = false;
    tag1.connected = false;
    tag1.rssi = -40;
    tags_.push_back(tag1);

    NfcTag tag2;
    tag2.tagId = "88:04:12:34:56:78:9A";
    tag2.protocol = NfcProtocol::MIFARE_CLASSIC;
    tag2.type = NfcTagType::MIFARE_CLASSIC;
    tag2.ndefContent = {};
    tag2.maxSize = 1024;
    tag2.readOnly = false;
    tag2.connected = false;
    tag2.rssi = -55;
    tags_.push_back(tag2);

    NfcTag tag3;
    tag3.tagId = "01:23:45:67:89:AB:CD";
    tag3.protocol = NfcProtocol::FELICA;
    tag3.type = NfcTagType::FELICA;
    tag3.ndefContent = {};
    tag3.maxSize = 4096;
    tag3.readOnly = true;
    tag3.connected = false;
    tag3.rssi = -48;
    tags_.push_back(tag3);
}

std::string NfcManager::redactTagId(const std::string& tagId) const {
    // Keep first 2 octets, replace rest with XX
    if (tagId.size() < 8) return "XX:XX:XX:XX:XX:XX:XX";
    return tagId.substr(0, 8) + "XX:XX:XX:XX:XX";
}

std::string NfcManager::pseudonymizeTagId(const std::string& tagId) const {
    uint32_t hash = fnv1a(tagId);
    return "PSN:" + toHex(hash, 8);
}

}  // namespace nfc
}  // namespace phantom
