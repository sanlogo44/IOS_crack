/*
 * Phantom OS - NFC Manager
 * v0.35.0 - License: GPL-3.0
 *
 * Privacy-first NFC service: adapter state management, tag discovery
 * (reader/writer/P2P/card-emulation), protocol support (ISO 14443 A/B,
 * ISO 15693, MIFARE, FeliCa), NDEF message handling, Host Card Emulation
 * (HCE) with per-app AID routing, per-app NFC policy with foreground-only
 * enforcement, secure element access control, privacy indicator, mock
 * tags for testing, events, stats, callbacks and optional
 * LogServer/CrashReporter integration.
 *
 * All data is simulated in-memory. Tag data is deterministic stubs.
 * The LogServer must never log raw card data, NDEF payloads, or AIDs.
 */

#ifndef PHANTOM_NFC_NFC_MANAGER_H
#define PHANTOM_NFC_NFC_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace nfc {

// ============================================================
// Constants
// ============================================================

static const uint32_t NFC_PRIVACY_NONE = 0;
static const uint32_t NFC_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t NFC_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t NFC_PRIVACY_REDACT_TAG_ID = 1 << 2;
static const uint32_t NFC_PRIVACY_PSEUDONYMIZE = 1 << 3;
static const uint32_t NFC_PRIVACY_METADATA_ONLY = 1 << 4;
static const uint32_t NFC_PRIVACY_MOCK_ALLOWED = 1 << 5;
static const uint32_t NFC_PRIVACY_INDICATOR_REQUIRED = 1 << 6;
static const uint32_t NFC_PRIVACY_BLOCK_CARD_EMULATION = 1 << 7;

static const uint32_t NFC_DEFAULT_MAX_TAGS = 16;
static const uint32_t NFC_DEFAULT_MAX_HISTORY = 128;
static const uint32_t NFC_DEFAULT_MAX_EVENTS = 256;

// ============================================================
// Enums
// ============================================================

enum class NfcAdapterState : uint8_t {
    OFF = 0,
    TURNING_ON,
    ON,
    TURNING_OFF
};

enum class NfcDiscoveryMode : uint8_t {
    IDLE = 0,
    READER,
    WRITER,
    P2P,
    CARD_EMULATION
};

enum class NfcProtocol : uint8_t {
    UNKNOWN = 0,
    ISO_14443_A,
    ISO_14443_B,
    ISO_15693,
    MIFARE_CLASSIC,
    MIFARE_ULTRALIGHT,
    FELICA,
    NFC_BARCODE,
    NDEF
};

enum class NfcTagType : uint8_t {
    UNKNOWN = 0,
    NDEF,
    MIFARE_CLASSIC,
    MIFARE_ULTRALIGHT,
    FELICA,
    ISO_14443_4,
    ISO_15693,
    NFC_BARCODE,
    NDEF_FORMATABLE
};

enum class NfcPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class NfcPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class NfcResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    ADAPTER_OFF,
    DISCOVERY_ACTIVE,
    NO_DISCOVERY,
    TAG_NOT_FOUND,
    TAG_IO_ERROR,
    NDEF_INVALID,
    AID_CONFLICT,
    CAPACITY_EXCEEDED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class NfcEventType : uint8_t {
    ADAPTER_STATE_CHANGED = 0,
    DISCOVERY_STARTED,
    DISCOVERY_STOPPED,
    TAG_DISCOVERED,
    TAG_REMOVED,
    NDEF_READ,
    NDEF_WRITE,
    CARD_EMULATION_ACTIVATED,
    CARD_EMULATION_DEACTIVATED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    MOCK_TAG_SET,
    HISTORY_CLEARED
};

// ============================================================
// Data structures
// ============================================================

struct NfcTag {
    std::string tagId;
    NfcProtocol protocol = NfcProtocol::UNKNOWN;
    NfcTagType type = NfcTagType::UNKNOWN;
    std::vector<uint8_t> ndefContent;
    uint32_t maxSize = 0;
    bool readOnly = false;
    bool connected = false;
    int32_t rssi = -50;
    uint64_t discoveredAt = 0;
};

struct AidRoute {
    std::string appId;
    std::string aid;
    std::string description;
    bool active = false;
};

struct NfcPolicy {
    std::string appId;
    NfcPermission permission = NfcPermission::DENY;
    NfcPrivacyMode privacyMode = NfcPrivacyMode::FULL;
    uint32_t privacyFlags = NFC_PRIVACY_NONE;
    bool allowReaderMode = false;
    bool allowWriterMode = false;
    bool allowP2P = false;
    bool allowCardEmulation = false;
    std::vector<AidRoute> aidRoutes;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
};

struct NfcEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    NfcEventType type = NfcEventType::ADAPTER_STATE_CHANGED;
    NfcResult result = NfcResult::SUCCESS;
    std::string appId;
    std::string detail;
};

struct NfcStats {
    uint64_t adapterOnCount = 0;
    uint64_t adapterOffCount = 0;
    uint64_t discoveryCount = 0;
    uint64_t tagsDiscovered = 0;
    uint64_t tagsRemoved = 0;
    uint64_t ndefReads = 0;
    uint64_t ndefWrites = 0;
    uint64_t cardEmulationActivations = 0;
    uint64_t cardEmulationDeactivations = 0;
    uint64_t permissionsChanged = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t mockTagsSet = 0;
    uint64_t byEventType[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// NFC Manager
// ============================================================

class NfcManager {
public:
    NfcManager() = default;
    ~NfcManager() = default;

    NfcManager(const NfcManager&) = delete;
    NfcManager& operator=(const NfcManager&) = delete;

    // ---- Lifecycle ----
    NfcResult initialize(size_t maxTags = 16, size_t maxHistory = 128,
                           size_t maxEvents = 256);
    NfcResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Adapter state ----
    NfcResult enableAdapter(const std::string& owner = "system");
    NfcResult disableAdapter(const std::string& owner = "system");
    NfcAdapterState getAdapterState() const { return adapterState_; }
    bool isAdapterEnabled() const { return adapterState_ == NfcAdapterState::ON; }
    bool isAdapterOff() const { return adapterState_ == NfcAdapterState::OFF; }

    // ---- Discovery ----
    NfcResult startDiscovery(NfcDiscoveryMode mode, const std::string& owner = "system");
    NfcResult stopDiscovery(const std::string& owner = "system");
    NfcDiscoveryMode getDiscoveryMode() const { return discoveryMode_; }
    bool isDiscoveryActive() const { return discoveryMode_ != NfcDiscoveryMode::IDLE; }

    // ---- Tag management ----
    NfcResult connectTag(const std::string& tagId, const std::string& owner = "system");
    NfcResult disconnectTag(const std::string& owner = "system");
    NfcResult getTag(const std::string& tagId, NfcTag& outTag) const;
    std::vector<NfcTag> getAllTags() const;
    std::vector<NfcTag> getConnectedTags() const;
    size_t getTagCount() const { return tags_.size(); }
    NfcResult removeTag(const std::string& tagId, const std::string& owner = "system");

    // ---- NDEF ----
    NfcResult readNdef(const std::string& tagId, std::vector<uint8_t>& outData,
                        const std::string& owner = "system");
    NfcResult writeNdef(const std::string& tagId, const std::vector<uint8_t>& data,
                         const std::string& owner = "system");
    bool isTagReadOnly(const std::string& tagId) const;

    // ---- Card emulation / HCE ----
    NfcResult registerAidRoute(const std::string& appId, const std::string& aid,
                                  const std::string& description,
                                  const std::string& owner = "system");
    NfcResult unregisterAidRoute(const std::string& appId, const std::string& aid,
                                   const std::string& owner = "system");
    std::vector<AidRoute> getAidRoutes() const;
    std::vector<AidRoute> getAidRoutesForApp(const std::string& appId) const;
    NfcResult setCardEmulationActive(const std::string& appId, bool active,
                                        const std::string& owner = "system");
    bool isCardEmulationActive() const;

    // ---- Permission / policy ----
    NfcResult setAppNfcPolicy(const std::string& appId,
                                NfcPermission permission,
                                NfcPrivacyMode privacyMode,
                                uint32_t privacyFlags = NFC_PRIVACY_NONE,
                                bool allowReader = false,
                                bool allowWriter = false,
                                bool allowP2P = false,
                                bool allowCardEmulation = false,
                                const std::string& owner = "system");
    NfcPolicy getAppNfcPolicy(const std::string& appId) const;
    NfcResult clearAppNfcPolicy(const std::string& appId,
                                   const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    NfcResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Identifier access ----
    NfcResult getTagId(const std::string& appId, const std::string& tagId,
                         std::string& outId) const;
    NfcResult getTagProtocol(const std::string& appId, const std::string& tagId,
                                NfcProtocol& outProtocol) const;
    NfcResult getTagRssi(const std::string& appId, const std::string& tagId,
                           int32_t& outRssi) const;

    // ---- History ----
    std::vector<NfcEvent> getHistory(const std::string& appId,
                                      size_t limit = 0) const;
    NfcResult clearHistory(const std::string& owner = "system");
    NfcResult clearAppHistory(const std::string& appId,
                                 const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    NfcResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    NfcResult setMockTag(const std::string& tagId, NfcProtocol protocol,
                           NfcTagType type,
                           const std::vector<uint8_t>& ndefContent,
                           uint32_t maxSize, bool readOnly,
                           const std::string& owner = "system");
    NfcResult addMockTag(const NfcTag& tag, const std::string& owner = "system");
    NfcResult removeMockTag(const std::string& tagId, const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeNfcUsers_.empty(); }
    std::vector<std::string> getActiveNfcUsers() const { return activeNfcUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<NfcEvent> getEvents(size_t limit = 0) const;
    std::vector<NfcEvent> getEventsByType(NfcEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    NfcResult clearEvents();

    // ---- Stats ----
    NfcStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const NfcEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, NfcResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* adapterStateToString(NfcAdapterState state);
    static const char* discoveryModeToString(NfcDiscoveryMode mode);
    static const char* protocolToString(NfcProtocol protocol);
    static const char* tagTypeToString(NfcTagType type);
    static const char* permissionToString(NfcPermission permission);
    static const char* privacyModeToString(NfcPrivacyMode mode);
    static const char* resultToString(NfcResult result);
    static const char* eventTypeToString(NfcEventType type);
    static NfcResult stringToResult(const std::string& str);
    static NfcProtocol stringToProtocol(const std::string& str);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(NfcEventType type, NfcResult result,
                     const std::string& appId,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void createStubTags();
    std::string redactTagId(const std::string& tagId) const;
    std::string pseudonymizeTagId(const std::string& tagId) const;
    NfcResult findTag(const std::string& tagId, NfcTag*& outTag);
    NfcResult findTagConst(const std::string& tagId, const NfcTag*& outTag) const;

    bool initialized_ = false;
    size_t maxTags_ = 16;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;

    NfcAdapterState adapterState_ = NfcAdapterState::OFF;
    NfcDiscoveryMode discoveryMode_ = NfcDiscoveryMode::IDLE;

    std::vector<NfcTag> tags_;
    std::map<std::string, NfcPolicy> appPolicies_;

    std::vector<NfcEvent> history_;
    std::vector<NfcEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    std::vector<std::string> activeNfcUsers_;
    uint64_t lastAccessTime_ = 0;

    NfcStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const NfcEvent&)> eventCallback_;
    std::function<void(const std::string&, NfcResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace nfc
}  // namespace phantom

#endif  // PHANTOM_NFC_NFC_MANAGER_H
