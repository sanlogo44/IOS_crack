/*
 * Phantom OS - Power Manager Implementation
 *
 * v0.26.0
 * License: GPL-3.0
 *
 * All battery, charging and thermal values are simulated. The manager
 * never touches real hardware; state changes are driven by explicit
 * simulation calls (used by tests and the future HAL mock runtime).
 */

#include "phantom/power/power_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>

namespace phantom::power {

// ============================================================
// Helpers
// ============================================================

uint64_t PowerManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ != 0) {
        return timeOverrideMs_;
    }
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

void PowerManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message,
                                 "PowerManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message,
                                "PowerManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message,
                                "PowerManager");
        }
    }
}

void PowerManager::notifyCrashReporter(const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr("power_manager", "power_manager", 0, message);
    }
}

bool PowerManager::isSystemOwner(const std::string& owner) const {
    return owner == "system" || owner == "phantos.system";
}

void PowerManager::recordEvent(PowerEventType type, PowerResult result,
                               const std::string& owner, const std::string& detail) {
    PowerEvent event;
    event.id = nextEventId_++;
    event.type = type;
    event.result = result;
    event.owner = owner;
    event.detail = detail;
    event.timestamp = getCurrentTimeMs();

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        events_.erase(events_.begin());
    }
    byEventType_[static_cast<size_t>(type)]++;

    if (powerEventCb_) {
        powerEventCb_(event);
    }
}

void PowerManager::moveToHistory(const PowerEvent& event) {
    history_.push_back(event);
    if (history_.size() > maxHistory_) {
        history_.erase(history_.begin());
    }
}

// ============================================================
// Lifecycle
// ============================================================

PowerResult PowerManager::initialize(size_t maxWakeLocks, size_t maxEvents,
                                     size_t maxHistory) {
    if (initialized_) {
        return PowerResult::ALREADY_INITIALIZED;
    }
    if (maxWakeLocks == 0 || maxEvents == 0 || maxHistory == 0) {
        return PowerResult::INVALID_PARAMETER;
    }
    maxWakeLocks_ = maxWakeLocks;
    maxEvents_ = maxEvents;
    maxHistory_ = maxHistory;
    battery_ = BatteryStatus{};
    batteryPresent_ = true;
    powerMode_ = PowerMode::BALANCED;
    manualMode_ = false;
    autoPowerSaver_ = true;
    systemState_ = SystemPowerState::AWAKE;
    poweredOn_ = true;
    thermalState_ = ThermalState::NORMAL;
    initialized_ = true;
    logToServer("info", "PowerManager initialized (maxWakeLocks=" +
                        std::to_string(maxWakeLocks) + ")");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::shutdown() {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    wakeLocks_.clear();
    events_.clear();
    history_.clear();
    battery_ = BatteryStatus{};
    batteryPresent_ = true;
    powerMode_ = PowerMode::BALANCED;
    manualMode_ = false;
    autoPowerSaver_ = true;
    systemState_ = SystemPowerState::AWAKE;
    poweredOn_ = true;
    thermalState_ = ThermalState::NORMAL;
    lowThreshold_ = 20;
    criticalThreshold_ = 5;
    autoSaverThreshold_ = 15;
    nextWakeLockId_ = 1;
    nextEventId_ = 1;
    initialized_ = false;
    logToServer("info", "PowerManager shut down");
    return PowerResult::SUCCESS;
}

// ============================================================
// Battery state computation
// ============================================================

void PowerManager::updateBatteryState(const std::string& owner) {
    BatteryState newState;
    if (!batteryPresent_) {
        newState = BatteryState::NOT_PRESENT;
    } else if (battery_.charging) {
        newState = (battery_.level >= 100) ? BatteryState::FULL : BatteryState::CHARGING;
    } else {
        if (battery_.level <= criticalThreshold_) {
            newState = BatteryState::CRITICAL;
        } else if (battery_.level <= lowThreshold_) {
            newState = BatteryState::LOW;
        } else {
            newState = BatteryState::DISCHARGING;
        }
    }

    if (newState != battery_.state) {
        BatteryState oldState = battery_.state;
        battery_.state = newState;
        byBatteryState_[static_cast<size_t>(newState)]++;

        if (newState == BatteryState::LOW && oldState != BatteryState::CRITICAL) {
            lowWarnings_++;
            recordEvent(PowerEventType::LOW_POWER_WARNING, PowerResult::SUCCESS, owner,
                        "Battery low: " + std::to_string(battery_.level) + "%");
            logToServer("warn", "Battery low: " + std::to_string(battery_.level) + "%");
        } else if (newState == BatteryState::CRITICAL) {
            criticalWarnings_++;
            recordEvent(PowerEventType::LOW_POWER_WARNING, PowerResult::SUCCESS, owner,
                        "Battery critical: " + std::to_string(battery_.level) + "%");
            logToServer("warn", "Battery critical: " + std::to_string(battery_.level) + "%");
        }
    }
}

void PowerManager::applyPowerMode(PowerMode newMode, const std::string& owner, bool manual) {
    if (newMode == powerMode_) {
        if (manual) {
            manualMode_ = true;
        }
        return;
    }
    PowerMode oldMode = powerMode_;
    powerMode_ = newMode;
    if (manual) {
        manualMode_ = true;
    }
    modeChanges_++;
    byPowerMode_[static_cast<size_t>(newMode)]++;
    recordEvent(PowerEventType::MODE_CHANGED, PowerResult::SUCCESS, owner,
                std::string(powerModeToString(oldMode)) + " -> " + powerModeToString(newMode) +
                (manual ? " (manual)" : " (auto)"));
    if (powerModeCb_) {
        powerModeCb_(oldMode, newMode);
    }
    logToServer("info", std::string("Power mode: ") + powerModeToString(oldMode) + " -> " +
                        powerModeToString(newMode));
}

void PowerManager::applyAutoSaverRules(const std::string& owner) {
    (void)owner;  // Reserved for future policy attribution

    if (!autoPowerSaver_ || manualMode_ || !poweredOn_) {
        return;
    }
    if (battery_.state == BatteryState::CRITICAL ||
        battery_.level <= criticalThreshold_) {
        applyPowerMode(PowerMode::EXTREME_SAVER, "system", false);
    } else if (battery_.source == PowerSource::BATTERY && !battery_.charging &&
               battery_.level <= autoSaverThreshold_) {
        applyPowerMode(PowerMode::BATTERY_SAVER, "system", false);
    } else if (battery_.charging &&
               battery_.level > autoSaverThreshold_ + SAVER_HYSTERESIS_) {
        applyPowerMode(PowerMode::BALANCED, "system", false);
    }
}

// ============================================================
// Battery simulation
// ============================================================

PowerResult PowerManager::setBatteryLevelForTesting(uint8_t percent) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (percent > 100) {
        return PowerResult::INVALID_PARAMETER;
    }
    uint8_t oldLevel = battery_.level;
    battery_.level = percent;
    updateBatteryState("system");
    if (oldLevel != battery_.level) {
        batteryLevelChanges_++;
        recordEvent(PowerEventType::BATTERY_CHANGED, PowerResult::SUCCESS, "system",
                    "Level " + std::to_string(oldLevel) + "% -> " +
                    std::to_string(battery_.level) + "%");
        if (batteryCb_) {
            batteryCb_(oldLevel, battery_.level, battery_.state);
        }
    }
    applyAutoSaverRules("system");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::setPowerSourceForTesting(PowerSource source) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (source == PowerSource::UNKNOWN) {
        return PowerResult::INVALID_PARAMETER;
    }
    PowerSource oldSource = battery_.source;
    battery_.source = source;
    if (source == PowerSource::BATTERY) {
        battery_.charging = false;
        battery_.chargingType = ChargingType::NONE;
    } else {
        battery_.charging = true;
        if (battery_.chargingType == ChargingType::NONE) {
            battery_.chargingType = ChargingType::STANDARD;
        }
    }
    updateBatteryState("system");
    if (oldSource != source) {
        recordEvent(PowerEventType::SOURCE_CHANGED, PowerResult::SUCCESS, "system",
                    std::string(powerSourceToString(oldSource)) + " -> " +
                    powerSourceToString(source));
    }
    applyAutoSaverRules("system");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::setChargingForTesting(bool charging, ChargingType type) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    bool wasCharging = battery_.charging;
    battery_.charging = charging;
    battery_.chargingType = charging ? type : ChargingType::NONE;
    if (charging && battery_.source == PowerSource::BATTERY) {
        battery_.source = PowerSource::USB;
    }
    updateBatteryState("system");
    if (wasCharging != charging) {
        recordEvent(PowerEventType::SOURCE_CHANGED, PowerResult::SUCCESS, "system",
                    charging ? "Charging started (" + std::string(chargingTypeToString(type)) + ")"
                             : "Charging stopped");
        logToServer("info", charging ? "Charging started" : "Charging stopped");
    }
    applyAutoSaverRules("system");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::setBatteryPresentForTesting(bool present) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    batteryPresent_ = present;
    if (!present) {
        battery_.charging = false;
        battery_.chargingType = ChargingType::NONE;
    }
    updateBatteryState("system");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::simulateDrain(uint8_t percent) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (percent == 0 || percent > 100) {
        return PowerResult::INVALID_PARAMETER;
    }
    uint8_t oldLevel = battery_.level;
    battery_.level = (battery_.level > percent) ? static_cast<uint8_t>(battery_.level - percent)
                                                : 0;
    updateBatteryState("system");
    if (oldLevel != battery_.level) {
        batteryLevelChanges_++;
        recordEvent(PowerEventType::BATTERY_CHANGED, PowerResult::SUCCESS, "system",
                    "Drain " + std::to_string(oldLevel) + "% -> " +
                    std::to_string(battery_.level) + "%");
        if (batteryCb_) {
            batteryCb_(oldLevel, battery_.level, battery_.state);
        }
    }
    applyAutoSaverRules("system");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::simulateCharge(uint8_t percent) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (percent == 0 || percent > 100) {
        return PowerResult::INVALID_PARAMETER;
    }
    uint8_t oldLevel = battery_.level;
    battery_.level = static_cast<uint8_t>(
        std::min(100, static_cast<int>(battery_.level) + static_cast<int>(percent)));
    updateBatteryState("system");
    if (oldLevel != battery_.level) {
        batteryLevelChanges_++;
        recordEvent(PowerEventType::BATTERY_CHANGED, PowerResult::SUCCESS, "system",
                    "Charge " + std::to_string(oldLevel) + "% -> " +
                    std::to_string(battery_.level) + "%");
        if (batteryCb_) {
            batteryCb_(oldLevel, battery_.level, battery_.state);
        }
    }
    applyAutoSaverRules("system");
    return PowerResult::SUCCESS;
}

uint32_t PowerManager::estimateRemainingMinutes() const {
    if (battery_.state == BatteryState::NOT_PRESENT) {
        return 0;
    }
    if (battery_.charging) {
        // Rough estimate: 2 minutes per missing percent
        return static_cast<uint32_t>(100 - battery_.level) * 2;
    }
    uint32_t minutesPerPercent = 3;
    switch (powerMode_) {
        case PowerMode::PERFORMANCE:
        case PowerMode::BALANCED:
            minutesPerPercent = 3;
            break;
        case PowerMode::BATTERY_SAVER:
            minutesPerPercent = 5;
            break;
        case PowerMode::EXTREME_SAVER:
            minutesPerPercent = 7;
            break;
    }
    return static_cast<uint32_t>(battery_.level) * minutesPerPercent;
}

// ============================================================
// Thresholds
// ============================================================

PowerResult PowerManager::setBatteryThresholds(uint8_t low, uint8_t critical,
                                               uint8_t autoSaver,
                                               const std::string& owner) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return PowerResult::PERMISSION_DENIED;
    }
    if (critical >= autoSaver || autoSaver > low || low > 100) {
        return PowerResult::INVALID_PARAMETER;
    }
    lowThreshold_ = low;
    criticalThreshold_ = critical;
    autoSaverThreshold_ = autoSaver;
    logToServer("info", "Battery thresholds: low=" + std::to_string(low) +
                        " critical=" + std::to_string(critical) +
                        " autoSaver=" + std::to_string(autoSaver));
    return PowerResult::SUCCESS;
}

// ============================================================
// Power mode
// ============================================================

PowerResult PowerManager::setPowerMode(PowerMode mode, const std::string& owner) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (owner.empty()) {
        return PowerResult::INVALID_PARAMETER;
    }
    applyPowerMode(mode, owner, true);
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    return PowerResult::SUCCESS;
}

void PowerManager::setAutoPowerSaverEnabled(bool enabled) {
    autoPowerSaver_ = enabled;
    if (enabled) {
        // Re-enabling auto saver returns control to automatic rules
        manualMode_ = false;
    }
    logToServer("info", std::string("Auto power saver ") + (enabled ? "enabled" : "disabled"));
}

// ============================================================
// Wake locks
// ============================================================

uint64_t PowerManager::acquireWakeLock(const std::string& owner, const std::string& tag,
                                       WakeLockType type, uint64_t timeoutMs) {
    if (!initialized_) {
        return 0;
    }
    if (owner.empty() || tag.empty()) {
        byResult_[static_cast<size_t>(PowerResult::INVALID_PARAMETER)]++;
        return 0;
    }
    for (const auto& lock : wakeLocks_) {
        if (lock.owner == owner && lock.tag == tag && lock.type == type) {
            byResult_[static_cast<size_t>(PowerResult::WAKE_LOCK_EXISTS)]++;
            return 0;
        }
    }
    if (wakeLocks_.size() >= maxWakeLocks_) {
        byResult_[static_cast<size_t>(PowerResult::CAPACITY_EXCEEDED)]++;
        return 0;
    }
    WakeLock lock;
    lock.id = nextWakeLockId_++;
    lock.owner = owner;
    lock.tag = tag;
    lock.type = type;
    lock.acquiredAt = getCurrentTimeMs();
    lock.timeoutMs = timeoutMs;
    wakeLocks_.push_back(lock);
    wakeLocksAcquired_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::WAKE_LOCK_ACQUIRED, PowerResult::SUCCESS, owner,
                std::string(wakeLockTypeToString(type)) + " '" + tag + "'");
    logToServer("info", "Wake lock acquired: " + owner + "/" + tag);
    return lock.id;
}

PowerResult PowerManager::releaseWakeLock(uint64_t id, const std::string& owner) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    for (auto it = wakeLocks_.begin(); it != wakeLocks_.end(); ++it) {
        if (it->id == id) {
            if (it->owner != owner && !isSystemOwner(owner)) {
                byResult_[static_cast<size_t>(PowerResult::PERMISSION_DENIED)]++;
                return PowerResult::PERMISSION_DENIED;
            }
            std::string lockOwner = it->owner;
            std::string lockTag = it->tag;
            wakeLocks_.erase(it);
            wakeLocksReleased_++;
            byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
            recordEvent(PowerEventType::WAKE_LOCK_RELEASED, PowerResult::SUCCESS, lockOwner,
                        "'" + lockTag + "'");
            logToServer("info", "Wake lock released: " + lockOwner + "/" + lockTag);
            return PowerResult::SUCCESS;
        }
    }
    byResult_[static_cast<size_t>(PowerResult::WAKE_LOCK_NOT_FOUND)]++;
    return PowerResult::WAKE_LOCK_NOT_FOUND;
}

PowerResult PowerManager::releaseWakeLocksByOwner(const std::string& owner) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (owner.empty()) {
        return PowerResult::INVALID_PARAMETER;
    }
    size_t removed = 0;
    for (auto it = wakeLocks_.begin(); it != wakeLocks_.end();) {
        if (it->owner == owner || isSystemOwner(owner)) {
            wakeLocksReleased_++;
            recordEvent(PowerEventType::WAKE_LOCK_RELEASED, PowerResult::SUCCESS, it->owner,
                        "'" + it->tag + "'");
            it = wakeLocks_.erase(it);
            removed++;
        } else {
            ++it;
        }
    }
    if (removed == 0) {
        byResult_[static_cast<size_t>(PowerResult::WAKE_LOCK_NOT_FOUND)]++;
        return PowerResult::WAKE_LOCK_NOT_FOUND;
    }
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    return PowerResult::SUCCESS;
}

std::vector<WakeLock> PowerManager::getActiveWakeLocks() const {
    return wakeLocks_;
}

PowerResult PowerManager::processExpiredWakeLocks() {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    uint64_t now = getCurrentTimeMs();
    for (auto it = wakeLocks_.begin(); it != wakeLocks_.end();) {
        if (it->timeoutMs != 0 && now >= it->acquiredAt + it->timeoutMs) {
            wakeLocksExpired_++;
            recordEvent(PowerEventType::WAKE_LOCK_EXPIRED, PowerResult::SUCCESS, it->owner,
                        "'" + it->tag + "'");
            logToServer("info", "Wake lock expired: " + it->owner + "/" + it->tag);
            it = wakeLocks_.erase(it);
        } else {
            ++it;
        }
    }
    return PowerResult::SUCCESS;
}

// ============================================================
// System power state
// ============================================================

PowerResult PowerManager::requestSuspend(const std::string& owner, WakeReason reason,
                                        bool force) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        byResult_[static_cast<size_t>(PowerResult::SIMULATED_FAILURE)]++;
        recordEvent(PowerEventType::SUSPEND, PowerResult::SIMULATED_FAILURE, owner,
                    "Simulated suspend failure");
        notifyCrashReporter("power_suspend_failed");
        return PowerResult::SIMULATED_FAILURE;
    }
    if (!isSystemOwner(owner)) {
        byResult_[static_cast<size_t>(PowerResult::PERMISSION_DENIED)]++;
        return PowerResult::PERMISSION_DENIED;
    }
    if (thermalState_ == ThermalState::CRITICAL || thermalState_ == ThermalState::SHUTDOWN) {
        byResult_[static_cast<size_t>(PowerResult::THERMAL_CRITICAL)]++;
        return PowerResult::THERMAL_CRITICAL;
    }
    if (!poweredOn_ ||
        (systemState_ != SystemPowerState::AWAKE && systemState_ != SystemPowerState::IDLE)) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    if (!wakeLocks_.empty() && !force) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        recordEvent(PowerEventType::SUSPEND, PowerResult::BAD_STATE, owner,
                    "Blocked by " + std::to_string(wakeLocks_.size()) + " wake lock(s)");
        return PowerResult::BAD_STATE;
    }
    systemState_ = SystemPowerState::SUSPENDED;
    suspends_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::SUSPEND, PowerResult::SUCCESS, owner,
                std::string("Reason: ") + wakeReasonToString(reason));
    logToServer("info", std::string("Suspend (") + wakeReasonToString(reason) + ")");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::resume(WakeReason reason) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (systemState_ != SystemPowerState::SUSPENDED &&
        systemState_ != SystemPowerState::HIBERNATING) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    systemState_ = SystemPowerState::AWAKE;
    resumes_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::RESUME, PowerResult::SUCCESS, "system",
                std::string("Reason: ") + wakeReasonToString(reason));
    logToServer("info", std::string("Resume (") + wakeReasonToString(reason) + ")");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::requestHibernate(const std::string& owner, bool force) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        byResult_[static_cast<size_t>(PowerResult::SIMULATED_FAILURE)]++;
        recordEvent(PowerEventType::HIBERNATE_REQUESTED, PowerResult::SIMULATED_FAILURE,
                    owner, "Simulated hibernate failure");
        notifyCrashReporter("power_hibernate_failed");
        return PowerResult::SIMULATED_FAILURE;
    }
    if (!isSystemOwner(owner)) {
        byResult_[static_cast<size_t>(PowerResult::PERMISSION_DENIED)]++;
        return PowerResult::PERMISSION_DENIED;
    }
    if (thermalState_ == ThermalState::CRITICAL || thermalState_ == ThermalState::SHUTDOWN) {
        byResult_[static_cast<size_t>(PowerResult::THERMAL_CRITICAL)]++;
        return PowerResult::THERMAL_CRITICAL;
    }
    if (!poweredOn_ || systemState_ != SystemPowerState::AWAKE) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    if (batteryPresent_ && battery_.level <= criticalThreshold_) {
        // Hibernating below critical battery is unsafe (may not wake up)
        byResult_[static_cast<size_t>(PowerResult::BATTERY_TOO_LOW)]++;
        return PowerResult::BATTERY_TOO_LOW;
    }
    if (!wakeLocks_.empty() && !force) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    systemState_ = SystemPowerState::HIBERNATING;
    hibernateRequests_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::HIBERNATE_REQUESTED, PowerResult::SUCCESS, owner, "");
    logToServer("info", "Hibernate requested");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::requestShutdown(const std::string& owner, bool force) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        byResult_[static_cast<size_t>(PowerResult::SIMULATED_FAILURE)]++;
        recordEvent(PowerEventType::SHUTDOWN_REQUESTED, PowerResult::SIMULATED_FAILURE,
                    owner, "Simulated shutdown failure");
        notifyCrashReporter("power_shutdown_failed");
        return PowerResult::SIMULATED_FAILURE;
    }
    if (!isSystemOwner(owner)) {
        byResult_[static_cast<size_t>(PowerResult::PERMISSION_DENIED)]++;
        return PowerResult::PERMISSION_DENIED;
    }
    if (!poweredOn_) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    if (!wakeLocks_.empty() && !force) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        recordEvent(PowerEventType::SHUTDOWN_REQUESTED, PowerResult::BAD_STATE, owner,
                    "Blocked by " + std::to_string(wakeLocks_.size()) + " wake lock(s)");
        return PowerResult::BAD_STATE;
    }
    systemState_ = SystemPowerState::SHUTTING_DOWN;
    poweredOn_ = false;
    shutdownRequests_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::SHUTDOWN_REQUESTED, PowerResult::SUCCESS, owner,
                force ? "Forced (wake locks overridden)" : "");
    logToServer("info", "Shutdown requested");
    return PowerResult::SUCCESS;
}

PowerResult PowerManager::requestReboot(const std::string& owner, bool force) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        byResult_[static_cast<size_t>(PowerResult::SIMULATED_FAILURE)]++;
        recordEvent(PowerEventType::REBOOT_REQUESTED, PowerResult::SIMULATED_FAILURE,
                    owner, "Simulated reboot failure");
        notifyCrashReporter("power_reboot_failed");
        return PowerResult::SIMULATED_FAILURE;
    }
    if (!isSystemOwner(owner)) {
        byResult_[static_cast<size_t>(PowerResult::PERMISSION_DENIED)]++;
        return PowerResult::PERMISSION_DENIED;
    }
    if (!poweredOn_) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        return PowerResult::BAD_STATE;
    }
    if (!wakeLocks_.empty() && !force) {
        byResult_[static_cast<size_t>(PowerResult::BAD_STATE)]++;
        recordEvent(PowerEventType::REBOOT_REQUESTED, PowerResult::BAD_STATE, owner,
                    "Blocked by " + std::to_string(wakeLocks_.size()) + " wake lock(s)");
        return PowerResult::BAD_STATE;
    }
    systemState_ = SystemPowerState::REBOOTING;
    rebootRequests_++;
    byResult_[static_cast<size_t>(PowerResult::SUCCESS)]++;
    recordEvent(PowerEventType::REBOOT_REQUESTED, PowerResult::SUCCESS, owner, "");
    logToServer("info", "Reboot requested");
    // Reboot completes instantly in the simulation
    systemState_ = SystemPowerState::AWAKE;
    return PowerResult::SUCCESS;
}

// ============================================================
// Thermal
// ============================================================

PowerResult PowerManager::setThermalStateForTesting(ThermalState state) {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    if (state == thermalState_) {
        return PowerResult::SUCCESS;
    }
    ThermalState oldState = thermalState_;
    thermalState_ = state;
    thermalTransitions_++;
    recordEvent(PowerEventType::THERMAL_CHANGED, PowerResult::SUCCESS, "system",
                std::string(thermalStateToString(oldState)) + " -> " +
                thermalStateToString(state));
    if (state == ThermalState::CRITICAL || state == ThermalState::SHUTDOWN) {
        logToServer("error", std::string("Thermal state: ") + thermalStateToString(state));
        notifyCrashReporter(std::string("thermal_") +
                            (state == ThermalState::SHUTDOWN ? "shutdown" : "critical"));
    }
    if (state == ThermalState::SHUTDOWN) {
        forceThermalShutdown();
    }
    return PowerResult::SUCCESS;
}

void PowerManager::forceThermalShutdown() {
    // Thermal protection: power off regardless of wake locks
    if (!poweredOn_) {
        return;
    }
    systemState_ = SystemPowerState::SHUTTING_DOWN;
    poweredOn_ = false;
    shutdownRequests_++;
    recordEvent(PowerEventType::SHUTDOWN_REQUESTED, PowerResult::SUCCESS, "system",
                "Thermal protection shutdown");
}

uint32_t PowerManager::getThermalThrottlePercent() const {
    switch (thermalState_) {
        case ThermalState::NORMAL: return 0;
        case ThermalState::WARM: return 15;
        case ThermalState::HOT: return 40;
        case ThermalState::CRITICAL: return 75;
        case ThermalState::SHUTDOWN: return 100;
    }
    return 0;
}

bool PowerManager::isThermalThrottled() const {
    return getThermalThrottlePercent() > 0;
}

// ============================================================
// Policy queries
// ============================================================

bool PowerManager::shouldRestrictBackgroundActivity() const {
    return powerMode_ == PowerMode::BATTERY_SAVER || powerMode_ == PowerMode::EXTREME_SAVER;
}

bool PowerManager::shouldRestrictNetwork() const {
    return powerMode_ == PowerMode::EXTREME_SAVER;
}

bool PowerManager::shouldDimDisplay() const {
    return powerMode_ == PowerMode::BATTERY_SAVER || powerMode_ == PowerMode::EXTREME_SAVER;
}

uint32_t PowerManager::getCpuThrottlePercent() const {
    uint32_t modePenalty = 0;
    switch (powerMode_) {
        case PowerMode::PERFORMANCE:
        case PowerMode::BALANCED:
            modePenalty = 0;
            break;
        case PowerMode::BATTERY_SAVER:
            modePenalty = 30;
            break;
        case PowerMode::EXTREME_SAVER:
            modePenalty = 60;
            break;
    }
    uint32_t combined = getThermalThrottlePercent() + modePenalty;
    return combined > 100 ? 100 : combined;
}

// ============================================================
// Events, stats and history
// ============================================================

std::vector<PowerEvent> PowerManager::getEvents(size_t limit) const {
    std::vector<PowerEvent> result;
    if (limit == 0 || limit >= events_.size()) {
        result = events_;
    } else {
        result.assign(events_.end() - static_cast<std::ptrdiff_t>(limit), events_.end());
    }
    return result;
}

std::vector<PowerEvent> PowerManager::getEventsByType(PowerEventType type,
                                                       size_t limit) const {
    std::vector<PowerEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
            if (limit != 0 && result.size() >= limit) {
                break;
            }
        }
    }
    return result;
}

PowerResult PowerManager::clearEvents() {
    if (!initialized_) {
        return PowerResult::NOT_INITIALIZED;
    }
    for (const auto& event : events_) {
        moveToHistory(event);
    }
    events_.clear();
    return PowerResult::SUCCESS;
}

PowerManagerStats PowerManager::getStats() const {
    PowerManagerStats stats;
    stats.batteryLevelChanges = batteryLevelChanges_;
    stats.lowWarnings = lowWarnings_;
    stats.criticalWarnings = criticalWarnings_;
    stats.modeChanges = modeChanges_;
    stats.wakeLocksAcquired = wakeLocksAcquired_;
    stats.wakeLocksReleased = wakeLocksReleased_;
    stats.wakeLocksExpired = wakeLocksExpired_;
    stats.suspends = suspends_;
    stats.resumes = resumes_;
    stats.hibernateRequests = hibernateRequests_;
    stats.shutdownRequests = shutdownRequests_;
    stats.rebootRequests = rebootRequests_;
    stats.thermalTransitions = thermalTransitions_;
    stats.totalFailures = totalFailures_;
    for (size_t i = 0; i < 7; i++) {
        stats.byBatteryState[i] = byBatteryState_[i];
    }
    for (size_t i = 0; i < 4; i++) {
        stats.byPowerMode[i] = byPowerMode_[i];
    }
    for (size_t i = 0; i < 13; i++) {
        stats.byEventType[i] = byEventType_[i];
    }
    for (size_t i = 0; i < 13; i++) {
        stats.byResult[i] = byResult_[i];
    }
    return stats;
}

void PowerManager::resetStats() {
    batteryLevelChanges_ = 0;
    lowWarnings_ = 0;
    criticalWarnings_ = 0;
    modeChanges_ = 0;
    wakeLocksAcquired_ = 0;
    wakeLocksReleased_ = 0;
    wakeLocksExpired_ = 0;
    suspends_ = 0;
    resumes_ = 0;
    hibernateRequests_ = 0;
    shutdownRequests_ = 0;
    rebootRequests_ = 0;
    thermalTransitions_ = 0;
    totalFailures_ = 0;
    for (size_t i = 0; i < 7; i++) {
        byBatteryState_[i] = 0;
    }
    for (size_t i = 0; i < 4; i++) {
        byPowerMode_[i] = 0;
    }
    for (size_t i = 0; i < 13; i++) {
        byEventType_[i] = 0;
    }
    for (size_t i = 0; i < 13; i++) {
        byResult_[i] = 0;
    }
}

// ============================================================
// String helpers
// ============================================================

const char* PowerManager::batteryStateToString(BatteryState state) {
    switch (state) {
        case BatteryState::UNKNOWN: return "UNKNOWN";
        case BatteryState::DISCHARGING: return "DISCHARGING";
        case BatteryState::CHARGING: return "CHARGING";
        case BatteryState::FULL: return "FULL";
        case BatteryState::LOW: return "LOW";
        case BatteryState::CRITICAL: return "CRITICAL";
        case BatteryState::NOT_PRESENT: return "NOT_PRESENT";
    }
    return "UNKNOWN";
}

const char* PowerManager::powerSourceToString(PowerSource source) {
    switch (source) {
        case PowerSource::BATTERY: return "BATTERY";
        case PowerSource::USB: return "USB";
        case PowerSource::AC_ADAPTER: return "AC_ADAPTER";
        case PowerSource::WIRELESS_STUB: return "WIRELESS_STUB";
        case PowerSource::UNKNOWN: return "UNKNOWN";
    }
    return "UNKNOWN";
}

const char* PowerManager::powerModeToString(PowerMode mode) {
    switch (mode) {
        case PowerMode::PERFORMANCE: return "PERFORMANCE";
        case PowerMode::BALANCED: return "BALANCED";
        case PowerMode::BATTERY_SAVER: return "BATTERY_SAVER";
        case PowerMode::EXTREME_SAVER: return "EXTREME_SAVER";
    }
    return "UNKNOWN";
}

const char* PowerManager::systemPowerStateToString(SystemPowerState state) {
    switch (state) {
        case SystemPowerState::AWAKE: return "AWAKE";
        case SystemPowerState::IDLE: return "IDLE";
        case SystemPowerState::SUSPENDING: return "SUSPENDING";
        case SystemPowerState::SUSPENDED: return "SUSPENDED";
        case SystemPowerState::HIBERNATING: return "HIBERNATING";
        case SystemPowerState::SHUTTING_DOWN: return "SHUTTING_DOWN";
        case SystemPowerState::REBOOTING: return "REBOOTING";
    }
    return "UNKNOWN";
}

const char* PowerManager::thermalStateToString(ThermalState state) {
    switch (state) {
        case ThermalState::NORMAL: return "NORMAL";
        case ThermalState::WARM: return "WARM";
        case ThermalState::HOT: return "HOT";
        case ThermalState::CRITICAL: return "CRITICAL";
        case ThermalState::SHUTDOWN: return "SHUTDOWN";
    }
    return "UNKNOWN";
}

const char* PowerManager::wakeLockTypeToString(WakeLockType type) {
    switch (type) {
        case WakeLockType::PARTIAL: return "PARTIAL";
        case WakeLockType::DISPLAY: return "DISPLAY";
        case WakeLockType::NETWORK: return "NETWORK";
        case WakeLockType::CPU: return "CPU";
        case WakeLockType::FULL: return "FULL";
    }
    return "UNKNOWN";
}

const char* PowerManager::wakeReasonToString(WakeReason reason) {
    switch (reason) {
        case WakeReason::POWER_BUTTON: return "POWER_BUTTON";
        case WakeReason::TOUCH: return "TOUCH";
        case WakeReason::TIMER: return "TIMER";
        case WakeReason::NETWORK: return "NETWORK";
        case WakeReason::CHARGER: return "CHARGER";
        case WakeReason::ALARM: return "ALARM";
        case WakeReason::SYSTEM: return "SYSTEM";
    }
    return "UNKNOWN";
}

const char* PowerManager::chargingTypeToString(ChargingType type) {
    switch (type) {
        case ChargingType::NONE: return "NONE";
        case ChargingType::TRICKLE: return "TRICKLE";
        case ChargingType::STANDARD: return "STANDARD";
        case ChargingType::FAST_STUB: return "FAST_STUB";
        case ChargingType::WIRELESS_STUB: return "WIRELESS_STUB";
    }
    return "UNKNOWN";
}

const char* PowerManager::powerResultToString(PowerResult result) {
    switch (result) {
        case PowerResult::SUCCESS: return "SUCCESS";
        case PowerResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case PowerResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case PowerResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case PowerResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case PowerResult::WAKE_LOCK_NOT_FOUND: return "WAKE_LOCK_NOT_FOUND";
        case PowerResult::WAKE_LOCK_EXISTS: return "WAKE_LOCK_EXISTS";
        case PowerResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case PowerResult::BAD_STATE: return "BAD_STATE";
        case PowerResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case PowerResult::BATTERY_TOO_LOW: return "BATTERY_TOO_LOW";
        case PowerResult::THERMAL_CRITICAL: return "THERMAL_CRITICAL";
        case PowerResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
    }
    return "UNKNOWN";
}

const char* PowerManager::powerEventTypeToString(PowerEventType type) {
    switch (type) {
        case PowerEventType::BATTERY_CHANGED: return "BATTERY_CHANGED";
        case PowerEventType::SOURCE_CHANGED: return "SOURCE_CHANGED";
        case PowerEventType::MODE_CHANGED: return "MODE_CHANGED";
        case PowerEventType::WAKE_LOCK_ACQUIRED: return "WAKE_LOCK_ACQUIRED";
        case PowerEventType::WAKE_LOCK_RELEASED: return "WAKE_LOCK_RELEASED";
        case PowerEventType::WAKE_LOCK_EXPIRED: return "WAKE_LOCK_EXPIRED";
        case PowerEventType::THERMAL_CHANGED: return "THERMAL_CHANGED";
        case PowerEventType::SUSPEND: return "SUSPEND";
        case PowerEventType::RESUME: return "RESUME";
        case PowerEventType::SHUTDOWN_REQUESTED: return "SHUTDOWN_REQUESTED";
        case PowerEventType::REBOOT_REQUESTED: return "REBOOT_REQUESTED";
        case PowerEventType::HIBERNATE_REQUESTED: return "HIBERNATE_REQUESTED";
        case PowerEventType::LOW_POWER_WARNING: return "LOW_POWER_WARNING";
    }
    return "UNKNOWN";
}

PowerMode PowerManager::stringToPowerMode(const std::string& str) {
    if (str == "PERFORMANCE") return PowerMode::PERFORMANCE;
    if (str == "BALANCED") return PowerMode::BALANCED;
    if (str == "BATTERY_SAVER") return PowerMode::BATTERY_SAVER;
    if (str == "EXTREME_SAVER") return PowerMode::EXTREME_SAVER;
    return PowerMode::BALANCED;
}

BatteryState PowerManager::stringToBatteryState(const std::string& str) {
    if (str == "UNKNOWN") return BatteryState::UNKNOWN;
    if (str == "DISCHARGING") return BatteryState::DISCHARGING;
    if (str == "CHARGING") return BatteryState::CHARGING;
    if (str == "FULL") return BatteryState::FULL;
    if (str == "LOW") return BatteryState::LOW;
    if (str == "CRITICAL") return BatteryState::CRITICAL;
    if (str == "NOT_PRESENT") return BatteryState::NOT_PRESENT;
    return BatteryState::UNKNOWN;
}

PowerResult PowerManager::stringToPowerResult(const std::string& str) {
    if (str == "SUCCESS") return PowerResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return PowerResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return PowerResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return PowerResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return PowerResult::PERMISSION_DENIED;
    if (str == "WAKE_LOCK_NOT_FOUND") return PowerResult::WAKE_LOCK_NOT_FOUND;
    if (str == "WAKE_LOCK_EXISTS") return PowerResult::WAKE_LOCK_EXISTS;
    if (str == "CAPACITY_EXCEEDED") return PowerResult::CAPACITY_EXCEEDED;
    if (str == "BAD_STATE") return PowerResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return PowerResult::OPERATION_FAILED;
    if (str == "BATTERY_TOO_LOW") return PowerResult::BATTERY_TOO_LOW;
    if (str == "THERMAL_CRITICAL") return PowerResult::THERMAL_CRITICAL;
    if (str == "SIMULATED_FAILURE") return PowerResult::SIMULATED_FAILURE;
    return PowerResult::SUCCESS;
}

}  // namespace phantom::power
