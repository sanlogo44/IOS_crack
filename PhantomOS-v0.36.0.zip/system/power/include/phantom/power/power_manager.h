/*
 * Phantom OS - Power Manager
 * Battery monitoring, charging, power saver modes, wake locks, thermal
 * management and system power state control (simulated)
 *
 * v0.26.0
 * License: GPL-3.0
 *
 * All power/battery operations are simulated stubs for prototype use.
 * Battery levels, charging and thermal states are set explicitly; nothing
 * is measured from real hardware. Deterministic (FNV-1a based) where needed.
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::power {

// ============================================================
// Enums
// ============================================================

enum class BatteryState {
    UNKNOWN,      // Not yet determined
    DISCHARGING,  // On battery, draining
    CHARGING,     // External power, below full
    FULL,         // Charged to 100%
    LOW,          // Below low threshold
    CRITICAL,     // Below critical threshold
    NOT_PRESENT   // No battery detected
};

enum class PowerSource {
    BATTERY,       // Running on battery
    USB,           // USB host/charger
    AC_ADAPTER,    // Wall adapter
    WIRELESS_STUB, // Wireless charging (simulated)
    UNKNOWN
};

enum class PowerMode {
    PERFORMANCE,   // Full performance
    BALANCED,      // Default mode
    BATTERY_SAVER, // Reduced background activity
    EXTREME_SAVER  // Minimal activity, heavy throttling
};

enum class SystemPowerState {
    AWAKE,        // Fully operational
    IDLE,         // Screen off, background allowed
    SUSPENDING,   // Transition into suspend
    SUSPENDED,    // Deep sleep
    HIBERNATING,  // Persisted to storage (simulated)
    SHUTTING_DOWN,// Power-off in progress
    REBOOTING     // Restart in progress
};

enum class ThermalState {
    NORMAL,   // No throttling
    WARM,     // Light throttling (15%)
    HOT,      // Heavy throttling (40%)
    CRITICAL, // Severe throttling (75%)
    SHUTDOWN  // Thermal protection: forced power-off
};

enum class WakeLockType {
    PARTIAL, // CPU alive, display off
    DISPLAY, // Keep display on
    NETWORK, // Keep network active
    CPU,     // Keep CPU running
    FULL     // Everything awake
};

enum class WakeReason {
    POWER_BUTTON,
    TOUCH,
    TIMER,
    NETWORK,
    CHARGER,
    ALARM,
    SYSTEM
};

enum class ChargingType {
    NONE,
    TRICKLE,     // Slow charging
    STANDARD,    // Normal charging
    FAST_STUB,   // Fast charging (simulated)
    WIRELESS_STUB // Wireless charging (simulated)
};

enum class PowerResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    WAKE_LOCK_NOT_FOUND,
    WAKE_LOCK_EXISTS,
    CAPACITY_EXCEEDED,
    BAD_STATE,
    OPERATION_FAILED,
    BATTERY_TOO_LOW,
    THERMAL_CRITICAL,
    SIMULATED_FAILURE
};

enum class PowerEventType {
    BATTERY_CHANGED,      // Battery level/state updated
    SOURCE_CHANGED,       // Power source changed
    MODE_CHANGED,         // Power mode changed
    WAKE_LOCK_ACQUIRED,   // Wake lock acquired
    WAKE_LOCK_RELEASED,   // Wake lock released
    WAKE_LOCK_EXPIRED,    // Wake lock timed out
    THERMAL_CHANGED,      // Thermal state transition
    SUSPEND,              // System entered suspend
    RESUME,               // System woke up
    SHUTDOWN_REQUESTED,   // Shutdown initiated
    REBOOT_REQUESTED,     // Reboot initiated
    HIBERNATE_REQUESTED,  // Hibernate initiated
    LOW_POWER_WARNING     // Battery low/critical warning
};

// ============================================================
// Structs
// ============================================================

struct BatteryStatus {
    uint8_t level = 75;                  // 0-100 percent
    BatteryState state = BatteryState::DISCHARGING;
    PowerSource source = PowerSource::BATTERY;
    ChargingType chargingType = ChargingType::NONE;
    bool charging = false;
    uint32_t voltageMv = 3810;
    int32_t temperatureCelsius = 25;
};

struct WakeLock {
    uint64_t id = 0;
    std::string owner;
    std::string tag;
    WakeLockType type = WakeLockType::PARTIAL;
    uint64_t acquiredAt = 0;
    uint64_t timeoutMs = 0;  // 0 = no timeout (held until released)
};

struct PowerEvent {
    uint64_t id = 0;
    PowerEventType type = PowerEventType::BATTERY_CHANGED;
    PowerResult result = PowerResult::SUCCESS;
    std::string owner;
    std::string detail;
    uint64_t timestamp = 0;
};

struct PowerManagerStats {
    uint64_t batteryLevelChanges = 0;
    uint64_t lowWarnings = 0;
    uint64_t criticalWarnings = 0;
    uint64_t modeChanges = 0;
    uint64_t wakeLocksAcquired = 0;
    uint64_t wakeLocksReleased = 0;
    uint64_t wakeLocksExpired = 0;
    uint64_t suspends = 0;
    uint64_t resumes = 0;
    uint64_t hibernateRequests = 0;
    uint64_t shutdownRequests = 0;
    uint64_t rebootRequests = 0;
    uint64_t thermalTransitions = 0;
    uint64_t totalFailures = 0;
    uint64_t byBatteryState[7] = {};   // Transitions into each BatteryState
    uint64_t byPowerMode[4] = {};      // Transitions into each PowerMode
    uint64_t byEventType[13] = {};     // Per PowerEventType
    uint64_t byResult[13] = {};        // Per PowerResult
};

// ============================================================
// PowerManager - Battery, saver, wake lock and thermal service
// ============================================================

class PowerManager {
public:
    PowerManager() = default;
    ~PowerManager() { shutdown(); }

    // Lifecycle
    PowerResult initialize(size_t maxWakeLocks = 64, size_t maxEvents = 500,
                           size_t maxHistory = 500);
    PowerResult shutdown();
    bool isInitialized() const { return initialized_; }
    size_t getMaxWakeLocks() const { return maxWakeLocks_; }
    size_t getMaxEvents() const { return maxEvents_; }
    size_t getMaxHistory() const { return maxHistory_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Test hooks
    void setFailNextOperation(bool fail) { failNextOperation_ = fail; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // Battery simulation
    BatteryStatus getBatteryStatus() const { return battery_; }
    PowerResult setBatteryLevelForTesting(uint8_t percent);
    PowerResult setPowerSourceForTesting(PowerSource source);
    PowerResult setChargingForTesting(bool charging, ChargingType type);
    PowerResult setBatteryPresentForTesting(bool present);
    PowerResult simulateDrain(uint8_t percent);
    PowerResult simulateCharge(uint8_t percent);
    uint32_t estimateRemainingMinutes() const;

    // Thresholds
    uint8_t getLowThreshold() const { return lowThreshold_; }
    uint8_t getCriticalThreshold() const { return criticalThreshold_; }
    uint8_t getAutoSaverThreshold() const { return autoSaverThreshold_; }
    PowerResult setBatteryThresholds(uint8_t low, uint8_t critical, uint8_t autoSaver,
                                     const std::string& owner);

    // Power mode
    PowerResult setPowerMode(PowerMode mode, const std::string& owner);
    PowerMode getPowerMode() const { return powerMode_; }
    bool isManualModeOverride() const { return manualMode_; }
    void setAutoPowerSaverEnabled(bool enabled);
    bool isAutoPowerSaverEnabled() const { return autoPowerSaver_; }

    // Wake locks
    uint64_t acquireWakeLock(const std::string& owner, const std::string& tag,
                              WakeLockType type, uint64_t timeoutMs = 0);
    PowerResult releaseWakeLock(uint64_t id, const std::string& owner);
    PowerResult releaseWakeLocksByOwner(const std::string& owner);
    std::vector<WakeLock> getActiveWakeLocks() const;
    size_t getWakeLockCount() const { return wakeLocks_.size(); }
    PowerResult processExpiredWakeLocks();
    bool hasWakeLocks() const { return !wakeLocks_.empty(); }

    // System power state
    PowerResult requestSuspend(const std::string& owner, WakeReason reason,
                               bool force = false);
    PowerResult resume(WakeReason reason);
    PowerResult requestHibernate(const std::string& owner, bool force = false);
    PowerResult requestShutdown(const std::string& owner, bool force = false);
    PowerResult requestReboot(const std::string& owner, bool force = false);
    SystemPowerState getSystemPowerState() const { return systemState_; }
    bool isPoweredOn() const { return poweredOn_; }

    // Thermal
    PowerResult setThermalStateForTesting(ThermalState state);
    ThermalState getThermalState() const { return thermalState_; }
    uint32_t getThermalThrottlePercent() const;
    bool isThermalThrottled() const;

    // Policy queries (for other services; no hard dependencies)
    bool shouldRestrictBackgroundActivity() const;
    bool shouldRestrictNetwork() const;
    bool shouldDimDisplay() const;
    uint32_t getCpuThrottlePercent() const;

    // Events, stats and history
    std::vector<PowerEvent> getEvents(size_t limit = 0) const;
    std::vector<PowerEvent> getEventsByType(PowerEventType type, size_t limit = 0) const;
    PowerResult clearEvents();
    PowerManagerStats getStats() const;
    void resetStats();

    // Callbacks
    using BatteryCallback = std::function<void(uint8_t oldLevel, uint8_t newLevel,
                                                BatteryState newState)>;
    using PowerModeCallback = std::function<void(PowerMode oldMode, PowerMode newMode)>;
    using PowerEventCallback = std::function<void(const PowerEvent&)>;
    void setBatteryCallback(BatteryCallback cb) { batteryCb_ = cb; }
    void setPowerModeCallback(PowerModeCallback cb) { powerModeCb_ = cb; }
    void setPowerEventCallback(PowerEventCallback cb) { powerEventCb_ = cb; }

    // String helpers
    static const char* batteryStateToString(BatteryState state);
    static const char* powerSourceToString(PowerSource source);
    static const char* powerModeToString(PowerMode mode);
    static const char* systemPowerStateToString(SystemPowerState state);
    static const char* thermalStateToString(ThermalState state);
    static const char* wakeLockTypeToString(WakeLockType type);
    static const char* wakeReasonToString(WakeReason reason);
    static const char* chargingTypeToString(ChargingType type);
    static const char* powerResultToString(PowerResult result);
    static const char* powerEventTypeToString(PowerEventType type);
    static PowerMode stringToPowerMode(const std::string& str);
    static BatteryState stringToBatteryState(const std::string& str);
    static PowerResult stringToPowerResult(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxWakeLocks_ = 64;
    size_t maxEvents_ = 500;
    size_t maxHistory_ = 500;
    uint64_t nextWakeLockId_ = 1;
    uint64_t nextEventId_ = 1;

    BatteryStatus battery_;
    bool batteryPresent_ = true;
    uint8_t lowThreshold_ = 20;
    uint8_t criticalThreshold_ = 5;
    uint8_t autoSaverThreshold_ = 15;
    static constexpr uint8_t SAVER_HYSTERESIS_ = 5;

    PowerMode powerMode_ = PowerMode::BALANCED;
    bool manualMode_ = false;
    bool autoPowerSaver_ = true;

    SystemPowerState systemState_ = SystemPowerState::AWAKE;
    bool poweredOn_ = true;
    ThermalState thermalState_ = ThermalState::NORMAL;

    std::vector<WakeLock> wakeLocks_;
    std::vector<PowerEvent> events_;
    std::vector<PowerEvent> history_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    BatteryCallback batteryCb_;
    PowerModeCallback powerModeCb_;
    PowerEventCallback powerEventCb_;

    // Stats
    uint64_t batteryLevelChanges_ = 0;
    uint64_t lowWarnings_ = 0;
    uint64_t criticalWarnings_ = 0;
    uint64_t modeChanges_ = 0;
    uint64_t wakeLocksAcquired_ = 0;
    uint64_t wakeLocksReleased_ = 0;
    uint64_t wakeLocksExpired_ = 0;
    uint64_t suspends_ = 0;
    uint64_t resumes_ = 0;
    uint64_t hibernateRequests_ = 0;
    uint64_t shutdownRequests_ = 0;
    uint64_t rebootRequests_ = 0;
    uint64_t thermalTransitions_ = 0;
    uint64_t totalFailures_ = 0;
    uint64_t byBatteryState_[7] = {};
    uint64_t byPowerMode_[4] = {};
    uint64_t byEventType_[13] = {};
    uint64_t byResult_[13] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& message) const;
    void recordEvent(PowerEventType type, PowerResult result, const std::string& owner,
                     const std::string& detail);
    void moveToHistory(const PowerEvent& event);
    void updateBatteryState(const std::string& owner);
    void applyPowerMode(PowerMode newMode, const std::string& owner, bool manual);
    void applyAutoSaverRules(const std::string& owner);
    bool isSystemOwner(const std::string& owner) const;
    void forceThermalShutdown();
};

}  // namespace phantom::power
