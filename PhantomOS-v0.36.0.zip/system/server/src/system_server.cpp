/*
 * Phantom OS - System Server Implementation
 * Boot sequence management, service lifecycle, and system state control
 *
 * License: GPL-3.0
 */

#include "phantom/sysserver/system_server.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <queue>
#include <set>
#include <unordered_map>
#include <unordered_set>

namespace phantom::sysserver {

// ============================================================
// String Helpers
// ============================================================

const char* SystemServer::systemStateToString(SystemState state) {
    switch (state) {
        case SystemState::OFF: return "OFF";
        case SystemState::BOOTING: return "BOOTING";
        case SystemState::INITIALIZING: return "INITIALIZING";
        case SystemState::RUNNING: return "RUNNING";
        case SystemState::SHUTTING_DOWN: return "SHUTTING_DOWN";
        case SystemState::REBOOTING: return "REBOOTING";
        case SystemState::ERROR_STATE: return "ERROR_STATE";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::serviceStateToString(ServiceState state) {
    switch (state) {
        case ServiceState::STOPPED: return "STOPPED";
        case ServiceState::STARTING: return "STARTING";
        case ServiceState::RUNNING: return "RUNNING";
        case ServiceState::STOPPING: return "STOPPING";
        case ServiceState::FAILED: return "FAILED";
        case ServiceState::RESTARTING: return "RESTARTING";
        case ServiceState::DISABLED: return "DISABLED";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::serviceGroupToString(ServiceGroup group) {
    switch (group) {
        case ServiceGroup::CORE: return "CORE";
        case ServiceGroup::SYSTEM: return "SYSTEM";
        case ServiceGroup::NETWORK: return "NETWORK";
        case ServiceGroup::APPS: return "APPS";
        case ServiceGroup::OPTIONAL: return "OPTIONAL";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::bootPhaseToString(BootPhase phase) {
    switch (phase) {
        case BootPhase::PRE_INIT: return "PRE_INIT";
        case BootPhase::INIT: return "INIT";
        case BootPhase::CORE_SERVICES: return "CORE_SERVICES";
        case BootPhase::SYSTEM_SERVICES: return "SYSTEM_SERVICES";
        case BootPhase::APP_SERVICES: return "APP_SERVICES";
        case BootPhase::POST_BOOT: return "POST_BOOT";
        case BootPhase::COMPLETE: return "COMPLETE";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::serviceTypeToString(ServiceType type) {
    switch (type) {
        case ServiceType::NATIVE: return "NATIVE";
        case ServiceType::HAL: return "HAL";
        case ServiceType::DAEMON: return "DAEMON";
        case ServiceType::APP: return "APP";
        case ServiceType::DRIVER: return "DRIVER";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::healthStatusToString(HealthStatus status) {
    switch (status) {
        case HealthStatus::UNKNOWN: return "UNKNOWN";
        case HealthStatus::HEALTHY: return "HEALTHY";
        case HealthStatus::DEGRADED: return "DEGRADED";
        case HealthStatus::UNHEALTHY: return "UNHEALTHY";
        case HealthStatus::CRITICAL: return "CRITICAL";
        default: return "UNKNOWN";
    }
}

const char* SystemServer::initResultToString(InitResult result) {
    switch (result) {
        case InitResult::SUCCESS: return "SUCCESS";
        case InitResult::ALREADY_RUNNING: return "ALREADY_RUNNING";
        case InitResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case InitResult::SERVICE_NOT_FOUND: return "SERVICE_NOT_FOUND";
        case InitResult::SERVICE_FAILED: return "SERVICE_FAILED";
        case InitResult::DEPENDENCY_FAILED: return "DEPENDENCY_FAILED";
        case InitResult::INVALID_STATE: return "INVALID_STATE";
        case InitResult::TIMEOUT: return "TIMEOUT";
        case InitResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        default: return "UNKNOWN";
    }
}

// ============================================================
// Lifecycle
// ============================================================

InitResult SystemServer::initialize() {
    if (initialized_) return InitResult::ALREADY_RUNNING;

    systemState_ = SystemState::OFF;
    bootPhase_ = BootPhase::PRE_INIT;
    services_.clear();
    bootEvents_.clear();
    nextServiceId_ = 1;
    nextBootEventId_ = 1;

    buildDefaultServices();
    registerDefaultServices();

    initialized_ = true;
    initStartTime_ = getCurrentTimeMs();

    logBootEvent("System server initialized", BootPhase::PRE_INIT);

    return InitResult::SUCCESS;
}

InitResult SystemServer::boot() {
    if (!initialized_) return InitResult::NOT_INITIALIZED;
    if (systemState_ == SystemState::RUNNING) return InitResult::ALREADY_RUNNING;

    bootStartTime_ = getCurrentTimeMs();
    setSystemState(SystemState::BOOTING);

    InitResult result = runBootSequence();

    if (result == InitResult::SUCCESS) {
        setSystemState(SystemState::RUNNING);
    } else {
        setSystemState(SystemState::ERROR_STATE);
    }

    return result;
}

InitResult SystemServer::shutdown() {
    if (!initialized_) return InitResult::NOT_INITIALIZED;
    if (systemState_ == SystemState::OFF) return InitResult::SUCCESS;

    setSystemState(SystemState::SHUTTING_DOWN);

    // Stop all services in reverse dependency order
    auto order = getStartupOrder();
    std::reverse(order.begin(), order.end());

    for (const auto& name : order) {
        stopService(name);
    }

    services_.clear();
    bootEvents_.clear();
    defaultServices_.clear();
    nextServiceId_ = 1;
    nextBootEventId_ = 1;
    bootPhase_ = BootPhase::PRE_INIT;
    stateChangeCb_ = nullptr;
    serviceStateCb_ = nullptr;
    bootEventCb_ = nullptr;

    setSystemState(SystemState::OFF);
    initialized_ = false;

    return InitResult::SUCCESS;
}

InitResult SystemServer::reboot() {
    if (!initialized_) return InitResult::NOT_INITIALIZED;

    setSystemState(SystemState::REBOOTING);

    // Stop all services
    auto order = getStartupOrder();
    std::reverse(order.begin(), order.end());
    for (const auto& name : order) {
        stopService(name);
    }

    // Reset states
    for (auto& s : services_) {
        s.state = ServiceState::STOPPED;
        s.restartCount = 0;
        s.pid = -1;
    }

    bootPhase_ = BootPhase::PRE_INIT;

    // Re-run boot sequence
    setSystemState(SystemState::BOOTING);
    InitResult result = runBootSequence();

    if (result == InitResult::SUCCESS) {
        setSystemState(SystemState::RUNNING);
    } else {
        setSystemState(SystemState::ERROR_STATE);
    }

    return result;
}

// ============================================================
// Service Management
// ============================================================

uint32_t SystemServer::registerService(const ServiceInfo& service) {
    // Check for duplicate name
    if (findService(service.name) != nullptr) {
        return 0;
    }

    ServiceInfo s = service;
    s.id = nextServiceId_++;
    s.state = ServiceState::STOPPED;
    s.health = HealthStatus::UNKNOWN;
    services_.push_back(s);
    return s.id;
}

bool SystemServer::unregisterService(const std::string& name) {
    auto it = std::find_if(services_.begin(), services_.end(),
                           [&name](const ServiceInfo& s) { return s.name == name; });
    if (it == services_.end()) return false;
    services_.erase(it);
    return true;
}

ServiceInfo SystemServer::getService(const std::string& name) const {
    const auto* s = findService(name);
    if (s) return *s;
    return ServiceInfo{};
}

ServiceInfo SystemServer::getServiceById(uint32_t id) const {
    const auto* s = findServiceById(id);
    if (s) return *s;
    return ServiceInfo{};
}

std::vector<ServiceInfo> SystemServer::getServices() const {
    return services_;
}

std::vector<ServiceInfo> SystemServer::getServicesByGroup(ServiceGroup group) const {
    std::vector<ServiceInfo> result;
    for (const auto& s : services_) {
        if (s.group == group) result.push_back(s);
    }
    return result;
}

std::vector<ServiceInfo> SystemServer::getServicesByState(ServiceState state) const {
    std::vector<ServiceInfo> result;
    for (const auto& s : services_) {
        if (s.state == state) result.push_back(s);
    }
    return result;
}

size_t SystemServer::getServiceCount() const {
    return services_.size();
}

size_t SystemServer::getRunningServiceCount() const {
    size_t count = 0;
    for (const auto& s : services_) {
        if (s.state == ServiceState::RUNNING) count++;
    }
    return count;
}

size_t SystemServer::getFailedServiceCount() const {
    size_t count = 0;
    for (const auto& s : services_) {
        if (s.state == ServiceState::FAILED) count++;
    }
    return count;
}

// ============================================================
// Service Lifecycle
// ============================================================

InitResult SystemServer::startService(const std::string& name) {
    ServiceInfo* s = findService(name);
    if (!s) return InitResult::SERVICE_NOT_FOUND;

    if (s->state == ServiceState::RUNNING) return InitResult::ALREADY_RUNNING;
    if (s->state == ServiceState::DISABLED) return InitResult::INVALID_STATE;

    // Check dependencies
    if (!areDependenciesRunning(name)) {
        setServiceState(*s, ServiceState::FAILED);
        s->health = HealthStatus::CRITICAL;
        return InitResult::DEPENDENCY_FAILED;
    }

    setServiceState(*s, ServiceState::STARTING);
    s->startTime = getCurrentTimeMs();
    s->pid = static_cast<int32_t>(s->id + 1000);  // Simulated PID

    setServiceState(*s, ServiceState::RUNNING);
    s->health = HealthStatus::HEALTHY;

    return InitResult::SUCCESS;
}

InitResult SystemServer::stopService(const std::string& name) {
    ServiceInfo* s = findService(name);
    if (!s) return InitResult::SERVICE_NOT_FOUND;

    if (s->state == ServiceState::STOPPED) return InitResult::SUCCESS;

    setServiceState(*s, ServiceState::STOPPING);
    s->pid = -1;
    setServiceState(*s, ServiceState::STOPPED);
    s->health = HealthStatus::UNKNOWN;

    return InitResult::SUCCESS;
}

InitResult SystemServer::restartService(const std::string& name) {
    ServiceInfo* s = findService(name);
    if (!s) return InitResult::SERVICE_NOT_FOUND;

    setServiceState(*s, ServiceState::RESTARTING);
    s->restartCount++;

    stopService(name);
    InitResult result = startService(name);

    return result;
}

InitResult SystemServer::enableService(const std::string& name) {
    ServiceInfo* s = findService(name);
    if (!s) return InitResult::SERVICE_NOT_FOUND;

    if (s->state == ServiceState::DISABLED) {
        setServiceState(*s, ServiceState::STOPPED);
    }
    s->autoStart = true;
    return InitResult::SUCCESS;
}

InitResult SystemServer::disableService(const std::string& name) {
    ServiceInfo* s = findService(name);
    if (!s) return InitResult::SERVICE_NOT_FOUND;

    if (s->state == ServiceState::RUNNING) {
        stopService(name);
    }
    setServiceState(*s, ServiceState::DISABLED);
    s->autoStart = false;
    return InitResult::SUCCESS;
}

// ============================================================
// Boot Sequence
// ============================================================

InitResult SystemServer::runBootSequence() {
    setBootPhase(BootPhase::INIT);
    logBootEvent("Boot sequence started", BootPhase::INIT);

    // Get startup order respecting dependencies
    auto order = getStartupOrder();

    // Phase: Core services
    setBootPhase(BootPhase::CORE_SERVICES);
    logBootEvent("Starting core services", BootPhase::CORE_SERVICES);
    for (const auto& name : order) {
        ServiceInfo* s = findService(name);
        if (s && s->group == ServiceGroup::CORE && s->autoStart) {
            InitResult r = startService(name);
            if (r != InitResult::SUCCESS && r != InitResult::ALREADY_RUNNING) {
                logBootEvent("Core service failed: " + name, BootPhase::CORE_SERVICES, true);
                return InitResult::SERVICE_FAILED;
            }
        }
    }

    // Phase: System services
    setBootPhase(BootPhase::SYSTEM_SERVICES);
    logBootEvent("Starting system services", BootPhase::SYSTEM_SERVICES);
    for (const auto& name : order) {
        ServiceInfo* s = findService(name);
        if (s && (s->group == ServiceGroup::SYSTEM || s->group == ServiceGroup::NETWORK) && s->autoStart) {
            InitResult r = startService(name);
            if (r != InitResult::SUCCESS && r != InitResult::ALREADY_RUNNING) {
                logBootEvent("System service failed: " + name, BootPhase::SYSTEM_SERVICES, true);
                // Non-fatal for system services, continue
            }
        }
    }

    // Phase: App services
    setBootPhase(BootPhase::APP_SERVICES);
    logBootEvent("Starting app services", BootPhase::APP_SERVICES);
    for (const auto& name : order) {
        ServiceInfo* s = findService(name);
        if (s && s->group == ServiceGroup::APPS && s->autoStart) {
            startService(name);  // Non-fatal
        }
    }

    // Phase: Optional services
    for (const auto& name : order) {
        ServiceInfo* s = findService(name);
        if (s && s->group == ServiceGroup::OPTIONAL && s->autoStart) {
            startService(name);  // Non-fatal
        }
    }

    // Post-boot
    setBootPhase(BootPhase::POST_BOOT);
    logBootEvent("Post-boot phase", BootPhase::POST_BOOT);

    setBootPhase(BootPhase::COMPLETE);
    logBootEvent("Boot sequence complete", BootPhase::COMPLETE);

    return InitResult::SUCCESS;
}

std::vector<BootEvent> SystemServer::getBootEvents() const {
    return bootEvents_;
}

size_t SystemServer::getBootEventCount() const {
    return bootEvents_.size();
}

void SystemServer::clearBootEvents() {
    bootEvents_.clear();
}

// ============================================================
// Dependency Resolution
// ============================================================

std::vector<std::string> SystemServer::resolveDependencies(const std::string& serviceName) const {
    std::vector<std::string> result;
    std::unordered_set<std::string> visited;
    std::function<void(const std::string&)> visit = [&](const std::string& name) {
        if (visited.count(name)) return;
        visited.insert(name);
        const auto* s = findService(name);
        if (!s) return;
        for (const auto& dep : s->dependencies) {
            visit(dep);
        }
        result.push_back(name);
    };
    visit(serviceName);
    return result;
}

bool SystemServer::hasCircularDependency(const std::string& serviceName) const {
    std::unordered_set<std::string> visiting;
    std::unordered_set<std::string> visited;

    std::function<bool(const std::string&)> visit = [&](const std::string& name) -> bool {
        if (visiting.count(name)) return true;  // Cycle detected
        if (visited.count(name)) return false;

        visiting.insert(name);
        const auto* s = findService(name);
        if (s) {
            for (const auto& dep : s->dependencies) {
                if (visit(dep)) return true;
            }
        }
        visiting.erase(name);
        visited.insert(name);
        return false;
    };

    return visit(serviceName);
}

std::vector<std::string> SystemServer::getStartupOrder() const {
    // Topological sort respecting dependencies and priority
    std::vector<std::string> result;
    std::unordered_set<std::string> visited;
    std::unordered_set<std::string> visiting;

    // Sort services by priority first (lower = higher priority)
    std::vector<ServiceInfo> sorted = services_;
    std::sort(sorted.begin(), sorted.end(), [](const ServiceInfo& a, const ServiceInfo& b) {
        return a.priority < b.priority;
    });

    std::function<void(const std::string&)> visit = [&](const std::string& name) {
        if (visited.count(name) || visiting.count(name)) return;
        visiting.insert(name);
        const auto* s = findService(name);
        if (s) {
            for (const auto& dep : s->dependencies) {
                visit(dep);
            }
        }
        visiting.erase(name);
        visited.insert(name);
        result.push_back(name);
    };

    for (const auto& s : sorted) {
        visit(s.name);
    }

    return result;
}

// ============================================================
// Health Monitoring
// ============================================================

HealthStatus SystemServer::getServiceHealth(const std::string& name) const {
    const auto* s = findService(name);
    if (!s) return HealthStatus::UNKNOWN;
    return s->health;
}

HealthStatus SystemServer::getOverallHealth() const {
    if (services_.empty()) return HealthStatus::UNKNOWN;

    bool hasCritical = false;
    bool hasUnhealthy = false;
    bool hasDegraded = false;

    for (const auto& s : services_) {
        if (s.state == ServiceState::DISABLED) continue;
        if (s.health == HealthStatus::CRITICAL) hasCritical = true;
        else if (s.health == HealthStatus::UNHEALTHY) hasUnhealthy = true;
        else if (s.health == HealthStatus::DEGRADED) hasDegraded = true;
    }

    if (hasCritical) return HealthStatus::CRITICAL;
    if (hasUnhealthy) return HealthStatus::UNHEALTHY;
    if (hasDegraded) return HealthStatus::DEGRADED;
    return HealthStatus::HEALTHY;
}

void SystemServer::setHealthStatus(const std::string& name, HealthStatus status) {
    ServiceInfo* s = findService(name);
    if (s) {
        s->health = status;
    }
}

void SystemServer::runHealthCheck() {
    for (auto& s : services_) {
        if (s.state == ServiceState::RUNNING) {
            s.uptime = getCurrentTimeMs() - s.startTime;
            if (s.health == HealthStatus::UNKNOWN) {
                s.health = HealthStatus::HEALTHY;
            }
        } else if (s.state == ServiceState::FAILED) {
            s.health = HealthStatus::CRITICAL;
        }
    }
}

// ============================================================
// Auto-restart
// ============================================================

void SystemServer::setAutoRestart(const std::string& name, bool enabled) {
    ServiceInfo* s = findService(name);
    if (s) {
        s->autoRestart = enabled;
    }
}

void SystemServer::checkFailedServices() {
    for (auto& s : services_) {
        if (s.state == ServiceState::FAILED && s.autoRestart && s.restartCount < s.maxRestarts) {
            restartService(s.name);
        }
    }
}

uint32_t SystemServer::getRestartCount(const std::string& name) const {
    const auto* s = findService(name);
    if (s) return s->restartCount;
    return 0;
}

// ============================================================
// System Stats
// ============================================================

SystemStats SystemServer::getSystemStats() const {
    SystemStats stats;
    stats.totalServices = static_cast<uint32_t>(services_.size());

    for (const auto& s : services_) {
        if (s.state == ServiceState::RUNNING) stats.runningServices++;
        if (s.state == ServiceState::FAILED) stats.failedServices++;
        if (s.state == ServiceState::DISABLED) stats.disabledServices++;
        stats.totalRestarts += s.restartCount;
    }

    stats.bootTime = bootStartTime_ > 0 ? (getCurrentTimeMs() - bootStartTime_) : 0;
    stats.initTime = initStartTime_ > 0 ? (getCurrentTimeMs() - initStartTime_) : 0;
    stats.overallHealth = getOverallHealth();

    return stats;
}

void SystemServer::resetStats() {
    for (auto& s : services_) {
        s.restartCount = 0;
    }
}

// ============================================================
// Default Services
// ============================================================

void SystemServer::buildDefaultServices() {
    defaultServices_.clear();

    // Core services (priority 0-19)
    ServiceInfo hal;
    hal.name = "hal_service";
    hal.description = "Hardware Abstraction Layer service";
    hal.group = ServiceGroup::CORE;
    hal.type = ServiceType::HAL;
    hal.priority = 0;
    defaultServices_.push_back(hal);

    ServiceInfo config;
    config.name = "config_service";
    config.description = "System configuration service";
    config.group = ServiceGroup::CORE;
    config.type = ServiceType::NATIVE;
    config.priority = 5;
    config.dependencies = {"hal_service"};
    defaultServices_.push_back(config);

    ServiceInfo privacyd;
    privacyd.name = "privacy_service";
    privacyd.description = "Privacy management service";
    privacyd.group = ServiceGroup::CORE;
    privacyd.type = ServiceType::NATIVE;
    privacyd.priority = 10;
    privacyd.dependencies = {"config_service"};
    defaultServices_.push_back(privacyd);

    ServiceInfo sandbox;
    sandbox.name = "sandbox_service";
    sandbox.description = "App sandbox management service";
    sandbox.group = ServiceGroup::CORE;
    sandbox.type = ServiceType::NATIVE;
    sandbox.priority = 15;
    sandbox.dependencies = {"privacy_service"};
    defaultServices_.push_back(sandbox);

    // System services (priority 20-39)
    ServiceInfo ipc;
    ipc.name = "ipc_service";
    ipc.description = "Inter-process communication bus";
    ipc.group = ServiceGroup::SYSTEM;
    ipc.type = ServiceType::DAEMON;
    ipc.priority = 20;
    ipc.dependencies = {"sandbox_service"};
    defaultServices_.push_back(ipc);

    ServiceInfo pkgmgr;
    pkgmgr.name = "package_manager_service";
    pkgmgr.description = "Package manager service";
    pkgmgr.group = ServiceGroup::SYSTEM;
    pkgmgr.type = ServiceType::NATIVE;
    pkgmgr.priority = 25;
    pkgmgr.dependencies = {"ipc_service"};
    defaultServices_.push_back(pkgmgr);

    ServiceInfo lifecycle;
    lifecycle.name = "app_lifecycle_service";
    lifecycle.description = "Application lifecycle manager";
    lifecycle.group = ServiceGroup::SYSTEM;
    lifecycle.type = ServiceType::NATIVE;
    lifecycle.priority = 30;
    lifecycle.dependencies = {"package_manager_service"};
    defaultServices_.push_back(lifecycle);

    ServiceInfo linuxcompat;
    linuxcompat.name = "linux_compat_service";
    linuxcompat.description = "Linux compatibility layer service";
    linuxcompat.group = ServiceGroup::SYSTEM;
    linuxcompat.type = ServiceType::NATIVE;
    linuxcompat.priority = 35;
    linuxcompat.dependencies = {"app_lifecycle_service"};
    defaultServices_.push_back(linuxcompat);

    // Network services (priority 40-49)
    ServiceInfo network;
    network.name = "network_service";
    network.description = "Network management service";
    network.group = ServiceGroup::NETWORK;
    network.type = ServiceType::DAEMON;
    network.priority = 40;
    network.dependencies = {"hal_service"};
    defaultServices_.push_back(network);

    ServiceInfo nids;
    nids.name = "nids_service";
    nids.description = "Network intrusion detection service";
    nids.group = ServiceGroup::NETWORK;
    nids.type = ServiceType::DAEMON;
    nids.priority = 45;
    nids.dependencies = {"network_service"};
    defaultServices_.push_back(nids);

    // App services (priority 50-69)
    ServiceInfo settings;
    settings.name = "settings_app";
    settings.description = "Settings application";
    settings.group = ServiceGroup::APPS;
    settings.type = ServiceType::APP;
    settings.priority = 50;
    settings.dependencies = {"config_service"};
    defaultServices_.push_back(settings);

    ServiceInfo terminal;
    terminal.name = "terminal_app";
    terminal.description = "Terminal application";
    terminal.group = ServiceGroup::APPS;
    terminal.type = ServiceType::APP;
    terminal.priority = 55;
    terminal.dependencies = {"linux_compat_service"};
    defaultServices_.push_back(terminal);

    ServiceInfo filemanager;
    filemanager.name = "file_manager_app";
    filemanager.description = "File manager application";
    filemanager.group = ServiceGroup::APPS;
    filemanager.type = ServiceType::APP;
    filemanager.priority = 60;
    filemanager.dependencies = {"sandbox_service"};
    defaultServices_.push_back(filemanager);

    ServiceInfo sysmon;
    sysmon.name = "system_monitor_app";
    sysmon.description = "System monitor application";
    sysmon.group = ServiceGroup::APPS;
    sysmon.type = ServiceType::APP;
    sysmon.priority = 65;
    sysmon.dependencies = {"hal_service", "linux_compat_service"};
    defaultServices_.push_back(sysmon);

    // Optional services (priority 70+)
    ServiceInfo telemetry;
    telemetry.name = "telemetry_service";
    telemetry.description = "Optional telemetry service (disabled by default for privacy)";
    telemetry.group = ServiceGroup::OPTIONAL;
    telemetry.type = ServiceType::DAEMON;
    telemetry.priority = 100;
    telemetry.autoStart = false;
    defaultServices_.push_back(telemetry);
}

void SystemServer::registerDefaultServices() {
    for (const auto& s : defaultServices_) {
        registerService(s);
    }
}

// ============================================================
// Private Helpers
// ============================================================

void SystemServer::setSystemState(SystemState newState) {
    SystemState oldState = systemState_;
    systemState_ = newState;
    if (stateChangeCb_ && oldState != newState) {
        stateChangeCb_(oldState, newState);
    }
}

void SystemServer::setBootPhase(BootPhase phase) {
    bootPhase_ = phase;
}

void SystemServer::setServiceState(ServiceInfo& service, ServiceState newState) {
    ServiceState oldState = service.state;
    service.state = newState;
    if (serviceStateCb_ && oldState != newState) {
        serviceStateCb_(service.name, oldState, newState);
    }
}

void SystemServer::logBootEvent(const std::string& message, BootPhase phase, bool isError) {
    BootEvent event;
    event.id = nextBootEventId_++;
    event.message = message;
    event.phase = phase;
    event.systemState = systemState_;
    event.timestamp = getCurrentTimeMs();
    event.isError = isError;
    bootEvents_.push_back(event);

    if (bootEventCb_) bootEventCb_(event);
}

bool SystemServer::checkDependencies(const ServiceInfo& service) const {
    for (const auto& dep : service.dependencies) {
        if (findService(dep) == nullptr) return false;
    }
    return true;
}

bool SystemServer::areDependenciesRunning(const std::string& serviceName) const {
    const auto* s = findService(serviceName);
    if (!s) return false;

    for (const auto& dep : s->dependencies) {
        const auto* depService = findService(dep);
        if (!depService) return false;
        if (depService->state != ServiceState::RUNNING) return false;
    }
    return true;
}

ServiceInfo* SystemServer::findService(const std::string& name) {
    for (auto& s : services_) {
        if (s.name == name) return &s;
    }
    return nullptr;
}

const ServiceInfo* SystemServer::findService(const std::string& name) const {
    for (const auto& s : services_) {
        if (s.name == name) return &s;
    }
    return nullptr;
}

ServiceInfo* SystemServer::findServiceById(uint32_t id) {
    for (auto& s : services_) {
        if (s.id == id) return &s;
    }
    return nullptr;
}

const ServiceInfo* SystemServer::findServiceById(uint32_t id) const {
    for (const auto& s : services_) {
        if (s.id == id) return &s;
    }
    return nullptr;
}

uint64_t SystemServer::getCurrentTimeMs() const {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}

}  // namespace phantom::sysserver
