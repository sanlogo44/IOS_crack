/*
 * Phantom OS - System Server / Init Process
 * Boot sequence management, service lifecycle, and system state control
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <chrono>

namespace phantom::sysserver {

// ============================================================
// Enums
// ============================================================

enum class SystemState {
    OFF,
    BOOTING,
    INITIALIZING,
    RUNNING,
    SHUTTING_DOWN,
    REBOOTING,
    ERROR_STATE
};

enum class ServiceState {
    STOPPED,
    STARTING,
    RUNNING,
    STOPPING,
    FAILED,
    RESTARTING,
    DISABLED
};

enum class ServiceGroup {
    CORE,       // Essential system services (init, hal, config)
    SYSTEM,     // System services (ipc, sandbox, package_manager)
    NETWORK,    // Network services (nids, network_service)
    APPS,       // Application services (settings, terminal, file_manager, sysmon)
    OPTIONAL    // Non-essential services
};

enum class BootPhase {
    PRE_INIT,      // Before init
    INIT,          // Init phase
    CORE_SERVICES, // Core services starting
    SYSTEM_SERVICES, // System services starting
    APP_SERVICES,  // App services starting
    POST_BOOT,     // After all services
    COMPLETE       // Boot complete
};

enum class ServiceType {
    NATIVE,      // C++ service
    HAL,         // Hardware abstraction
    DAEMON,      // Background daemon
    APP,         // Application
    DRIVER       // Device driver
};

enum class HealthStatus {
    UNKNOWN,
    HEALTHY,
    DEGRADED,
    UNHEALTHY,
    CRITICAL
};

enum class InitResult {
    SUCCESS,
    ALREADY_RUNNING,
    NOT_INITIALIZED,
    SERVICE_NOT_FOUND,
    SERVICE_FAILED,
    DEPENDENCY_FAILED,
    INVALID_STATE,
    TIMEOUT,
    PERMISSION_DENIED
};

// ============================================================
// Structs
// ============================================================

struct ServiceInfo {
    uint32_t id = 0;
    std::string name;
    std::string description;
    ServiceGroup group = ServiceGroup::OPTIONAL;
    ServiceType type = ServiceType::NATIVE;
    ServiceState state = ServiceState::STOPPED;
    HealthStatus health = HealthStatus::UNKNOWN;
    std::vector<std::string> dependencies;
    std::vector<std::string> dependents;
    bool autoStart = true;
    bool autoRestart = true;
    uint32_t restartCount = 0;
    uint32_t maxRestarts = 3;
    uint64_t startTime = 0;
    uint64_t uptime = 0;
    int32_t pid = -1;
    std::string startupArgs;
    uint32_t priority = 50;  // Lower = higher priority
};

struct BootEvent {
    uint32_t id = 0;
    std::string message;
    BootPhase phase = BootPhase::PRE_INIT;
    SystemState systemState = SystemState::OFF;
    uint64_t timestamp = 0;
    bool isError = false;
};

struct SystemStats {
    uint32_t totalServices = 0;
    uint32_t runningServices = 0;
    uint32_t failedServices = 0;
    uint32_t disabledServices = 0;
    uint64_t bootTime = 0;       // Total boot time in ms
    uint64_t initTime = 0;        // Init phase time
    uint32_t totalRestarts = 0;
    uint32_t healthChecks = 0;
    HealthStatus overallHealth = HealthStatus::UNKNOWN;
};

// ============================================================
// SystemServer - Core Init/Service Manager
// ============================================================

class SystemServer {
public:
    SystemServer() = default;
    ~SystemServer() { shutdown(); }

    // Lifecycle
    InitResult initialize();
    InitResult boot();
    InitResult shutdown();
    InitResult reboot();
    bool isInitialized() const { return initialized_; }
    bool isRunning() const { return systemState_ == SystemState::RUNNING; }
    SystemState getSystemState() const { return systemState_; }
    BootPhase getBootPhase() const { return bootPhase_; }

    // Service management
    uint32_t registerService(const ServiceInfo& service);
    bool unregisterService(const std::string& name);
    ServiceInfo getService(const std::string& name) const;
    ServiceInfo getServiceById(uint32_t id) const;
    std::vector<ServiceInfo> getServices() const;
    std::vector<ServiceInfo> getServicesByGroup(ServiceGroup group) const;
    std::vector<ServiceInfo> getServicesByState(ServiceState state) const;
    size_t getServiceCount() const;
    size_t getRunningServiceCount() const;
    size_t getFailedServiceCount() const;

    // Service lifecycle
    InitResult startService(const std::string& name);
    InitResult stopService(const std::string& name);
    InitResult restartService(const std::string& name);
    InitResult enableService(const std::string& name);
    InitResult disableService(const std::string& name);

    // Boot sequence
    InitResult runBootSequence();
    BootPhase getCurrentBootPhase() const { return bootPhase_; }
    std::vector<BootEvent> getBootEvents() const;
    size_t getBootEventCount() const;
    void clearBootEvents();

    // Dependency resolution
    std::vector<std::string> resolveDependencies(const std::string& serviceName) const;
    bool hasCircularDependency(const std::string& serviceName) const;
    std::vector<std::string> getStartupOrder() const;

    // Health monitoring
    HealthStatus getServiceHealth(const std::string& name) const;
    HealthStatus getOverallHealth() const;
    void setHealthStatus(const std::string& name, HealthStatus status);
    void runHealthCheck();

    // Auto-restart
    void setAutoRestart(const std::string& name, bool enabled);
    void checkFailedServices();
    uint32_t getRestartCount(const std::string& name) const;

    // System stats
    SystemStats getSystemStats() const;
    void resetStats();

    // Callbacks
    using StateChangeCallback = std::function<void(SystemState oldState, SystemState newState)>;
    void setStateChangeCallback(StateChangeCallback cb) { stateChangeCb_ = cb; }

    using ServiceStateCallback = std::function<void(const std::string& name, ServiceState oldState, ServiceState newState)>;
    void setServiceStateCallback(ServiceStateCallback cb) { serviceStateCb_ = cb; }

    using BootEventCallback = std::function<void(const BootEvent&)>;
    void setBootEventCallback(BootEventCallback cb) { bootEventCb_ = cb; }

    // String helpers
    static const char* systemStateToString(SystemState state);
    static const char* serviceStateToString(ServiceState state);
    static const char* serviceGroupToString(ServiceGroup group);
    static const char* bootPhaseToString(BootPhase phase);
    static const char* serviceTypeToString(ServiceType type);
    static const char* healthStatusToString(HealthStatus status);
    static const char* initResultToString(InitResult result);

    // Default services
    void registerDefaultServices();
    size_t getDefaultServiceCount() const { return defaultServices_.size(); }

private:
    bool initialized_ = false;
    SystemState systemState_ = SystemState::OFF;
    BootPhase bootPhase_ = BootPhase::PRE_INIT;

    std::vector<ServiceInfo> services_;
    uint32_t nextServiceId_ = 1;

    std::vector<BootEvent> bootEvents_;
    uint32_t nextBootEventId_ = 1;

    uint64_t bootStartTime_ = 0;
    uint64_t initStartTime_ = 0;

    // Default service definitions
    std::vector<ServiceInfo> defaultServices_;

    // Callbacks
    StateChangeCallback stateChangeCb_;
    ServiceStateCallback serviceStateCb_;
    BootEventCallback bootEventCb_;

    // Internal helpers
    void setSystemState(SystemState newState);
    void setBootPhase(BootPhase phase);
    void setServiceState(ServiceInfo& service, ServiceState newState);
    void logBootEvent(const std::string& message, BootPhase phase, bool isError = false);
    bool checkDependencies(const ServiceInfo& service) const;
    bool areDependenciesRunning(const std::string& serviceName) const;
    ServiceInfo* findService(const std::string& name);
    const ServiceInfo* findService(const std::string& name) const;
    ServiceInfo* findServiceById(uint32_t id);
    const ServiceInfo* findServiceById(uint32_t id) const;
    uint64_t getCurrentTimeMs() const;
    void buildDefaultServices();
};

}  // namespace phantom::sysserver
