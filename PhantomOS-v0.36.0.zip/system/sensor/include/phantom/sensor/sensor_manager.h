/*
 * Phantom OS - Sensor Manager
 * v0.29.0 - License: GPL-3.0
 *
 * Privacy-first sensor service: sensor management (accelerometer,
 * gyroscope, magnetometer, proximity, ambient light, barometer, step
 * counter, heart-rate stub, device-orientation fused stub, mock),
 * per-app sensor access control with foreground-only and coarse-motion
 * enforcement, sensor requests with interval/batching/flush, mock sensor
 * for testing, sensor history with per-app isolation and privacy
 * redaction, events, stats, callbacks and optional LogServer/CrashReporter
 * integration.
 *
 * All data is simulated in-memory. Sensor readings are deterministic mock
 * values, not real hardware data. Coarse-motion transforms are deterministic
 * (precision reduction), not random. LogServer must never log raw sensor
 * vectors.
 */

#ifndef PHANTOM_SENSOR_SENSOR_MANAGER_H
#define PHANTOM_SENSOR_SENSOR_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace sensor {

// ============================================================
// Constants
// ============================================================

static const uint32_t SENSOR_PRIVACY_NONE = 0;
static const uint32_t SENSOR_PRIVACY_COARSE_MOTION = 1 << 0;
static const uint32_t SENSOR_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t SENSOR_PRIVACY_REDACT_PRECISION = 1 << 2;
static const uint32_t SENSOR_PRIVACY_REQUIRE_FOREGROUND = 1 << 3;
static const uint32_t SENSOR_PRIVACY_MOCK_ALLOWED = 1 << 4;
static const uint32_t SENSOR_PRIVACY_RATE_LIMIT = 1 << 5;
static const uint32_t SENSOR_PRIVACY_DISABLE_BIOMETRIC_HEALTH = 1 << 6;

static const uint64_t SENSOR_DEFAULT_REQUEST_TIMEOUT_MS = 60000;
static const uint64_t SENSOR_DEFAULT_MAX_REPORT_LATENCY_MS = 10000;
static const uint32_t SENSOR_DEFAULT_MAX_SAMPLE_RATE_HZ = 100;
static const uint32_t SENSOR_BATCH_DEFAULT_CAPACITY = 256;

// ============================================================
// Enums
// ============================================================

enum class SensorType : uint8_t {
    ACCELEROMETER = 0,
    GYROSCOPE,
    MAGNETOMETER,
    PROXIMITY,
    AMBIENT_LIGHT,
    BAROMETER,
    STEP_COUNTER,
    HEART_RATE_STUB,
    DEVICE_ORIENTATION_FUSED,
    MOCK,
    // Sentinel for array sizing
    COUNT
};

enum class SensorState : uint8_t {
    DISABLED = 0,
    IDLE,
    SEARCHING,
    AVAILABLE,
    TEMP_UNAVAILABLE,
    FAILED
};

enum class SensorAccuracy : uint8_t {
    NONE = 0,
    LOW,
    MEDIUM,
    HIGH,
    UNKNOWN
};

enum class SensorPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class SensorRequestState : uint8_t {
    ACTIVE = 0,
    PAUSED,
    EXPIRED,
    CANCELLED
};

enum class SensorPrivacyMode : uint8_t {
    FULL = 0,
    COARSE,
    NO_RAW
};

enum class SensorResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    SENSOR_DISABLED,
    READING_UNAVAILABLE,
    REQUEST_NOT_FOUND,
    CAPACITY_EXCEEDED,
    MOCK_NOT_ALLOWED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE,
    FLUSH_FAILED
};

enum class SensorEventType : uint8_t {
    SENSOR_ENABLED = 0,
    SENSOR_DISABLED,
    READING_UPDATED,
    READING_DELIVERED,
    READING_DENIED,
    PERMISSION_CHANGED,
    REQUEST_STARTED,
    REQUEST_CANCELLED,
    REQUEST_EXPIRED,
    FLUSH_COMPLETED,
    MOCK_READING_SET,
    HISTORY_CLEARED,
    PRIVACY_APPLIED,
    SENSOR_FAILED,
    SENSOR_RECOVERED,
    BATCH_OVERFLOW,
    RATE_THROTTLED
};

// ============================================================
// Data structures
// ============================================================

struct SensorReading {
    double values[6] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};  // Multi-axis support
    uint8_t valueCount = 0;
    SensorType sensor = SensorType::ACCELEROMETER;
    SensorAccuracy accuracy = SensorAccuracy::UNKNOWN;
    uint64_t timestamp = 0;
    uint64_t timestampNanos = 0;
    uint32_t privacyFlags = SENSOR_PRIVACY_NONE;
    bool mock = false;
};

struct SensorInfo {
    SensorType sensor = SensorType::ACCELEROMETER;
    SensorState state = SensorState::DISABLED;
    bool enabled = false;
    bool wakeup = false;
    bool batching = false;
    uint64_t lastReadingAt = 0;
    double minValue = 0.0;
    double maxValue = 0.0;
    double resolution = 0.0;
    double powerUsage = 0.0;  // mA
    uint32_t maxSampleRateHz = 0;
    uint8_t axisCount = 0;
    std::string name;
    std::string vendor;
};

struct SensorPolicy {
    std::string appId;
    SensorPermission permission = SensorPermission::DENY;
    SensorPrivacyMode privacyMode = SensorPrivacyMode::FULL;
    uint32_t privacyFlags = SENSOR_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
    uint32_t rateLimitHz = 0;  // 0 = unlimited
};

struct SensorRequest {
    uint64_t id = 0;
    std::string appId;
    SensorType sensor = SensorType::ACCELEROMETER;
    uint32_t sampleRateHz = 0;          // Desired sample rate
    uint64_t maxReportLatencyMs = 0;    // Batching latency
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;
    uint64_t lastDeliveredAt = 0;
    uint64_t lastDeliveredNanos = 0;
    SensorReading lastReading;       // Privacy-transformed last delivered
    SensorReading lastRawReading;    // Raw last delivered for rate filtering
    SensorRequestState state = SensorRequestState::ACTIVE;
    std::vector<SensorReading> batchBuffer;  // Pending batched readings
};

struct SensorEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    SensorEventType type = SensorEventType::READING_UPDATED;
    SensorResult result = SensorResult::SUCCESS;
    std::string appId;
    SensorType sensor = SensorType::ACCELEROMETER;
    uint64_t requestId = 0;
    std::string detail;  // Metadata only — never raw sensor vectors
};

struct SensorStats {
    uint64_t readingUpdates = 0;
    uint64_t deliveredReadings = 0;
    uint64_t deniedRequests = 0;
    uint64_t permissionsChanged = 0;
    uint64_t requestsStarted = 0;
    uint64_t requestsCancelled = 0;
    uint64_t requestsExpired = 0;
    uint64_t flushesCompleted = 0;
    uint64_t mockReadingsSet = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t batchOverflows = 0;
    uint64_t rateThrottled = 0;
    uint64_t bySensor[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byEventType[17] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Sensor Manager
// ============================================================

class SensorManager {
public:
    SensorManager() = default;
    ~SensorManager() = default;

    SensorManager(const SensorManager&) = delete;
    SensorManager& operator=(const SensorManager&) = delete;

    // ---- Lifecycle ----
    SensorResult initialize(size_t maxHistory = 256, size_t maxEvents = 256,
                             size_t maxRequests = 64, size_t maxBatchSize = 256);
    SensorResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Sensor control ----
    SensorResult setSensorEnabled(SensorType sensor, bool enabled,
                                    const std::string& owner = "system");
    bool isSensorEnabled(SensorType sensor) const;
    SensorInfo getSensorInfo(SensorType sensor) const;
    std::vector<SensorInfo> getSensors() const;
    std::vector<SensorType> getAvailableSensors() const;

    // ---- Permission / policy ----
    SensorResult setAppSensorPolicy(const std::string& appId,
                                      SensorPermission permission,
                                      SensorPrivacyMode privacyMode,
                                      uint32_t privacyFlags = SENSOR_PRIVACY_NONE,
                                      uint32_t rateLimitHz = 0,
                                      const std::string& owner = "system");
    SensorPolicy getAppSensorPolicy(const std::string& appId) const;
    SensorResult clearAppSensorPolicy(const std::string& appId,
                                       const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId, SensorType sensor) const;
    SensorResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Sensor update ----
    SensorResult updateSensorReading(SensorType sensor,
                                       const SensorReading& reading,
                                       const std::string& owner = "system");
    SensorResult getLastReading(const std::string& appId,
                                  SensorType sensor,
                                  SensorReading& out);
    SensorResult requestSingleReading(const std::string& appId,
                                        SensorType sensor,
                                        uint64_t timeoutMs = 0);
    SensorResult startSensorUpdates(const std::string& appId,
                                      SensorType sensor,
                                      uint32_t sampleRateHz,
                                      uint64_t maxReportLatencyMs = 0,
                                      uint64_t timeoutMs = 0,
                                      uint64_t* outRequestId = nullptr);
    SensorResult cancelSensorUpdates(uint64_t requestId,
                                       const std::string& appId);
    SensorResult processSensorRequests();
    SensorResult flushBatch(uint64_t requestId,
                              const std::string& appId);

    // ---- History / privacy ----
    std::vector<SensorReading> getHistory(const std::string& appId,
                                            size_t limit = 0,
                                            bool includeMock = false) const;
    SensorResult clearHistory(const std::string& owner = "system");
    SensorResult clearAppHistory(const std::string& appId,
                                  const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    SensorResult setMockEnabled(bool enabled,
                                   const std::string& owner = "system");
    SensorResult setMockReading(SensorType sensor,
                                   const SensorReading& reading,
                                   const std::string& owner = "system");
    SensorResult clearMockReading(SensorType sensor,
                                    const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }

    // ---- Events ----
    std::vector<SensorEvent> getEvents(size_t limit = 0) const;
    std::vector<SensorEvent> getEventsByType(SensorEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    SensorResult clearEvents();

    // ---- Stats ----
    SensorStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setReadingCallback(std::function<void(const SensorReading&, const std::string&)> cb) {
        readingCallback_ = cb;
    }
    void setAccessCallback(std::function<void(const std::string&, SensorResult)> cb) {
        accessCallback_ = cb;
    }
    void setEventCallback(std::function<void(const SensorEvent&)> cb) { eventCallback_ = cb; }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* sensorTypeToString(SensorType sensor);
    static const char* sensorStateToString(SensorState state);
    static const char* sensorAccuracyToString(SensorAccuracy accuracy);
    static const char* sensorPermissionToString(SensorPermission permission);
    static const char* requestStateToString(SensorRequestState state);
    static const char* sensorPrivacyModeToString(SensorPrivacyMode mode);
    static const char* sensorResultToString(SensorResult result);
    static const char* sensorEventTypeToString(SensorEventType type);
    static SensorType stringToSensorType(const std::string& str);
    static SensorResult stringToSensorResult(const std::string& str);

    // ---- Privacy helpers ----
    static SensorReading applyPrivacyTransform(const SensorReading& reading,
                                                 SensorPrivacyMode mode,
                                                 uint32_t privacyFlags);
    static double quantizePrecision(double value, int decimals);

private:
    uint64_t getCurrentTimeMs() const;
    uint64_t getCurrentTimeNanos() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(SensorEventType type, SensorResult result,
                     const std::string& appId, SensorType sensor,
                     uint64_t requestId, const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    SensorResult deliverReadingToRequest(SensorRequest& request,
                                           const SensorReading& reading);
    static int sensorIndex(SensorType sensor);
    void initSensorCapabilities();

    bool initialized_ = false;
    size_t maxHistory_ = 256;
    size_t maxEvents_ = 256;
    size_t maxRequests_ = 64;
    size_t maxBatchSize_ = 256;

    SensorInfo sensors_[10];
    SensorReading sensorReadings_[10];

    std::map<std::string, SensorPolicy> appPolicies_;

    std::vector<SensorRequest> requests_;
    uint64_t nextRequestId_ = 1;

    std::vector<SensorReading> history_;   // Newest first
    std::vector<SensorEvent> events_;
    std::vector<SensorEvent> eventHistory_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    SensorReading mockReadings_[10];

    SensorStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const SensorReading&, const std::string&)> readingCallback_;
    std::function<void(const std::string&, SensorResult)> accessCallback_;
    std::function<void(const SensorEvent&)> eventCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace sensor
}  // namespace phantom

#endif  // PHANTOM_SENSOR_SENSOR_MANAGER_H
