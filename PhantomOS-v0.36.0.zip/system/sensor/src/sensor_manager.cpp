/*
 * Phantom OS - Sensor Manager
 * v0.29.0 - License: GPL-3.0
 *
 * Implementation of SensorManager: privacy-first sensor service with
 * provider management, per-app policy, sensor requests with batching/flush,
 * mock sensor support, history with privacy redaction, events, stats,
 * callbacks and optional LogServer/CrashReporter integration.
 */

#include "phantom/sensor/sensor_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <chrono>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace phantom {
namespace sensor {

// ============================================================
// Private helpers
// ============================================================

int SensorManager::sensorIndex(SensorType sensor) {
    return static_cast<int>(sensor);
}

uint64_t SensorManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

uint64_t SensorManager::getCurrentTimeNanos() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_ * 1000000ULL;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool SensorManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "android" || app == "com.android.system";
}

void SensorManager::initSensorCapabilities() {
    // Accelerometer
    sensors_[0] = {};
    sensors_[0].sensor = SensorType::ACCELEROMETER;
    sensors_[0].state = SensorState::IDLE;
    sensors_[0].minValue = -19.6;
    sensors_[0].maxValue = 19.6;
    sensors_[0].resolution = 0.01;
    sensors_[0].powerUsage = 0.5;
    sensors_[0].maxSampleRateHz = SENSOR_DEFAULT_MAX_SAMPLE_RATE_HZ;
    sensors_[0].axisCount = 3;
    sensors_[0].wakeup = true;
    sensors_[0].batching = true;
    sensors_[0].name = "Accelerometer";
    sensors_[0].vendor = "PhantomOS";

    // Gyroscope
    sensors_[1] = {};
    sensors_[1].sensor = SensorType::GYROSCOPE;
    sensors_[1].state = SensorState::IDLE;
    sensors_[1].minValue = -1000.0;
    sensors_[1].maxValue = 1000.0;
    sensors_[1].resolution = 0.001;
    sensors_[1].powerUsage = 0.8;
    sensors_[1].maxSampleRateHz = SENSOR_DEFAULT_MAX_SAMPLE_RATE_HZ;
    sensors_[1].axisCount = 3;
    sensors_[1].wakeup = true;
    sensors_[1].batching = true;
    sensors_[1].name = "Gyroscope";
    sensors_[1].vendor = "PhantomOS";

    // Magnetometer
    sensors_[2] = {};
    sensors_[2].sensor = SensorType::MAGNETOMETER;
    sensors_[2].state = SensorState::IDLE;
    sensors_[2].minValue = -200.0;
    sensors_[2].maxValue = 200.0;
    sensors_[2].resolution = 0.01;
    sensors_[2].powerUsage = 0.6;
    sensors_[2].maxSampleRateHz = 50;
    sensors_[2].axisCount = 3;
    sensors_[2].wakeup = false;
    sensors_[2].batching = true;
    sensors_[2].name = "Magnetometer";
    sensors_[2].vendor = "PhantomOS";

    // Proximity
    sensors_[3] = {};
    sensors_[3].sensor = SensorType::PROXIMITY;
    sensors_[3].state = SensorState::IDLE;
    sensors_[3].minValue = 0.0;
    sensors_[3].maxValue = 1.0;
    sensors_[3].resolution = 1.0;
    sensors_[3].powerUsage = 0.1;
    sensors_[3].maxSampleRateHz = 10;
    sensors_[3].axisCount = 1;
    sensors_[3].wakeup = true;
    sensors_[3].batching = false;
    sensors_[3].name = "Proximity";
    sensors_[3].vendor = "PhantomOS";

    // Ambient Light
    sensors_[4] = {};
    sensors_[4].sensor = SensorType::AMBIENT_LIGHT;
    sensors_[4].state = SensorState::IDLE;
    sensors_[4].minValue = 0.0;
    sensors_[4].maxValue = 65535.0;
    sensors_[4].resolution = 1.0;
    sensors_[4].powerUsage = 0.1;
    sensors_[4].maxSampleRateHz = 10;
    sensors_[4].axisCount = 1;
    sensors_[4].wakeup = false;
    sensors_[4].batching = false;
    sensors_[4].name = "Ambient Light";
    sensors_[4].vendor = "PhantomOS";

    // Barometer
    sensors_[5] = {};
    sensors_[5].sensor = SensorType::BAROMETER;
    sensors_[5].state = SensorState::IDLE;
    sensors_[5].minValue = 300.0;
    sensors_[5].maxValue = 1100.0;
    sensors_[5].resolution = 0.01;
    sensors_[5].powerUsage = 0.3;
    sensors_[5].maxSampleRateHz = 10;
    sensors_[5].axisCount = 1;
    sensors_[5].wakeup = false;
    sensors_[5].batching = true;
    sensors_[5].name = "Barometer";
    sensors_[5].vendor = "PhantomOS";

    // Step Counter
    sensors_[6] = {};
    sensors_[6].sensor = SensorType::STEP_COUNTER;
    sensors_[6].state = SensorState::IDLE;
    sensors_[6].minValue = 0.0;
    sensors_[6].maxValue = 1000000.0;
    sensors_[6].resolution = 1.0;
    sensors_[6].powerUsage = 0.2;
    sensors_[6].maxSampleRateHz = 5;
    sensors_[6].axisCount = 1;
    sensors_[6].wakeup = true;
    sensors_[6].batching = true;
    sensors_[6].name = "Step Counter";
    sensors_[6].vendor = "PhantomOS";

    // Heart Rate (stub)
    sensors_[7] = {};
    sensors_[7].sensor = SensorType::HEART_RATE_STUB;
    sensors_[7].state = SensorState::DISABLED;
    sensors_[7].minValue = 0.0;
    sensors_[7].maxValue = 255.0;
    sensors_[7].resolution = 1.0;
    sensors_[7].powerUsage = 1.0;
    sensors_[7].maxSampleRateHz = 5;
    sensors_[7].axisCount = 1;
    sensors_[7].wakeup = true;
    sensors_[7].batching = false;
    sensors_[7].name = "Heart Rate (Stub)";
    sensors_[7].vendor = "PhantomOS";

    // Device Orientation (fused stub)
    sensors_[8] = {};
    sensors_[8].sensor = SensorType::DEVICE_ORIENTATION_FUSED;
    sensors_[8].state = SensorState::IDLE;
    sensors_[8].minValue = 0.0;
    sensors_[8].maxValue = 360.0;
    sensors_[8].resolution = 0.1;
    sensors_[8].powerUsage = 0.0;  // Virtual sensor
    sensors_[8].maxSampleRateHz = 50;
    sensors_[8].axisCount = 3;
    sensors_[8].wakeup = false;
    sensors_[8].batching = true;
    sensors_[8].name = "Device Orientation (Fused)";
    sensors_[8].vendor = "PhantomOS";

    // Mock
    sensors_[9] = {};
    sensors_[9].sensor = SensorType::MOCK;
    sensors_[9].state = SensorState::DISABLED;
    sensors_[9].minValue = -1000.0;
    sensors_[9].maxValue = 1000.0;
    sensors_[9].resolution = 0.001;
    sensors_[9].powerUsage = 0.0;
    sensors_[9].maxSampleRateHz = SENSOR_DEFAULT_MAX_SAMPLE_RATE_HZ;
    sensors_[9].axisCount = 6;
    sensors_[9].wakeup = true;
    sensors_[9].batching = true;
    sensors_[9].name = "Mock Sensor";
    sensors_[9].vendor = "PhantomOS";
}

void SensorManager::recordEvent(SensorEventType type, SensorResult result,
                                 const std::string& appId, SensorType sensor,
                                 uint64_t requestId, const std::string& detail) {
    SensorEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.sensor = sensor;
    event.requestId = requestId;
    event.detail = detail;

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        eventHistory_.push_back(events_.front());
        events_.erase(events_.begin());
    }

    int si = sensorIndex(sensor);
    if (si >= 0 && si < 10) stats_.bySensor[si]++;
    int et = static_cast<int>(type);
    if (et >= 0 && et < 17) stats_.byEventType[et]++;
    int ri = static_cast<int>(result);
    if (ri >= 0 && ri < 15) stats_.byResult[ri]++;

    if (eventCallback_) eventCallback_(event);
}

void SensorManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    // Never log raw sensor vectors — only metadata
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "SensorManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "SensorManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "SensorManager");
    }
}

void SensorManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("SensorManager", "SensorManager", 0, reason);
}

// ============================================================
// Lifecycle
// ============================================================

SensorResult SensorManager::initialize(size_t maxHistory, size_t maxEvents,
                                          size_t maxRequests, size_t maxBatchSize) {
    if (initialized_) return SensorResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxRequests == 0 || maxBatchSize == 0) {
        return SensorResult::INVALID_PARAMETER;
    }

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxRequests_ = maxRequests;
    maxBatchSize_ = maxBatchSize;

    initSensorCapabilities();

    // Enable default sensors: accelerometer, gyroscope, magnetometer, proximity, ambient light, barometer
    sensors_[0].enabled = true;  // Accelerometer
    sensors_[0].state = SensorState::AVAILABLE;
    sensors_[1].enabled = true;  // Gyroscope
    sensors_[1].state = SensorState::AVAILABLE;
    sensors_[2].enabled = true;  // Magnetometer
    sensors_[2].state = SensorState::AVAILABLE;
    sensors_[3].enabled = true;  // Proximity
    sensors_[3].state = SensorState::AVAILABLE;
    sensors_[4].enabled = true;  // Ambient Light
    sensors_[4].state = SensorState::AVAILABLE;
    sensors_[5].enabled = true;  // Barometer
    sensors_[5].state = SensorState::AVAILABLE;

    initialized_ = true;

    logToServer("INFO", "SensorManager initialized");
    recordEvent(SensorEventType::SENSOR_ENABLED, SensorResult::SUCCESS,
                 "system", SensorType::ACCELEROMETER, 0, "INIT");
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::shutdown() {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;

    appPolicies_.clear();
    requests_.clear();
    history_.clear();
    events_.clear();
    eventHistory_.clear();
    nextRequestId_ = 1;
    nextEventId_ = 1;

    // Reset sensors
    for (size_t i = 0; i < 10; ++i) {
        sensors_[i] = SensorInfo{};
        sensors_[i].sensor = static_cast<SensorType>(i);
        sensorReadings_[i] = SensorReading{};
        mockReadings_[i] = SensorReading{};
    }
    mockEnabled_ = false;
    stats_ = SensorStats{};
    initialized_ = false;
    return SensorResult::SUCCESS;
}

// ============================================================
// Sensor control
// ============================================================

SensorResult SensorManager::setSensorEnabled(SensorType sensor, bool enabled,
                                               const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;

    if (sensors_[idx].enabled == enabled) return SensorResult::SUCCESS;

    sensors_[idx].enabled = enabled;
    sensors_[idx].state = enabled ? SensorState::AVAILABLE : SensorState::DISABLED;

    recordEvent(enabled ? SensorEventType::SENSOR_ENABLED : SensorEventType::SENSOR_DISABLED,
                 SensorResult::SUCCESS, "system", sensor, 0,
                 enabled ? "ENABLED" : "DISABLED");
    logToServer("INFO", std::string("Sensor ") + sensorTypeToString(sensor) +
                (enabled ? " enabled" : " disabled"));
    return SensorResult::SUCCESS;
}

bool SensorManager::isSensorEnabled(SensorType sensor) const {
    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return false;
    return sensors_[idx].enabled;
}

SensorInfo SensorManager::getSensorInfo(SensorType sensor) const {
    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorInfo{};
    return sensors_[idx];
}

std::vector<SensorInfo> SensorManager::getSensors() const {
    std::vector<SensorInfo> result;
    for (size_t i = 0; i < 10; ++i) {
        result.push_back(sensors_[i]);
    }
    return result;
}

std::vector<SensorType> SensorManager::getAvailableSensors() const {
    std::vector<SensorType> result;
    for (size_t i = 0; i < 10; ++i) {
        if (sensors_[i].enabled) {
            result.push_back(static_cast<SensorType>(i));
        }
    }
    return result;
}

// ============================================================
// Permission / policy
// ============================================================

SensorResult SensorManager::setAppSensorPolicy(const std::string& appId,
                                                 SensorPermission permission,
                                                 SensorPrivacyMode privacyMode,
                                                 uint32_t privacyFlags,
                                                 uint32_t rateLimitHz,
                                                 const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }
    if (appId.empty()) return SensorResult::INVALID_PARAMETER;
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    // Check biometric/health sensor restrictions
    if (privacyFlags & SENSOR_PRIVACY_DISABLE_BIOMETRIC_HEALTH) {
        // Block heart rate sensor
        sensors_[7].enabled = false;
        sensors_[7].state = SensorState::DISABLED;
    }

    SensorPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.lastGrantedAt = getCurrentTimeMs();
    policy.rateLimitHz = rateLimitHz;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(SensorEventType::PERMISSION_CHANGED, SensorResult::SUCCESS,
                 appId, SensorType::ACCELEROMETER, 0, "POLICY_SET");
    logToServer("INFO", "Policy set for app: " + appId);
    return SensorResult::SUCCESS;
}

SensorPolicy SensorManager::getAppSensorPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return SensorPolicy{};
}

SensorResult SensorManager::clearAppSensorPolicy(const std::string& appId,
                                                   const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return SensorResult::SUCCESS;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    recordEvent(SensorEventType::PERMISSION_CHANGED, SensorResult::SUCCESS,
                 appId, SensorType::ACCELEROMETER, 0, "POLICY_CLEARED");
    return SensorResult::SUCCESS;
}

bool SensorManager::checkAppAccess(const std::string& appId, SensorType sensor) const {
    if (isSystemOwner(appId)) return true;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    // Check biometric/health restriction
    if (sensor == SensorType::HEART_RATE_STUB &&
        (policy.privacyFlags & SENSOR_PRIVACY_DISABLE_BIOMETRIC_HEALTH)) {
        return false;
    }

    switch (policy.permission) {
        case SensorPermission::DENY:
            return false;
        case SensorPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case SensorPermission::ALLOW_ALWAYS:
            return true;
        case SensorPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

SensorResult SensorManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return SensorResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return SensorResult::SUCCESS;
}

// ============================================================
// Sensor update
// ============================================================

SensorResult SensorManager::updateSensorReading(SensorType sensor,
                                                  const SensorReading& reading,
                                                  const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;
    if (!sensors_[idx].enabled) return SensorResult::SENSOR_DISABLED;

    // Use mock reading if available
    SensorReading effectiveReading = reading;
    if (mockEnabled_ && mockReadings_[idx].timestamp > 0) {
        effectiveReading = mockReadings_[idx];
        effectiveReading.mock = true;
    }
    effectiveReading.sensor = sensor;
    effectiveReading.timestamp = getCurrentTimeMs();
    effectiveReading.timestampNanos = getCurrentTimeNanos();

    sensorReadings_[idx] = effectiveReading;
    sensors_[idx].lastReadingAt = effectiveReading.timestamp;
    if (sensors_[idx].state == SensorState::SEARCHING) {
        sensors_[idx].state = SensorState::AVAILABLE;
    }
    stats_.readingUpdates++;

    recordEvent(SensorEventType::READING_UPDATED, SensorResult::SUCCESS,
                 "system", sensor, 0, "UPDATE");
    logToServer("INFO", std::string("Sensor reading updated: ") + sensorTypeToString(sensor));

    // Deliver to active requests
    for (auto& req : requests_) {
        if (req.state != SensorRequestState::ACTIVE) continue;
        if (req.sensor != sensor) continue;

        // Rate limiting
        if (req.lastDeliveredAt > 0) {
            auto it = appPolicies_.find(req.appId);
            if (it != appPolicies_.end() && it->second.rateLimitHz > 0) {
                uint64_t minIntervalMs = 1000 / it->second.rateLimitHz;
                if (effectiveReading.timestamp - req.lastDeliveredAt < minIntervalMs) {
                    stats_.rateThrottled++;
                    recordEvent(SensorEventType::RATE_THROTTLED, SensorResult::RATE_LIMITED,
                                 req.appId, sensor, req.id, "RATE_LIMIT");
                    continue;
                }
            }
        }

        // Interval filter based on sample rate
        if (req.sampleRateHz > 0 && req.lastDeliveredAt > 0) {
            uint64_t minIntervalMs = 1000 / req.sampleRateHz;
            if (effectiveReading.timestamp - req.lastDeliveredAt < minIntervalMs) {
                continue;
            }
        }

        deliverReadingToRequest(req, effectiveReading);
    }

    // Add to history (unless NO_HISTORY flag)
    auto it = appPolicies_.find("system");
    bool systemNoHistory = (it != appPolicies_.end() &&
                            (it->second.privacyFlags & SENSOR_PRIVACY_NO_HISTORY));
    if (!systemNoHistory) {
        history_.insert(history_.begin(), effectiveReading);
        if (history_.size() > maxHistory_) {
            history_.resize(maxHistory_);
        }
    }

    // Note: readingCallback_ is called by deliverReadingToRequest for app-targeted delivery
    // Only call for system-level notification if no requests consumed it
    bool delivered = false;
    for (const auto& req : requests_) {
        if (req.state == SensorRequestState::ACTIVE && req.sensor == sensor) {
            delivered = true;
            break;
        }
    }
    if (!delivered && readingCallback_) {
        readingCallback_(effectiveReading, "system");
    }

    return SensorResult::SUCCESS;
}

SensorResult SensorManager::getLastReading(const std::string& appId,
                                             SensorType sensor,
                                             SensorReading& out) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }

    if (!checkAppAccess(appId, sensor)) {
        stats_.deniedRequests++;
        if (accessCallback_) accessCallback_(appId, SensorResult::PERMISSION_DENIED);
        recordEvent(SensorEventType::READING_DENIED, SensorResult::PERMISSION_DENIED,
                     appId, sensor, 0, "ACCESS_DENIED");
        return SensorResult::PERMISSION_DENIED;
    }

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;
    if (!sensors_[idx].enabled) return SensorResult::SENSOR_DISABLED;

    if (sensorReadings_[idx].timestamp == 0) {
        return SensorResult::READING_UNAVAILABLE;
    }

    auto policy = getAppSensorPolicy(appId);
    out = applyPrivacyTransform(sensorReadings_[idx], policy.privacyMode,
                                  policy.privacyFlags);
    if (policy.privacyMode != SensorPrivacyMode::FULL || policy.privacyFlags != SENSOR_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == SensorPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }
    stats_.deliveredReadings++;
    recordEvent(SensorEventType::READING_DELIVERED, SensorResult::SUCCESS,
                 appId, sensor, 0, "LAST_KNOWN");
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::requestSingleReading(const std::string& appId,
                                                   SensorType sensor,
                                                   uint64_t timeoutMs) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }

    if (!checkAppAccess(appId, sensor)) {
        stats_.deniedRequests++;
        if (accessCallback_) accessCallback_(appId, SensorResult::PERMISSION_DENIED);
        recordEvent(SensorEventType::READING_DENIED, SensorResult::PERMISSION_DENIED,
                     appId, sensor, 0, "ACCESS_DENIED");
        return SensorResult::PERMISSION_DENIED;
    }

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;
    if (!sensors_[idx].enabled) return SensorResult::SENSOR_DISABLED;

    // If we have a reading, deliver immediately
    if (sensorReadings_[idx].timestamp > 0) {
        auto policy = getAppSensorPolicy(appId);
        SensorReading delivered = applyPrivacyTransform(sensorReadings_[idx],
                                                          policy.privacyMode,
                                                          policy.privacyFlags);
    if (policy.privacyMode != SensorPrivacyMode::FULL || policy.privacyFlags != SENSOR_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

        // Consume ALLOW_ONCE
        auto it = appPolicies_.find(appId);
        if (it != appPolicies_.end() && it->second.permission == SensorPermission::ALLOW_ONCE) {
            it->second.oneShotUsed = true;
        }
        stats_.deliveredReadings++;
        recordEvent(SensorEventType::READING_DELIVERED, SensorResult::SUCCESS,
                     appId, sensor, 0, "SINGLE");
        if (readingCallback_) readingCallback_(delivered, appId);
        return SensorResult::SUCCESS;
    }

    return SensorResult::READING_UNAVAILABLE;
}

SensorResult SensorManager::startSensorUpdates(const std::string& appId,
                                                 SensorType sensor,
                                                 uint32_t sampleRateHz,
                                                 uint64_t maxReportLatencyMs,
                                                 uint64_t timeoutMs,
                                                 uint64_t* outRequestId) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }

    if (appId.empty()) return SensorResult::INVALID_PARAMETER;
    if (sampleRateHz == 0) return SensorResult::INVALID_PARAMETER;

    if (!checkAppAccess(appId, sensor)) {
        stats_.deniedRequests++;
        if (accessCallback_) accessCallback_(appId, SensorResult::PERMISSION_DENIED);
        recordEvent(SensorEventType::READING_DENIED, SensorResult::PERMISSION_DENIED,
                     appId, sensor, 0, "ACCESS_DENIED");
        return SensorResult::PERMISSION_DENIED;
    }

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;
    if (!sensors_[idx].enabled) return SensorResult::SENSOR_DISABLED;

    if (requests_.size() >= maxRequests_) return SensorResult::CAPACITY_EXCEEDED;

    SensorRequest req;
    req.id = nextRequestId_++;
    req.appId = appId;
    req.sensor = sensor;
    req.sampleRateHz = sampleRateHz;
    req.maxReportLatencyMs = maxReportLatencyMs;
    req.createdAt = getCurrentTimeMs();
    req.expiresAt = timeoutMs > 0 ? req.createdAt + timeoutMs : 0;
    req.state = SensorRequestState::ACTIVE;

    if (outRequestId) *outRequestId = req.id;
    requests_.push_back(req);
    stats_.requestsStarted++;

    recordEvent(SensorEventType::REQUEST_STARTED, SensorResult::SUCCESS,
                 appId, sensor, req.id, "START");
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::cancelSensorUpdates(uint64_t requestId,
                                                  const std::string& appId) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::SIMULATED_FAILURE; }

    for (auto& req : requests_) {
        if (req.id != requestId) continue;
        if (req.appId != appId && !isSystemOwner(appId)) return SensorResult::PERMISSION_DENIED;
        if (req.state == SensorRequestState::CANCELLED) return SensorResult::BAD_STATE;
        req.state = SensorRequestState::CANCELLED;
        stats_.requestsCancelled++;
        recordEvent(SensorEventType::REQUEST_CANCELLED, SensorResult::SUCCESS,
                     appId, req.sensor, req.id, "CANCEL");
        return SensorResult::SUCCESS;
    }
    return SensorResult::REQUEST_NOT_FOUND;
}

SensorResult SensorManager::processSensorRequests() {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    uint64_t now = getCurrentTimeMs();

    for (auto& req : requests_) {
        if (req.state != SensorRequestState::ACTIVE) continue;
        if (req.expiresAt > 0 && now >= req.expiresAt) {
            req.state = SensorRequestState::EXPIRED;
            stats_.requestsExpired++;
            recordEvent(SensorEventType::REQUEST_EXPIRED, SensorResult::SUCCESS,
                         req.appId, req.sensor, req.id, "EXPIRED");
        }
    }
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::flushBatch(uint64_t requestId,
                                         const std::string& appId) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return SensorResult::FLUSH_FAILED; }

    for (auto& req : requests_) {
        if (req.id != requestId) continue;
        if (req.appId != appId && !isSystemOwner(appId)) return SensorResult::PERMISSION_DENIED;
        if (req.state != SensorRequestState::ACTIVE) return SensorResult::BAD_STATE;

        // Deliver all batched readings
        for (const auto& reading : req.batchBuffer) {
            auto policy = getAppSensorPolicy(req.appId);
            SensorReading delivered = applyPrivacyTransform(reading,
                                                              policy.privacyMode,
                                                              policy.privacyFlags);
            if (policy.privacyMode != SensorPrivacyMode::FULL || policy.privacyFlags != SENSOR_PRIVACY_NONE) {
                stats_.privacyApplications++;
            }
            stats_.deliveredReadings++;
            if (readingCallback_) readingCallback_(delivered, req.appId);
        }
        size_t flushed = req.batchBuffer.size();
        req.batchBuffer.clear();
        stats_.flushesCompleted++;
        recordEvent(SensorEventType::FLUSH_COMPLETED, SensorResult::SUCCESS,
                     req.appId, req.sensor, req.id, "FLUSH:" + std::to_string(flushed));
        return SensorResult::SUCCESS;
    }
    return SensorResult::REQUEST_NOT_FOUND;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<SensorReading> SensorManager::getHistory(const std::string& appId,
                                                       size_t limit,
                                                       bool includeMock) const {
    std::vector<SensorReading> result;
    for (const auto& reading : history_) {
        if (!includeMock && reading.mock) continue;
        result.push_back(reading);
        if (limit > 0 && result.size() >= limit) break;
    }
    return result;
}

SensorResult SensorManager::clearHistory(const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(SensorEventType::HISTORY_CLEARED, SensorResult::SUCCESS,
                 "system", SensorType::ACCELEROMETER, 0, "CLEAR_ALL");
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::clearAppHistory(const std::string& appId,
                                              const std::string& requester) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (appId != requester && !isSystemOwner(requester)) return SensorResult::PERMISSION_DENIED;

    // History is system-wide; app-specific filtering would require per-app tagging
    // For now, this clears entries tagged with the app (future enhancement)
    size_t before = history_.size();
    history_.erase(std::remove_if(history_.begin(), history_.end(),
        [&appId](const SensorReading& r) {
            // In current model, history is system-tagged; this is a stub
            return false;
        }), history_.end());
    stats_.historyClears++;
    recordEvent(SensorEventType::HISTORY_CLEARED, SensorResult::SUCCESS,
                 appId, SensorType::ACCELEROMETER, 0, "CLEAR_APP");
    return SensorResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

SensorResult SensorManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;
    mockEnabled_ = enabled;
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::setMockReading(SensorType sensor,
                                             const SensorReading& reading,
                                             const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) {
        // Non-system owner needs MOCK_ALLOWED flag
        auto policy = getAppSensorPolicy(owner);
        if (!(policy.privacyFlags & SENSOR_PRIVACY_MOCK_ALLOWED)) {
            return SensorResult::MOCK_NOT_ALLOWED;
        }
    }

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;

    mockReadings_[idx] = reading;
    mockReadings_[idx].sensor = sensor;
    mockReadings_[idx].mock = true;
    mockReadings_[idx].timestamp = getCurrentTimeMs();
    stats_.mockReadingsSet++;
    recordEvent(SensorEventType::MOCK_READING_SET, SensorResult::SUCCESS,
                 "system", sensor, 0, "MOCK_SET");
    return SensorResult::SUCCESS;
}

SensorResult SensorManager::clearMockReading(SensorType sensor,
                                               const std::string& owner) {
    if (!initialized_) return SensorResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return SensorResult::PERMISSION_DENIED;

    int idx = sensorIndex(sensor);
    if (idx < 0 || idx >= 10) return SensorResult::INVALID_PARAMETER;
    mockReadings_[idx] = SensorReading{};
    return SensorResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<SensorEvent> SensorManager::getEvents(size_t limit) const {
    if (limit == 0 || limit >= events_.size()) return events_;
    return std::vector<SensorEvent>(events_.end() - limit, events_.end());
}

std::vector<SensorEvent> SensorManager::getEventsByType(SensorEventType type) const {
    std::vector<SensorEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) result.push_back(event);
    }
    return result;
}

SensorResult SensorManager::clearEvents() {
    for (const auto& event : events_) {
        eventHistory_.push_back(event);
    }
    events_.clear();
    return SensorResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void SensorManager::resetStats() {
    stats_ = SensorStats{};
}

// ============================================================
// Privacy helpers
// ============================================================

double SensorManager::quantizePrecision(double value, int decimals) {
    double factor = std::pow(10.0, decimals);
    return std::round(value * factor) / factor;
}

SensorReading SensorManager::applyPrivacyTransform(const SensorReading& reading,
                                                     SensorPrivacyMode mode,
                                                     uint32_t privacyFlags) {
    SensorReading result = reading;

    if (mode == SensorPrivacyMode::FULL && privacyFlags == SENSOR_PRIVACY_NONE) {
        return result;
    }

    // COARSE mode: reduce precision significantly
    if (mode == SensorPrivacyMode::COARSE ||
        (privacyFlags & SENSOR_PRIVACY_COARSE_MOTION)) {
        for (int i = 0; i < result.valueCount; ++i) {
            result.values[i] = quantizePrecision(result.values[i], 0);  // Round to integer
        }
    }

    // REDACT_PRECISION: reduce decimal precision
    if (privacyFlags & SENSOR_PRIVACY_REDACT_PRECISION) {
        for (int i = 0; i < result.valueCount; ++i) {
            result.values[i] = quantizePrecision(result.values[i], 1);  // 1 decimal
        }
    }

    // NO_RAW: zero out all values but keep metadata
    if (mode == SensorPrivacyMode::NO_RAW) {
        for (int i = 0; i < result.valueCount; ++i) {
            result.values[i] = 0.0;
        }
    }

    result.privacyFlags = privacyFlags;
    return result;
}

// ============================================================
// Private: deliver reading to request
// ============================================================

SensorResult SensorManager::deliverReadingToRequest(SensorRequest& request,
                                                       const SensorReading& reading) {
    auto policy = getAppSensorPolicy(request.appId);
    SensorReading delivered = applyPrivacyTransform(reading,
                                                      policy.privacyMode,
                                                      policy.privacyFlags);
    if (policy.privacyMode != SensorPrivacyMode::FULL || policy.privacyFlags != SENSOR_PRIVACY_NONE) {
        stats_.privacyApplications++;
    }

    // Batching: add to batch buffer if maxReportLatency > 0
    if (request.maxReportLatencyMs > 0 && sensors_[sensorIndex(request.sensor)].batching) {
        if (request.batchBuffer.size() >= maxBatchSize_) {
            // Overflow: deliver oldest to make room
            stats_.batchOverflows++;
            recordEvent(SensorEventType::BATCH_OVERFLOW, SensorResult::CAPACITY_EXCEEDED,
                         request.appId, request.sensor, request.id, "OVERFLOW");
            // Drop oldest
            request.batchBuffer.erase(request.batchBuffer.begin());
        }
        request.batchBuffer.push_back(delivered);
        request.lastDeliveredAt = getCurrentTimeMs();
        request.lastDeliveredNanos = getCurrentTimeNanos();
        request.lastReading = delivered;
        request.lastRawReading = reading;
        return SensorResult::SUCCESS;
    }

    // Direct delivery
    request.lastReading = delivered;
    request.lastRawReading = reading;
    request.lastDeliveredAt = getCurrentTimeMs();
    request.lastDeliveredNanos = getCurrentTimeNanos();
    stats_.deliveredReadings++;

    // Consume ALLOW_ONCE
    auto it = appPolicies_.find(request.appId);
    if (it != appPolicies_.end() && it->second.permission == SensorPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    recordEvent(SensorEventType::READING_DELIVERED, SensorResult::SUCCESS,
                 request.appId, request.sensor, request.id, "DELIVERED");

    if (readingCallback_) {
        readingCallback_(delivered, request.appId);
    }

    return SensorResult::SUCCESS;
}

// ============================================================
// String helpers
// ============================================================

const char* SensorManager::sensorTypeToString(SensorType sensor) {
    switch (sensor) {
        case SensorType::ACCELEROMETER: return "ACCELEROMETER";
        case SensorType::GYROSCOPE: return "GYROSCOPE";
        case SensorType::MAGNETOMETER: return "MAGNETOMETER";
        case SensorType::PROXIMITY: return "PROXIMITY";
        case SensorType::AMBIENT_LIGHT: return "AMBIENT_LIGHT";
        case SensorType::BAROMETER: return "BAROMETER";
        case SensorType::STEP_COUNTER: return "STEP_COUNTER";
        case SensorType::HEART_RATE_STUB: return "HEART_RATE_STUB";
        case SensorType::DEVICE_ORIENTATION_FUSED: return "DEVICE_ORIENTATION_FUSED";
        case SensorType::MOCK: return "MOCK";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorStateToString(SensorState state) {
    switch (state) {
        case SensorState::DISABLED: return "DISABLED";
        case SensorState::IDLE: return "IDLE";
        case SensorState::SEARCHING: return "SEARCHING";
        case SensorState::AVAILABLE: return "AVAILABLE";
        case SensorState::TEMP_UNAVAILABLE: return "TEMP_UNAVAILABLE";
        case SensorState::FAILED: return "FAILED";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorAccuracyToString(SensorAccuracy accuracy) {
    switch (accuracy) {
        case SensorAccuracy::NONE: return "NONE";
        case SensorAccuracy::LOW: return "LOW";
        case SensorAccuracy::MEDIUM: return "MEDIUM";
        case SensorAccuracy::HIGH: return "HIGH";
        case SensorAccuracy::UNKNOWN: return "UNKNOWN";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorPermissionToString(SensorPermission permission) {
    switch (permission) {
        case SensorPermission::DENY: return "DENY";
        case SensorPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case SensorPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case SensorPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::requestStateToString(SensorRequestState state) {
    switch (state) {
        case SensorRequestState::ACTIVE: return "ACTIVE";
        case SensorRequestState::PAUSED: return "PAUSED";
        case SensorRequestState::EXPIRED: return "EXPIRED";
        case SensorRequestState::CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorPrivacyModeToString(SensorPrivacyMode mode) {
    switch (mode) {
        case SensorPrivacyMode::FULL: return "FULL";
        case SensorPrivacyMode::COARSE: return "COARSE";
        case SensorPrivacyMode::NO_RAW: return "NO_RAW";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorResultToString(SensorResult result) {
    switch (result) {
        case SensorResult::SUCCESS: return "SUCCESS";
        case SensorResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case SensorResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case SensorResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case SensorResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case SensorResult::SENSOR_DISABLED: return "SENSOR_DISABLED";
        case SensorResult::READING_UNAVAILABLE: return "READING_UNAVAILABLE";
        case SensorResult::REQUEST_NOT_FOUND: return "REQUEST_NOT_FOUND";
        case SensorResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case SensorResult::MOCK_NOT_ALLOWED: return "MOCK_NOT_ALLOWED";
        case SensorResult::RATE_LIMITED: return "RATE_LIMITED";
        case SensorResult::BAD_STATE: return "BAD_STATE";
        case SensorResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case SensorResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        case SensorResult::FLUSH_FAILED: return "FLUSH_FAILED";
        default: return "UNKNOWN";
    }
}

const char* SensorManager::sensorEventTypeToString(SensorEventType type) {
    switch (type) {
        case SensorEventType::SENSOR_ENABLED: return "SENSOR_ENABLED";
        case SensorEventType::SENSOR_DISABLED: return "SENSOR_DISABLED";
        case SensorEventType::READING_UPDATED: return "READING_UPDATED";
        case SensorEventType::READING_DELIVERED: return "READING_DELIVERED";
        case SensorEventType::READING_DENIED: return "READING_DENIED";
        case SensorEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case SensorEventType::REQUEST_STARTED: return "REQUEST_STARTED";
        case SensorEventType::REQUEST_CANCELLED: return "REQUEST_CANCELLED";
        case SensorEventType::REQUEST_EXPIRED: return "REQUEST_EXPIRED";
        case SensorEventType::FLUSH_COMPLETED: return "FLUSH_COMPLETED";
        case SensorEventType::MOCK_READING_SET: return "MOCK_READING_SET";
        case SensorEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        case SensorEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case SensorEventType::SENSOR_FAILED: return "SENSOR_FAILED";
        case SensorEventType::SENSOR_RECOVERED: return "SENSOR_RECOVERED";
        case SensorEventType::BATCH_OVERFLOW: return "BATCH_OVERFLOW";
        case SensorEventType::RATE_THROTTLED: return "RATE_THROTTLED";
        default: return "UNKNOWN";
    }
}

SensorType SensorManager::stringToSensorType(const std::string& str) {
    if (str == "ACCELEROMETER") return SensorType::ACCELEROMETER;
    if (str == "GYROSCOPE") return SensorType::GYROSCOPE;
    if (str == "MAGNETOMETER") return SensorType::MAGNETOMETER;
    if (str == "PROXIMITY") return SensorType::PROXIMITY;
    if (str == "AMBIENT_LIGHT") return SensorType::AMBIENT_LIGHT;
    if (str == "BAROMETER") return SensorType::BAROMETER;
    if (str == "STEP_COUNTER") return SensorType::STEP_COUNTER;
    if (str == "HEART_RATE_STUB") return SensorType::HEART_RATE_STUB;
    if (str == "DEVICE_ORIENTATION_FUSED") return SensorType::DEVICE_ORIENTATION_FUSED;
    if (str == "MOCK") return SensorType::MOCK;
    return SensorType::ACCELEROMETER;  // Default
}

SensorResult SensorManager::stringToSensorResult(const std::string& str) {
    if (str == "SUCCESS") return SensorResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return SensorResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return SensorResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return SensorResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return SensorResult::PERMISSION_DENIED;
    if (str == "SENSOR_DISABLED") return SensorResult::SENSOR_DISABLED;
    if (str == "READING_UNAVAILABLE") return SensorResult::READING_UNAVAILABLE;
    if (str == "REQUEST_NOT_FOUND") return SensorResult::REQUEST_NOT_FOUND;
    if (str == "CAPACITY_EXCEEDED") return SensorResult::CAPACITY_EXCEEDED;
    if (str == "MOCK_NOT_ALLOWED") return SensorResult::MOCK_NOT_ALLOWED;
    if (str == "RATE_LIMITED") return SensorResult::RATE_LIMITED;
    if (str == "BAD_STATE") return SensorResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return SensorResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return SensorResult::SIMULATED_FAILURE;
    if (str == "FLUSH_FAILED") return SensorResult::FLUSH_FAILED;
    return SensorResult::SUCCESS;
}

}  // namespace sensor
}  // namespace phantom
