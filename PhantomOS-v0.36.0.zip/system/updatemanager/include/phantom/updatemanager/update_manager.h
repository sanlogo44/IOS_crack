/*
 * Phantom OS - Update Manager
 * OS/App update checking, downloading, verification, installation, and rollback
 *
 * v0.20.0
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::updatemanager {

// ============================================================
// Enums
// ============================================================

enum class UpdateType {
    OS,              // Full OS update
    APP,             // Application update
    SECURITY_PATCH,  // Security patch
    DRIVER,         // Driver update
    CONFIG,         // Configuration update
    FIRMWARE        // Firmware update
};

enum class UpdateState {
    IDLE,           // No activity
    CHECKING,       // Checking for updates
    AVAILABLE,      // Update available, not yet queued
    QUEUED,         // Queued for download
    DOWNLOADING,    // Downloading
    PAUSED,         // Download paused
    DOWNLOADED,     // Download complete
    VERIFYING,      // Verifying checksum/signature
    VERIFIED,       // Verification passed
    STAGED,         // Staged for install (atomic)
    INSTALLING,     // Installing
    INSTALLED,      // Installation complete
    FAILED,         // Operation failed
    CANCELLED,      // User cancelled
    ROLLED_BACK     // Rolled back to previous version
};

enum class UpdateChannel {
    STABLE,     // Stable release channel
    BETA,       // Beta channel
    NIGHTLY,    // Nightly builds
    SECURITY    // Security-only channel
};

enum class UpdatePriority {
    LOW,        // Low priority update
    NORMAL,     // Normal priority
    HIGH,       // High priority
    CRITICAL    // Critical (security) update
};

enum class UpdatePolicy {
    MANUAL,         // User must manually check and install
    NOTIFY_ONLY,    // Notify user when updates available
    AUTO_DOWNLOAD,  // Auto-download but manual install
    AUTO_INSTALL    // Auto-download and auto-install
};

enum class UpdateResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PACKAGE,
    NOT_FOUND,
    BAD_STATE,
    CHECKSUM_FAILED,
    SIGNATURE_FAILED,
    INSTALL_FAILED,
    ROLLBACK_FAILED,
    POLICY_BLOCKED,
    MAINTENANCE_BLOCKED,
    ALREADY_INSTALLED,
    CANCELLED,
    QUEUE_FULL,
    INVALID_PARAMETER,
    VERIFICATION_REQUIRED,
    STAGING_REQUIRED
};

// ============================================================
// Structs
// ============================================================

struct UpdatePackage {
    uint64_t id = 0;
    std::string name;
    std::string version;           // Semantic version string (e.g. "1.2.3")
    std::string packageName;       // For APP updates
    std::string appId;             // For APP updates
    UpdateType type = UpdateType::OS;
    UpdateChannel channel = UpdateChannel::STABLE;
    UpdatePriority priority = UpdatePriority::NORMAL;
    uint64_t sizeBytes = 0;        // Download size in bytes
    std::string checksum;          // Expected checksum
    std::string signature;         // Signature for verification
    std::string sourceUrl;         // Source URL (simulated)
    std::string releaseNotes;
    std::string currentVersion;    // Currently installed version
    bool requiresReboot = false;
    bool securityUpdate = false;
    uint64_t releaseDate = 0;      // Release timestamp (ms)
    uint64_t availableSince = 0;   // When discovered (ms)
};

struct UpdateProgress {
    uint64_t updateId = 0;
    UpdateState state = UpdateState::IDLE;
    uint32_t progressPercent = 0;   // 0-100
    uint64_t downloadedBytes = 0;
    uint64_t totalBytes = 0;
    uint32_t downloadSpeed = 0;    // Bytes/sec (simulated)
    uint64_t etaSeconds = 0;       // Estimated time remaining
    std::string errorMessage;
    uint64_t lastUpdated = 0;
};

struct MaintenanceWindow {
    bool enabled = false;
    uint32_t startHour = 0;        // 0-23
    uint32_t startMinute = 0;      // 0-59
    uint32_t durationMinutes = 0;  // Window duration
    bool weekendsOnly = false;
    bool allowCriticalBypass = true;
};

struct UpdateSchedule {
    bool autoCheckEnabled = false;
    uint32_t checkIntervalHours = 24;  // Hours between auto-checks
    uint64_t lastCheckTime = 0;        // Last check timestamp (ms)
    uint64_t nextCheckTime = 0;        // Next scheduled check (ms)
    MaintenanceWindow maintenanceWindow;
};

struct RollbackPoint {
    uint64_t id = 0;
    uint64_t updateId = 0;
    std::string previousVersion;
    std::string newVersion;
    uint64_t timestamp = 0;
    bool committed = false;       // Whether the update was committed
    bool rolledBack = false;      // Whether it was rolled back
};

struct UpdateStats {
    uint64_t totalChecks = 0;
    uint64_t totalAvailable = 0;
    uint64_t totalDownloadsStarted = 0;
    uint64_t totalDownloadsCompleted = 0;
    uint64_t totalInstallsAttempted = 0;
    uint64_t totalInstallsSucceeded = 0;
    uint64_t totalInstallsFailed = 0;
    uint64_t totalRollbacks = 0;
    uint64_t totalCancelled = 0;
    uint64_t totalByType[6] = {};      // One per UpdateType
    uint64_t totalByChannel[4] = {};   // One per UpdateChannel
    uint64_t totalByPriority[4] = {};  // One per UpdatePriority
    uint64_t activeQueueSize = 0;
    uint64_t historySize = 0;
    std::map<std::string, uint64_t> perPackageCounts;
};

// ============================================================
// UpdateManager - Central update management service
// ============================================================

class UpdateManager {
public:
    UpdateManager() = default;
    ~UpdateManager() { shutdown(); }

    // Lifecycle
    UpdateResult initialize(size_t maxQueueSize = 50, size_t maxHistorySize = 200);
    UpdateResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxQueueSize(size_t size) { maxQueueSize_ = size; }
    size_t getMaxQueueSize() const { return maxQueueSize_; }
    void setMaxHistorySize(size_t size) { maxHistorySize_ = size; }
    size_t getMaxHistorySize() const { return maxHistorySize_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Policy
    void setUpdatePolicy(UpdatePolicy policy) { updatePolicy_ = policy; }
    UpdatePolicy getUpdatePolicy() const { return updatePolicy_; }
    void setAutoRollback(bool enabled) { autoRollback_ = enabled; }
    bool isAutoRollback() const { return autoRollback_; }
    void setAnonymousChecks(bool enabled) { anonymousChecks_ = enabled; }
    bool isAnonymousChecks() const { return anonymousChecks_; }
    void setTelemetryEnabled(bool enabled) { telemetryEnabled_ = enabled; }
    bool isTelemetryEnabled() const { return telemetryEnabled_; }
    void setAllowedChannel(UpdateChannel channel) { allowedChannel_ = channel; }
    UpdateChannel getAllowedChannel() const { return allowedChannel_; }

    // Test hook: force next installUpdate to fail (prototype simulation)
    void setFailNextInstall(bool fail) { failNextInstall_ = fail; }
    bool getFailNextInstall() const { return failNextInstall_; }

    // Schedule
    void setSchedule(const UpdateSchedule& schedule) { schedule_ = schedule; }
    UpdateSchedule getSchedule() const { return schedule_; }
    void setMaintenanceWindow(const MaintenanceWindow& window) { schedule_.maintenanceWindow = window; }
    MaintenanceWindow getMaintenanceWindow() const { return schedule_.maintenanceWindow; }
    bool isWithinMaintenanceWindow(uint64_t currentTimeMs = 0) const;
    bool shouldAutoCheck(uint64_t currentTimeMs = 0) const;

    // Update management
    UpdateResult addAvailableUpdate(const UpdatePackage& pkg);
    UpdateResult removeAvailableUpdate(uint64_t id);
    std::vector<UpdatePackage> getAvailableUpdates() const;
    std::vector<UpdatePackage> getUpdatesByType(UpdateType type) const;
    std::vector<UpdatePackage> getUpdatesByChannel(UpdateChannel channel) const;
    std::vector<UpdatePackage> getUpdatesByPriority(UpdatePriority priority) const;
    UpdatePackage getUpdateById(uint64_t id) const;
    size_t getAvailableCount() const { return availableUpdates_.size(); }

    // Version comparison
    static bool isNewerVersion(const std::string& current, const std::string& candidate);
    static int compareVersions(const std::string& v1, const std::string& v2);

    // Update checking
    UpdateResult checkForUpdates();
    std::vector<UpdatePackage> getPendingUpdates() const;

    // Download management
    UpdateResult queueForDownload(uint64_t id);
    UpdateResult startDownload(uint64_t id);
    UpdateResult pauseDownload(uint64_t id);
    UpdateResult resumeDownload(uint64_t id);
    UpdateResult cancelDownload(uint64_t id);
    UpdateResult updateDownloadProgress(uint64_t id, uint64_t downloadedBytes, uint32_t speedBps = 0);
    UpdateProgress getDownloadProgress(uint64_t id) const;
    std::vector<UpdateProgress> getActiveDownloads() const;
    size_t getDownloadQueueSize() const { return downloadQueue_.size(); }

    // Verification
    UpdateResult verifyUpdate(uint64_t id);
    UpdateResult setChecksum(uint64_t id, const std::string& checksum);
    UpdateResult setSignature(uint64_t id, const std::string& signature);
    std::string computeChecksum(const std::string& data) const;
    bool verifyChecksum(const std::string& data, const std::string& expected) const;
    bool verifySignature(const UpdatePackage& pkg) const;

    // Installation
    UpdateResult stageUpdate(uint64_t id);
    UpdateResult commitStagedUpdate(uint64_t id);
    UpdateResult installUpdate(uint64_t id);
    UpdateResult rollback(uint64_t id);
    std::vector<RollbackPoint> getRollbackPoints() const;
    RollbackPoint getRollbackPoint(uint64_t updateId) const;

    // History
    std::vector<UpdatePackage> getHistory() const;
    UpdateResult clearHistory();

    // Query
    std::vector<UpdatePackage> getUpdatesByState(UpdateState state) const;
    size_t getCountByType(UpdateType type) const;
    size_t getCountByChannel(UpdateChannel channel) const;
    size_t getCountByPriority(UpdatePriority priority) const;

    // Callbacks
    using UpdateCallback = std::function<void(const UpdatePackage&)>;
    using ProgressCallback = std::function<void(const UpdateProgress&)>;
    using RollbackCallback = std::function<void(const RollbackPoint&)>;
    void setUpdateAvailableCallback(UpdateCallback cb) { availableCb_ = cb; }
    void setDownloadProgressCallback(ProgressCallback cb) { progressCb_ = cb; }
    void setVerifyCompleteCallback(UpdateCallback cb) { verifyCb_ = cb; }
    void setInstallCompleteCallback(UpdateCallback cb) { installCompleteCb_ = cb; }
    void setInstallFailedCallback(UpdateCallback cb) { installFailedCb_ = cb; }
    void setRollbackCallback(RollbackCallback cb) { rollbackCb_ = cb; }

    // Stats
    UpdateStats getStats() const;
    void resetStats();

    // String helpers
    static const char* updateTypeToString(UpdateType type);
    static const char* updateStateToString(UpdateState state);
    static const char* updateChannelToString(UpdateChannel channel);
    static const char* updatePriorityToString(UpdatePriority priority);
    static const char* updatePolicyToString(UpdatePolicy policy);
    static const char* updateResultToString(UpdateResult result);
    static UpdateType stringToUpdateType(const std::string& str);
    static UpdateChannel stringToUpdateChannel(const std::string& str);
    static UpdatePriority stringToUpdatePriority(const std::string& str);
    static UpdatePolicy stringToUpdatePolicy(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxQueueSize_ = 50;
    size_t maxHistorySize_ = 200;
    uint64_t nextId_ = 1;
    uint64_t nextRollbackId_ = 1;

    std::vector<UpdatePackage> availableUpdates_;
    std::vector<uint64_t> downloadQueue_;        // Queued update IDs
    std::map<uint64_t, UpdateProgress> progress_; // key = updateId
    std::vector<UpdatePackage> history_;
    std::vector<RollbackPoint> rollbackPoints_;

    UpdatePolicy updatePolicy_ = UpdatePolicy::MANUAL;
    bool autoRollback_ = true;
    bool anonymousChecks_ = true;
    bool telemetryEnabled_ = false;  // Privacy: disabled by default
    UpdateChannel allowedChannel_ = UpdateChannel::STABLE;
    bool failNextInstall_ = false;  // Test hook for simulated install failure

    UpdateSchedule schedule_;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    // Callbacks
    UpdateCallback availableCb_;
    ProgressCallback progressCb_;
    UpdateCallback verifyCb_;
    UpdateCallback installCompleteCb_;
    UpdateCallback installFailedCb_;
    RollbackCallback rollbackCb_;

    // Stats
    uint64_t totalChecks_ = 0;
    uint64_t totalAvailable_ = 0;
    uint64_t totalDownloadsStarted_ = 0;
    uint64_t totalDownloadsCompleted_ = 0;
    uint64_t totalInstallsAttempted_ = 0;
    uint64_t totalInstallsSucceeded_ = 0;
    uint64_t totalInstallsFailed_ = 0;
    uint64_t totalRollbacks_ = 0;
    uint64_t totalCancelled_ = 0;
    uint64_t totalByType_[6] = {};
    uint64_t totalByChannel_[4] = {};
    uint64_t totalByPriority_[4] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    int findAvailableIndex(uint64_t id) const;
    int findProgressIndex(uint64_t id) const;
    int findRollbackIndex(uint64_t updateId) const;
    bool isChannelAllowed(UpdateChannel channel) const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    void moveToHistory(uint64_t id, UpdateState finalState);
    void updateProgressState(uint64_t id, UpdateState state, uint32_t percent);
};

}  // namespace phantom::updatemanager
