/*
 * Phantom OS - Update Manager Implementation
 * v0.20.0
 * License: GPL-3.0
 */

#include "phantom/updatemanager/update_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"
#include <algorithm>
#include <sstream>
#include <cstring>
#include <cstdio>

namespace phantom::updatemanager {

// ============================================================
// Private helpers
// ============================================================

uint64_t UpdateManager::getCurrentTimeMs() const {
    auto now = std::chrono::steady_clock::now();
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count());
}

int UpdateManager::findAvailableIndex(uint64_t id) const {
    for (size_t i = 0; i < availableUpdates_.size(); ++i) {
        if (availableUpdates_[i].id == id) return static_cast<int>(i);
    }
    return -1;
}

int UpdateManager::findProgressIndex(uint64_t id) const {
    // Progress is stored in a map, so this returns whether present via -1/0
    return progress_.count(id) > 0 ? 0 : -1;
}

int UpdateManager::findRollbackIndex(uint64_t updateId) const {
    for (size_t i = 0; i < rollbackPoints_.size(); ++i) {
        if (rollbackPoints_[i].updateId == updateId) return static_cast<int>(i);
    }
    return -1;
}

bool UpdateManager::isChannelAllowed(UpdateChannel channel) const {
    // SECURITY channel updates are always allowed regardless of allowedChannel_
    if (channel == UpdateChannel::SECURITY) return true;
    return channel == allowedChannel_;
}

void UpdateManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "UpdateManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "UpdateManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "UpdateManager");
        }
    }
}

void UpdateManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId, "update_manager", 0, message);
    }
}

void UpdateManager::moveToHistory(uint64_t id, UpdateState finalState) {
    int idx = findAvailableIndex(id);
    if (idx >= 0) {
        UpdatePackage pkg = availableUpdates_[idx];
        if (history_.size() >= maxHistorySize_) {
            history_.erase(history_.begin());
        }
        history_.push_back(pkg);
    }

    // Remove from download queue if present
    downloadQueue_.erase(
        std::remove(downloadQueue_.begin(), downloadQueue_.end(), id),
        downloadQueue_.end());
}

void UpdateManager::updateProgressState(uint64_t id, UpdateState state, uint32_t percent) {
    auto it = progress_.find(id);
    if (it == progress_.end()) {
        UpdateProgress p;
        p.updateId = id;
        p.state = state;
        p.progressPercent = std::min(percent, 100u);
        p.lastUpdated = getCurrentTimeMs();
        progress_[id] = p;
    } else {
        it->second.state = state;
        it->second.progressPercent = std::min(percent, 100u);
        it->second.lastUpdated = getCurrentTimeMs();
    }
}

// ============================================================
// Lifecycle
// ============================================================

UpdateResult UpdateManager::initialize(size_t maxQueueSize, size_t maxHistorySize) {
    if (initialized_) return UpdateResult::ALREADY_INITIALIZED;
    initialized_ = true;
    maxQueueSize_ = maxQueueSize;
    maxHistorySize_ = maxHistorySize;
    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::shutdown() {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    availableUpdates_.clear();
    downloadQueue_.clear();
    progress_.clear();
    history_.clear();
    rollbackPoints_.clear();
    totalChecks_ = 0;
    totalAvailable_ = 0;
    totalDownloadsStarted_ = 0;
    totalDownloadsCompleted_ = 0;
    totalInstallsAttempted_ = 0;
    totalInstallsSucceeded_ = 0;
    totalInstallsFailed_ = 0;
    totalRollbacks_ = 0;
    totalCancelled_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalByChannel_, 0, sizeof(totalByChannel_));
    memset(totalByPriority_, 0, sizeof(totalByPriority_));
    initialized_ = false;
    return UpdateResult::SUCCESS;
}

// ============================================================
// Schedule / maintenance window
// ============================================================

bool UpdateManager::isWithinMaintenanceWindow(uint64_t currentTimeMs) const {
    if (!schedule_.maintenanceWindow.enabled) return true;  // No restriction if disabled

    if (currentTimeMs == 0) currentTimeMs = getCurrentTimeMs();

    // Simulate hour-of-day using modulo of a 24h cycle for deterministic testing.
    // In this prototype, callers can pass a timestamp representing ms-since-midnight.
    uint64_t msInDay = currentTimeMs % (24ULL * 3600ULL * 1000ULL);
    uint64_t windowStartMs = (schedule_.maintenanceWindow.startHour * 3600ULL +
                              schedule_.maintenanceWindow.startMinute * 60ULL) * 1000ULL;
    uint64_t windowEndMs = windowStartMs + schedule_.maintenanceWindow.durationMinutes * 60ULL * 1000ULL;

    if (windowEndMs <= 24ULL * 3600ULL * 1000ULL) {
        return msInDay >= windowStartMs && msInDay < windowEndMs;
    } else {
        // Window wraps past midnight
        return msInDay >= windowStartMs || msInDay < (windowEndMs - 24ULL * 3600ULL * 1000ULL);
    }
}

bool UpdateManager::shouldAutoCheck(uint64_t currentTimeMs) const {
    if (!schedule_.autoCheckEnabled) return false;
    if (currentTimeMs == 0) currentTimeMs = getCurrentTimeMs();
    if (schedule_.nextCheckTime == 0) return true;  // Never checked before
    return currentTimeMs >= schedule_.nextCheckTime;
}

// ============================================================
// Update management
// ============================================================

UpdateResult UpdateManager::addAvailableUpdate(const UpdatePackage& pkg) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    if (pkg.name.empty() || pkg.version.empty()) return UpdateResult::INVALID_PACKAGE;

    UpdatePackage newPkg = pkg;
    newPkg.id = nextId_++;
    newPkg.availableSince = getCurrentTimeMs();

    availableUpdates_.push_back(newPkg);
    updateProgressState(newPkg.id, UpdateState::AVAILABLE, 0);

    totalAvailable_++;
    totalByType_[static_cast<int>(newPkg.type)]++;
    totalByChannel_[static_cast<int>(newPkg.channel)]++;
    totalByPriority_[static_cast<int>(newPkg.priority)]++;

    logToServer("info", "Update available: " + newPkg.name + " v" + newPkg.version);

    if (availableCb_) availableCb_(newPkg);

    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::removeAvailableUpdate(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    availableUpdates_.erase(availableUpdates_.begin() + idx);
    downloadQueue_.erase(
        std::remove(downloadQueue_.begin(), downloadQueue_.end(), id),
        downloadQueue_.end());
    progress_.erase(id);

    return UpdateResult::SUCCESS;
}

std::vector<UpdatePackage> UpdateManager::getAvailableUpdates() const {
    return availableUpdates_;
}

std::vector<UpdatePackage> UpdateManager::getUpdatesByType(UpdateType type) const {
    std::vector<UpdatePackage> result;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.type == type) result.push_back(pkg);
    }
    return result;
}

std::vector<UpdatePackage> UpdateManager::getUpdatesByChannel(UpdateChannel channel) const {
    std::vector<UpdatePackage> result;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.channel == channel) result.push_back(pkg);
    }
    return result;
}

std::vector<UpdatePackage> UpdateManager::getUpdatesByPriority(UpdatePriority priority) const {
    std::vector<UpdatePackage> result;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.priority == priority) result.push_back(pkg);
    }
    return result;
}

UpdatePackage UpdateManager::getUpdateById(uint64_t id) const {
    int idx = findAvailableIndex(id);
    if (idx >= 0) return availableUpdates_[idx];

    for (const auto& pkg : history_) {
        if (pkg.id == id) return pkg;
    }

    return UpdatePackage{};
}

// ============================================================
// Version comparison
// ============================================================

int UpdateManager::compareVersions(const std::string& v1, const std::string& v2) {
    // Parse dot-separated numeric components; ignore any pre-release suffix after '-'
    auto parse = [](const std::string& v) {
        std::vector<int> parts;
        std::string cleaned = v;
        size_t dashPos = cleaned.find('-');
        if (dashPos != std::string::npos) cleaned = cleaned.substr(0, dashPos);

        std::stringstream ss(cleaned);
        std::string segment;
        while (std::getline(ss, segment, '.')) {
            try {
                parts.push_back(std::stoi(segment));
            } catch (...) {
                parts.push_back(0);
            }
        }
        return parts;
    };

    std::vector<int> p1 = parse(v1);
    std::vector<int> p2 = parse(v2);

    size_t maxLen = std::max(p1.size(), p2.size());
    for (size_t i = 0; i < maxLen; ++i) {
        int a = i < p1.size() ? p1[i] : 0;
        int b = i < p2.size() ? p2[i] : 0;
        if (a < b) return -1;
        if (a > b) return 1;
    }
    return 0;
}

bool UpdateManager::isNewerVersion(const std::string& current, const std::string& candidate) {
    return compareVersions(candidate, current) > 0;
}

// ============================================================
// Update checking
// ============================================================

UpdateResult UpdateManager::checkForUpdates() {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;

    totalChecks_++;
    schedule_.lastCheckTime = getCurrentTimeMs();
    schedule_.nextCheckTime = schedule_.lastCheckTime +
        static_cast<uint64_t>(schedule_.checkIntervalHours) * 3600ULL * 1000ULL;

    std::string checkMsg = anonymousChecks_ ? "Anonymous update check performed"
                                             : "Update check performed";
    logToServer("info", checkMsg);

    return UpdateResult::SUCCESS;
}

std::vector<UpdatePackage> UpdateManager::getPendingUpdates() const {
    std::vector<UpdatePackage> result;
    for (const auto& pkg : availableUpdates_) {
        if (!isChannelAllowed(pkg.channel)) continue;
        if (isNewerVersion(pkg.currentVersion, pkg.version)) {
            result.push_back(pkg);
        } else if (pkg.currentVersion.empty()) {
            // No current version to compare - treat as pending
            result.push_back(pkg);
        }
    }
    return result;
}

// ============================================================
// Download management
// ============================================================

UpdateResult UpdateManager::queueForDownload(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    if (downloadQueue_.size() >= maxQueueSize_) {
        return UpdateResult::QUEUE_FULL;
    }

    // Check if already queued
    if (std::find(downloadQueue_.begin(), downloadQueue_.end(), id) != downloadQueue_.end()) {
        return UpdateResult::SUCCESS;  // Idempotent
    }

    downloadQueue_.push_back(id);
    updateProgressState(id, UpdateState::QUEUED, 0);
    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::startDownload(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    // Policy check
    if (updatePolicy_ == UpdatePolicy::NOTIFY_ONLY || updatePolicy_ == UpdatePolicy::MANUAL) {
        // Manual/notify-only still allows explicit user-triggered download calls
    }

    UpdatePackage& pkg = availableUpdates_[idx];

    auto progIt = progress_.find(id);
    if (progIt != progress_.end() &&
        (progIt->second.state == UpdateState::DOWNLOADING ||
         progIt->second.state == UpdateState::DOWNLOADED)) {
        return UpdateResult::BAD_STATE;
    }

    UpdateProgress prog;
    prog.updateId = id;
    prog.state = UpdateState::DOWNLOADING;
    prog.totalBytes = pkg.sizeBytes;
    prog.downloadedBytes = 0;
    prog.progressPercent = 0;
    prog.lastUpdated = getCurrentTimeMs();
    progress_[id] = prog;

    totalDownloadsStarted_++;

    logToServer("info", "Download started: " + pkg.name);

    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::pauseDownload(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    auto it = progress_.find(id);
    if (it == progress_.end()) return UpdateResult::NOT_FOUND;
    if (it->second.state != UpdateState::DOWNLOADING) return UpdateResult::BAD_STATE;

    it->second.state = UpdateState::PAUSED;
    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::resumeDownload(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    auto it = progress_.find(id);
    if (it == progress_.end()) return UpdateResult::NOT_FOUND;
    if (it->second.state != UpdateState::PAUSED) return UpdateResult::BAD_STATE;

    it->second.state = UpdateState::DOWNLOADING;
    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::cancelDownload(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    auto it = progress_.find(id);
    if (it == progress_.end()) return UpdateResult::NOT_FOUND;

    it->second.state = UpdateState::CANCELLED;
    totalCancelled_++;

    downloadQueue_.erase(
        std::remove(downloadQueue_.begin(), downloadQueue_.end(), id),
        downloadQueue_.end());

    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::updateDownloadProgress(uint64_t id, uint64_t downloadedBytes, uint32_t speedBps) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    auto it = progress_.find(id);
    if (it == progress_.end()) return UpdateResult::NOT_FOUND;
    if (it->second.state != UpdateState::DOWNLOADING) return UpdateResult::BAD_STATE;

    UpdateProgress& prog = it->second;
    prog.downloadedBytes = std::min(downloadedBytes, prog.totalBytes > 0 ? prog.totalBytes : downloadedBytes);
    prog.downloadSpeed = speedBps;
    prog.lastUpdated = getCurrentTimeMs();

    if (prog.totalBytes > 0) {
        uint32_t pct = static_cast<uint32_t>((prog.downloadedBytes * 100) / prog.totalBytes);
        prog.progressPercent = std::min(pct, 100u);
    } else {
        prog.progressPercent = 100;
    }

    if (speedBps > 0 && prog.totalBytes > prog.downloadedBytes) {
        prog.etaSeconds = (prog.totalBytes - prog.downloadedBytes) / speedBps;
    } else {
        prog.etaSeconds = 0;
    }

    if (progressCb_) progressCb_(prog);

    if (prog.progressPercent >= 100) {
        prog.state = UpdateState::DOWNLOADED;
        totalDownloadsCompleted_++;
        logToServer("info", "Download completed for update id " + std::to_string(id));
    }

    return UpdateResult::SUCCESS;
}

UpdateProgress UpdateManager::getDownloadProgress(uint64_t id) const {
    auto it = progress_.find(id);
    if (it != progress_.end()) return it->second;
    return UpdateProgress{};
}

std::vector<UpdateProgress> UpdateManager::getActiveDownloads() const {
    std::vector<UpdateProgress> result;
    for (const auto& [id, prog] : progress_) {
        if (prog.state == UpdateState::DOWNLOADING || prog.state == UpdateState::PAUSED) {
            result.push_back(prog);
        }
    }
    return result;
}

// ============================================================
// Verification
// ============================================================

std::string UpdateManager::computeChecksum(const std::string& data) const {
    // FNV-1a based checksum model (not cryptographic SHA-256).
    // Deterministic and stable for prototype verification purposes.
    uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    std::ostringstream ss;
    ss << std::hex << hash;
    return ss.str();
}

bool UpdateManager::verifyChecksum(const std::string& data, const std::string& expected) const {
    if (expected.empty()) return false;
    return computeChecksum(data) == expected;
}

bool UpdateManager::verifySignature(const UpdatePackage& pkg) const {
    // Simulated signature model: non-empty signature is considered present.
    // Actual cryptographic verification is out of scope for this prototype.
    return !pkg.signature.empty();
}

UpdateResult UpdateManager::verifyUpdate(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    auto it = progress_.find(id);
    if (it == progress_.end() || it->second.state != UpdateState::DOWNLOADED) {
        return UpdateResult::BAD_STATE;
    }

    UpdatePackage& pkg = availableUpdates_[idx];
    it->second.state = UpdateState::VERIFYING;

    // Verify checksum using package name+version+size as the simulated payload
    std::string simulatedPayload = pkg.name + pkg.version + std::to_string(pkg.sizeBytes);

    if (!pkg.checksum.empty()) {
        std::string computed = computeChecksum(simulatedPayload);
        if (computed != pkg.checksum) {
            it->second.state = UpdateState::FAILED;
            it->second.errorMessage = "Checksum verification failed";
            logToServer("error", "Checksum verification failed for " + pkg.name);
            if (installFailedCb_) installFailedCb_(pkg);
            return UpdateResult::CHECKSUM_FAILED;
        }
    }

    if (!verifySignature(pkg)) {
        it->second.state = UpdateState::FAILED;
        it->second.errorMessage = "Signature verification failed";
        logToServer("error", "Signature verification failed for " + pkg.name);
        if (installFailedCb_) installFailedCb_(pkg);
        return UpdateResult::SIGNATURE_FAILED;
    }

    it->second.state = UpdateState::VERIFIED;
    logToServer("info", "Verification passed for " + pkg.name);

    if (verifyCb_) verifyCb_(pkg);

    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::setChecksum(uint64_t id, const std::string& checksum) {
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;
    availableUpdates_[idx].checksum = checksum;
    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::setSignature(uint64_t id, const std::string& signature) {
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;
    availableUpdates_[idx].signature = signature;
    return UpdateResult::SUCCESS;
}

// ============================================================
// Installation
// ============================================================

UpdateResult UpdateManager::stageUpdate(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    auto it = progress_.find(id);
    if (it == progress_.end() || it->second.state != UpdateState::VERIFIED) {
        return UpdateResult::VERIFICATION_REQUIRED;
    }

    it->second.state = UpdateState::STAGED;
    logToServer("info", "Update staged: " + availableUpdates_[idx].name);

    return UpdateResult::SUCCESS;
}

UpdateResult UpdateManager::commitStagedUpdate(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    auto it = progress_.find(id);
    if (it == progress_.end() || it->second.state != UpdateState::STAGED) {
        return UpdateResult::STAGING_REQUIRED;
    }

    return installUpdate(id);
}

UpdateResult UpdateManager::installUpdate(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    int idx = findAvailableIndex(id);
    if (idx < 0) return UpdateResult::NOT_FOUND;

    auto it = progress_.find(id);
    if (it == progress_.end() ||
        (it->second.state != UpdateState::VERIFIED && it->second.state != UpdateState::STAGED)) {
        return UpdateResult::VERIFICATION_REQUIRED;
    }

    UpdatePackage& pkg = availableUpdates_[idx];

    // Maintenance window check (critical updates can bypass if configured)
    bool isCritical = (pkg.priority == UpdatePriority::CRITICAL || pkg.securityUpdate);
    if (!isWithinMaintenanceWindow() &&
        !(isCritical && schedule_.maintenanceWindow.allowCriticalBypass)) {
        return UpdateResult::MAINTENANCE_BLOCKED;
    }

    totalInstallsAttempted_++;
    it->second.state = UpdateState::INSTALLING;

    // Create rollback point before install
    RollbackPoint rp;
    rp.id = nextRollbackId_++;
    rp.updateId = id;
    rp.previousVersion = pkg.currentVersion;
    rp.newVersion = pkg.version;
    rp.timestamp = getCurrentTimeMs();
    rp.committed = false;
    rollbackPoints_.push_back(rp);

    // Simulated install: use failNextInstall_ test hook for deterministic failure
    bool installSuccess = !failNextInstall_;
    failNextInstall_ = false;  // Reset after use

    if (installSuccess) {
        it->second.state = UpdateState::INSTALLED;
        it->second.progressPercent = 100;
        totalInstallsSucceeded_++;

        // Mark rollback point as committed
        int rbIdx = findRollbackIndex(id);
        if (rbIdx >= 0) {
            rollbackPoints_[rbIdx].committed = true;
        }

        pkg.currentVersion = pkg.version;

        logToServer("info", "Update installed successfully: " + pkg.name + " v" + pkg.version);

        if (installCompleteCb_) installCompleteCb_(pkg);

        moveToHistory(id, UpdateState::INSTALLED);

        return UpdateResult::SUCCESS;
    } else {
        it->second.state = UpdateState::FAILED;
        totalInstallsFailed_++;

        logToServer("error", "Update installation failed: " + pkg.name);
        notifyCrashReporter(pkg.appId.empty() ? "system" : pkg.appId,
                            "Update installation failed: " + pkg.name);

        if (installFailedCb_) installFailedCb_(pkg);

        if (autoRollback_) {
            rollback(id);
        }

        return UpdateResult::INSTALL_FAILED;
    }
}

UpdateResult UpdateManager::rollback(uint64_t id) {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;

    int rbIdx = findRollbackIndex(id);
    if (rbIdx < 0) return UpdateResult::ROLLBACK_FAILED;

    RollbackPoint& rp = rollbackPoints_[rbIdx];
    if (rp.rolledBack) return UpdateResult::ROLLBACK_FAILED;

    int idx = findAvailableIndex(id);
    if (idx >= 0) {
        availableUpdates_[idx].currentVersion = rp.previousVersion;
    }

    auto it = progress_.find(id);
    if (it != progress_.end()) {
        it->second.state = UpdateState::ROLLED_BACK;
    }

    rp.rolledBack = true;
    totalRollbacks_++;

    logToServer("warn", "Rolled back update id " + std::to_string(id) +
                " to version " + rp.previousVersion);

    if (rollbackCb_) rollbackCb_(rp);

    return UpdateResult::SUCCESS;
}

std::vector<RollbackPoint> UpdateManager::getRollbackPoints() const {
    return rollbackPoints_;
}

RollbackPoint UpdateManager::getRollbackPoint(uint64_t updateId) const {
    int idx = findRollbackIndex(updateId);
    if (idx >= 0) return rollbackPoints_[idx];
    return RollbackPoint{};
}

// ============================================================
// History
// ============================================================

std::vector<UpdatePackage> UpdateManager::getHistory() const {
    return history_;
}

UpdateResult UpdateManager::clearHistory() {
    if (!initialized_) return UpdateResult::NOT_INITIALIZED;
    history_.clear();
    return UpdateResult::SUCCESS;
}

// ============================================================
// Query
// ============================================================

std::vector<UpdatePackage> UpdateManager::getUpdatesByState(UpdateState state) const {
    std::vector<UpdatePackage> result;
    for (const auto& pkg : availableUpdates_) {
        auto it = progress_.find(pkg.id);
        if (it != progress_.end() && it->second.state == state) {
            result.push_back(pkg);
        }
    }
    return result;
}

size_t UpdateManager::getCountByType(UpdateType type) const {
    size_t count = 0;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.type == type) ++count;
    }
    return count;
}

size_t UpdateManager::getCountByChannel(UpdateChannel channel) const {
    size_t count = 0;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.channel == channel) ++count;
    }
    return count;
}

size_t UpdateManager::getCountByPriority(UpdatePriority priority) const {
    size_t count = 0;
    for (const auto& pkg : availableUpdates_) {
        if (pkg.priority == priority) ++count;
    }
    return count;
}

// ============================================================
// Stats
// ============================================================

UpdateStats UpdateManager::getStats() const {
    UpdateStats stats;
    stats.totalChecks = totalChecks_;
    stats.totalAvailable = totalAvailable_;
    stats.totalDownloadsStarted = totalDownloadsStarted_;
    stats.totalDownloadsCompleted = totalDownloadsCompleted_;
    stats.totalInstallsAttempted = totalInstallsAttempted_;
    stats.totalInstallsSucceeded = totalInstallsSucceeded_;
    stats.totalInstallsFailed = totalInstallsFailed_;
    stats.totalRollbacks = totalRollbacks_;
    stats.totalCancelled = totalCancelled_;
    stats.activeQueueSize = downloadQueue_.size();
    stats.historySize = history_.size();

    memcpy(stats.totalByType, totalByType_, sizeof(totalByType_));
    memcpy(stats.totalByChannel, totalByChannel_, sizeof(totalByChannel_));
    memcpy(stats.totalByPriority, totalByPriority_, sizeof(totalByPriority_));

    for (const auto& pkg : availableUpdates_) {
        std::string key = pkg.packageName.empty() ? pkg.name : pkg.packageName;
        stats.perPackageCounts[key]++;
    }
    for (const auto& pkg : history_) {
        std::string key = pkg.packageName.empty() ? pkg.name : pkg.packageName;
        stats.perPackageCounts[key]++;
    }

    return stats;
}

void UpdateManager::resetStats() {
    totalChecks_ = 0;
    totalAvailable_ = 0;
    totalDownloadsStarted_ = 0;
    totalDownloadsCompleted_ = 0;
    totalInstallsAttempted_ = 0;
    totalInstallsSucceeded_ = 0;
    totalInstallsFailed_ = 0;
    totalRollbacks_ = 0;
    totalCancelled_ = 0;
    memset(totalByType_, 0, sizeof(totalByType_));
    memset(totalByChannel_, 0, sizeof(totalByChannel_));
    memset(totalByPriority_, 0, sizeof(totalByPriority_));
}

// ============================================================
// String helpers
// ============================================================

const char* UpdateManager::updateTypeToString(UpdateType type) {
    switch (type) {
        case UpdateType::OS: return "OS";
        case UpdateType::APP: return "APP";
        case UpdateType::SECURITY_PATCH: return "SECURITY_PATCH";
        case UpdateType::DRIVER: return "DRIVER";
        case UpdateType::CONFIG: return "CONFIG";
        case UpdateType::FIRMWARE: return "FIRMWARE";
    }
    return "UNKNOWN";
}

const char* UpdateManager::updateStateToString(UpdateState state) {
    switch (state) {
        case UpdateState::IDLE: return "IDLE";
        case UpdateState::CHECKING: return "CHECKING";
        case UpdateState::AVAILABLE: return "AVAILABLE";
        case UpdateState::QUEUED: return "QUEUED";
        case UpdateState::DOWNLOADING: return "DOWNLOADING";
        case UpdateState::PAUSED: return "PAUSED";
        case UpdateState::DOWNLOADED: return "DOWNLOADED";
        case UpdateState::VERIFYING: return "VERIFYING";
        case UpdateState::VERIFIED: return "VERIFIED";
        case UpdateState::STAGED: return "STAGED";
        case UpdateState::INSTALLING: return "INSTALLING";
        case UpdateState::INSTALLED: return "INSTALLED";
        case UpdateState::FAILED: return "FAILED";
        case UpdateState::CANCELLED: return "CANCELLED";
        case UpdateState::ROLLED_BACK: return "ROLLED_BACK";
    }
    return "UNKNOWN";
}

const char* UpdateManager::updateChannelToString(UpdateChannel channel) {
    switch (channel) {
        case UpdateChannel::STABLE: return "STABLE";
        case UpdateChannel::BETA: return "BETA";
        case UpdateChannel::NIGHTLY: return "NIGHTLY";
        case UpdateChannel::SECURITY: return "SECURITY";
    }
    return "UNKNOWN";
}

const char* UpdateManager::updatePriorityToString(UpdatePriority priority) {
    switch (priority) {
        case UpdatePriority::LOW: return "LOW";
        case UpdatePriority::NORMAL: return "NORMAL";
        case UpdatePriority::HIGH: return "HIGH";
        case UpdatePriority::CRITICAL: return "CRITICAL";
    }
    return "UNKNOWN";
}

const char* UpdateManager::updatePolicyToString(UpdatePolicy policy) {
    switch (policy) {
        case UpdatePolicy::MANUAL: return "MANUAL";
        case UpdatePolicy::NOTIFY_ONLY: return "NOTIFY_ONLY";
        case UpdatePolicy::AUTO_DOWNLOAD: return "AUTO_DOWNLOAD";
        case UpdatePolicy::AUTO_INSTALL: return "AUTO_INSTALL";
    }
    return "UNKNOWN";
}

const char* UpdateManager::updateResultToString(UpdateResult result) {
    switch (result) {
        case UpdateResult::SUCCESS: return "SUCCESS";
        case UpdateResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case UpdateResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case UpdateResult::INVALID_PACKAGE: return "INVALID_PACKAGE";
        case UpdateResult::NOT_FOUND: return "NOT_FOUND";
        case UpdateResult::BAD_STATE: return "BAD_STATE";
        case UpdateResult::CHECKSUM_FAILED: return "CHECKSUM_FAILED";
        case UpdateResult::SIGNATURE_FAILED: return "SIGNATURE_FAILED";
        case UpdateResult::INSTALL_FAILED: return "INSTALL_FAILED";
        case UpdateResult::ROLLBACK_FAILED: return "ROLLBACK_FAILED";
        case UpdateResult::POLICY_BLOCKED: return "POLICY_BLOCKED";
        case UpdateResult::MAINTENANCE_BLOCKED: return "MAINTENANCE_BLOCKED";
        case UpdateResult::ALREADY_INSTALLED: return "ALREADY_INSTALLED";
        case UpdateResult::CANCELLED: return "CANCELLED";
        case UpdateResult::QUEUE_FULL: return "QUEUE_FULL";
        case UpdateResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case UpdateResult::VERIFICATION_REQUIRED: return "VERIFICATION_REQUIRED";
        case UpdateResult::STAGING_REQUIRED: return "STAGING_REQUIRED";
    }
    return "UNKNOWN";
}

UpdateType UpdateManager::stringToUpdateType(const std::string& str) {
    if (str == "OS") return UpdateType::OS;
    if (str == "APP") return UpdateType::APP;
    if (str == "SECURITY_PATCH") return UpdateType::SECURITY_PATCH;
    if (str == "DRIVER") return UpdateType::DRIVER;
    if (str == "CONFIG") return UpdateType::CONFIG;
    if (str == "FIRMWARE") return UpdateType::FIRMWARE;
    return UpdateType::OS;
}

UpdateChannel UpdateManager::stringToUpdateChannel(const std::string& str) {
    if (str == "STABLE") return UpdateChannel::STABLE;
    if (str == "BETA") return UpdateChannel::BETA;
    if (str == "NIGHTLY") return UpdateChannel::NIGHTLY;
    if (str == "SECURITY") return UpdateChannel::SECURITY;
    return UpdateChannel::STABLE;
}

UpdatePriority UpdateManager::stringToUpdatePriority(const std::string& str) {
    if (str == "LOW") return UpdatePriority::LOW;
    if (str == "NORMAL") return UpdatePriority::NORMAL;
    if (str == "HIGH") return UpdatePriority::HIGH;
    if (str == "CRITICAL") return UpdatePriority::CRITICAL;
    return UpdatePriority::NORMAL;
}

UpdatePolicy UpdateManager::stringToUpdatePolicy(const std::string& str) {
    if (str == "MANUAL") return UpdatePolicy::MANUAL;
    if (str == "NOTIFY_ONLY") return UpdatePolicy::NOTIFY_ONLY;
    if (str == "AUTO_DOWNLOAD") return UpdatePolicy::AUTO_DOWNLOAD;
    if (str == "AUTO_INSTALL") return UpdatePolicy::AUTO_INSTALL;
    return UpdatePolicy::MANUAL;
}

}  // namespace phantom::updatemanager
