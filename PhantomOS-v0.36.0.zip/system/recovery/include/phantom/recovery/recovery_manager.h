/*
 * Phantom OS - Recovery Mode Manager
 * System recovery, safe mode, factory reset, and diagnostic management
 *
 * v0.22.0
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::recovery {

// ============================================================
// Enums
// ============================================================

enum class RecoveryMode {
    NORMAL_BOOT,      // Normal system boot
    SAFE_MODE,        // Safe mode (minimal services)
    RECOVERY_SHELL,   // Recovery shell (interactive)
    UPDATE_RECOVERY,  // Apply update in recovery
    BACKUP_RESTORE,   // Restore from backup in recovery
    FACTORY_RESET,    // Factory reset mode
    DIAGNOSTIC        // Diagnostic mode
};

enum class RecoveryState {
    IDLE,             // No recovery activity
    ENTERING,         // Entering recovery mode
    ACTIVE,           // Recovery mode active
    SCANNING,         // Scanning system for issues
    REPAIRING,        // Repairing filesystem or system
    RESTORING,        // Restoring from backup
    APPLYING_UPDATE,  // Applying update in recovery
    WIPING,           // Wiping data/cache
    REBOOTING,        // Rebooting after recovery
    FAILED,           // Recovery operation failed
    COMPLETED         // Recovery operation completed
};

enum class RecoveryAction {
    VERIFY_SYSTEM,      // Verify system integrity
    APPLY_UPDATE,       // Apply a pending update
    ROLLBACK_UPDATE,    // Rollback to previous version
    RESTORE_BACKUP,     // Restore from backup
    WIPE_CACHE,         // Wipe cache partition
    FACTORY_RESET,      // Factory reset
    RUN_DIAGNOSTICS,    // Run diagnostic scans
    REPAIR_FILESYSTEM   // Repair filesystem errors
};

enum class BootReason {
    NORMAL,            // Normal boot
    RECOVERY_REQUESTED,// User requested recovery
    OTA_FAILURE,       // OTA update failed
    BOOT_FAILURE,      // Boot failed (crash loop)
    SAFE_MODE_REQUESTED,// User requested safe mode
    KERNEL_PANIC,      // Kernel panic detected
    WATCHDOG_RESET,    // Hardware watchdog reset
    POWER_LOSS         // Unexpected power loss
};

enum class DiagnosticStatus {
    NOT_RUN,           // Diagnostics not yet run
    RUNNING,           // Diagnostics in progress
    PASSED,            // All checks passed
    WARNINGS,          // Completed with warnings
    FAILED,            // One or more checks failed
    SKIPPED            // Diagnostics skipped
};

enum class DiagnosticSeverity {
    INFO,             // Informational
    WARNING,           // Warning — non-critical issue
    ERROR,             // Error — should be addressed
    CRITICAL           // Critical — system may not boot
};

enum class RecoveryResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_ACTION,
    INVALID_MODE,
    NOT_FOUND,
    BAD_STATE,
    ACTION_FAILED,
    REPAIR_FAILED,
    WIPE_FAILED,
    RESET_FAILED,
    DIAGNOSTIC_FAILED,
    ALREADY_IN_RECOVERY,
    NOT_IN_RECOVERY,
    QUEUE_FULL,
    INVALID_PARAMETER,
    CANCELLED,
    VERIFICATION_FAILED,
    BACKUP_NOT_FOUND,
    UPDATE_NOT_FOUND,
    IN_PROGRESS,
    REBOOT_PENDING
};

// ============================================================
// Structs
// ============================================================

struct DiagnosticCheck {
    uint64_t id = 0;
    std::string name;
    std::string description;
    DiagnosticSeverity severity = DiagnosticSeverity::INFO;
    DiagnosticStatus status = DiagnosticStatus::NOT_RUN;
    std::string message;
    uint64_t timestamp = 0;
    bool autoRepairable = false;
};

struct DiagnosticResult {
    DiagnosticStatus overallStatus = DiagnosticStatus::NOT_RUN;
    uint64_t totalChecks = 0;
    uint64_t passed = 0;
    uint64_t warnings = 0;
    uint64_t failed = 0;
    uint64_t critical = 0;
    uint64_t skipped = 0;
    std::vector<DiagnosticCheck> checks;
    uint64_t scanDuration = 0;  // ms
    uint64_t timestamp = 0;
};

struct RecoverySession {
    uint64_t id = 0;
    RecoveryMode mode = RecoveryMode::NORMAL_BOOT;
    RecoveryState state = RecoveryState::IDLE;
    BootReason bootReason = BootReason::NORMAL;
    uint64_t startTime = 0;
    uint64_t endTime = 0;
    bool safeModeEnabled = false;
    std::string enteredBy;  // "user", "system", "auto"
    std::vector<RecoveryAction> plannedActions;
    uint64_t actionsExecuted = 0;
    uint64_t actionsSucceeded = 0;
    uint64_t actionsFailed = 0;
    bool rebootPending = false;
    std::string failureReason;
};

struct RecoveryReport {
    uint64_t sessionId = 0;
    RecoveryMode mode = RecoveryMode::NORMAL_BOOT;
    BootReason bootReason = BootReason::NORMAL;
    RecoveryState finalState = RecoveryState::IDLE;
    DiagnosticResult diagnostics;
    std::vector<std::string> actionsPerformed;
    std::vector<std::string> errors;
    uint64_t duration = 0;  // ms
    uint64_t timestamp = 0;
    bool success = false;
    std::string summary;
};

struct RecoveryProgress {
    uint64_t sessionId = 0;
    RecoveryState state = RecoveryState::IDLE;
    RecoveryAction currentAction = RecoveryAction::VERIFY_SYSTEM;
    uint32_t progressPercent = 0;  // 0-100
    uint64_t step = 0;
    uint64_t totalSteps = 0;
    std::string currentStepDescription;
    std::string errorMessage;
    uint64_t lastUpdated = 0;
};

struct RecoveryStats {
    uint64_t totalSessions = 0;
    uint64_t totalRecoveries = 0;
    uint64_t totalFactoryResets = 0;
    uint64_t totalSafeModeBoots = 0;
    uint64_t totalDiagnosticsRun = 0;
    uint64_t totalRepairs = 0;
    uint64_t totalUpdatesApplied = 0;
    uint64_t totalRollbacks = 0;
    uint64_t totalBackupRestores = 0;
    uint64_t totalCacheWipes = 0;
    uint64_t totalFailures = 0;
    uint64_t totalByMode[7] = {};       // One per RecoveryMode
    uint64_t totalByBootReason[8] = {}; // One per BootReason
    uint64_t totalDiagnosticChecks = 0;
    uint64_t totalDiagnosticFailures = 0;
};

// ============================================================
// RecoveryManager - Central recovery management service
// ============================================================

class RecoveryManager {
public:
    RecoveryManager() = default;
    ~RecoveryManager() { shutdown(); }

    // Lifecycle
    RecoveryResult initialize(size_t maxQueueSize = 20, size_t maxHistorySize = 100);
    RecoveryResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxQueueSize(size_t max) { maxQueueSize_ = max; }
    size_t getMaxQueueSize() const { return maxQueueSize_; }
    void setMaxHistorySize(size_t max) { maxHistorySize_ = max; }
    size_t getMaxHistorySize() const { return maxHistorySize_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Test hooks
    void setFailNextAction(bool fail) { failNextAction_ = fail; }
    bool getFailNextAction() const { return failNextAction_; }

    // Session management
    RecoveryResult enterRecovery(RecoveryMode mode, BootReason reason = BootReason::RECOVERY_REQUESTED,
                                 const std::string& enteredBy = "user");
    RecoveryResult exitRecovery();
    bool isInRecovery() const { return currentSession_.state != RecoveryState::IDLE; }
    RecoverySession getCurrentSession() const { return currentSession_; }
    RecoveryMode getCurrentMode() const { return currentSession_.mode; }
    BootReason getBootReason() const { return currentSession_.bootReason; }
    bool isSafeMode() const { return currentSession_.safeModeEnabled; }

    // Action queue
    RecoveryResult queueAction(RecoveryAction action);
    RecoveryResult cancelAction();
    std::vector<RecoveryAction> getActionQueue() const { return actionQueue_; }
    size_t getQueueSize() const { return actionQueue_.size(); }

    // Action execution
    RecoveryResult executeNextAction();
    RecoveryResult executeAllActions();
    RecoveryProgress getProgress() const { return progress_; }

    // Individual recovery operations
    RecoveryResult verifySystem();
    RecoveryResult applyUpdate(uint64_t updateId);
    RecoveryResult rollbackUpdate(uint64_t updateId);
    RecoveryResult restoreBackup(uint64_t backupId);
    RecoveryResult wipeCache();
    RecoveryResult factoryReset();
    RecoveryResult repairFilesystem();

    // Diagnostics
    RecoveryResult runDiagnostics();
    DiagnosticResult getDiagnosticResult() const { return lastDiagnostic_; }
    std::vector<DiagnosticCheck> getDiagnosticChecks() const { return lastDiagnostic_.checks; }

    // Recovery reports
    RecoveryReport generateReport() const;
    std::vector<RecoveryReport> getHistory() const;
    RecoveryResult clearHistory();

    // Query
    size_t getCountByMode(RecoveryMode mode) const;
    size_t getCountByBootReason(BootReason reason) const;

    // Callbacks
    using StateCallback = std::function<void(RecoveryState oldState, RecoveryState newState)>;
    using ActionCallback = std::function<void(RecoveryAction action, RecoveryResult result)>;
    using ProgressCallback = std::function<void(const RecoveryProgress&)>;
    using CompleteCallback = std::function<void(const RecoveryReport&)>;
    void setStateCallback(StateCallback cb) { stateCb_ = cb; }
    void setActionCallback(ActionCallback cb) { actionCb_ = cb; }
    void setProgressCallback(ProgressCallback cb) { progressCb_ = cb; }
    void setCompleteCallback(CompleteCallback cb) { completeCb_ = cb; }

    // Stats
    RecoveryStats getStats() const;
    void resetStats();

    // String helpers
    static const char* recoveryModeToString(RecoveryMode mode);
    static const char* recoveryStateToString(RecoveryState state);
    static const char* recoveryActionToString(RecoveryAction action);
    static const char* bootReasonToString(BootReason reason);
    static const char* diagnosticStatusToString(DiagnosticStatus status);
    static const char* diagnosticSeverityToString(DiagnosticSeverity severity);
    static const char* recoveryResultToString(RecoveryResult result);
    static RecoveryMode stringToRecoveryMode(const std::string& str);
    static RecoveryAction stringToRecoveryAction(const std::string& str);
    static BootReason stringToBootReason(const std::string& str);
    static RecoveryAction diagnosticActionFromString(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxQueueSize_ = 20;
    size_t maxHistorySize_ = 100;
    uint64_t nextSessionId_ = 1;
    uint64_t nextDiagnosticId_ = 1;

    RecoverySession currentSession_;
    std::vector<RecoveryAction> actionQueue_;
    RecoveryProgress progress_;
    DiagnosticResult lastDiagnostic_;
    std::vector<RecoveryReport> history_;

    bool failNextAction_ = false;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    // Callbacks
    StateCallback stateCb_;
    ActionCallback actionCb_;
    ProgressCallback progressCb_;
    CompleteCallback completeCb_;

    // Stats
    uint64_t totalSessions_ = 0;
    uint64_t totalRecoveries_ = 0;
    uint64_t totalFactoryResets_ = 0;
    uint64_t totalSafeModeBoots_ = 0;
    uint64_t totalDiagnosticsRun_ = 0;
    uint64_t totalRepairs_ = 0;
    uint64_t totalUpdatesApplied_ = 0;
    uint64_t totalRollbacks_ = 0;
    uint64_t totalBackupRestores_ = 0;
    uint64_t totalCacheWipes_ = 0;
    uint64_t totalFailures_ = 0;
    uint64_t totalByMode_[7] = {};
    uint64_t totalByBootReason_[8] = {};
    uint64_t totalDiagnosticChecks_ = 0;
    uint64_t totalDiagnosticFailures_ = 0;

    // Helpers
    uint64_t getCurrentTimeMs() const;
    void changeState(RecoveryState newState);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    void updateProgress(RecoveryAction action, uint32_t percent, const std::string& stepDesc);
    void moveToHistory(const RecoveryReport& report);
    RecoveryResult executeAction(RecoveryAction action);
    std::vector<DiagnosticCheck> generateDefaultChecks();
    void finalizeSession(bool success, const std::string& summary);
};

}  // namespace phantom::recovery
