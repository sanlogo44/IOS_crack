/*
 * Phantom OS - Recovery Mode Manager Implementation
 *
 * v0.22.0
 * License: GPL-3.0
 */

#include "phantom/recovery/recovery_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <sstream>
#include <cstdlib>

namespace phantom::recovery {

// ============================================================
// Helpers
// ============================================================

uint64_t RecoveryManager::getCurrentTimeMs() const {
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

void RecoveryManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "RecoveryManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "RecoveryManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "RecoveryManager");
        }
    }
}

void RecoveryManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId, "recovery_manager", 0, message);
    }
}

void RecoveryManager::changeState(RecoveryState newState) {
    RecoveryState oldState = currentSession_.state;
    if (oldState == newState) return;
    currentSession_.state = newState;
    if (stateCb_) stateCb_(oldState, newState);
}

void RecoveryManager::updateProgress(RecoveryAction action, uint32_t percent, const std::string& stepDesc) {
    progress_.currentAction = action;
    progress_.state = currentSession_.state;
    progress_.progressPercent = (percent > 100) ? 100 : percent;
    progress_.currentStepDescription = stepDesc;
    progress_.lastUpdated = getCurrentTimeMs();
    if (progressCb_) progressCb_(progress_);
}

void RecoveryManager::moveToHistory(const RecoveryReport& report) {
    if (history_.size() >= maxHistorySize_) {
        history_.erase(history_.begin());
    }
    history_.push_back(report);
}

// ============================================================
// Lifecycle
// ============================================================

RecoveryResult RecoveryManager::initialize(size_t maxQueueSize, size_t maxHistorySize) {
    if (initialized_) return RecoveryResult::ALREADY_INITIALIZED;

    maxQueueSize_ = maxQueueSize;
    maxHistorySize_ = maxHistorySize;
    nextSessionId_ = 1;
    nextDiagnosticId_ = 1;

    currentSession_ = RecoverySession{};
    actionQueue_.clear();
    progress_ = RecoveryProgress{};
    lastDiagnostic_ = DiagnosticResult{};
    history_.clear();
    failNextAction_ = false;

    // Reset stats
    totalSessions_ = 0;
    totalRecoveries_ = 0;
    totalFactoryResets_ = 0;
    totalSafeModeBoots_ = 0;
    totalDiagnosticsRun_ = 0;
    totalRepairs_ = 0;
    totalUpdatesApplied_ = 0;
    totalRollbacks_ = 0;
    totalBackupRestores_ = 0;
    totalCacheWipes_ = 0;
    totalFailures_ = 0;
    totalDiagnosticChecks_ = 0;
    totalDiagnosticFailures_ = 0;
    for (int i = 0; i < 7; ++i) totalByMode_[i] = 0;
    for (int i = 0; i < 8; ++i) totalByBootReason_[i] = 0;

    initialized_ = true;
    logToServer("info", "RecoveryManager initialized");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::shutdown() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;

    // If in recovery, finalize session
    if (isInRecovery()) {
        finalizeSession(false, "Shutdown during recovery");
    }

    initialized_ = false;
    currentSession_ = RecoverySession{};
    actionQueue_.clear();
    progress_ = RecoveryProgress{};
    lastDiagnostic_ = DiagnosticResult{};
    history_.clear();
    failNextAction_ = false;
    stateCb_ = nullptr;
    actionCb_ = nullptr;
    progressCb_ = nullptr;
    completeCb_ = nullptr;

    return RecoveryResult::SUCCESS;
}

// ============================================================
// Session management
// ============================================================

RecoveryResult RecoveryManager::enterRecovery(RecoveryMode mode, BootReason reason,
                                               const std::string& enteredBy) {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (isInRecovery()) return RecoveryResult::ALREADY_IN_RECOVERY;

    currentSession_ = RecoverySession{};
    currentSession_.id = nextSessionId_++;
    currentSession_.mode = mode;
    currentSession_.bootReason = reason;
    currentSession_.enteredBy = enteredBy;
    currentSession_.startTime = getCurrentTimeMs();
    currentSession_.safeModeEnabled = (mode == RecoveryMode::SAFE_MODE);

    changeState(RecoveryState::ENTERING);
    totalSessions_++;
    totalRecoveries_++;
    totalByMode_[static_cast<int>(mode)]++;
    totalByBootReason_[static_cast<int>(reason)]++;

    if (mode == RecoveryMode::SAFE_MODE) totalSafeModeBoots_++;
    if (mode == RecoveryMode::FACTORY_RESET) totalFactoryResets_++;

    changeState(RecoveryState::ACTIVE);

    std::string msg = "Entered recovery mode: " + std::string(recoveryModeToString(mode)) +
                      " (reason: " + std::string(bootReasonToString(reason)) + ")";
    logToServer("info", msg);

    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::exitRecovery() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    // Finalize current session
    bool success = (currentSession_.actionsFailed == 0);
    std::string summary = "Recovery session " + std::to_string(currentSession_.id) +
                          " completed: " + std::to_string(currentSession_.actionsSucceeded) +
                          " succeeded, " + std::to_string(currentSession_.actionsFailed) + " failed";
    finalizeSession(success, summary);

    logToServer("info", "Exited recovery mode");
    return RecoveryResult::SUCCESS;
}

void RecoveryManager::finalizeSession(bool success, const std::string& summary) {
    currentSession_.endTime = getCurrentTimeMs();
    if (!success) totalFailures_++;

    // Set final state BEFORE generating the report so it's accurate
    changeState(success ? RecoveryState::COMPLETED : RecoveryState::FAILED);

    RecoveryReport report = generateReport();
    report.success = success;
    report.summary = summary;
    moveToHistory(report);

    changeState(RecoveryState::IDLE);
    currentSession_ = RecoverySession{};
    progress_ = RecoveryProgress{};

    if (completeCb_) completeCb_(report);
}

// ============================================================
// Action queue
// ============================================================

RecoveryResult RecoveryManager::queueAction(RecoveryAction action) {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;
    if (actionQueue_.size() >= maxQueueSize_) return RecoveryResult::QUEUE_FULL;

    actionQueue_.push_back(action);
    currentSession_.plannedActions.push_back(action);
    logToServer("info", "Action queued: " + std::string(recoveryActionToString(action)));
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::cancelAction() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    if (actionQueue_.empty()) return RecoveryResult::NOT_FOUND;

    RecoveryAction cancelled = actionQueue_.front();
    actionQueue_.erase(actionQueue_.begin());

    totalFailures_++;
    logToServer("info", "Action cancelled: " + std::string(recoveryActionToString(cancelled)));

    if (actionCb_) actionCb_(cancelled, RecoveryResult::CANCELLED);
    return RecoveryResult::SUCCESS;
}

// ============================================================
// Action execution
// ============================================================

RecoveryResult RecoveryManager::executeNextAction() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;
    if (actionQueue_.empty()) return RecoveryResult::NOT_FOUND;

    return executeAction(actionQueue_.front());
}

RecoveryResult RecoveryManager::executeAllActions() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;
    if (actionQueue_.empty()) return RecoveryResult::NOT_FOUND;

    RecoveryResult lastResult = RecoveryResult::SUCCESS;
    while (!actionQueue_.empty()) {
        lastResult = executeAction(actionQueue_.front());
        if (lastResult != RecoveryResult::SUCCESS) {
            break;
        }
    }

    return lastResult;
}

RecoveryResult RecoveryManager::executeAction(RecoveryAction action) {
    if (failNextAction_) {
        failNextAction_ = false;
        currentSession_.actionsFailed++;
        totalFailures_++;
        std::string msg = "Action failed (simulated): " + std::string(recoveryActionToString(action));
        logToServer("error", msg);
        notifyCrashReporter("recovery_manager", msg);
        if (actionCb_) actionCb_(action, RecoveryResult::ACTION_FAILED);

        // Remove from queue
        auto it = std::find(actionQueue_.begin(), actionQueue_.end(), action);
        if (it != actionQueue_.end()) actionQueue_.erase(it);

        return RecoveryResult::ACTION_FAILED;
    }

    RecoveryResult result = RecoveryResult::SUCCESS;

    switch (action) {
        case RecoveryAction::VERIFY_SYSTEM:
            result = verifySystem();
            break;
        case RecoveryAction::APPLY_UPDATE:
            result = applyUpdate(0);
            break;
        case RecoveryAction::ROLLBACK_UPDATE:
            result = rollbackUpdate(0);
            break;
        case RecoveryAction::RESTORE_BACKUP:
            result = restoreBackup(0);
            break;
        case RecoveryAction::WIPE_CACHE:
            result = wipeCache();
            break;
        case RecoveryAction::FACTORY_RESET:
            result = factoryReset();
            break;
        case RecoveryAction::RUN_DIAGNOSTICS:
            result = runDiagnostics();
            break;
        case RecoveryAction::REPAIR_FILESYSTEM:
            result = repairFilesystem();
            break;
        default:
            result = RecoveryResult::INVALID_ACTION;
            break;
    }

    currentSession_.actionsExecuted++;
    if (result == RecoveryResult::SUCCESS) {
        currentSession_.actionsSucceeded++;
    } else {
        currentSession_.actionsFailed++;
    }

    // Remove from queue
    auto it = std::find(actionQueue_.begin(), actionQueue_.end(), action);
    if (it != actionQueue_.end()) actionQueue_.erase(it);

    if (actionCb_) actionCb_(action, result);
    return result;
}

// ============================================================
// Individual recovery operations
// ============================================================

RecoveryResult RecoveryManager::verifySystem() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::SCANNING);
    updateProgress(RecoveryAction::VERIFY_SYSTEM, 50, "Verifying system integrity");

    // Simulated verification
    totalRepairs_++;
    logToServer("info", "System verification completed (simulated)");

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::VERIFY_SYSTEM, 100, "System verification complete");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::applyUpdate(uint64_t updateId) {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::APPLYING_UPDATE);
    updateProgress(RecoveryAction::APPLY_UPDATE, 50, "Applying update " + std::to_string(updateId));

    totalUpdatesApplied_++;
    logToServer("info", "Update applied in recovery (simulated): " + std::to_string(updateId));

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::APPLY_UPDATE, 100, "Update applied");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::rollbackUpdate(uint64_t updateId) {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::APPLYING_UPDATE);
    updateProgress(RecoveryAction::ROLLBACK_UPDATE, 50, "Rolling back update " + std::to_string(updateId));

    totalRollbacks_++;
    logToServer("info", "Update rollback in recovery (simulated): " + std::to_string(updateId));

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::ROLLBACK_UPDATE, 100, "Rollback complete");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::restoreBackup(uint64_t backupId) {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::RESTORING);
    updateProgress(RecoveryAction::RESTORE_BACKUP, 50, "Restoring from backup " + std::to_string(backupId));

    totalBackupRestores_++;
    logToServer("info", "Backup restore in recovery (simulated): " + std::to_string(backupId));

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::RESTORE_BACKUP, 100, "Restore complete");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::wipeCache() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::WIPING);
    updateProgress(RecoveryAction::WIPE_CACHE, 50, "Wiping cache partition");

    totalCacheWipes_++;
    logToServer("info", "Cache wipe completed (simulated)");

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::WIPE_CACHE, 100, "Cache wipe complete");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::factoryReset() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::WIPING);
    updateProgress(RecoveryAction::FACTORY_RESET, 50, "Performing factory reset");

    totalFactoryResets_++;
    logToServer("info", "Factory reset completed (simulated)");

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::FACTORY_RESET, 100, "Factory reset complete");
    return RecoveryResult::SUCCESS;
}

RecoveryResult RecoveryManager::repairFilesystem() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::REPAIRING);
    updateProgress(RecoveryAction::REPAIR_FILESYSTEM, 50, "Repairing filesystem");

    totalRepairs_++;
    logToServer("info", "Filesystem repair completed (simulated)");

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::REPAIR_FILESYSTEM, 100, "Filesystem repair complete");
    return RecoveryResult::SUCCESS;
}

// ============================================================
// Diagnostics
// ============================================================

std::vector<DiagnosticCheck> RecoveryManager::generateDefaultChecks() {
    std::vector<DiagnosticCheck> checks;

    checks.push_back({nextDiagnosticId_++, "Filesystem Check", "Verify filesystem integrity",
                      DiagnosticSeverity::WARNING, DiagnosticStatus::NOT_RUN, "", 0, true});
    checks.push_back({nextDiagnosticId_++, "Boot Partition", "Check boot partition health",
                      DiagnosticSeverity::ERROR, DiagnosticStatus::NOT_RUN, "", 0, false});
    checks.push_back({nextDiagnosticId_++, "System Partition", "Check system partition health",
                      DiagnosticSeverity::ERROR, DiagnosticStatus::NOT_RUN, "", 0, true});
    checks.push_back({nextDiagnosticId_++, "Cache Partition", "Check cache partition",
                      DiagnosticSeverity::INFO, DiagnosticStatus::NOT_RUN, "", 0, true});
    checks.push_back({nextDiagnosticId_++, "User Data", "Check user data partition",
                      DiagnosticSeverity::WARNING, DiagnosticStatus::NOT_RUN, "", 0, false});
    checks.push_back({nextDiagnosticId_++, "Kernel Log", "Analyze kernel log for errors",
                      DiagnosticSeverity::WARNING, DiagnosticStatus::NOT_RUN, "", 0, false});
    checks.push_back({nextDiagnosticId_++, "Hardware Watchdog", "Check watchdog reset status",
                      DiagnosticSeverity::CRITICAL, DiagnosticStatus::NOT_RUN, "", 0, false});
    checks.push_back({nextDiagnosticId_++, "Memory Test", "Basic memory health check",
                      DiagnosticSeverity::ERROR, DiagnosticStatus::NOT_RUN, "", 0, false});

    return checks;
}

RecoveryResult RecoveryManager::runDiagnostics() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    if (!isInRecovery()) return RecoveryResult::NOT_IN_RECOVERY;

    changeState(RecoveryState::SCANNING);

    auto checks = generateDefaultChecks();
    uint64_t startTime = getCurrentTimeMs();

    for (auto& check : checks) {
        check.status = DiagnosticStatus::PASSED;
        check.timestamp = getCurrentTimeMs();
        check.message = "Check passed (simulated)";
    }

    uint64_t duration = getCurrentTimeMs() - startTime;

    lastDiagnostic_ = DiagnosticResult{};
    lastDiagnostic_.checks = checks;
    lastDiagnostic_.totalChecks = checks.size();
    lastDiagnostic_.passed = checks.size();
    lastDiagnostic_.warnings = 0;
    lastDiagnostic_.failed = 0;
    lastDiagnostic_.critical = 0;
    lastDiagnostic_.skipped = 0;
    lastDiagnostic_.overallStatus = DiagnosticStatus::PASSED;
    lastDiagnostic_.scanDuration = duration;
    lastDiagnostic_.timestamp = getCurrentTimeMs();

    totalDiagnosticsRun_++;
    totalDiagnosticChecks_ += checks.size();

    std::string msg = "Diagnostics completed: " + std::to_string(checks.size()) + " checks, all passed (simulated)";
    logToServer("info", msg);

    changeState(RecoveryState::ACTIVE);
    updateProgress(RecoveryAction::RUN_DIAGNOSTICS, 100, msg);
    return RecoveryResult::SUCCESS;
}

// ============================================================
// Reports
// ============================================================

RecoveryReport RecoveryManager::generateReport() const {
    RecoveryReport report{};
    report.sessionId = currentSession_.id;
    report.mode = currentSession_.mode;
    report.bootReason = currentSession_.bootReason;
    report.finalState = currentSession_.state;
    report.diagnostics = lastDiagnostic_;
    report.duration = (currentSession_.endTime > 0)
                          ? (currentSession_.endTime - currentSession_.startTime)
                          : (getCurrentTimeMs() - currentSession_.startTime);
    report.timestamp = getCurrentTimeMs();
    report.success = (currentSession_.actionsFailed == 0);
    return report;
}

std::vector<RecoveryReport> RecoveryManager::getHistory() const {
    return history_;
}

RecoveryResult RecoveryManager::clearHistory() {
    if (!initialized_) return RecoveryResult::NOT_INITIALIZED;
    history_.clear();
    return RecoveryResult::SUCCESS;
}

// ============================================================
// Query
// ============================================================

size_t RecoveryManager::getCountByMode(RecoveryMode mode) const {
    return static_cast<size_t>(totalByMode_[static_cast<int>(mode)]);
}

size_t RecoveryManager::getCountByBootReason(BootReason reason) const {
    return static_cast<size_t>(totalByBootReason_[static_cast<int>(reason)]);
}

// ============================================================
// Stats
// ============================================================

RecoveryStats RecoveryManager::getStats() const {
    RecoveryStats stats{};
    stats.totalSessions = totalSessions_;
    stats.totalRecoveries = totalRecoveries_;
    stats.totalFactoryResets = totalFactoryResets_;
    stats.totalSafeModeBoots = totalSafeModeBoots_;
    stats.totalDiagnosticsRun = totalDiagnosticsRun_;
    stats.totalRepairs = totalRepairs_;
    stats.totalUpdatesApplied = totalUpdatesApplied_;
    stats.totalRollbacks = totalRollbacks_;
    stats.totalBackupRestores = totalBackupRestores_;
    stats.totalCacheWipes = totalCacheWipes_;
    stats.totalFailures = totalFailures_;
    stats.totalDiagnosticChecks = totalDiagnosticChecks_;
    stats.totalDiagnosticFailures = totalDiagnosticFailures_;
    for (int i = 0; i < 7; ++i) stats.totalByMode[i] = totalByMode_[i];
    for (int i = 0; i < 8; ++i) stats.totalByBootReason[i] = totalByBootReason_[i];
    return stats;
}

void RecoveryManager::resetStats() {
    totalSessions_ = 0;
    totalRecoveries_ = 0;
    totalFactoryResets_ = 0;
    totalSafeModeBoots_ = 0;
    totalDiagnosticsRun_ = 0;
    totalRepairs_ = 0;
    totalUpdatesApplied_ = 0;
    totalRollbacks_ = 0;
    totalBackupRestores_ = 0;
    totalCacheWipes_ = 0;
    totalFailures_ = 0;
    totalDiagnosticChecks_ = 0;
    totalDiagnosticFailures_ = 0;
    for (int i = 0; i < 7; ++i) totalByMode_[i] = 0;
    for (int i = 0; i < 8; ++i) totalByBootReason_[i] = 0;
}

// ============================================================
// String helpers
// ============================================================

const char* RecoveryManager::recoveryModeToString(RecoveryMode mode) {
    switch (mode) {
        case RecoveryMode::NORMAL_BOOT:     return "NORMAL_BOOT";
        case RecoveryMode::SAFE_MODE:       return "SAFE_MODE";
        case RecoveryMode::RECOVERY_SHELL:  return "RECOVERY_SHELL";
        case RecoveryMode::UPDATE_RECOVERY: return "UPDATE_RECOVERY";
        case RecoveryMode::BACKUP_RESTORE:  return "BACKUP_RESTORE";
        case RecoveryMode::FACTORY_RESET:   return "FACTORY_RESET";
        case RecoveryMode::DIAGNOSTIC:      return "DIAGNOSTIC";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::recoveryStateToString(RecoveryState state) {
    switch (state) {
        case RecoveryState::IDLE:            return "IDLE";
        case RecoveryState::ENTERING:        return "ENTERING";
        case RecoveryState::ACTIVE:          return "ACTIVE";
        case RecoveryState::SCANNING:        return "SCANNING";
        case RecoveryState::REPAIRING:       return "REPAIRING";
        case RecoveryState::RESTORING:       return "RESTORING";
        case RecoveryState::APPLYING_UPDATE: return "APPLYING_UPDATE";
        case RecoveryState::WIPING:          return "WIPING";
        case RecoveryState::REBOOTING:       return "REBOOTING";
        case RecoveryState::FAILED:          return "FAILED";
        case RecoveryState::COMPLETED:       return "COMPLETED";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::recoveryActionToString(RecoveryAction action) {
    switch (action) {
        case RecoveryAction::VERIFY_SYSTEM:     return "VERIFY_SYSTEM";
        case RecoveryAction::APPLY_UPDATE:      return "APPLY_UPDATE";
        case RecoveryAction::ROLLBACK_UPDATE:   return "ROLLBACK_UPDATE";
        case RecoveryAction::RESTORE_BACKUP:    return "RESTORE_BACKUP";
        case RecoveryAction::WIPE_CACHE:        return "WIPE_CACHE";
        case RecoveryAction::FACTORY_RESET:     return "FACTORY_RESET";
        case RecoveryAction::RUN_DIAGNOSTICS:   return "RUN_DIAGNOSTICS";
        case RecoveryAction::REPAIR_FILESYSTEM: return "REPAIR_FILESYSTEM";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::bootReasonToString(BootReason reason) {
    switch (reason) {
        case BootReason::NORMAL:              return "NORMAL";
        case BootReason::RECOVERY_REQUESTED:  return "RECOVERY_REQUESTED";
        case BootReason::OTA_FAILURE:         return "OTA_FAILURE";
        case BootReason::BOOT_FAILURE:        return "BOOT_FAILURE";
        case BootReason::SAFE_MODE_REQUESTED: return "SAFE_MODE_REQUESTED";
        case BootReason::KERNEL_PANIC:        return "KERNEL_PANIC";
        case BootReason::WATCHDOG_RESET:      return "WATCHDOG_RESET";
        case BootReason::POWER_LOSS:          return "POWER_LOSS";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::diagnosticStatusToString(DiagnosticStatus status) {
    switch (status) {
        case DiagnosticStatus::NOT_RUN:  return "NOT_RUN";
        case DiagnosticStatus::RUNNING:  return "RUNNING";
        case DiagnosticStatus::PASSED:   return "PASSED";
        case DiagnosticStatus::WARNINGS: return "WARNINGS";
        case DiagnosticStatus::FAILED:   return "FAILED";
        case DiagnosticStatus::SKIPPED:  return "SKIPPED";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::diagnosticSeverityToString(DiagnosticSeverity severity) {
    switch (severity) {
        case DiagnosticSeverity::INFO:     return "INFO";
        case DiagnosticSeverity::WARNING:  return "WARNING";
        case DiagnosticSeverity::ERROR:    return "ERROR";
        case DiagnosticSeverity::CRITICAL: return "CRITICAL";
    }
    return "UNKNOWN";
}

const char* RecoveryManager::recoveryResultToString(RecoveryResult result) {
    switch (result) {
        case RecoveryResult::SUCCESS:             return "SUCCESS";
        case RecoveryResult::NOT_INITIALIZED:     return "NOT_INITIALIZED";
        case RecoveryResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case RecoveryResult::INVALID_ACTION:      return "INVALID_ACTION";
        case RecoveryResult::INVALID_MODE:        return "INVALID_MODE";
        case RecoveryResult::NOT_FOUND:           return "NOT_FOUND";
        case RecoveryResult::BAD_STATE:           return "BAD_STATE";
        case RecoveryResult::ACTION_FAILED:       return "ACTION_FAILED";
        case RecoveryResult::REPAIR_FAILED:       return "REPAIR_FAILED";
        case RecoveryResult::WIPE_FAILED:         return "WIPE_FAILED";
        case RecoveryResult::RESET_FAILED:        return "RESET_FAILED";
        case RecoveryResult::DIAGNOSTIC_FAILED:   return "DIAGNOSTIC_FAILED";
        case RecoveryResult::ALREADY_IN_RECOVERY: return "ALREADY_IN_RECOVERY";
        case RecoveryResult::NOT_IN_RECOVERY:     return "NOT_IN_RECOVERY";
        case RecoveryResult::QUEUE_FULL:          return "QUEUE_FULL";
        case RecoveryResult::INVALID_PARAMETER:   return "INVALID_PARAMETER";
        case RecoveryResult::CANCELLED:           return "CANCELLED";
        case RecoveryResult::VERIFICATION_FAILED: return "VERIFICATION_FAILED";
        case RecoveryResult::BACKUP_NOT_FOUND:    return "BACKUP_NOT_FOUND";
        case RecoveryResult::UPDATE_NOT_FOUND:    return "UPDATE_NOT_FOUND";
        case RecoveryResult::IN_PROGRESS:         return "IN_PROGRESS";
        case RecoveryResult::REBOOT_PENDING:      return "REBOOT_PENDING";
    }
    return "UNKNOWN";
}

RecoveryMode RecoveryManager::stringToRecoveryMode(const std::string& str) {
    if (str == "NORMAL_BOOT")     return RecoveryMode::NORMAL_BOOT;
    if (str == "SAFE_MODE")       return RecoveryMode::SAFE_MODE;
    if (str == "RECOVERY_SHELL")  return RecoveryMode::RECOVERY_SHELL;
    if (str == "UPDATE_RECOVERY") return RecoveryMode::UPDATE_RECOVERY;
    if (str == "BACKUP_RESTORE")  return RecoveryMode::BACKUP_RESTORE;
    if (str == "FACTORY_RESET")   return RecoveryMode::FACTORY_RESET;
    if (str == "DIAGNOSTIC")      return RecoveryMode::DIAGNOSTIC;
    return RecoveryMode::NORMAL_BOOT;
}

RecoveryAction RecoveryManager::stringToRecoveryAction(const std::string& str) {
    if (str == "VERIFY_SYSTEM")     return RecoveryAction::VERIFY_SYSTEM;
    if (str == "APPLY_UPDATE")      return RecoveryAction::APPLY_UPDATE;
    if (str == "ROLLBACK_UPDATE")   return RecoveryAction::ROLLBACK_UPDATE;
    if (str == "RESTORE_BACKUP")    return RecoveryAction::RESTORE_BACKUP;
    if (str == "WIPE_CACHE")        return RecoveryAction::WIPE_CACHE;
    if (str == "FACTORY_RESET")     return RecoveryAction::FACTORY_RESET;
    if (str == "RUN_DIAGNOSTICS")   return RecoveryAction::RUN_DIAGNOSTICS;
    if (str == "REPAIR_FILESYSTEM") return RecoveryAction::REPAIR_FILESYSTEM;
    return RecoveryAction::VERIFY_SYSTEM;
}

BootReason RecoveryManager::stringToBootReason(const std::string& str) {
    if (str == "NORMAL")              return BootReason::NORMAL;
    if (str == "RECOVERY_REQUESTED")  return BootReason::RECOVERY_REQUESTED;
    if (str == "OTA_FAILURE")         return BootReason::OTA_FAILURE;
    if (str == "BOOT_FAILURE")        return BootReason::BOOT_FAILURE;
    if (str == "SAFE_MODE_REQUESTED") return BootReason::SAFE_MODE_REQUESTED;
    if (str == "KERNEL_PANIC")        return BootReason::KERNEL_PANIC;
    if (str == "WATCHDOG_RESET")      return BootReason::WATCHDOG_RESET;
    if (str == "POWER_LOSS")          return BootReason::POWER_LOSS;
    return BootReason::NORMAL;
}

RecoveryAction RecoveryManager::diagnosticActionFromString(const std::string& str) {
    return stringToRecoveryAction(str);
}

}  // namespace phantom::recovery
