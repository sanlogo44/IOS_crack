/*
 * Phantom OS - Bluetooth Manager
 * v0.33.0 - License: GPL-3.0
 *
 * Privacy-first Bluetooth service: adapter control, device discovery,
 * pairing/bonding, profile management (A2DP, HFP, AVRCP, HID, GATT, etc.),
 * per-app Bluetooth policy with foreground-only and privacy-indicator
 * enforcement, MAC address randomization, identifier protection,
 * connection management, mock devices for testing, privacy-transformed
 * history, events, stats, callbacks and optional LogServer/CrashReporter
 * integration.
 *
 * All data is simulated in-memory. Device addresses are deterministic stubs,
 * not real Bluetooth MAC addresses. Privacy transforms are deterministic.
 * The LogServer must never log raw device addresses, device names, or
 * connection metadata.
 */

#ifndef PHANTOM_BLUETOOTH_BLUETOOTH_MANAGER_H
#define PHANTOM_BLUETOOTH_BLUETOOTH_MANAGER_H

#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace phantom {
namespace logging { class LogServer; }
namespace crashreporter { class CrashReporter; }

namespace bluetooth {

// ============================================================
// Constants
// ============================================================

static const uint32_t BT_PRIVACY_NONE = 0;
static const uint32_t BT_PRIVACY_REQUIRE_FOREGROUND = 1 << 0;
static const uint32_t BT_PRIVACY_NO_HISTORY = 1 << 1;
static const uint32_t BT_PRIVACY_REDACT_ADDRESS = 1 << 2;
static const uint32_t BT_PRIVACY_PSEUDONYMIZE = 1 << 3;
static const uint32_t BT_PRIVACY_METADATA_ONLY = 1 << 4;
static const uint32_t BT_PRIVACY_MOCK_ALLOWED = 1 << 5;
static const uint32_t BT_PRIVACY_INDICATOR_REQUIRED = 1 << 6;
static const uint32_t BT_PRIVACY_DISABLE_DISCOVERABLE = 1 << 7;

static const uint32_t BT_DEFAULT_MAX_DEVICES = 64;
static const uint32_t BT_DEFAULT_MAX_BONDED = 32;
static const uint32_t BT_DEFAULT_MAX_HISTORY = 128;
static const uint32_t BT_DEFAULT_MAX_EVENTS = 256;

// ============================================================
// Enums
// ============================================================

enum class AdapterState : uint8_t {
    DISABLED = 0,
    OFF,
    TURNING_ON,
    ON,
    TURNING_OFF
};

enum class ScanMode : uint8_t {
    NONE = 0,
    CONNECTABLE,
    CONNECTABLE_DISCOVERABLE
};

enum class DeviceType : uint8_t {
    UNKNOWN = 0,
    CLASSIC,
    LE,
    DUAL
};

enum class DeviceState : uint8_t {
    UNBONDED = 0,
    BONDING,
    BONDED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING
};

enum class BondState : uint8_t {
    NONE = 0,
    BONDING,
    BONDED,
    BOND_FAILED
};

enum class ProfileType : uint8_t {
    A2DP_SINK = 0,
    A2DP_SOURCE,
    HFP_CLIENT,
    HSP_CLIENT,
    AVRCP_CONTROLLER,
    AVRCP_TARGET,
    HID_HOST,
    PAN_USER,
    GATT_CLIENT,
    GATT_SERVER,
    SPP_SERVER,
    MAP_CLIENT
};

enum class BluetoothPermission : uint8_t {
    DENY = 0,
    ALLOW_FOREGROUND,
    ALLOW_ALWAYS,
    ALLOW_ONCE
};

enum class BluetoothPrivacyMode : uint8_t {
    FULL = 0,
    REDACTED,
    METADATA_ONLY
};

enum class BluetoothResult : uint8_t {
    SUCCESS = 0,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_PARAMETER,
    PERMISSION_DENIED,
    ADAPTER_OFF,
    DEVICE_NOT_FOUND,
    ALREADY_BONDED,
    BOND_FAILED,
    NOT_BONDED,
    CONNECTION_FAILED,
    PROFILE_NOT_SUPPORTED,
    CAPACITY_EXCEEDED,
    RATE_LIMITED,
    BAD_STATE,
    OPERATION_FAILED,
    SIMULATED_FAILURE
};

enum class BluetoothEventType : uint8_t {
    ADAPTER_STATE_CHANGED = 0,
    SCAN_STARTED,
    SCAN_STOPPED,
    DEVICE_FOUND,
    BOND_STATE_CHANGED,
    DEVICE_CONNECTED,
    DEVICE_DISCONNECTED,
    PROFILE_CONNECTED,
    PROFILE_DISCONNECTED,
    PERMISSION_CHANGED,
    PRIVACY_APPLIED,
    INDICATOR_ON,
    INDICATOR_OFF,
    DISCOVERABLE_CHANGED,
    MOCK_DEVICE_SET,
    HISTORY_CLEARED
};

// ============================================================
// Data structures
// ============================================================

struct BluetoothDevice {
    std::string address;        // MAC address (stub)
    std::string name;
    DeviceType type = DeviceType::UNKNOWN;
    DeviceState state = DeviceState::UNBONDED;
    BondState bondState = BondState::NONE;
    bool connected = false;
    int32_t rssi = 0;
    uint64_t lastSeen = 0;
    std::vector<std::string> uuids;
    uint32_t deviceClass = 0;   // Bluetooth device class
};

struct ProfileConnection {
    ProfileType profile = ProfileType::A2DP_SINK;
    std::string deviceAddress;
    bool connected = false;
    uint64_t connectedAt = 0;
};

struct BluetoothPolicy {
    std::string appId;
    BluetoothPermission permission = BluetoothPermission::DENY;
    BluetoothPrivacyMode privacyMode = BluetoothPrivacyMode::FULL;
    uint32_t privacyFlags = BT_PRIVACY_NONE;
    uint64_t lastGrantedAt = 0;
    bool oneShotUsed = false;
    bool foreground = false;
    std::string pseudonym;
};

struct BluetoothEvent {
    uint64_t id = 0;
    uint64_t timestamp = 0;
    BluetoothEventType type = BluetoothEventType::ADAPTER_STATE_CHANGED;
    BluetoothResult result = BluetoothResult::SUCCESS;
    std::string appId;
    std::string deviceAddress;   // Metadata only — never raw address
    std::string detail;
};

struct BluetoothStats {
    uint64_t adapterOnCount = 0;
    uint64_t adapterOffCount = 0;
    uint64_t scanCount = 0;
    uint64_t devicesFound = 0;
    uint64_t bondsCreated = 0;
    uint64_t bondsFailed = 0;
    uint64_t connectionsEstablished = 0;
    uint64_t connectionsLost = 0;
    uint64_t profileConnections = 0;
    uint64_t profileDisconnections = 0;
    uint64_t permissionsChanged = 0;
    uint64_t privacyApplications = 0;
    uint64_t historyClears = 0;
    uint64_t totalFailures = 0;
    uint64_t indicatorToggleCount = 0;
    uint64_t discoverableChanges = 0;
    uint64_t mockDevicesSet = 0;
    uint64_t byEventType[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint64_t byResult[17] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
};

// ============================================================
// Bluetooth Manager
// ============================================================

class BluetoothManager {
public:
    BluetoothManager() = default;
    ~BluetoothManager() = default;

    BluetoothManager(const BluetoothManager&) = delete;
    BluetoothManager& operator=(const BluetoothManager&) = delete;

    // ---- Lifecycle ----
    BluetoothResult initialize(size_t maxHistory = 128, size_t maxEvents = 256,
                                 size_t maxDevices = 64, size_t maxBonded = 32);
    BluetoothResult shutdown();
    bool isInitialized() const { return initialized_; }

    // ---- Adapter control ----
    BluetoothResult enableAdapter(const std::string& owner = "system");
    BluetoothResult disableAdapter(const std::string& owner = "system");
    AdapterState getAdapterState() const { return adapterState_; }
    bool isAdapterEnabled() const { return adapterState_ == AdapterState::ON; }
    BluetoothResult setScanMode(ScanMode mode, const std::string& owner = "system");
    ScanMode getScanMode() const { return scanMode_; }
    bool isDiscoverable() const { return scanMode_ == ScanMode::CONNECTABLE_DISCOVERABLE; }

    // ---- Scanning ----
    BluetoothResult startScan(const std::string& owner = "system");
    BluetoothResult stopScan(const std::string& owner = "system");
    bool isScanning() const { return scanning_; }
    std::vector<BluetoothDevice> getScanResults() const;
    BluetoothResult setMockScanResults(const std::vector<BluetoothDevice>& devices,
                                         const std::string& owner = "system");

    // ---- Device management ----
    BluetoothDevice getDevice(const std::string& address) const;
    std::vector<BluetoothDevice> getAllDevices() const;
    std::vector<BluetoothDevice> getBondedDevices() const;
    std::vector<BluetoothDevice> getConnectedDevices() const;
    size_t getDeviceCount() const { return devices_.size(); }
    size_t getBondedCount() const;
    size_t getConnectedCount() const;

    // ---- Pairing / bonding ----
    BluetoothResult pair(const std::string& address, const std::string& owner = "system");
    BluetoothResult unpair(const std::string& address, const std::string& owner = "system");
    BondState getBondState(const std::string& address) const;
    bool isBonded(const std::string& address) const;

    // ---- Connection management ----
    BluetoothResult connect(const std::string& address, const std::string& owner = "system");
    BluetoothResult disconnect(const std::string& address, const std::string& owner = "system");
    bool isConnected(const std::string& address) const;
    DeviceState getDeviceState(const std::string& address) const;

    // ---- Profile management ----
    BluetoothResult connectProfile(const std::string& address, ProfileType profile,
                                     const std::string& owner = "system");
    BluetoothResult disconnectProfile(const std::string& address, ProfileType profile,
                                        const std::string& owner = "system");
    std::vector<ProfileConnection> getConnectedProfiles() const;
    std::vector<ProfileConnection> getProfilesForDevice(const std::string& address) const;
    bool isProfileConnected(const std::string& address, ProfileType profile) const;

    // ---- Permission / policy ----
    BluetoothResult setAppBluetoothPolicy(const std::string& appId,
                                            BluetoothPermission permission,
                                            BluetoothPrivacyMode privacyMode,
                                            uint32_t privacyFlags = BT_PRIVACY_NONE,
                                            const std::string& pseudonym = "",
                                            const std::string& owner = "system");
    BluetoothPolicy getAppBluetoothPolicy(const std::string& appId) const;
    BluetoothResult clearAppBluetoothPolicy(const std::string& appId,
                                             const std::string& owner = "system");
    bool checkAppAccess(const std::string& appId) const;
    BluetoothResult setAppForeground(const std::string& appId, bool foreground);

    // ---- Identifier access ----
    BluetoothResult getDeviceAddress(const std::string& appId, const std::string& deviceId,
                                       std::string& out);
    BluetoothResult getDeviceName(const std::string& appId, const std::string& deviceId,
                                     std::string& out);
    BluetoothResult getDeviceRssi(const std::string& appId, const std::string& deviceId,
                                    int32_t& out);
    BluetoothResult getAdapterAddress(const std::string& appId, std::string& out);

    // ---- History / privacy ----
    std::vector<BluetoothEvent> getHistory(const std::string& appId,
                                             size_t limit = 0) const;
    BluetoothResult clearHistory(const std::string& owner = "system");
    BluetoothResult clearAppHistory(const std::string& appId,
                                      const std::string& requester);
    size_t getHistoryCount() const { return history_.size(); }

    // ---- Mock / testing ----
    BluetoothResult setMockEnabled(bool enabled, const std::string& owner = "system");
    bool isMockEnabled() const { return mockEnabled_; }
    BluetoothResult setMockDevice(const BluetoothDevice& device,
                                   const std::string& owner = "system");
    BluetoothResult addMockDevice(const BluetoothDevice& device,
                                    const std::string& owner = "system");
    BluetoothResult removeMockDevice(const std::string& address,
                                       const std::string& owner = "system");

    // ---- Privacy indicator ----
    bool isPrivacyIndicatorOn() const { return !activeBluetoothUsers_.empty(); }
    std::vector<std::string> getActiveBluetoothUsers() const { return activeBluetoothUsers_; }
    uint64_t getLastAccessTime() const { return lastAccessTime_; }

    // ---- Events ----
    std::vector<BluetoothEvent> getEvents(size_t limit = 0) const;
    std::vector<BluetoothEvent> getEventsByType(BluetoothEventType type) const;
    size_t getEventCount() const { return events_.size(); }
    BluetoothResult clearEvents();

    // ---- Stats ----
    BluetoothStats getStats() const { return stats_; }
    void resetStats();

    // ---- Integration ----
    void setLogServer(logging::LogServer* server) { logServer_ = server; }
    logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    void setEventCallback(std::function<void(const BluetoothEvent&)> cb) { eventCallback_ = cb; }
    void setAccessCallback(std::function<void(const std::string&, BluetoothResult)> cb) {
        accessCallback_ = cb;
    }

    // ---- Test hooks ----
    void setFailNextOperation(bool enable) { failNextOperation_ = enable; }
    bool getFailNextOperation() const { return failNextOperation_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // ---- String helpers ----
    static const char* adapterStateToString(AdapterState state);
    static const char* scanModeToString(ScanMode mode);
    static const char* deviceTypeToString(DeviceType type);
    static const char* deviceStateToString(DeviceState state);
    static const char* bondStateToString(BondState state);
    static const char* profileTypeToString(ProfileType profile);
    static const char* permissionToString(BluetoothPermission permission);
    static const char* privacyModeToString(BluetoothPrivacyMode mode);
    static const char* resultToString(BluetoothResult result);
    static const char* eventTypeToString(BluetoothEventType type);
    static BluetoothResult stringToResult(const std::string& str);
    static ProfileType stringToProfile(const std::string& str);

    // ---- Privacy helpers ----
    static BluetoothDevice applyPrivacyTransform(const BluetoothDevice& device,
                                                   BluetoothPrivacyMode mode,
                                                   uint32_t privacyFlags,
                                                   const std::string& pseudonym = "");
    static std::string redactAddress(const std::string& address);
    static std::string pseudonymizeAddress(const std::string& address,
                                              const std::string& pseudonym);

private:
    uint64_t getCurrentTimeMs() const;
    bool isSystemOwner(const std::string& app) const;
    void recordEvent(BluetoothEventType type, BluetoothResult result,
                     const std::string& appId,
                     const std::string& deviceAddress,
                     const std::string& detail);
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& reason) const;
    void updatePrivacyIndicator();
    void setStubDevices();
    void setStubAdapter();

    bool initialized_ = false;
    size_t maxHistory_ = 128;
    size_t maxEvents_ = 256;
    size_t maxDevices_ = 64;
    size_t maxBonded_ = 32;

    AdapterState adapterState_ = AdapterState::OFF;
    ScanMode scanMode_ = ScanMode::NONE;
    bool scanning_ = false;
    std::string adapterAddress_;  // Stub MAC address

    std::vector<BluetoothDevice> devices_;
    std::map<std::string, std::vector<ProfileConnection>> profileConnections_;
    std::map<std::string, BluetoothDevice*> deviceMap_;

    std::map<std::string, BluetoothPolicy> appPolicies_;

    std::vector<BluetoothEvent> history_;
    std::vector<BluetoothEvent> events_;
    uint64_t nextEventId_ = 1;

    bool mockEnabled_ = false;
    std::vector<BluetoothDevice> mockDevices_;
    std::vector<BluetoothDevice> mockScanResults_;

    std::vector<std::string> activeBluetoothUsers_;
    uint64_t lastAccessTime_ = 0;

    BluetoothStats stats_;

    logging::LogServer* logServer_ = nullptr;
    crashreporter::CrashReporter* crashReporter_ = nullptr;

    std::function<void(const BluetoothEvent&)> eventCallback_;
    std::function<void(const std::string&, BluetoothResult)> accessCallback_;

    bool failNextOperation_ = false;
    uint64_t timeOverrideMs_ = 0;
};

}  // namespace bluetooth
}  // namespace phantom

#endif  // PHANTOM_BLUETOOTH_BLUETOOTH_MANAGER_H
