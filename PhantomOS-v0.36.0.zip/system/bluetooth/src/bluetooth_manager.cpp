/*
 * Phantom OS - Bluetooth Manager Implementation
 * v0.33.0 - License: GPL-3.0
 *
 * Implementation of the privacy-first Bluetooth service.
 * All data is simulated in-memory. Privacy transforms are deterministic.
 */

#include "phantom/bluetooth/bluetooth_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <chrono>
#include <cstring>

namespace phantom {
namespace bluetooth {

// ============================================================
// FNV-1a hash (deterministic, same as other Phantom OS components)
// ============================================================

static uint32_t fnv1a(const std::string& str) {
    uint32_t hash = 2166136261u;
    for (char c : str) {
        hash ^= static_cast<uint32_t>(static_cast<unsigned char>(c));
        hash *= 16777619u;
    }
    return hash;
}

static std::string generateStubMac(uint32_t seed) {
    char buf[24];
    snprintf(buf, sizeof(buf), "02:%02X:%02X:%02X:%02X:%02X:%02X",
             (seed >> 24) & 0xFF,
             (seed >> 16) & 0xFF,
             (seed >> 8) & 0xFF,
             seed & 0xFF,
             (seed * 7) & 0xFF,
             (seed * 13) & 0xFF);
    return std::string(buf);
}

// ============================================================
// Lifecycle
// ============================================================

BluetoothResult BluetoothManager::initialize(size_t maxHistory, size_t maxEvents,
                                               size_t maxDevices, size_t maxBonded) {
    if (initialized_) return BluetoothResult::ALREADY_INITIALIZED;
    if (maxHistory == 0 || maxEvents == 0 || maxDevices == 0 || maxBonded == 0)
        return BluetoothResult::INVALID_PARAMETER;

    maxHistory_ = maxHistory;
    maxEvents_ = maxEvents;
    maxDevices_ = maxDevices;
    maxBonded_ = maxBonded;

    initialized_ = true;
    adapterState_ = AdapterState::OFF;
    scanMode_ = ScanMode::NONE;
    scanning_ = false;
    mockEnabled_ = false;

    setStubAdapter();
    setStubDevices();

    stats_ = BluetoothStats{};

    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::shutdown() {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;

    devices_.clear();
    profileConnections_.clear();
    deviceMap_.clear();
    appPolicies_.clear();
    history_.clear();
    events_.clear();
    mockDevices_.clear();
    mockScanResults_.clear();
    activeBluetoothUsers_.clear();

    adapterState_ = AdapterState::OFF;
    scanMode_ = ScanMode::NONE;
    scanning_ = false;
    mockEnabled_ = false;
    initialized_ = false;

    return BluetoothResult::SUCCESS;
}

// ============================================================
// Adapter control
// ============================================================

BluetoothResult BluetoothManager::enableAdapter(const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    if (adapterState_ == AdapterState::ON) return BluetoothResult::BAD_STATE;

    adapterState_ = AdapterState::ON;
    scanMode_ = ScanMode::CONNECTABLE;

    stats_.adapterOnCount++;
    recordEvent(BluetoothEventType::ADAPTER_STATE_CHANGED, BluetoothResult::SUCCESS,
                "system", "", "Adapter enabled");

    logToServer("INFO", "Bluetooth adapter enabled");
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::disableAdapter(const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    if (adapterState_ == AdapterState::OFF) return BluetoothResult::BAD_STATE;

    // Disconnect all devices
    for (auto& dev : devices_) {
        if (dev.connected) {
            dev.connected = false;
            dev.state = DeviceState::BONDED;
            stats_.connectionsLost++;
        }
    }
    profileConnections_.clear();
    scanning_ = false;
    scanMode_ = ScanMode::NONE;
    adapterState_ = AdapterState::OFF;
    activeBluetoothUsers_.clear();

    stats_.adapterOffCount++;
    recordEvent(BluetoothEventType::ADAPTER_STATE_CHANGED, BluetoothResult::SUCCESS,
                "system", "", "Adapter disabled");
    updatePrivacyIndicator();

    logToServer("INFO", "Bluetooth adapter disabled");
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::setScanMode(ScanMode mode, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;
    if (adapterState_ != AdapterState::ON) return BluetoothResult::ADAPTER_OFF;

    ScanMode oldMode = scanMode_;
    scanMode_ = mode;

    if (oldMode != mode) {
        stats_.discoverableChanges++;
        recordEvent(BluetoothEventType::DISCOVERABLE_CHANGED, BluetoothResult::SUCCESS,
                    "system", "", "Scan mode changed");
    }

    return BluetoothResult::SUCCESS;
}

// ============================================================
// Scanning
// ============================================================

BluetoothResult BluetoothManager::startScan(const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (adapterState_ != AdapterState::ON) return BluetoothResult::ADAPTER_OFF;

    scanning_ = true;
    stats_.scanCount++;
    recordEvent(BluetoothEventType::SCAN_STARTED, BluetoothResult::SUCCESS,
                owner, "", "Scan started");

    // If we have mock scan results, add them to devices
    if (mockEnabled_ && !mockScanResults_.empty()) {
        for (const auto& mockDev : mockScanResults_) {
            // Add or update device in list
            bool found = false;
            for (auto& dev : devices_) {
                if (dev.address == mockDev.address) {
                    dev.rssi = mockDev.rssi;
                    dev.lastSeen = getCurrentTimeMs();
                    found = true;
                    break;
                }
            }
            if (!found && devices_.size() < maxDevices_) {
                BluetoothDevice dev = mockDev;
                dev.lastSeen = getCurrentTimeMs();
                devices_.push_back(dev);
                stats_.devicesFound++;
                recordEvent(BluetoothEventType::DEVICE_FOUND, BluetoothResult::SUCCESS,
                            owner, redactAddress(dev.address), "Device found: " + dev.name);
            }
        }
    }

    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::stopScan(const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (!scanning_) return BluetoothResult::BAD_STATE;

    scanning_ = false;
    recordEvent(BluetoothEventType::SCAN_STOPPED, BluetoothResult::SUCCESS,
                owner, "", "Scan stopped");

    return BluetoothResult::SUCCESS;
}

std::vector<BluetoothDevice> BluetoothManager::getScanResults() const {
    std::vector<BluetoothDevice> results;
    for (const auto& dev : devices_) {
        if (dev.state == DeviceState::UNBONDED || dev.bondState == BondState::NONE) {
            results.push_back(dev);
        }
    }
    return results;
}

BluetoothResult BluetoothManager::setMockScanResults(const std::vector<BluetoothDevice>& devices,
                                                       const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    mockScanResults_ = devices;
    return BluetoothResult::SUCCESS;
}

// ============================================================
// Device management
// ============================================================

BluetoothDevice BluetoothManager::getDevice(const std::string& address) const {
    for (const auto& dev : devices_) {
        if (dev.address == address) return dev;
    }
    return BluetoothDevice{};
}

std::vector<BluetoothDevice> BluetoothManager::getAllDevices() const {
    return devices_;
}

std::vector<BluetoothDevice> BluetoothManager::getBondedDevices() const {
    std::vector<BluetoothDevice> bonded;
    for (const auto& dev : devices_) {
        if (dev.bondState == BondState::BONDED) {
            bonded.push_back(dev);
        }
    }
    return bonded;
}

std::vector<BluetoothDevice> BluetoothManager::getConnectedDevices() const {
    std::vector<BluetoothDevice> connected;
    for (const auto& dev : devices_) {
        if (dev.connected) {
            connected.push_back(dev);
        }
    }
    return connected;
}

size_t BluetoothManager::getBondedCount() const {
    size_t count = 0;
    for (const auto& dev : devices_) {
        if (dev.bondState == BondState::BONDED) count++;
    }
    return count;
}

size_t BluetoothManager::getConnectedCount() const {
    size_t count = 0;
    for (const auto& dev : devices_) {
        if (dev.connected) count++;
    }
    return count;
}

// ============================================================
// Pairing / bonding
// ============================================================

BluetoothResult BluetoothManager::pair(const std::string& address, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (adapterState_ != AdapterState::ON) return BluetoothResult::ADAPTER_OFF;
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    // Find device
    BluetoothDevice* dev = nullptr;
    for (auto& d : devices_) {
        if (d.address == address) { dev = &d; break; }
    }
    if (!dev) return BluetoothResult::DEVICE_NOT_FOUND;

    if (dev->bondState == BondState::BONDED) return BluetoothResult::ALREADY_BONDED;
    if (getBondedCount() >= maxBonded_) return BluetoothResult::CAPACITY_EXCEEDED;

    // Simulate bonding
    dev->bondState = BondState::BONDING;
    dev->state = DeviceState::BONDING;

    // Deterministic success/failure based on FNV-1a hash
    uint32_t hash = fnv1a(address);
    if (hash % 10 == 0) {
        // 10% failure rate
        dev->bondState = BondState::BOND_FAILED;
        dev->state = DeviceState::UNBONDED;
        stats_.bondsFailed++;
        recordEvent(BluetoothEventType::BOND_STATE_CHANGED, BluetoothResult::BOND_FAILED,
                    owner, redactAddress(address), "Bond failed");
        return BluetoothResult::BOND_FAILED;
    }

    dev->bondState = BondState::BONDED;
    dev->state = DeviceState::BONDED;
    stats_.bondsCreated++;
    recordEvent(BluetoothEventType::BOND_STATE_CHANGED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Device bonded");

    logToServer("INFO", "Device bonded: " + redactAddress(address));
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::unpair(const std::string& address, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    BluetoothDevice* dev = nullptr;
    for (auto& d : devices_) {
        if (d.address == address) { dev = &d; break; }
    }
    if (!dev) return BluetoothResult::DEVICE_NOT_FOUND;

    if (dev->bondState != BondState::BONDED) return BluetoothResult::NOT_BONDED;

    // Disconnect if connected
    if (dev->connected) {
        dev->connected = false;
        profileConnections_.erase(address);
        stats_.connectionsLost++;
    }

    dev->bondState = BondState::NONE;
    dev->state = DeviceState::UNBONDED;

    recordEvent(BluetoothEventType::BOND_STATE_CHANGED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Device unbonded");

    return BluetoothResult::SUCCESS;
}

BondState BluetoothManager::getBondState(const std::string& address) const {
    for (const auto& dev : devices_) {
        if (dev.address == address) return dev.bondState;
    }
    return BondState::NONE;
}

bool BluetoothManager::isBonded(const std::string& address) const {
    return getBondState(address) == BondState::BONDED;
}

// ============================================================
// Connection management
// ============================================================

BluetoothResult BluetoothManager::connect(const std::string& address, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (adapterState_ != AdapterState::ON) return BluetoothResult::ADAPTER_OFF;
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    BluetoothDevice* dev = nullptr;
    for (auto& d : devices_) {
        if (d.address == address) { dev = &d; break; }
    }
    if (!dev) return BluetoothResult::DEVICE_NOT_FOUND;

    if (dev->bondState != BondState::BONDED) return BluetoothResult::NOT_BONDED;
    if (dev->connected) return BluetoothResult::BAD_STATE;

    dev->state = DeviceState::CONNECTING;

    // Deterministic success/failure
    uint32_t hash = fnv1a(address + "connect");
    if (hash % 20 == 0) {
        dev->state = DeviceState::BONDED;
        stats_.totalFailures++;
        recordEvent(BluetoothEventType::DEVICE_DISCONNECTED, BluetoothResult::CONNECTION_FAILED,
                    owner, redactAddress(address), "Connection failed");
        return BluetoothResult::CONNECTION_FAILED;
    }

    dev->connected = true;
    dev->state = DeviceState::CONNECTED;
    stats_.connectionsEstablished++;
    recordEvent(BluetoothEventType::DEVICE_CONNECTED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Device connected");

    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::disconnect(const std::string& address, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    BluetoothDevice* dev = nullptr;
    for (auto& d : devices_) {
        if (d.address == address) { dev = &d; break; }
    }
    if (!dev) return BluetoothResult::DEVICE_NOT_FOUND;

    if (!dev->connected) return BluetoothResult::BAD_STATE;

    dev->connected = false;
    dev->state = DeviceState::BONDED;
    profileConnections_.erase(address);
    stats_.connectionsLost++;
    recordEvent(BluetoothEventType::DEVICE_DISCONNECTED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Device disconnected");

    return BluetoothResult::SUCCESS;
}

bool BluetoothManager::isConnected(const std::string& address) const {
    for (const auto& dev : devices_) {
        if (dev.address == address) return dev.connected;
    }
    return false;
}

DeviceState BluetoothManager::getDeviceState(const std::string& address) const {
    for (const auto& dev : devices_) {
        if (dev.address == address) return dev.state;
    }
    return DeviceState::UNBONDED;
}

// ============================================================
// Profile management
// ============================================================

BluetoothResult BluetoothManager::connectProfile(const std::string& address, ProfileType profile,
                                                   const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (adapterState_ != AdapterState::ON) return BluetoothResult::ADAPTER_OFF;
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    BluetoothDevice* dev = nullptr;
    for (auto& d : devices_) {
        if (d.address == address) { dev = &d; break; }
    }
    if (!dev) return BluetoothResult::DEVICE_NOT_FOUND;
    if (!dev->connected) return BluetoothResult::BAD_STATE;

    // Check if already connected
    auto& profiles = profileConnections_[address];
    for (const auto& p : profiles) {
        if (p.profile == profile && p.connected) return BluetoothResult::BAD_STATE;
    }

    ProfileConnection pc;
    pc.profile = profile;
    pc.deviceAddress = address;
    pc.connected = true;
    pc.connectedAt = getCurrentTimeMs();
    profiles.push_back(pc);

    stats_.profileConnections++;
    recordEvent(BluetoothEventType::PROFILE_CONNECTED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Profile connected");

    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::disconnectProfile(const std::string& address, ProfileType profile,
                                                      const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (failNextOperation_) { failNextOperation_ = false; return BluetoothResult::SIMULATED_FAILURE; }
    if (address.empty()) return BluetoothResult::INVALID_PARAMETER;

    auto it = profileConnections_.find(address);
    if (it == profileConnections_.end()) return BluetoothResult::PROFILE_NOT_SUPPORTED;

    bool found = false;
    for (auto& p : it->second) {
        if (p.profile == profile && p.connected) {
            p.connected = false;
            found = true;
            break;
        }
    }
    if (!found) return BluetoothResult::PROFILE_NOT_SUPPORTED;

    stats_.profileDisconnections++;
    recordEvent(BluetoothEventType::PROFILE_DISCONNECTED, BluetoothResult::SUCCESS,
                owner, redactAddress(address), "Profile disconnected");

    return BluetoothResult::SUCCESS;
}

std::vector<ProfileConnection> BluetoothManager::getConnectedProfiles() const {
    std::vector<ProfileConnection> result;
    for (const auto& [addr, profiles] : profileConnections_) {
        for (const auto& p : profiles) {
            if (p.connected) result.push_back(p);
        }
    }
    return result;
}

std::vector<ProfileConnection> BluetoothManager::getProfilesForDevice(const std::string& address) const {
    auto it = profileConnections_.find(address);
    if (it == profileConnections_.end()) return {};
    return it->second;
}

bool BluetoothManager::isProfileConnected(const std::string& address, ProfileType profile) const {
    auto it = profileConnections_.find(address);
    if (it == profileConnections_.end()) return false;
    for (const auto& p : it->second) {
        if (p.profile == profile && p.connected) return true;
    }
    return false;
}

// ============================================================
// Permission / policy
// ============================================================

BluetoothResult BluetoothManager::setAppBluetoothPolicy(const std::string& appId,
                                                          BluetoothPermission permission,
                                                          BluetoothPrivacyMode privacyMode,
                                                          uint32_t privacyFlags,
                                                          const std::string& pseudonym,
                                                          const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;
    if (appId.empty()) return BluetoothResult::INVALID_PARAMETER;

    BluetoothPolicy policy;
    policy.appId = appId;
    policy.permission = permission;
    policy.privacyMode = privacyMode;
    policy.privacyFlags = privacyFlags;
    policy.lastGrantedAt = (permission != BluetoothPermission::DENY) ? getCurrentTimeMs() : 0;
    policy.oneShotUsed = false;
    policy.foreground = false;
    policy.pseudonym = pseudonym;

    appPolicies_[appId] = policy;
    stats_.permissionsChanged++;

    recordEvent(BluetoothEventType::PERMISSION_CHANGED, BluetoothResult::SUCCESS,
                owner, "", "Policy set for " + appId);

    return BluetoothResult::SUCCESS;
}

BluetoothPolicy BluetoothManager::getAppBluetoothPolicy(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) return it->second;
    return BluetoothPolicy{};
}

BluetoothResult BluetoothManager::clearAppBluetoothPolicy(const std::string& appId,
                                                            const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return BluetoothResult::INVALID_PARAMETER;

    appPolicies_.erase(it);
    stats_.permissionsChanged++;

    // Remove from active users
    auto uit = std::find(activeBluetoothUsers_.begin(), activeBluetoothUsers_.end(), appId);
    if (uit != activeBluetoothUsers_.end()) {
        activeBluetoothUsers_.erase(uit);
        updatePrivacyIndicator();
    }

    return BluetoothResult::SUCCESS;
}

bool BluetoothManager::checkAppAccess(const std::string& appId) const {
    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return false;

    const auto& policy = it->second;

    switch (policy.permission) {
        case BluetoothPermission::DENY:
            return false;
        case BluetoothPermission::ALLOW_FOREGROUND:
            return policy.foreground;
        case BluetoothPermission::ALLOW_ALWAYS:
            return true;
        case BluetoothPermission::ALLOW_ONCE:
            return !policy.oneShotUsed;
        default:
            return false;
    }
}

BluetoothResult BluetoothManager::setAppForeground(const std::string& appId, bool foreground) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;

    auto it = appPolicies_.find(appId);
    if (it == appPolicies_.end()) return BluetoothResult::INVALID_PARAMETER;

    it->second.foreground = foreground;
    return BluetoothResult::SUCCESS;
}

// ============================================================
// Identifier access
// ============================================================

BluetoothResult BluetoothManager::getDeviceAddress(const std::string& appId, const std::string& deviceId,
                                                     std::string& out) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId)) return BluetoothResult::PERMISSION_DENIED;

    BluetoothDevice dev = getDevice(deviceId);
    if (dev.address.empty()) return BluetoothResult::DEVICE_NOT_FOUND;

    // Consume one-shot
    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == BluetoothPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    lastAccessTime_ = getCurrentTimeMs();
    if (std::find(activeBluetoothUsers_.begin(), activeBluetoothUsers_.end(), appId) == activeBluetoothUsers_.end()) {
        activeBluetoothUsers_.push_back(appId);
        stats_.indicatorToggleCount++;
        updatePrivacyIndicator();
    }

    // Apply privacy transform
    BluetoothPrivacyMode mode = BluetoothPrivacyMode::FULL;
    uint32_t flags = BT_PRIVACY_NONE;
    std::string pseudonym;
    it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) {
        mode = it->second.privacyMode;
        flags = it->second.privacyFlags;
        pseudonym = it->second.pseudonym;
    }

    BluetoothDevice transformed = applyPrivacyTransform(dev, mode, flags, pseudonym);
    out = transformed.address;

    if (accessCallback_) accessCallback_(appId, BluetoothResult::SUCCESS);
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::getDeviceName(const std::string& appId, const std::string& deviceId,
                                                  std::string& out) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId)) return BluetoothResult::PERMISSION_DENIED;

    BluetoothDevice dev = getDevice(deviceId);
    if (dev.address.empty()) return BluetoothResult::DEVICE_NOT_FOUND;

    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == BluetoothPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    lastAccessTime_ = getCurrentTimeMs();
    if (std::find(activeBluetoothUsers_.begin(), activeBluetoothUsers_.end(), appId) == activeBluetoothUsers_.end()) {
        activeBluetoothUsers_.push_back(appId);
        stats_.indicatorToggleCount++;
        updatePrivacyIndicator();
    }

    BluetoothPrivacyMode mode = BluetoothPrivacyMode::FULL;
    uint32_t flags = BT_PRIVACY_NONE;
    std::string pseudonym;
    it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) {
        mode = it->second.privacyMode;
        flags = it->second.privacyFlags;
        pseudonym = it->second.pseudonym;
    }

    BluetoothDevice transformed = applyPrivacyTransform(dev, mode, flags, pseudonym);
    out = transformed.name;

    if (accessCallback_) accessCallback_(appId, BluetoothResult::SUCCESS);
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::getDeviceRssi(const std::string& appId, const std::string& deviceId,
                                                  int32_t& out) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!checkAppAccess(appId)) return BluetoothResult::PERMISSION_DENIED;

    BluetoothDevice dev = getDevice(deviceId);
    if (dev.address.empty()) return BluetoothResult::DEVICE_NOT_FOUND;

    auto it = appPolicies_.find(appId);
    if (it != appPolicies_.end() && it->second.permission == BluetoothPermission::ALLOW_ONCE) {
        it->second.oneShotUsed = true;
    }

    lastAccessTime_ = getCurrentTimeMs();
    if (std::find(activeBluetoothUsers_.begin(), activeBluetoothUsers_.end(), appId) == activeBluetoothUsers_.end()) {
        activeBluetoothUsers_.push_back(appId);
        stats_.indicatorToggleCount++;
        updatePrivacyIndicator();
    }

    // METADATA_ONLY mode redacts RSSI
    BluetoothPrivacyMode mode = BluetoothPrivacyMode::FULL;
    it = appPolicies_.find(appId);
    if (it != appPolicies_.end()) {
        mode = it->second.privacyMode;
    }

    if (mode == BluetoothPrivacyMode::METADATA_ONLY) {
        out = 0;
    } else {
        out = dev.rssi;
    }

    if (accessCallback_) accessCallback_(appId, BluetoothResult::SUCCESS);
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::getAdapterAddress(const std::string& appId, std::string& out) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(appId)) return BluetoothResult::PERMISSION_DENIED;

    out = adapterAddress_;
    return BluetoothResult::SUCCESS;
}

// ============================================================
// History / privacy
// ============================================================

std::vector<BluetoothEvent> BluetoothManager::getHistory(const std::string& appId,
                                                            size_t limit) const {
    std::vector<BluetoothEvent> result;
    for (auto it = history_.rbegin(); it != history_.rend(); ++it) {
        if (it->appId == appId || isSystemOwner(appId)) {
            result.push_back(*it);
            if (limit > 0 && result.size() >= limit) break;
        }
    }
    return result;
}

BluetoothResult BluetoothManager::clearHistory(const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    history_.clear();
    stats_.historyClears++;
    recordEvent(BluetoothEventType::HISTORY_CLEARED, BluetoothResult::SUCCESS,
                owner, "", "History cleared");
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::clearAppHistory(const std::string& appId,
                                                     const std::string& requester) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(requester) && requester != appId) return BluetoothResult::PERMISSION_DENIED;

    auto it = std::remove_if(history_.begin(), history_.end(),
        [&appId](const BluetoothEvent& e) { return e.appId == appId; });
    history_.erase(it, history_.end());

    return BluetoothResult::SUCCESS;
}

// ============================================================
// Mock / testing
// ============================================================

BluetoothResult BluetoothManager::setMockEnabled(bool enabled, const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    mockEnabled_ = enabled;
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::setMockDevice(const BluetoothDevice& device,
                                                  const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    // Find and replace or add
    bool found = false;
    for (auto& dev : devices_) {
        if (dev.address == device.address) {
            dev = device;
            found = true;
            break;
        }
    }
    if (!found) {
        if (devices_.size() >= maxDevices_) return BluetoothResult::CAPACITY_EXCEEDED;
        devices_.push_back(device);
    }

    stats_.mockDevicesSet++;
    recordEvent(BluetoothEventType::MOCK_DEVICE_SET, BluetoothResult::SUCCESS,
                owner, redactAddress(device.address), "Mock device set");

    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::addMockDevice(const BluetoothDevice& device,
                                                 const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;
    if (devices_.size() >= maxDevices_) return BluetoothResult::CAPACITY_EXCEEDED;

    // Check duplicate
    for (const auto& dev : devices_) {
        if (dev.address == device.address) return BluetoothResult::ALREADY_BONDED;
    }

    devices_.push_back(device);
    stats_.mockDevicesSet++;
    return BluetoothResult::SUCCESS;
}

BluetoothResult BluetoothManager::removeMockDevice(const std::string& address,
                                                     const std::string& owner) {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;
    if (!isSystemOwner(owner)) return BluetoothResult::PERMISSION_DENIED;

    auto it = std::remove_if(devices_.begin(), devices_.end(),
        [&address](const BluetoothDevice& d) { return d.address == address; });
    if (it == devices_.end()) return BluetoothResult::DEVICE_NOT_FOUND;

    devices_.erase(it, devices_.end());
    profileConnections_.erase(address);

    return BluetoothResult::SUCCESS;
}

// ============================================================
// Events
// ============================================================

std::vector<BluetoothEvent> BluetoothManager::getEvents(size_t limit) const {
    if (limit == 0) return events_;
    std::vector<BluetoothEvent> result;
    for (auto it = events_.rbegin(); it != events_.rend() && result.size() < limit; ++it) {
        result.push_back(*it);
    }
    return result;
}

std::vector<BluetoothEvent> BluetoothManager::getEventsByType(BluetoothEventType type) const {
    std::vector<BluetoothEvent> result;
    for (const auto& e : events_) {
        if (e.type == type) result.push_back(e);
    }
    return result;
}

BluetoothResult BluetoothManager::clearEvents() {
    if (!initialized_) return BluetoothResult::NOT_INITIALIZED;

    // Archive to history
    for (const auto& e : events_) {
        if (history_.size() >= maxHistory_) {
            history_.erase(history_.begin());
        }
        history_.push_back(e);
    }
    events_.clear();
    return BluetoothResult::SUCCESS;
}

// ============================================================
// Stats
// ============================================================

void BluetoothManager::resetStats() {
    stats_ = BluetoothStats{};
}

// ============================================================
// String helpers
// ============================================================

const char* BluetoothManager::adapterStateToString(AdapterState state) {
    switch (state) {
        case AdapterState::DISABLED: return "DISABLED";
        case AdapterState::OFF: return "OFF";
        case AdapterState::TURNING_ON: return "TURNING_ON";
        case AdapterState::ON: return "ON";
        case AdapterState::TURNING_OFF: return "TURNING_OFF";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::scanModeToString(ScanMode mode) {
    switch (mode) {
        case ScanMode::NONE: return "NONE";
        case ScanMode::CONNECTABLE: return "CONNECTABLE";
        case ScanMode::CONNECTABLE_DISCOVERABLE: return "CONNECTABLE_DISCOVERABLE";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::deviceTypeToString(DeviceType type) {
    switch (type) {
        case DeviceType::UNKNOWN: return "UNKNOWN";
        case DeviceType::CLASSIC: return "CLASSIC";
        case DeviceType::LE: return "LE";
        case DeviceType::DUAL: return "DUAL";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::deviceStateToString(DeviceState state) {
    switch (state) {
        case DeviceState::UNBONDED: return "UNBONDED";
        case DeviceState::BONDING: return "BONDING";
        case DeviceState::BONDED: return "BONDED";
        case DeviceState::CONNECTING: return "CONNECTING";
        case DeviceState::CONNECTED: return "CONNECTED";
        case DeviceState::DISCONNECTING: return "DISCONNECTING";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::bondStateToString(BondState state) {
    switch (state) {
        case BondState::NONE: return "NONE";
        case BondState::BONDING: return "BONDING";
        case BondState::BONDED: return "BONDED";
        case BondState::BOND_FAILED: return "BOND_FAILED";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::profileTypeToString(ProfileType profile) {
    switch (profile) {
        case ProfileType::A2DP_SINK: return "A2DP_SINK";
        case ProfileType::A2DP_SOURCE: return "A2DP_SOURCE";
        case ProfileType::HFP_CLIENT: return "HFP_CLIENT";
        case ProfileType::HSP_CLIENT: return "HSP_CLIENT";
        case ProfileType::AVRCP_CONTROLLER: return "AVRCP_CONTROLLER";
        case ProfileType::AVRCP_TARGET: return "AVRCP_TARGET";
        case ProfileType::HID_HOST: return "HID_HOST";
        case ProfileType::PAN_USER: return "PAN_USER";
        case ProfileType::GATT_CLIENT: return "GATT_CLIENT";
        case ProfileType::GATT_SERVER: return "GATT_SERVER";
        case ProfileType::SPP_SERVER: return "SPP_SERVER";
        case ProfileType::MAP_CLIENT: return "MAP_CLIENT";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::permissionToString(BluetoothPermission permission) {
    switch (permission) {
        case BluetoothPermission::DENY: return "DENY";
        case BluetoothPermission::ALLOW_FOREGROUND: return "ALLOW_FOREGROUND";
        case BluetoothPermission::ALLOW_ALWAYS: return "ALLOW_ALWAYS";
        case BluetoothPermission::ALLOW_ONCE: return "ALLOW_ONCE";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::privacyModeToString(BluetoothPrivacyMode mode) {
    switch (mode) {
        case BluetoothPrivacyMode::FULL: return "FULL";
        case BluetoothPrivacyMode::REDACTED: return "REDACTED";
        case BluetoothPrivacyMode::METADATA_ONLY: return "METADATA_ONLY";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::resultToString(BluetoothResult result) {
    switch (result) {
        case BluetoothResult::SUCCESS: return "SUCCESS";
        case BluetoothResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case BluetoothResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case BluetoothResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case BluetoothResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case BluetoothResult::ADAPTER_OFF: return "ADAPTER_OFF";
        case BluetoothResult::DEVICE_NOT_FOUND: return "DEVICE_NOT_FOUND";
        case BluetoothResult::ALREADY_BONDED: return "ALREADY_BONDED";
        case BluetoothResult::BOND_FAILED: return "BOND_FAILED";
        case BluetoothResult::NOT_BONDED: return "NOT_BONDED";
        case BluetoothResult::CONNECTION_FAILED: return "CONNECTION_FAILED";
        case BluetoothResult::PROFILE_NOT_SUPPORTED: return "PROFILE_NOT_SUPPORTED";
        case BluetoothResult::CAPACITY_EXCEEDED: return "CAPACITY_EXCEEDED";
        case BluetoothResult::RATE_LIMITED: return "RATE_LIMITED";
        case BluetoothResult::BAD_STATE: return "BAD_STATE";
        case BluetoothResult::OPERATION_FAILED: return "OPERATION_FAILED";
        case BluetoothResult::SIMULATED_FAILURE: return "SIMULATED_FAILURE";
        default: return "UNKNOWN";
    }
}

const char* BluetoothManager::eventTypeToString(BluetoothEventType type) {
    switch (type) {
        case BluetoothEventType::ADAPTER_STATE_CHANGED: return "ADAPTER_STATE_CHANGED";
        case BluetoothEventType::SCAN_STARTED: return "SCAN_STARTED";
        case BluetoothEventType::SCAN_STOPPED: return "SCAN_STOPPED";
        case BluetoothEventType::DEVICE_FOUND: return "DEVICE_FOUND";
        case BluetoothEventType::BOND_STATE_CHANGED: return "BOND_STATE_CHANGED";
        case BluetoothEventType::DEVICE_CONNECTED: return "DEVICE_CONNECTED";
        case BluetoothEventType::DEVICE_DISCONNECTED: return "DEVICE_DISCONNECTED";
        case BluetoothEventType::PROFILE_CONNECTED: return "PROFILE_CONNECTED";
        case BluetoothEventType::PROFILE_DISCONNECTED: return "PROFILE_DISCONNECTED";
        case BluetoothEventType::PERMISSION_CHANGED: return "PERMISSION_CHANGED";
        case BluetoothEventType::PRIVACY_APPLIED: return "PRIVACY_APPLIED";
        case BluetoothEventType::INDICATOR_ON: return "INDICATOR_ON";
        case BluetoothEventType::INDICATOR_OFF: return "INDICATOR_OFF";
        case BluetoothEventType::DISCOVERABLE_CHANGED: return "DISCOVERABLE_CHANGED";
        case BluetoothEventType::MOCK_DEVICE_SET: return "MOCK_DEVICE_SET";
        case BluetoothEventType::HISTORY_CLEARED: return "HISTORY_CLEARED";
        default: return "UNKNOWN";
    }
}

BluetoothResult BluetoothManager::stringToResult(const std::string& str) {
    if (str == "SUCCESS") return BluetoothResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return BluetoothResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return BluetoothResult::ALREADY_INITIALIZED;
    if (str == "INVALID_PARAMETER") return BluetoothResult::INVALID_PARAMETER;
    if (str == "PERMISSION_DENIED") return BluetoothResult::PERMISSION_DENIED;
    if (str == "ADAPTER_OFF") return BluetoothResult::ADAPTER_OFF;
    if (str == "DEVICE_NOT_FOUND") return BluetoothResult::DEVICE_NOT_FOUND;
    if (str == "ALREADY_BONDED") return BluetoothResult::ALREADY_BONDED;
    if (str == "BOND_FAILED") return BluetoothResult::BOND_FAILED;
    if (str == "NOT_BONDED") return BluetoothResult::NOT_BONDED;
    if (str == "CONNECTION_FAILED") return BluetoothResult::CONNECTION_FAILED;
    if (str == "PROFILE_NOT_SUPPORTED") return BluetoothResult::PROFILE_NOT_SUPPORTED;
    if (str == "CAPACITY_EXCEEDED") return BluetoothResult::CAPACITY_EXCEEDED;
    if (str == "RATE_LIMITED") return BluetoothResult::RATE_LIMITED;
    if (str == "BAD_STATE") return BluetoothResult::BAD_STATE;
    if (str == "OPERATION_FAILED") return BluetoothResult::OPERATION_FAILED;
    if (str == "SIMULATED_FAILURE") return BluetoothResult::SIMULATED_FAILURE;
    return BluetoothResult::OPERATION_FAILED;
}

ProfileType BluetoothManager::stringToProfile(const std::string& str) {
    if (str == "A2DP_SINK") return ProfileType::A2DP_SINK;
    if (str == "A2DP_SOURCE") return ProfileType::A2DP_SOURCE;
    if (str == "HFP_CLIENT") return ProfileType::HFP_CLIENT;
    if (str == "HSP_CLIENT") return ProfileType::HSP_CLIENT;
    if (str == "AVRCP_CONTROLLER") return ProfileType::AVRCP_CONTROLLER;
    if (str == "AVRCP_TARGET") return ProfileType::AVRCP_TARGET;
    if (str == "HID_HOST") return ProfileType::HID_HOST;
    if (str == "PAN_USER") return ProfileType::PAN_USER;
    if (str == "GATT_CLIENT") return ProfileType::GATT_CLIENT;
    if (str == "GATT_SERVER") return ProfileType::GATT_SERVER;
    if (str == "SPP_SERVER") return ProfileType::SPP_SERVER;
    if (str == "MAP_CLIENT") return ProfileType::MAP_CLIENT;
    return ProfileType::A2DP_SINK;
}

// ============================================================
// Privacy helpers
// ============================================================

BluetoothDevice BluetoothManager::applyPrivacyTransform(const BluetoothDevice& device,
                                                          BluetoothPrivacyMode mode,
                                                          uint32_t privacyFlags,
                                                          const std::string& pseudonym) {
    BluetoothDevice result = device;

    if (mode == BluetoothPrivacyMode::FULL && privacyFlags == BT_PRIVACY_NONE) {
        return result;
    }

    // REDACT_ADDRESS or REDACTED mode
    if (privacyFlags & BT_PRIVACY_REDACT_ADDRESS || mode == BluetoothPrivacyMode::REDACTED) {
        result.address = redactAddress(device.address);
    }

    // PSEUDONYMIZE
    if (privacyFlags & BT_PRIVACY_PSEUDONYMIZE) {
        result.address = pseudonymizeAddress(device.address, pseudonym);
    }

    // METADATA_ONLY: redact address, name, and rssi
    if (mode == BluetoothPrivacyMode::METADATA_ONLY || (privacyFlags & BT_PRIVACY_METADATA_ONLY)) {
        result.address = redactAddress(device.address);
        result.name = "[REDACTED]";
        result.rssi = 0;
        result.uuids.clear();
    }

    return result;
}

std::string BluetoothManager::redactAddress(const std::string& address) {
    if (address.length() < 17) return "[REDACTED]";
    // Redact middle part: XX:XX:XX:XX:XX:XX -> XX:XX:XX:XX:XX:XX becomes XX:XX:XX:XX:XX:XX
    // We keep first 2 octets and redact the rest
    return address.substr(0, 5) + ":XX:XX:XX:XX";
}

std::string BluetoothManager::pseudonymizeAddress(const std::string& address,
                                                      const std::string& pseudonym) {
    if (pseudonym.empty()) return redactAddress(address);
    uint32_t hash = fnv1a(pseudonym);
    return generateStubMac(hash);
}

// ============================================================
// Private helpers
// ============================================================

uint64_t BluetoothManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ > 0) return timeOverrideMs_;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

bool BluetoothManager::isSystemOwner(const std::string& app) const {
    return app == "system" || app == "system_server";
}

void BluetoothManager::recordEvent(BluetoothEventType type, BluetoothResult result,
                                     const std::string& appId,
                                     const std::string& deviceAddress,
                                     const std::string& detail) {
    BluetoothEvent event;
    event.id = nextEventId_++;
    event.timestamp = getCurrentTimeMs();
    event.type = type;
    event.result = result;
    event.appId = appId;
    event.deviceAddress = deviceAddress;  // Already redacted by caller
    event.detail = detail;

    if (events_.size() >= maxEvents_) {
        events_.erase(events_.begin());
    }
    events_.push_back(event);

    // Update stats
    uint8_t typeIdx = static_cast<uint8_t>(type);
    uint8_t resultIdx = static_cast<uint8_t>(result);
    if (typeIdx < 16) stats_.byEventType[typeIdx]++;
    if (resultIdx < 17) stats_.byResult[resultIdx]++;

    if (result != BluetoothResult::SUCCESS) {
        stats_.totalFailures++;
    }

    if (eventCallback_) eventCallback_(event);
}

void BluetoothManager::logToServer(const std::string& level, const std::string& message) const {
    if (!logServer_) return;
    // Never log raw device addresses, device names, or connection metadata
    if (level == "INFO") {
        logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "BluetoothManager");
    } else if (level == "WARN") {
        logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "BluetoothManager");
    } else if (level == "ERROR") {
        logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "BluetoothManager");
    }
}

void BluetoothManager::notifyCrashReporter(const std::string& reason) const {
    if (!crashReporter_) return;
    crashReporter_->captureAnr("BluetoothManager", "BluetoothManager", 0, reason);
}

void BluetoothManager::updatePrivacyIndicator() {
    bool wasOn = !activeBluetoothUsers_.empty();
    bool isOn = !activeBluetoothUsers_.empty();

    if (wasOn && !isOn) {
        recordEvent(BluetoothEventType::INDICATOR_OFF, BluetoothResult::SUCCESS,
                    "system", "", "Privacy indicator off");
    } else if (!wasOn && isOn) {
        recordEvent(BluetoothEventType::INDICATOR_ON, BluetoothResult::SUCCESS,
                    "system", "", "Privacy indicator on");
    }
}

void BluetoothManager::setStubAdapter() {
    // Deterministic adapter address
    adapterAddress_ = generateStubMac(0x12345678);
}

void BluetoothManager::setStubDevices() {
    // Add some default mock devices
    BluetoothDevice dev1;
    dev1.address = generateStubMac(0xAABBCCDD);
    dev1.name = "AirPods Pro (Mock)";
    dev1.type = DeviceType::DUAL;
    dev1.state = DeviceState::UNBONDED;
    dev1.bondState = BondState::NONE;
    dev1.connected = false;
    dev1.rssi = -45;
    dev1.uuids.push_back("0000110A-0000-1000-8000-00805F9B34FB");
    devices_.push_back(dev1);

    BluetoothDevice dev2;
    dev2.address = generateStubMac(0x11223344);
    dev2.name = "JBL Charge 5 (Mock)";
    dev2.type = DeviceType::CLASSIC;
    dev2.state = DeviceState::UNBONDED;
    dev2.bondState = BondState::NONE;
    dev2.connected = false;
    dev2.rssi = -62;
    devices_.push_back(dev2);

    BluetoothDevice dev3;
    dev3.address = generateStubMac(0x55667788);
    dev3.name = "Magic Keyboard (Mock)";
    dev3.type = DeviceType::LE;
    dev3.state = DeviceState::UNBONDED;
    dev3.bondState = BondState::NONE;
    dev3.connected = false;
    dev3.rssi = -55;
    devices_.push_back(dev3);
}

}  // namespace bluetooth
}  // namespace phantom
