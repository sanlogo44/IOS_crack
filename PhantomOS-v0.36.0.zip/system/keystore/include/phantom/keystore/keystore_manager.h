/*
 * Phantom OS - KeyStore / Crypto Service
 * Key management, encryption, signing, attestation (simulated/stub)
 *
 * v0.23.0
 * License: GPL-3.0
 *
 * All cryptographic operations are simulated stubs for prototype use.
 * No real AES/RSA/ECDSA/PBKDF2/HKDF is implemented.
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::keystore {

// ============================================================
// Enums
// ============================================================

enum class KeyType {
    AES_128,        // 128-bit symmetric key
    AES_256,        // 256-bit symmetric key
    RSA_2048,       // 2048-bit RSA key pair
    RSA_4096,       // 4096-bit RSA key pair
    ECDSA_P256,     // ECDSA P-256 key pair
    HMAC_SHA256,    // HMAC-SHA256 key
    DERIVED_SECRET, // Key derived from another key or password
    RAW_SECRET      // Raw secret material
};

enum class KeyPurpose {
    ENCRYPT,   // Encrypt data
    DECRYPT,   // Decrypt data
    SIGN,      // Sign data
    VERIFY,    // Verify signatures
    WRAP,      // Wrap (encrypt) another key
    UNWRAP,    // Unwrap (decrypt) another key
    DERIVE,    // Derive sub-keys
    ATTEST    // Attest key properties
};

enum class KeyState {
    ACTIVE,       // Key is usable
    DISABLED,     // Temporarily disabled
    EXPIRED,      // Past expiration
    REVOKED,      // Permanently revoked
    ROTATED,      // Superseded by a rotation
    DESTROYED,    // Key material destroyed
    COMPROMISED   // Key may be compromised
};

enum class StorageBackend {
    MEMORY,              // In-memory only (lost on reboot)
    SECURE_STORAGE_STUB,  // Simulated secure storage
    HARDWARE_BACKED_STUB, // Simulated hardware-backed
    BACKUP_BLOB          // Serialized for backup
};

enum class CryptoAlgorithm {
    AES_GCM_STUB,       // AES-GCM (simulated)
    AES_CBC_STUB,       // AES-CBC (simulated)
    RSA_OAEP_STUB,      // RSA-OAEP (simulated)
    ECDSA_P256_STUB,    // ECDSA P-256 (simulated)
    HMAC_SHA256_STUB,   // HMAC-SHA256 (simulated)
    PBKDF2_SHA256_STUB, // PBKDF2-SHA256 (simulated)
    HKDF_SHA256_STUB,   // HKDF-SHA256 (simulated)
    FNV1A_MAC_STUB      // FNV-1a MAC (simulated)
};

enum class SecurityLevel {
    SOFTWARE,            // Pure software implementation
    SECURE_STORAGE,      // Simulated secure storage
    HARDWARE_BACKED_STUB,// Simulated hardware-backed
    SECURE_ENCLAVE_STUB  // Simulated Secure Enclave (SEP)
};

enum class AccessScope {
    SYSTEM_ONLY,   // Only system services
    APP_PRIVATE,   // Only the owning app
    SHARED_APPS,   // Multiple apps via grants
    RECOVERY_ONLY  // Only accessible in recovery mode
};

enum class CertificateState {
    VALID,     // Certificate is valid
    EXPIRED,   // Certificate has expired
    REVOKED,   // Certificate has been revoked
    UNTRUSTED  // Certificate is not trusted
};

enum class KeyStoreResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    KEY_NOT_FOUND,
    KEY_EXISTS,
    INVALID_KEY_ID,
    INVALID_ALIAS,
    INVALID_PARAMETER,
    BAD_STATE,
    PERMISSION_DENIED,
    PURPOSE_NOT_ALLOWED,
    ALGORITHM_MISMATCH,
    UNSUPPORTED_KEY_TYPE,
    UNSUPPORTED_ALGORITHM,
    STORAGE_FULL,
    KEY_EXPIRED,
    KEY_REVOKED,
    KEY_DISABLED,
    EXPORT_DENIED,
    IMPORT_FAILED,
    CRYPTO_FAILED,
    VERIFICATION_FAILED,
    ATTESTATION_FAILED,
    CERTIFICATE_NOT_FOUND,
    HARDWARE_UNAVAILABLE
};

// ============================================================
// Structs
// ============================================================

struct KeyPolicy {
    uint8_t allowedPurposes = 0;          // Bitmask of KeyPurpose bits
    bool exportable = false;              // Can key material be exported?
    bool backupable = false;              // Can key be included in backups?
    bool requiresAuth = false;            // Requires user authentication?
    bool hardwareBackedRequired = false;  // Must be hardware-backed?
    uint64_t expiresAt = 0;               // Expiration timestamp (0 = never)
    uint32_t maxUses = 0;                 // Max uses (0 = unlimited)
    AccessScope accessScope = AccessScope::APP_PRIVATE;
};

struct KeyMetadata {
    uint64_t id = 0;
    std::string alias;
    std::string ownerAppId;
    KeyType type = KeyType::AES_256;
    KeyState state = KeyState::ACTIVE;
    StorageBackend backend = StorageBackend::MEMORY;
    SecurityLevel securityLevel = SecurityLevel::SOFTWARE;
    KeyPolicy policy;
    uint32_t version = 1;
    uint64_t createdAt = 0;
    uint64_t lastUsedAt = 0;
    uint64_t useCount = 0;
    bool systemKey = false;
    // Internal key material (simulated)
    uint64_t keyMaterial = 0;
};

struct AccessGrant {
    uint64_t keyId = 0;
    std::string appId;
    uint8_t allowedPurposes = 0;  // Bitmask of KeyPurpose bits
    uint64_t expiresAt = 0;       // 0 = never
};

struct CryptoRequest {
    uint64_t keyId = 0;
    std::string alias;             // Alternative to keyId
    std::string appId;
    CryptoAlgorithm algorithm = CryptoAlgorithm::AES_GCM_STUB;
    std::string input;             // Plaintext or ciphertext
    std::string aad;               // Additional authenticated data
    std::string iv;                // IV/nonce (empty = generate)
};

struct CryptoResult {
    KeyStoreResult result = KeyStoreResult::SUCCESS;
    std::string output;           // Ciphertext or plaintext
    std::string iv;               // Generated IV/nonce
    std::string tag;               // Authentication tag or signature
    uint64_t bytesProcessed = 0;
};

struct DerivationParams {
    CryptoAlgorithm algorithm = CryptoAlgorithm::PBKDF2_SHA256_STUB;
    std::string password;         // For PBKDF2
    uint64_t sourceKeyId = 0;     // For HKDF (derive from another key)
    std::string salt;
    std::string info;             // HKDF info parameter
    uint32_t iterations = 1000;   // PBKDF2 iterations
    uint32_t outputLength = 32;   // Output key length in bytes
};

struct AttestationReport {
    uint64_t keyId = 0;
    std::string challenge;
    SecurityLevel securityLevel = SecurityLevel::SOFTWARE;
    bool hardwareBacked = false;
    bool verified = false;
    uint64_t timestamp = 0;
    std::string certificateChainStub;
    std::string summary;
};

struct CertificateEntry {
    uint64_t certId = 0;
    uint64_t keyId = 0;
    std::string subject;
    std::string issuer;
    std::string serial;
    uint64_t validFrom = 0;
    uint64_t validTo = 0;
    CertificateState state = CertificateState::VALID;
    std::string fingerprint;
};

struct KeyStoreStats {
    uint64_t totalKeys = 0;
    uint64_t keysGenerated = 0;
    uint64_t keysImported = 0;
    uint64_t keysDerived = 0;
    uint64_t keysDeleted = 0;
    uint64_t keysRotated = 0;
    uint64_t keysDisabled = 0;
    uint64_t keysRevoked = 0;
    uint64_t encryptOps = 0;
    uint64_t decryptOps = 0;
    uint64_t signOps = 0;
    uint64_t verifyOps = 0;
    uint64_t wrapOps = 0;
    uint64_t unwrapOps = 0;
    uint64_t attestations = 0;
    uint64_t certificates = 0;
    uint64_t totalFailures = 0;
    uint64_t totalByType[8] = {};        // Per KeyType
    uint64_t totalByBackend[4] = {};     // Per StorageBackend
    uint64_t totalByState[7] = {};       // Per KeyState
    uint64_t totalBySecurityLevel[4] = {}; // Per SecurityLevel
};

struct KeyOperationRecord {
    uint64_t id = 0;
    uint64_t keyId = 0;
    std::string appId;
    std::string operation;  // "encrypt", "decrypt", "sign", etc.
    CryptoAlgorithm algorithm = CryptoAlgorithm::AES_GCM_STUB;
    KeyStoreResult result = KeyStoreResult::SUCCESS;
    uint64_t timestamp = 0;
    uint64_t bytesProcessed = 0;
};

// ============================================================
// KeyStoreManager - Central key management and crypto service
// ============================================================

class KeyStoreManager {
public:
    KeyStoreManager() = default;
    ~KeyStoreManager() { shutdown(); }

    // Lifecycle
    KeyStoreResult initialize(size_t maxKeys = 256, size_t maxCertificates = 128, size_t maxHistory = 500);
    KeyStoreResult shutdown();
    bool isInitialized() const { return initialized_; }
    void setMaxKeys(size_t max) { maxKeys_ = max; }
    size_t getMaxKeys() const { return maxKeys_; }
    void setMaxCertificates(size_t max) { maxCertificates_ = max; }
    size_t getMaxCertificates() const { return maxCertificates_; }
    void setMaxHistory(size_t max) { maxHistory_ = max; }
    size_t getMaxHistory() const { return maxHistory_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Test hooks
    void setFailNextOperation(bool fail) { failNextOperation_ = fail; }
    bool getFailNextOperation() const { return failNextOperation_; }

    // Key management
    uint64_t generateKey(const std::string& alias, KeyType type, const KeyPolicy& policy,
                          const std::string& ownerAppId, StorageBackend backend = StorageBackend::MEMORY);
    KeyStoreResult importKey(const std::string& alias, KeyType type, const std::string& material,
                             const KeyPolicy& policy, const std::string& ownerAppId,
                             StorageBackend backend = StorageBackend::MEMORY);
    uint64_t deriveKey(const std::string& alias, const DerivationParams& params,
                        const KeyPolicy& policy, const std::string& ownerAppId);
    KeyMetadata getKeyMetadata(uint64_t id) const;
    uint64_t getKeyByAlias(const std::string& alias, const std::string& ownerAppId) const;
    std::vector<KeyMetadata> listKeys() const;
    std::vector<KeyMetadata> getKeysByOwner(const std::string& ownerAppId) const;
    std::vector<KeyMetadata> getKeysByType(KeyType type) const;
    std::vector<KeyMetadata> getKeysByState(KeyState state) const;
    KeyStoreResult deleteKey(uint64_t id, const std::string& appId);
    KeyStoreResult disableKey(uint64_t id, const std::string& appId);
    KeyStoreResult enableKey(uint64_t id, const std::string& appId);
    KeyStoreResult revokeKey(uint64_t id, const std::string& appId);
    uint64_t rotateKey(uint64_t id, const std::string& appId);

    // Access control
    KeyStoreResult grantAccess(uint64_t keyId, const std::string& appId, uint8_t purposes, uint64_t expiresAt = 0);
    KeyStoreResult revokeAccess(uint64_t keyId, const std::string& appId);
    bool checkAccess(uint64_t keyId, const std::string& appId, KeyPurpose purpose) const;
    std::vector<AccessGrant> getAccessGrants(uint64_t keyId) const;

    // Crypto operations
    CryptoResult encrypt(const CryptoRequest& req);
    CryptoResult decrypt(const CryptoRequest& req);
    CryptoResult sign(const CryptoRequest& req);
    KeyStoreResult verify(const CryptoRequest& req, const std::string& signatureOrTag);
    CryptoResult wrapKey(uint64_t wrappingKeyId, uint64_t keyToWrapId, const std::string& appId);
    uint64_t unwrapKey(uint64_t wrappingKeyId, const std::string& wrappedBlob,
                       const std::string& alias, const KeyPolicy& policy, const std::string& appId);

    // Backup/update/recovery hooks
    std::string exportKeyBlob(uint64_t keyId, const std::string& appId);
    uint64_t importKeyBlob(const std::string& blob, const std::string& alias,
                            const KeyPolicy& policy, const std::string& appId);
    std::vector<KeyMetadata> getRecoveryKeys() const;
    std::vector<KeyMetadata> getKeysByScope(AccessScope scope) const;

    // Attestation and certificates
    AttestationReport attestKey(uint64_t keyId, const std::string& challenge, const std::string& appId);
    uint64_t createSelfSignedCertificate(uint64_t keyId, const std::string& subject, const std::string& appId);
    KeyStoreResult importCertificate(uint64_t keyId, const std::string& certData, const std::string& appId);
    CertificateEntry getCertificate(uint64_t certId) const;
    std::vector<CertificateEntry> getCertificatesForKey(uint64_t keyId) const;
    KeyStoreResult revokeCertificate(uint64_t certId, const std::string& appId);

    // Stats and history
    KeyStoreStats getStats() const;
    void resetStats();
    std::vector<KeyOperationRecord> getHistory() const;
    KeyStoreResult clearHistory();

    // Callbacks
    using KeyStateCallback = std::function<void(uint64_t keyId, KeyState oldState, KeyState newState)>;
    using CryptoCallback = std::function<void(const KeyOperationRecord&)>;
    void setKeyStateCallback(KeyStateCallback cb) { keyStateCb_ = cb; }
    void setCryptoCallback(CryptoCallback cb) { cryptoCb_ = cb; }

    // String helpers
    static const char* keyTypeToString(KeyType type);
    static const char* keyPurposeToString(KeyPurpose purpose);
    static const char* keyStateToString(KeyState state);
    static const char* storageBackendToString(StorageBackend backend);
    static const char* cryptoAlgorithmToString(CryptoAlgorithm algo);
    static const char* securityLevelToString(SecurityLevel level);
    static const char* accessScopeToString(AccessScope scope);
    static const char* certificateStateToString(CertificateState state);
    static const char* keyStoreResultToString(KeyStoreResult result);
    static KeyType stringToKeyType(const std::string& str);
    static KeyPurpose stringToKeyPurpose(const std::string& str);
    static KeyState stringToKeyState(const std::string& str);
    static StorageBackend stringToStorageBackend(const std::string& str);
    static CryptoAlgorithm stringToCryptoAlgorithm(const std::string& str);

    // Purpose bitmask helpers
    static uint8_t purposeToBit(KeyPurpose purpose);
    static bool hasPurpose(uint8_t bitmask, KeyPurpose purpose);
    static std::string purposeBitmaskToString(uint8_t bitmask);

private:
    bool initialized_ = false;
    size_t maxKeys_ = 256;
    size_t maxCertificates_ = 128;
    size_t maxHistory_ = 500;
    uint64_t nextKeyId_ = 1;
    uint64_t nextCertId_ = 1;
    uint64_t nextOpId_ = 1;

    std::map<uint64_t, KeyMetadata> keys_;
    std::map<uint64_t, CertificateEntry> certificates_;
    std::map<uint64_t, std::vector<AccessGrant>> accessGrants_;
    std::vector<KeyOperationRecord> history_;

    bool failNextOperation_ = false;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    KeyStateCallback keyStateCb_;
    CryptoCallback cryptoCb_;

    // Stats
    uint64_t keysGenerated_ = 0;
    uint64_t keysImported_ = 0;
    uint64_t keysDerived_ = 0;
    uint64_t keysDeleted_ = 0;
    uint64_t keysRotated_ = 0;
    uint64_t keysDisabled_ = 0;
    uint64_t keysRevoked_ = 0;
    uint64_t encryptOps_ = 0;
    uint64_t decryptOps_ = 0;
    uint64_t signOps_ = 0;
    uint64_t verifyOps_ = 0;
    uint64_t wrapOps_ = 0;
    uint64_t unwrapOps_ = 0;
    uint64_t attestations_ = 0;
    uint64_t totalFailures_ = 0;
    uint64_t totalByType_[8] = {};
    uint64_t totalByBackend_[4] = {};
    uint64_t totalByState_[7] = {};
    uint64_t totalBySecurityLevel_[4] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    uint64_t computeFNV1a(const std::string& data) const;
    uint64_t generateKeyMaterial(uint64_t keyId, KeyType type, const std::string& alias, const std::string& owner);
    void changeKeyState(uint64_t keyId, KeyState newState);
    bool isKeyUsable(uint64_t keyId) const;
    void recordOperation(uint64_t keyId, const std::string& appId, const std::string& operation,
                         CryptoAlgorithm algo, KeyStoreResult result, uint64_t bytes);
    void moveToHistory(const KeyOperationRecord& record);
    bool isOwner(uint64_t keyId, const std::string& appId) const;
    bool isSystemApp(const std::string& appId) const;
    std::string xorWithKeystream(const std::string& data, uint64_t keyMaterial, const std::string& iv) const;
};

}  // namespace phantom::keystore
