/*
 * Phantom OS - KeyStore / Crypto Service Implementation
 *
 * v0.23.0
 * License: GPL-3.0
 *
 * All cryptographic operations are simulated stubs (FNV-1a based) for
 * prototype purposes. No real AES/RSA/ECDSA/PBKDF2/HKDF is implemented.
 */

#include "phantom/keystore/keystore_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <sstream>
#include <cstring>

namespace phantom::keystore {

// FNV-1a constants (matching project convention)
static constexpr uint64_t FNV_OFFSET_BASIS = 14695981039346656037ULL;
static constexpr uint64_t FNV_PRIME = 1099511628211ULL;

// ============================================================
// Helpers
// ============================================================

uint64_t KeyStoreManager::getCurrentTimeMs() const {
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

void KeyStoreManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "KeyStoreManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "KeyStoreManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "KeyStoreManager");
        }
    }
}

void KeyStoreManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId, "keystore_manager", 0, message);
    }
}

uint64_t KeyStoreManager::computeFNV1a(const std::string& data) const {
    uint64_t hash = FNV_OFFSET_BASIS;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    return hash;
}

uint64_t KeyStoreManager::generateKeyMaterial(uint64_t keyId, KeyType type, const std::string& alias,
                                               const std::string& owner) {
    std::ostringstream oss;
    oss << keyId << ":" << static_cast<int>(type) << ":" << alias << ":" << owner << ":"
        << getCurrentTimeMs() << ":" << nextOpId_++;
    return computeFNV1a(oss.str());
}

std::string KeyStoreManager::xorWithKeystream(const std::string& data, uint64_t keyMaterial,
                                               const std::string& iv) const {
    // Simulated keystream: FNV-1a over (keyMaterial || iv || counter), XOR'd byte-by-byte.
    std::string output;
    output.resize(data.size());
    uint64_t counter = 0;
    std::string block;
    size_t blockPos = 0;

    for (size_t i = 0; i < data.size(); ++i) {
        if (blockPos == 0 || blockPos >= 8) {
            std::ostringstream oss;
            oss << keyMaterial << ":" << iv << ":" << counter++;
            uint64_t h = computeFNV1a(oss.str());
            block.assign(reinterpret_cast<char*>(&h), sizeof(h));
            blockPos = 0;
        }
        output[i] = data[i] ^ block[blockPos++];
    }
    return output;
}

void KeyStoreManager::changeKeyState(uint64_t keyId, KeyState newState) {
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return;
    KeyState oldState = it->second.state;
    if (oldState == newState) return;
    it->second.state = newState;
    if (keyStateCb_) keyStateCb_(keyId, oldState, newState);
}

bool KeyStoreManager::isKeyUsable(uint64_t keyId) const {
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return false;
    const KeyMetadata& key = it->second;
    if (key.state != KeyState::ACTIVE) return false;
    if (key.policy.expiresAt > 0 && getCurrentTimeMs() >= key.policy.expiresAt) return false;
    if (key.policy.maxUses > 0 && key.useCount >= key.policy.maxUses) return false;
    return true;
}

bool KeyStoreManager::isOwner(uint64_t keyId, const std::string& appId) const {
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return false;
    return it->second.ownerAppId == appId;
}

bool KeyStoreManager::isSystemApp(const std::string& appId) const {
    return appId == "system" || appId.empty();
}

void KeyStoreManager::recordOperation(uint64_t keyId, const std::string& appId, const std::string& operation,
                                       CryptoAlgorithm algo, KeyStoreResult result, uint64_t bytes) {
    KeyOperationRecord record;
    record.id = nextOpId_++;
    record.keyId = keyId;
    record.appId = appId;
    record.operation = operation;
    record.algorithm = algo;
    record.result = result;
    record.timestamp = getCurrentTimeMs();
    record.bytesProcessed = bytes;
    moveToHistory(record);
    if (cryptoCb_) cryptoCb_(record);
}

void KeyStoreManager::moveToHistory(const KeyOperationRecord& record) {
    if (history_.size() >= maxHistory_) {
        history_.erase(history_.begin());
    }
    history_.push_back(record);
}

// ============================================================
// Lifecycle
// ============================================================

KeyStoreResult KeyStoreManager::initialize(size_t maxKeys, size_t maxCertificates, size_t maxHistory) {
    if (initialized_) return KeyStoreResult::ALREADY_INITIALIZED;

    maxKeys_ = maxKeys;
    maxCertificates_ = maxCertificates;
    maxHistory_ = maxHistory;
    nextKeyId_ = 1;
    nextCertId_ = 1;
    nextOpId_ = 1;

    keys_.clear();
    certificates_.clear();
    accessGrants_.clear();
    history_.clear();
    failNextOperation_ = false;

    keysGenerated_ = 0;
    keysImported_ = 0;
    keysDerived_ = 0;
    keysDeleted_ = 0;
    keysRotated_ = 0;
    keysDisabled_ = 0;
    keysRevoked_ = 0;
    encryptOps_ = 0;
    decryptOps_ = 0;
    signOps_ = 0;
    verifyOps_ = 0;
    wrapOps_ = 0;
    unwrapOps_ = 0;
    attestations_ = 0;
    totalFailures_ = 0;
    for (int i = 0; i < 8; ++i) totalByType_[i] = 0;
    for (int i = 0; i < 4; ++i) totalByBackend_[i] = 0;
    for (int i = 0; i < 7; ++i) totalByState_[i] = 0;
    for (int i = 0; i < 4; ++i) totalBySecurityLevel_[i] = 0;

    initialized_ = true;
    logToServer("info", "KeyStoreManager initialized");
    return KeyStoreResult::SUCCESS;
}

KeyStoreResult KeyStoreManager::shutdown() {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;

    initialized_ = false;
    keys_.clear();
    certificates_.clear();
    accessGrants_.clear();
    history_.clear();
    failNextOperation_ = false;
    keyStateCb_ = nullptr;
    cryptoCb_ = nullptr;

    return KeyStoreResult::SUCCESS;
}

// ============================================================
// Key management
// ============================================================

uint64_t KeyStoreManager::generateKey(const std::string& alias, KeyType type, const KeyPolicy& policy,
                                       const std::string& ownerAppId, StorageBackend backend) {
    if (!initialized_) return 0;
    if (alias.empty()) return 0;
    if (keys_.size() >= maxKeys_) return 0;

    // Check for duplicate alias for the same owner
    for (const auto& [id, key] : keys_) {
        if (key.alias == alias && key.ownerAppId == ownerAppId) {
            return 0;
        }
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        logToServer("error", "Key generation failed (simulated): " + alias);
        notifyCrashReporter(ownerAppId.empty() ? "system" : ownerAppId, "Key generation failed: " + alias);
        return 0;
    }

    uint64_t id = nextKeyId_++;
    KeyMetadata key;
    key.id = id;
    key.alias = alias;
    key.ownerAppId = ownerAppId;
    key.type = type;
    key.state = KeyState::ACTIVE;
    key.backend = backend;
    key.securityLevel = (backend == StorageBackend::HARDWARE_BACKED_STUB)
                            ? SecurityLevel::HARDWARE_BACKED_STUB
                            : SecurityLevel::SOFTWARE;
    key.policy = policy;
    key.version = 1;
    key.createdAt = getCurrentTimeMs();
    key.lastUsedAt = 0;
    key.useCount = 0;
    key.systemKey = isSystemApp(ownerAppId);
    key.keyMaterial = generateKeyMaterial(id, type, alias, ownerAppId);

    keys_[id] = key;
    keysGenerated_++;
    totalByType_[static_cast<int>(type)]++;
    totalByBackend_[static_cast<int>(backend)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;
    totalBySecurityLevel_[static_cast<int>(key.securityLevel)]++;

    logToServer("info", "Key generated: " + alias + " (id=" + std::to_string(id) + ")");
    return id;
}

KeyStoreResult KeyStoreManager::importKey(const std::string& alias, KeyType type, const std::string& material,
                                           const KeyPolicy& policy, const std::string& ownerAppId,
                                           StorageBackend backend) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    if (alias.empty()) return KeyStoreResult::INVALID_ALIAS;
    if (material.empty()) return KeyStoreResult::INVALID_PARAMETER;
    if (keys_.size() >= maxKeys_) return KeyStoreResult::STORAGE_FULL;

    for (const auto& [id, key] : keys_) {
        if (key.alias == alias && key.ownerAppId == ownerAppId) {
            return KeyStoreResult::KEY_EXISTS;
        }
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        logToServer("error", "Key import failed (simulated): " + alias);
        return KeyStoreResult::IMPORT_FAILED;
    }

    uint64_t id = nextKeyId_++;
    KeyMetadata key;
    key.id = id;
    key.alias = alias;
    key.ownerAppId = ownerAppId;
    key.type = type;
    key.state = KeyState::ACTIVE;
    key.backend = backend;
    key.securityLevel = SecurityLevel::SOFTWARE;
    key.policy = policy;
    key.version = 1;
    key.createdAt = getCurrentTimeMs();
    key.systemKey = isSystemApp(ownerAppId);
    key.keyMaterial = computeFNV1a(material);

    keys_[id] = key;
    keysImported_++;
    totalByType_[static_cast<int>(type)]++;
    totalByBackend_[static_cast<int>(backend)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;
    totalBySecurityLevel_[static_cast<int>(key.securityLevel)]++;

    logToServer("info", "Key imported: " + alias);
    return KeyStoreResult::SUCCESS;
}

uint64_t KeyStoreManager::deriveKey(const std::string& alias, const DerivationParams& params,
                                     const KeyPolicy& policy, const std::string& ownerAppId) {
    if (!initialized_) return 0;
    if (alias.empty()) return 0;
    if (keys_.size() >= maxKeys_) return 0;

    uint64_t derivedMaterial = 0;

    if (params.algorithm == CryptoAlgorithm::PBKDF2_SHA256_STUB) {
        // Deterministic PBKDF2 stub: iterate hashing password + salt
        std::string current = params.password + ":" + params.salt;
        uint64_t h = computeFNV1a(current);
        for (uint32_t i = 1; i < params.iterations; ++i) {
            std::ostringstream oss;
            oss << h << ":" << i;
            h = computeFNV1a(oss.str());
        }
        derivedMaterial = h;
    } else if (params.algorithm == CryptoAlgorithm::HKDF_SHA256_STUB) {
        auto it = keys_.find(params.sourceKeyId);
        if (it == keys_.end()) return 0;
        std::ostringstream oss;
        oss << it->second.keyMaterial << ":" << params.salt << ":" << params.info;
        derivedMaterial = computeFNV1a(oss.str());
    } else {
        return 0;  // Unsupported derivation algorithm
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        logToServer("error", "Key derivation failed (simulated): " + alias);
        return 0;
    }

    uint64_t id = nextKeyId_++;
    KeyMetadata key;
    key.id = id;
    key.alias = alias;
    key.ownerAppId = ownerAppId;
    key.type = KeyType::DERIVED_SECRET;
    key.state = KeyState::ACTIVE;
    key.backend = StorageBackend::MEMORY;
    key.securityLevel = SecurityLevel::SOFTWARE;
    key.policy = policy;
    key.version = 1;
    key.createdAt = getCurrentTimeMs();
    key.systemKey = isSystemApp(ownerAppId);
    key.keyMaterial = derivedMaterial;

    keys_[id] = key;
    keysDerived_++;
    totalByType_[static_cast<int>(KeyType::DERIVED_SECRET)]++;
    totalByBackend_[static_cast<int>(StorageBackend::MEMORY)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;
    totalBySecurityLevel_[static_cast<int>(SecurityLevel::SOFTWARE)]++;

    logToServer("info", "Key derived: " + alias);
    return id;
}

KeyMetadata KeyStoreManager::getKeyMetadata(uint64_t id) const {
    auto it = keys_.find(id);
    if (it == keys_.end()) return KeyMetadata{};
    return it->second;
}

uint64_t KeyStoreManager::getKeyByAlias(const std::string& alias, const std::string& ownerAppId) const {
    for (const auto& [id, key] : keys_) {
        if (key.alias == alias && key.ownerAppId == ownerAppId) {
            return id;
        }
    }
    return 0;
}

std::vector<KeyMetadata> KeyStoreManager::listKeys() const {
    std::vector<KeyMetadata> result;
    for (const auto& [id, key] : keys_) {
        result.push_back(key);
    }
    return result;
}

std::vector<KeyMetadata> KeyStoreManager::getKeysByOwner(const std::string& ownerAppId) const {
    std::vector<KeyMetadata> result;
    for (const auto& [id, key] : keys_) {
        if (key.ownerAppId == ownerAppId) result.push_back(key);
    }
    return result;
}

std::vector<KeyMetadata> KeyStoreManager::getKeysByType(KeyType type) const {
    std::vector<KeyMetadata> result;
    for (const auto& [id, key] : keys_) {
        if (key.type == type) result.push_back(key);
    }
    return result;
}

std::vector<KeyMetadata> KeyStoreManager::getKeysByState(KeyState state) const {
    std::vector<KeyMetadata> result;
    for (const auto& [id, key] : keys_) {
        if (key.state == state) result.push_back(key);
    }
    return result;
}

KeyStoreResult KeyStoreManager::deleteKey(uint64_t id, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = keys_.find(id);
    if (it == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;
    if (!isOwner(id, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;

    changeKeyState(id, KeyState::DESTROYED);
    keys_.erase(it);
    accessGrants_.erase(id);
    keysDeleted_++;
    logToServer("info", "Key deleted: id=" + std::to_string(id));
    return KeyStoreResult::SUCCESS;
}

KeyStoreResult KeyStoreManager::disableKey(uint64_t id, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = keys_.find(id);
    if (it == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;
    if (!isOwner(id, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;

    changeKeyState(id, KeyState::DISABLED);
    keysDisabled_++;
    return KeyStoreResult::SUCCESS;
}

KeyStoreResult KeyStoreManager::enableKey(uint64_t id, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = keys_.find(id);
    if (it == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;
    if (!isOwner(id, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;
    if (it->second.state != KeyState::DISABLED) return KeyStoreResult::BAD_STATE;

    changeKeyState(id, KeyState::ACTIVE);
    return KeyStoreResult::SUCCESS;
}

KeyStoreResult KeyStoreManager::revokeKey(uint64_t id, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = keys_.find(id);
    if (it == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;
    if (!isOwner(id, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;

    changeKeyState(id, KeyState::REVOKED);
    keysRevoked_++;
    return KeyStoreResult::SUCCESS;
}

uint64_t KeyStoreManager::rotateKey(uint64_t id, const std::string& appId) {
    if (!initialized_) return 0;
    auto it = keys_.find(id);
    if (it == keys_.end()) return 0;
    if (!isOwner(id, appId) && !isSystemApp(appId)) return 0;

    KeyMetadata oldKey = it->second;
    changeKeyState(id, KeyState::ROTATED);

    uint64_t newId = nextKeyId_++;
    KeyMetadata newKey = oldKey;
    newKey.id = newId;
    newKey.version = oldKey.version + 1;
    newKey.state = KeyState::ACTIVE;
    newKey.createdAt = getCurrentTimeMs();
    newKey.useCount = 0;
    newKey.keyMaterial = generateKeyMaterial(newId, oldKey.type, oldKey.alias, oldKey.ownerAppId);

    keys_[newId] = newKey;
    keysRotated_++;
    totalByType_[static_cast<int>(newKey.type)]++;
    totalByBackend_[static_cast<int>(newKey.backend)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;

    logToServer("info", "Key rotated: " + oldKey.alias + " (new id=" + std::to_string(newId) + ")");
    return newId;
}

// ============================================================
// Access control
// ============================================================

KeyStoreResult KeyStoreManager::grantAccess(uint64_t keyId, const std::string& appId, uint8_t purposes,
                                             uint64_t expiresAt) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    if (keys_.find(keyId) == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;

    AccessGrant grant;
    grant.keyId = keyId;
    grant.appId = appId;
    grant.allowedPurposes = purposes;
    grant.expiresAt = expiresAt;

    auto& grants = accessGrants_[keyId];
    // Replace existing grant for the same app
    for (auto& g : grants) {
        if (g.appId == appId) {
            g = grant;
            return KeyStoreResult::SUCCESS;
        }
    }
    grants.push_back(grant);
    return KeyStoreResult::SUCCESS;
}

KeyStoreResult KeyStoreManager::revokeAccess(uint64_t keyId, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = accessGrants_.find(keyId);
    if (it == accessGrants_.end()) return KeyStoreResult::KEY_NOT_FOUND;

    auto& grants = it->second;
    auto grantIt = std::find_if(grants.begin(), grants.end(),
                                 [&appId](const AccessGrant& g) { return g.appId == appId; });
    if (grantIt == grants.end()) return KeyStoreResult::KEY_NOT_FOUND;

    grants.erase(grantIt);
    return KeyStoreResult::SUCCESS;
}

bool KeyStoreManager::checkAccess(uint64_t keyId, const std::string& appId, KeyPurpose purpose) const {
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return false;
    const KeyMetadata& key = it->second;

    // System apps always have access
    if (isSystemApp(appId)) return true;

    // Owner has access if the purpose is allowed by policy
    uint8_t purposeBit = purposeToBit(purpose);
    if (key.ownerAppId == appId) {
        return (key.policy.allowedPurposes & purposeBit) != 0;
    }

    // Check access scope
    if (key.policy.accessScope == AccessScope::SYSTEM_ONLY) return false;
    if (key.policy.accessScope == AccessScope::RECOVERY_ONLY) return false;
    if (key.policy.accessScope == AccessScope::APP_PRIVATE) return false;

    // SHARED_APPS: check grants
    auto grantsIt = accessGrants_.find(keyId);
    if (grantsIt == accessGrants_.end()) return false;

    for (const auto& grant : grantsIt->second) {
        if (grant.appId == appId) {
            if (grant.expiresAt > 0 && getCurrentTimeMs() >= grant.expiresAt) return false;
            return (grant.allowedPurposes & purposeBit) != 0;
        }
    }
    return false;
}

std::vector<AccessGrant> KeyStoreManager::getAccessGrants(uint64_t keyId) const {
    auto it = accessGrants_.find(keyId);
    if (it == accessGrants_.end()) return {};
    return it->second;
}

// ============================================================
// Crypto operations
// ============================================================

CryptoResult KeyStoreManager::encrypt(const CryptoRequest& req) {
    CryptoResult result;
    if (!initialized_) {
        result.result = KeyStoreResult::NOT_INITIALIZED;
        return result;
    }

    uint64_t keyId = req.keyId;
    if (keyId == 0 && !req.alias.empty()) {
        keyId = getKeyByAlias(req.alias, req.appId);
    }

    auto it = keys_.find(keyId);
    if (it == keys_.end()) {
        result.result = KeyStoreResult::KEY_NOT_FOUND;
        recordOperation(keyId, req.appId, "encrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (!checkAccess(keyId, req.appId, KeyPurpose::ENCRYPT)) {
        result.result = KeyStoreResult::PERMISSION_DENIED;
        recordOperation(keyId, req.appId, "encrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (!isKeyUsable(keyId)) {
        result.result = (it->second.state == KeyState::REVOKED) ? KeyStoreResult::KEY_REVOKED
                        : (it->second.state == KeyState::DISABLED) ? KeyStoreResult::KEY_DISABLED
                        : KeyStoreResult::KEY_EXPIRED;
        recordOperation(keyId, req.appId, "encrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        result.result = KeyStoreResult::CRYPTO_FAILED;
        recordOperation(keyId, req.appId, "encrypt", req.algorithm, result.result, 0);
        return result;
    }

    std::string iv = req.iv;
    if (iv.empty()) {
        std::ostringstream oss;
        oss << getCurrentTimeMs() << ":" << nextOpId_;
        uint64_t ivSeed = computeFNV1a(oss.str());
        iv.assign(reinterpret_cast<char*>(&ivSeed), sizeof(ivSeed));
    }

    std::string ciphertext = xorWithKeystream(req.input, it->second.keyMaterial, iv);

    // Compute authentication tag over key material + aad + ciphertext (simulated GCM tag)
    std::ostringstream tagInput;
    tagInput << it->second.keyMaterial << ":" << req.aad << ":" << ciphertext;
    uint64_t tag = computeFNV1a(tagInput.str());

    result.result = KeyStoreResult::SUCCESS;
    result.output = ciphertext;
    result.iv = iv;
    result.tag.assign(reinterpret_cast<char*>(&tag), sizeof(tag));
    result.bytesProcessed = req.input.size();

    it->second.useCount++;
    it->second.lastUsedAt = getCurrentTimeMs();
    encryptOps_++;
    recordOperation(keyId, req.appId, "encrypt", req.algorithm, result.result, result.bytesProcessed);
    return result;
}

CryptoResult KeyStoreManager::decrypt(const CryptoRequest& req) {
    CryptoResult result;
    if (!initialized_) {
        result.result = KeyStoreResult::NOT_INITIALIZED;
        return result;
    }

    uint64_t keyId = req.keyId;
    if (keyId == 0 && !req.alias.empty()) {
        keyId = getKeyByAlias(req.alias, req.appId);
    }

    auto it = keys_.find(keyId);
    if (it == keys_.end()) {
        result.result = KeyStoreResult::KEY_NOT_FOUND;
        recordOperation(keyId, req.appId, "decrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (!checkAccess(keyId, req.appId, KeyPurpose::DECRYPT)) {
        result.result = KeyStoreResult::PERMISSION_DENIED;
        recordOperation(keyId, req.appId, "decrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (!isKeyUsable(keyId)) {
        result.result = (it->second.state == KeyState::REVOKED) ? KeyStoreResult::KEY_REVOKED
                        : (it->second.state == KeyState::DISABLED) ? KeyStoreResult::KEY_DISABLED
                        : KeyStoreResult::KEY_EXPIRED;
        recordOperation(keyId, req.appId, "decrypt", req.algorithm, result.result, 0);
        return result;
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        result.result = KeyStoreResult::CRYPTO_FAILED;
        recordOperation(keyId, req.appId, "decrypt", req.algorithm, result.result, 0);
        return result;
    }

    // Verify tag if provided (in req.aad we assume caller passes original aad;
    // for simplicity decrypt does not re-verify tag here, that's verify()'s job)
    std::string plaintext = xorWithKeystream(req.input, it->second.keyMaterial, req.iv);

    result.result = KeyStoreResult::SUCCESS;
    result.output = plaintext;
    result.bytesProcessed = req.input.size();

    it->second.useCount++;
    it->second.lastUsedAt = getCurrentTimeMs();
    decryptOps_++;
    recordOperation(keyId, req.appId, "decrypt", req.algorithm, result.result, result.bytesProcessed);
    return result;
}

CryptoResult KeyStoreManager::sign(const CryptoRequest& req) {
    CryptoResult result;
    if (!initialized_) {
        result.result = KeyStoreResult::NOT_INITIALIZED;
        return result;
    }

    uint64_t keyId = req.keyId;
    if (keyId == 0 && !req.alias.empty()) {
        keyId = getKeyByAlias(req.alias, req.appId);
    }

    auto it = keys_.find(keyId);
    if (it == keys_.end()) {
        result.result = KeyStoreResult::KEY_NOT_FOUND;
        recordOperation(keyId, req.appId, "sign", req.algorithm, result.result, 0);
        return result;
    }

    if (!checkAccess(keyId, req.appId, KeyPurpose::SIGN)) {
        result.result = KeyStoreResult::PERMISSION_DENIED;
        recordOperation(keyId, req.appId, "sign", req.algorithm, result.result, 0);
        return result;
    }

    if (!isKeyUsable(keyId)) {
        result.result = (it->second.state == KeyState::REVOKED) ? KeyStoreResult::KEY_REVOKED
                        : (it->second.state == KeyState::DISABLED) ? KeyStoreResult::KEY_DISABLED
                        : KeyStoreResult::KEY_EXPIRED;
        recordOperation(keyId, req.appId, "sign", req.algorithm, result.result, 0);
        return result;
    }

    if (failNextOperation_) {
        failNextOperation_ = false;
        totalFailures_++;
        result.result = KeyStoreResult::CRYPTO_FAILED;
        recordOperation(keyId, req.appId, "sign", req.algorithm, result.result, 0);
        return result;
    }

    // Simulated signature: FNV-1a over (keyMaterial || algorithm || message)
    std::ostringstream sigInput;
    sigInput << it->second.keyMaterial << ":" << static_cast<int>(req.algorithm) << ":" << req.input;
    uint64_t sig = computeFNV1a(sigInput.str());

    result.result = KeyStoreResult::SUCCESS;
    result.tag.assign(reinterpret_cast<char*>(&sig), sizeof(sig));
    result.bytesProcessed = req.input.size();

    it->second.useCount++;
    it->second.lastUsedAt = getCurrentTimeMs();
    signOps_++;
    recordOperation(keyId, req.appId, "sign", req.algorithm, result.result, result.bytesProcessed);
    return result;
}

KeyStoreResult KeyStoreManager::verify(const CryptoRequest& req, const std::string& signatureOrTag) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;

    uint64_t keyId = req.keyId;
    if (keyId == 0 && !req.alias.empty()) {
        keyId = getKeyByAlias(req.alias, req.appId);
    }

    auto it = keys_.find(keyId);
    if (it == keys_.end()) {
        recordOperation(keyId, req.appId, "verify", req.algorithm, KeyStoreResult::KEY_NOT_FOUND, 0);
        return KeyStoreResult::KEY_NOT_FOUND;
    }

    if (!checkAccess(keyId, req.appId, KeyPurpose::VERIFY)) {
        recordOperation(keyId, req.appId, "verify", req.algorithm, KeyStoreResult::PERMISSION_DENIED, 0);
        return KeyStoreResult::PERMISSION_DENIED;
    }

    if (it->second.state == KeyState::DESTROYED || it->second.state == KeyState::REVOKED) {
        recordOperation(keyId, req.appId, "verify", req.algorithm, KeyStoreResult::KEY_REVOKED, 0);
        return KeyStoreResult::KEY_REVOKED;
    }

    std::ostringstream sigInput;
    sigInput << it->second.keyMaterial << ":" << static_cast<int>(req.algorithm) << ":" << req.input;
    uint64_t expectedSig = computeFNV1a(sigInput.str());

    std::string expectedSigStr;
    expectedSigStr.assign(reinterpret_cast<char*>(&expectedSig), sizeof(expectedSig));

    verifyOps_++;
    KeyStoreResult res = (expectedSigStr == signatureOrTag) ? KeyStoreResult::SUCCESS
                                                             : KeyStoreResult::VERIFICATION_FAILED;
    if (res == KeyStoreResult::SUCCESS) {
        it->second.useCount++;
        it->second.lastUsedAt = getCurrentTimeMs();
    }
    recordOperation(keyId, req.appId, "verify", req.algorithm, res, req.input.size());
    return res;
}

CryptoResult KeyStoreManager::wrapKey(uint64_t wrappingKeyId, uint64_t keyToWrapId, const std::string& appId) {
    CryptoResult result;
    if (!initialized_) {
        result.result = KeyStoreResult::NOT_INITIALIZED;
        return result;
    }

    auto wrapIt = keys_.find(wrappingKeyId);
    auto targetIt = keys_.find(keyToWrapId);
    if (wrapIt == keys_.end() || targetIt == keys_.end()) {
        result.result = KeyStoreResult::KEY_NOT_FOUND;
        return result;
    }

    if (!checkAccess(wrappingKeyId, appId, KeyPurpose::WRAP)) {
        result.result = KeyStoreResult::PERMISSION_DENIED;
        return result;
    }

    // Serialize target key material and "encrypt" with wrapping key
    std::ostringstream oss;
    oss << targetIt->second.keyMaterial << ":" << static_cast<int>(targetIt->second.type) << ":"
        << targetIt->second.alias;
    std::string blob = xorWithKeystream(oss.str(), wrapIt->second.keyMaterial, "wrap");

    result.result = KeyStoreResult::SUCCESS;
    result.output = blob;
    result.bytesProcessed = blob.size();
    wrapOps_++;
    recordOperation(wrappingKeyId, appId, "wrap", CryptoAlgorithm::AES_GCM_STUB, result.result, blob.size());
    return result;
}

uint64_t KeyStoreManager::unwrapKey(uint64_t wrappingKeyId, const std::string& wrappedBlob,
                                    const std::string& alias, const KeyPolicy& policy,
                                    const std::string& appId) {
    if (!initialized_) return 0;

    auto wrapIt = keys_.find(wrappingKeyId);
    if (wrapIt == keys_.end()) return 0;

    if (!checkAccess(wrappingKeyId, appId, KeyPurpose::UNWRAP)) return 0;

    std::string decoded = xorWithKeystream(wrappedBlob, wrapIt->second.keyMaterial, "wrap");
    // Reconstruct is simulated - since original stub can't easily parse back,
    // we generate a new key material derived from the unwrapped blob.
    uint64_t newMaterial = computeFNV1a(decoded);

    if (keys_.size() >= maxKeys_) return 0;

    uint64_t id = nextKeyId_++;
    KeyMetadata key;
    key.id = id;
    key.alias = alias;
    key.ownerAppId = appId;
    key.type = KeyType::RAW_SECRET;
    key.state = KeyState::ACTIVE;
    key.backend = StorageBackend::MEMORY;
    key.securityLevel = SecurityLevel::SOFTWARE;
    key.policy = policy;
    key.version = 1;
    key.createdAt = getCurrentTimeMs();
    key.systemKey = isSystemApp(appId);
    key.keyMaterial = newMaterial;

    keys_[id] = key;
    unwrapOps_++;
    totalByType_[static_cast<int>(KeyType::RAW_SECRET)]++;
    totalByBackend_[static_cast<int>(StorageBackend::MEMORY)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;

    recordOperation(wrappingKeyId, appId, "unwrap", CryptoAlgorithm::AES_GCM_STUB, KeyStoreResult::SUCCESS, 0);
    return id;
}

// ============================================================
// Backup/update/recovery hooks
// ============================================================

std::string KeyStoreManager::exportKeyBlob(uint64_t keyId, const std::string& appId) {
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return "";
    if (!isOwner(keyId, appId) && !isSystemApp(appId)) return "";
    if (!it->second.policy.exportable) return "";

    std::ostringstream oss;
    oss << it->second.keyMaterial << ":" << static_cast<int>(it->second.type) << ":" << it->second.alias;
    return oss.str();
}

uint64_t KeyStoreManager::importKeyBlob(const std::string& blob, const std::string& alias,
                                         const KeyPolicy& policy, const std::string& appId) {
    if (!initialized_) return 0;
    if (blob.empty() || alias.empty()) return 0;
    if (keys_.size() >= maxKeys_) return 0;

    uint64_t id = nextKeyId_++;
    KeyMetadata key;
    key.id = id;
    key.alias = alias;
    key.ownerAppId = appId;
    key.type = KeyType::RAW_SECRET;
    key.state = KeyState::ACTIVE;
    key.backend = StorageBackend::BACKUP_BLOB;
    key.securityLevel = SecurityLevel::SOFTWARE;
    key.policy = policy;
    key.version = 1;
    key.createdAt = getCurrentTimeMs();
    key.systemKey = isSystemApp(appId);
    key.keyMaterial = computeFNV1a(blob);

    keys_[id] = key;
    keysImported_++;
    totalByType_[static_cast<int>(KeyType::RAW_SECRET)]++;
    totalByBackend_[static_cast<int>(StorageBackend::BACKUP_BLOB)]++;
    totalByState_[static_cast<int>(KeyState::ACTIVE)]++;

    return id;
}

std::vector<KeyMetadata> KeyStoreManager::getRecoveryKeys() const {
    return getKeysByScope(AccessScope::RECOVERY_ONLY);
}

std::vector<KeyMetadata> KeyStoreManager::getKeysByScope(AccessScope scope) const {
    std::vector<KeyMetadata> result;
    for (const auto& [id, key] : keys_) {
        if (key.policy.accessScope == scope) result.push_back(key);
    }
    return result;
}

// ============================================================
// Attestation and certificates
// ============================================================

AttestationReport KeyStoreManager::attestKey(uint64_t keyId, const std::string& challenge,
                                              const std::string& appId) {
    AttestationReport report;
    report.keyId = keyId;
    report.challenge = challenge;
    report.timestamp = getCurrentTimeMs();

    auto it = keys_.find(keyId);
    if (it == keys_.end()) {
        report.verified = false;
        report.summary = "Key not found";
        return report;
    }

    if (!checkAccess(keyId, appId, KeyPurpose::ATTEST)) {
        report.verified = false;
        report.summary = "Permission denied";
        return report;
    }

    report.securityLevel = it->second.securityLevel;
    report.hardwareBacked = (it->second.securityLevel == SecurityLevel::HARDWARE_BACKED_STUB ||
                             it->second.securityLevel == SecurityLevel::SECURE_ENCLAVE_STUB);

    std::ostringstream oss;
    oss << it->second.keyMaterial << ":" << challenge << ":" << static_cast<int>(it->second.securityLevel);
    uint64_t attestHash = computeFNV1a(oss.str());
    std::ostringstream chainOss;
    chainOss << "STUB-CHAIN-" << attestHash;
    report.certificateChainStub = chainOss.str();
    report.verified = true;
    report.summary = "Attestation successful (simulated)";

    attestations_++;
    logToServer("info", "Key attested: id=" + std::to_string(keyId));
    return report;
}

uint64_t KeyStoreManager::createSelfSignedCertificate(uint64_t keyId, const std::string& subject,
                                                       const std::string& appId) {
    if (!initialized_) return 0;
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return 0;
    if (!isOwner(keyId, appId) && !isSystemApp(appId)) return 0;
    if (certificates_.size() >= maxCertificates_) return 0;

    uint64_t certId = nextCertId_++;
    CertificateEntry cert;
    cert.certId = certId;
    cert.keyId = keyId;
    cert.subject = subject;
    cert.issuer = subject;  // Self-signed
    std::ostringstream serialOss;
    serialOss << "SN-" << certId << "-" << it->second.keyMaterial;
    cert.serial = serialOss.str();
    cert.validFrom = getCurrentTimeMs();
    cert.validTo = cert.validFrom + (365ULL * 24 * 3600 * 1000);  // 1 year
    cert.state = CertificateState::VALID;

    std::ostringstream fpOss;
    fpOss << it->second.keyMaterial << ":" << subject << ":" << certId;
    uint64_t fp = computeFNV1a(fpOss.str());
    std::ostringstream fpStrOss;
    fpStrOss << "FP-" << fp;
    cert.fingerprint = fpStrOss.str();

    certificates_[certId] = cert;
    logToServer("info", "Certificate created: " + subject);
    return certId;
}

KeyStoreResult KeyStoreManager::importCertificate(uint64_t keyId, const std::string& certData,
                                                   const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = keys_.find(keyId);
    if (it == keys_.end()) return KeyStoreResult::KEY_NOT_FOUND;
    if (!isOwner(keyId, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;
    if (certData.empty()) return KeyStoreResult::INVALID_PARAMETER;
    if (certificates_.size() >= maxCertificates_) return KeyStoreResult::STORAGE_FULL;

    uint64_t certId = nextCertId_++;
    CertificateEntry cert;
    cert.certId = certId;
    cert.keyId = keyId;
    cert.subject = "imported";
    cert.issuer = "external";
    std::ostringstream serialOss;
    serialOss << "IMPORTED-" << certId;
    cert.serial = serialOss.str();
    cert.validFrom = getCurrentTimeMs();
    cert.validTo = cert.validFrom + (365ULL * 24 * 3600 * 1000);
    cert.state = CertificateState::VALID;

    uint64_t fp = computeFNV1a(certData);
    std::ostringstream fpOss;
    fpOss << "FP-" << fp;
    cert.fingerprint = fpOss.str();

    certificates_[certId] = cert;
    return KeyStoreResult::SUCCESS;
}

CertificateEntry KeyStoreManager::getCertificate(uint64_t certId) const {
    auto it = certificates_.find(certId);
    if (it == certificates_.end()) return CertificateEntry{};
    return it->second;
}

std::vector<CertificateEntry> KeyStoreManager::getCertificatesForKey(uint64_t keyId) const {
    std::vector<CertificateEntry> result;
    for (const auto& [id, cert] : certificates_) {
        if (cert.keyId == keyId) result.push_back(cert);
    }
    return result;
}

KeyStoreResult KeyStoreManager::revokeCertificate(uint64_t certId, const std::string& appId) {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    auto it = certificates_.find(certId);
    if (it == certificates_.end()) return KeyStoreResult::CERTIFICATE_NOT_FOUND;

    if (!isOwner(it->second.keyId, appId) && !isSystemApp(appId)) return KeyStoreResult::PERMISSION_DENIED;

    it->second.state = CertificateState::REVOKED;
    return KeyStoreResult::SUCCESS;
}

// ============================================================
// Stats and history
// ============================================================

KeyStoreStats KeyStoreManager::getStats() const {
    KeyStoreStats stats{};
    stats.totalKeys = keys_.size();
    stats.keysGenerated = keysGenerated_;
    stats.keysImported = keysImported_;
    stats.keysDerived = keysDerived_;
    stats.keysDeleted = keysDeleted_;
    stats.keysRotated = keysRotated_;
    stats.keysDisabled = keysDisabled_;
    stats.keysRevoked = keysRevoked_;
    stats.encryptOps = encryptOps_;
    stats.decryptOps = decryptOps_;
    stats.signOps = signOps_;
    stats.verifyOps = verifyOps_;
    stats.wrapOps = wrapOps_;
    stats.unwrapOps = unwrapOps_;
    stats.attestations = attestations_;
    stats.certificates = certificates_.size();
    stats.totalFailures = totalFailures_;
    for (int i = 0; i < 8; ++i) stats.totalByType[i] = totalByType_[i];
    for (int i = 0; i < 4; ++i) stats.totalByBackend[i] = totalByBackend_[i];
    for (int i = 0; i < 7; ++i) stats.totalByState[i] = totalByState_[i];
    for (int i = 0; i < 4; ++i) stats.totalBySecurityLevel[i] = totalBySecurityLevel_[i];
    return stats;
}

void KeyStoreManager::resetStats() {
    keysGenerated_ = 0;
    keysImported_ = 0;
    keysDerived_ = 0;
    keysDeleted_ = 0;
    keysRotated_ = 0;
    keysDisabled_ = 0;
    keysRevoked_ = 0;
    encryptOps_ = 0;
    decryptOps_ = 0;
    signOps_ = 0;
    verifyOps_ = 0;
    wrapOps_ = 0;
    unwrapOps_ = 0;
    attestations_ = 0;
    totalFailures_ = 0;
    for (int i = 0; i < 8; ++i) totalByType_[i] = 0;
    for (int i = 0; i < 4; ++i) totalByBackend_[i] = 0;
    for (int i = 0; i < 7; ++i) totalByState_[i] = 0;
    for (int i = 0; i < 4; ++i) totalBySecurityLevel_[i] = 0;
}

std::vector<KeyOperationRecord> KeyStoreManager::getHistory() const {
    return history_;
}

KeyStoreResult KeyStoreManager::clearHistory() {
    if (!initialized_) return KeyStoreResult::NOT_INITIALIZED;
    history_.clear();
    return KeyStoreResult::SUCCESS;
}

// ============================================================
// Purpose bitmask helpers
// ============================================================

uint8_t KeyStoreManager::purposeToBit(KeyPurpose purpose) {
    return static_cast<uint8_t>(1u << static_cast<int>(purpose));
}

bool KeyStoreManager::hasPurpose(uint8_t bitmask, KeyPurpose purpose) {
    return (bitmask & purposeToBit(purpose)) != 0;
}

std::string KeyStoreManager::purposeBitmaskToString(uint8_t bitmask) {
    std::vector<std::string> parts;
    KeyPurpose purposes[] = {KeyPurpose::ENCRYPT, KeyPurpose::DECRYPT, KeyPurpose::SIGN,
                             KeyPurpose::VERIFY, KeyPurpose::WRAP, KeyPurpose::UNWRAP,
                             KeyPurpose::DERIVE, KeyPurpose::ATTEST};
    for (auto p : purposes) {
        if (hasPurpose(bitmask, p)) {
            parts.push_back(keyPurposeToString(p));
        }
    }
    std::ostringstream oss;
    for (size_t i = 0; i < parts.size(); ++i) {
        if (i > 0) oss << "|";
        oss << parts[i];
    }
    return oss.str();
}

// ============================================================
// String helpers
// ============================================================

const char* KeyStoreManager::keyTypeToString(KeyType type) {
    switch (type) {
        case KeyType::AES_128:        return "AES_128";
        case KeyType::AES_256:        return "AES_256";
        case KeyType::RSA_2048:       return "RSA_2048";
        case KeyType::RSA_4096:       return "RSA_4096";
        case KeyType::ECDSA_P256:     return "ECDSA_P256";
        case KeyType::HMAC_SHA256:    return "HMAC_SHA256";
        case KeyType::DERIVED_SECRET: return "DERIVED_SECRET";
        case KeyType::RAW_SECRET:     return "RAW_SECRET";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::keyPurposeToString(KeyPurpose purpose) {
    switch (purpose) {
        case KeyPurpose::ENCRYPT: return "ENCRYPT";
        case KeyPurpose::DECRYPT: return "DECRYPT";
        case KeyPurpose::SIGN:    return "SIGN";
        case KeyPurpose::VERIFY:  return "VERIFY";
        case KeyPurpose::WRAP:    return "WRAP";
        case KeyPurpose::UNWRAP:  return "UNWRAP";
        case KeyPurpose::DERIVE:  return "DERIVE";
        case KeyPurpose::ATTEST:  return "ATTEST";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::keyStateToString(KeyState state) {
    switch (state) {
        case KeyState::ACTIVE:      return "ACTIVE";
        case KeyState::DISABLED:    return "DISABLED";
        case KeyState::EXPIRED:     return "EXPIRED";
        case KeyState::REVOKED:     return "REVOKED";
        case KeyState::ROTATED:     return "ROTATED";
        case KeyState::DESTROYED:   return "DESTROYED";
        case KeyState::COMPROMISED: return "COMPROMISED";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::storageBackendToString(StorageBackend backend) {
    switch (backend) {
        case StorageBackend::MEMORY:               return "MEMORY";
        case StorageBackend::SECURE_STORAGE_STUB:  return "SECURE_STORAGE_STUB";
        case StorageBackend::HARDWARE_BACKED_STUB: return "HARDWARE_BACKED_STUB";
        case StorageBackend::BACKUP_BLOB:          return "BACKUP_BLOB";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::cryptoAlgorithmToString(CryptoAlgorithm algo) {
    switch (algo) {
        case CryptoAlgorithm::AES_GCM_STUB:       return "AES_GCM_STUB";
        case CryptoAlgorithm::AES_CBC_STUB:       return "AES_CBC_STUB";
        case CryptoAlgorithm::RSA_OAEP_STUB:      return "RSA_OAEP_STUB";
        case CryptoAlgorithm::ECDSA_P256_STUB:    return "ECDSA_P256_STUB";
        case CryptoAlgorithm::HMAC_SHA256_STUB:   return "HMAC_SHA256_STUB";
        case CryptoAlgorithm::PBKDF2_SHA256_STUB: return "PBKDF2_SHA256_STUB";
        case CryptoAlgorithm::HKDF_SHA256_STUB:   return "HKDF_SHA256_STUB";
        case CryptoAlgorithm::FNV1A_MAC_STUB:     return "FNV1A_MAC_STUB";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::securityLevelToString(SecurityLevel level) {
    switch (level) {
        case SecurityLevel::SOFTWARE:             return "SOFTWARE";
        case SecurityLevel::SECURE_STORAGE:       return "SECURE_STORAGE";
        case SecurityLevel::HARDWARE_BACKED_STUB: return "HARDWARE_BACKED_STUB";
        case SecurityLevel::SECURE_ENCLAVE_STUB:  return "SECURE_ENCLAVE_STUB";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::accessScopeToString(AccessScope scope) {
    switch (scope) {
        case AccessScope::SYSTEM_ONLY:   return "SYSTEM_ONLY";
        case AccessScope::APP_PRIVATE:   return "APP_PRIVATE";
        case AccessScope::SHARED_APPS:   return "SHARED_APPS";
        case AccessScope::RECOVERY_ONLY: return "RECOVERY_ONLY";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::certificateStateToString(CertificateState state) {
    switch (state) {
        case CertificateState::VALID:     return "VALID";
        case CertificateState::EXPIRED:   return "EXPIRED";
        case CertificateState::REVOKED:   return "REVOKED";
        case CertificateState::UNTRUSTED: return "UNTRUSTED";
    }
    return "UNKNOWN";
}

const char* KeyStoreManager::keyStoreResultToString(KeyStoreResult result) {
    switch (result) {
        case KeyStoreResult::SUCCESS:               return "SUCCESS";
        case KeyStoreResult::NOT_INITIALIZED:       return "NOT_INITIALIZED";
        case KeyStoreResult::ALREADY_INITIALIZED:   return "ALREADY_INITIALIZED";
        case KeyStoreResult::KEY_NOT_FOUND:         return "KEY_NOT_FOUND";
        case KeyStoreResult::KEY_EXISTS:            return "KEY_EXISTS";
        case KeyStoreResult::INVALID_KEY_ID:        return "INVALID_KEY_ID";
        case KeyStoreResult::INVALID_ALIAS:         return "INVALID_ALIAS";
        case KeyStoreResult::INVALID_PARAMETER:     return "INVALID_PARAMETER";
        case KeyStoreResult::BAD_STATE:             return "BAD_STATE";
        case KeyStoreResult::PERMISSION_DENIED:     return "PERMISSION_DENIED";
        case KeyStoreResult::PURPOSE_NOT_ALLOWED:   return "PURPOSE_NOT_ALLOWED";
        case KeyStoreResult::ALGORITHM_MISMATCH:    return "ALGORITHM_MISMATCH";
        case KeyStoreResult::UNSUPPORTED_KEY_TYPE:  return "UNSUPPORTED_KEY_TYPE";
        case KeyStoreResult::UNSUPPORTED_ALGORITHM: return "UNSUPPORTED_ALGORITHM";
        case KeyStoreResult::STORAGE_FULL:          return "STORAGE_FULL";
        case KeyStoreResult::KEY_EXPIRED:           return "KEY_EXPIRED";
        case KeyStoreResult::KEY_REVOKED:           return "KEY_REVOKED";
        case KeyStoreResult::KEY_DISABLED:          return "KEY_DISABLED";
        case KeyStoreResult::EXPORT_DENIED:         return "EXPORT_DENIED";
        case KeyStoreResult::IMPORT_FAILED:         return "IMPORT_FAILED";
        case KeyStoreResult::CRYPTO_FAILED:         return "CRYPTO_FAILED";
        case KeyStoreResult::VERIFICATION_FAILED:   return "VERIFICATION_FAILED";
        case KeyStoreResult::ATTESTATION_FAILED:    return "ATTESTATION_FAILED";
        case KeyStoreResult::CERTIFICATE_NOT_FOUND: return "CERTIFICATE_NOT_FOUND";
        case KeyStoreResult::HARDWARE_UNAVAILABLE:  return "HARDWARE_UNAVAILABLE";
    }
    return "UNKNOWN";
}

KeyType KeyStoreManager::stringToKeyType(const std::string& str) {
    if (str == "AES_128")        return KeyType::AES_128;
    if (str == "AES_256")        return KeyType::AES_256;
    if (str == "RSA_2048")       return KeyType::RSA_2048;
    if (str == "RSA_4096")       return KeyType::RSA_4096;
    if (str == "ECDSA_P256")     return KeyType::ECDSA_P256;
    if (str == "HMAC_SHA256")    return KeyType::HMAC_SHA256;
    if (str == "DERIVED_SECRET") return KeyType::DERIVED_SECRET;
    if (str == "RAW_SECRET")     return KeyType::RAW_SECRET;
    return KeyType::AES_256;
}

KeyPurpose KeyStoreManager::stringToKeyPurpose(const std::string& str) {
    if (str == "ENCRYPT") return KeyPurpose::ENCRYPT;
    if (str == "DECRYPT") return KeyPurpose::DECRYPT;
    if (str == "SIGN")    return KeyPurpose::SIGN;
    if (str == "VERIFY")  return KeyPurpose::VERIFY;
    if (str == "WRAP")    return KeyPurpose::WRAP;
    if (str == "UNWRAP")  return KeyPurpose::UNWRAP;
    if (str == "DERIVE")  return KeyPurpose::DERIVE;
    if (str == "ATTEST")  return KeyPurpose::ATTEST;
    return KeyPurpose::ENCRYPT;
}

KeyState KeyStoreManager::stringToKeyState(const std::string& str) {
    if (str == "ACTIVE")      return KeyState::ACTIVE;
    if (str == "DISABLED")    return KeyState::DISABLED;
    if (str == "EXPIRED")     return KeyState::EXPIRED;
    if (str == "REVOKED")     return KeyState::REVOKED;
    if (str == "ROTATED")     return KeyState::ROTATED;
    if (str == "DESTROYED")   return KeyState::DESTROYED;
    if (str == "COMPROMISED") return KeyState::COMPROMISED;
    return KeyState::ACTIVE;
}

StorageBackend KeyStoreManager::stringToStorageBackend(const std::string& str) {
    if (str == "MEMORY")               return StorageBackend::MEMORY;
    if (str == "SECURE_STORAGE_STUB")  return StorageBackend::SECURE_STORAGE_STUB;
    if (str == "HARDWARE_BACKED_STUB") return StorageBackend::HARDWARE_BACKED_STUB;
    if (str == "BACKUP_BLOB")          return StorageBackend::BACKUP_BLOB;
    return StorageBackend::MEMORY;
}

CryptoAlgorithm KeyStoreManager::stringToCryptoAlgorithm(const std::string& str) {
    if (str == "AES_GCM_STUB")       return CryptoAlgorithm::AES_GCM_STUB;
    if (str == "AES_CBC_STUB")       return CryptoAlgorithm::AES_CBC_STUB;
    if (str == "RSA_OAEP_STUB")      return CryptoAlgorithm::RSA_OAEP_STUB;
    if (str == "ECDSA_P256_STUB")    return CryptoAlgorithm::ECDSA_P256_STUB;
    if (str == "HMAC_SHA256_STUB")   return CryptoAlgorithm::HMAC_SHA256_STUB;
    if (str == "PBKDF2_SHA256_STUB") return CryptoAlgorithm::PBKDF2_SHA256_STUB;
    if (str == "HKDF_SHA256_STUB")   return CryptoAlgorithm::HKDF_SHA256_STUB;
    if (str == "FNV1A_MAC_STUB")     return CryptoAlgorithm::FNV1A_MAC_STUB;
    return CryptoAlgorithm::AES_GCM_STUB;
}

}  // namespace phantom::keystore
