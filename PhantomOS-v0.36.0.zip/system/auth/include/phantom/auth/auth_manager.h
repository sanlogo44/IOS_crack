/*
 * Phantom OS - Device Lock / Authentication Manager
 * Credential enrollment, device lock, authentication, sessions, recovery
 *
 * v0.24.0
 * License: GPL-3.0
 *
 * All authentication and cryptographic operations are simulated stubs
 * (FNV-1a based) for prototype use. No real biometry is implemented;
 * BIOMETRIC_STUB is a placeholder. Secrets are never stored in plaintext.
 */

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <chrono>

// Forward declarations for optional integrations
namespace phantom::logging {
class LogServer;
}
namespace phantom::crashreporter {
class CrashReporter;
}

namespace phantom::auth {

// ============================================================
// Enums
// ============================================================

enum class AuthMethod {
    PIN,             // Numeric PIN (4-8 digits)
    PASSWORD,        // Alphanumeric password
    PATTERN,         // Grid pattern (simulated)
    BIOMETRIC_STUB,  // Biometric (Face ID / fingerprint, simulated)
    RECOVERY_KEY,    // Long recovery key for lockout bypass
    TRUSTED_SESSION  // Already-authenticated session token
};

enum class LockState {
    UNCONFIGURED,     // No credential enrolled yet
    UNLOCKED,         // Device is unlocked
    LOCKED,           // Device is locked, awaiting authentication
    AUTHENTICATING,   // Authentication in progress (transient)
    TEMP_LOCKED,      // Temporarily locked out after failed attempts
    RECOVERY_REQUIRED,// Too many failures, recovery key required
    DISABLED          // Locking disabled (developer mode)
};

enum class AuthResult {
    SUCCESS,
    NOT_INITIALIZED,
    ALREADY_INITIALIZED,
    INVALID_CREDENTIAL,
    LOCKED_OUT,
    NO_CREDENTIAL_CONFIGURED,
    CREDENTIAL_NOT_FOUND,
    CREDENTIAL_EXISTS,
    CREDENTIAL_DISABLED,
    CREDENTIAL_EXPIRED,
    INVALID_PARAMETER,
    BAD_STATE,
    PERMISSION_DENIED,
    RATE_LIMITED,
    METHOD_NOT_ENROLLED,
    SESSION_NOT_FOUND,
    SESSION_EXPIRED,
    SESSION_INVALID,
    RECOVERY_NOT_AVAILABLE,
    OPERATION_FAILED
};

enum class SessionState {
    ACTIVE,   // Token is valid and usable
    EXPIRED,  // Past expiration
    REVOKED   // Explicitly revoked
};

enum class CredentialState {
    ACTIVE,      // Credential is usable
    DISABLED,     // Temporarily disabled
    EXPIRED,      // Past expiration
    COMPROMISED,  // Marked compromised, unusable
    ROTATED       // Superseded by a rotation
};

enum class AuthEventType {
    LOCK,                    // Device locked
    UNLOCK,                  // Device unlocked
    AUTH_SUCCESS,            // Successful authentication
    AUTH_FAILURE,            // Failed authentication attempt
    LOCKOUT,                 // Temporary lockout triggered
    METHOD_ENROLLED,         // Credential method enrolled
    METHOD_REMOVED,          // Credential method removed
    SESSION_CREATED,         // Session token created
    SESSION_REVOKED,         // Session token revoked
    RECOVERY_KEY_GENERATED    // Recovery key generated
};

// ============================================================
// Structs
// ============================================================

struct CredentialPolicy {
    size_t minLength = 4;              // Minimum secret length
    size_t maxLength = 128;             // Maximum secret length
    uint32_t maxAttempts = 5;           // Failed attempts before lockout
    uint64_t lockoutDurationMs = 30000; // Lockout duration in ms
    bool requireDigitsOnly = false;     // PIN: digits only
    bool requireAlphanumeric = false;   // Password: letters and digits
    uint64_t expiresAt = 0;             // Expiration timestamp (0 = never)
    bool allowBiometric = true;         // Biometric stub allowed
};

struct AuthCredential {
    uint64_t id = 0;
    std::string owner;                  // Owning app or "system"
    AuthMethod method = AuthMethod::PIN;
    CredentialState state = CredentialState::ACTIVE;
    uint32_t version = 1;
    uint64_t createdAt = 0;
    uint64_t lastUsedAt = 0;
    uint64_t useCount = 0;
    CredentialPolicy policy;
    // Internal (never exposed via API): hashed secret
    uint64_t secretHash = 0;
    uint64_t secretSalt = 0;
};

struct AuthSession {
    uint64_t token = 0;
    std::string owner;
    AuthMethod method = AuthMethod::PIN;
    SessionState state = SessionState::ACTIVE;
    uint64_t createdAt = 0;
    uint64_t expiresAt = 0;
    uint64_t lastUsedAt = 0;
};

struct AuthEvent {
    uint64_t id = 0;
    AuthEventType type = AuthEventType::LOCK;
    AuthMethod method = AuthMethod::PIN;
    AuthResult result = AuthResult::SUCCESS;
    std::string owner;
    std::string detail;
    uint64_t timestamp = 0;
};

struct AuthManagerStats {
    uint64_t totalCredentials = 0;
    uint64_t credentialsEnrolled = 0;
    uint64_t credentialsRemoved = 0;
    uint64_t credentialsRotated = 0;
    uint64_t credentialsDisabled = 0;
    uint64_t totalAuthAttempts = 0;
    uint64_t successfulAuths = 0;
    uint64_t failedAuths = 0;
    uint64_t lockouts = 0;
    uint64_t unlockCount = 0;
    uint64_t lockCount = 0;
    uint64_t sessionsCreated = 0;
    uint64_t sessionsRevoked = 0;
    uint64_t sessionsExpired = 0;
    uint64_t recoveryKeysGenerated = 0;
    uint64_t recoveryUnlocks = 0;
    uint64_t totalFailures = 0;
    uint64_t byMethod[6] = {};       // Per AuthMethod attempts
    uint64_t byResult[20] = {};      // Per AuthResult
    uint64_t byEventType[10] = {};   // Per AuthEventType
};

// ============================================================
// AuthManager - Device lock and authentication service
// ============================================================

class AuthManager {
public:
    AuthManager() = default;
    ~AuthManager() { shutdown(); }

    // Lifecycle
    AuthResult initialize(size_t maxCredentials = 16, size_t maxSessions = 64,
                          size_t maxEvents = 500, size_t maxHistory = 500);
    AuthResult shutdown();
    bool isInitialized() const { return initialized_; }
    size_t getMaxCredentials() const { return maxCredentials_; }
    size_t getMaxSessions() const { return maxSessions_; }
    size_t getMaxEvents() const { return maxEvents_; }
    size_t getMaxHistory() const { return maxHistory_; }

    // Optional integrations
    void setLogServer(phantom::logging::LogServer* server) { logServer_ = server; }
    phantom::logging::LogServer* getLogServer() const { return logServer_; }
    void setCrashReporter(phantom::crashreporter::CrashReporter* reporter) { crashReporter_ = reporter; }
    phantom::crashreporter::CrashReporter* getCrashReporter() const { return crashReporter_; }

    // Test hooks
    void setFailNextAuth(bool fail) { failNextAuth_ = fail; }
    bool getFailNextAuth() const { return failNextAuth_; }
    void setCurrentTimeForTesting(uint64_t ms) { timeOverrideMs_ = ms; }
    void clearTimeOverride() { timeOverrideMs_ = 0; }

    // Lock control
    AuthResult lockDevice(const std::string& owner);
    AuthResult unlockDevice(uint64_t sessionToken, const std::string& owner);
    LockState getLockState() const { return lockState_; }
    bool isLocked() const;
    AuthResult setLockDisabled(bool disabled, const std::string& owner);
    AuthResult setAutoLockTimeout(uint64_t timeoutMs, const std::string& owner);
    uint64_t getAutoLockTimeout() const { return autoLockTimeoutMs_; }
    bool shouldAutoLock(uint64_t lastActivityMs) const;

    // Credential enrollment
    AuthResult enrollCredential(AuthMethod method, const std::string& secret,
                                 const std::string& owner,
                                 const CredentialPolicy& policy = CredentialPolicy());
    AuthResult changeCredential(AuthMethod method, const std::string& oldSecret,
                                const std::string& newSecret, const std::string& owner);
    AuthResult removeCredential(AuthMethod method, const std::string& owner);
    bool hasCredential(AuthMethod method, const std::string& owner) const;
    AuthCredential getCredentialInfo(AuthMethod method, const std::string& owner) const;
    std::vector<AuthCredential> listCredentials() const;
    std::vector<AuthCredential> getCredentialsByOwner(const std::string& owner) const;
    AuthResult disableCredential(AuthMethod method, const std::string& owner);
    AuthResult enableCredential(AuthMethod method, const std::string& owner);
    AuthResult markCredentialCompromised(AuthMethod method, const std::string& owner);

    // Authentication
    AuthResult authenticate(AuthMethod method, const std::string& secret,
                            const std::string& owner,
                            uint64_t* outSessionToken = nullptr);
    uint32_t getFailedAttempts(const std::string& owner, AuthMethod method) const;
    uint64_t getLockoutUntil(const std::string& owner, AuthMethod method) const;
    AuthResult resetFailedAttempts(const std::string& owner, AuthMethod method,
                                   const std::string& systemOwner);

    // Sessions
    AuthResult validateSession(uint64_t token, const std::string& owner);
    AuthSession getSession(uint64_t token) const;
    AuthResult revokeSession(uint64_t token);
    AuthResult revokeAllSessions(const std::string& owner);
    AuthResult refreshSession(uint64_t token, uint64_t extendMs);
    size_t getActiveSessionCount() const;
    size_t processExpiredSessions();

    // Recovery
    std::string generateRecoveryKey(const std::string& owner);
    AuthResult authenticateWithRecoveryKey(const std::string& recoveryKey,
                                           const std::string& owner);
    bool isRecoveryAvailable() const;

    // Events, stats and history
    std::vector<AuthEvent> getEvents(size_t limit = 0) const;
    std::vector<AuthEvent> getEventsByType(AuthEventType type, size_t limit = 0) const;
    AuthResult clearEvents();
    AuthManagerStats getStats() const;
    void resetStats();

    // Callbacks
    using LockStateCallback = std::function<void(LockState oldState, LockState newState)>;
    using AuthEventCallback = std::function<void(const AuthEvent&)>;
    void setLockStateCallback(LockStateCallback cb) { lockStateCb_ = cb; }
    void setAuthEventCallback(AuthEventCallback cb) { authEventCb_ = cb; }

    // String helpers
    static const char* authMethodToString(AuthMethod method);
    static const char* lockStateToString(LockState state);
    static const char* authResultToString(AuthResult result);
    static const char* sessionStateToString(SessionState state);
    static const char* credentialStateToString(CredentialState state);
    static const char* authEventTypeToString(AuthEventType type);
    static AuthMethod stringToAuthMethod(const std::string& str);
    static LockState stringToLockState(const std::string& str);
    static AuthResult stringToAuthResult(const std::string& str);

private:
    bool initialized_ = false;
    size_t maxCredentials_ = 16;
    size_t maxSessions_ = 64;
    size_t maxEvents_ = 500;
    size_t maxHistory_ = 500;
    uint64_t nextCredentialId_ = 1;
    uint64_t nextSessionToken_ = 1000;
    uint64_t nextEventId_ = 1;

    LockState lockState_ = LockState::UNCONFIGURED;
    uint64_t autoLockTimeoutMs_ = 0;  // 0 = disabled

    std::map<uint64_t, AuthCredential> credentials_;
    std::map<uint64_t, AuthSession> sessions_;
    std::vector<AuthEvent> events_;
    std::vector<AuthEvent> history_;

    // Per owner+method failure tracking
    struct FailureTracker {
        uint32_t failedAttempts = 0;
        uint64_t lockoutUntil = 0;
    };
    std::map<std::string, FailureTracker> failures_;
    std::map<std::string, uint64_t> ownerLockouts_;  // Cumulative lockouts per owner

    bool failNextAuth_ = false;
    uint64_t timeOverrideMs_ = 0;

    phantom::logging::LogServer* logServer_ = nullptr;
    phantom::crashreporter::CrashReporter* crashReporter_ = nullptr;

    LockStateCallback lockStateCb_;
    AuthEventCallback authEventCb_;

    // Stats
    uint64_t credentialsEnrolled_ = 0;
    uint64_t credentialsRemoved_ = 0;
    uint64_t credentialsRotated_ = 0;
    uint64_t credentialsDisabled_ = 0;
    uint64_t totalAuthAttempts_ = 0;
    uint64_t successfulAuths_ = 0;
    uint64_t failedAuths_ = 0;
    uint64_t lockouts_ = 0;
    uint64_t unlockCount_ = 0;
    uint64_t lockCount_ = 0;
    uint64_t sessionsCreated_ = 0;
    uint64_t sessionsRevoked_ = 0;
    uint64_t sessionsExpired_ = 0;
    uint64_t recoveryKeysGenerated_ = 0;
    uint64_t recoveryUnlocks_ = 0;
    uint64_t totalFailures_ = 0;
    uint64_t byMethod_[6] = {};
    uint64_t byResult_[20] = {};
    uint64_t byEventType_[10] = {};

    // Helpers
    uint64_t getCurrentTimeMs() const;
    void logToServer(const std::string& level, const std::string& message) const;
    void notifyCrashReporter(const std::string& appId, const std::string& message) const;
    uint64_t computeFNV1a(const std::string& data) const;
    uint64_t hashSecret(const std::string& secret, uint64_t salt) const;
    static std::string failureKey(const std::string& owner, AuthMethod method);
    void changeLockState(LockState newState);
    void recordEvent(AuthEventType type, AuthMethod method, AuthResult result,
                     const std::string& owner, const std::string& detail);
    void moveToHistory(const AuthEvent& event);
    AuthCredential* findCredential(AuthMethod method, const std::string& owner);
    const AuthCredential* findCredential(AuthMethod method, const std::string& owner) const;
    AuthResult validateSecret(const CredentialPolicy& policy, AuthMethod method,
                              const std::string& secret) const;
    bool isSystemOwner(const std::string& owner) const;
    uint64_t createSessionInternal(const std::string& owner, AuthMethod method,
                                   uint64_t durationMs);
};

}  // namespace phantom::auth
