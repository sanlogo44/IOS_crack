/*
 * Phantom OS - Device Lock / Authentication Manager Implementation
 *
 * v0.24.0
 * License: GPL-3.0
 *
 * All authentication operations are simulated stubs (FNV-1a based) for
 * prototype purposes. Secrets are stored hashed (FNV-1a + per-credential
 * salt), never in plaintext. BIOMETRIC_STUB simulates biometric auth.
 */

#include "phantom/auth/auth_manager.h"
#include "phantom/logging/log_server.h"
#include "phantom/crashreporter/crash_reporter.h"

#include <algorithm>
#include <sstream>
#include <cstring>
#include <cstdio>

namespace phantom::auth {

// FNV-1a constants (matching project convention)
static constexpr uint64_t FNV_OFFSET_BASIS = 14695981039346656037ULL;
static constexpr uint64_t FNV_PRIME = 1099511628211ULL;

// Session defaults
static constexpr uint64_t DEFAULT_SESSION_DURATION_MS = 300000;  // 5 minutes

// Recovery key alphabet
static const char RECOVERY_ALPHABET[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
static constexpr size_t RECOVERY_ALPHABET_LEN = 31;
static constexpr size_t RECOVERY_GROUPS = 8;
static constexpr size_t RECOVERY_GROUP_LEN = 4;

// ============================================================
// Helpers
// ============================================================

uint64_t AuthManager::getCurrentTimeMs() const {
    if (timeOverrideMs_ != 0) {
        return timeOverrideMs_;
    }
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

void AuthManager::logToServer(const std::string& level, const std::string& message) const {
    if (logServer_) {
        if (level == "error") {
            logServer_->logError(phantom::logging::LogSource::SYSTEM_SERVER, message, "AuthManager");
        } else if (level == "warn") {
            logServer_->logWarn(phantom::logging::LogSource::SYSTEM_SERVER, message, "AuthManager");
        } else {
            logServer_->logInfo(phantom::logging::LogSource::SYSTEM_SERVER, message, "AuthManager");
        }
    }
}

void AuthManager::notifyCrashReporter(const std::string& appId, const std::string& message) const {
    if (crashReporter_) {
        crashReporter_->captureAnr(appId, "auth_manager", 0, message);
    }
}

uint64_t AuthManager::computeFNV1a(const std::string& data) const {
    uint64_t hash = FNV_OFFSET_BASIS;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    return hash;
}

uint64_t AuthManager::hashSecret(const std::string& secret, uint64_t salt) const {
    // Salted FNV-1a: combine salt into the hash state
    uint64_t hash = FNV_OFFSET_BASIS ^ salt;
    for (unsigned char c : secret) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    // Second pass over the salt string for avalanche
    std::string saltStr = std::to_string(salt);
    for (unsigned char c : saltStr) {
        hash ^= c;
        hash *= FNV_PRIME;
    }
    return hash;
}

std::string AuthManager::failureKey(const std::string& owner, AuthMethod method) {
    return owner + "/" + std::to_string(static_cast<int>(method));
}

void AuthManager::changeLockState(LockState newState) {
    if (lockState_ == newState) {
        return;
    }
    LockState old = lockState_;
    lockState_ = newState;
    if (lockStateCb_) {
        lockStateCb_(old, newState);
    }
}

void AuthManager::recordEvent(AuthEventType type, AuthMethod method, AuthResult result,
                              const std::string& owner, const std::string& detail) {
    AuthEvent event;
    event.id = nextEventId_++;
    event.type = type;
    event.method = method;
    event.result = result;
    event.owner = owner;
    event.detail = detail;
    event.timestamp = getCurrentTimeMs();

    events_.push_back(event);
    if (events_.size() > maxEvents_) {
        events_.erase(events_.begin());
    }
    byEventType_[static_cast<size_t>(type)]++;

    if (authEventCb_) {
        authEventCb_(event);
    }
}

void AuthManager::moveToHistory(const AuthEvent& event) {
    history_.push_back(event);
    if (history_.size() > maxHistory_) {
        history_.erase(history_.begin());
    }
}

AuthCredential* AuthManager::findCredential(AuthMethod method, const std::string& owner) {
    for (auto& pair : credentials_) {
        if (pair.second.method == method && pair.second.owner == owner) {
            return &pair.second;
        }
    }
    return nullptr;
}

const AuthCredential* AuthManager::findCredential(AuthMethod method, const std::string& owner) const {
    for (const auto& pair : credentials_) {
        if (pair.second.method == method && pair.second.owner == owner) {
            return &pair.second;
        }
    }
    return nullptr;
}

bool AuthManager::isSystemOwner(const std::string& owner) const {
    return owner == "system" || owner == "phantos.system";
}

uint64_t AuthManager::createSessionInternal(const std::string& owner, AuthMethod method,
                                            uint64_t durationMs) {
    uint64_t now = getCurrentTimeMs();
    AuthSession session;
    session.token = nextSessionToken_++;
    session.owner = owner;
    session.method = method;
    session.state = SessionState::ACTIVE;
    session.createdAt = now;
    session.expiresAt = now + durationMs;
    session.lastUsedAt = now;
    sessions_[session.token] = session;
    sessionsCreated_++;
    recordEvent(AuthEventType::SESSION_CREATED, method, AuthResult::SUCCESS, owner,
                "Session created");
    if (sessions_.size() > maxSessions_) {
        // Revoke the oldest session
        uint64_t oldestToken = 0;
        uint64_t oldestTime = UINT64_MAX;
        for (const auto& pair : sessions_) {
            if (pair.second.createdAt < oldestTime) {
                oldestTime = pair.second.createdAt;
                oldestToken = pair.first;
            }
        }
        if (oldestToken != 0) {
            sessions_[oldestToken].state = SessionState::REVOKED;
            sessionsRevoked_++;
            sessions_.erase(oldestToken);
        }
    }
    return session.token;
}

// ============================================================
// Lifecycle
// ============================================================

AuthResult AuthManager::initialize(size_t maxCredentials, size_t maxSessions,
                                    size_t maxEvents, size_t maxHistory) {
    if (initialized_) {
        return AuthResult::ALREADY_INITIALIZED;
    }
    if (maxCredentials == 0 || maxSessions == 0 || maxEvents == 0 || maxHistory == 0) {
        return AuthResult::INVALID_PARAMETER;
    }
    maxCredentials_ = maxCredentials;
    maxSessions_ = maxSessions;
    maxEvents_ = maxEvents;
    maxHistory_ = maxHistory;
    initialized_ = true;
    lockState_ = LockState::UNCONFIGURED;
    logToServer("info", "AuthManager initialized (maxCredentials=" +
                        std::to_string(maxCredentials) + ")");
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::shutdown() {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    credentials_.clear();
    sessions_.clear();
    events_.clear();
    history_.clear();
    failures_.clear();
    ownerLockouts_.clear();
    lockState_ = LockState::UNCONFIGURED;
    initialized_ = false;
    logToServer("info", "AuthManager shut down");
    return AuthResult::SUCCESS;
}

// ============================================================
// Lock control
// ============================================================

AuthResult AuthManager::lockDevice(const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (lockState_ == LockState::DISABLED) {
        return AuthResult::BAD_STATE;
    }
    if (lockState_ == LockState::UNCONFIGURED) {
        return AuthResult::NO_CREDENTIAL_CONFIGURED;
    }
    if (lockState_ == LockState::LOCKED || lockState_ == LockState::TEMP_LOCKED ||
        lockState_ == LockState::RECOVERY_REQUIRED) {
        return AuthResult::BAD_STATE;  // Already locked
    }
    changeLockState(LockState::LOCKED);
    lockCount_++;
    recordEvent(AuthEventType::LOCK, AuthMethod::PIN, AuthResult::SUCCESS, owner, "Device locked");
    logToServer("info", "Device locked");
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::unlockDevice(uint64_t sessionToken, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    auto it = sessions_.find(sessionToken);
    if (it == sessions_.end()) {
        return AuthResult::SESSION_NOT_FOUND;
    }
    AuthSession& session = it->second;
    if (session.state == SessionState::REVOKED) {
        return AuthResult::SESSION_INVALID;
    }
    if (session.state == SessionState::EXPIRED ||
        (session.expiresAt != 0 && getCurrentTimeMs() > session.expiresAt)) {
        session.state = SessionState::EXPIRED;
        return AuthResult::SESSION_EXPIRED;
    }
    if (!owner.empty() && session.owner != owner) {
        return AuthResult::PERMISSION_DENIED;
    }
    if (lockState_ != LockState::LOCKED && lockState_ != LockState::TEMP_LOCKED &&
        lockState_ != LockState::RECOVERY_REQUIRED) {
        return AuthResult::BAD_STATE;
    }
    session.lastUsedAt = getCurrentTimeMs();
    changeLockState(LockState::UNLOCKED);
    unlockCount_++;
    recordEvent(AuthEventType::UNLOCK, session.method, AuthResult::SUCCESS,
                session.owner, "Device unlocked via session");
    logToServer("info", "Device unlocked via trusted session");
    return AuthResult::SUCCESS;
}

bool AuthManager::isLocked() const {
    return lockState_ == LockState::LOCKED || lockState_ == LockState::TEMP_LOCKED ||
           lockState_ == LockState::RECOVERY_REQUIRED;
}

AuthResult AuthManager::setLockDisabled(bool disabled, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return AuthResult::PERMISSION_DENIED;
    }
    if (disabled) {
        changeLockState(LockState::DISABLED);
    } else {
        // Re-enable: locked if credentials exist, else unconfigured
        if (credentials_.empty()) {
            changeLockState(LockState::UNCONFIGURED);
        } else {
            changeLockState(LockState::LOCKED);
        }
    }
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::setAutoLockTimeout(uint64_t timeoutMs, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(owner)) {
        return AuthResult::PERMISSION_DENIED;
    }
    autoLockTimeoutMs_ = timeoutMs;
    return AuthResult::SUCCESS;
}

bool AuthManager::shouldAutoLock(uint64_t lastActivityMs) const {
    if (autoLockTimeoutMs_ == 0) {
        return false;
    }
    if (lockState_ != LockState::UNLOCKED) {
        return false;
    }
    return (getCurrentTimeMs() - lastActivityMs) >= autoLockTimeoutMs_;
}

// ============================================================
// Credential enrollment
// ============================================================

AuthResult AuthManager::validateSecret(const CredentialPolicy& policy, AuthMethod method,
                                        const std::string& secret) const {
    if (secret.empty()) {
        return AuthResult::INVALID_PARAMETER;
    }
    if (secret.size() < policy.minLength) {
        return AuthResult::INVALID_PARAMETER;
    }
    if (secret.size() > policy.maxLength) {
        return AuthResult::INVALID_PARAMETER;
    }
    if (policy.requireDigitsOnly) {
        for (char c : secret) {
            if (c < '0' || c > '9') {
                return AuthResult::INVALID_PARAMETER;
            }
        }
    }
    if (policy.requireAlphanumeric) {
        bool hasLetter = false;
        bool hasDigit = false;
        for (char c : secret) {
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                hasLetter = true;
            } else if (c >= '0' && c <= '9') {
                hasDigit = true;
            }
        }
        if (!hasLetter || !hasDigit) {
            return AuthResult::INVALID_PARAMETER;
        }
    }
    if (method == AuthMethod::BIOMETRIC_STUB && !policy.allowBiometric) {
        return AuthResult::INVALID_PARAMETER;
    }
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::enrollCredential(AuthMethod method, const std::string& secret,
                                          const std::string& owner,
                                          const CredentialPolicy& policy) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (owner.empty()) {
        return AuthResult::INVALID_PARAMETER;
    }
    if (method == AuthMethod::TRUSTED_SESSION) {
        return AuthResult::INVALID_PARAMETER;  // Not enrollable
    }
    if (method == AuthMethod::RECOVERY_KEY) {
        return AuthResult::INVALID_PARAMETER;  // Use generateRecoveryKey
    }
    AuthResult valid = validateSecret(policy, method, secret);
    if (valid != AuthResult::SUCCESS) {
        totalFailures_++;
        return valid;
    }
    if (findCredential(method, owner) != nullptr) {
        return AuthResult::CREDENTIAL_EXISTS;
    }
    if (credentials_.size() >= maxCredentials_) {
        return AuthResult::RATE_LIMITED;  // Capacity limit reached
    }
    AuthCredential cred;
    cred.id = nextCredentialId_++;
    cred.owner = owner;
    cred.method = method;
    cred.state = CredentialState::ACTIVE;
    cred.version = 1;
    cred.createdAt = getCurrentTimeMs();
    cred.policy = policy;
    cred.secretSalt = cred.id * FNV_PRIME ^ getCurrentTimeMs();
    cred.secretHash = hashSecret(secret, cred.secretSalt);
    credentials_[cred.id] = cred;
    credentialsEnrolled_++;

    // First credential transitions the device out of UNCONFIGURED
    if (lockState_ == LockState::UNCONFIGURED) {
        changeLockState(LockState::UNLOCKED);
    }

    recordEvent(AuthEventType::METHOD_ENROLLED, method, AuthResult::SUCCESS, owner,
                "Credential enrolled (v1)");
    logToServer("info", std::string("Credential enrolled: ") + authMethodToString(method) +
                        " for " + owner);
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::changeCredential(AuthMethod method, const std::string& oldSecret,
                                         const std::string& newSecret, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthResult::CREDENTIAL_NOT_FOUND;
    }
    if (cred->state == CredentialState::DISABLED) {
        return AuthResult::CREDENTIAL_DISABLED;
    }
    if (cred->state == CredentialState::COMPROMISED) {
        return AuthResult::CREDENTIAL_DISABLED;
    }
    if (cred->secretHash != hashSecret(oldSecret, cred->secretSalt)) {
        totalFailures_++;
        return AuthResult::INVALID_CREDENTIAL;
    }
    AuthResult valid = validateSecret(cred->policy, method, newSecret);
    if (valid != AuthResult::SUCCESS) {
        totalFailures_++;
        return valid;
    }
    // Rotate: old credential becomes ROTATED history entry, version increments
    cred->secretSalt = cred->id * FNV_PRIME ^ getCurrentTimeMs() ^ cred->version;
    cred->secretHash = hashSecret(newSecret, cred->secretSalt);
    cred->version++;
    cred->state = CredentialState::ACTIVE;
    cred->useCount = 0;
    cred->lastUsedAt = getCurrentTimeMs();
    credentialsRotated_++;

    recordEvent(AuthEventType::METHOD_ENROLLED, method, AuthResult::SUCCESS, owner,
                "Credential changed (v" + std::to_string(cred->version) + ")");
    logToServer("info", "Credential changed");
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::removeCredential(AuthMethod method, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (method == AuthMethod::RECOVERY_KEY) {
        AuthCredential* cred = findCredential(method, owner);
        if (!cred) {
            return AuthResult::CREDENTIAL_NOT_FOUND;
        }
        credentials_.erase(cred->id);
        credentialsRemoved_++;
        recordEvent(AuthEventType::METHOD_REMOVED, method, AuthResult::SUCCESS, owner,
                    "Recovery key removed");
        return AuthResult::SUCCESS;
    }
    AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthResult::CREDENTIAL_NOT_FOUND;
    }
    // The last non-recovery credential cannot be removed while lock is armed
    size_t nonRecovery = 0;
    for (const auto& pair : credentials_) {
        if (pair.second.method != AuthMethod::RECOVERY_KEY &&
            !(pair.second.method == method && pair.second.owner == owner)) {
            nonRecovery++;
        }
    }
    if (nonRecovery == 0 && lockState_ != LockState::DISABLED) {
        return AuthResult::BAD_STATE;  // Would leave device without any credential
    }
    credentials_.erase(cred->id);
    credentialsRemoved_++;
    // Revoke sessions created with this method for this owner
    for (auto& pair : sessions_) {
        if (pair.second.owner == owner && pair.second.method == method &&
            pair.second.state == SessionState::ACTIVE) {
            pair.second.state = SessionState::REVOKED;
            sessionsRevoked_++;
        }
    }
    if (credentials_.empty() && lockState_ != LockState::DISABLED) {
        changeLockState(LockState::UNCONFIGURED);
    }
    recordEvent(AuthEventType::METHOD_REMOVED, method, AuthResult::SUCCESS, owner,
                "Credential removed");
    logToServer("info", "Credential removed");
    return AuthResult::SUCCESS;
}

bool AuthManager::hasCredential(AuthMethod method, const std::string& owner) const {
    return findCredential(method, owner) != nullptr;
}

AuthCredential AuthManager::getCredentialInfo(AuthMethod method, const std::string& owner) const {
    const AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthCredential{};
    }
    return *cred;
}

std::vector<AuthCredential> AuthManager::listCredentials() const {
    std::vector<AuthCredential> result;
    for (const auto& pair : credentials_) {
        result.push_back(pair.second);
    }
    return result;
}

std::vector<AuthCredential> AuthManager::getCredentialsByOwner(const std::string& owner) const {
    std::vector<AuthCredential> result;
    for (const auto& pair : credentials_) {
        if (pair.second.owner == owner) {
            result.push_back(pair.second);
        }
    }
    return result;
}

AuthResult AuthManager::disableCredential(AuthMethod method, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthResult::CREDENTIAL_NOT_FOUND;
    }
    if (cred->state != CredentialState::ACTIVE) {
        return AuthResult::BAD_STATE;
    }
    cred->state = CredentialState::DISABLED;
    credentialsDisabled_++;
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::enableCredential(AuthMethod method, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthResult::CREDENTIAL_NOT_FOUND;
    }
    if (cred->state != CredentialState::DISABLED) {
        return AuthResult::BAD_STATE;
    }
    cred->state = CredentialState::ACTIVE;
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::markCredentialCompromised(AuthMethod method, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        return AuthResult::CREDENTIAL_NOT_FOUND;
    }
    cred->state = CredentialState::COMPROMISED;
    // Revoke all active sessions of this owner
    for (auto& pair : sessions_) {
        if (pair.second.owner == owner && pair.second.state == SessionState::ACTIVE) {
            pair.second.state = SessionState::REVOKED;
            sessionsRevoked_++;
        }
    }
    logToServer("warn", "Credential marked compromised: " +
                        std::string(authMethodToString(method)) + " for " + owner);
    return AuthResult::SUCCESS;
}

// ============================================================
// Authentication
// ============================================================

AuthResult AuthManager::authenticate(AuthMethod method, const std::string& secret,
                                      const std::string& owner,
                                      uint64_t* outSessionToken) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    totalAuthAttempts_++;
    byMethod_[static_cast<size_t>(method)]++;

    if (lockState_ == LockState::DISABLED) {
        // Lock disabled: grant access without credential check
        if (outSessionToken) {
            *outSessionToken = createSessionInternal(owner.empty() ? "system" : owner,
                                                      AuthMethod::TRUSTED_SESSION,
                                                      DEFAULT_SESSION_DURATION_MS);
        }
        successfulAuths_++;
        byResult_[static_cast<size_t>(AuthResult::SUCCESS)]++;
        recordEvent(AuthEventType::AUTH_SUCCESS, method, AuthResult::SUCCESS, owner,
                    "Lock disabled, auto-granted");
        return AuthResult::SUCCESS;
    }

    const AuthCredential* cred = findCredential(method, owner);
    if (!cred) {
        failedAuths_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(AuthResult::METHOD_NOT_ENROLLED)]++;
        return AuthResult::METHOD_NOT_ENROLLED;
    }

    // State checks
    if (cred->state == CredentialState::DISABLED) {
        byResult_[static_cast<size_t>(AuthResult::CREDENTIAL_DISABLED)]++;
        return AuthResult::CREDENTIAL_DISABLED;
    }
    if (cred->state == CredentialState::COMPROMISED) {
        byResult_[static_cast<size_t>(AuthResult::CREDENTIAL_DISABLED)]++;
        return AuthResult::CREDENTIAL_DISABLED;
    }
    if (cred->state == CredentialState::EXPIRED ||
        (cred->policy.expiresAt != 0 && getCurrentTimeMs() > cred->policy.expiresAt)) {
        byResult_[static_cast<size_t>(AuthResult::CREDENTIAL_EXPIRED)]++;
        return AuthResult::CREDENTIAL_EXPIRED;
    }

    // Lockout checks
    const std::string fkey = failureKey(owner, method);
    auto fit = failures_.find(fkey);
    if (fit != failures_.end()) {
        if (fit->second.lockoutUntil > getCurrentTimeMs()) {
            byResult_[static_cast<size_t>(AuthResult::LOCKED_OUT)]++;
            return AuthResult::LOCKED_OUT;
        }
    }

    // Failure simulation hook
    if (failNextAuth_) {
        failNextAuth_ = false;
        failedAuths_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(AuthResult::OPERATION_FAILED)]++;
        recordEvent(AuthEventType::AUTH_FAILURE, method, AuthResult::OPERATION_FAILED, owner,
                    "Simulated failure");
        return AuthResult::OPERATION_FAILED;
    }

    // Verify secret
    if (cred->secretHash != hashSecret(secret, cred->secretSalt)) {
        failedAuths_++;
        totalFailures_++;
        byResult_[static_cast<size_t>(AuthResult::INVALID_CREDENTIAL)]++;
        recordEvent(AuthEventType::AUTH_FAILURE, method, AuthResult::INVALID_CREDENTIAL, owner,
                    "Invalid secret");

        // Update failure tracker
        FailureTracker& tracker = failures_[fkey];
        tracker.failedAttempts++;
        if (tracker.failedAttempts >= cred->policy.maxAttempts) {
            tracker.lockoutUntil = getCurrentTimeMs() + cred->policy.lockoutDurationMs;
            tracker.failedAttempts = 0;
            lockouts_++;
            ownerLockouts_[owner]++;
            changeLockState(LockState::TEMP_LOCKED);
            recordEvent(AuthEventType::LOCKOUT, method, AuthResult::LOCKED_OUT, owner,
                        "Temporary lockout triggered");
            logToServer("warn", "Lockout triggered for " + owner);
            notifyCrashReporter(owner, "auth_lockout");

            // Hard limit: repeated lockouts require recovery
            if (ownerLockouts_[owner] >= 4) {
                changeLockState(LockState::RECOVERY_REQUIRED);
                logToServer("error", "Recovery required for " + owner);
            }
        }
        return AuthResult::INVALID_CREDENTIAL;
    }

    // Success
    AuthCredential* mutableCred = findCredential(method, owner);
    mutableCred->useCount++;
    mutableCred->lastUsedAt = getCurrentTimeMs();

    // Reset failure tracking for this owner+method
    failures_.erase(fkey);

    successfulAuths_++;
    byResult_[static_cast<size_t>(AuthResult::SUCCESS)]++;

    uint64_t token = createSessionInternal(owner, method, DEFAULT_SESSION_DURATION_MS);
    if (outSessionToken) {
        *outSessionToken = token;
    }

    // Unlock the device if it was locked
    if (lockState_ == LockState::LOCKED || lockState_ == LockState::TEMP_LOCKED) {
        changeLockState(LockState::UNLOCKED);
        unlockCount_++;
    }
    recordEvent(AuthEventType::AUTH_SUCCESS, method, AuthResult::SUCCESS, owner,
                "Authenticated (v" + std::to_string(mutableCred->version) + ")");
    return AuthResult::SUCCESS;
}

uint32_t AuthManager::getFailedAttempts(const std::string& owner, AuthMethod method) const {
    auto it = failures_.find(failureKey(owner, method));
    if (it == failures_.end()) {
        return 0;
    }
    return it->second.failedAttempts;
}

uint64_t AuthManager::getLockoutUntil(const std::string& owner, AuthMethod method) const {
    auto it = failures_.find(failureKey(owner, method));
    if (it == failures_.end()) {
        return 0;
    }
    return it->second.lockoutUntil;
}

AuthResult AuthManager::resetFailedAttempts(const std::string& owner, AuthMethod method,
                                           const std::string& systemOwner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (!isSystemOwner(systemOwner)) {
        return AuthResult::PERMISSION_DENIED;
    }
    failures_.erase(failureKey(owner, method));
    if (lockState_ == LockState::TEMP_LOCKED) {
        changeLockState(LockState::LOCKED);
    }
    return AuthResult::SUCCESS;
}

// ============================================================
// Sessions
// ============================================================

AuthResult AuthManager::validateSession(uint64_t token, const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    auto it = sessions_.find(token);
    if (it == sessions_.end()) {
        return AuthResult::SESSION_NOT_FOUND;
    }
    AuthSession& session = it->second;
    if (session.state == SessionState::REVOKED) {
        return AuthResult::SESSION_INVALID;
    }
    if (session.state == SessionState::EXPIRED ||
        (session.expiresAt != 0 && getCurrentTimeMs() > session.expiresAt)) {
        if (session.state == SessionState::ACTIVE) {
            session.state = SessionState::EXPIRED;
            sessionsExpired_++;
        }
        return AuthResult::SESSION_EXPIRED;
    }
    if (!owner.empty() && session.owner != owner) {
        return AuthResult::PERMISSION_DENIED;
    }
    session.lastUsedAt = getCurrentTimeMs();
    return AuthResult::SUCCESS;
}

AuthSession AuthManager::getSession(uint64_t token) const {
    auto it = sessions_.find(token);
    if (it == sessions_.end()) {
        return AuthSession{};
    }
    return it->second;
}

AuthResult AuthManager::revokeSession(uint64_t token) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    auto it = sessions_.find(token);
    if (it == sessions_.end()) {
        return AuthResult::SESSION_NOT_FOUND;
    }
    if (it->second.state != SessionState::ACTIVE) {
        return AuthResult::BAD_STATE;
    }
    it->second.state = SessionState::REVOKED;
    sessionsRevoked_++;
    recordEvent(AuthEventType::SESSION_REVOKED, it->second.method, AuthResult::SUCCESS,
                it->second.owner, "Session revoked");
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::revokeAllSessions(const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    if (owner.empty()) {
        return AuthResult::INVALID_PARAMETER;
    }
    size_t revoked = 0;
    for (auto& pair : sessions_) {
        if (pair.second.owner == owner && pair.second.state == SessionState::ACTIVE) {
            pair.second.state = SessionState::REVOKED;
            sessionsRevoked_++;
            revoked++;
        }
    }
    if (revoked == 0) {
        return AuthResult::SESSION_NOT_FOUND;
    }
    return AuthResult::SUCCESS;
}

AuthResult AuthManager::refreshSession(uint64_t token, uint64_t extendMs) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    auto it = sessions_.find(token);
    if (it == sessions_.end()) {
        return AuthResult::SESSION_NOT_FOUND;
    }
    AuthSession& session = it->second;
    if (session.state == SessionState::REVOKED) {
        return AuthResult::SESSION_INVALID;
    }
    if (session.state == SessionState::EXPIRED ||
        (session.expiresAt != 0 && getCurrentTimeMs() > session.expiresAt)) {
        if (session.state == SessionState::ACTIVE) {
            session.state = SessionState::EXPIRED;
            sessionsExpired_++;
        }
        return AuthResult::SESSION_EXPIRED;
    }
    session.expiresAt = getCurrentTimeMs() + extendMs;
    session.lastUsedAt = getCurrentTimeMs();
    return AuthResult::SUCCESS;
}

size_t AuthManager::getActiveSessionCount() const {
    size_t count = 0;
    uint64_t now = 0;
    // Note: uses real current time (const method, no side effects)
    for (const auto& pair : sessions_) {
        if (pair.second.state != SessionState::ACTIVE) {
            continue;
        }
        if (now == 0) {
            AuthManager* self = const_cast<AuthManager*>(this);
            now = self->getCurrentTimeMs();
        }
        if (pair.second.expiresAt == 0 || pair.second.expiresAt > now) {
            count++;
        }
    }
    return count;
}

size_t AuthManager::processExpiredSessions() {
    size_t expired = 0;
    uint64_t now = getCurrentTimeMs();
    for (auto& pair : sessions_) {
        if (pair.second.state == SessionState::ACTIVE &&
            pair.second.expiresAt != 0 && now > pair.second.expiresAt) {
            pair.second.state = SessionState::EXPIRED;
            sessionsExpired_++;
            expired++;
        }
    }
    return expired;
}

// ============================================================
// Recovery
// ============================================================

std::string AuthManager::generateRecoveryKey(const std::string& owner) {
    if (!initialized_ || owner.empty()) {
        return "";
    }
    // Deterministic pseudo-random material from FNV-1a state
    uint64_t now = getCurrentTimeMs();
    uint64_t seed = computeFNV1a(owner + std::to_string(now) +
                                 std::to_string(nextCredentialId_) +
                                 std::to_string(recoveryKeysGenerated_));
    std::string key;
    for (size_t g = 0; g < RECOVERY_GROUPS; g++) {
        if (g > 0) {
            key += "-";
        }
        for (size_t i = 0; i < RECOVERY_GROUP_LEN; i++) {
            seed = seed * FNV_PRIME ^ (now + i + g);
            key += RECOVERY_ALPHABET[seed % RECOVERY_ALPHABET_LEN];
        }
    }

    // Replace existing recovery key for this owner
    AuthCredential* existing = findCredential(AuthMethod::RECOVERY_KEY, owner);
    if (existing) {
        existing->secretSalt = existing->id * FNV_PRIME ^ now;
        existing->secretHash = hashSecret(key, existing->secretSalt);
        existing->version++;
        existing->state = CredentialState::ACTIVE;
    } else {
        if (credentials_.size() >= maxCredentials_) {
            return "";
        }
        AuthCredential cred;
        cred.id = nextCredentialId_++;
        cred.owner = owner;
        cred.method = AuthMethod::RECOVERY_KEY;
        cred.state = CredentialState::ACTIVE;
        cred.version = 1;
        cred.createdAt = now;
        cred.policy.minLength = RECOVERY_GROUPS * (RECOVERY_GROUP_LEN + 1) - 1;
        cred.policy.maxLength = 256;
        cred.policy.maxAttempts = 3;
        cred.policy.lockoutDurationMs = 600000;  // 10 min
        cred.secretSalt = cred.id * FNV_PRIME ^ now;
        cred.secretHash = hashSecret(key, cred.secretSalt);
        credentials_[cred.id] = cred;
        credentialsEnrolled_++;
    }
    recoveryKeysGenerated_++;
    recordEvent(AuthEventType::RECOVERY_KEY_GENERATED, AuthMethod::RECOVERY_KEY,
                AuthResult::SUCCESS, owner, "Recovery key generated");
    logToServer("info", "Recovery key generated for " + owner);
    return key;
}

AuthResult AuthManager::authenticateWithRecoveryKey(const std::string& recoveryKey,
                                                    const std::string& owner) {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    const AuthCredential* cred = findCredential(AuthMethod::RECOVERY_KEY, owner);
    if (!cred) {
        return AuthResult::RECOVERY_NOT_AVAILABLE;
    }
    const std::string fkey = failureKey(owner, AuthMethod::RECOVERY_KEY);
    auto fit = failures_.find(fkey);
    if (fit != failures_.end() && fit->second.lockoutUntil > getCurrentTimeMs()) {
        return AuthResult::LOCKED_OUT;
    }
    if (cred->secretHash != hashSecret(recoveryKey, cred->secretSalt)) {
        failedAuths_++;
        totalFailures_++;
        FailureTracker& tracker = failures_[fkey];
        tracker.failedAttempts++;
        if (tracker.failedAttempts >= cred->policy.maxAttempts) {
            tracker.lockoutUntil = getCurrentTimeMs() + cred->policy.lockoutDurationMs;
            tracker.failedAttempts = 0;
            lockouts_++;
        }
        return AuthResult::INVALID_CREDENTIAL;
    }
    failures_.erase(fkey);
    successfulAuths_++;
    recoveryUnlocks_++;

    // Recovery unlocks even from RECOVERY_REQUIRED
    if (lockState_ == LockState::RECOVERY_REQUIRED || lockState_ == LockState::TEMP_LOCKED ||
        lockState_ == LockState::LOCKED) {
        changeLockState(LockState::UNLOCKED);
        unlockCount_++;
    }
    recordEvent(AuthEventType::UNLOCK, AuthMethod::RECOVERY_KEY, AuthResult::SUCCESS, owner,
                "Unlocked via recovery key");
    logToServer("warn", "Device unlocked via recovery key for " + owner);
    return AuthResult::SUCCESS;
}

bool AuthManager::isRecoveryAvailable() const {
    for (const auto& pair : credentials_) {
        if (pair.second.method == AuthMethod::RECOVERY_KEY &&
            pair.second.state == CredentialState::ACTIVE) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Events, stats and history
// ============================================================

std::vector<AuthEvent> AuthManager::getEvents(size_t limit) const {
    std::vector<AuthEvent> result;
    if (limit == 0 || limit >= events_.size()) {
        result = events_;
    } else {
        result.assign(events_.end() - static_cast<std::ptrdiff_t>(limit), events_.end());
    }
    return result;
}

std::vector<AuthEvent> AuthManager::getEventsByType(AuthEventType type, size_t limit) const {
    std::vector<AuthEvent> result;
    for (const auto& event : events_) {
        if (event.type == type) {
            result.push_back(event);
            if (limit != 0 && result.size() >= limit) {
                break;
            }
        }
    }
    return result;
}

AuthResult AuthManager::clearEvents() {
    if (!initialized_) {
        return AuthResult::NOT_INITIALIZED;
    }
    for (const auto& event : events_) {
        moveToHistory(event);
    }
    events_.clear();
    return AuthResult::SUCCESS;
}

AuthManagerStats AuthManager::getStats() const {
    AuthManagerStats stats;
    stats.totalCredentials = credentials_.size();
    stats.credentialsEnrolled = credentialsEnrolled_;
    stats.credentialsRemoved = credentialsRemoved_;
    stats.credentialsRotated = credentialsRotated_;
    stats.credentialsDisabled = credentialsDisabled_;
    stats.totalAuthAttempts = totalAuthAttempts_;
    stats.successfulAuths = successfulAuths_;
    stats.failedAuths = failedAuths_;
    stats.lockouts = lockouts_;
    stats.unlockCount = unlockCount_;
    stats.lockCount = lockCount_;
    stats.sessionsCreated = sessionsCreated_;
    stats.sessionsRevoked = sessionsRevoked_;
    stats.sessionsExpired = sessionsExpired_;
    stats.recoveryKeysGenerated = recoveryKeysGenerated_;
    stats.recoveryUnlocks = recoveryUnlocks_;
    stats.totalFailures = totalFailures_;
    for (size_t i = 0; i < 6; i++) {
        stats.byMethod[i] = byMethod_[i];
    }
    for (size_t i = 0; i < 20; i++) {
        stats.byResult[i] = byResult_[i];
    }
    for (size_t i = 0; i < 10; i++) {
        stats.byEventType[i] = byEventType_[i];
    }
    return stats;
}

void AuthManager::resetStats() {
    credentialsEnrolled_ = 0;
    credentialsRemoved_ = 0;
    credentialsRotated_ = 0;
    credentialsDisabled_ = 0;
    totalAuthAttempts_ = 0;
    successfulAuths_ = 0;
    failedAuths_ = 0;
    lockouts_ = 0;
    unlockCount_ = 0;
    lockCount_ = 0;
    sessionsCreated_ = 0;
    sessionsRevoked_ = 0;
    sessionsExpired_ = 0;
    recoveryKeysGenerated_ = 0;
    recoveryUnlocks_ = 0;
    totalFailures_ = 0;
    for (size_t i = 0; i < 6; i++) {
        byMethod_[i] = 0;
    }
    for (size_t i = 0; i < 20; i++) {
        byResult_[i] = 0;
    }
    for (size_t i = 0; i < 10; i++) {
        byEventType_[i] = 0;
    }
}

// ============================================================
// String helpers
// ============================================================

const char* AuthManager::authMethodToString(AuthMethod method) {
    switch (method) {
        case AuthMethod::PIN: return "PIN";
        case AuthMethod::PASSWORD: return "PASSWORD";
        case AuthMethod::PATTERN: return "PATTERN";
        case AuthMethod::BIOMETRIC_STUB: return "BIOMETRIC_STUB";
        case AuthMethod::RECOVERY_KEY: return "RECOVERY_KEY";
        case AuthMethod::TRUSTED_SESSION: return "TRUSTED_SESSION";
    }
    return "UNKNOWN";
}

const char* AuthManager::lockStateToString(LockState state) {
    switch (state) {
        case LockState::UNCONFIGURED: return "UNCONFIGURED";
        case LockState::UNLOCKED: return "UNLOCKED";
        case LockState::LOCKED: return "LOCKED";
        case LockState::AUTHENTICATING: return "AUTHENTICATING";
        case LockState::TEMP_LOCKED: return "TEMP_LOCKED";
        case LockState::RECOVERY_REQUIRED: return "RECOVERY_REQUIRED";
        case LockState::DISABLED: return "DISABLED";
    }
    return "UNKNOWN";
}

const char* AuthManager::authResultToString(AuthResult result) {
    switch (result) {
        case AuthResult::SUCCESS: return "SUCCESS";
        case AuthResult::NOT_INITIALIZED: return "NOT_INITIALIZED";
        case AuthResult::ALREADY_INITIALIZED: return "ALREADY_INITIALIZED";
        case AuthResult::INVALID_CREDENTIAL: return "INVALID_CREDENTIAL";
        case AuthResult::LOCKED_OUT: return "LOCKED_OUT";
        case AuthResult::NO_CREDENTIAL_CONFIGURED: return "NO_CREDENTIAL_CONFIGURED";
        case AuthResult::CREDENTIAL_NOT_FOUND: return "CREDENTIAL_NOT_FOUND";
        case AuthResult::CREDENTIAL_EXISTS: return "CREDENTIAL_EXISTS";
        case AuthResult::CREDENTIAL_DISABLED: return "CREDENTIAL_DISABLED";
        case AuthResult::CREDENTIAL_EXPIRED: return "CREDENTIAL_EXPIRED";
        case AuthResult::INVALID_PARAMETER: return "INVALID_PARAMETER";
        case AuthResult::BAD_STATE: return "BAD_STATE";
        case AuthResult::PERMISSION_DENIED: return "PERMISSION_DENIED";
        case AuthResult::RATE_LIMITED: return "RATE_LIMITED";
        case AuthResult::METHOD_NOT_ENROLLED: return "METHOD_NOT_ENROLLED";
        case AuthResult::SESSION_NOT_FOUND: return "SESSION_NOT_FOUND";
        case AuthResult::SESSION_EXPIRED: return "SESSION_EXPIRED";
        case AuthResult::SESSION_INVALID: return "SESSION_INVALID";
        case AuthResult::RECOVERY_NOT_AVAILABLE: return "RECOVERY_NOT_AVAILABLE";
        case AuthResult::OPERATION_FAILED: return "OPERATION_FAILED";
    }
    return "UNKNOWN";
}

const char* AuthManager::sessionStateToString(SessionState state) {
    switch (state) {
        case SessionState::ACTIVE: return "ACTIVE";
        case SessionState::EXPIRED: return "EXPIRED";
        case SessionState::REVOKED: return "REVOKED";
    }
    return "UNKNOWN";
}

const char* AuthManager::credentialStateToString(CredentialState state) {
    switch (state) {
        case CredentialState::ACTIVE: return "ACTIVE";
        case CredentialState::DISABLED: return "DISABLED";
        case CredentialState::EXPIRED: return "EXPIRED";
        case CredentialState::COMPROMISED: return "COMPROMISED";
        case CredentialState::ROTATED: return "ROTATED";
    }
    return "UNKNOWN";
}

const char* AuthManager::authEventTypeToString(AuthEventType type) {
    switch (type) {
        case AuthEventType::LOCK: return "LOCK";
        case AuthEventType::UNLOCK: return "UNLOCK";
        case AuthEventType::AUTH_SUCCESS: return "AUTH_SUCCESS";
        case AuthEventType::AUTH_FAILURE: return "AUTH_FAILURE";
        case AuthEventType::LOCKOUT: return "LOCKOUT";
        case AuthEventType::METHOD_ENROLLED: return "METHOD_ENROLLED";
        case AuthEventType::METHOD_REMOVED: return "METHOD_REMOVED";
        case AuthEventType::SESSION_CREATED: return "SESSION_CREATED";
        case AuthEventType::SESSION_REVOKED: return "SESSION_REVOKED";
        case AuthEventType::RECOVERY_KEY_GENERATED: return "RECOVERY_KEY_GENERATED";
    }
    return "UNKNOWN";
}

AuthMethod AuthManager::stringToAuthMethod(const std::string& str) {
    if (str == "PIN") return AuthMethod::PIN;
    if (str == "PASSWORD") return AuthMethod::PASSWORD;
    if (str == "PATTERN") return AuthMethod::PATTERN;
    if (str == "BIOMETRIC_STUB") return AuthMethod::BIOMETRIC_STUB;
    if (str == "RECOVERY_KEY") return AuthMethod::RECOVERY_KEY;
    if (str == "TRUSTED_SESSION") return AuthMethod::TRUSTED_SESSION;
    return AuthMethod::PIN;
}

LockState AuthManager::stringToLockState(const std::string& str) {
    if (str == "UNCONFIGURED") return LockState::UNCONFIGURED;
    if (str == "UNLOCKED") return LockState::UNLOCKED;
    if (str == "LOCKED") return LockState::LOCKED;
    if (str == "AUTHENTICATING") return LockState::AUTHENTICATING;
    if (str == "TEMP_LOCKED") return LockState::TEMP_LOCKED;
    if (str == "RECOVERY_REQUIRED") return LockState::RECOVERY_REQUIRED;
    if (str == "DISABLED") return LockState::DISABLED;
    return LockState::UNCONFIGURED;
}

AuthResult AuthManager::stringToAuthResult(const std::string& str) {
    if (str == "SUCCESS") return AuthResult::SUCCESS;
    if (str == "NOT_INITIALIZED") return AuthResult::NOT_INITIALIZED;
    if (str == "ALREADY_INITIALIZED") return AuthResult::ALREADY_INITIALIZED;
    if (str == "INVALID_CREDENTIAL") return AuthResult::INVALID_CREDENTIAL;
    if (str == "LOCKED_OUT") return AuthResult::LOCKED_OUT;
    if (str == "NO_CREDENTIAL_CONFIGURED") return AuthResult::NO_CREDENTIAL_CONFIGURED;
    if (str == "CREDENTIAL_NOT_FOUND") return AuthResult::CREDENTIAL_NOT_FOUND;
    if (str == "CREDENTIAL_EXISTS") return AuthResult::CREDENTIAL_EXISTS;
    if (str == "CREDENTIAL_DISABLED") return AuthResult::CREDENTIAL_DISABLED;
    if (str == "CREDENTIAL_EXPIRED") return AuthResult::CREDENTIAL_EXPIRED;
    if (str == "INVALID_PARAMETER") return AuthResult::INVALID_PARAMETER;
    if (str == "BAD_STATE") return AuthResult::BAD_STATE;
    if (str == "PERMISSION_DENIED") return AuthResult::PERMISSION_DENIED;
    if (str == "RATE_LIMITED") return AuthResult::RATE_LIMITED;
    if (str == "METHOD_NOT_ENROLLED") return AuthResult::METHOD_NOT_ENROLLED;
    if (str == "SESSION_NOT_FOUND") return AuthResult::SESSION_NOT_FOUND;
    if (str == "SESSION_EXPIRED") return AuthResult::SESSION_EXPIRED;
    if (str == "SESSION_INVALID") return AuthResult::SESSION_INVALID;
    if (str == "RECOVERY_NOT_AVAILABLE") return AuthResult::RECOVERY_NOT_AVAILABLE;
    if (str == "OPERATION_FAILED") return AuthResult::OPERATION_FAILED;
    return AuthResult::SUCCESS;
}

}  // namespace phantom::auth
