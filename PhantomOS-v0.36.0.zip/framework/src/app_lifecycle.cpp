/*
 * Phantom OS - App Lifecycle Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/app_lifecycle.h"
#include <algorithm>
#include <cstdio>

namespace phantom::framework {

AppLifecycleManager& AppLifecycleManager::getInstance() {
    static AppLifecycleManager instance;
    return instance;
}

AppLifecycleResult AppLifecycleManager::registerApp(
        const AppInfo& info,
        std::shared_ptr<IAppLifecycleCallbacks> callbacks) {
    if (info.app_id.empty()) return AppLifecycleResult::INVALID_APP;

    if (apps_.find(info.app_id) != apps_.end()) {
        return AppLifecycleResult::ALREADY_REGISTERED;
    }

    AppEntry entry;
    entry.info = info;
    entry.state = AppState::REGISTERED;
    entry.callbacks = callbacks;
    entry.start_count = 0;
    entry.pause_count = 0;
    entry.auto_start = info.auto_start;

    apps_[info.app_id] = std::move(entry);
    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::unregisterApp(const std::string& appId) {
    auto it = apps_.find(appId);
    if (it == apps_.end()) return AppLifecycleResult::APP_NOT_FOUND;
    if (it->second.state == AppState::RUNNING || it->second.state == AppState::PAUSED) {
        return AppLifecycleResult::ALREADY_RUNNING;
    }
    apps_.erase(it);
    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::startApp(const std::string& appId) {
    AppEntry* entry = findApp(appId);
    if (!entry) return AppLifecycleResult::APP_NOT_FOUND;
    if (entry->state == AppState::RUNNING) return AppLifecycleResult::ALREADY_RUNNING;
    if (entry->state == AppState::PAUSED) return AppLifecycleResult::ALREADY_PAUSED;

    if (!isValidTransition(entry->state, AppState::STARTING)) {
        return AppLifecycleResult::INVALID_TRANSITION;
    }

    setState(*entry, AppState::STARTING);

    if (entry->callbacks) {
        entry->callbacks->onCreate(appId);
    }

    setState(*entry, AppState::RUNNING);
    entry->start_count++;

    if (entry->callbacks) {
        entry->callbacks->onStart(appId);
        entry->callbacks->onResume(appId);
    }

    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::pauseApp(const std::string& appId) {
    AppEntry* entry = findApp(appId);
    if (!entry) return AppLifecycleResult::APP_NOT_FOUND;
    if (entry->state == AppState::PAUSED) return AppLifecycleResult::ALREADY_PAUSED;
    if (entry->state != AppState::RUNNING) return AppLifecycleResult::NOT_RUNNING;

    setState(*entry, AppState::PAUSED);
    entry->pause_count++;

    if (entry->callbacks) {
        entry->callbacks->onPause(appId);
    }

    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::resumeApp(const std::string& appId) {
    AppEntry* entry = findApp(appId);
    if (!entry) return AppLifecycleResult::APP_NOT_FOUND;
    if (entry->state != AppState::PAUSED) return AppLifecycleResult::NOT_PAUSED;

    setState(*entry, AppState::RUNNING);

    if (entry->callbacks) {
        entry->callbacks->onResume(appId);
    }

    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::stopApp(const std::string& appId) {
    AppEntry* entry = findApp(appId);
    if (!entry) return AppLifecycleResult::APP_NOT_FOUND;
    if (entry->state == AppState::STOPPED) return AppLifecycleResult::NOT_RUNNING;
    if (entry->state == AppState::REGISTERED) return AppLifecycleResult::NOT_RUNNING;

    setState(*entry, AppState::STOPPING);

    if (entry->callbacks) {
        entry->callbacks->onStop(appId);
    }

    setState(*entry, AppState::STOPPED);

    if (entry->callbacks) {
        entry->callbacks->onDestroy(appId);
    }

    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::destroyApp(const std::string& appId) {
    AppEntry* entry = findApp(appId);
    if (!entry) return AppLifecycleResult::APP_NOT_FOUND;

    if (entry->state == AppState::RUNNING || entry->state == AppState::PAUSED) {
        auto result = stopApp(appId);
        if (result != AppLifecycleResult::SUCCESS) return result;
    }

    apps_.erase(appId);
    return AppLifecycleResult::SUCCESS;
}

AppLifecycleResult AppLifecycleManager::startAllAuto() {
    AppLifecycleResult overall = AppLifecycleResult::SUCCESS;
    for (auto& [id, entry] : apps_) {
        if (entry.auto_start && entry.state == AppState::REGISTERED) {
            auto result = startApp(id);
            if (result != AppLifecycleResult::SUCCESS) {
                overall = result;
            }
        }
    }
    return overall;
}

AppLifecycleResult AppLifecycleManager::stopAll() {
    AppLifecycleResult overall = AppLifecycleResult::SUCCESS;
    // Stop in reverse priority order
    std::vector<std::string> running;
    for (const auto& [id, entry] : apps_) {
        if (entry.state == AppState::RUNNING || entry.state == AppState::PAUSED) {
            running.push_back(id);
        }
    }
    // Sort by priority (LOW first for stopping)
    std::sort(running.begin(), running.end(), [this](const std::string& a, const std::string& b) {
        auto ea = apps_.find(a);
        auto eb = apps_.find(b);
        if (ea != apps_.end() && eb != apps_.end()) {
            return static_cast<int>(ea->second.info.priority) > static_cast<int>(eb->second.info.priority);
        }
        return false;
    });

    for (const auto& id : running) {
        auto result = stopApp(id);
        if (result != AppLifecycleResult::SUCCESS) {
            overall = result;
        }
    }
    return overall;
}

AppState AppLifecycleManager::getAppState(const std::string& appId) const {
    const AppEntry* entry = findApp(appId);
    if (!entry) return AppState::REGISTERED;
    return entry->state;
}

bool AppLifecycleManager::isAppRunning(const std::string& appId) const {
    return getAppState(appId) == AppState::RUNNING;
}

bool AppLifecycleManager::isAppRegistered(const std::string& appId) const {
    return apps_.find(appId) != apps_.end();
}

AppInfo AppLifecycleManager::getAppInfo(const std::string& appId) const {
    const AppEntry* entry = findApp(appId);
    if (!entry) return AppInfo{};
    return entry->info;
}

std::vector<std::string> AppLifecycleManager::getRegisteredApps() const {
    std::vector<std::string> result;
    for (const auto& [id, entry] : apps_) {
        result.push_back(id);
    }
    return result;
}

std::vector<std::string> AppLifecycleManager::getRunningApps() const {
    std::vector<std::string> result;
    for (const auto& [id, entry] : apps_) {
        if (entry.state == AppState::RUNNING) {
            result.push_back(id);
        }
    }
    return result;
}

std::vector<std::string> AppLifecycleManager::getPausedApps() const {
    std::vector<std::string> result;
    for (const auto& [id, entry] : apps_) {
        if (entry.state == AppState::PAUSED) {
            result.push_back(id);
        }
    }
    return result;
}

size_t AppLifecycleManager::getRegisteredCount() const {
    return apps_.size();
}

size_t AppLifecycleManager::getRunningCount() const {
    size_t count = 0;
    for (const auto& [id, entry] : apps_) {
        if (entry.state == AppState::RUNNING) count++;
    }
    return count;
}

std::vector<StateTransition> AppLifecycleManager::getStateHistory(const std::string& appId) const {
    const AppEntry* entry = findApp(appId);
    if (!entry) return {};
    return entry->state_history;
}

size_t AppLifecycleManager::getStartCount(const std::string& appId) const {
    const AppEntry* entry = findApp(appId);
    if (!entry) return 0;
    return entry->start_count;
}

size_t AppLifecycleManager::getPauseCount(const std::string& appId) const {
    const AppEntry* entry = findApp(appId);
    if (!entry) return 0;
    return entry->pause_count;
}

void AppLifecycleManager::setStateChangeCallback(StateChangeCallback callback) {
    state_callback_ = std::move(callback);
}

void AppLifecycleManager::clear() {
    apps_.clear();
    state_callback_ = nullptr;
}

bool AppLifecycleManager::isValidTransition(AppState from, AppState to) {
    switch (from) {
        case AppState::REGISTERED:
            return to == AppState::STARTING || to == AppState::STOPPED;
        case AppState::STARTING:
            return to == AppState::RUNNING || to == AppState::CRASHED || to == AppState::STOPPING;
        case AppState::RUNNING:
            return to == AppState::PAUSED || to == AppState::STOPPING || to == AppState::CRASHED;
        case AppState::PAUSED:
            return to == AppState::RUNNING || to == AppState::STOPPING || to == AppState::CRASHED;
        case AppState::STOPPING:
            return to == AppState::STOPPED || to == AppState::CRASHED;
        case AppState::STOPPED:
            return to == AppState::STARTING;
        case AppState::CRASHED:
            return to == AppState::STARTING || to == AppState::STOPPED;
        default:
            return false;
    }
}

const char* AppLifecycleManager::stateToString(AppState state) {
    switch (state) {
        case AppState::REGISTERED: return "REGISTERED";
        case AppState::STARTING:   return "STARTING";
        case AppState::RUNNING:    return "RUNNING";
        case AppState::PAUSED:     return "PAUSED";
        case AppState::STOPPING:   return "STOPPING";
        case AppState::STOPPED:    return "STOPPED";
        case AppState::CRASHED:    return "CRASHED";
        default: return "UNKNOWN";
    }
}

const char* AppLifecycleManager::priorityToString(AppPriority priority) {
    switch (priority) {
        case AppPriority::SYSTEM: return "SYSTEM";
        case AppPriority::HIGH:   return "HIGH";
        case AppPriority::NORMAL: return "NORMAL";
        case AppPriority::LOW:    return "LOW";
        default: return "UNKNOWN";
    }
}

const char* AppLifecycleManager::resultToString(AppLifecycleResult result) {
    switch (result) {
        case AppLifecycleResult::SUCCESS:             return "SUCCESS";
        case AppLifecycleResult::ALREADY_REGISTERED:  return "ALREADY_REGISTERED";
        case AppLifecycleResult::NOT_REGISTERED:      return "NOT_REGISTERED";
        case AppLifecycleResult::ALREADY_RUNNING:    return "ALREADY_RUNNING";
        case AppLifecycleResult::NOT_RUNNING:         return "NOT_RUNNING";
        case AppLifecycleResult::ALREADY_PAUSED:      return "ALREADY_PAUSED";
        case AppLifecycleResult::NOT_PAUSED:          return "NOT_PAUSED";
        case AppLifecycleResult::START_FAILED:        return "START_FAILED";
        case AppLifecycleResult::STOP_FAILED:         return "STOP_FAILED";
        case AppLifecycleResult::PAUSE_FAILED:        return "PAUSE_FAILED";
        case AppLifecycleResult::RESUME_FAILED:       return "RESUME_FAILED";
        case AppLifecycleResult::INVALID_TRANSITION:  return "INVALID_TRANSITION";
        case AppLifecycleResult::INVALID_APP:         return "INVALID_APP";
        case AppLifecycleResult::APP_NOT_FOUND:       return "APP_NOT_FOUND";
        default: return "UNKNOWN";
    }
}

AppEntry* AppLifecycleManager::findApp(const std::string& appId) {
    auto it = apps_.find(appId);
    if (it == apps_.end()) return nullptr;
    return &it->second;
}

const AppEntry* AppLifecycleManager::findApp(const std::string& appId) const {
    auto it = apps_.find(appId);
    if (it == apps_.end()) return nullptr;
    return &it->second;
}

void AppLifecycleManager::setState(AppEntry& entry, AppState newState) {
    AppState oldState = entry.state;
    entry.state = newState;
    if (state_callback_ && oldState != newState) {
        state_callback_(entry.info.app_id, oldState, newState);
    }
    recordTransition(entry, oldState, newState);
}

void AppLifecycleManager::recordTransition(AppEntry& entry, AppState fromState, AppState toState) {
    StateTransition transition;
    transition.app_id = entry.info.app_id;
    transition.from_state = fromState;
    transition.to_state = toState;
    transition.timestamp = std::chrono::steady_clock::now();
    entry.state_history.push_back(transition);
}

}  // namespace phantom::framework
