/*
 * Phantom OS - Service Manager Implementation
 *
 * License: GPL-3.0
 */

#include "phantom/service_manager.h"
#include <algorithm>
#include <cstring>
#include <cstdio>

namespace phantom::framework {

ServiceManager& ServiceManager::getInstance() {
    static ServiceManager instance;
    return instance;
}

ServiceManager::Result ServiceManager::registerService(std::unique_ptr<IService> service) {
    if (!service) return Result::INVALID_SERVICE;

    const char* name = service->getName();
    if (!name) return Result::INVALID_SERVICE;

    // Check if already registered
    if (findService(name)) {
        return Result::ALREADY_REGISTERED;
    }

    ServiceEntry entry;
    entry.service = std::move(service);
    entry.state = ServiceState::CREATED;
    services_.push_back(std::move(entry));

    // Sort by priority (CRITICAL first, LOW last)
    std::stable_sort(services_.begin(), services_.end(),
        [](const ServiceEntry& a, const ServiceEntry& b) {
            return static_cast<int>(a.service->getPriority()) <
                   static_cast<int>(b.service->getPriority());
        });

    return Result::SUCCESS;
}

ServiceManager::Result ServiceManager::unregisterService(const char* name) {
    auto it = std::find_if(services_.begin(), services_.end(),
        [name](const ServiceEntry& e) {
            return e.service && strcmp(e.service->getName(), name) == 0;
        });

    if (it == services_.end()) return Result::NOT_FOUND;
    if (it->state == ServiceState::RUNNING) return Result::ALREADY_RUNNING;

    services_.erase(it);
    return Result::SUCCESS;
}

ServiceManager::Result ServiceManager::startService(const char* name) {
    ServiceEntry* entry = findService(name);
    if (!entry) return Result::NOT_FOUND;
    if (entry->state == ServiceState::RUNNING) return Result::ALREADY_RUNNING;

    setState(*entry, ServiceState::STARTING);

    if (entry->service->onStart()) {
        setState(*entry, ServiceState::RUNNING);
        return Result::SUCCESS;
    } else {
        setState(*entry, ServiceState::ERROR);
        return Result::START_FAILED;
    }
}

ServiceManager::Result ServiceManager::stopService(const char* name) {
    ServiceEntry* entry = findService(name);
    if (!entry) return Result::NOT_FOUND;
    if (entry->state != ServiceState::RUNNING) return Result::NOT_RUNNING;

    setState(*entry, ServiceState::STOPPING);

    if (entry->service->onStop()) {
        setState(*entry, ServiceState::STOPPED);
        return Result::SUCCESS;
    } else {
        setState(*entry, ServiceState::ERROR);
        return Result::STOP_FAILED;
    }
}

ServiceManager::Result ServiceManager::startAll() {
    Result overall = Result::SUCCESS;
    for (auto& entry : services_) {
        if (entry.state != ServiceState::RUNNING && entry.state != ServiceState::STARTING) {
            setState(entry, ServiceState::STARTING);
            if (entry.service->onStart()) {
                setState(entry, ServiceState::RUNNING);
            } else {
                setState(entry, ServiceState::ERROR);
                overall = Result::START_FAILED;
            }
        }
    }
    return overall;
}

ServiceManager::Result ServiceManager::stopAll() {
    Result overall = Result::SUCCESS;
    // Stop in reverse priority order
    for (auto it = services_.rbegin(); it != services_.rend(); ++it) {
        if (it->state == ServiceState::RUNNING) {
            setState(*it, ServiceState::STOPPING);
            if (it->service->onStop()) {
                setState(*it, ServiceState::STOPPED);
            } else {
                setState(*it, ServiceState::ERROR);
                overall = Result::STOP_FAILED;
            }
        }
    }
    return overall;
}

ServiceState ServiceManager::getServiceState(const char* name) const {
    const ServiceEntry* entry = findService(name);
    if (!entry) return ServiceState::CREATED;
    return entry->state;
}

bool ServiceManager::isServiceRunning(const char* name) const {
    return getServiceState(name) == ServiceState::RUNNING;
}

std::vector<std::string> ServiceManager::getRegisteredServices() const {
    std::vector<std::string> result;
    for (const auto& entry : services_) {
        if (entry.service) {
            result.push_back(entry.service->getName());
        }
    }
    return result;
}

std::vector<std::string> ServiceManager::getRunningServices() const {
    std::vector<std::string> result;
    for (const auto& entry : services_) {
        if (entry.state == ServiceState::RUNNING && entry.service) {
            result.push_back(entry.service->getName());
        }
    }
    return result;
}

size_t ServiceManager::getServiceCount() const {
    return services_.size();
}

size_t ServiceManager::getRunningCount() const {
    size_t count = 0;
    for (const auto& entry : services_) {
        if (entry.state == ServiceState::RUNNING) count++;
    }
    return count;
}

bool ServiceManager::allServicesHealthy() const {
    for (const auto& entry : services_) {
        if (entry.state == ServiceState::RUNNING && !entry.service->isHealthy()) {
            return false;
        }
    }
    return true;
}

void ServiceManager::setStateChangeCallback(StateChangeCallback callback) {
    state_callback_ = std::move(callback);
}

void ServiceManager::setState(ServiceEntry& entry, ServiceState newState) {
    ServiceState oldState = entry.state;
    entry.state = newState;
    if (state_callback_ && oldState != newState) {
        state_callback_(entry.service->getName(), oldState, newState);
    }
}

ServiceManager::ServiceEntry* ServiceManager::findService(const char* name) {
    for (auto& entry : services_) {
        if (entry.service && strcmp(entry.service->getName(), name) == 0) {
            return &entry;
        }
    }
    return nullptr;
}

const ServiceManager::ServiceEntry* ServiceManager::findService(const char* name) const {
    for (const auto& entry : services_) {
        if (entry.service && strcmp(entry.service->getName(), name) == 0) {
            return &entry;
        }
    }
    return nullptr;
}

}  // namespace phantom::framework
