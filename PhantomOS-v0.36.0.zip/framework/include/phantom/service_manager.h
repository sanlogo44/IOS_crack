/*
 * Phantom OS - Service Manager
 * Manages lifecycle of all Phantom OS system services
 *
 * License: GPL-3.0
 */

#pragma once

#include "service.h"
#include <vector>
#include <memory>
#include <string>
#include <unordered_map>
#include <functional>

namespace phantom::framework {

// Service manager - singleton that manages all system services
class ServiceManager {
public:
    // Result of service operations
    enum class Result : int8_t {
        SUCCESS = 0,
        ALREADY_REGISTERED = -1,
        NOT_FOUND = -2,
        ALREADY_RUNNING = -3,
        NOT_RUNNING = -4,
        START_FAILED = -5,
        STOP_FAILED = -6,
        INVALID_SERVICE = -7,
    };

    // Singleton access
    static ServiceManager& getInstance();

    // Register a service
    Result registerService(std::unique_ptr<IService> service);

    // Unregister a service by name
    Result unregisterService(const char* name);

    // Start a service by name
    Result startService(const char* name);

    // Stop a service by name
    Result stopService(const char* name);

    // Start all registered services (in priority order)
    Result startAll();

    // Stop all running services (in reverse priority order)
    Result stopAll();

    // Get service state by name
    ServiceState getServiceState(const char* name) const;

    // Check if a service is running
    bool isServiceRunning(const char* name) const;

    // Get list of all registered service names
    std::vector<std::string> getRegisteredServices() const;

    // Get list of all running service names
    std::vector<std::string> getRunningServices() const;

    // Get count of registered services
    size_t getServiceCount() const;

    // Get count of running services
    size_t getRunningCount() const;

    // Health check - returns true if all running services are healthy
    bool allServicesHealthy() const;

    // Set callback for service state changes
    using StateChangeCallback = std::function<void(const char* serviceName, ServiceState oldState, ServiceState newState)>;
    void setStateChangeCallback(StateChangeCallback callback);

private:
    ServiceManager() = default;
    ~ServiceManager() = default;
    ServiceManager(const ServiceManager&) = delete;
    ServiceManager& operator=(const ServiceManager&) = delete;

    struct ServiceEntry {
        std::unique_ptr<IService> service;
        ServiceState state = ServiceState::CREATED;
    };

    std::vector<ServiceEntry> services_;
    StateChangeCallback state_callback_;

    void setState(ServiceEntry& entry, ServiceState newState);
    ServiceEntry* findService(const char* name);
    const ServiceEntry* findService(const char* name) const;
};

}  // namespace phantom::framework
