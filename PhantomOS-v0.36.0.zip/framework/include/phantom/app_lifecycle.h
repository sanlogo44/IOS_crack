/*
 * Phantom OS - App Lifecycle Manager
 * Manages the lifecycle of applications (Start, Stop, Pause, Resume)
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <unordered_map>
#include <chrono>

namespace phantom::framework {

// App lifecycle states
enum class AppState : uint8_t {
    REGISTERED = 0,   // App is registered but not yet started
    STARTING   = 1,   // App is in the process of starting
    RUNNING    = 2,   // App is running and visible
    PAUSED     = 3,   // App is paused (backgrounded)
    STOPPING   = 4,   // App is in the process of stopping
    STOPPED    = 5,   // App has been stopped
    CRASHED    = 6,    // App has crashed
};

// App priority for scheduling and resource management
enum class AppPriority : uint8_t {
    SYSTEM   = 0,   // System-critical apps (launcher, phone)
    HIGH     = 1,   // Foreground/active apps
    NORMAL   = 2,   // Standard apps
    LOW      = 3,   // Background/low-priority apps
};

// Result codes for lifecycle operations
enum class AppLifecycleResult : int8_t {
    SUCCESS              = 0,
    ALREADY_REGISTERED   = -1,
    NOT_REGISTERED       = -2,
    ALREADY_RUNNING      = -3,
    NOT_RUNNING          = -4,
    ALREADY_PAUSED       = -5,
    NOT_PAUSED           = -6,
    START_FAILED         = -7,
    STOP_FAILED          = -8,
    PAUSE_FAILED         = -9,
    RESUME_FAILED        = -10,
    INVALID_TRANSITION   = -11,
    INVALID_APP          = -12,
    APP_NOT_FOUND        = -13,
};

// App metadata
struct AppInfo {
    std::string app_id;       // Unique app identifier (e.g., "com.phantom.settings")
    std::string name;         // Human-readable name
    std::string version;      // App version string
    std::string package_uri;  // URI to the app package
    AppPriority priority = AppPriority::NORMAL;
    uint32_t target_sdk = 0;  // Target SDK version
    std::vector<std::string> required_permissions;
    bool auto_start = false;         // Whether to auto-start this app on boot
};

// Lifecycle callback interface
class IAppLifecycleCallbacks {
public:
    virtual ~IAppLifecycleCallbacks() = default;
    virtual void onCreate(const std::string& appId) {}
    virtual void onStart(const std::string& appId) {}
    virtual void onResume(const std::string& appId) {}
    virtual void onPause(const std::string& appId) {}
    virtual void onStop(const std::string& appId) {}
    virtual void onDestroy(const std::string& appId) {}
};

// State transition record for history
struct StateTransition {
    std::string app_id;
    AppState from_state;
    AppState to_state;
    std::chrono::steady_clock::time_point timestamp;
};

// App entry internal structure
struct AppEntry {
    AppInfo info;
    AppState state = AppState::REGISTERED;
    std::shared_ptr<IAppLifecycleCallbacks> callbacks;
    std::vector<StateTransition> state_history;
    uint64_t start_count = 0;
    uint64_t pause_count = 0;
    bool auto_start = false;
};

// App Lifecycle Manager - singleton
class AppLifecycleManager {
public:
    static AppLifecycleManager& getInstance();

    // Registration
    AppLifecycleResult registerApp(const AppInfo& info,
                                   std::shared_ptr<IAppLifecycleCallbacks> callbacks = nullptr);
    AppLifecycleResult unregisterApp(const std::string& appId);

    // Lifecycle operations
    AppLifecycleResult startApp(const std::string& appId);
    AppLifecycleResult pauseApp(const std::string& appId);
    AppLifecycleResult resumeApp(const std::string& appId);
    AppLifecycleResult stopApp(const std::string& appId);
    AppLifecycleResult destroyApp(const std::string& appId);

    // Batch operations
    AppLifecycleResult startAllAuto();
    AppLifecycleResult stopAll();

    // Query operations
    AppState getAppState(const std::string& appId) const;
    bool isAppRunning(const std::string& appId) const;
    bool isAppRegistered(const std::string& appId) const;
    AppInfo getAppInfo(const std::string& appId) const;
    std::vector<std::string> getRegisteredApps() const;
    std::vector<std::string> getRunningApps() const;
    std::vector<std::string> getPausedApps() const;
    size_t getRegisteredCount() const;
    size_t getRunningCount() const;

    // State history
    std::vector<StateTransition> getStateHistory(const std::string& appId) const;
    size_t getStartCount(const std::string& appId) const;
    size_t getPauseCount(const std::string& appId) const;

    // State change callback
    using StateChangeCallback = std::function<void(const std::string& appId,
                                                   AppState oldState, AppState newState)>;
    void setStateChangeCallback(StateChangeCallback callback);

    // Clear all apps (for testing)
    void clear();

    // Check if a state transition is valid
    static bool isValidTransition(AppState from, AppState to);

    // Get state name as string
    static const char* stateToString(AppState state);
    static const char* priorityToString(AppPriority priority);
    static const char* resultToString(AppLifecycleResult result);

private:
    AppLifecycleManager() = default;
    ~AppLifecycleManager() = default;
    AppLifecycleManager(const AppLifecycleManager&) = delete;
    AppLifecycleManager& operator=(const AppLifecycleManager&) = delete;

    std::unordered_map<std::string, AppEntry> apps_;
    StateChangeCallback state_callback_;

    AppEntry* findApp(const std::string& appId);
    const AppEntry* findApp(const std::string& appId) const;
    void setState(AppEntry& entry, AppState newState);
    void recordTransition(AppEntry& entry, AppState fromState, AppState toState);
};

}  // namespace phantom::framework
