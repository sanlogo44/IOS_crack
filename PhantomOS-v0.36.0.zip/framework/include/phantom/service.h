/*
 * Phantom OS - Base Service Interface
 * All Phantom OS system services inherit from this interface
 *
 * License: GPL-3.0
 */

#pragma once

#include <cstdint>
#include <string>
#include <memory>

namespace phantom::framework {

// Service states
enum class ServiceState : uint8_t {
    CREATED = 0,
    STARTING = 1,
    RUNNING = 2,
    STOPPING = 3,
    STOPPED = 4,
    ERROR = 5,
};

// Service priority levels
enum class ServicePriority : uint8_t {
    CRITICAL = 0,    // Boot-critical services (can't start without these)
    HIGH = 1,        // Important system services
    NORMAL = 2,      // Standard services
    LOW = 3,         // Non-essential services
};

// Base service interface
class IService {
public:
    virtual ~IService() = default;

    // Get service name (e.g., "PermissionService")
    virtual const char* getName() const = 0;

    // Get service description
    virtual const char* getDescription() const = 0;

    // Get current state
    virtual ServiceState getState() const = 0;

    // Get priority
    virtual ServicePriority getPriority() const = 0;

    // Lifecycle
    virtual bool onStart() = 0;   // Returns true on success
    virtual bool onStop() = 0;    // Returns true on success

    // Health check
    virtual bool isHealthy() const = 0;
};

}  // namespace phantom::framework
