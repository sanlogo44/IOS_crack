/*
 * Phantom OS - System Monitor App
 * Real-time system monitoring with HAL and ProgramExecutor integration
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/layout.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/color.h"
#include "phantom/hal/hal_interfaces.h"
#include <memory>
#include <string>
#include <vector>
#include <functional>

namespace phantom::linux_compat { class ProgramExecutor; }

namespace phantom::sysmon {

// ============================================================
// Enums
// ============================================================

enum class MonitorState {
    IDLE,
    INITIALIZED,
    SHUTDOWN
};

enum class MonitorTab {
    OVERVIEW,
    PROCESSES,
    HARDWARE,
    NETWORK
};

enum class CpuState {
    IDLE,
    USER,
    SYSTEM,
    IO_WAIT
};

// ============================================================
// Structs
// ============================================================

struct ProcessInfo {
    uint32_t pid = 0;
    std::string name;
    std::string state;
    uint32_t cpuUsage = 0;      // percentage (0-100)
    uint64_t memoryBytes = 0;
    uint64_t startTime = 0;
};

struct SystemInfo {
    std::string osVersion;
    std::string kernelVersion;
    std::string deviceName;
    std::string cpuModel;
    uint32_t cpuCores = 0;
    uint64_t cpuFrequency = 0;   // Hz
    uint64_t totalMemory = 0;    // bytes
    uint64_t usedMemory = 0;
    uint64_t freeMemory = 0;
    uint32_t cpuUsage = 0;       // percentage (0-100)
    uint64_t uptime = 0;         // seconds
    uint32_t processCount = 0;
    uint32_t threadCount = 0;
};

struct HardwareStatus {
    // Display
    uint32_t displayWidth = 0;
    uint32_t displayHeight = 0;
    uint32_t displayDpi = 0;
    std::string displayType;
    uint8_t brightness = 0;

    // Storage
    uint64_t storageTotal = 0;
    uint64_t storageAvailable = 0;
    bool storageEncrypted = false;
    std::string filesystemType;

    // Battery
    uint8_t batteryLevel = 0;
    bool batteryCharging = false;
    int32_t batteryVoltage = 0;
    int32_t batteryTemp = 0;

    // Network
    bool wifiConnected = false;
    bool btFound = false;
    bool cellularRegistered = false;
    std::string networkInterface;

    // Power state
    std::string powerState;
};

// ============================================================
// SystemMonitorApp
// ============================================================

class SystemMonitorApp {
public:
    SystemMonitorApp() = default;
    ~SystemMonitorApp() { shutdown(); }

    // Initialize with optional HAL factory and ProgramExecutor
    void initialize(hal::IHalFactory* halFactory = nullptr,
                    linux_compat::ProgramExecutor* executor = nullptr);

    // Shutdown and cleanup
    void shutdown();

    // Tab management
    void setActiveTab(MonitorTab tab);
    MonitorTab getActiveTab() const { return activeTab_; }
    size_t getTabCount() const { return 4; }

    // System info
    SystemInfo getSystemInfo() const { return systemInfo_; }
    void refreshSystemInfo();

    // Hardware status
    HardwareStatus getHardwareStatus() const { return hardwareStatus_; }
    void refreshHardwareStatus();

    // Process list
    std::vector<ProcessInfo> getProcessList() const;
    size_t getProcessCount() const;
    bool killProcess(uint32_t pid);
    void refreshProcessList();

    // Selection
    void setSelectedProcessIndex(int32_t index);
    int32_t getSelectedProcessIndex() const { return selectedProcessIndex_; }
    ProcessInfo getSelectedProcess() const;

    // CPU usage simulation
    void simulateCpuActivity();
    uint32_t getCpuUsage() const { return systemInfo_.cpuUsage; }

    // Layout and render
    void layout(int32_t width, int32_t height);
    void render(gui::Framebuffer& fb) const;
    void renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font) const;

    // Input handling
    bool handleTouchDown(int32_t x, int32_t y);
    bool handleTouchUp(int32_t x, int32_t y);
    bool handleTouchDownRecursive(gui::Widget& widget, int32_t x, int32_t y);
    bool handleTouchUpRecursive(gui::Widget& widget, int32_t x, int32_t y);

    // State
    bool isInitialized() const { return state_ == MonitorState::INITIALIZED; }
    MonitorState getState() const { return state_; }

    // Widget tree
    gui::Widget* getRootWidget() { return root_.get(); }
    const gui::Widget* getRootWidget() const { return root_.get(); }

    // Update callbacks
    using UpdateCallback = std::function<void()>;
    void setUpdateCallback(UpdateCallback cb) { updateCallback_ = cb; }

    // Tab labels
    static const char* tabToString(MonitorTab tab);
    std::string getTabLabel(MonitorTab tab) const;

    // Info string helpers
    std::string getOverviewText() const;
    std::string getHardwareText() const;
    std::string getNetworkText() const;
    std::string getProcessListText() const;

    // Format helpers
    static std::string formatBytes(uint64_t bytes);
    static std::string formatUptime(uint64_t seconds);
    static std::string formatPercentage(uint32_t percent);

    // HAL access
    hal::IHalFactory* getHalFactory() const { return halFactory_; }
    linux_compat::ProgramExecutor* getProgramExecutor() const { return executor_; }

    // Theme
    void applyTheme(const gui::Theme& theme);

private:
    // State
    MonitorState state_ = MonitorState::IDLE;
    MonitorTab activeTab_ = MonitorTab::OVERVIEW;

    // Widget tree
    std::unique_ptr<gui::Widget> root_;
    std::unique_ptr<gui::LinearLayout> rootLayout_;
    std::unique_ptr<gui::Widget> tabBar_;
    std::unique_ptr<gui::LinearLayout> tabLayout_;
    std::unique_ptr<gui::Widget> contentWidget_;
    std::unique_ptr<gui::LinearLayout> contentLayout_;

    // Widgets
    std::vector<gui::Button*> tabButtons_;

    // Panels (unique_ptr versions)
    std::unique_ptr<gui::Widget> overviewPanel_;
    std::unique_ptr<gui::LinearLayout> overviewLayout_;
    std::unique_ptr<gui::Widget> processPanel_;
    std::unique_ptr<gui::LinearLayout> processLayout_;
    std::unique_ptr<gui::Widget> hardwarePanel_;
    std::unique_ptr<gui::LinearLayout> hardwareLayout_;
    std::unique_ptr<gui::Widget> networkPanel_;
    std::unique_ptr<gui::LinearLayout> networkLayout_;

    // Raw pointers for convenience access
    gui::Label* overviewLabel_ = nullptr;
    gui::ListView* processListView_ = nullptr;
    gui::Button* killButton_ = nullptr;
    gui::Label* processCountLabel_ = nullptr;
    gui::Label* hardwareLabel_ = nullptr;
    gui::Label* networkLabel_ = nullptr;

    // HAL
    hal::IHalFactory* halFactory_ = nullptr;
    hal::IHalFactory* ownedFactory_ = nullptr;
    hal::IDisplayHal* displayHal_ = nullptr;
    hal::IStorageHal* storageHal_ = nullptr;
    hal::INetworkHal* networkHal_ = nullptr;
    hal::IPowerHal* powerHal_ = nullptr;

    // ProgramExecutor
    linux_compat::ProgramExecutor* executor_ = nullptr;

    // System info
    SystemInfo systemInfo_;
    HardwareStatus hardwareStatus_;
    std::vector<ProcessInfo> processList_;
    int32_t selectedProcessIndex_ = -1;

    // Update callback
    UpdateCallback updateCallback_;

    // Private methods
    void buildWidgetTree();
    void buildTabBar();
    void buildOverviewPanel();
    void buildProcessPanel();
    void buildHardwarePanel();
    void buildNetworkPanel();
    void updatePanelVisibility();
    void updateOverviewLabel();
    void updateHardwareLabel();
    void updateNetworkLabel();
    void updateProcessListView();
    void initHal();
    void cleanupHal();
    void simulateSystemInfo();
    void simulateProcessList();
};

}  // namespace phantom::sysmon
