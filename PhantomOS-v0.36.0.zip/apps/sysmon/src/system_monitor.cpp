/*
 * Phantom OS - System Monitor App Implementation
 * Real-time system monitoring with HAL and ProgramExecutor integration
 *
 * License: GPL-3.0
 */

#include "phantom/sysmon/system_monitor.h"
#include "mock_hal_factory.h"
#include "phantom/linux_compat/program_executor.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <random>

namespace phantom::sysmon {

// ============================================================
// Initialization / Shutdown
// ============================================================

void SystemMonitorApp::initialize(hal::IHalFactory* halFactory,
                                  linux_compat::ProgramExecutor* executor) {
    if (state_ == MonitorState::INITIALIZED) return;

    // HAL factory
    if (halFactory) {
        halFactory_ = halFactory;
    } else {
        ownedFactory_ = hal::createMockHalFactory();
        halFactory_ = ownedFactory_;
    }

    // ProgramExecutor
    executor_ = executor;

    // Init HAL
    initHal();

    // Build widget tree
    buildWidgetTree();

    // Simulate initial system info
    simulateSystemInfo();
    simulateProcessList();

    // Refresh hardware from HAL
    refreshHardwareStatus();

    // Update content
    updateOverviewLabel();
    updateHardwareLabel();
    updateNetworkLabel();
    updateProcessListView();

    state_ = MonitorState::INITIALIZED;
}

void SystemMonitorApp::shutdown() {
    if (state_ != MonitorState::INITIALIZED) return;

    cleanupHal();

    root_.reset();
    rootLayout_.reset();
    tabBar_.reset();
    tabLayout_.reset();
    contentWidget_.reset();
    contentLayout_.reset();
    overviewPanel_.reset();
    overviewLayout_.reset();
    processPanel_.reset();
    processLayout_.reset();
    hardwarePanel_.reset();
    hardwareLayout_.reset();
    networkPanel_.reset();
    networkLayout_.reset();
    tabButtons_.clear();
    overviewLabel_ = nullptr;
    processListView_ = nullptr;
    killButton_ = nullptr;
    processCountLabel_ = nullptr;
    hardwareLabel_ = nullptr;
    networkLabel_ = nullptr;

    if (ownedFactory_) {
        delete ownedFactory_;
        ownedFactory_ = nullptr;
        halFactory_ = nullptr;
    }

    executor_ = nullptr;
    state_ = MonitorState::SHUTDOWN;
}

// ============================================================
// HAL
// ============================================================

void SystemMonitorApp::initHal() {
    if (!halFactory_) return;
    halFactory_->createDisplay(&displayHal_);
    if (displayHal_) displayHal_->init();
    halFactory_->createStorage(&storageHal_);
    if (storageHal_) storageHal_->init();
    halFactory_->createNetwork(&networkHal_);
    if (networkHal_) networkHal_->init();
    halFactory_->createPower(&powerHal_);
    if (powerHal_) powerHal_->init();
}

void SystemMonitorApp::cleanupHal() {
    if (halFactory_) {
        if (displayHal_) { displayHal_->deinit(); halFactory_->destroyDisplay(displayHal_); displayHal_ = nullptr; }
        if (storageHal_) { storageHal_->deinit(); halFactory_->destroyStorage(storageHal_); storageHal_ = nullptr; }
        if (networkHal_) { networkHal_->deinit(); halFactory_->destroyNetwork(networkHal_); networkHal_ = nullptr; }
        if (powerHal_) { powerHal_->deinit(); halFactory_->destroyPower(powerHal_); powerHal_ = nullptr; }
    }
}

// ============================================================
// Widget Tree
// ============================================================

void SystemMonitorApp::buildWidgetTree() {
    root_ = std::make_unique<gui::Widget>();
    root_->setTag("system_monitor_root");
    rootLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    rootLayout_->setSpacing(8);

    // Tab bar
    buildTabBar();
    root_->addChild(std::move(tabBar_));

    // Content area
    contentWidget_ = std::make_unique<gui::Widget>();
    contentWidget_->setTag("content");
    contentLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    contentLayout_->setSpacing(8);

    // Build panels
    buildOverviewPanel();
    buildProcessPanel();
    buildHardwarePanel();
    buildNetworkPanel();

    contentWidget_->addChild(std::move(overviewPanel_));
    contentWidget_->addChild(std::move(processPanel_));
    contentWidget_->addChild(std::move(hardwarePanel_));
    contentWidget_->addChild(std::move(networkPanel_));

    root_->addChild(std::move(contentWidget_));

    updatePanelVisibility();
}

void SystemMonitorApp::buildTabBar() {
    tabBar_ = std::make_unique<gui::Widget>();
    tabBar_->setTag("tab_bar");
    tabLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::HORIZONTAL);
    tabLayout_->setSpacing(8);

    const char* tabs[] = {"Overview", "Processes", "Hardware", "Network"};
    for (int i = 0; i < 4; ++i) {
        auto btn = std::make_unique<gui::Button>();
        btn->setText(tabs[i]);
        btn->setBackgroundColor(gui::Color::DarkGray);
        btn->setTextColor(gui::Color::White);
        tabButtons_.push_back(btn.get());
        tabBar_->addChild(std::move(btn));
    }
}

void SystemMonitorApp::buildOverviewPanel() {
    overviewPanel_ = std::make_unique<gui::Widget>();
    overviewPanel_->setTag("overview_panel");
    overviewLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    overviewLayout_->setSpacing(8);

    overviewLabel_ = new gui::Label();
    overviewLabel_->setText("System Overview");
    overviewLabel_->setTextColor(gui::Color::White);
    overviewPanel_->addChild(std::unique_ptr<gui::Widget>(overviewLabel_));
}

void SystemMonitorApp::buildProcessPanel() {
    processPanel_ = std::make_unique<gui::Widget>();
    processPanel_->setTag("process_panel");
    processLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    processLayout_->setSpacing(8);

    // Process count label
    processCountLabel_ = new gui::Label();
    processCountLabel_->setText("Processes: 0");
    processCountLabel_->setTextColor(gui::Color::White);
    processPanel_->addChild(std::unique_ptr<gui::Widget>(processCountLabel_));

    // Process list view
    processListView_ = new gui::ListView();
    processListView_->setSelectedIndex(0);
    processListView_->setBgColor(gui::Color::Black);
    processListView_->setSelectedBgColor(gui::Color::DarkGray);
    processListView_->setItemTextColor(gui::Color::White);
    processListView_->setSelectedTextColor(gui::Color::White);

    processListView_->setItemTextCallback([this](size_t index) -> std::string {
        auto procs = getProcessList();
        if (index < procs.size()) {
            const auto& p = procs[index];
            char buf[256];
            std::snprintf(buf, sizeof(buf), "[%5u] %-20s CPU:%3u%% MEM:%s",
                          p.pid, p.name.c_str(), p.cpuUsage,
                          formatBytes(p.memoryBytes).c_str());
            return std::string(buf);
        }
        return "";
    });

    processPanel_->addChild(std::unique_ptr<gui::Widget>(processListView_));

    // Kill button
    killButton_ = new gui::Button();
    killButton_->setText("Kill Process");
    killButton_->setBackgroundColor(gui::Color::Red);
    killButton_->setTextColor(gui::Color::White);
    processPanel_->addChild(std::unique_ptr<gui::Widget>(killButton_));
}

void SystemMonitorApp::buildHardwarePanel() {
    hardwarePanel_ = std::make_unique<gui::Widget>();
    hardwarePanel_->setTag("hardware_panel");
    hardwareLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    hardwareLayout_->setSpacing(8);

    hardwareLabel_ = new gui::Label();
    hardwareLabel_->setText("Hardware Status");
    hardwareLabel_->setTextColor(gui::Color::White);
    hardwarePanel_->addChild(std::unique_ptr<gui::Widget>(hardwareLabel_));
}

void SystemMonitorApp::buildNetworkPanel() {
    networkPanel_ = std::make_unique<gui::Widget>();
    networkPanel_->setTag("network_panel");
    networkLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    networkLayout_->setSpacing(8);

    networkLabel_ = new gui::Label();
    networkLabel_->setText("Network Status");
    networkLabel_->setTextColor(gui::Color::White);
    networkPanel_->addChild(std::unique_ptr<gui::Widget>(networkLabel_));
}

void SystemMonitorApp::updatePanelVisibility() {
    if (overviewPanel_) overviewPanel_->setVisibility(activeTab_ == MonitorTab::OVERVIEW ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (processPanel_) processPanel_->setVisibility(activeTab_ == MonitorTab::PROCESSES ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (hardwarePanel_) hardwarePanel_->setVisibility(activeTab_ == MonitorTab::HARDWARE ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (networkPanel_) networkPanel_->setVisibility(activeTab_ == MonitorTab::NETWORK ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
}

// ============================================================
// Tab Management
// ============================================================

void SystemMonitorApp::setActiveTab(MonitorTab tab) {
    if (activeTab_ == tab) return;
    activeTab_ = tab;
    updatePanelVisibility();
}

const char* SystemMonitorApp::tabToString(MonitorTab tab) {
    switch (tab) {
        case MonitorTab::OVERVIEW: return "OVERVIEW";
        case MonitorTab::PROCESSES: return "PROCESSES";
        case MonitorTab::HARDWARE: return "HARDWARE";
        case MonitorTab::NETWORK: return "NETWORK";
        default: return "UNKNOWN";
    }
}

std::string SystemMonitorApp::getTabLabel(MonitorTab tab) const {
    switch (tab) {
        case MonitorTab::OVERVIEW: return "System Overview";
        case MonitorTab::PROCESSES: return "Running Processes";
        case MonitorTab::HARDWARE: return "Hardware Status";
        case MonitorTab::NETWORK: return "Network Status";
        default: return "Unknown";
    }
}

// ============================================================
// System Info
// ============================================================

void SystemMonitorApp::simulateSystemInfo() {
    systemInfo_.osVersion = "Phantom OS 0.13.0";
    systemInfo_.kernelVersion = "6.1.0-phantom";
    systemInfo_.deviceName = "iPhone X (A11 Bionic)";
    systemInfo_.cpuModel = "Apple A11 Bionic";
    systemInfo_.cpuCores = 6;
    systemInfo_.cpuFrequency = 2390000000ULL;
    systemInfo_.totalMemory = 3ULL * 1024 * 1024 * 1024;  // 3GB
    systemInfo_.usedMemory = 1ULL * 1024 * 1024 * 1024;  // 1GB
    systemInfo_.freeMemory = systemInfo_.totalMemory - systemInfo_.usedMemory;
    systemInfo_.cpuUsage = 15;
    systemInfo_.uptime = 3600;
    systemInfo_.processCount = 0;
    systemInfo_.threadCount = 0;
}

void SystemMonitorApp::refreshSystemInfo() {
    // Update uptime
    systemInfo_.uptime += 1;

    // Update memory (simulated fluctuation)
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> memDelta(-50, 50);
    int64_t delta = memDelta(gen) * 1024 * 1024;
    int64_t newUsed = static_cast<int64_t>(systemInfo_.usedMemory) + delta;
    if (newUsed < 0) newUsed = 0;
    if (newUsed > static_cast<int64_t>(systemInfo_.totalMemory)) newUsed = systemInfo_.totalMemory;
    systemInfo_.usedMemory = static_cast<uint64_t>(newUsed);
    systemInfo_.freeMemory = systemInfo_.totalMemory - systemInfo_.usedMemory;

    // Update CPU usage (simulated)
    simulateCpuActivity();

    // Update process count
    systemInfo_.processCount = static_cast<uint32_t>(getProcessCount());
    systemInfo_.threadCount = systemInfo_.processCount * 2;

    // Update overview
    updateOverviewLabel();
}

// ============================================================
// Hardware Status
// ============================================================

void SystemMonitorApp::refreshHardwareStatus() {
    if (!halFactory_) return;

    // Display
    if (displayHal_) {
        hal::DisplayInfo info{};
        if (displayHal_->getInfo(&info) == hal::HalResult::SUCCESS) {
            hardwareStatus_.displayWidth = info.resolution.width;
            hardwareStatus_.displayHeight = info.resolution.height;
            hardwareStatus_.displayDpi = info.resolution.dpi;
            hardwareStatus_.displayType = info.panel_type;
        }
        uint8_t brightness = 0;
        if (displayHal_->getBrightness(&brightness) == hal::HalResult::SUCCESS) {
            hardwareStatus_.brightness = brightness;
        }
    }

    // Storage
    if (storageHal_) {
        hal::StorageInfo info{};
        if (storageHal_->getInfo(&info) == hal::HalResult::SUCCESS) {
            hardwareStatus_.storageTotal = info.total_bytes;
            hardwareStatus_.storageAvailable = info.available_bytes;
            hardwareStatus_.storageEncrypted = info.is_encrypted;
            hardwareStatus_.filesystemType = info.filesystem_type;
        }
    }

    // Battery / Power
    if (powerHal_) {
        hal::BatteryInfo info{};
        if (powerHal_->getBatteryInfo(&info) == hal::HalResult::SUCCESS) {
            hardwareStatus_.batteryLevel = info.level;
            hardwareStatus_.batteryCharging = info.is_charging;
            hardwareStatus_.batteryVoltage = info.voltage_mv;
            hardwareStatus_.batteryTemp = info.temperature_dc;
        }
        hal::PowerState ps = hal::PowerState::ACTIVE;
        if (powerHal_->getPowerState(&ps) == hal::HalResult::SUCCESS) {
            switch (ps) {
                case hal::PowerState::ACTIVE: hardwareStatus_.powerState = "ACTIVE"; break;
                case hal::PowerState::SUSPEND: hardwareStatus_.powerState = "SUSPEND"; break;
                case hal::PowerState::DEEP_SLEEP: hardwareStatus_.powerState = "DEEP_SLEEP"; break;
                case hal::PowerState::SHUTDOWN: hardwareStatus_.powerState = "SHUTDOWN"; break;
            }
        }
    }

    // Network
    if (networkHal_) {
        bool wifiConnected = false;
        if (networkHal_->wifiGetStatus(&wifiConnected) == hal::HalResult::SUCCESS) {
            hardwareStatus_.wifiConnected = wifiConnected;
        }
        bool btFound = false;
        if (networkHal_->btScan(&btFound) == hal::HalResult::SUCCESS) {
            hardwareStatus_.btFound = btFound;
        }
        bool cellular = false;
        if (networkHal_->cellularGetStatus(&cellular) == hal::HalResult::SUCCESS) {
            hardwareStatus_.cellularRegistered = cellular;
        }
        hardwareStatus_.networkInterface = "wlan0";
    }

    updateHardwareLabel();
    updateNetworkLabel();
}

// ============================================================
// Process Management
// ============================================================

void SystemMonitorApp::simulateProcessList() {
    processList_.clear();

    // Built-in processes
    const char* names[] = {
        "init", "system_server", "surfaceflinger", "phantom_gui",
        "phantom_ipc", "phantom_config", "phantom_sandbox",
        "settings_app", "terminal_app", "file_manager",
        "network_service", "power_service", "sensor_service",
        "audio_service", "package_manager", "linux_compat",
        "window_manager", "compositor", "input_dispatcher",
        "theme_manager", "permission_manager", "identity_service",
        "data_sanitizer", "service_manager", "ipc_bus",
        "mock_runtime", "hal_display", "hal_storage",
        "hal_network", "hal_power"
    };
    const char* states[] = {"RUNNING", "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING", "RUNNING",
                             "RUNNING", "RUNNING"};

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> cpuDist(0, 80);
    std::uniform_int_distribution<> memDist(1, 200);

    uint32_t pid = 1;
    for (int i = 0; i < 30; ++i) {
        ProcessInfo p;
        p.pid = pid++;
        p.name = names[i];
        p.state = states[i];
        p.cpuUsage = static_cast<uint32_t>(cpuDist(gen));
        p.memoryBytes = static_cast<uint64_t>(memDist(gen)) * 1024 * 1024;
        p.startTime = 0;
        processList_.push_back(p);
    }
}

void SystemMonitorApp::refreshProcessList() {
    // Simulate CPU fluctuations
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> delta(-10, 10);

    for (auto& p : processList_) {
        int32_t newCpu = static_cast<int32_t>(p.cpuUsage) + delta(gen);
        if (newCpu < 0) newCpu = 0;
        if (newCpu > 100) newCpu = 100;
        p.cpuUsage = static_cast<uint32_t>(newCpu);
    }

    updateProcessListView();
    if (processCountLabel_) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "Processes: %zu", processList_.size());
        processCountLabel_->setText(buf);
    }
}

std::vector<ProcessInfo> SystemMonitorApp::getProcessList() const {
    return processList_;
}

size_t SystemMonitorApp::getProcessCount() const {
    return processList_.size();
}

bool SystemMonitorApp::killProcess(uint32_t pid) {
    auto it = std::find_if(processList_.begin(), processList_.end(),
                           [pid](const ProcessInfo& p) { return p.pid == pid; });
    if (it == processList_.end()) return false;

    // Don't allow killing init (PID 1)
    if (pid == 1) return false;

    processList_.erase(it);

    // Adjust selection
    if (selectedProcessIndex_ >= static_cast<int32_t>(processList_.size())) {
        selectedProcessIndex_ = static_cast<int32_t>(processList_.size()) - 1;
    }

    updateProcessListView();
    if (processCountLabel_) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "Processes: %zu", processList_.size());
        processCountLabel_->setText(buf);
    }
    if (updateCallback_) updateCallback_();
    return true;
}

void SystemMonitorApp::setSelectedProcessIndex(int32_t index) {
    selectedProcessIndex_ = index;
    if (processListView_) {
        processListView_->setSelectedIndex(index);
    }
}

ProcessInfo SystemMonitorApp::getSelectedProcess() const {
    if (selectedProcessIndex_ >= 0 && selectedProcessIndex_ < static_cast<int32_t>(processList_.size())) {
        return processList_[selectedProcessIndex_];
    }
    return ProcessInfo{};
}

// ============================================================
// CPU Simulation
// ============================================================

void SystemMonitorApp::simulateCpuActivity() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(5, 85);
    systemInfo_.cpuUsage = static_cast<uint32_t>(dist(gen));
}

// ============================================================
// Label Updates
// ============================================================

void SystemMonitorApp::updateOverviewLabel() {
    if (!overviewLabel_) return;
    overviewLabel_->setText(getOverviewText());
}

void SystemMonitorApp::updateHardwareLabel() {
    if (!hardwareLabel_) return;
    hardwareLabel_->setText(getHardwareText());
}

void SystemMonitorApp::updateNetworkLabel() {
    if (!networkLabel_) return;
    networkLabel_->setText(getNetworkText());
}

void SystemMonitorApp::updateProcessListView() {
    if (!processListView_) return;
    processListView_->setItemCount(processList_.size());
}

// ============================================================
// Info Text Generators
// ============================================================

std::string SystemMonitorApp::getOverviewText() const {
    char buf[1024];
    std::snprintf(buf, sizeof(buf),
        "=== System Overview ===\n\n"
        "OS:        %s\n"
        "Kernel:    %s\n"
        "Device:    %s\n"
        "CPU:       %s (%u cores @ %u MHz)\n"
        "CPU Usage: %s\n"
        "Memory:    %s / %s (%s used)\n"
        "Uptime:    %s\n"
        "Processes: %u (Threads: %u)\n",
        systemInfo_.osVersion.c_str(),
        systemInfo_.kernelVersion.c_str(),
        systemInfo_.deviceName.c_str(),
        systemInfo_.cpuModel.c_str(),
        systemInfo_.cpuCores,
        static_cast<uint32_t>(systemInfo_.cpuFrequency / 1000000),
        formatPercentage(systemInfo_.cpuUsage).c_str(),
        formatBytes(systemInfo_.usedMemory).c_str(),
        formatBytes(systemInfo_.totalMemory).c_str(),
        formatPercentage(static_cast<uint32_t>(systemInfo_.usedMemory * 100 / systemInfo_.totalMemory)).c_str(),
        formatUptime(systemInfo_.uptime).c_str(),
        systemInfo_.processCount,
        systemInfo_.threadCount
    );
    return std::string(buf);
}

std::string SystemMonitorApp::getHardwareText() const {
    char buf[1024];
    std::snprintf(buf, sizeof(buf),
        "=== Hardware Status ===\n\n"
        "Display:\n"
        "  Resolution: %ux%u\n"
        "  DPI:        %u\n"
        "  Type:       %s\n"
        "  Brightness: %u/255\n\n"
        "Storage:\n"
        "  Total:      %s\n"
        "  Available:  %s\n"
        "  Encrypted:  %s\n"
        "  Filesystem: %s\n\n"
        "Battery:\n"
        "  Level:      %u%%\n"
        "  Charging:   %s\n"
        "  Voltage:    %d mV\n"
        "  Temperature: %d.%dC\n\n"
        "Power State: %s\n",
        hardwareStatus_.displayWidth,
        hardwareStatus_.displayHeight,
        hardwareStatus_.displayDpi,
        hardwareStatus_.displayType.c_str(),
        hardwareStatus_.brightness,
        formatBytes(hardwareStatus_.storageTotal).c_str(),
        formatBytes(hardwareStatus_.storageAvailable).c_str(),
        hardwareStatus_.storageEncrypted ? "Yes" : "No",
        hardwareStatus_.filesystemType.c_str(),
        hardwareStatus_.batteryLevel,
        hardwareStatus_.batteryCharging ? "Yes" : "No",
        hardwareStatus_.batteryVoltage,
        hardwareStatus_.batteryTemp / 10,
        hardwareStatus_.batteryTemp % 10,
        hardwareStatus_.powerState.c_str()
    );
    return std::string(buf);
}

std::string SystemMonitorApp::getNetworkText() const {
    char buf[512];
    std::snprintf(buf, sizeof(buf),
        "=== Network Status ===\n\n"
        "Interface:  %s\n"
        "Wi-Fi:      %s\n"
        "Bluetooth:  %s\n"
        "Cellular:   %s\n",
        hardwareStatus_.networkInterface.c_str(),
        hardwareStatus_.wifiConnected ? "Connected" : "Disconnected",
        hardwareStatus_.btFound ? "Available" : "Not found",
        hardwareStatus_.cellularRegistered ? "Registered" : "Not registered"
    );
    return std::string(buf);
}

std::string SystemMonitorApp::getProcessListText() const {
    std::string result = "PID     Name                CPU%  Memory\n";
    result += "------- ------------------- ----- --------\n";
    for (const auto& p : processList_) {
        char buf[128];
        std::snprintf(buf, sizeof(buf), "%-7u %-20s %3u%%  %s\n",
                      p.pid, p.name.c_str(), p.cpuUsage,
                      formatBytes(p.memoryBytes).c_str());
        result += buf;
    }
    return result;
}

// ============================================================
// Format Helpers
// ============================================================

std::string SystemMonitorApp::formatBytes(uint64_t bytes) {
    char buf[64];
    if (bytes >= 1024ULL * 1024 * 1024) {
        std::snprintf(buf, sizeof(buf), "%.1f GB", static_cast<double>(bytes) / (1024.0 * 1024 * 1024));
    } else if (bytes >= 1024ULL * 1024) {
        std::snprintf(buf, sizeof(buf), "%.1f MB", static_cast<double>(bytes) / (1024.0 * 1024));
    } else if (bytes >= 1024) {
        std::snprintf(buf, sizeof(buf), "%.1f KB", static_cast<double>(bytes) / 1024.0);
    } else {
        std::snprintf(buf, sizeof(buf), "%llu B", static_cast<unsigned long long>(bytes));
    }
    return std::string(buf);
}

std::string SystemMonitorApp::formatUptime(uint64_t seconds) {
    uint64_t days = seconds / 86400;
    uint64_t hours = (seconds % 86400) / 3600;
    uint64_t mins = (seconds % 3600) / 60;
    uint64_t secs = seconds % 60;
    char buf[128];
    if (days > 0) {
        std::snprintf(buf, sizeof(buf), "%llu days %02llu:%02llu:%02llu",
                      static_cast<unsigned long long>(days),
                      static_cast<unsigned long long>(hours),
                      static_cast<unsigned long long>(mins),
                      static_cast<unsigned long long>(secs));
    } else {
        std::snprintf(buf, sizeof(buf), "%02llu:%02llu:%02llu",
                      static_cast<unsigned long long>(hours),
                      static_cast<unsigned long long>(mins),
                      static_cast<unsigned long long>(secs));
    }
    return std::string(buf);
}

std::string SystemMonitorApp::formatPercentage(uint32_t percent) {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "%u%%", percent);
    return std::string(buf);
}

// ============================================================
// Layout and Render
// ============================================================

void SystemMonitorApp::layout(int32_t width, int32_t height) {
    if (!root_) return;
    root_->setBounds(gui::Rect(0, 0, width, height));
    root_->setPadding(16, 16, 16, 16);

    if (rootLayout_) {
        rootLayout_->measure(*root_);
        rootLayout_->layout(*root_);
    }
}

void SystemMonitorApp::render(gui::Framebuffer& fb) const {
    if (!root_) return;
    fb.clear(gui::Color::Black);
    gui::BitmapFont font;
    renderWidget(*root_, fb, font);
}

void SystemMonitorApp::renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font) const {
    widget.onRender(fb, font);
    for (auto* child : widget.getChildren()) {
        if (child && child->isVisible()) {
            renderWidget(*child, fb, font);
        }
    }
}

// ============================================================
// Input Handling
// ============================================================

bool SystemMonitorApp::handleTouchDown(int32_t x, int32_t y) {
    if (!root_) return false;
    return handleTouchDownRecursive(*root_, x, y);
}

bool SystemMonitorApp::handleTouchUp(int32_t x, int32_t y) {
    if (!root_) return false;
    return handleTouchUpRecursive(*root_, x, y);
}

bool SystemMonitorApp::handleTouchDownRecursive(gui::Widget& widget, int32_t x, int32_t y) {
    if (!widget.isVisible()) return false;
    if (!widget.getBounds().contains(x, y)) return false;

    // Check tab buttons
    for (size_t i = 0; i < tabButtons_.size(); ++i) {
        if (tabButtons_[i] == &widget) {
            setActiveTab(static_cast<MonitorTab>(i));
            return true;
        }
    }

    // Check kill button
    if (killButton_ == &widget) {
        if (selectedProcessIndex_ >= 0 && selectedProcessIndex_ < static_cast<int32_t>(processList_.size())) {
            uint32_t pid = processList_[selectedProcessIndex_].pid;
            killProcess(pid);
        }
        return true;
    }

    // Check process list view
    if (processListView_ == &widget) {
        // Use ListView's built-in touch handling
        int32_t relX = x - widget.getBounds().x;
        int32_t relY = y - widget.getBounds().y;
        int32_t itemHeight = processListView_->getItemHeight();
        if (itemHeight > 0) {
            int32_t itemIndex = (relY + processListView_->getScrollOffset()) / itemHeight;
            if (itemIndex >= 0 && itemIndex < static_cast<int32_t>(processListView_->getItemCount())) {
                processListView_->setSelectedIndex(itemIndex);
                selectedProcessIndex_ = itemIndex;
                if (updateCallback_) updateCallback_();
            }
        }
        return true;
    }

    // Recurse into children
    for (auto* child : widget.getChildren()) {
        if (child && handleTouchDownRecursive(*child, x, y)) return true;
    }
    return true;
}

bool SystemMonitorApp::handleTouchUpRecursive(gui::Widget& widget, int32_t x, int32_t y) {
    if (!widget.isVisible()) return false;
    if (!widget.getBounds().contains(x, y)) return false;
    return true;
}

// ============================================================
// Theme
// ============================================================

void SystemMonitorApp::applyTheme(const gui::Theme& theme) {
    if (theme.getType() == gui::ThemeType::DARK) {
        for (auto* btn : tabButtons_) {
            if (btn) {
                btn->setBackgroundColor(gui::Color::DarkGray);
                btn->setTextColor(gui::Color::White);
            }
        }

        if (overviewLabel_) overviewLabel_->setTextColor(gui::Color::White);
        if (processCountLabel_) processCountLabel_->setTextColor(gui::Color::White);
        if (processListView_) {
            processListView_->setBgColor(gui::Color::Black);
            processListView_->setSelectedBgColor(gui::Color::DarkGray);
            processListView_->setItemTextColor(gui::Color::White);
            processListView_->setSelectedTextColor(gui::Color::White);
        }
        if (killButton_) {
            killButton_->setBackgroundColor(gui::Color::Red);
            killButton_->setTextColor(gui::Color::White);
        }
        if (hardwareLabel_) hardwareLabel_->setTextColor(gui::Color::White);
        if (networkLabel_) networkLabel_->setTextColor(gui::Color::White);
    } else {
        for (auto* btn : tabButtons_) {
            if (btn) {
                btn->setBackgroundColor(gui::Color::LightGray);
                btn->setTextColor(gui::Color::Black);
            }
        }

        if (overviewLabel_) overviewLabel_->setTextColor(gui::Color::Black);
        if (processCountLabel_) processCountLabel_->setTextColor(gui::Color::Black);
        if (processListView_) {
            processListView_->setBgColor(gui::Color::White);
            processListView_->setSelectedBgColor(gui::Color::LightGray);
            processListView_->setItemTextColor(gui::Color::Black);
            processListView_->setSelectedTextColor(gui::Color::Black);
        }
        if (killButton_) {
            killButton_->setBackgroundColor(gui::Color::Red);
            killButton_->setTextColor(gui::Color::White);
        }
        if (hardwareLabel_) hardwareLabel_->setTextColor(gui::Color::Black);
        if (networkLabel_) networkLabel_->setTextColor(gui::Color::Black);
    }
}

}  // namespace phantom::sysmon
