/*
 * Phantom OS - Terminal App
 * GUI Terminal emulator with Linux Compatibility Layer integration
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/multi_line_text.h"
#include "phantom/gui/layout.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/color.h"
#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <deque>

namespace phantom::linux_compat { class ProgramExecutor; }

namespace phantom::terminal {

// ============================================================
// Enums
// ============================================================

// Terminal state
enum class TerminalState {
    IDLE,           // Not initialized
    INITIALIZED,    // Ready for commands
    SHUTDOWN        // Terminated
};

// Command result
enum class CommandResult {
    SUCCESS,        // Command executed successfully
    NOT_FOUND,      // Unknown command
    INVALID_ARGS,   // Invalid arguments
    DENIED,         // Permission denied
    ERROR_          // Command error
};

// ============================================================
// Structs
// ============================================================

// A single output line with color
struct TerminalLine {
    std::string text;
    gui::Color color = gui::Color::LightGray;
    bool isPrompt = false;      // Is this a prompt line
    bool isInput = false;       // Is this echoed user input
    bool isError = false;       // Is this an error message
};

// Command history entry
struct HistoryEntry {
    std::string command;        // Full command string
    std::string output;         // Captured output
    uint64_t timestamp = 0;     // When executed
};

// ============================================================
// Terminal App
// ============================================================

class TerminalApp {
public:
    TerminalApp() = default;
    ~TerminalApp() { shutdown(); }

    // Initialize with optional ProgramExecutor
    void initialize(linux_compat::ProgramExecutor* executor = nullptr);

    // Shutdown and cleanup
    void shutdown();

    // Process a command string
    CommandResult executeCommand(const std::string& input);

    // Process a command string and capture output
    CommandResult executeCommand(const std::string& input, std::string& outOutput);

    // Clear the output buffer
    void clearOutput();

    // Layout and render
    void layout(int32_t width, int32_t height);
    void render(gui::Framebuffer& fb) const;

    // Render widget tree recursively
    void renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font) const;

    // Input handling
    bool handleTouchDown(int32_t x, int32_t y);
    bool handleTouchUp(int32_t x, int32_t y);

    // Text input
    void insertChar(char c);
    void deleteChar();
    void clearInput();
    void submitInput();         // Submit current input as command

    // Command history navigation
    void navigateHistoryUp();
    void navigateHistoryDown();

    // State
    bool isInitialized() const { return state_ == TerminalState::INITIALIZED; }
    TerminalState getState() const { return state_; }

    // Output buffer
    const std::deque<TerminalLine>& getOutputLines() const { return outputLines_; }
    size_t getOutputLineCount() const { return outputLines_.size(); }
    size_t getMaxOutputLines() const { return maxOutputLines_; }
    void setMaxOutputLines(size_t max) { maxOutputLines_ = max; }

    // Input line
    const std::string& getInputText() const;
    void setInputText(const std::string& text);

    // Command history
    const std::vector<HistoryEntry>& getHistory() const { return history_; }
    size_t getHistoryCount() const { return history_.size(); }

    // Working directory
    const std::string& getWorkingDirectory() const { return workingDir_; }
    void setWorkingDirectory(const std::string& dir) { workingDir_ = dir; }

    // Prompt
    std::string getPromptString() const;
    void setPromptPrefix(const std::string& prefix) { promptPrefix_ = prefix; }

    // Built-in command count
    size_t getBuiltinCommandCount() const { return builtinCommands_.size(); }
    bool hasBuiltinCommand(const std::string& name) const;

    // Widget tree
    gui::Widget* getRootWidget() { return root_.get(); }
    const gui::Widget* getRootWidget() const { return root_.get(); }

    // Output callback (called when new output is added)
    using OutputCallback = std::function<void(const TerminalLine&)>;
    void setOutputCallback(OutputCallback cb) { outputCallback_ = cb; }

    // Program executor access
    linux_compat::ProgramExecutor* getProgramExecutor() const { return executor_; }

    // Scroll position
    int32_t getScrollOffset() const { return scrollOffset_; }
    void setScrollOffset(int32_t offset);
    void scrollToBottom();
    void scrollUp(int32_t lines);
    void scrollDown(int32_t lines);

    // Theme
    void applyTheme(const gui::Theme& theme);
    gui::ThemeType getThemeType() const;

private:
    // ============================================================
    // Internal state
    // ============================================================
    TerminalState state_ = TerminalState::IDLE;
    std::unique_ptr<gui::Widget> root_;
    std::unique_ptr<gui::LinearLayout> rootLayout_;
    std::unique_ptr<gui::LinearLayout> outputLayout_;
    std::unique_ptr<gui::LinearLayout> inputLayout_;

    // Widgets
    gui::Widget* outputArea_ = nullptr;     // Container for output text
    gui::Label* outputLabel_ = nullptr;      // Label displaying output text
    gui::TextField* inputField_ = nullptr;  // Input text field
    gui::Label* promptLabel_ = nullptr;     // Prompt prefix label

    // Output buffer
    std::deque<TerminalLine> outputLines_;
    size_t maxOutputLines_ = 100;
    int32_t scrollOffset_ = 0;

    // Command history
    std::vector<HistoryEntry> history_;
    int32_t historyIndex_ = -1;

    // Working directory
    std::string workingDir_ = "/home/user";
    std::string promptPrefix_ = "phantom";

    // Program executor
    linux_compat::ProgramExecutor* executor_ = nullptr;
    bool ownsExecutor_ = false;

    // Built-in commands
    struct BuiltinCommand {
        std::string name;
        std::string description;
        std::function<CommandResult(const std::vector<std::string>&, std::string&)> handler;
    };
    std::vector<BuiltinCommand> builtinCommands_;

    // Output callback
    OutputCallback outputCallback_;

    // ============================================================
    // Private methods
    // ============================================================
    void buildWidgetTree();
    void registerBuiltinCommands();

    void addOutput(const std::string& text, const gui::Color& color = gui::Color::LightGray);
    void addPrompt();
    void addInputEcho(const std::string& input);
    void addError(const std::string& message);
    void trimOutputBuffer();
    void updateOutputLabel();

    std::string formatOutput() const;
    std::vector<std::string> parseArgs(const std::string& input) const;
    std::string joinArgs(const std::vector<std::string>& args, size_t start = 0) const;

    // Built-in command handlers
    CommandResult cmdHelp(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdLs(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdPs(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdKill(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdRun(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdClear(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdVersion(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdUname(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdEcho(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdWhoami(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdPwd(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdCd(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdDate(const std::vector<std::string>& args, std::string& output);
    CommandResult cmdHistory(const std::vector<std::string>& args, std::string& output);
};

}  // namespace phantom::terminal
