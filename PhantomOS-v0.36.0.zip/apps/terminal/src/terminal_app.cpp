/*
 * Phantom OS - Terminal App
 * Implementation of GUI Terminal emulator with Linux Compatibility Layer integration
 *
 * License: GPL-3.0
 */

#include "phantom/terminal/terminal_app.h"
#include "phantom/linux_compat/program_executor.h"
#include "phantom/linux_compat/linux_program.h"
#include <sstream>
#include <algorithm>
#include <cstring>
#include <ctime>

namespace phantom::terminal {

using namespace phantom::gui;
using namespace phantom::linux_compat;

// ============================================================
// Initialization
// ============================================================

void TerminalApp::initialize(ProgramExecutor* executor) {
    if (state_ == TerminalState::INITIALIZED) return;

    // Use provided executor or create internal one
    if (executor) {
        executor_ = executor;
        ownsExecutor_ = false;
    } else {
        executor_ = &ProgramExecutor::getInstance();
        ownsExecutor_ = false;  // Singleton, don't own
    }

    // Register built-in commands
    registerBuiltinCommands();

    // Build widget tree
    buildWidgetTree();

    // Print welcome message
    addOutput("Phantom OS Terminal v0.11.0", Color::Green);
    addOutput("Linux Compatibility Layer: Active", Color::Green);
    addOutput("Type 'help' for available commands.", Color::Green);
    addOutput("", Color::LightGray);

    // Add initial prompt
    addPrompt();

    state_ = TerminalState::INITIALIZED;
}

void TerminalApp::shutdown() {
    if (state_ != TerminalState::INITIALIZED) return;

    root_.reset();
    rootLayout_.reset();
    outputLayout_.reset();
    inputLayout_.reset();
    outputArea_ = nullptr;
    outputLabel_ = nullptr;
    inputField_ = nullptr;
    promptLabel_ = nullptr;

    outputLines_.clear();
    history_.clear();
    historyIndex_ = -1;
    builtinCommands_.clear();
    executor_ = nullptr;
    outputCallback_ = nullptr;

    state_ = TerminalState::SHUTDOWN;
}

// ============================================================
// Widget Tree Construction
// ============================================================

void TerminalApp::buildWidgetTree() {
    root_ = std::make_unique<Widget>();
    root_->setTag("terminal_root");
    root_->setPreferredSize(300, 200);

    rootLayout_ = std::make_unique<LinearLayout>(LayoutOrientation::VERTICAL);
    rootLayout_->setSpacing(0);

    // Output area (scrollable text region)
    auto outputArea = std::make_unique<Widget>();
    outputArea->setTag("terminal_output");
    outputArea->setPreferredSize(300, 170);

    outputLayout_ = std::make_unique<LinearLayout>(LayoutOrientation::VERTICAL);
    outputLayout_->setSpacing(0);

    // Output label (displays all text)
    auto outputLabel = std::make_unique<Label>(0, "");
    outputLabel->setTag("terminal_output_label");
    outputLabel->setTextColor(Color::LightGray);
    outputLabel->setPreferredSize(300, 170);
    outputLabel_ = outputLabel.get();
    outputArea->addChild(std::move(outputLabel));

    outputArea_ = outputArea.get();
    root_->addChild(std::move(outputArea));

    // Input area (prompt + text field)
    auto inputArea = std::make_unique<Widget>();
    inputArea->setTag("terminal_input");
    inputArea->setPreferredSize(300, 14);

    inputLayout_ = std::make_unique<LinearLayout>(LayoutOrientation::HORIZONTAL);
    inputLayout_->setSpacing(1);

    // Prompt label
    auto prompt = std::make_unique<Label>(0, getPromptString());
    prompt->setTag("terminal_prompt");
    prompt->setTextColor(Color::Green);
    prompt->setPreferredSize(60, 14);
    promptLabel_ = prompt.get();
    inputArea->addChild(std::move(prompt));

    // Input text field
    auto inputField = std::make_unique<TextField>(0, "");
    inputField->setTag("terminal_input_field");
    inputField->setTextColor(Color::White);
    inputField->setBackgroundColor(Color::Black);
    inputField->setPreferredSize(240, 14);
    inputField_ = inputField.get();
    inputArea->addChild(std::move(inputField));

    root_->addChild(std::move(inputArea));
}

// ============================================================
// Built-in Commands Registration
// ============================================================

void TerminalApp::registerBuiltinCommands() {
    builtinCommands_.push_back({"help", "Show available commands",
        [this](const auto& args, auto& out) { return cmdHelp(args, out); }});

    builtinCommands_.push_back({"ls", "List directory contents",
        [this](const auto& args, auto& out) { return cmdLs(args, out); }});

    builtinCommands_.push_back({"ps", "Show running processes",
        [this](const auto& args, auto& out) { return cmdPs(args, out); }});

    builtinCommands_.push_back({"kill", "Terminate a process",
        [this](const auto& args, auto& out) { return cmdKill(args, out); }});

    builtinCommands_.push_back({"run", "Execute a registered program",
        [this](const auto& args, auto& out) { return cmdRun(args, out); }});

    builtinCommands_.push_back({"clear", "Clear terminal output",
        [this](const auto& args, auto& out) { return cmdClear(args, out); }});

    builtinCommands_.push_back({"version", "Show Phantom OS version",
        [this](const auto& args, auto& out) { return cmdVersion(args, out); }});

    builtinCommands_.push_back({"uname", "Show system information",
        [this](const auto& args, auto& out) { return cmdUname(args, out); }});

    builtinCommands_.push_back({"echo", "Print text to output",
        [this](const auto& args, auto& out) { return cmdEcho(args, out); }});

    builtinCommands_.push_back({"whoami", "Show current user",
        [this](const auto& args, auto& out) { return cmdWhoami(args, out); }});

    builtinCommands_.push_back({"pwd", "Print working directory",
        [this](const auto& args, auto& out) { return cmdPwd(args, out); }});

    builtinCommands_.push_back({"cd", "Change directory",
        [this](const auto& args, auto& out) { return cmdCd(args, out); }});

    builtinCommands_.push_back({"date", "Show current date and time",
        [this](const auto& args, auto& out) { return cmdDate(args, out); }});

    builtinCommands_.push_back({"history", "Show command history",
        [this](const auto& args, auto& out) { return cmdHistory(args, out); }});
}

// ============================================================
// Command Execution
// ============================================================

CommandResult TerminalApp::executeCommand(const std::string& input) {
    std::string output;
    return executeCommand(input, output);
}

CommandResult TerminalApp::executeCommand(const std::string& input, std::string& outOutput) {
    if (state_ != TerminalState::INITIALIZED) {
        outOutput = "Terminal not initialized";
        return CommandResult::ERROR_;
    }

    // Parse arguments
    auto args = parseArgs(input);
    if (args.empty()) {
        outOutput = "";
        return CommandResult::SUCCESS;
    }

    const std::string& cmdName = args[0];

    // Find built-in command
    for (const auto& cmd : builtinCommands_) {
        if (cmd.name == cmdName) {
            CommandResult result = cmd.handler(args, outOutput);

            // Add output to buffer
            if (!outOutput.empty()) {
                Color color = (result == CommandResult::NOT_FOUND || result == CommandResult::ERROR_)
                              ? Color::Red : Color::LightGray;
                addOutput(outOutput, color);
            }

            // Add to history
            HistoryEntry entry;
            entry.command = input;
            entry.output = outOutput;
            entry.timestamp = static_cast<uint64_t>(std::time(nullptr));
            history_.push_back(entry);
            historyIndex_ = static_cast<int32_t>(history_.size());

            return result;
        }
    }

    // Not a built-in — try ProgramExecutor
    if (executor_) {
        ExecutionOptions opts;
        opts.capture_stdout = true;
        opts.capture_stderr = true;
        if (args.size() > 1) {
            opts.args.assign(args.begin() + 1, args.end());
        }

        ProcessInfo procInfo;
        auto result = executor_->executeProgram(cmdName, opts, &procInfo);

        if (result == ProgramExecutorResult::SUCCESS) {
            outOutput = procInfo.stdout_output;
            if (!procInfo.stderr_output.empty()) {
                if (!outOutput.empty()) outOutput += "\n";
                outOutput += procInfo.stderr_output;
            }

            // Add output to buffer
            if (!outOutput.empty()) {
                addOutput(outOutput, Color::LightGray);
            }

            HistoryEntry entry;
            entry.command = input;
            entry.output = outOutput;
            entry.timestamp = static_cast<uint64_t>(std::time(nullptr));
            history_.push_back(entry);
            historyIndex_ = static_cast<int32_t>(history_.size());

            return CommandResult::SUCCESS;
        } else if (result == ProgramExecutorResult::NOT_REGISTERED ||
                   result == ProgramExecutorResult::NOT_FOUND) {
            outOutput = cmdName + ": command not found";
            addOutput(outOutput, Color::Red);
            return CommandResult::NOT_FOUND;
        } else {
            outOutput = cmdName + ": execution failed (" +
                       std::string(resultToString(result)) + ")";
            addOutput(outOutput, Color::Red);
            return CommandResult::ERROR_;
        }
    }

    outOutput = cmdName + ": command not found";
    addOutput(outOutput, Color::Red);
    return CommandResult::NOT_FOUND;
}

// ============================================================
// Output Buffer Management
// ============================================================

void TerminalApp::addOutput(const std::string& text, const Color& color) {
    // Split by newlines
    std::istringstream stream(text);
    std::string line;
    while (std::getline(stream, line)) {
        TerminalLine tl;
        tl.text = line;
        tl.color = color;
        tl.isPrompt = false;
        tl.isInput = false;
        tl.isError = (color == Color::Red);
        outputLines_.push_back(tl);

        if (outputCallback_) {
            outputCallback_(tl);
        }
    }

    // Handle case where text ends with newline (don't add empty line)
    trimOutputBuffer();
    updateOutputLabel();
}

void TerminalApp::addPrompt() {
    TerminalLine tl;
    tl.text = getPromptString();
    tl.color = Color::Green;
    tl.isPrompt = true;
    outputLines_.push_back(tl);

    if (outputCallback_) {
        outputCallback_(tl);
    }

    trimOutputBuffer();
    updateOutputLabel();
}

void TerminalApp::addInputEcho(const std::string& input) {
    TerminalLine tl;
    tl.text = input;
    tl.color = Color::White;
    tl.isInput = true;
    outputLines_.push_back(tl);

    if (outputCallback_) {
        outputCallback_(tl);
    }

    trimOutputBuffer();
    updateOutputLabel();
}

void TerminalApp::addError(const std::string& message) {
    addOutput(message, Color::Red);
}

void TerminalApp::trimOutputBuffer() {
    while (outputLines_.size() > maxOutputLines_) {
        outputLines_.pop_front();
    }
}

void TerminalApp::clearOutput() {
    outputLines_.clear();
    scrollOffset_ = 0;
    updateOutputLabel();
}

void TerminalApp::updateOutputLabel() {
    if (outputLabel_) {
        outputLabel_->setText(formatOutput());
    }
}

std::string TerminalApp::formatOutput() const {
    std::string result;
    for (const auto& line : outputLines_) {
        if (!result.empty()) result += "\n";
        result += line.text;
    }
    return result;
}

// ============================================================
// Input Handling
// ============================================================

void TerminalApp::insertChar(char c) {
    if (inputField_) {
        inputField_->insertChar(c);
    }
}

void TerminalApp::deleteChar() {
    if (inputField_) {
        inputField_->deleteChar();
    }
}

void TerminalApp::clearInput() {
    if (inputField_) {
        inputField_->clear();
    }
}

void TerminalApp::submitInput() {
    if (!inputField_) return;

    std::string input = inputField_->getText();

    // Echo input to output
    addInputEcho(input);

    // Execute command
    std::string output;
    CommandResult result = executeCommand(input, output);

    // Display output
    if (!output.empty()) {
        Color color = (result == CommandResult::NOT_FOUND || result == CommandResult::ERROR_)
                      ? Color::Red : Color::LightGray;
        addOutput(output, color);
    }

    // Add new prompt
    addPrompt();

    // Clear input field
    clearInput();

    // Update prompt label
    if (promptLabel_) {
        promptLabel_->setText(getPromptString());
    }

    // Scroll to bottom
    scrollToBottom();
}

// ============================================================
// Command History Navigation
// ============================================================

void TerminalApp::navigateHistoryUp() {
    if (history_.empty()) return;

    if (historyIndex_ > 0) {
        historyIndex_--;
        setInputText(history_[historyIndex_].command);
    }
}

void TerminalApp::navigateHistoryDown() {
    if (history_.empty()) return;

    if (historyIndex_ < static_cast<int32_t>(history_.size()) - 1) {
        historyIndex_++;
        setInputText(history_[historyIndex_].command);
    } else {
        historyIndex_ = static_cast<int32_t>(history_.size());
        clearInput();
    }
}

// ============================================================
// Prompt
// ============================================================

std::string TerminalApp::getPromptString() const {
    return promptPrefix_ + ":" + workingDir_ + "$ ";
}

// ============================================================
// Scrolling
// ============================================================

void TerminalApp::setScrollOffset(int32_t offset) {
    scrollOffset_ = std::max(0, offset);
    updateOutputLabel();
}

void TerminalApp::scrollToBottom() {
    scrollOffset_ = 0;
    updateOutputLabel();
}

void TerminalApp::scrollUp(int32_t lines) {
    scrollOffset_ += lines;
    updateOutputLabel();
}

void TerminalApp::scrollDown(int32_t lines) {
    scrollOffset_ = std::max(0, scrollOffset_ - lines);
    updateOutputLabel();
}

// ============================================================
// Layout and Render
// ============================================================

void TerminalApp::layout(int32_t width, int32_t height) {
    if (!root_) return;
    root_->setBounds(Rect(0, 0, width, height));

    if (rootLayout_) {
        rootLayout_->measure(*root_);
        rootLayout_->layout(*root_);
    }

    // Layout output area children
    if (outputArea_ && outputLayout_) {
        outputLayout_->measure(*outputArea_);
        outputLayout_->layout(*outputArea_);
    }

    // Layout input area children
    auto* inputArea = root_->getChild(1);
    if (inputArea && inputLayout_) {
        inputLayout_->measure(*inputArea);
        inputLayout_->layout(*inputArea);
    }
}

void TerminalApp::render(Framebuffer& fb) const {
    if (!root_) return;

    BitmapFont font;
    renderWidget(*root_, fb, font);
}

void TerminalApp::renderWidget(Widget& widget, Framebuffer& fb, const BitmapFont& font) const {
    widget.onRender(fb, font);

    auto children = widget.getChildren();
    for (auto* child : children) {
        if (child && child->isVisible()) {
            renderWidget(*child, fb, font);
        }
    }
}

bool TerminalApp::handleTouchDown(int32_t x, int32_t y) {
    if (!root_) return false;

    // Test children in reverse order (topmost first)
    auto children = root_->getChildren();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        Widget* child = *it;
        if (child && child->isVisible() && child->getBounds().contains(x, y)) {
            if (child->onTouchDown(x, y)) {
                return true;
            }
            // Recurse into children
            auto grandchildren = child->getChildren();
            for (auto it2 = grandchildren.rbegin(); it2 != grandchildren.rend(); ++it2) {
                Widget* grandchild = *it2;
                if (grandchild && grandchild->isVisible() &&
                    grandchild->getBounds().contains(x, y)) {
                    if (grandchild->onTouchDown(x, y)) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

bool TerminalApp::handleTouchUp(int32_t x, int32_t y) {
    if (!root_) return false;

    auto children = root_->getChildren();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        Widget* child = *it;
        if (child && child->isVisible() && child->getBounds().contains(x, y)) {
            if (child->onTouchUp(x, y)) {
                return true;
            }
            auto grandchildren = child->getChildren();
            for (auto it2 = grandchildren.rbegin(); it2 != grandchildren.rend(); ++it2) {
                Widget* grandchild = *it2;
                if (grandchild && grandchild->isVisible() &&
                    grandchild->getBounds().contains(x, y)) {
                    if (grandchild->onTouchUp(x, y)) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

// ============================================================
// Input/Output Accessors
// ============================================================

const std::string& TerminalApp::getInputText() const {
    static std::string empty;
    return inputField_ ? inputField_->getText() : empty;
}

void TerminalApp::setInputText(const std::string& text) {
    if (inputField_) {
        inputField_->setText(text);
        inputField_->setCursorPosition(text.size());
    }
}

// ============================================================
// Theme
// ============================================================

void TerminalApp::applyTheme(const Theme& theme) {
    if (!root_) return;
    root_->applyTheme(theme);

    // Terminal-specific theme
    if (theme.getType() == ThemeType::DARK) {
        if (outputLabel_) outputLabel_->setTextColor(Color::LightGray);
        if (inputField_) {
            inputField_->setTextColor(Color::White);
            inputField_->setBackgroundColor(Color::Black);
        }
        if (promptLabel_) promptLabel_->setTextColor(Color::Green);
    } else {
        if (outputLabel_) outputLabel_->setTextColor(Color::Black);
        if (inputField_) {
            inputField_->setTextColor(Color::Black);
            inputField_->setBackgroundColor(Color::White);
        }
        if (promptLabel_) promptLabel_->setTextColor(Color::Blue);
    }
}

ThemeType TerminalApp::getThemeType() const {
    return ThemeManager::getInstance().getCurrentType();
}

// ============================================================
// Arg Parsing
// ============================================================

std::vector<std::string> TerminalApp::parseArgs(const std::string& input) const {
    std::vector<std::string> args;
    std::string current;
    bool inQuote = false;
    char quoteChar = 0;

    for (size_t i = 0; i < input.size(); ++i) {
        char c = input[i];

        if (inQuote) {
            if (c == quoteChar) {
                inQuote = false;
            } else {
                current += c;
            }
        } else if (c == '"' || c == '\'') {
            inQuote = true;
            quoteChar = c;
        } else if (c == ' ' || c == '\t') {
            if (!current.empty()) {
                args.push_back(current);
                current.clear();
            }
        } else {
            current += c;
        }
    }

    if (!current.empty()) {
        args.push_back(current);
    }

    return args;
}

std::string TerminalApp::joinArgs(const std::vector<std::string>& args, size_t start) const {
    std::string result;
    for (size_t i = start; i < args.size(); ++i) {
        if (!result.empty()) result += " ";
        result += args[i];
    }
    return result;
}

bool TerminalApp::hasBuiltinCommand(const std::string& name) const {
    for (const auto& cmd : builtinCommands_) {
        if (cmd.name == name) return true;
    }
    return false;
}

// ============================================================
// Built-in Command Handlers
// ============================================================

CommandResult TerminalApp::cmdHelp(const std::vector<std::string>&, std::string& output) {
    std::ostringstream ss;
    ss << "Available commands:\n";
    ss << "===================\n";
    for (const auto& cmd : builtinCommands_) {
        ss << "  " << cmd.name;
        // Pad to align descriptions
        for (size_t i = cmd.name.size(); i < 12; ++i) ss << " ";
        ss << cmd.description << "\n";
    }

    if (executor_) {
        auto programs = executor_->getRegisteredPrograms();
        if (!programs.empty()) {
            ss << "\nRegistered Linux programs:\n";
            for (const auto& progId : programs) {
                auto info = executor_->getProgramInfo(progId);
                ss << "  " << progId;
                for (size_t i = progId.size(); i < 12; ++i) ss << " ";
                ss << info.description << "\n";
            }
        }
    }

    output = ss.str();
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdLs(const std::vector<std::string>&, std::string& output) {
    // Simulated directory listing
    std::ostringstream ss;
    ss << "Applications/    Documents/    Downloads/\n";
    ss << "Music/          Pictures/     Videos/\n";
    ss << "System/         tmp/          var/";
    output = ss.str();
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdPs(const std::vector<std::string>&, std::string& output) {
    if (!executor_) {
        output = "No process manager available";
        return CommandResult::ERROR_;
    }

    auto pids = executor_->getRunningProcesses();
    if (pids.empty()) {
        output = "No running processes";
        return CommandResult::SUCCESS;
    }

    std::ostringstream ss;
    ss << "  PID  PROGRAM              STATE\n";
    ss << "  ---  -------              -----\n";

    for (uint32_t pid : pids) {
        auto info = executor_->getProcessInfo(pid);
        ss << "  " << pid;
        // Pad PID
        std::string pidStr = std::to_string(pid);
        for (size_t i = pidStr.size(); i < 5; ++i) ss << " ";

        ss << info.program_id;
        for (size_t i = info.program_id.size(); i < 20; ++i) ss << " ";

        ss << programStateToString(info.state) << "\n";
    }

    output = ss.str();
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdKill(const std::vector<std::string>& args, std::string& output) {
    if (args.size() < 2) {
        output = "Usage: kill <pid>";
        return CommandResult::INVALID_ARGS;
    }

    if (!executor_) {
        output = "No process manager available";
        return CommandResult::ERROR_;
    }

    uint32_t pid = static_cast<uint32_t>(std::strtoul(args[1].c_str(), nullptr, 10));
    auto result = executor_->terminateProcess(pid);

    if (result == ProgramExecutorResult::TERMINATED_OK) {
        output = "Process " + std::to_string(pid) + " terminated";
        return CommandResult::SUCCESS;
    } else if (result == ProgramExecutorResult::NOT_RUNNING) {
        output = "Process " + std::to_string(pid) + " is not running";
        return CommandResult::ERROR_;
    } else if (result == ProgramExecutorResult::ALREADY_EXITED) {
        output = "Process " + std::to_string(pid) + " already exited";
        return CommandResult::ERROR_;
    }

    output = "Failed to terminate process " + std::to_string(pid);
    return CommandResult::ERROR_;
}

CommandResult TerminalApp::cmdRun(const std::vector<std::string>& args, std::string& output) {
    if (args.size() < 2) {
        output = "Usage: run <program_id> [args...]";
        return CommandResult::INVALID_ARGS;
    }

    if (!executor_) {
        output = "No process manager available";
        return CommandResult::ERROR_;
    }

    const std::string& programId = args[1];
    ExecutionOptions opts;
    if (args.size() > 2) {
        opts.args.assign(args.begin() + 2, args.end());
    }
    opts.capture_stdout = true;
    opts.capture_stderr = true;

    uint32_t pid = 0;
    auto result = executor_->startProgram(programId, opts, &pid);

    if (result == ProgramExecutorResult::SUCCESS) {
        output = "Started " + programId + " (PID: " + std::to_string(pid) + ")";
        return CommandResult::SUCCESS;
    } else if (result == ProgramExecutorResult::NOT_REGISTERED) {
        output = "Program '" + programId + "' not registered";
        return CommandResult::NOT_FOUND;
    } else if (result == ProgramExecutorResult::ALREADY_RUNNING) {
        output = "Program '" + programId + "' is already running";
        return CommandResult::ERROR_;
    }

    output = "Failed to start " + programId;
    return CommandResult::ERROR_;
}

CommandResult TerminalApp::cmdClear(const std::vector<std::string>&, std::string& output) {
    clearOutput();
    output = "";
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdVersion(const std::vector<std::string>&, std::string& output) {
    output = "Phantom OS v0.11.0\nTerminal App v0.11.0\nLinux Compatibility Layer v0.9.0";
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdUname(const std::vector<std::string>& args, std::string& output) {
    bool showAll = (args.size() > 1 && args[1] == "-a");

    if (showAll) {
        output = "PhantomOS phantom-os 0.11.0 #1 SMP aarch64 GNU/Linux";
    } else {
        output = "PhantomOS";
    }
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdEcho(const std::vector<std::string>& args, std::string& output) {
    output = joinArgs(args, 1);
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdWhoami(const std::vector<std::string>&, std::string& output) {
    output = "user";
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdPwd(const std::vector<std::string>&, std::string& output) {
    output = workingDir_;
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdCd(const std::vector<std::string>& args, std::string& output) {
    if (args.size() < 2) {
        workingDir_ = "/home/user";
        output = "";
        return CommandResult::SUCCESS;
    }

    const std::string& dir = args[1];

    if (dir == "..") {
        // Go up one directory
        size_t pos = workingDir_.rfind('/');
        if (pos != std::string::npos && pos > 0) {
            workingDir_ = workingDir_.substr(0, pos);
        } else if (pos == 0) {
            workingDir_ = "/";
        }
    } else if (dir[0] == '/') {
        // Absolute path
        workingDir_ = dir;
    } else {
        // Relative path
        if (workingDir_.back() != '/') workingDir_ += '/';
        workingDir_ += dir;
    }

    output = "";
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdDate(const std::vector<std::string>&, std::string& output) {
    std::time_t now = std::time(nullptr);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%a %b %d %H:%M:%S %Z %Y", std::localtime(&now));
    output = buf;
    return CommandResult::SUCCESS;
}

CommandResult TerminalApp::cmdHistory(const std::vector<std::string>&, std::string& output) {
    if (history_.empty()) {
        output = "No commands in history";
        return CommandResult::SUCCESS;
    }

    std::ostringstream ss;
    for (size_t i = 0; i < history_.size(); ++i) {
        ss << "  " << (i + 1) << "  " << history_[i].command << "\n";
    }

    output = ss.str();
    return CommandResult::SUCCESS;
}

}  // namespace phantom::terminal
