/*
 * Phantom OS - File Manager App
 * Implementation of GUI file browser with simulated filesystem
 *
 * License: GPL-3.0
 */

#include "phantom/filemanager/file_manager.h"
#include <sstream>
#include <algorithm>
#include <cstring>
#include <ctime>

namespace phantom::filemanager {

using namespace phantom::gui;

// ============================================================
// File type helpers
// ============================================================

const char* FileManagerApp::fileTypeToString(FileType type) {
    switch (type) {
        case FileType::DIRECTORY: return "DIR";
        case FileType::EXECUTABLE: return "EXE";
        case FileType::CONFIG: return "CFG";
        case FileType::TEXT: return "TXT";
        case FileType::IMAGE: return "IMG";
        case FileType::BINARY: return "BIN";
        default: return "???";
    }
}

const char* FileManagerApp::fileTypeToIcon(FileType type) {
    switch (type) {
        case FileType::DIRECTORY: return "[D]";
        case FileType::EXECUTABLE: return "[X]";
        case FileType::CONFIG: return "[C]";
        case FileType::TEXT: return "[T]";
        case FileType::IMAGE: return "[I]";
        case FileType::BINARY: return "[B]";
        default: return "[?]";
    }
}

FileType FileManagerApp::detectFileType(const std::string& name) {
    if (name.empty()) return FileType::UNKNOWN;

    // Check extension
    size_t dotPos = name.rfind('.');
    if (dotPos != std::string::npos) {
        std::string ext = name.substr(dotPos);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);

        if (ext == ".txt" || ext == ".md" || ext == ".log") return FileType::TEXT;
        if (ext == ".cfg" || ext == ".conf" || ext == ".properties") return FileType::CONFIG;
        if (ext == ".png" || ext == ".jpg" || ext == ".bmp") return FileType::IMAGE;
        if (ext == ".bin" || ext == ".dat" || ext == ".so" || ext == ".a") return FileType::BINARY;
        if (ext == ".sh" || ext == ".bin" || name.find("run") != std::string::npos) return FileType::EXECUTABLE;
    }

    return FileType::UNKNOWN;
}

// ============================================================
// Initialization
// ============================================================

void FileManagerApp::initialize(const std::string& sandboxProfile) {
    if (state_ == FileManagerState::INITIALIZED) return;

    sandboxProfile_ = sandboxProfile;

    // Build simulated filesystem
    buildFilesystem();

    // Start at root
    currentNode_ = rootDir_.get();
    currentPath_ = "/";
    navHistory_.push_back(currentPath_);

    // Build widget tree
    buildWidgetTree();

    // Refresh file list
    refreshFileList();

    // Update path bar and status bar
    updatePathBar();
    updateStatusBar();

    state_ = FileManagerState::INITIALIZED;
}

void FileManagerApp::shutdown() {
    if (state_ != FileManagerState::INITIALIZED) return;

    root_.reset();
    rootLayout_.reset();
    toolbarLayout_.reset();
    pathBar_ = nullptr;
    backButton_ = nullptr;
    upButton_ = nullptr;
    newFolderButton_ = nullptr;
    deleteButton_ = nullptr;
    fileListView_ = nullptr;
    statusBar_ = nullptr;

    rootDir_.reset();
    currentNode_ = nullptr;
    currentPath_.clear();
    navHistory_.clear();
    selectedIndex_ = -1;
    operationCallback_ = nullptr;

    state_ = FileManagerState::SHUTDOWN;
}

// ============================================================
// Simulated Filesystem
// ============================================================

void FileManagerApp::buildFilesystem() {
    rootDir_ = std::make_unique<DirectoryNode>();
    rootDir_->name = "/";
    rootDir_->fullPath = "/";
    rootDir_->parent = nullptr;

    // Helper to add a directory
    auto addDir = [](DirectoryNode* parent, const std::string& name) -> DirectoryNode* {
        auto node = std::make_unique<DirectoryNode>();
        node->name = name;
        node->fullPath = parent->fullPath == "/" ? "/" + name : parent->fullPath + "/" + name;
        node->parent = parent;

        FileEntry entry;
        entry.name = name;
        entry.type = FileType::DIRECTORY;
        entry.isDirectory = true;
        entry.size = 0;
        entry.modifiedDate = "2026-09-19";
        entry.readable = true;
        entry.writable = true;
        parent->entries.push_back(entry);

        DirectoryNode* raw = node.get();
        parent->children.push_back(std::move(node));
        return raw;
    };

    // Helper to add a file
    auto addFile = [](DirectoryNode* parent, const std::string& name, uint64_t size, FileType type) {
        FileEntry entry;
        entry.name = name;
        entry.type = type;
        entry.isDirectory = false;
        entry.size = size;
        entry.modifiedDate = "2026-09-19";
        entry.readable = true;
        entry.writable = (type != FileType::EXECUTABLE);
        entry.executable = (type == FileType::EXECUTABLE);
        parent->entries.push_back(entry);
    };

    // Root level
    auto* home = addDir(rootDir_.get(), "home");
    auto* system = addDir(rootDir_.get(), "System");
    auto* varDir = addDir(rootDir_.get(), "var");
    auto* tmpDir = addDir(rootDir_.get(), "tmp");

    addFile(rootDir_.get(), "README.txt", 1024, FileType::TEXT);
    addFile(rootDir_.get(), "LICENSE", 35149, FileType::TEXT);

    // /home/user
    auto* user = addDir(home, "user");
    auto* docs = addDir(user, "Documents");
    auto* downloads = addDir(user, "Downloads");
    auto* music = addDir(user, "Music");
    auto* pictures = addDir(user, "Pictures");
    auto* videos = addDir(user, "Videos");
    auto* apps = addDir(user, "Applications");

    addFile(user, "profile.cfg", 512, FileType::CONFIG);
    addFile(user, "notes.txt", 2048, FileType::TEXT);
    addFile(user, "phantom.sh", 256, FileType::EXECUTABLE);

    // /home/user/Documents
    addFile(docs, "manual.txt", 8192, FileType::TEXT);
    addFile(docs, "changelog.md", 4096, FileType::TEXT);
    addFile(docs, "config.conf", 1024, FileType::CONFIG);

    // /home/user/Downloads
    addFile(downloads, "update.bin", 10485760, FileType::BINARY);
    addFile(downloads, "image.png", 524288, FileType::IMAGE);

    // /home/user/Pictures
    addFile(pictures, "wallpaper.png", 2097152, FileType::IMAGE);
    addFile(pictures, "screenshot.png", 1048576, FileType::IMAGE);

    // /home/user/Applications
    addFile(apps, "settings.app", 65536, FileType::BINARY);
    addFile(apps, "terminal.app", 65536, FileType::BINARY);

    // /System
    auto* sysConfig = addDir(system, "config");
    auto* sysLogs = addDir(system, "logs");
    auto* sysLib = addDir(system, "lib");

    addFile(sysConfig, "phantom.conf", 2048, FileType::CONFIG);
    addFile(sysConfig, "network.conf", 1024, FileType::CONFIG);

    addFile(sysLogs, "system.log", 16384, FileType::TEXT);
    addFile(sysLogs, "error.log", 8192, FileType::TEXT);

    addFile(sysLib, "libphantom.so", 524288, FileType::BINARY);
    addFile(sysLib, "libgui.so", 262144, FileType::BINARY);

    // /var
    addFile(varDir, "data.bin", 4096, FileType::BINARY);
    addFile(varDir, "cache.dat", 1024, FileType::BINARY);

    // /tmp
    addFile(tmpDir, "temp.tmp", 0, FileType::UNKNOWN);
}

// ============================================================
// Widget Tree
// ============================================================

void FileManagerApp::buildWidgetTree() {
    root_ = std::make_unique<Widget>();
    root_->setTag("filemanager_root");
    root_->setPreferredSize(300, 200);

    rootLayout_ = std::make_unique<LinearLayout>(LayoutOrientation::VERTICAL);
    rootLayout_->setSpacing(1);

    // Path bar
    auto pathBar = std::make_unique<Label>(0, getPathBarText());
    pathBar->setTag("path_bar");
    pathBar->setTextColor(Color::Green);
    pathBar->setPreferredSize(300, 14);
    pathBar_ = pathBar.get();
    root_->addChild(std::move(pathBar));

    // Toolbar (horizontal)
    auto toolbar = std::make_unique<Widget>();
    toolbar->setTag("toolbar");
    toolbar->setPreferredSize(300, 14);

    toolbarLayout_ = std::make_unique<LinearLayout>(LayoutOrientation::HORIZONTAL);
    toolbarLayout_->setSpacing(2);

    auto backBtn = std::make_unique<Button>(0, "Back");
    backBtn->setTag("btn_back");
    backBtn->setPreferredSize(50, 14);
    backBtn->setOnClick([this](Widget*) { navigateBack(); });
    backButton_ = backBtn.get();
    toolbar->addChild(std::move(backBtn));

    auto upBtn = std::make_unique<Button>(0, "Up");
    upBtn->setTag("btn_up");
    upBtn->setPreferredSize(50, 14);
    upBtn->setOnClick([this](Widget*) { navigateUp(); });
    upButton_ = upBtn.get();
    toolbar->addChild(std::move(upBtn));

    auto newFolderBtn = std::make_unique<Button>(0, "New Dir");
    newFolderBtn->setTag("btn_new");
    newFolderBtn->setPreferredSize(60, 14);
    newFolderBtn->setOnClick([this](Widget*) {
        if (operationCallback_) {
            operationCallback_(FileOperation::CREATE_FOLDER, OperationResult::SUCCESS, "");
        }
    });
    newFolderButton_ = newFolderBtn.get();
    toolbar->addChild(std::move(newFolderBtn));

    auto delBtn = std::make_unique<Button>(0, "Delete");
    delBtn->setTag("btn_del");
    delBtn->setPreferredSize(60, 14);
    delBtn->setOnClick([this](Widget*) {
        if (selectedIndex_ >= 0 && operationCallback_) {
            auto entry = getSelectedEntry();
            operationCallback_(FileOperation::DELETE, OperationResult::SUCCESS, entry.name);
        }
    });
    deleteButton_ = delBtn.get();
    toolbar->addChild(std::move(delBtn));

    root_->addChild(std::move(toolbar));

    // File list (ListView)
    auto fileList = std::make_unique<ListView>(0, 0);
    fileList->setTag("file_list");
    fileList->setPreferredSize(300, 160);
    fileList->setItemHeight(12);
    fileList->setBgColor(Color::Black);
    fileList->setSelectedBgColor(Color::Blue);
    fileList->setItemTextColor(Color::LightGray);
    fileList->setSelectedTextColor(Color::White);

    fileList->setItemTextCallback([this](size_t index) -> std::string {
        if (!currentNode_ || index >= currentNode_->entries.size()) return "";
        const auto& entry = currentNode_->entries[index];
        std::string icon = fileTypeToIcon(entry.type);
        return icon + " " + entry.name;
    });

    fileList->setItemClickCallback([this](size_t index) {
        if (!currentNode_ || index >= currentNode_->entries.size()) return;
        const auto& entry = currentNode_->entries[index];
        if (entry.isDirectory) {
            navigateInto(entry.name);
        }
    });

    fileListView_ = fileList.get();
    root_->addChild(std::move(fileList));

    // Status bar
    auto status = std::make_unique<Label>(0, getStatusBarText());
    status->setTag("status_bar");
    status->setTextColor(Color::LightGray);
    status->setPreferredSize(300, 12);
    statusBar_ = status.get();
    root_->addChild(std::move(status));
}

// ============================================================
// Navigation
// ============================================================

OperationResult FileManagerApp::navigateTo(const std::string& path) {
    std::string normPath = normalizePath(path);

    DirectoryNode* node = findNode(normPath);
    if (!node) {
        if (operationCallback_) {
            operationCallback_(FileOperation::NAVIGATE_INTO, OperationResult::NOT_FOUND, path);
        }
        return OperationResult::NOT_FOUND;
    }

    currentNode_ = node;
    currentPath_ = normPath;
    navHistory_.push_back(currentPath_);
    selectedIndex_ = -1;

    refreshFileList();
    updatePathBar();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::NAVIGATE_INTO, OperationResult::SUCCESS, normPath);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::navigateUp() {
    if (!currentNode_ || !currentNode_->parent) {
        return OperationResult::INVALID_PATH;
    }

    currentNode_ = currentNode_->parent;
    currentPath_ = currentNode_->fullPath;
    navHistory_.push_back(currentPath_);
    selectedIndex_ = -1;

    refreshFileList();
    updatePathBar();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::NAVIGATE_UP, OperationResult::SUCCESS, currentPath_);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::navigateInto(const std::string& dirName) {
    if (!currentNode_) return OperationResult::INVALID_PATH;

    DirectoryNode* child = findChildNode(currentNode_, dirName);
    if (!child) {
        if (operationCallback_) {
            operationCallback_(FileOperation::NAVIGATE_INTO, OperationResult::NOT_FOUND, dirName);
        }
        return OperationResult::NOT_FOUND;
    }

    currentNode_ = child;
    currentPath_ = child->fullPath;
    navHistory_.push_back(currentPath_);
    selectedIndex_ = -1;

    refreshFileList();
    updatePathBar();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::NAVIGATE_INTO, OperationResult::SUCCESS, dirName);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::navigateBack() {
    if (navHistory_.size() < 2) {
        return OperationResult::INVALID_PATH;
    }

    // Remove current entry
    navHistory_.pop_back();

    // Get previous path
    std::string prevPath = navHistory_.back();

    DirectoryNode* node = findNode(prevPath);
    if (!node) {
        navHistory_.push_back(currentPath_);
        return OperationResult::NOT_FOUND;
    }

    currentNode_ = node;
    currentPath_ = prevPath;
    selectedIndex_ = -1;

    refreshFileList();
    updatePathBar();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::NAVIGATE_UP, OperationResult::SUCCESS, prevPath);
    }

    return OperationResult::SUCCESS;
}

// ============================================================
// File Operations
// ============================================================

OperationResult FileManagerApp::createFolder(const std::string& name) {
    if (!currentNode_) return OperationResult::INVALID_PATH;
    if (name.empty()) return OperationResult::INVALID_NAME;

    // Check if already exists
    for (const auto& entry : currentNode_->entries) {
        if (entry.name == name) {
            if (operationCallback_) {
                operationCallback_(FileOperation::CREATE_FOLDER, OperationResult::ALREADY_EXISTS, name);
            }
            return OperationResult::ALREADY_EXISTS;
        }
    }

    // Create new directory entry
    FileEntry entry;
    entry.name = name;
    entry.type = FileType::DIRECTORY;
    entry.isDirectory = true;
    entry.size = 0;
    entry.modifiedDate = formatDate();
    entry.readable = true;
    entry.writable = true;
    currentNode_->entries.push_back(entry);

    // Create child node
    auto node = std::make_unique<DirectoryNode>();
    node->name = name;
    node->fullPath = (currentPath_ == "/") ? "/" + name : currentPath_ + "/" + name;
    node->parent = currentNode_;
    currentNode_->children.push_back(std::move(node));

    refreshFileList();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::CREATE_FOLDER, OperationResult::SUCCESS, name);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::deleteEntry(const std::string& name) {
    if (!currentNode_) return OperationResult::INVALID_PATH;

    auto it = std::find_if(currentNode_->entries.begin(), currentNode_->entries.end(),
        [&](const FileEntry& e) { return e.name == name; });

    if (it == currentNode_->entries.end()) {
        if (operationCallback_) {
            operationCallback_(FileOperation::DELETE, OperationResult::NOT_FOUND, name);
        }
        return OperationResult::NOT_FOUND;
    }

    // Check if directory has children
    if (it->isDirectory) {
        DirectoryNode* child = findChildNode(currentNode_, name);
        if (child && !child->entries.empty()) {
            if (operationCallback_) {
                operationCallback_(FileOperation::DELETE, OperationResult::NOT_EMPTY, name);
            }
            return OperationResult::NOT_EMPTY;
        }
    }

    // Remove from entries
    currentNode_->entries.erase(it);

    // Remove child node if it's a directory
    if (it == currentNode_->entries.end()) {
        // Already erased, check children
    }
    auto childIt = std::find_if(currentNode_->children.begin(), currentNode_->children.end(),
        [&](const std::unique_ptr<DirectoryNode>& n) { return n->name == name; });
    if (childIt != currentNode_->children.end()) {
        currentNode_->children.erase(childIt);
    }

    if (selectedIndex_ >= static_cast<int32_t>(currentNode_->entries.size())) {
        selectedIndex_ = -1;
    }

    refreshFileList();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::DELETE, OperationResult::SUCCESS, name);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::renameEntry(const std::string& oldName, const std::string& newName) {
    if (!currentNode_) return OperationResult::INVALID_PATH;
    if (newName.empty()) return OperationResult::INVALID_NAME;

    // Check if new name already exists
    for (const auto& entry : currentNode_->entries) {
        if (entry.name == newName) {
            return OperationResult::ALREADY_EXISTS;
        }
    }

    // Find entry
    auto it = std::find_if(currentNode_->entries.begin(), currentNode_->entries.end(),
        [&](const FileEntry& e) { return e.name == oldName; });

    if (it == currentNode_->entries.end()) {
        return OperationResult::NOT_FOUND;
    }

    // Rename entry
    it->name = newName;
    it->type = detectFileType(newName);
    it->modifiedDate = formatDate();

    // Rename child node if directory
    if (it->isDirectory) {
        auto childIt = std::find_if(currentNode_->children.begin(), currentNode_->children.end(),
            [&](const std::unique_ptr<DirectoryNode>& n) { return n->name == oldName; });
        if (childIt != currentNode_->children.end()) {
            (*childIt)->name = newName;
            (*childIt)->fullPath = (currentPath_ == "/") ? "/" + newName : currentPath_ + "/" + newName;
        }
    }

    refreshFileList();
    updateStatusBar();

    if (operationCallback_) {
        operationCallback_(FileOperation::RENAME, OperationResult::SUCCESS, oldName + " -> " + newName);
    }

    return OperationResult::SUCCESS;
}

OperationResult FileManagerApp::copyEntry(const std::string& name, const std::string& destPath) {
    if (!currentNode_) return OperationResult::INVALID_PATH;

    auto it = std::find_if(currentNode_->entries.begin(), currentNode_->entries.end(),
        [&](const FileEntry& e) { return e.name == name; });

    if (it == currentNode_->entries.end()) {
        return OperationResult::NOT_FOUND;
    }

    DirectoryNode* destNode = findNode(destPath);
    if (!destNode) {
        return OperationResult::INVALID_PATH;
    }

    // Check if already exists at destination
    for (const auto& entry : destNode->entries) {
        if (entry.name == name) {
            return OperationResult::ALREADY_EXISTS;
        }
    }

    // Copy entry
    FileEntry copy = *it;
    destNode->entries.push_back(copy);

    if (operationCallback_) {
        operationCallback_(FileOperation::NONE, OperationResult::SUCCESS, name + " -> " + destPath);
    }

    return OperationResult::SUCCESS;
}

// ============================================================
// Query
// ============================================================

std::vector<FileEntry> FileManagerApp::listCurrentDirectory() const {
    if (!currentNode_) return {};
    return sortEntries(currentNode_->entries);
}

size_t FileManagerApp::getFileCount() const {
    if (!currentNode_) return 0;
    size_t count = 0;
    for (const auto& e : currentNode_->entries) {
        if (!e.isDirectory) count++;
    }
    return count;
}

size_t FileManagerApp::getDirectoryCount() const {
    if (!currentNode_) return 0;
    size_t count = 0;
    for (const auto& e : currentNode_->entries) {
        if (e.isDirectory) count++;
    }
    return count;
}

bool FileManagerApp::entryExists(const std::string& name) const {
    if (!currentNode_) return false;
    for (const auto& e : currentNode_->entries) {
        if (e.name == name) return true;
    }
    return false;
}

FileEntry FileManagerApp::getEntry(const std::string& name) const {
    if (!currentNode_) return FileEntry{};
    for (const auto& e : currentNode_->entries) {
        if (e.name == name) return e;
    }
    return FileEntry{};
}

// ============================================================
// Selection
// ============================================================

void FileManagerApp::setSelectedIndex(int32_t index) {
    selectedIndex_ = index;
    if (fileListView_) {
        fileListView_->setSelectedIndex(index);
    }
    updateStatusBar();
}

FileEntry FileManagerApp::getSelectedEntry() const {
    if (!currentNode_ || selectedIndex_ < 0 ||
        static_cast<size_t>(selectedIndex_) >= currentNode_->entries.size()) {
        return FileEntry{};
    }
    return currentNode_->entries[selectedIndex_];
}

std::string FileManagerApp::getSelectedPath() const {
    auto entry = getSelectedEntry();
    if (entry.name.empty()) return "";
    if (currentPath_ == "/") return "/" + entry.name;
    return currentPath_ + "/" + entry.name;
}

// ============================================================
// Layout and Render
// ============================================================

void FileManagerApp::layout(int32_t width, int32_t height) {
    if (!root_) return;
    root_->setBounds(Rect(0, 0, width, height));

    if (rootLayout_) {
        rootLayout_->measure(*root_);
        rootLayout_->layout(*root_);
    }

    // Layout toolbar children
    auto* toolbar = root_->getChild(1);
    if (toolbar && toolbarLayout_) {
        toolbarLayout_->measure(*toolbar);
        toolbarLayout_->layout(*toolbar);
    }
}

void FileManagerApp::render(Framebuffer& fb) const {
    if (!root_) return;
    BitmapFont font;
    renderWidget(*root_, fb, font);
}

void FileManagerApp::renderWidget(Widget& widget, Framebuffer& fb, const BitmapFont& font) const {
    widget.onRender(fb, font);
    auto children = widget.getChildren();
    for (auto* child : children) {
        if (child && child->isVisible()) {
            renderWidget(*child, fb, font);
        }
    }
}

bool FileManagerApp::handleTouchDown(int32_t x, int32_t y) {
    if (!root_) return false;
    return handleTouchDownRecursive(*root_, x, y);
}

bool FileManagerApp::handleTouchDownRecursive(Widget& widget, int32_t x, int32_t y) {
    auto children = widget.getChildren();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        Widget* child = *it;
        if (child && child->isVisible() && child->getBounds().contains(x, y)) {
            if (handleTouchDownRecursive(*child, x, y)) return true;
        }
    }
    if (widget.containsPoint(x, y)) {
        if (widget.onTouchDown(x, y)) return true;
    }
    return false;
}

bool FileManagerApp::handleTouchUp(int32_t x, int32_t y) {
    if (!root_) return false;
    return handleTouchUpRecursive(*root_, x, y);
}

bool FileManagerApp::handleTouchUpRecursive(Widget& widget, int32_t x, int32_t y) {
    auto children = widget.getChildren();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        Widget* child = *it;
        if (child && child->isVisible() && child->getBounds().contains(x, y)) {
            if (handleTouchUpRecursive(*child, x, y)) return true;
        }
    }
    if (widget.containsPoint(x, y)) {
        if (widget.onTouchUp(x, y)) return true;
    }
    return false;
}

// ============================================================
// Path Bar and Status Bar
// ============================================================

void FileManagerApp::updatePathBar() {
    if (pathBar_) {
        pathBar_->setText(getPathBarText());
    }
}

std::string FileManagerApp::getPathBarText() const {
    return "Path: " + currentPath_;
}

void FileManagerApp::updateStatusBar() {
    if (statusBar_) {
        statusBar_->setText(getStatusBarText());
    }
}

std::string FileManagerApp::getStatusBarText() const {
    std::ostringstream ss;
    size_t dirs = getDirectoryCount();
    size_t files = getFileCount();
    ss << dirs << " dirs, " << files << " files";

    if (selectedIndex_ >= 0) {
        auto entry = getSelectedEntry();
        if (!entry.name.empty()) {
            ss << " | Selected: " << entry.name;
            if (!entry.isDirectory) {
                ss << " (" << formatSize(entry.size) << ")";
            }
        }
    }

    return ss.str();
}

// ============================================================
// Breadcrumbs
// ============================================================

std::vector<std::string> FileManagerApp::getBreadcrumbs() const {
    std::vector<std::string> crumbs;
    if (currentPath_.empty()) return crumbs;

    std::string path = currentPath_;
    if (path[0] == '/') path = path.substr(1);

    std::istringstream stream(path);
    std::string segment;
    while (std::getline(stream, segment, '/')) {
        if (!segment.empty()) crumbs.push_back(segment);
    }

    return crumbs;
}

size_t FileManagerApp::getBreadcrumbCount() const {
    return getBreadcrumbs().size();
}

// ============================================================
// Sandbox
// ============================================================

bool FileManagerApp::isPathAllowed(const std::string& path) const {
    // Default sandbox: allow /home/user and /tmp
    if (sandboxProfile_ == "default") {
        return path.find("/home/user") == 0 || path.find("/tmp") == 0 || path == "/";
    }
    // Restricted: only /home/user
    if (sandboxProfile_ == "restricted") {
        return path.find("/home/user") == 0;
    }
    // Full access
    if (sandboxProfile_ == "full") {
        return true;
    }
    return true;
}

// ============================================================
// Theme
// ============================================================

void FileManagerApp::applyTheme(const Theme& theme) {
    if (!root_) return;
    root_->applyTheme(theme);

    if (theme.getType() == ThemeType::DARK) {
        if (pathBar_) pathBar_->setTextColor(Color::Green);
        if (statusBar_) statusBar_->setTextColor(Color::LightGray);
        if (fileListView_) {
            fileListView_->setBgColor(Color::Black);
            fileListView_->setSelectedBgColor(Color::Blue);
            fileListView_->setItemTextColor(Color::LightGray);
            fileListView_->setSelectedTextColor(Color::White);
        }
    } else {
        if (pathBar_) pathBar_->setTextColor(Color::Blue);
        if (statusBar_) statusBar_->setTextColor(Color::Black);
        if (fileListView_) {
            fileListView_->setBgColor(Color::White);
            fileListView_->setSelectedBgColor(Color::Blue);
            fileListView_->setItemTextColor(Color::Black);
            fileListView_->setSelectedTextColor(Color::White);
        }
    }
}

// ============================================================
// Private Helpers
// ============================================================

void FileManagerApp::refreshFileList() {
    if (!fileListView_ || !currentNode_) return;
    fileListView_->setItemCount(currentNode_->entries.size());
    fileListView_->setSelectedIndex(selectedIndex_);
}

DirectoryNode* FileManagerApp::findNode(const std::string& path) {
    if (path == "/" || path.empty()) return rootDir_.get();

    std::string normPath = normalizePath(path);
    if (normPath == "/") return rootDir_.get();

    // Split path and traverse
    std::string pathStr = normPath;
    if (pathStr[0] == '/') pathStr = pathStr.substr(1);

    DirectoryNode* node = rootDir_.get();
    std::istringstream stream(pathStr);
    std::string segment;
    while (std::getline(stream, segment, '/')) {
        if (segment.empty()) continue;
        DirectoryNode* child = findChildNode(node, segment);
        if (!child) return nullptr;
        node = child;
    }

    return node;
}

DirectoryNode* FileManagerApp::findChildNode(DirectoryNode* parent, const std::string& name) {
    if (!parent) return nullptr;
    for (auto& child : parent->children) {
        if (child->name == name) return child.get();
    }
    return nullptr;
}

std::string FileManagerApp::normalizePath(const std::string& path) const {
    std::string result = path;
    // Remove trailing slashes
    while (result.size() > 1 && result.back() == '/') {
        result.pop_back();
    }
    // Ensure leading slash
    if (result.empty() || result[0] != '/') {
        result = "/" + result;
    }
    return result;
}

std::string FileManagerApp::formatSize(uint64_t bytes) const {
    if (bytes == 0) return "0B";
    if (bytes < 1024) return std::to_string(bytes) + "B";
    if (bytes < 1048576) return std::to_string(bytes / 1024) + "K";
    if (bytes < 1073741824) return std::to_string(bytes / 1048576) + "M";
    return std::to_string(bytes / 1073741824) + "G";
}

std::string FileManagerApp::formatDate() const {
    std::time_t now = std::time(nullptr);
    char buf[16];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d", std::localtime(&now));
    return buf;
}

std::vector<FileEntry> FileManagerApp::sortEntries(const std::vector<FileEntry>& entries) const {
    std::vector<FileEntry> sorted = entries;
    std::sort(sorted.begin(), sorted.end(), [](const FileEntry& a, const FileEntry& b) {
        // Directories first
        if (a.isDirectory && !b.isDirectory) return true;
        if (!a.isDirectory && b.isDirectory) return false;
        // Then alphabetical
        return a.name < b.name;
    });
    return sorted;
}

}  // namespace phantom::filemanager
