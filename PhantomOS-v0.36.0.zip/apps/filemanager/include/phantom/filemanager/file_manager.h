/*
 * Phantom OS - File Manager App
 * GUI file browser with simulated filesystem and sandbox integration
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/layout.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/color.h"
#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <unordered_map>

namespace phantom::gui { class BitmapFont; }

namespace phantom::filemanager {

// ============================================================
// Enums
// ============================================================

enum class FileManagerState {
    IDLE,
    INITIALIZED,
    SHUTDOWN
};

enum class FileType {
    DIRECTORY,
    EXECUTABLE,
    CONFIG,
    TEXT,
    IMAGE,
    BINARY,
    UNKNOWN
};

enum class FileOperation {
    NONE,
    CREATE_FOLDER,
    DELETE,
    RENAME,
    NAVIGATE_UP,
    NAVIGATE_INTO
};

enum class OperationResult {
    SUCCESS,
    NOT_FOUND,
    ALREADY_EXISTS,
    INVALID_NAME,
    PERMISSION_DENIED,
    NOT_EMPTY,
    INVALID_PATH,
    INVALID_TYPE
};

// ============================================================
// Structs
// ============================================================

struct FileEntry {
    std::string name;
    FileType type = FileType::UNKNOWN;
    uint64_t size = 0;
    std::string modifiedDate;
    bool isDirectory = false;
    bool readable = true;
    bool writable = true;
    bool executable = false;
};

struct DirectoryNode {
    std::string name;
    std::string fullPath;
    std::vector<FileEntry> entries;
    DirectoryNode* parent = nullptr;
    std::vector<std::unique_ptr<DirectoryNode>> children;
};

// ============================================================
// FileManagerApp
// ============================================================

class FileManagerApp {
public:
    FileManagerApp() = default;
    ~FileManagerApp() { shutdown(); }

    // Initialize with optional sandbox profile
    void initialize(const std::string& sandboxProfile = "default");

    // Shutdown and cleanup
    void shutdown();

    // Navigation
    OperationResult navigateTo(const std::string& path);
    OperationResult navigateUp();
    OperationResult navigateInto(const std::string& dirName);
    std::string getCurrentPath() const { return currentPath_; }

    // File operations
    OperationResult createFolder(const std::string& name);
    OperationResult deleteEntry(const std::string& name);
    OperationResult renameEntry(const std::string& oldName, const std::string& newName);
    OperationResult copyEntry(const std::string& name, const std::string& destPath);

    // Query
    std::vector<FileEntry> listCurrentDirectory() const;
    size_t getFileCount() const;
    size_t getDirectoryCount() const;
    bool entryExists(const std::string& name) const;
    FileEntry getEntry(const std::string& name) const;

    // Selection
    void setSelectedIndex(int32_t index);
    int32_t getSelectedIndex() const { return selectedIndex_; }
    FileEntry getSelectedEntry() const;
    std::string getSelectedPath() const;

    // Layout and render
    void layout(int32_t width, int32_t height);
    void render(gui::Framebuffer& fb) const;
    void renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font) const;

    // Input handling
    bool handleTouchDown(int32_t x, int32_t y);
    bool handleTouchUp(int32_t x, int32_t y);

    // Recursive touch helpers
    bool handleTouchDownRecursive(gui::Widget& widget, int32_t x, int32_t y);
    bool handleTouchUpRecursive(gui::Widget& widget, int32_t x, int32_t y);

    // State
    bool isInitialized() const { return state_ == FileManagerState::INITIALIZED; }
    FileManagerState getState() const { return state_; }

    // Widget tree
    gui::Widget* getRootWidget() { return root_.get(); }
    const gui::Widget* getRootWidget() const { return root_.get(); }

    // Path bar
    void updatePathBar();
    std::string getPathBarText() const;

    // Status bar
    void updateStatusBar();
    std::string getStatusBarText() const;

    // File operations callback
    using OperationCallback = std::function<void(FileOperation, OperationResult, const std::string&)>;
    void setOperationCallback(OperationCallback cb) { operationCallback_ = cb; }

    // Sandbox
    const std::string& getSandboxProfile() const { return sandboxProfile_; }
    bool isPathAllowed(const std::string& path) const;

    // Simulated filesystem
    void buildFilesystem();
    const DirectoryNode* getRootNode() const { return rootDir_.get(); }
    DirectoryNode* getCurrentNode() { return currentNode_; }
    const DirectoryNode* getCurrentNode() const { return currentNode_; }

    // File type helpers
    static const char* fileTypeToString(FileType type);
    static const char* fileTypeToIcon(FileType type);
    static FileType detectFileType(const std::string& name);

    // Theme
    void applyTheme(const gui::Theme& theme);

    // Breadcrumb navigation
    std::vector<std::string> getBreadcrumbs() const;
    size_t getBreadcrumbCount() const;

    // History
    const std::vector<std::string>& getNavigationHistory() const { return navHistory_; }
    size_t getHistoryCount() const { return navHistory_.size(); }
    OperationResult navigateBack();

private:
    // State
    FileManagerState state_ = FileManagerState::IDLE;

    // Widget tree
    std::unique_ptr<gui::Widget> root_;
    std::unique_ptr<gui::LinearLayout> rootLayout_;
    std::unique_ptr<gui::LinearLayout> toolbarLayout_;

    // Widgets
    gui::Label* pathBar_ = nullptr;
    gui::Button* backButton_ = nullptr;
    gui::Button* upButton_ = nullptr;
    gui::Button* newFolderButton_ = nullptr;
    gui::Button* deleteButton_ = nullptr;
    gui::ListView* fileListView_ = nullptr;
    gui::Label* statusBar_ = nullptr;

    // Simulated filesystem
    std::unique_ptr<DirectoryNode> rootDir_;
    DirectoryNode* currentNode_ = nullptr;
    std::string currentPath_;

    // Selection
    int32_t selectedIndex_ = -1;

    // Sandbox
    std::string sandboxProfile_ = "default";

    // Navigation history
    std::vector<std::string> navHistory_;

    // Operation callback
    OperationCallback operationCallback_;

    // Private methods
    void buildWidgetTree();
    void refreshFileList();
    DirectoryNode* findNode(const std::string& path);
    DirectoryNode* findChildNode(DirectoryNode* parent, const std::string& name);
    std::string normalizePath(const std::string& path) const;
    std::string formatSize(uint64_t bytes) const;
    std::string formatDate() const;
    std::vector<FileEntry> sortEntries(const std::vector<FileEntry>& entries) const;
};

}  // namespace phantom::filemanager
