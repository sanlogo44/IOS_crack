/*
 * Phantom OS - Settings App Implementation
 * Prototype settings application integrating GUI, Config, Privacy, Theme, and HAL
 *
 * License: GPL-3.0
 */

#include "phantom/settings/settings_app.h"
#include "phantom/hal/hal_interfaces.h"
#include "mock_hal_factory.h"
#include <cstdio>
#include <cstring>
#include <algorithm>

namespace phantom::settings {

// ============================================================
// Constructor / Destructor
// ============================================================

SettingsApp::SettingsApp() {
    // Define default config properties
    config_.defineProperty("display.brightness", config::PropertyType::INTEGER, "128",
                           "Screen brightness (0-255)");
    config_.defineProperty("display.theme", config::PropertyType::STRING, "DARK",
                           "Theme type (DARK, LIGHT, CUSTOM)");
    config_.defineProperty("privacy.profile", config::PropertyType::STRING, "NORMAL",
                           "Privacy profile level");
    config_.defineProperty("privacy.telemetry", config::PropertyType::BOOLEAN, "false",
                           "Enable telemetry");
    config_.defineProperty("privacy.crash_reports", config::PropertyType::BOOLEAN, "false",
                           "Enable crash reports");
    config_.defineProperty("privacy.analytics", config::PropertyType::BOOLEAN, "false",
                           "Enable analytics");
    config_.defineProperty("privacy.tracking", config::PropertyType::BOOLEAN, "false",
                           "Enable tracking");
    config_.defineProperty("privacy.location_accuracy", config::PropertyType::STRING, "NONE",
                           "Location accuracy level");
    config_.defineProperty("system.os_version", config::PropertyType::STRING, "0.10.0",
                           "OS version");
    config_.defineProperty("system.device", config::PropertyType::STRING, "iPhone X (A11)",
                           "Device model");
}

SettingsApp::~SettingsApp() {
    shutdown();
}

// ============================================================
// Lifecycle
// ============================================================

bool SettingsApp::initialize(hal::IHalFactory* factory) {
    if (initialized_) return true;

    // Create or use provided HAL factory
    if (factory) {
        halFactory_ = factory;
    } else {
        ownedFactory_ = hal::createMockHalFactory();
        halFactory_ = ownedFactory_;
    }

    if (!halFactory_) return false;

    // Initialize HAL instances
    halFactory_->createDisplay(&displayHal_);
    if (displayHal_) displayHal_->init();
    halFactory_->createPower(&powerHal_);
    if (powerHal_) powerHal_->init();
    halFactory_->createStorage(&storageHal_);
    if (storageHal_) storageHal_->init();
    halFactory_->createNetwork(&networkHal_);
    if (networkHal_) networkHal_->init();

    // Build the widget tree
    buildRoot();

    // Load initial config values
    brightness_ = static_cast<int>(config_.getInt("display.brightness"));
    telemetryEnabled_ = config_.getBool("privacy.telemetry");
    crashReportsEnabled_ = config_.getBool("privacy.crash_reports");
    analyticsEnabled_ = config_.getBool("privacy.analytics");
    trackingEnabled_ = config_.getBool("privacy.tracking");

    // Refresh hardware info from HAL
    refreshHardwareInfo();

    initialized_ = true;
    return true;
}

void SettingsApp::shutdown() {
    if (!initialized_) return;

    // Release HAL instances
    if (halFactory_) {
        if (displayHal_) { displayHal_->deinit(); halFactory_->destroyDisplay(displayHal_); displayHal_ = nullptr; }
        if (powerHal_) { powerHal_->deinit(); halFactory_->destroyPower(powerHal_); powerHal_ = nullptr; }
        if (storageHal_) { storageHal_->deinit(); halFactory_->destroyStorage(storageHal_); storageHal_ = nullptr; }
        if (networkHal_) { networkHal_->deinit(); halFactory_->destroyNetwork(networkHal_); networkHal_ = nullptr; }
    }

    if (ownedFactory_) {
        delete ownedFactory_;
        ownedFactory_ = nullptr;
        halFactory_ = nullptr;
    }

    // Clear widget tree and layouts
    root_.reset();
    rootLayout_.reset();
    navLayout_.reset();
    displayLayout_.reset();
    privacyLayout_.reset();
    networkLayout_.reset();
    storageLayout_.reset();
    aboutLayout_.reset();
    displaySection_ = nullptr;
    privacySection_ = nullptr;
    networkSection_ = nullptr;
    storageSection_ = nullptr;
    aboutSection_ = nullptr;
    navButtons_.clear();
    brightnessSlider_ = nullptr;
    darkModeCheckbox_ = nullptr;
    brightnessLabel_ = nullptr;
    profileNormalRb_ = nullptr;
    profilePrivacyRb_ = nullptr;
    profileMaxRb_ = nullptr;
    profileDevRb_ = nullptr;
    telemetryCheckbox_ = nullptr;
    crashReportsCheckbox_ = nullptr;
    analyticsCheckbox_ = nullptr;
    trackingCheckbox_ = nullptr;
    locationAccuracyLabel_ = nullptr;
    permissionsLabel_ = nullptr;
    wifiStatusLabel_ = nullptr;
    btStatusLabel_ = nullptr;
    cellularStatusLabel_ = nullptr;
    storageBar_ = nullptr;
    storageLabel_ = nullptr;
    osVersionLabel_ = nullptr;
    deviceLabel_ = nullptr;
    batteryLabel_ = nullptr;
    displayInfoLabel_ = nullptr;

    initialized_ = false;
}

// ============================================================
// Widget Tree Construction
// ============================================================

void SettingsApp::buildRoot() {
    root_ = std::make_unique<gui::Widget>();
    root_->setTag("settings_root");

    // Create root layout (vertical) as unique_ptr
    rootLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    rootLayout_->setSpacing(2);

    buildNavigation();
    buildDisplaySection();
    buildPrivacySection();
    buildNetworkSection();
    buildStorageSection();
    buildAboutSection();

    // Sync singletons from config defaults
    auto& tm = gui::ThemeManager::getInstance();
    std::string themeStr = config_.get("display.theme");
    if (themeStr == "LIGHT") {
        tm.setThemeType(gui::ThemeType::LIGHT);
    } else {
        tm.setThemeType(gui::ThemeType::DARK);
    }

    // Apply initial theme
    tm.applyTheme(*root_);

    // Sync privacy profile from config
    std::string profileStr = config_.get("privacy.profile");
    auto& pm = privacy::PermissionManager::getInstance();
    if (profileStr == "PRIVACY") {
        pm.setPrivacyProfile(privacy::PrivacyProfile::PRIVACY);
    } else if (profileStr == "MAXIMUM_PRIVACY") {
        pm.setPrivacyProfile(privacy::PrivacyProfile::MAXIMUM_PRIVACY);
    } else if (profileStr == "DEVELOPER") {
        pm.setPrivacyProfile(privacy::PrivacyProfile::DEVELOPER);
    } else {
        pm.setPrivacyProfile(privacy::PrivacyProfile::NORMAL);
    }

    // Apply initial panel visibility
    updatePanelVisibility();
}

void SettingsApp::buildNavigation() {
    // Navigation bar (horizontal layout)
    auto navBar = std::make_unique<gui::Widget>();
    navBar->setTag("nav_bar");
    navBar->setPreferredSize(300, 16);

    navLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::HORIZONTAL);
    navLayout_->setSpacing(1);

    const char* labels[] = {"Display", "Privacy", "Network", "Storage", "About"};
    SettingsPanel panels[] = {
        SettingsPanel::DISPLAY, SettingsPanel::PRIVACY,
        SettingsPanel::NETWORK, SettingsPanel::STORAGE, SettingsPanel::ABOUT
    };

    for (int i = 0; i < 5; ++i) {
        auto btn = std::make_unique<gui::Button>(0, labels[i]);
        btn->setTag(labels[i]);
        btn->setPreferredSize(58, 14);
        btn->setOnClick([this, panel = panels[i]](gui::Widget*) {
            setActivePanel(panel);
        });
        navButtons_.push_back(btn.get());
        navBar->addChild(std::move(btn));
    }

    root_->addChild(std::move(navBar));
}

std::unique_ptr<gui::Widget> SettingsApp::createSection(const std::string& title,
                                                          std::unique_ptr<gui::LinearLayout>& outLayout) {
    auto section = std::make_unique<gui::Widget>();
    section->setTag(title);

    // Create vertical layout for this section
    outLayout = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    outLayout->setSpacing(2);

    // Title label
    auto titleLabel = std::make_unique<gui::Label>(0, title);
    titleLabel->setTag(title + "_title");
    titleLabel->setPreferredSize(290, 12);
    section->addChild(std::move(titleLabel));

    return section;
}

void SettingsApp::buildDisplaySection() {
    auto section = std::make_unique<gui::Widget>();
    section->setTag("display_section");
    section->setPreferredSize(300, 80);
    displayLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    displayLayout_->setSpacing(2);

    // Title
    auto title = std::make_unique<gui::Label>(0, "--- Display ---");
    title->setTag("display_title");
    title->setPreferredSize(290, 12);
    section->addChild(std::move(title));

    // Brightness label
    auto brightLabel = std::make_unique<gui::Label>(0, "Brightness: 128");
    brightLabel->setTag("brightness_label");
    brightLabel->setPreferredSize(290, 10);
    brightnessLabel_ = brightLabel.get();
    section->addChild(std::move(brightLabel));

    // Brightness slider
    auto slider = std::make_unique<gui::Slider>(0, 0, 255, 128);
    slider->setTag("brightness_slider");
    slider->setPreferredSize(280, 14);
    slider->setOnChange([this](int32_t value) {
        setBrightness(value);
    });
    brightnessSlider_ = slider.get();
    section->addChild(std::move(slider));

    // Dark mode checkbox
    auto darkCb = std::make_unique<gui::CheckBox>(0, "Dark Mode");
    darkCb->setTag("dark_mode");
    darkCb->setChecked(gui::ThemeManager::getInstance().getCurrentType() == gui::ThemeType::DARK);
    darkCb->setOnChange([this](bool checked) {
        if (checked) {
            setThemeType(gui::ThemeType::DARK);
        } else {
            setThemeType(gui::ThemeType::LIGHT);
        }
    });
    darkModeCheckbox_ = darkCb.get();
    section->addChild(std::move(darkCb));

    displaySection_ = section.get();
    root_->addChild(std::move(section));
}

void SettingsApp::buildPrivacySection() {
    auto section = std::make_unique<gui::Widget>();
    section->setTag("privacy_section");
    section->setPreferredSize(300, 200);
    privacyLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    privacyLayout_->setSpacing(2);

    // Title
    auto title = std::make_unique<gui::Label>(0, "--- Privacy ---");
    title->setTag("privacy_title");
    title->setPreferredSize(290, 12);
    section->addChild(std::move(title));

    // Privacy profile label
    auto profileLabel = std::make_unique<gui::Label>(0, "Privacy Profile:");
    profileLabel->setTag("profile_label");
    profileLabel->setPreferredSize(290, 10);
    section->addChild(std::move(profileLabel));

    // Radio buttons for privacy profiles
    auto rbNormal = std::make_unique<gui::RadioButton>(1, "Normal", 1);
    rbNormal->setTag("profile_normal");
    rbNormal->setSelected(true);
    rbNormal->setPreferredSize(280, 12);
    profileNormalRb_ = rbNormal.get();
    section->addChild(std::move(rbNormal));

    auto rbPrivacy = std::make_unique<gui::RadioButton>(2, "Privacy", 1);
    rbPrivacy->setTag("profile_privacy");
    rbPrivacy->setPreferredSize(280, 12);
    profilePrivacyRb_ = rbPrivacy.get();
    section->addChild(std::move(rbPrivacy));

    auto rbMax = std::make_unique<gui::RadioButton>(3, "Maximum Privacy", 1);
    rbMax->setTag("profile_max");
    rbMax->setPreferredSize(280, 12);
    profileMaxRb_ = rbMax.get();
    section->addChild(std::move(rbMax));

    auto rbDev = std::make_unique<gui::RadioButton>(4, "Developer", 1);
    rbDev->setTag("profile_dev");
    rbDev->setPreferredSize(280, 12);
    profileDevRb_ = rbDev.get();
    section->addChild(std::move(rbDev));

    // Set onChange for radio buttons
    profileNormalRb_->setOnChange([this](int32_t, bool selected) {
        if (selected) setPrivacyProfile(privacy::PrivacyProfile::NORMAL);
    });
    profilePrivacyRb_->setOnChange([this](int32_t, bool selected) {
        if (selected) setPrivacyProfile(privacy::PrivacyProfile::PRIVACY);
    });
    profileMaxRb_->setOnChange([this](int32_t, bool selected) {
        if (selected) setPrivacyProfile(privacy::PrivacyProfile::MAXIMUM_PRIVACY);
    });
    profileDevRb_->setOnChange([this](int32_t, bool selected) {
        if (selected) setPrivacyProfile(privacy::PrivacyProfile::DEVELOPER);
    });

    // Location accuracy label
    auto locLabel = std::make_unique<gui::Label>(0, "Location Accuracy: NONE");
    locLabel->setTag("location_accuracy");
    locLabel->setPreferredSize(290, 10);
    locationAccuracyLabel_ = locLabel.get();
    section->addChild(std::move(locLabel));

    // Telemetry toggle
    auto teleCb = std::make_unique<gui::CheckBox>(0, "Telemetry");
    teleCb->setTag("telemetry");
    teleCb->setChecked(false);
    teleCb->setOnChange([this](bool checked) {
        setTelemetryEnabled(checked);
    });
    telemetryCheckbox_ = teleCb.get();
    section->addChild(std::move(teleCb));

    // Crash reports toggle
    auto crashCb = std::make_unique<gui::CheckBox>(0, "Crash Reports");
    crashCb->setTag("crash_reports");
    crashCb->setChecked(false);
    crashCb->setOnChange([this](bool checked) {
        crashReportsEnabled_ = checked;
        config_.setBool("privacy.crash_reports", checked);
        notifyStateChange();
    });
    crashReportsCheckbox_ = crashCb.get();
    section->addChild(std::move(crashCb));

    // Analytics toggle
    auto analyticsCb = std::make_unique<gui::CheckBox>(0, "Analytics");
    analyticsCb->setTag("analytics");
    analyticsCb->setChecked(false);
    analyticsCb->setOnChange([this](bool checked) {
        analyticsEnabled_ = checked;
        config_.setBool("privacy.analytics", checked);
        notifyStateChange();
    });
    analyticsCheckbox_ = analyticsCb.get();
    section->addChild(std::move(analyticsCb));

    // Tracking toggle
    auto trackingCb = std::make_unique<gui::CheckBox>(0, "Tracking");
    trackingCb->setTag("tracking");
    trackingCb->setChecked(false);
    trackingCb->setOnChange([this](bool checked) {
        trackingEnabled_ = checked;
        config_.setBool("privacy.tracking", checked);
        notifyStateChange();
    });
    trackingCheckbox_ = trackingCb.get();
    section->addChild(std::move(trackingCb));

    // Permissions summary label
    auto permsLabel = std::make_unique<gui::Label>(0, "Registered apps: 0");
    permsLabel->setTag("permissions_summary");
    permsLabel->setPreferredSize(290, 10);
    permissionsLabel_ = permsLabel.get();
    section->addChild(std::move(permsLabel));

    privacySection_ = section.get();
    root_->addChild(std::move(section));
}

void SettingsApp::buildNetworkSection() {
    auto section = std::make_unique<gui::Widget>();
    section->setTag("network_section");
    section->setPreferredSize(300, 60);
    networkLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    networkLayout_->setSpacing(2);

    // Title
    auto title = std::make_unique<gui::Label>(0, "--- Network ---");
    title->setTag("network_title");
    title->setPreferredSize(290, 12);
    section->addChild(std::move(title));

    // Wi-Fi status
    auto wifiLabel = std::make_unique<gui::Label>(0, "Wi-Fi: Unknown");
    wifiLabel->setTag("wifi_status");
    wifiLabel->setPreferredSize(290, 10);
    wifiStatusLabel_ = wifiLabel.get();
    section->addChild(std::move(wifiLabel));

    // Bluetooth status
    auto btLabel = std::make_unique<gui::Label>(0, "Bluetooth: Unknown");
    btLabel->setTag("bt_status");
    btLabel->setPreferredSize(290, 10);
    btStatusLabel_ = btLabel.get();
    section->addChild(std::move(btLabel));

    // Cellular status
    auto cellLabel = std::make_unique<gui::Label>(0, "Cellular: Unknown");
    cellLabel->setTag("cellular_status");
    cellLabel->setPreferredSize(290, 10);
    cellularStatusLabel_ = cellLabel.get();
    section->addChild(std::move(cellLabel));

    networkSection_ = section.get();
    root_->addChild(std::move(section));
}

void SettingsApp::buildStorageSection() {
    auto section = std::make_unique<gui::Widget>();
    section->setTag("storage_section");
    section->setPreferredSize(300, 50);
    storageLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    storageLayout_->setSpacing(2);

    // Title
    auto title = std::make_unique<gui::Label>(0, "--- Storage ---");
    title->setTag("storage_title");
    title->setPreferredSize(290, 12);
    section->addChild(std::move(title));

    // Storage usage progress bar
    auto bar = std::make_unique<gui::ProgressBar>(0, 0, 100, 0);
    bar->setTag("storage_bar");
    bar->setPreferredSize(280, 12);
    storageBar_ = bar.get();
    section->addChild(std::move(bar));

    // Storage info label
    auto storageLabel = std::make_unique<gui::Label>(0, "Storage: Unknown");
    storageLabel->setTag("storage_info");
    storageLabel->setPreferredSize(290, 10);
    storageLabel_ = storageLabel.get();
    section->addChild(std::move(storageLabel));

    storageSection_ = section.get();
    root_->addChild(std::move(section));
}

void SettingsApp::buildAboutSection() {
    auto section = std::make_unique<gui::Widget>();
    section->setTag("about_section");
    section->setPreferredSize(300, 60);
    aboutLayout_ = std::make_unique<gui::LinearLayout>(gui::LayoutOrientation::VERTICAL);
    aboutLayout_->setSpacing(2);

    // Title
    auto title = std::make_unique<gui::Label>(0, "--- About ---");
    title->setTag("about_title");
    title->setPreferredSize(290, 12);
    section->addChild(std::move(title));

    // OS version
    auto osLabel = std::make_unique<gui::Label>(0, "OS: Phantom OS v0.10.0");
    osLabel->setTag("os_version");
    osLabel->setPreferredSize(290, 10);
    osVersionLabel_ = osLabel.get();
    section->addChild(std::move(osLabel));

    // Device
    auto devLabel = std::make_unique<gui::Label>(0, "Device: iPhone X (A11)");
    devLabel->setTag("device_info");
    devLabel->setPreferredSize(290, 10);
    deviceLabel_ = devLabel.get();
    section->addChild(std::move(devLabel));

    // Battery
    auto batLabel = std::make_unique<gui::Label>(0, "Battery: Unknown");
    batLabel->setTag("battery_info");
    batLabel->setPreferredSize(290, 10);
    batteryLabel_ = batLabel.get();
    section->addChild(std::move(batLabel));

    // Display info
    auto dispLabel = std::make_unique<gui::Label>(0, "Display: Unknown");
    dispLabel->setTag("display_info");
    dispLabel->setPreferredSize(290, 10);
    displayInfoLabel_ = dispLabel.get();
    section->addChild(std::move(dispLabel));

    aboutSection_ = section.get();
    root_->addChild(std::move(section));
}

// ============================================================
// Panel Navigation
// ============================================================

void SettingsApp::setActivePanel(SettingsPanel panel) {
    if (activePanel_ == panel) return;
    activePanel_ = panel;
    updatePanelVisibility();
    notifyStateChange();
}

void SettingsApp::updatePanelVisibility() {
    if (displaySection_) displaySection_->setVisibility(
        activePanel_ == SettingsPanel::DISPLAY ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (privacySection_) privacySection_->setVisibility(
        activePanel_ == SettingsPanel::PRIVACY ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (networkSection_) networkSection_->setVisibility(
        activePanel_ == SettingsPanel::NETWORK ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (storageSection_) storageSection_->setVisibility(
        activePanel_ == SettingsPanel::STORAGE ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
    if (aboutSection_) aboutSection_->setVisibility(
        activePanel_ == SettingsPanel::ABOUT ? gui::WidgetVisibility::VISIBLE : gui::WidgetVisibility::GONE);
}

// ============================================================
// Display Settings
// ============================================================

void SettingsApp::setBrightness(int value) {
    if (value < 0) value = 0;
    if (value > 255) value = 255;
    brightness_ = value;
    config_.setInt("display.brightness", value);

    // Update HAL
    if (displayHal_) {
        displayHal_->setBrightness(static_cast<uint8_t>(value));
    }

    // Update label
    if (brightnessLabel_) {
        char buf[64];
        snprintf(buf, sizeof(buf), "Brightness: %d", value);
        brightnessLabel_->setText(buf);
    }

    notifyStateChange();
}

int SettingsApp::getBrightness() const {
    return brightness_;
}

// ============================================================
// Theme Settings
// ============================================================

void SettingsApp::toggleTheme() {
    auto& tm = gui::ThemeManager::getInstance();
    tm.toggleTheme();

    // Update config
    config_.set("display.theme",
        tm.getCurrentType() == gui::ThemeType::DARK ? "DARK" : "LIGHT");

    // Update checkbox
    if (darkModeCheckbox_) {
        darkModeCheckbox_->setChecked(tm.getCurrentType() == gui::ThemeType::DARK);
    }

    // Re-apply theme to widget tree
    tm.applyTheme(*root_);

    notifyStateChange();
}

void SettingsApp::setThemeType(gui::ThemeType type) {
    auto& tm = gui::ThemeManager::getInstance();
    tm.setThemeType(type);

    // Update config
    config_.set("display.theme",
        type == gui::ThemeType::DARK ? "DARK" : "LIGHT");

    // Update checkbox
    if (darkModeCheckbox_) {
        darkModeCheckbox_->setChecked(type == gui::ThemeType::DARK);
    }

    // Re-apply theme to widget tree
    tm.applyTheme(*root_);

    notifyStateChange();
}

gui::ThemeType SettingsApp::getThemeType() const {
    return gui::ThemeManager::getInstance().getCurrentType();
}

// ============================================================
// Privacy Settings
// ============================================================

void SettingsApp::setPrivacyProfile(privacy::PrivacyProfile profile) {
    auto& pm = privacy::PermissionManager::getInstance();
    pm.setPrivacyProfile(profile);

    // Update config
    const char* profileStr = "NORMAL";
    switch (profile) {
        case privacy::PrivacyProfile::PRIVACY: profileStr = "PRIVACY"; break;
        case privacy::PrivacyProfile::MAXIMUM_PRIVACY: profileStr = "MAXIMUM_PRIVACY"; break;
        case privacy::PrivacyProfile::DEVELOPER: profileStr = "DEVELOPER"; break;
        case privacy::PrivacyProfile::CUSTOM: profileStr = "CUSTOM"; break;
        default: break;
    }
    config_.set("privacy.profile", profileStr);

    // Update radio buttons
    if (profileNormalRb_) profileNormalRb_->setSelected(profile == privacy::PrivacyProfile::NORMAL);
    if (profilePrivacyRb_) profilePrivacyRb_->setSelected(profile == privacy::PrivacyProfile::PRIVACY);
    if (profileMaxRb_) profileMaxRb_->setSelected(profile == privacy::PrivacyProfile::MAXIMUM_PRIVACY);
    if (profileDevRb_) profileDevRb_->setSelected(profile == privacy::PrivacyProfile::DEVELOPER);

    // Update location accuracy based on profile
    int profileLevel = static_cast<int>(profile);
    locationAccuracy_ = privacy::defaultLocationAccuracy(profileLevel);

    // Update location accuracy label
    if (locationAccuracyLabel_) {
        const char* accStr = privacy::locationAccuracyToString(locationAccuracy_);
        char buf[64];
        snprintf(buf, sizeof(buf), "Location Accuracy: %s", accStr);
        locationAccuracyLabel_->setText(buf);
    }

    // Update config
    config_.set("privacy.location_accuracy", privacy::locationAccuracyToString(locationAccuracy_));

    notifyStateChange();
}

privacy::PrivacyProfile SettingsApp::getPrivacyProfile() const {
    return privacy::PermissionManager::getInstance().getPrivacyProfile();
}

void SettingsApp::setTelemetryEnabled(bool enabled) {
    telemetryEnabled_ = enabled;
    config_.setBool("privacy.telemetry", enabled);

    // Update checkbox
    if (telemetryCheckbox_) {
        telemetryCheckbox_->setChecked(enabled);
    }

    notifyStateChange();
}

bool SettingsApp::isTelemetryEnabled() const {
    return telemetryEnabled_;
}

void SettingsApp::setLocationAccuracy(privacy::LocationAccuracy accuracy) {
    locationAccuracy_ = accuracy;
    config_.set("privacy.location_accuracy", privacy::locationAccuracyToString(accuracy));

    if (locationAccuracyLabel_) {
        const char* accStr = privacy::locationAccuracyToString(accuracy);
        char buf[64];
        snprintf(buf, sizeof(buf), "Location Accuracy: %s", accStr);
        locationAccuracyLabel_->setText(buf);
    }

    notifyStateChange();
}

privacy::LocationAccuracy SettingsApp::getLocationAccuracy() const {
    return locationAccuracy_;
}

// ============================================================
// Hardware Info
// ============================================================

void SettingsApp::refreshHardwareInfo() {
    // Display info
    if (displayHal_) {
        displayHal_->getInfo(&displayInfo_);
        if (displayInfoLabel_) {
            char buf[128];
            snprintf(buf, sizeof(buf), "Display: %ux%u %s, %u DPI",
                     displayInfo_.resolution.width,
                     displayInfo_.resolution.height,
                     displayInfo_.panel_type,
                     displayInfo_.resolution.dpi);
            displayInfoLabel_->setText(buf);
        }
    }

    // Battery info
    if (powerHal_) {
        powerHal_->getBatteryInfo(&batteryInfo_);
        if (batteryLabel_) {
            char buf[128];
            snprintf(buf, sizeof(buf), "Battery: %d%%, %s, %d mV",
                     batteryInfo_.level,
                     batteryInfo_.is_charging ? "charging" : "not charging",
                     batteryInfo_.voltage_mv);
            batteryLabel_->setText(buf);
        }
    }

    // Storage info
    if (storageHal_) {
        storageHal_->getInfo(&storageInfo_);
        if (storageLabel_) {
            char buf[128];
            uint64_t totalGB = storageInfo_.total_bytes / (1024 * 1024 * 1024);
            uint64_t availGB = storageInfo_.available_bytes / (1024 * 1024 * 1024);
            snprintf(buf, sizeof(buf), "Storage: %llu GB / %llu GB (%s)",
                     static_cast<unsigned long long>(availGB),
                     static_cast<unsigned long long>(totalGB),
                     storageInfo_.is_encrypted ? "encrypted" : "not encrypted");
            storageLabel_->setText(buf);
        }

        // Update storage progress bar
        if (storageBar_ && storageInfo_.total_bytes > 0) {
            uint64_t used = storageInfo_.total_bytes - storageInfo_.available_bytes;
            int32_t percentage = static_cast<int32_t>((used * 100) / storageInfo_.total_bytes);
            storageBar_->setValue(percentage);
        }
    }

    // Network info
    if (networkHal_) {
        networkHal_->wifiGetStatus(&wifiConnected_);
        networkHal_->btScan(&btConnected_);
        networkHal_->cellularGetStatus(&cellularRegistered_);

        if (wifiStatusLabel_) {
            wifiStatusLabel_->setText(wifiConnected_ ? "Wi-Fi: Connected" : "Wi-Fi: Disconnected");
        }
        if (btStatusLabel_) {
            btStatusLabel_->setText(btConnected_ ? "Bluetooth: Device found" : "Bluetooth: No device found");
        }
        if (cellularStatusLabel_) {
            cellularStatusLabel_->setText(cellularRegistered_ ? "Cellular: Registered" : "Cellular: Not registered");
        }
    }

    // Update permissions summary
    if (permissionsLabel_) {
        auto& pm = privacy::PermissionManager::getInstance();
        auto apps = pm.getRegisteredApps();
        char buf[64];
        snprintf(buf, sizeof(buf), "Registered apps: %zu", apps.size());
        permissionsLabel_->setText(buf);
    }

    notifyStateChange();
}

std::string SettingsApp::getDisplayInfoString() const {
    char buf[128];
    snprintf(buf, sizeof(buf), "%ux%u %s, %u DPI",
             displayInfo_.resolution.width,
             displayInfo_.resolution.height,
             displayInfo_.panel_type,
             displayInfo_.resolution.dpi);
    return buf;
}

std::string SettingsApp::getBatteryInfoString() const {
    char buf[128];
    snprintf(buf, sizeof(buf), "%d%%, %s, %d mV",
             batteryInfo_.level,
             batteryInfo_.is_charging ? "charging" : "not charging",
             batteryInfo_.voltage_mv);
    return buf;
}

std::string SettingsApp::getStorageInfoString() const {
    char buf[128];
    uint64_t totalGB = storageInfo_.total_bytes / (1024 * 1024 * 1024);
    uint64_t availGB = storageInfo_.available_bytes / (1024 * 1024 * 1024);
    snprintf(buf, sizeof(buf), "%llu GB / %llu GB (%s)",
             static_cast<unsigned long long>(availGB),
             static_cast<unsigned long long>(totalGB),
             storageInfo_.is_encrypted ? "encrypted" : "not encrypted");
    return buf;
}

std::string SettingsApp::getNetworkInfoString() const {
    char buf[128];
    snprintf(buf, sizeof(buf), "Wi-Fi: %s, BT: %s, Cellular: %s",
             wifiConnected_ ? "Connected" : "Disconnected",
             btConnected_ ? "Device found" : "No device found",
             cellularRegistered_ ? "Registered" : "Not registered");
    return buf;
}

// ============================================================
// Rendering
// ============================================================

void SettingsApp::layout(int32_t width, int32_t height) {
    if (!root_) return;
    root_->setBounds(gui::Rect(0, 0, width, height));

    // Measure and layout root children using root layout
    if (rootLayout_) {
        rootLayout_->measure(*root_);
        rootLayout_->layout(*root_);
    }

    // Layout nav bar children
    auto* nav = root_->getChild(0);
    if (nav && nav->isVisible() && navLayout_) {
        navLayout_->measure(*nav);
        navLayout_->layout(*nav);
    }

    // Layout active section children
    if (displaySection_ && displaySection_->isVisible() && displayLayout_) {
        displayLayout_->measure(*displaySection_);
        displayLayout_->layout(*displaySection_);
    }
    if (privacySection_ && privacySection_->isVisible() && privacyLayout_) {
        privacyLayout_->measure(*privacySection_);
        privacyLayout_->layout(*privacySection_);
    }
    if (networkSection_ && networkSection_->isVisible() && networkLayout_) {
        networkLayout_->measure(*networkSection_);
        networkLayout_->layout(*networkSection_);
    }
    if (storageSection_ && storageSection_->isVisible() && storageLayout_) {
        storageLayout_->measure(*storageSection_);
        storageLayout_->layout(*storageSection_);
    }
    if (aboutSection_ && aboutSection_->isVisible() && aboutLayout_) {
        aboutLayout_->measure(*aboutSection_);
        aboutLayout_->layout(*aboutSection_);
    }
}

void SettingsApp::render(gui::Framebuffer& fb) {
    if (!root_) return;

    gui::BitmapFont font;
    renderWidget(*root_, fb, font);
}

void SettingsApp::renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font) {
    // Render this widget
    widget.onRender(fb, font);

    // Render children
    auto children = widget.getChildren();
    for (auto* child : children) {
        if (child && child->isVisible()) {
            renderWidget(*child, fb, font);
        }
    }
}

// ============================================================
// Touch Handling
// ============================================================

bool SettingsApp::handleTouchDown(int32_t x, int32_t y) {
    if (!root_) return false;

    gui::Widget* target = hitTestWidget(root_.get(), x, y);
    if (target) {
        return target->onTouchDown(x, y);
    }
    return false;
}

bool SettingsApp::handleTouchUp(int32_t x, int32_t y) {
    if (!root_) return false;

    gui::Widget* target = hitTestWidget(root_.get(), x, y);
    if (target) {
        return target->onTouchUp(x, y);
    }
    return false;
}

gui::Widget* SettingsApp::hitTestWidget(gui::Widget* widget, int32_t x, int32_t y) {
    if (!widget || !widget->isVisible()) return nullptr;
    if (!widget->containsPoint(x, y)) return nullptr;

    // Check children first (topmost)
    auto children = widget->getChildren();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        gui::Widget* hit = hitTestWidget(*it, x, y);
        if (hit) return hit;
    }

    return widget;
}

// ============================================================
// Utilities
// ============================================================

void SettingsApp::notifyStateChange() {
    if (stateChangeCb_) {
        stateChangeCb_();
    }
}

void SettingsApp::reset() {
    shutdown();

    // Reset singletons
    gui::ThemeManager::getInstance().reset();
    privacy::PermissionManager::getInstance().setPrivacyProfile(privacy::PrivacyProfile::NORMAL);

    // Reset config
    config_.clear();
    // Re-define properties
    config_.defineProperty("display.brightness", config::PropertyType::INTEGER, "128",
                           "Screen brightness (0-255)");
    config_.defineProperty("display.theme", config::PropertyType::STRING, "DARK",
                           "Theme type (DARK, LIGHT, CUSTOM)");
    config_.defineProperty("privacy.profile", config::PropertyType::STRING, "NORMAL",
                           "Privacy profile level");
    config_.defineProperty("privacy.telemetry", config::PropertyType::BOOLEAN, "false",
                           "Enable telemetry");
    config_.defineProperty("privacy.crash_reports", config::PropertyType::BOOLEAN, "false",
                           "Enable crash reports");
    config_.defineProperty("privacy.analytics", config::PropertyType::BOOLEAN, "false",
                           "Enable analytics");
    config_.defineProperty("privacy.tracking", config::PropertyType::BOOLEAN, "false",
                           "Enable tracking");
    config_.defineProperty("privacy.location_accuracy", config::PropertyType::STRING, "NONE",
                           "Location accuracy level");
    config_.defineProperty("system.os_version", config::PropertyType::STRING, "0.10.0",
                           "OS version");
    config_.defineProperty("system.device", config::PropertyType::STRING, "iPhone X (A11)",
                           "Device model");

    // Reset state
    brightness_ = 128;
    telemetryEnabled_ = false;
    crashReportsEnabled_ = false;
    analyticsEnabled_ = false;
    trackingEnabled_ = false;
    locationAccuracy_ = privacy::LocationAccuracy::NONE;
    activePanel_ = SettingsPanel::DISPLAY;
}

}  // namespace phantom::settings
