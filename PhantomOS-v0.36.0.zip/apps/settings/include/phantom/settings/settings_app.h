/*
 * Phantom OS - Settings App
 * Prototype settings application integrating GUI, Config, Privacy, Theme, and HAL
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/widgets/widgets.h"
#include "phantom/gui/widgets/extended_widgets.h"
#include "phantom/gui/layout.h"
#include "phantom/gui/extended_layout.h"
#include "phantom/gui/theme.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/config/config.h"
#include "phantom/privacy/permission_manager.h"
#include "phantom/hal/hal_interfaces.h"
#include <memory>
#include <string>
#include <vector>
#include <functional>

namespace phantom::settings {

// ============================================================
// Settings Panel IDs
// ============================================================
enum class SettingsPanel : uint8_t {
    DISPLAY = 0,
    PRIVACY = 1,
    NETWORK = 2,
    STORAGE = 3,
    ABOUT = 4,
};

// Convert panel to string
inline const char* settingsPanelToString(SettingsPanel panel) {
    switch (panel) {
        case SettingsPanel::DISPLAY: return "Display";
        case SettingsPanel::PRIVACY: return "Privacy";
        case SettingsPanel::NETWORK: return "Network";
        case SettingsPanel::STORAGE: return "Storage";
        case SettingsPanel::ABOUT: return "About";
        default: return "Unknown";
    }
}

// ============================================================
// SettingsApp — Prototype Settings Application
// ============================================================
class SettingsApp {
public:
    using StateChangeCallback = std::function<void()>;

    SettingsApp();
    ~SettingsApp();

    // Lifecycle
    bool initialize(hal::IHalFactory* factory = nullptr);
    void shutdown();
    bool isInitialized() const { return initialized_; }

    // Widget tree access
    gui::Widget* getRootWidget() { return root_.get(); }
    const gui::Widget* getRootWidget() const { return root_.get(); }

    // Config access
    config::Config& getConfig() { return config_; }
    const config::Config& getConfig() const { return config_; }

    // Panel navigation
    void setActivePanel(SettingsPanel panel);
    SettingsPanel getActivePanel() const { return activePanel_; }
    size_t getPanelCount() const { return 5; }

    // Display settings
    void setBrightness(int value);
    int getBrightness() const;

    // Theme settings
    void toggleTheme();
    void setThemeType(gui::ThemeType type);
    gui::ThemeType getThemeType() const;

    // Privacy settings
    void setPrivacyProfile(privacy::PrivacyProfile profile);
    privacy::PrivacyProfile getPrivacyProfile() const;
    void setTelemetryEnabled(bool enabled);
    bool isTelemetryEnabled() const;
    void setLocationAccuracy(privacy::LocationAccuracy accuracy);
    privacy::LocationAccuracy getLocationAccuracy() const;

    // Hardware info (refreshed from HAL)
    void refreshHardwareInfo();
    std::string getDisplayInfoString() const;
    std::string getBatteryInfoString() const;
    std::string getStorageInfoString() const;
    std::string getNetworkInfoString() const;

    // Rendering
    void layout(int32_t width, int32_t height);
    void render(gui::Framebuffer& fb);
    void renderWidget(gui::Widget& widget, gui::Framebuffer& fb, const gui::BitmapFont& font);

    // Touch handling
    bool handleTouchDown(int32_t x, int32_t y);
    bool handleTouchUp(int32_t x, int32_t y);

    // Callback
    void setStateChangeCallback(const StateChangeCallback& cb) { stateChangeCb_ = cb; }

    // Reset (for tests)
    void reset();

private:
    bool initialized_ = false;
    SettingsPanel activePanel_ = SettingsPanel::DISPLAY;

    // Widget tree
    std::unique_ptr<gui::Widget> root_;
    std::unique_ptr<gui::LinearLayout> rootLayout_;
    std::unique_ptr<gui::LinearLayout> navLayout_;
    std::unique_ptr<gui::LinearLayout> displayLayout_;
    std::unique_ptr<gui::LinearLayout> privacyLayout_;
    std::unique_ptr<gui::LinearLayout> networkLayout_;
    std::unique_ptr<gui::LinearLayout> storageLayout_;
    std::unique_ptr<gui::LinearLayout> aboutLayout_;

    // Section containers (raw pointers into the tree)
    gui::Widget* displaySection_ = nullptr;
    gui::Widget* privacySection_ = nullptr;
    gui::Widget* networkSection_ = nullptr;
    gui::Widget* storageSection_ = nullptr;
    gui::Widget* aboutSection_ = nullptr;

    // Panel navigation buttons
    std::vector<gui::Button*> navButtons_;

    // Display section widgets
    gui::Slider* brightnessSlider_ = nullptr;
    gui::CheckBox* darkModeCheckbox_ = nullptr;
    gui::Label* brightnessLabel_ = nullptr;

    // Privacy section widgets
    gui::RadioButton* profileNormalRb_ = nullptr;
    gui::RadioButton* profilePrivacyRb_ = nullptr;
    gui::RadioButton* profileMaxRb_ = nullptr;
    gui::RadioButton* profileDevRb_ = nullptr;
    gui::CheckBox* telemetryCheckbox_ = nullptr;
    gui::CheckBox* crashReportsCheckbox_ = nullptr;
    gui::CheckBox* analyticsCheckbox_ = nullptr;
    gui::CheckBox* trackingCheckbox_ = nullptr;
    gui::Label* locationAccuracyLabel_ = nullptr;
    gui::Label* permissionsLabel_ = nullptr;

    // Network section widgets
    gui::Label* wifiStatusLabel_ = nullptr;
    gui::Label* btStatusLabel_ = nullptr;
    gui::Label* cellularStatusLabel_ = nullptr;

    // Storage section widgets
    gui::ProgressBar* storageBar_ = nullptr;
    gui::Label* storageLabel_ = nullptr;

    // About section widgets
    gui::Label* osVersionLabel_ = nullptr;
    gui::Label* deviceLabel_ = nullptr;
    gui::Label* batteryLabel_ = nullptr;
    gui::Label* displayInfoLabel_ = nullptr;

    // Config
    config::Config config_;

    // HAL instances (owned by app if factory provided)
    hal::IHalFactory* halFactory_ = nullptr;
    hal::IHalFactory* ownedFactory_ = nullptr;
    hal::IDisplayHal* displayHal_ = nullptr;
    hal::IPowerHal* powerHal_ = nullptr;
    hal::IStorageHal* storageHal_ = nullptr;
    hal::INetworkHal* networkHal_ = nullptr;

    // Cached hardware info
    hal::DisplayInfo displayInfo_;
    hal::BatteryInfo batteryInfo_;
    hal::StorageInfo storageInfo_;
    bool wifiConnected_ = false;
    bool btConnected_ = false;
    bool cellularRegistered_ = false;

    // State
    int brightness_ = 128;
    bool telemetryEnabled_ = false;
    bool crashReportsEnabled_ = false;
    bool analyticsEnabled_ = false;
    bool trackingEnabled_ = false;
    privacy::LocationAccuracy locationAccuracy_ = privacy::LocationAccuracy::NONE;

    StateChangeCallback stateChangeCb_;

    // Build methods
    void buildRoot();
    void buildNavigation();
    void buildDisplaySection();
    void buildPrivacySection();
    void buildNetworkSection();
    void buildStorageSection();
    void buildAboutSection();

    // Helper: create a section container with vertical layout
    std::unique_ptr<gui::Widget> createSection(const std::string& title,
                                                 std::unique_ptr<gui::LinearLayout>& outLayout);

    // Helper: recursively layout a widget and its children using the stored layout
    void layoutWidget(gui::Widget& widget, gui::LinearLayout* layout);
    void updatePanelVisibility();

    // Helper: notify state change
    void notifyStateChange();

    // Helper: show/hide panels
    // Helper: recursively hit-test and dispatch touch
    gui::Widget* hitTestWidget(gui::Widget* widget, int32_t x, int32_t y);
};

}  // namespace phantom::settings
