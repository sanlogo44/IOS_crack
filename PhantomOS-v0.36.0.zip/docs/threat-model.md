# Phantom OS – Threat Model

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Methodology

This threat model identifies assets, threats, attack surfaces, and mitigations for Phantom OS on iPhone X.

---

## 2. Assets

### 2.1 User Data Assets

| Asset | Value | Location |
|-------|-------|----------|
| Personal data (contacts, messages, photos) | High | Encrypted local storage |
| Biometric data (Face ID) | Critical | Secure Enclave (if available) |
| Location history | High | Not stored by default |
| Credentials (passwords, tokens, keys) | Critical | KeyStore (hardware-backed if available) |
| Network traffic | Medium | Encrypted in transit |
| Clipboard data | Medium | RAM only |

### 2.2 System Assets

| Asset | Value | Location |
|-------|-------|----------|
| Kernel integrity | Critical | Boot chain, dm-verity |
| System partition | Critical | Read-only, verified |
| SELinux policies | Critical | Kernel-enforced |
| Update mechanism | Critical | Signed, verified |
| Boot chain | Critical | checkm8 → PongoOS → Kernel |

---

## 3. Threats

### 3.1 Malicious Applications

| Threat | Impact | Mitigation |
|--------|--------|------------|
| Unauthorized data access | High | Permission system (default deny), sandboxing, SELinux |
| Privilege escalation | Critical | SELinux, seccomp-bpf, ASLR, CFI |
| Cross-app data leakage | High | Per-app sandbox, app-specific identifiers |
| Background surveillance | High | Background restrictions, network firewall |
| Clipboard snooping | Medium | Clipboard access control, auto-delete |
| Metadata harvesting | Medium | Metadata stripping, DNS encryption |

### 3.2 Network Threats

| Threat | Impact | Mitigation |
|--------|--------|------------|
| Man-in-the-middle attacks | High | Certificate pinning, TLS enforcement |
| DNS poisoning | Medium | DNS-over-TLS/HTTPS |
| Tracker surveillance | High | System-wide tracker blocking, per-app firewall |
| Network fingerprinting | Medium | Minimal network footprint, no telemetry |
| IMSI catching | High | `UNKNOWN` — Requires modem control (not available) |

### 3.3 Physical Attacks

| Threat | Impact | Mitigation |
|--------|--------|------------|
| Device theft | Critical | File-based encryption, secure lock screen |
| Physical extraction | High | Encryption, verified boot |
| Bootloader tampering | Critical | checkm8 chain of trust (modified), dm-verity |
| Hardware debug access | High | `UNKNOWN` — Hardware debug restrictions unknown |

### 3.4 Supply Chain Attacks

| Threat | Impact | Mitigation |
|--------|--------|------------|
| Compromised updates | Critical | Signed updates, signature verification |
| Backdoored components | Critical | Reproducible builds, source code audit |
| Malicious pre-installed apps | High | Minimal default apps, audit-able system |

### 3.5 iPhone X-Specific Threats

| Threat | Impact | Mitigation |
|--------|--------|------------|
| Boot ROM vulnerability (checkm8) | Critical | Used as boot mechanism; documented, not hidden |
| SEP compromise | Critical | `UNKNOWN` — SEP security depends on Apple hardware |
| Baseband exploitation | High | `UNKNOWN` — Modem isolation unknown |
| DFU mode exploitation | Medium | Documented boot procedure; user must enter DFU intentionally |

---

## 4. Attack Surfaces

### 4.1 Network Attack Surface

| Surface | Exposure | Mitigation |
|---------|----------|------------|
| Wi-Fi | Medium | `UNKNOWN` — No Wi-Fi driver currently |
| Bluetooth | Medium | `UNKNOWN` — No BT driver currently |
| Cellular/Modem | High | `UNKNOWN` — No modem driver currently |
| NFC | Low | `UNKNOWN` — No NFC driver currently |

### 4.2 Local Attack Surface

| Surface | Exposure | Mitigation |
|---------|----------|------------|
| USB | Medium | USB networking enabled; restrict in production |
| Physical buttons | Low | Standard Android input handling |
| Sensors | Low | Permission-gated, reducible accuracy |

### 4.3 Software Attack Surface

| Surface | Exposure | Mitigation |
|---------|----------|------------|
| Android Runtime | High | Sandboxing, SELinux, permission interception |
| Phantom Framework | Medium | Privileged but audited, SELinux-confined |
| Kernel | Critical | Hardened config, minimal attack surface |
| Boot chain | Critical | checkm8-based, documented |

---

## 5. Trust Boundaries

```
┌─────────────────────────────────────────┐
│           UNTRUSTED (Apps)              │
│  ┌─────────┐  ┌─────────┐  ┌────────┐  │
│  │ Phantom │  │ Android │  │ Other  │  │
│  │   App   │  │   App   │  │  Apps  │  │
│  └────┬────┘  └────┬────┘  └───┬────┘  │
│       │            │           │        │
├───────┼────────────┼───────────┼────────┤
│       │    PERMISSION LAYER     │        │
│       │            │           │        │
├───────┼────────────┼───────────┼────────┤
│       │  TRUSTED (System Services)     │
│       ▼            ▼           ▼        │
│  ┌─────────────────────────────────┐   │
│  │       Phantom Framework         │   │
│  ├─────────────────────────────────┤   │
│  │       Privacy Layer              │   │
│  ├─────────────────────────────────┤   │
│  │       Security Layer (SELinux)   │   │
│  ├─────────────────────────────────┤   │
│  │       Phantom HAL                │   │
│  ├─────────────────────────────────┤   │
│  │       Kernel                     │   │
│  ├─────────────────────────────────┤   │
│  │       Boot Chain (checkm8)       │   │
│  ├─────────────────────────────────┤   │
│  │       Hardware (iPhone X)        │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

---

## 6. Risk Assessment

| Risk | Severity | Likelihood | Priority |
|------|----------|------------|----------|
| No SEP driver (no Face ID, no HW crypto) | High | High | P1 |
| No Wi-Fi/Bluetooth drivers | High | High | P1 |
| No modem driver (no cellular) | High | High | P1 |
| No touchscreen driver | Critical | Medium | P0 |
| No GPU driver (no 3D acceleration) | Medium | Medium | P2 |
| No GMS certification (no Google Play) | Medium | Certain | P3 |
| Boot chain compromise | Critical | Low | P0 |
| Kernel vulnerability | Critical | Medium | P1 |
| App sandbox escape | Critical | Low | P1 |
| Supply chain attack | High | Low | P2 |
