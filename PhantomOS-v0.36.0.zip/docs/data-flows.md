# Phantom OS – Data Flow Documentation

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Data Flow Model

All sensitive data in Phantom OS follows a documented flow:

```
SOURCE
  ↓
PROCESSING
  ↓
STORAGE
  ↓
TRANSMISSION
  ↓
DELETION
```

---

## 2. Location Data Flow

```
GPS Hardware
  ↓
Location HAL
  ↓
Location Service
  ↓
Permission Check (default: DENY)
  ↓
Privacy Layer
  ├── Check profile setting (precise/approximate/city/none)
  ├── Apply location approximation if needed
  └── Log access (app, timestamp, duration, reason)
  ↓
App (receives only permitted location data)
  ↓
DELETION: Location data is not stored unless app explicitly saves it
```

### Location Approximation Levels

| Level | Accuracy | Method |
|-------|----------|--------|
| Precise | Full GPS accuracy | Pass-through |
| Approximate | ~100m | Coordinate rounding + noise |
| City | City center | Map to nearest city |
| Region | Region centroid | Map to state/province |
| Country | Country centroid | Map to country |
| None | No data | Return null |

---

## 3. Camera Data Flow

```
Camera Hardware
  ↓
Camera HAL
  ↓
Camera Service
  ↓
Permission Check (default: DENY)
  ↓
Privacy Layer
  ├── Verify time-limited grant is valid
  ├── Show camera active indicator
  └── Log access (app, timestamp, duration)
  ↓
App (receives camera frames)
  ↓
STORAGE: Photos/videos stored encrypted (FBE) in app sandbox or user storage
  ↓
DELETION: User-controlled deletion; no automatic cloud backup
```

---

## 4. Microphone Data Flow

```
Microphone Hardware
  ↓
Audio HAL
  ↓
Audio Service
  ↓
Permission Check (default: DENY)
  ↓
Privacy Layer
  ├── Verify time-limited grant is valid
  ├── Show microphone active indicator
  └── Log access (app, timestamp, duration)
  ↓
App (receives audio data)
  ↓
STORAGE: Audio stored encrypted in app sandbox or user storage
  ↓
DELETION: User-controlled; session-based for real-time apps
```

---

## 5. Clipboard Data Flow

```
Source App
  ↓
Clipboard Service
  ├── Sensitive content detection (passwords, tokens, keys)
  ├── Start auto-delete timer (60s default, 15s for sensitive)
  └── Log write access
  ↓
STORAGE: RAM only (volatile, never written to disk)
  ↓
Destination App (with permission)
  ↓
Permission Check
  ↓
Privacy Layer
  ├── Verify clipboard access permission
  ├── Log read access (app, timestamp)
  └── Return clipboard content
  ↓
DELETION: Auto-delete after timeout; manual clear on demand
```

---

## 6. Contact Data Flow

```
Contacts Storage (encrypted, local)
  ↓
Contacts Service
  ↓
Permission Check (default: DENY)
  ↓
Privacy Layer
  ├── Scope to requested contact only (if scoped)
  ├── Log access (app, timestamp, which contacts)
  └── Return scoped contact data
  ↓
App (receives only requested contacts)
  ↓
TRANSMISSION: Only if app has network permission AND user has explicitly approved
  ↓
DELETION: App's copy deleted when permission revoked
```

---

## 7. Network Data Flow

```
App
  ↓
Phantom Network Security Layer
  ├── Permission check (internet, local, background)
  ├── Firewall rules (per-app)
  ├── DNS encryption (DoT/DoH)
  ├── Tracker domain blocking
  └── Per-app VPN routing (if configured)
  ↓
Network Interface (Wi-Fi/Cellular)
  ↓
Internet
  ↓
LOGGING: Local connection log (7 days default, encrypted)
  ↓
DELETION: Log entries expire after retention period
```

### Network Connection Log

| Field | Retention |
|-------|-----------|
| App name | 7 days |
| Destination domain | 7 days |
| Timestamp | 7 days |
| Bytes sent/received | 7 days |
| Connection status | 7 days |

---

## 8. File Sharing Data Flow

```
Source App / User
  ↓
Share Intent
  ↓
Privacy Layer
  ├── Offer: "Share original" or "Share sanitized copy"
  ├── If sanitized:
  │   ├── Remove GPS coordinates
  │   ├── Remove device information
  │   ├── Remove camera metadata
  │   ├── Remove user identifiers
  │   └── Remove unnecessary timestamps
  └── Log sharing event
  ↓
Destination App (receives original or sanitized copy)
  ↓
STORAGE: In destination app's sandbox (encrypted)
  ↓
DELETION: User-controlled
```

---

## 9. App Identifier Data Flow

```
App requests device identifier
  ↓
Privacy API
  ↓
Identity Management
  ├── Generate app-specific identifier (per-app, per-installation)
  ├── Do NOT return IMEI, MAC, serial, Android ID, or advertising ID
  └── Log identifier access
  ↓
App (receives app-specific pseudonymous ID only)
  ↓
TRANSMISSION: Identifier is per-app, cannot be correlated across apps
  ↓
DELETION: Identifier rotates on app reinstall
```

---

## 10. Crash Report Data Flow

```
Application Crash
  ↓
Crash Handler
  ↓
STORAGE: Local crash report (encrypted)
  ↓
Privacy Layer (when user chooses to share)
  ├── Scan for sensitive information:
  │   ├── Usernames
  │   ├── File paths
  │   ├── IP addresses
  │   ├── Device identifiers
  │   └── Application data
  ├── Display findings to user
  ├── Allow user to remove sensitive items
  └── Generate sanitized report
  ↓
TRANSMISSION: Only sanitized, user-approved report
  ↓
DELETION: Original crash report deleted after user review
```

---

## 11. Biometric Data Flow (Face ID)

```
TrueDepth Camera (dot projector + IR camera)
  ↓
Face ID HAL
  ↓
Secure Enclave (SEP)
  ├── Process facial data locally
  ├── Store biometric template in SEP (never leaves SEP)
  └── Return only authentication result (success/fail)
  ↓
Privacy Layer
  └── Log authentication event (no biometric data logged)
  ↓
App (receives only authentication result, never biometric data)
  ↓
DELETION: Biometric data never leaves SEP; no transmission
```

**Note:** Face ID/SEP availability on Phantom OS is `UNKNOWN` — depends on A11 SEP driver availability.

---

## 12. Update Check Data Flow

```
Phantom Update Service
  ↓
Privacy Layer
  ├── Generate anonymous update check (no device ID)
  ├── Use DNS encryption
  └── Verify update signature
  ↓
TRANSMISSION: Anonymous HTTPS request to update server
  ↓
Response (signed update manifest)
  ↓
STORAGE: Update downloaded to staging partition
  ↓
VERIFICATION: Signature verification before installation
  ↓
DELETION: Old partition kept for rollback; staging cleared after install
```
