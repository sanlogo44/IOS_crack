# Phantom OS – Phase 0: Development Environment

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Phase 0 Goals

Phase 0 establishes the foundational development environment and project skeleton for Phantom OS. No OS code is written in this phase — the goal is to create a reproducible, well-documented starting point.

### Deliverables

- [x] Repository structure
- [x] Architecture documentation
- [x] Development environment guide
- [x] Project validation tools
- [x] Project structure tests
- [x] ZIP distribution

---

## 2. Development Environment

### 2.1 Host System Requirements

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| OS | Ubuntu 22.04 LTS or Debian 12 | Ubuntu 24.04 LTS |
| Architecture | 64-bit x86 | 64-bit x86 |
| RAM | 16 GB (Phase 0) | 64 GB (for AOSP builds in Phase 2+) |
| Disk | 50 GB free (Phase 0) | 500 GB+ free (for AOSP in Phase 2+) |
| CPU | 4 cores | 8+ cores |

### 2.2 Required Software

```bash
# Essential packages
sudo apt-get update
sudo apt-get install -y \
    git \
    python3 \
    python3-pip \
    build-essential \
    zip \
    unzip \
    curl \
    wget \
    qemu-system-aarch64 \
    gcc-aarch64-linux-gnu \
    make
```

### 2.3 AOSP Build Prerequisites (For Phase 2+)

The following are NOT needed for Phase 0 but documented for future reference:

| Requirement | Value | Source |
|-------------|-------|--------|
| OS | Ubuntu 18.04+ (for Android 11+) | [AOSP Setup](https://source.android.com/docs/setup/start/requirements) |
| RAM | 64 GB minimum | [AOSP Setup](https://source.android.com/docs/setup/start/requirements) |
| Disk | 400 GB free (250 GB checkout + 150 GB build) | [AOSP Setup](https://source.android.com/docs/setup/start/requirements) |
| Build system | Soong (Android.bp) | [AOSP Build](https://source.android.com/docs/setup/build) |

```bash
# AOSP build packages (for Phase 2+)
sudo apt-get install -y \
    git-core \
    gnupg \
    flex \
    bison \
    build-essential \
    zip \
    curl \
    zlib1g-dev \
    libc6-dev-i386 \
    x11proto-core-dev \
    libx11-dev \
    lib32z1-dev \
    libgl1-mesa-dev \
    libxml2-utils \
    xsltproc \
    unzip \
    fontconfig \
    repo
```

---

## 3. iPhone X Development Setup

### 3.1 Hardware Requirements

| Item | Required | Notes |
|------|----------|-------|
| iPhone X | Yes | Any model (A1865/A1901/A1902) |
| USB-A to Lightning cable | Yes | USB-C to Lightning may not work for DFU ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))) |
| Linux host computer | Yes | For checkm8/PongoOS |
| libirecovery | Yes | Required because A11 cannot boot from DFU via force reset ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))) |

### 3.2 Boot Tools

| Tool | Purpose | Source |
|------|---------|--------|
| checkm8 | Boot ROM exploit | [Wikipedia](https://en.wikipedia.org/wiki/Checkm8) |
| palera1n | Jailbreak tool (A8-A11) | [GitHub](https://github.com/palera1n/palera1n) |
| PongoOS | Pre-boot environment | [GitHub](https://github.com/palera1n/PongoOS) |
| libirecovery | Device communication in DFU/recovery | Required for A11 |
| idevicerestore | Device restoration | For recovery |

### 3.3 Boot Procedure (Reference)

1. Connect iPhone X to host with USB-A to Lightning cable
2. Power off device
3. Enter recovery mode (hold until Apple logo appears and disappears)
4. Enter DFU mode:
   - Run `irecovery -c reset` on host
   - Follow DFU timing (hold 2 seconds, release 8 seconds)
5. Use checkm8/PongoOS to boot custom code

**Warning:** Flashing is marked as `Broken` in postmarketOS. Do not flash to NVMe namespace 2 — data is unrecoverable even with DFU restore ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))).

---

## 4. Emulation (Alternative to Hardware)

For development without physical iPhone X hardware:

| Emulator | Architecture | Use Case |
|----------|-------------|----------|
| QEMU (aarch64) | ARM64 | Phantom OS userspace testing |
| Android Emulator | ARM64/x86 | Android app testing |
| Corellium | ARM64 | iOS/Android virtualization (commercial) |

QEMU can be used for Phantom OS userspace development without iPhone X hardware.

---

## 5. Project Validation

### 5.1 Structure Validation

```bash
python3 tools/validate_project.py
```

Validates:
- All required directories exist
- All required files exist
- Documentation is present
- No empty required directories

### 5.2 Test Suite

```bash
python3 tests/test_project_structure.py
```

Tests:
- Project structure integrity
- Required file presence
- Documentation completeness
- Architecture document sections

---

## 6. Known Limitations (Phase 0)

1. **No bootable OS** — Phase 0 produces documentation and project skeleton only
2. **No AOSP build** — AOSP integration begins in Phase 2
3. **No hardware drivers** — Hardware research documented, no drivers written
4. **No iPhone X boot** — Boot capability begins in Phase 9
5. **Most hardware components are UNKNOWN** — See [hardware-iphone-x.md](./hardware-iphone-x.md)

---

## 7. Next Steps

After Phase 0 completion:

1. **Phase 1** — Complete repository setup (mostly done in Phase 0)
2. **Phase 2** — Begin AOSP source checkout and build
3. **Phase 3** — Design and implement Phantom Framework architecture
4. **Phase 9** — Begin iPhone X boot chain research and implementation
