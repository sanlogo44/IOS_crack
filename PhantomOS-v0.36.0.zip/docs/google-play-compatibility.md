# Phantom OS – Google Play Compatibility

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Overview

Phantom OS is designed to function completely without Google services. However, optional Google Play compatibility is explored for users who require it.

---

## 2. Google Mobile Services (GMS)

### 2.1 What GMS Includes

Google Mobile Services is **not** part of AOSP and requires a license from Google ([Google: GMS](https://www.android.com/gms/)):

| Component | Description |
|-----------|-------------|
| Google Play Services | Core GMS framework (location, push, auth) |
| Google Play Store | App distribution platform |
| Google Play Protect | Security scanning |
| Google account integration | Sign-in, sync |
| Google Cloud Messaging / FCM | Push notifications |
| Google Maps API | Location and mapping |
| Google APIs | Various Google service APIs |

### 2.2 Licensing Requirements

| Requirement | Description |
|-------------|-------------|
| GMS License | Must be obtained from Google |
| Android Compatibility Commitment (ACC) | Agreement with Google restricting device modifications ([UK CMA Report](https://assets.publishing.service.gov.uk/media/62a0d5cbe90e07039ba54eee/Appendix_E_-_Google_agreements_with_device_manufacturers_and_app_developers.pdf)) |
| CTS (Compatibility Test Suite) | Device must pass Google's compatibility tests |
| Play Integrity API | Device attestation (replaced SafetyNet in 2025) ([Android Developers](https://developer.android.com/google/play/integrity)) |
| GMS as system app | Play Services must be installed at system level |

### 2.3 Play Integrity API

The Play Integrity API (formerly SafetyNet) provides:
- Device integrity verification
- App verification
- Account verification
- Anti-abuse detection

SafetyNet Attestation was fully deprecated in 2025 and replaced by Play Integrity ([Wikipedia: Play Integrity](https://en.wikipedia.org/wiki/Play_Integrity_API)).

**Impact on Phantom OS:** Without GMS and Play Integrity, many apps (banking, DRM-protected content, some games) will not function.

---

## 3. Feasibility Assessment

| Requirement | Feasible? | Notes |
|-------------|-----------|-------|
| GMS License | `CURRENTLY NOT FEASIBLE` | Google does not license GMS for custom OS on non-certified hardware |
| CTS Certification | `CURRENTLY NOT FEASIBLE` | iPhone X is not Android-certified hardware |
| Play Integrity | `CURRENTLY NOT FEASIBLE` | Requires GMS and certified device |
| Play Store | `CURRENTLY NOT FEASIBLE` | Requires GMS license |

**Conclusion:** Obtaining full Google Play compatibility for Phantom OS on iPhone X is not realistic in the foreseeable future. Phantom OS is designed to work fully without Google services.

---

## 4. Without Google Services

Phantom OS provides alternatives for common GMS-dependent functionality:

| GMS Feature | Phantom OS Alternative |
|-------------|----------------------|
| Google Cloud Messaging (FCM) | UnifiedPush or local push |
| Google Location Services | Local location service (GPS + offline geocoding) |
| Google Maps API | OpenStreetMap-based alternative |
| Google Sign-In | Local account, OAuth2 per-service |
| Google Play Store | APK sideloading, future Phantom App Store |
| Google Drive sync | Local storage, user-chosen cloud |
| Firebase Analytics | NOT INCLUDED (privacy by design) |
| Google AdMob | NOT INCLUDED (no advertising) |

---

## 5. microG Compatibility (Optional)

Phantom OS may support [microG](https://microg.org/) as an optional compatibility layer:
- Reimplements Google Play Services APIs
- Allows apps requiring GMS APIs to function
- User must explicitly enable
- Does not provide Play Integrity attestation

**Status:** `PLANNED` — Future phase, not in initial releases.

---

## 6. Documentation Requirements

All Google Play compatibility decisions must document:
- What is included and what is not
- Licensing implications
- Privacy implications of enabling GMS
- Security implications of GMS system-level access
- User consent requirements
