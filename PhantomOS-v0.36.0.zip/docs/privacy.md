# Phantom OS – Privacy Documentation

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Privacy Philosophy

Phantom OS follows the principle of **data minimization by default**:

> So wenig persönliche Daten wie möglich erfassen, so wenig persönliche Daten wie möglich speichern und so wenig persönliche Daten wie möglich weitergeben.

### The Phantom Principle

1. If information is not needed, it is not collected.
2. If needed, it is processed locally whenever possible.
3. If transmission is necessary, only the minimum is transmitted.
4. If identity is not needed, no persistent identity is used.
5. If metadata is not needed, it is removed or minimized.

Privacy is not just a setting — it is deeply integrated into the operating system architecture and technically verifiable.

---

## 2. Data Processing Principles

All data processing in Phantom OS follows these principles:

| Principle | Description |
|-----------|-------------|
| **Local** | Data is processed on-device whenever possible |
| **Minimal** | Only necessary data is collected or processed |
| **Encrypted** | Data at rest and in transit is encrypted |
| **Pseudonymized** | Identifiers are app-specific where possible |
| **Time-limited** | Data is retained only as long as needed |
| **Transparent** | Users can see what data is collected and why |
| **User-controlled** | Users can grant, revoke, or restrict access |

---

## 3. What Data Phantom OS Processes

### 3.1 Data Phantom OS Does NOT Collect

| Data Type | Status |
|-----------|--------|
| Telemetry | NOT COLLECTED (default OFF) |
| Crash reports | LOCAL ONLY (default OFF for remote) |
| Analytics | NOT COLLECTED (default OFF) |
| Usage statistics | NOT COLLECTED (default OFF) |
| Advertising IDs | NOT GENERATED |
| Device fingerprints | NOT SHARED |
| App usage patterns | NOT TRACKED |

### 3.2 Data Processed Locally

| Data Type | Purpose | Storage | Retention |
|-----------|---------|---------|-----------|
| Location data | Navigation, app functionality | Encrypted, local | Session-based or user-defined |
| Camera data | Photography, video | User storage (encrypted) | Until user deletes |
| Microphone data | Calls, recording | Session-based | Until session ends |
| Contacts | Contact management | Encrypted, local | Until user deletes |
| Messages | Communication | Encrypted, local | Until user deletes |
| Photos/Videos | Media storage | Encrypted, local | Until user deletes |
| Clipboard | Copy/paste | RAM only | Auto-delete after timeout |
| Biometric data | Face ID authentication | Secure Enclave (if available) | Never leaves device |

### 3.3 Data That May Leave the Device

| Data Type | Condition | Minimization |
|-----------|-----------|-------------|
| Network traffic | User-initiated | Firewall, DNS encryption, tracker blocking |
| App data | App-initiated, with permission | Only what app is permitted to access |
| Crash reports | User explicitly shares | Sanitized before sharing |
| Updates | OTA update checks | Anonymous, signed requests |

---

## 4. Storage Locations

| Data | Location | Encryption |
|------|----------|------------|
| System files | Root filesystem (dm-verity) | Verified |
| User files | User data partition | File-based encryption (FBE) |
| App data | Per-app sandbox | Encrypted, isolated |
| Keys | KeyStore (hardware-backed if SEP available) | Hardware-backed |
| Biometric data | Secure Enclave (if available) | Hardware-isolated |
| Clipboard | RAM only | N/A (volatile) |
| Logs | Local storage | Encrypted |

---

## 5. Data Retention

| Data Type | Default Retention | User Configurable |
|-----------|------------------|-------------------|
| Clipboard | 60 seconds | Yes |
| Location history | Not stored | N/A |
| Camera/mic access log | 30 days | Yes |
| Network connection log | 7 days | Yes |
| Crash reports | Until reviewed | Yes |
| App data | Until app uninstalled | Yes |

---

## 6. App Access Control

### 6.1 Permission Default State

All permissions default to **DENY**. Apps must request each permission individually.

### 6.2 Permission Categories

| Category | Permissions |
|----------|------------|
| Camera | Camera access |
| Microphone | Audio recording |
| Location | Precise, approximate, city, region, country, none |
| Contacts | Read, write |
| Photos | Read, write, share sanitized |
| Files | Scoped storage access |
| Bluetooth | Scan, connect, advertise |
| Nearby Devices | Discovery, connection |
| Notifications | Send, read |
| Network | Internet, local network, background |
| Sensors | Accelerometer, gyroscope, proximity, ambient light |
| Clipboard | Read, history |
| Phone | Call state, dial |
| SMS | Read, send |

### 6.3 Time-Limited Grants

| Grant Type | Duration |
|-----------|----------|
| Allow once | Single use |
| Allow for 10 minutes | 10 minutes |
| Allow while using | App in foreground only |
| Allow always | Until revoked |
| Deny | No access |

---

## 7. Identity Protection

### 7.1 App-Specific Identifiers

Each app receives a unique, app-specific identifier instead of a global device ID. This prevents cross-app tracking.

### 7.2 Protected Hardware Identifiers

The following identifiers are **not exposed** to apps by default:

| Identifier | Protection |
|-----------|-----------|
| IMEI | NEVER exposed to apps |
| IMSI | NEVER exposed to apps |
| Serial number | NEVER exposed to apps |
| Wi-Fi MAC | NEVER exposed to apps |
| Bluetooth MAC | NEVER exposed to apps |
| Android ID | App-specific per-app ID instead |
| Advertising ID | NOT GENERATED |
| SIM information | NEVER exposed to apps |
| Device fingerprint | NOT SHARED |

### 7.3 Exceptions

For functions requiring a stable identity (e.g., banking, DRM), an explicit exception must be documented and approved by the user.

---

## 8. Metadata Protection

### 8.1 Photo/Video Metadata

When sharing media, Phantom OS offers:

- **Share original** — Full file with all metadata
- **Share sanitized copy** — Removes:
  - GPS coordinates
  - Device information
  - Camera metadata
  - User identifiers
  - Unnecessary timestamps

### 8.2 File Metadata

File metadata is minimized when sharing:
- Original creation dates can be removed
- Device identifiers removed
- Application-specific metadata stripped

### 8.3 Network Metadata

- DNS queries encrypted (DNS-over-TLS/HTTPS)
- Connection logging is local and transparent
- No tracking domains contacted by system services

---

## 9. Clipboard Privacy

| Feature | Description |
|---------|-------------|
| Access control | Apps must request clipboard access |
| Auto-delete | Clipboard cleared after timeout (default 60s) |
| Sensitive detection | Passwords, tokens detected and auto-cleared |
| Access log | Transparent log of clipboard access |

---

## 10. Sensor Privacy

| Sensor | Privacy Options |
|--------|----------------|
| Location | Precise / Approximate / City / Region / Country / None |
| Microphone | Allow / Deny / Mute system-wide |
| Camera | Allow / Deny / Disable system-wide |
| Accelerometer | Allow / Deny / Reduced accuracy |
| Gyroscope | Allow / Deny / Reduced accuracy |
| Proximity | Allow / Deny |
| Ambient light | Allow / Deny |

---

## 11. Screenshot/Screen Recording Protection

Apps can mark content as sensitive, which:
- Blocks screenshots of sensitive areas
- Redacts sensitive content in screen recordings
- Shows a privacy indicator when protection is active

Users can override this protection in settings.

---

## 12. Privacy Center

The Privacy Center provides a centralized view:

```
┌──────────────────────────────────┐
│         PRIVACY CENTER           │
├──────────────────────────────────┤
│ Camera                       OFF │
│ Microphone                    ON │
│ Location                     OFF │
│ Network                      ON  │
│ Tracking                     OFF │
│ Analytics                    OFF │
│ Clipboard                    ON  │
├──────────────────────────────────┤
│ Recent Access                    │
│                                  │
│ Camera → Camera App              │
│ Location → Maps                  │
│ Microphone → Phone               │
└──────────────────────────────────┘
```

---

## 13. Privacy Profiles

| Profile | Description |
|---------|-------------|
| Normal | Standard smartphone functionality, privacy defaults |
| Privacy | Reduced data sharing, stricter permissions |
| Maximum Privacy | Maximum restrictions, may reduce app compatibility |
| Developer | Extended debugging and development access |
| Custom | User-defined all settings |

---

## 14. Network Privacy

### 14.1 DNS Privacy

| Protocol | Description |
|----------|-------------|
| DNS-over-TLS | Encrypted DNS over TLS (port 853) |
| DNS-over-HTTPS | Encrypted DNS over HTTPS (port 443) |

### 14.2 Firewall

Per-app network control:

```
App X
 ├── Internet: ALLOWED
 ├── DNS: ALLOWED
 ├── Local Network: DENIED
 └── Background Network: DENIED
```

### 14.3 Tracker Blocking

System-wide tracker domain blocking with profiles:
- Standard (common trackers)
- Strict (extended tracker list)
- Maximum Privacy (all known third-party domains)
- Custom (user-defined)

---

## 15. Crash Report Privacy

Crash reports are stored locally by default. Before sharing:

1. Scan for sensitive information (usernames, file paths, IPs, device IDs, app data)
2. Display findings to user
3. Allow user to remove sensitive information
4. Share only approved, sanitized report

---

## 16. Data That Never Leaves the Device

- Biometric data (Face ID)
- Private keys
- Passwords
- Tokens
- Contact list (unless explicitly shared)
- Calendar data (unless explicitly shared)
- Photos and videos (unless explicitly shared)
- App usage data
- Device identifiers (IMEI, MAC, serial)
