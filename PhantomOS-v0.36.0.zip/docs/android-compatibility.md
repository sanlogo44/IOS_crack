# Phantom OS – Android Compatibility

**Version:** 0.1.0  
**Date:** 2026-09-19  

---

## 1. Android App Compatibility

Phantom OS supports running Android applications through an integrated Android Runtime, not as the host OS.

---

## 2. Supported Android Features

| Feature | Status | Notes |
|---------|--------|-------|
| APK installation | PLANNED | Sideloading and package manager |
| Android Runtime (ART) | PLANNED | Execute Android bytecode |
| Binder IPC | PLANNED | Inter-process communication |
| Android Framework APIs | PLANNED | Activity Manager, Package Manager, Window Manager |
| Android Permissions | PLANNED | Mapped through Phantom Privacy Layer |
| Android UI toolkit | PLANNED | Render Android app UIs |
| Android Intents | PLANNED | Scoped, permission-checked |
| Android Services | PLANNED | Background services with restrictions |
| Google Play Services | OPTIONAL | See Google Play Compatibility doc |

---

## 3. Permission Mapping

Android permissions are intercepted and mapped through the Phantom OS Privacy Layer:

| Android Permission | Phantom OS Behavior |
|-------------------|---------------------|
| `ACCESS_FINE_LOCATION` | May return approximate location based on privacy profile |
| `ACCESS_COARSE_LOCATION` | Respects privacy profile approximation level |
| `READ_CONTACTS` | Scoped access, sanitized if shared |
| `WRITE_CONTACTS` | Scoped, logged |
| `CAMERA` | Time-limited, with active indicator |
| `RECORD_AUDIO` | Time-limited, with active indicator |
| `READ_PHONE_STATE` | Returns app-specific ID, never IMEI |
| `READ_EXTERNAL_STORAGE` | Scoped storage, sanitized copies on share |
| `WRITE_EXTERNAL_STORAGE` | Scoped storage only |
| `ACCESS_NETWORK_STATE` | Filtered network info |
| `INTERNET` | Per-app firewall, tracker blocking |
| `BLUETOOTH` | Time-limited, scoped |
| `BLUETOOTH_ADMIN` | Time-limited, scoped |
| `READ_SMS` | Scoped, logged |
| `SEND_SMS` | Permission-checked, logged |
| `CALL_PHONE` | Permission-checked, logged |
| `VIBRATE` | Allowed (low risk) |
| `WAKE_LOCK` | Allowed with restrictions |
| `RECEIVE_BOOT_COMPLETED` | Restricted background start |
| `FOREGROUND_SERVICE` | Allowed with restrictions |
| `ANDROID_ID` | App-specific per-app ID |
| `AD_ID` | Not available (no advertising ID) |
| `READ_MEDIA_IMAGES` | Scoped, sanitized on share |
| `READ_MEDIA_VIDEO` | Scoped, sanitized on share |
| `READ_MEDIA_AUDIO` | Scoped |
| `POST_NOTIFICATIONS` | Permission-checked |
| `NEARBY_WIFI_DEVICES` | Permission-checked, scoped |
| `BODY_SENSORS` | Permission-checked, reducible accuracy |
| `ACTIVITY_RECOGNITION` | Permission-checked, reducible accuracy |

---

## 4. Android Runtime Integration

### 4.1 Architecture

```
Android App (APK)
    ↓
Package Manager (installs APK)
    ↓
Activity Manager (manages lifecycle)
    ↓
Android Runtime (ART) — executes bytecode
    ↓
Android Framework APIs
    ↓
Phantom Privacy Layer (intercepts permissions)
    ↓
Phantom HAL / Phantom Services
    ↓
Hardware
```

### 4.2 Binder IPC

Android's Binder IPC is supported but all Binder transactions are:
- SELinux-enforced
- Permission-checked
- Auditable

---

## 5. Android App Sandboxing

Android apps run in the same sandboxing model as Phantom native apps:
- Per-app UID/GID
- Scoped storage
- seccomp-bpf filtering
- SELinux domain per app
- Network firewall per app

---

## 6. Limitations

| Limitation | Description |
|-----------|-------------|
| No Google Play Services (by default) | Apps requiring GMS APIs may not function |
| No SafetyNet/Play Integrity | Device attestation not available without GMS |
| No Google Cloud Messaging | Push notifications require alternative |
| No Google Maps API | Alternative map service needed |
| Restricted background services | Stricter than standard Android |
| Permission restrictions | Some permissions may be denied based on privacy profile |

---

## 7. AOSP Version

- **Initial target:** AOSP 14 (Android 14, API level 34)
- **Rationale:** Modern API level, security patches, ART improvements
- **Build system:** Soong (Android.bp)
- **Build requirements:** 64-bit x86, 64 GB RAM, 400 GB disk ([AOSP Setup Guide](https://source.android.com/docs/setup/start/requirements))
