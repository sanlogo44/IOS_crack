# iPhone X Hardware Documentation

**Version:** 0.1.0  
**Date:** 2026-09-19  
**Target Device:** Apple iPhone X (A11 Bionic)

---

## 1. Device Overview

| Specification | Value | Source |
|---------------|-------|--------|
| Model | iPhone X (10th anniversary) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Codename | apple-d22 (postmarketOS) | [postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)) |
| Released | November 3, 2017 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Discontinued | September 12, 2018 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Units sold | 63 million worldwide | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Dimensions | 143.6 × 70.9 × 7.7 mm | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Weight | 174.1 g | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Materials | Glass front/back, stainless steel frame | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Water resistance | IP67 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |

---

## 2. System-on-Chip: Apple A11 Bionic

| Specification | Value | Source |
|---------------|-------|--------|
| SoC | Apple A11 Bionic | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Product code | APL1W72 | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Manufacturer | TSMC | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Process | 10 nm FinFET (TSMC 10FF) | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Transistors | 4.3 billion | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Die size | 87.66 mm² | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |
| Instruction set | A64 – ARMv8.2-A | [Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11) |

### CPU

| Core | Type | Clock | Design |
|------|------|-------|--------|
| 2× Monsoon | High-performance | 2.39 GHz | 7-wide decode, out-of-order superscalar |
| 4× Mistral | Energy-efficient | 1.42 GHz | 3-wide decode, out-of-order, based on Apple Swift (A6) |

- Second-generation performance controller allows all 6 cores to be used simultaneously ([Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11))

### Cache

| Cache | Size |
|-------|------|
| L1 instruction | 64 KB per core |
| L1 data | 64 KB per core |
| L2 | 8 MB (shared) |

### GPU

- Apple-designed 3-core GPU
- ~30% faster than A10 Fusion GPU
- Up to 409 GFLOPS

### Neural Engine

- Dedicated neural network hardware
- 600 billion operations per second
- Used for Face ID and Animoji
- Third-party apps cannot access the Neural Engine ([Wikipedia: A11](https://en.wikipedia.org/wiki/Apple_A11))

### Memory

| Device | RAM | Type |
|--------|-----|------|
| iPhone X | 3 GB | LPDDR4X (PoP configuration) |

### Secure Enclave (SEP)

- Coprocessor within the A11 SoC
- Uses encrypted memory
- Hardware random number generator
- Handles Face ID biometric data
- Provides cryptographic operations for data protection
- Foundation for Data Protection key management

**Phantom OS Status:** `UNKNOWN` — No public Linux driver for A11 SEP. Face ID and hardware-backed crypto availability on Phantom OS is uncertain ([Apple Platform Security Guide](https://help.apple.com/pdf/security/en_US/apple-platform-security-guide.pdf)).

---

## 3. Storage

| Specification | Value | Source |
|---------------|-------|--------|
| Capacities | 64 GB / 256 GB | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Interface | Apple ANS2 NVMe | [postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)) |
| Linux support | Works (requires iOS 14+ firmware for RTKit) | [postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)) |

### NVMe Namespaces

- **Namespace 1:** Main storage (modifiable)
- **Namespace 2:** Bootloader data (DO NOT MODIFY — unrecoverable even with DFU restore)

---

## 4. Display

| Specification | Value | Source |
|---------------|-------|--------|
| Type | OLED (Super Retina HD) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Size | 5.85 in (149 mm diagonal) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Resolution | 2436 × 1125 pixels | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Pixel density | 458 ppi | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Aspect ratio | 19.5:9 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Contrast ratio | 1,000,000:1 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Max brightness | 625 cd/m² typical | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Color | DCI-P3, sRGB, HDR | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Supplier | Samsung Display | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Touch tech | 3D Touch | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Touch sampling | 120 Hz | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| True Tone | Yes | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Glass | Dual-ion exchange-strengthened | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |

**Phantom OS Status:** Screen `PARTIALLY KNOWN`, Touchscreen `UNKNOWN` (broken in postmarketOS)

---

## 5. Cellular / Modem

| Model | Modem | Source |
|-------|-------|--------|
| A1865 / A1902 | Qualcomm MDM9655 (Snapdragon X16 LTE) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X), [TechWalls](https://www.techwalls.com/iphone-x-a1865-qualcomm-a1901-intel-modem/) |
| A1901 | Intel XMM 7480 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X), [TechWalls](https://www.techwalls.com/iphone-x-a1865-qualcomm-a1901-intel-modem/) |

### Network Bands

| Network | Bands |
|---------|-------|
| GSM | 850 / 900 / 1800 / 1900 MHz |
| UMTS/HSPA+ | 850 / 900 / 1700(AWS) / 1900 / 2100 MHz |
| LTE | 1-5, 7, 8, 12, 13, 17-20, 25-30, 34, 38-41, 66 |
| CDMA (A1865) | 800 / 1900 / 2100 MHz |
| LTE Advanced | Supported, peak 500 Mbps |

**Phantom OS Status:** `UNKNOWN` — No public Linux driver for either Qualcomm or Intel modem on iPhone X. Calls, SMS, and mobile data are broken in postmarketOS.

---

## 6. Wireless Connectivity

| Feature | Specification | Source |
|---------|---------------|--------|
| Wi-Fi | 802.11 a/b/g/n/ac | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Bluetooth | 5.0 | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| NFC | Yes (with reader mode) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Positioning | GPS, GLONASS, Galileo, QZSS | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |

**Phantom OS Status:** All `UNKNOWN` — Wi-Fi, Bluetooth, and GPS are broken in postmarketOS on iPhone X.

---

## 7. Cameras

### Rear Cameras

| Camera | Specs |
|--------|-------|
| Wide-angle | 12 MP, f/1.8, 6-element lens, OIS |
| Telephoto | 12 MP, f/2.4, 2× optical zoom, OIS |
| Flash | Quad-LED True Tone with Slow Sync |
| Video | 4K @ 24/30/60 fps, 1080p @ 30/60/120/240 fps |

### Front Camera (TrueDepth)

| Camera | Specs |
|--------|-------|
| Resolution | 7 MP, f/2.2 |
| Features | Face ID, Animoji, Portrait Mode, Portrait Lighting |
| Video | 1080p @ 30 fps, 720p @ 240 fps |
| Face ID | Dot projector (30,000+ IR dots) + IR camera |

**Phantom OS Status:** All `UNKNOWN` — Camera is broken in postmarketOS. Face ID requires SEP access which is `UNKNOWN`.

---

## 8. Battery & Power

| Specification | Value | Source |
|---------------|-------|--------|
| Capacity | 2,716 mAh (10.35 Wh) | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Voltage | 3.81 V | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Charging | 5V/1A hardcoded in Linux | [postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)) |
| Wireless charging | Qi | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |
| Fast charging | USB-C to Lightning | [Wikipedia](https://en.wikipedia.org/wiki/IPhone_X) |

**Phantom OS Status:** Battery info `PARTIALLY KNOWN`, charging `PARTIALLY KNOWN` (limited to 5V/1A in current Linux port).

---

## 9. Boot Chain

### iOS Boot Chain (Original)

```
Boot ROM (SecureROM, read-only)
    ↓
Verifies Low-Level Bootloader (LLB) signature
    ↓
iBoot
    ↓
Kernel
    ↓
iOS
```

### Phantom OS Boot Chain (Planned)

```
Boot ROM (SecureROM)
    ↓
checkm8 exploit (CVE-2019-8900) — unpatchable
    ↓
PongoOS (pre-boot environment)
    ↓
Linux Kernel (Phantom OS)
    ↓
Phantom OS userspace
```

### Boot Constraints

1. **checkm8** is required — Boot ROM is read-only and enforces signature verification ([Wikipedia: checkm8](https://en.wikipedia.org/wiki/Checkm8))
2. **A11 cannot boot from DFU if entered via force reset** — `libirecovery` is required ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))
3. **Firmware must be iOS 14+** for RTKit protocol support needed by NVMe storage driver ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))
4. **NVMe namespace 2 must not be modified** — contains unrecoverable bootloader data ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))

---

## 10. Hardware Component Status Summary

| # | Component | PostmarketOS Status | Phantom OS Status | Priority |
|---|-----------|-------------------|-------------------|----------|
| 1 | Boot (checkm8/PongoOS) | Works | KNOWN | P0 |
| 2 | USB Networking | Works | KNOWN | P0 |
| 3 | Internal Storage (NVMe) | Works | KNOWN | P1 |
| 4 | Display | Partial | PARTIALLY KNOWN | P2 |
| 5 | Touchscreen | Broken | UNKNOWN | P2 |
| 6 | GPU/3D Acceleration | Broken | UNKNOWN | P3 |
| 7 | Audio | Broken | UNKNOWN | P3 |
| 8 | Camera | Broken | UNKNOWN | P4 |
| 9 | Wi-Fi | Broken | UNKNOWN | P2 |
| 10 | Bluetooth | Broken | UNKNOWN | P3 |
| 11 | GPS | Broken | UNKNOWN | P4 |
| 12 | Modem/LTE | Broken | UNKNOWN | P4 |
| 13 | SMS | Broken | UNKNOWN | P4 |
| 14 | Calls | Broken | UNKNOWN | P4 |
| 15 | Mobile Data | Broken | UNKNOWN | P4 |
| 16 | Face ID / SEP | Broken | UNKNOWN | P5 |
| 17 | Accelerometer | Broken | UNKNOWN | P5 |
| 18 | Battery | Partial | PARTIALLY KNOWN | P2 |
| 19 | FDE | Broken | UNKNOWN | P3 |
| 20 | USB OTG | Broken | UNKNOWN | P4 |

### Status Definitions

| Status | Meaning |
|--------|---------|
| KNOWN | Public documentation or working code exists |
| PARTIALLY KNOWN | Some aspects documented, others unknown |
| REVERSE ENGINEERED | Working through reverse-engineered drivers |
| UNKNOWN | No public documentation or working implementation |
| NOT FEASIBLE | Technically not possible with current knowledge |
| CURRENTLY NOT FEASIBLE | Not possible now, but may become feasible with research |

---

## 11. iPhone X Model Variants

| Model | Modem | Region | Notes |
|-------|-------|--------|-------|
| A1865 | Qualcomm MDM9655 | US, Japan | CDMA support |
| A1901 | Intel XMM 7480 | Global (GSM) | No CDMA |
| A1902 | Qualcomm MDM9655 | Japan | TD-SCDMA support |

---

## 12. Related Projects

| Project | Description | Relevance |
|---------|-------------|-----------|
| [postmarketOS](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)) | Linux on iPhone X | Kernel and driver reference |
| [Project Sandcastle](https://projectsandcastle.org/) | Android on iPhone (Corellium) | Android-on-iPhone reference (iPhone 7 only) |
| [palera1n](https://github.com/palera1n/palera1n) | Jailbreak for A8-A11 | Boot chain and exploit tooling |
| [PongoOS](https://github.com/palera1n/PongoOS) | Pre-boot environment for A10/A11 | Bootloader reference |
| [Asahi Linux](https://asahilinux.org/) | Linux on Apple Silicon Macs | Driver architecture patterns |
| [m1n1](https://github.com/AsahiLinux/m1n1) | Apple Silicon bootchain hypervisor | Boot chain reference |
