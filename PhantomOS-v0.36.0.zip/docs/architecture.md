# Phantom OS – Technical Architecture

**Version:** 0.1.0  
**Status:** Draft – Architecture & Phase 0  
**Date:** 2026-09-19  

---

## 1. Overview

Phantom OS is a privacy-first, modular smartphone operating system designed to run on Apple iPhone X (A11 Bionic) as its initial target hardware, with long-term goals of multi-hardware support. It is not a conventional Android ROM — it is an independent OS with its own framework, services, GUI, and privacy layer, built on top of an AOSP-derived Android compatibility runtime.

### Core Principles

1. **Privacy by default** — Data is not collected unless needed; when needed, processed locally and minimally.
2. **Security as foundation** — Verified boot, sandboxing, SELinux, and hardware-backed encryption.
3. **Modularity** — Each subsystem (privacy, security, GUI, HAL) is independently replaceable.
4. **Android compatibility** — Android apps run via a compatibility runtime, not as the host OS.
5. **Honesty** — No fabricated drivers, APIs, or hardware specs. Unknown areas are marked `UNKNOWN`.

---

## 2. System Architecture

```
                         PHANTOM OS
                              │
               ┌──────────────┴──────────────┐
               │                             │
        Phantom Native Apps             Android Apps
               │                             │
               │                       Android Runtime
               │                       (ART, Binder, Framework)
               │                             │
               └──────────────┬──────────────┘
                              │
                    Phantom Framework
                    (System Services, APIs)
                              │
                    Phantom Services
                    (Privacy, Network, Security)
                              │
                      Privacy Layer
                      (Permission, Sanitization)
                              │
                       Security Layer
                       (SELinux, Sandbox, Crypto)
                              │
                         Phantom HAL
                         (Hardware Abstraction)
                              │
                    Hardware / Kernel
                    (Linux Kernel + A11 Drivers)
                              │
                       iPhone X Hardware
```

### Layer Summary

| Layer | Responsibility | Status |
|-------|---------------|--------|
| Phantom Native Apps | Built-in Phantom applications | PLANNED |
| Android Runtime | ART, Binder, Android Framework APIs | PLANNED |
| Phantom Framework | Core system services, APIs | PLANNED |
| Phantom Services | Privacy, network security, audit | PLANNED |
| Privacy Layer | Permissions, data sanitization, identity | PLANNED |
| Security Layer | SELinux policies, sandboxing, crypto | PLANNED |
| Phantom HAL | Hardware abstraction for iPhone X | RESEARCH |
| Kernel | Linux kernel with A11/iPhone X support | RESEARCH |
| Hardware | Apple iPhone X (A11 Bionic) | PARTIALLY KNOWN |

---

## 3. Kernel

### 3.1 Strategy

Phantom OS will initially use a **Linux kernel** ported for the Apple A11 platform, leveraging existing work from:

- **postmarketOS** — iPhone X (`apple-d22`) has a booting Linux kernel, though most hardware features are broken ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))
- **PongoOS** — A pre-boot execution environment for A10/A11 devices, developed by the checkra1n team
- **Asahi Linux** — While targeting Apple Silicon Macs, its driver architecture and Linux-on-Apple-Silicon approach provides reference patterns

### 3.2 Boot Chain

The iPhone X boot chain for Phantom OS:

```
Boot ROM (SecureROM)
    │
    ├── checkm8 exploit (CVE-2019-8900, unpatchable in hardware)
    │   ([Wikipedia: checkm8](https://en.wikipedia.org/wiki/Checkm8))
    │
    └── PongoOS / m1n1 bootloader
            │
            └── Linux Kernel (Phantom OS)
                    │
                    └── Phantom OS userspace
```

**Key constraints:**
- The A11 Boot ROM is read-only and cannot be modified — checkm8 is required to boot unsigned code ([Wikipedia: checkm8](https://en.wikipedia.org/wiki/Checkm8))
- Apple A11 cannot boot from DFU if entered via force reset — `libirecovery` is required ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))
- Linux internal-storage support requires firmware at least iOS 14 due to RTKit protocol limitations ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22)))

### 3.3 Long-term Kernel Goals

- Phase 1-2: Linux kernel fork based on postmarketOS/Asahi patterns
- Phase 27: Custom kernel components (microkernel or hybrid approach)
- Phase 28: Multi-hardware kernel abstraction

### 3.4 Kernel Status

| Component | Status | Notes |
|-----------|--------|-------|
| Boot (checkm8 → PongoOS) | REVERSE ENGINEERED | Working in postmarketOS |
| USB | KNOWN | USB networking works in postmarketOS |
| Internal storage (NVMe) | KNOWN | ANS2 NVMe works, requires iOS 14+ firmware |
| Display | PARTIALLY KNOWN | Partial in postmarketOS |
| Touchscreen | UNKNOWN | Broken in postmarketOS |
| GPU (3D acceleration) | UNKNOWN | Broken in postmarketOS |
| Wi-Fi | UNKNOWN | Broken in postmarketOS |
| Bluetooth | UNKNOWN | Broken in postmarketOS |
| Audio | UNKNOWN | Broken in postmarketOS |
| Camera | UNKNOWN | Broken in postmarketOS |
| GPS | UNKNOWN | Broken in postmarketOS |
| Modem (LTE) | UNKNOWN | Broken in postmarketOS |
| Accelerometer | UNKNOWN | Broken in postmarketOS |
| Face ID / SEP | UNKNOWN | Secure Enclave is proprietary, no public Linux driver |
| Battery/Charging | PARTIALLY KNOWN | Battery info works, charging hardcoded to 5V/1A |

---

## 4. AOSP Integration

### 4.1 Approach

Phantom OS will use AOSP as the foundation for the Android compatibility layer, not as the full host OS. The Android Runtime (ART), Binder IPC, and Android Framework APIs will be integrated into the Phantom OS userspace.

### 4.2 AOSP Build Requirements

Building AOSP requires significant resources ([AOSP Setup Guide](https://source.android.com/docs/setup/start/requirements)):

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| Architecture | 64-bit x86 | 64-bit x86 |
| Disk space | 400 GB | 500+ GB |
| RAM | 64 GB | 64 GB |
| OS | Ubuntu 18.04+ | Ubuntu 22.04+ |
| Build system | Soong (Android.bp) | Soong |
| Full build time (6-core) | ~6 hours | — |
| Full build time (72-core) | ~40 minutes | — |

### 4.3 AOSP Version Strategy

- Initial target: AOSP 14 (Android 14) for modern API level and security patches
- Long-term: Track latest AOSP releases with Phantom OS patches

---

## 5. Android Runtime

### 5.1 Components

The Android compatibility runtime provides:

- **ART (Android Runtime)** — Execute Android APK files
- **Binder IPC** — Inter-process communication for Android services
- **Android Framework APIs** — Activity Manager, Package Manager, Window Manager, etc.
- **Android Permissions** — Mapped through Phantom OS Privacy Layer
- **Package Manager** — APK installation and management

### 5.2 Permission Mapping

Android app permissions are intercepted by the Phantom OS Privacy Layer:

```
Android App
    ↓
Android Framework Permission Check
    ↓
Phantom Privacy Layer (intercept)
    ↓
    ├── Grant (with optional restrictions)
    ├── Deny
    ├── Grant with reduced accuracy (e.g., approximate location)
    └── Grant with time limit
    ↓
Hardware Access
```

---

## 6. Phantom Framework

### 6.1 System Services

Phantom OS provides its own system services:

| Service | Responsibility |
|---------|---------------|
| PhantomPermissionService | Manages all permission grants, enforcement |
| PhantomPrivacyService | Data sanitization, identity management, audit |
| PhantomNetworkService | Firewall, DNS privacy, VPN, per-app networking |
| PhantomSecurityService | SELinux policy management, key management |
| PhantomUpdateService | OTA updates, rollback, verification |
| PhantomUIService | System UI, window management, notifications |
| PhantomHALService | Hardware abstraction management |
| PhantomStorageService | Encrypted storage, file access control |

### 6.2 Framework APIs

Phantom OS provides native APIs for Phantom apps:

- **Phantom UI Kit** — Native GUI framework
- **Phantom Privacy API** — Privacy-preserving data access
- **Phantom Network API** — Network access through privacy layer
- **Phantom Storage API** — Encrypted, sandboxed storage
- **Phantom Hardware API** — Controlled hardware access

---

## 7. Privacy Layer

### 7.1 Architecture

```
Application
     ↓
Permission Layer (granular, time-limited)
     ↓
Privacy API (identity, sanitization, audit)
     ↓
Data Sanitization (metadata removal, approximation)
     ↓
Security Layer (SELinux, crypto, sandbox)
     ↓
System Service (location, camera, network, etc.)
     ↓
Hardware
```

### 7.2 Permission Model

Default state for all permissions: **DENY**

Permissions support time-limited grants:

| Grant Type | Duration |
|-----------|----------|
| Allow once | Single use |
| Allow for 10 minutes | 10 minutes |
| Allow while using | App in foreground |
| Allow always | Until revoked |
| Deny | No access |

### 7.3 Identity Protection

- Each app receives an **app-specific identifier** instead of a global device ID
- Hardware identifiers (IMEI, MAC, serial) are **not exposed** by default
- Apps requiring stable identity must request it with documented justification

### 7.4 Data Sanitization

When sharing files, Phantom OS offers:

- **Share original** — Full file with all metadata
- **Share sanitized copy** — Removes GPS coordinates, device info, timestamps, camera metadata

### 7.5 Network Privacy

| Feature | Description |
|---------|-------------|
| DNS-over-TLS | Encrypted DNS queries |
| DNS-over-HTTPS | Alternative encrypted DNS |
| Per-App VPN | Route specific apps through VPN |
| Firewall | Block network access per app |
| Tracker Blocking | System-wide tracker domain blocking |
| Connection Logging | Local, transparent network log |

### 7.6 Privacy Profiles

| Profile | Description |
|---------|-------------|
| Normal | Standard smartphone functionality |
| Privacy | Reduced data sharing |
| Maximum Privacy | Maximum restrictions, may reduce app compatibility |
| Developer | Extended debugging and development access |
| Custom | User-defined all settings |

---

## 8. Security Layer

### 8.1 Security Architecture

| Feature | Approach |
|---------|----------|
| Secure Boot | checkm8-based chain of trust (modified) |
| Verified Boot | dm-verity for root filesystem |
| SELinux | Strict policies for all processes |
| Sandboxing | Per-app sandbox with seccomp-bpf |
| ASLR | Kernel and userspace |
| CFI | Control Flow Integrity (where supported) |
| Encryption | File-based encryption (FBE) |
| KeyStore | Hardware-backed keys (SEP where available) |
| Process Isolation | Strong isolation between apps and services |

### 8.2 Secure Enclave (SEP)

The iPhone X includes a Secure Enclave within the A11 Bionic. It handles:
- Face ID biometric data processing and storage
- Cryptographic key operations
- Data protection key management

**Status:** `UNKNOWN` — No public Linux driver for the A11 SEP exists. Face ID and hardware-backed crypto may not be available on Phantom OS without significant reverse engineering.

---

## 9. Phantom HAL

### 9.1 Hardware Abstraction Layer

The Phantom HAL provides a consistent interface to hardware, regardless of the underlying platform:

```
Phantom HAL
    ├── Display HAL
    ├── Touch HAL
    ├── Audio HAL
    ├── Camera HAL
    ├── Network HAL (Wi-Fi, Bluetooth, Cellular)
    ├── Sensor HAL
    ├── Storage HAL
    ├── Power HAL
    ├── Input HAL
    └── Biometric HAL (Face ID)
```

### 9.2 iPhone X HAL Status

See [docs/hardware-iphone-x.md](./hardware-iphone-x.md) for detailed component status.

---

## 10. GUI / System UI

### 10.1 Design Principles

- Futuristic, minimal aesthetic
- Fully customizable (launcher, lockscreen, icons, fonts, themes, animations)
- Privacy indicators (camera, microphone, location active)
- Modular — entire UI can be replaced

### 10.2 Components

| Component | Description |
|-----------|-------------|
| Lock Screen | Customizable lock screen with widgets |
| Home Screen | App grid, dynamic widgets |
| App Library | Categorized app organization |
| Notifications | Privacy-respecting notification system |
| Control Center | Quick settings and toggles |
| Multitasking | App switcher and split-screen |
| Settings | System configuration |
| Search | System-wide search |
| Themes | Dark/Light mode, custom themes |
| Gestures | Navigation gestures |

---

## 11. App System

### 11.1 Phantom Native Apps

Built with Phantom UI Kit, using Phantom Privacy API directly.

### 11.2 Android Apps

Run via Android Runtime with full Android API compatibility. Permissions are intercepted by Phantom Privacy Layer.

### 11.3 App Distribution

- APK installation (sideloading)
- Future: Phantom App Store (privacy-focused)
- Optional: Google Play Store (with GMS compatibility)

---

## 12. Google Play Compatibility

### 12.1 Legal & Technical Framework

Google Mobile Services (GMS) is **not** part of AOSP and requires a license from Google ([Google: GMS](https://www.android.com/gms/)). Key requirements:

| Requirement | Description |
|-------------|-------------|
| GMS License | Must be obtained from Google |
| Android Compatibility Commitment (ACC) | Agreement restricting device modifications |
| CTS (Compatibility Test Suite) | Must pass Google's compatibility tests |
| Play Integrity API | Device attestation (replaced SafetyNet in 2025) |
| GMS as system app | Play Services installed at system level |

**Status:** `CURRENTLY NOT FEASIBLE` — Obtaining a GMS license for a custom OS on non-certified hardware (iPhone X) is not realistic in the near term. Phantom OS will operate fully without Google services and may support microG or similar compatibility layers as an alternative.

### 12.2 Without Google Services

Phantom OS is designed to function completely without Google services:
- No Google Play Services required
- No Google account required
- Local alternatives for location, push notifications, etc.
- Optional: microG or similar for apps requiring GMS APIs

---

## 13. Update System

### 13.1 OTA Architecture

| Feature | Description |
|---------|-------------|
| A/B Updates | Seamless updates with dual partition |
| Verified Updates | Signature verification |
| Rollback | Automatic rollback on failure |
| Recovery | Recovery mode for manual updates |
| Update Channels | Stable, Beta, Nightly, Developer |

---

## 14. Hardware Abstraction

### 14.1 Multi-Hardware Strategy

```
                 Phantom OS Core
                        │
                  Phantom HAL
                        │
          ┌─────────────┼─────────────┐
          │             │             │
      iPhone X      Android ARM64   Future
      (A11 Bionic)  (Snapdragon)   Hardware
```

Each hardware platform provides its own HAL implementation. The Phantom OS core remains platform-agnostic.

---

## 15. Data Flow

See [docs/data-flows.md](./data-flows.md) for detailed data flow documentation.

### Example: Location Data Flow

```
GPS Hardware
    ↓
Location HAL
    ↓
Location Service
    ↓
Permission Check (DENY by default)
    ↓
Privacy Layer (approximation if needed)
    ↓
App (receives only permitted data)
```

---

## 16. Threat Model

See [docs/threat-model.md](./threat-model.md) for the full threat model.

### Key Threats

1. **Malicious apps** — Sandboxing, permissions, SELinux
2. **Network surveillance** — DNS encryption, VPN, tracker blocking
3. **Hardware attacks** — SEP isolation, verified boot
4. **Physical device access** — FBE encryption, secure lock screen
5. **Supply chain attacks** — Reproducible builds, signed updates

---

## 17. Privacy Model

See [docs/privacy-architecture.md](./privacy-architecture.md) and [docs/privacy.md](./privacy.md) for full privacy documentation.

### Phantom Principle

> If information is not needed, it is not collected.  
> If needed, it is processed locally.  
> If transmitted, only the minimum is sent.  
> If identity is not needed, no persistent identity is used.  
> If metadata is not needed, it is removed or minimized.

---

## 18. Development Environment

See [docs/phase-0-development-environment.md](./phase-0-development-environment.md) for Phase 0 details.

### Requirements

| Component | Requirement |
|-----------|-------------|
| OS | Ubuntu 22.04+ or Debian 12+ |
| RAM | 64 GB minimum (for AOSP builds) |
| Disk | 500 GB+ free |
| CPU | 64-bit x86, 8+ cores recommended |
| Tools | Git, Python 3, Repo, Android SDK |
| iPhone X | Required for hardware testing |

---

## 19. Test Strategy

| Level | Description |
|-------|-------------|
| Unit tests | Per-module automated tests |
| Integration tests | Cross-module interaction tests |
| Hardware tests | Device-specific functionality tests |
| Privacy tests | Permission enforcement verification |
| Security tests | Penetration testing, fuzzing |
| Build tests | Reproducible build verification |

---

## 20. Roadmap

See [docs/roadmap.md](./roadmap.md) for the full roadmap.

### Phase Summary

| Phase | Name | Status |
|-------|------|--------|
| Phase 0 | Development Environment | IN PROGRESS |
| Phase 1 | Repository | COMPLETE |
| Phase 2 | AOSP Integration | NOT STARTED |
| Phase 3 | Phantom Framework | NOT STARTED |
| Phase 4 | Privacy Layer | NOT STARTED |
| Phase 5 | Security Layer | NOT STARTED |
| Phase 6 | Futuristic GUI | NOT STARTED |
| Phase 7 | Android Apps | NOT STARTED |
| Phase 8 | HAL | NOT STARTED |
| Phase 9 | iPhone Boot | NOT STARTED |
| Phase 10-22 | Hardware Features | NOT STARTED |
| Phase 23 | OTA | NOT STARTED |
| Phase 24 | Phantom SDK | NOT STARTED |
| Phase 25 | Native Apps | NOT STARTED |
| Phase 26 | Google Play Compatibility | NOT STARTED |
| Phase 27 | Own Kernel Components | NOT STARTED |
| Phase 28 | Multi-Hardware | NOT STARTED |
| Phase 29 | Release Candidate | NOT STARTED |

---

## 21. Risks and Unknowns

### High-Risk Areas

| Risk | Impact | Likelihood | Mitigation |
|------|--------|-----------|------------|
| A11 SEP driver unavailable | No Face ID, no hardware crypto | High | Software fallback, document limitation |
| Wi-Fi/Bluetooth drivers | No wireless connectivity | High | Research existing reverse-engineering efforts |
| GPU acceleration | No 3D graphics | Medium | Research Asahi Linux GPU driver patterns |
| Modem/baseband | No cellular connectivity | High | May require proprietary firmware |
| GMS certification | No Google Play | Certain | Design OS to work fully without GMS |
| Touchscreen driver | No touch input | High | Research postmarketOS kernel patches |
| Audio driver | No sound | Medium | Research ALSA/SoundWire on A11 |

### Approach to Unknowns

All unknowns are documented honestly. No fabricated drivers, APIs, or hardware specifications will be included. Where research is needed, items are marked `NEEDS RESEARCH`. Where something is not currently possible, items are marked `CURRENTLY NOT FEASIBLE`.

---

## References

- [checkm8 — Wikipedia](https://en.wikipedia.org/wiki/Checkm8)
- [postmarketOS iPhone X Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))
- [Project Sandcastle](https://projectsandcastle.org/)
- [Apple A11 — Wikipedia](https://en.wikipedia.org/wiki/Apple_A11)
- [iPhone X — Wikipedia](https://en.wikipedia.org/wiki/IPhone_X)
- [AOSP Build Requirements](https://source.android.com/docs/setup/start/requirements)
- [Google Mobile Services](https://www.android.com/gms/)
- [Play Integrity API](https://developer.android.com/google/play/integrity)
- [palera1n — GitHub](https://github.com/palera1n/palera1n)
- [Apple Platform Security Guide](https://help.apple.com/pdf/security/en_US/apple-platform-security-guide.pdf)
