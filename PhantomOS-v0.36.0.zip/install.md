# Phantom OS – Installationsanleitung

**Version:** 0.2.0

---

## Systemanforderungen (Entwicklung)

- Linux (Debian/Ubuntu empfohlen)
- C++17 Compiler (g++ 7+ oder clang++ 7+)
- CMake 3.10+
- Python 3.6+
- Git

## Systemanforderungen (AOSP Build — Phase 1, BLOCKIERT)

- Debian/Ubuntu Linux PC
- 64GB RAM
- 400GB freier Festplattenspeicher
- Java Development Kit (JDK)
- Python 3.8+
- ccache (empfohlen)

## Installation

### 1. Repository klonen oder ZIP entpacken

```bash
git clone https://github.com/sanlogo44/IOS_crack.git
cd IOS_crack
unzip PhantomOS-v0.2.0.zip
cd PhantomOS
```

Oder direkt von der ZIP:

```bash
unzip PhantomOS-v0.2.0.zip
cd PhantomOS
```

### 2. Build-Abhängigkeiten installieren

```bash
sudo apt-get install -y build-essential cmake python3 python3-pip git
```

### 3. Projekt bauen

```bash
# Mit Build-Script:
chmod +x tools/build.sh
./tools/build.sh

# Oder manuell:
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j$(nproc)
```

### 4. Tests ausführen

```bash
cd build
ctest --output-on-failure
```

Erwartete Ausgabe: 6 Tests, alle PASS (49 Test-Fälle insgesamt).

### 5. Mock Runtime starten

```bash
./build/bin/phantom_mock_runtime
```

### 6. Projektstruktur validieren

```bash
python3 tools/validate_project.py
python3 tests/test_project_structure.py
```

Erwartete Ausgabe: ALL CHECKS PASSED (Python-Tests).

## Build-Ausgaben

Nach dem Build befinden sich folgende Ausgaben im `build/` Verzeichnis:

- `build/bin/phantom_mock_runtime` — Mock Runtime Executable
- `build/bin/test_permission` — Permission Unit Tests
- `build/bin/test_permission_manager` — Permission Manager Tests
- `build/bin/test_identity` — Identity Manager Tests
- `build/bin/test_data_sanitizer` — Data Sanitizer Tests
- `build/bin/test_service_manager` — Service Manager Tests
- `build/bin/test_hal_mock` — HAL Mock Tests
- `build/lib/libphantom_privacy.a` — Privacy Library (static)
- `build/lib/libphantom_framework.a` — Framework Library (static)
- `build/lib/libphantom_hal_mock.a` — HAL Mock Library (static)

## Was funktioniert

- C++ Build-System mit CMake
- Service Manager mit Lifecycle-Management
- Privacy Layer (Permissions, Identity, Data Sanitizer)
- HAL Interfaces und Mock-Implementierungen
- Mock Runtime Demonstration
- 49 Unit-Tests (alle bestanden)

## Was nicht funktioniert / BLOCKIERT

- AOSP Source Setup (benötigt 64GB RAM, 400GB Disk)
- Physisches iPhone X Booten (benötigt physisches Gerät + checkm8)
- Kernel-Kompilierung (Phase 3)
- GUI (Phase 7)
- Apps (Phase 7+)
- Hardware-Treiber (Phase 3+)

## GPL-3.0 Lizenz

Dieses Projekt ist unter der GNU General Public License v3.0 lizenziert. Der vollständige Lizenztext befindet sich in der `LICENSE`-Datei.
