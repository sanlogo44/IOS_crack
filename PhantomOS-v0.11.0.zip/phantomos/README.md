# Phantom OS

**Sichere, datenschutzorientierte Android-basierte Plattform — Für iPhone X (A11 SoC)**

**Version:** 0.11.0 — Terminal App Prototype  
**Lizenz:** GPL-3.0  
**Status:** Framework-Prototyp mit GUI-Widget-Toolkit, Layout-System, Text-Rendering, Konfiguration, Lokalisierung, URI-Schema, App-Sandbox, erweiterten Widgets, Animation System, Theme System, App Lifecycle Manager, IPC Message Bus, Package Manager, Linux Compatibility Layer, Settings App Prototyp und Terminal App Prototyp  
**Entwicklungsphase:** Phase 0 abgeschlossen, Phase 1 (AOSP Setup) BLOCKIERT

---

## Was ist Phantom OS?

Phantom OS ist ein Android-basiertes Betriebssystem, das mit maximaler Datenschutz-Sicherheit, minimaler Telemetrie und kompletter lokaler Kontrolle entwickelt wird. Das Projekt zielt darauf ab, eine funktionsfähige Android-Plattform auf einem iPhone X (A11 SoC) bereitzustellen — unter Einhaltung der Android Compatibility Definition Document (CDD) und der GPL-3.0-Lizenz.

## Aktueller Status (v0.11.0)

### Abgeschlossen:
- Vollständige Systemarchitektur (21 Sektionen)
- Threat Model und Privacy-Architektur
- iPhone X Hardware-Analyse mit Status-Markern
- Framework: Service Manager (Lifecycle, Priority, Health-Check)
- Privacy Layer: Permission Manager (Default-Deny, 15 Berechtigungen, 5 Grant-Typen)
- Privacy Layer: Identity Manager (App-spezifische IDs, Hardware-ID-Schutz)
- Privacy Layer: Data Sanitizer (Location-Approximation, Metadaten-Entfernung)
- HAL: Interfaces für alle Hardware-Komponenten
- HAL: Mock-Implementierungen (iPhone X Simulation)
- Mock Runtime: Demonstriert Framework + Privacy + HAL
- GUI: Geometry, Color, Framebuffer, Surface, Window, WindowManager, Compositor, InputDispatcher
- GUI: Bitmap Font (5x7, ASCII 32-126, Text-Rendering, Clipping)
- GUI: Widget Toolkit (Label, Button, TextField, ListView)
- GUI: Layout-System (LinearLayout vertikal/horizontal, FrameLayout, Gravity, Padding)
- GUI: Erweiterte Widgets (CheckBox, RadioButton mit Group-Support, ProgressBar, Slider)
- GUI: Multi-Line-Text-Rendering (Word-Wrapping, Alignment, TextLine-Struktur)
- GUI: Erweiterte Layouts (RelativeLayout, GridLayout mit Spans)
- GUI: Animation System (Easing Functions, ValueAnimator, PropertyAnimator, Transition, AnimationManager)
- System: Property-Based Configuration (Key-Value, Typed Access, .properties Format)
- System: Lokalisierung (Deutsch/Englisch, 50+ Übersetzungen, Fallback)
- System: Custom URI Scheme (phapp://, Parser, Query-Params, Percent-Encoding)
- System: App Sandbox (Policy-Modell, 4 Profile, Syscall-Rules, File-Access, Capabilities)
- Framework: App Lifecycle Manager (7 States, Lifecycle Callbacks, State History, Start/Pause/Resume/Stop/Destroy)
- System: IPC Message Bus (Endpoint Registration, Send/Broadcast/Round-Robin, Message Types, Delivery Callbacks, Statistics)
- System: Package Manager (Local Repository, Manifest-Based Install/Uninstall/Update, Semantic Versioning, Dependency Resolution, Topological Sort, Cycle Detection, Sandbox Profiles, App Lifecycle Integration)
- System: Linux Compatibility Layer (Simulated Program Execution, Kali/Arch/CSI-Linux Support, Distro Profiles, Package Format Mapping, Process Management, State Callbacks, Package Integration)
- App: Settings App Prototyp (5 Panels, Display/Privacy/Network/Storage/About, HAL-Integration, Config-Integration, Theme-Integration, Privacy-Integration, Widget Tree, Framebuffer Rendering, Touch Handling, State Change Callbacks)
- CMake Build-System
- 29 C++ Test-Suiten (150 neue Testfälle in v0.11.0, alle PASS)
- 10 Python-Projektstruktur-Tests (alle PASS)

### Blockiert:
- AOSP Source Setup (benötigt 64GB RAM, 400GB Disk)
- Physische Hardware-Tests (iPhone X Testgerät erforderlich)

## Schnellstart

```bash
# 1. Build
cd PhantomOS
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j$(nproc)

# 2. Tests ausführen
ctest --output-on-failure

# 3. Mock Runtime starten
./bin/phantom_mock_runtime

# 4. Projektstruktur validieren
python3 ../tools/validate_project.py
python3 ../tests/test_project_structure.py
```

## Projektstruktur

```
PhantomOS/
├── android/              # AOSP Source (leer — Phase 1)
├── boot/                 # Bootloader und Boot ROM Exploit (leer)
├── kernel/               # ARM64 Kernel Source (leer — Phase 3)
├── hal/                  # Hardware Abstraction Layer
│   ├── include/phantom/hal/   # HAL Interfaces
│   └── mock/                 # Mock-Implementierungen
├── framework/            # Phantom OS Framework
│   ├── include/phantom/      # Service Manager, App Lifecycle Manager
│   └── src/                  # Implementierung
├── libraries/
│   ├── privacy/          # Privacy Layer
│   │   ├── include/phantom/privacy/  # Permission, Identity, Data Sanitizer
│   │   └── src/                       # Implementierung
│   ├── config/           # Konfigurationssystem
│   │   ├── include/phantom/config/   # Property-Based Config
│   │   └── src/                        # Implementierung
│   ├── i18n/             # Lokalisierung
│   │   ├── include/phantom/i18n/      # Localization
│   │   └── src/                        # Implementierung
│   ├── uri/              # URI-Schema
│   │   ├── include/phantom/uri/       # URI Parser (phapp://)
│   │   └── src/                        # Implementierung
│   ├── security/         # App Sandbox
│   │   ├── include/phantom/security/ # Sandbox Policy
│   │   └── src/                         # Implementierung
│   └── ipc/              # IPC Message Bus
│       ├── include/phantom/ipc/     # Message Types, Message Bus
│       └── src/                        # Implementierung
│   └── package_manager/  # Package Manager
│       ├── include/phantom/package_manager/  # Package Types, Package Manager
│       └── src/                              # Implementierung
│   └── linux_compat/     # Linux Compatibility Layer
│       ├── include/phantom/linux_compat/     # Linux Program Types, Program Executor
│       └── src/                              # Implementierung
├── system/               # System Runtime
│   └── src/                  # Mock Runtime
├── gui/                  # GUI Framework
│   ├── include/phantom/gui/   # Geometry, Color, Framebuffer, Font, Widgets, Layout
│   └── src/                   # Implementierung
├── apps/                 # Anwendungen
│   ├── settings/        # Settings App Prototyp (v0.10.0)
│   └── terminal/        # Terminal App Prototyp (v0.11.0)
├── drivers/              # Hardware-Treiber (leer — Phase 3+)
├── sdk/                  # Developer SDK (leer)
├── tools/                # Build- und Test-Tools
├── tests/                # Unit Tests
│   ├── unit/                 # C++ Unit Tests
│   └── test_project_structure.py  # Python Struktur-Tests
├── docs/                 # Architektur und Dokumentation
├── CMakeLists.txt        # CMake Build-System
├── README.md             # Diese Datei
├── install.md            # Installationsanleitung
├── TODO.md               # Aufgaben-Tracker
├── Erledigt.md           # Abgeschlossene Aufgaben
├── Getestet.md           # Testergebnisse
└── LICENSE               # GPL-3.0
```

## Schlüsselkomponenten

### Phantom Framework
Service Manager mit Lifecycle-Management (CREATED → STARTING → RUNNING → STOPPING → STOPPED), Prioritätsbasierter Start-Reihenfolge (CRITICAL > HIGH > NORMAL > LOW), Health-Checks und State-Change-Callbacks.

### App Lifecycle Manager (v0.7.0)
Verwaltet den kompletten Lebenszyklus von Anwendungen: 7 States (REGISTERED → STARTING → RUNNING → PAUSED → STOPPING → STOPPED → CRASHED), Lifecycle Callbacks (onCreate, onStart, onResume, onPause, onStop, onDestroy), State History Tracking, Start/Pause/Resume/Stop/Destroy Operationen, Duplicate Detection, Auto-Start Support, Stop-All mit Reverse-Priority-Order.

### Privacy Layer
- **Permission Manager:** Default-Deny mit 15 Berechtigungstypen, 5 Grant-Typen (ALLOW_ONCE, ALLOW_10_MIN, ALLOW_WHILE_USING, ALLOW_ALWAYS, DENY), zeitlich begrenzte Grants, Privacy-Profile (Normal, Privacy, Maximum, Developer, Custom), Location-Approximation (Precise → Approximate → City → Region → Country → None).
- **Identity Manager:** App-spezifische Identifikatoren (keine globalen Geräte-IDs), Hardware-ID-Schutz (IMEI, MAC, Seriennummer standardmäßig DENIED).
- **Data Sanitizer:** Metadaten-Entfernung (GPS, Geräteinfo, Kamera-Metadaten etc.), Location-Approximation auf 6 Genauigkeitsstufen.

### HAL (Hardware Abstraction Layer)
Saubere C++ Interfaces für Display, Input, Storage, Network, Sensors, Camera, Audio, Power. Mock-Implementierungen simulieren iPhone X Hardware (2436x1125 OLED, 458 DPI, 64GB NVMe, Wi-Fi 6, Bluetooth 5.0, A11 Bionic SoC).

### GUI Framework
- **Bitmap Font:** 5x7 Fixed-Width Font für ASCII 32-126, Text-Rendering mit Clipping.
- **Widget Toolkit:** Label (Textanzeige), Button (Klickbar mit Callback), TextField (Editierbar mit Cursor), ListView (Scrollbar mit Item-Callbacks).
- **Layout-System:** LinearLayout (Vertikal/Horizontal, Spacing, Gravity, Padding), FrameLayout (Stacking, Center/Fill-Gravity).

### System-Komponenten (v0.4.0)
- **Configuration:** Property-Based Key-Value Store mit Typed Access (String/Int/Bool/Float), Defaults, .properties Format laden/speichern.
- **Localization (i18n):** Deutsch/Englisch Übersetzungen, Locale-Verwaltung, Fallback-Logik, 50+ vordefinierte UI-Strings.
- **URI Scheme:** phapp:// Parser mit App-ID, Pfad, Query-Parameters, Percent-Encoding/Decoding.
- **App Sandbox:** Policy-Modell mit 4 Profilen (STRICT, NORMAL, DEVELOPER, NETWORK), Syscall-Rules, File-Access-Control, Resource-Limits, Capability-System. Seccomp-bpf als Stub (Prototype-Modus).

### IPC Message Bus (v0.7.0)
In-Process Message Bus für Inter-Process Communication: Endpoint Registration mit Owner-App und Message-Handler, Send (Direct), Broadcast (an alle aktiven Endpoints) und Round-Robin (verteilt auf alle berechtigten Endpoints), Message Types mit Payload und Key-Value Parameters, Endpoint State Management (ACTIVE/INACTIVE/BLOCKED), Allowed Types Filtering, Reply Support, Delivery Callbacks, Message Statistics (Sent/Delivered/Failed per Endpoint und Global).

### Package Manager (v0.8.0)
Lokaler manifest-basierter Package Manager für Installation, Deinstallation und Updates: Package Types (PackageVersion mit Semantic Versioning, PackageDependency mit Version Constraints und optional flag, PackageInfo, PackageManifest mit Permissions, Dependencies, Sandbox Profile und Auto-Start), Install States (AVAILABLE → INSTALLING → INSTALLED → UPDATING → REMOVING → REMOVED → FAILED), 17 Result Codes, Local Repository (addAvailablePackage, removeAvailablePackage), Manifest Validation, Install (from Manifest oder Package ID), Uninstall (Force/Purge Optionen), Update (mit Downgrade-Blocking), Dependency Checking (Version Constraints, Optional Dependencies), Batch Install mit Topological Sort und Cycle Detection, App Lifecycle Integration (Register/Unregister, Permission Transfer, Auto-Start), Query Operations (Installed Packages, Dependents, Dependencies, Available Count), State Change Callbacks.

### Settings App (v0.10.0)
Prototyp einer Settings-Anwendung mit 5 Panels (Display, Privacy, Network, Storage, About): Widget-Tree mit Navigation (5 Buttons), Display-Panel (Brightness-Slider, Dark-Mode-Checkbox), Privacy-Panel (Privacy-Profile RadioButtons, Telemetry/Crash-Reports/Analytics/Tracking CheckBoxes, Location-Accuracy-Label, Permissions-Summary), Network-Panel (Wi-Fi/Bluetooth/Cellular Status), Storage-Panel (ProgressBar, Storage-Info), About-Panel (OS-Version, Device, Battery, Display-Info). Integration mit Config (10 Properties), ThemeManager (Dark/Light Toggle), PermissionManager (Privacy-Profile Selection, Location-Accuracy), HAL (Display/Power/Storage/Network). Framebuffer-Rendering mit rekursivem Widget-Tree-Traversal. Touch-Handling mit Hit-Testing. State-Change-Callbacks. Panel-Visibility (VISIBLE/GONE).

### Terminal App (v0.11.0)
GUI Terminal-Emulator mit Linux Compatibility Layer Integration: 14 Built-in Befehle (help, ls, ps, kill, run, clear, version, uname, echo, whoami, pwd, cd, date, history), Command-Parser mit Quote-Support (doppelte und einfache Anfuehrungszeichen), Output-Buffer mit konfigurierbarem Max-Limit und automatischem Trimming, Command-History mit Up/Down-Navigation, Prompt mit Working-Directory-Anzeige und anpassbarem Prefix, Scrolling (scrollUp/scrollDown/scrollToBottom), Text-Input (insertChar/deleteChar/clearInput/submitInput), ProgramExecutor-Integration (run/ps/kill Befehle fuer registrierte Linux-Programme), Output-Callback fuer externe Listener, Widget-Tree (Output-Area mit Label, Input-Area mit Prompt + TextField), LinearLayout fuer Root/Output/Input, rekursives Framebuffer-Rendering, Touch-Handling mit Hit-Testing, Theme-Integration (Dark/Light Mode), Re-Initialisierung nach Shutdown.

### Linux Compatibility Layer (v0.9.0)
Simulierte Programmausführung für Kali Linux, Arch Linux und CSI-Linux Programme: Linux Distribution Profiles (GENERIC_LINUX, KALI_LINUX, ARCH_LINUX, CSI_LINUX), Package Format Mapping (DEB für Kali, PACMAN für Arch, TAR für CSI/Generic), CPU Architecture Support (ARM64, X86_64, ARMV7), Program Types (CLI, GUI, SERVICE), Process States (REGISTERED → STARTING → RUNNING → EXITED → FAILED → TERMINATED → TIMEOUT), Program Registration (valid/duplicate/invalid/empty path), Program Execution (synchronous mit stdout/stderr capture, asynchronous mit PID allocation), Process Termination (mit state transitions), Timeout Simulation, Process Query (getProcessInfo, getRunningProcesses, getAllProcesses), Multiple Instances Support, State Change Callbacks, Package Integration (registerProgramFromPackage), Distro-Specific Query (getProgramsByDistro).

## Architektur-Dokumentation

Die vollständige Architektur-Dokumentation befindet sich unter `docs/architecture.md` mit folgenden Sektionen:

1. Overview — 2. System Architecture — 3. Kernel — 4. AOSP — 5. Android Runtime — 6. Phantom Framework — 7. Privacy Layer — 8. Security Layer — 9. Phantom HAL — 10. GUI — 11. App System — 12. Google Play — 13. Update System — 14. Hardware — 15. Data Flow — 16. Threat Model — 17. Privacy Model — 18. Development Environment — 19. Test Strategy — 20. Roadmap — 21. Risks

Weitere Dokumentation:
- `docs/privacy.md` — Datenschutz-Dokumentation
- `docs/threat-model.md` — Bedrohungsmodell
- `docs/security-architecture.md` — Sicherheitsarchitektur
- `docs/android-compatibility.md` — Android-Kompatibilität
- `docs/google-play-compatibility.md` — Google Play Assessment
- `docs/roadmap.md` — Entwicklungs-Roadmap

## Datenschutz

Phantom OS folgt dem Prinzip: **So wenig persönliche Daten wie möglich erfassen, speichern und weitergeben.**

- Keine Telemetrie standardmäßig
- Keine automatischen Absturzberichte standardmäßig
- Keine Cloud-Analyse standardmäßig
- Kein Tracking standardmäßig
- Hardware-IDs (IMEI, MAC, Seriennummer) werden standardmäßig nicht an Apps weitergegeben
- App-spezifische Identifikatoren statt globaler Geräte-IDs
- Location-Approximation je nach Privacy-Profil
- Metadaten-Entfernung aus Mediendateien

Siehe `docs/privacy.md` für Details.

## Lizenz

Phantom OS ist unter der GNU General Public License v3.0 (GPL-3.0) lizenziert. Siehe `LICENSE` für den vollständigen Lizenztext.
