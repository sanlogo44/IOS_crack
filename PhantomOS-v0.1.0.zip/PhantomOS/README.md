# Phantom OS

**Ein privacy-by-default, modulares Smartphone-Betriebssystem.**

**Version:** 0.1.0 (Architektur & Phase 0)  
**Datum:** 2026-09-19  
**Lizenz:** GPL-3.0  

---

## Was ist Phantom OS?

Phantom OS ist ein privacy-by-default, hochgradig anpassbares Smartphone-Betriebssystem. Es ist kein gewöhnliches Android-ROM — es ist ein eigenständiges OS mit eigener System-UI, eigenem Framework, eigenen Systemdiensten und tief integrierter Privacy-Schicht, mit Android-App-Kompatibilität.

### Geplante Hauptfunktionen

- **Privacy by default** — Datenminimierung, lokale Verarbeitung, keine Telemetrie
- **Android-App-Kompatibilität** — Android-Apps über integrierte Runtime ausführen
- **Futuristische GUI** — Vollständig anpassbare, moderne System-UI
- **Modulare Architektur** — Jedes Subsystem unabhängig austauschbar
- **Security first** — SELinux, Sandboxing, Verified Boot, Verschlüsselung
- **Multi-Hardware** — Initial iPhone X, für Erweiterung konzipiert

---

## Zielhardware

### Primär: Apple iPhone X (A11 Bionic)

| Spezifikation | Wert |
|---------------|------|
| SoC | Apple A11 Bionic (10nm, TSMC) |
| CPU | 2× Monsoon (2.39 GHz) + 4× Mistral (1.42 GHz) |
| GPU | Apple-designtes 3-Kern-GPU |
| RAM | 3 GB LPDDR4X |
| Speicher | 64/256 GB NVMe (ANS2) |
| Display | 5.8" OLED, 2436×1125, 458 ppi |
| Modem | Qualcomm MDM9655 oder Intel XMM 7480 |
| Wi-Fi | 802.11 a/b/g/n/ac |
| Bluetooth | 5.0 |
| Biometrie | Face ID (TrueDepth + Secure Enclave) |

### Boot-Chain

Phantom OS bootet auf dem iPhone X über den checkm8 Boot-ROM-Exploit (CVE-2019-8900), eine unpatchbare Hardware-Schwachstelle in A5-A11 Apple-Chips ([Wikipedia: checkm8](https://en.wikipedia.org/wiki/Checkm8)). Die Boot-Chain verläuft über PongoOS, eine Pre-Boot-Umgebung, in den Linux-Kernel und das Phantom OS Userspace.

### Hardware-Status

Die meisten iPhone-X-Hardwarekomponenten sind derzeit `UNKNOWN` — es existieren keine öffentlichen Linux-Treiber. Siehe [docs/hardware-iphone-x.md](./docs/hardware-iphone-x.md) für detaillierten Status. Das postmarketOS-Projekt hat Teil-Boots auf dem iPhone X erreicht, wobei USB-Netzwerk und interner Speicher funktionieren, aber Touchscreen, Wi-Fi, Bluetooth, Audio, Kamera, GPS und Modem sind nicht funktionsfähig ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))).

---

## Architektur

```
                         PHANTOM OS
                              │
               ┌──────────────┴──────────────┐
               │                             │
        Phantom Native Apps             Android Apps
               │                             │
               │                       Android Runtime
               │                             │
               └──────────────┬──────────────┘
                              │
                    Phantom Framework
                    Phantom Services
                      Privacy Layer
                       Security Layer
                         Phantom HAL
                    Hardware / Kernel
                       iPhone Hardware
```

Siehe [docs/architecture.md](./docs/architecture.md) für das vollständige Architekturdokument.

---

## Privacy

Phantom OS Privacy ist nicht nur eine Einstellung — sie ist tief in das OS integriert:

- **Default deny** — Alle Berechtigungen standardmäßig verweigert
- **Datenminimierung** — Nur notwendige Daten werden erhoben
- **Lokale Verarbeitung** — Daten werden auf dem Gerät verarbeitet
- **App-spezifische Identifikatoren** — Keine globalen Geräte-IDs für Apps
- **Metadaten-Entfernung** — Bereinigte Dateifreigabe
- **Netzwerk-Privacy** — DNS-Verschlüsselung, Tracker-Blocking, Per-App-Firewall
- **Keine Telemetrie** — Keine Analytics, keine Crash-Reports standardmäßig

Siehe [docs/privacy.md](./docs/privacy.md) und [docs/privacy-architecture.md](./docs/privacy-architecture.md) für Details.

---

## Security

- SELinux standardmäßig im Enforcing-Modus
- Per-App-Sandboxing (UID, Namespace, seccomp-bpf)
- File-based Encryption (FBE)
- Verified Boot (dm-verity)
- Signierte Updates mit Rollback-Schutz

Siehe [docs/security-architecture.md](./docs/security-architecture.md) für Details.

---

## Android-Kompatibilität

Android-Apps laufen über eine integrierte Android Runtime, wobei Berechtigungen durch die Phantom Privacy Layer abgefangen werden. Phantom OS funktioniert vollständig ohne Google-Dienste. Siehe [docs/android-compatibility.md](./docs/android-compatibility.md) für Details.

---

## Google-Play-Kompatibilität

Volle Google-Play-Kompatibilität ist `CURRENTLY NOT FEASIBLE` aufgrund von GMS-Lizenzanforderungen und Hardware-Zertifizierung. Phantom OS ist für den Betrieb ohne Google-Dienste konzipiert. Siehe [docs/google-play-compatibility.md](./docs/google-play-compatibility.md) für Details.

---

## Roadmap

| Phase | Name | Status |
|-------|------|--------|
| 0 | Entwicklungsumgebung | COMPLETE |
| 1 | Repository | COMPLETE |
| 2 | AOSP-Integration | NOT STARTED |
| 3 | Phantom Framework | NOT STARTED |
| 4 | Privacy Layer | NOT STARTED |
| 5 | Security Layer | NOT STARTED |
| 6 | Futuristische GUI | NOT STARTED |
| 7 | Android Apps | NOT STARTED |
| 8 | HAL | NOT STARTED |
| 9 | iPhone Boot | NOT STARTED |
| 10-22 | Hardware-Funktionen | NOT STARTED |
| 23 | OTA-Updates | NOT STARTED |
| 24 | Phantom SDK | NOT STARTED |
| 25 | Native Apps | NOT STARTED |
| 26 | Google-Play-Kompatibilität | NOT STARTED |
| 27 | Eigene Kernel-Komponenten | NOT STARTED |
| 28 | Multi-Hardware | NOT STARTED |
| 29 | Release Candidate | NOT STARTED |

Siehe [docs/roadmap.md](./docs/roadmap.md) für die vollständige Roadmap.

---

## Build

### Voraussetzungen (Phase 0)

```bash
sudo apt-get install -y git python3 python3-pip build-essential zip unzip
```

### Projekt validieren

```bash
python3 tools/validate_project.py
```

### Tests ausführen

```bash
python3 tests/test_project_structure.py
```

Siehe [install.md](./install.md) für vollständige Build- und Installationsanweisungen.

---

## Projektstruktur

```
PhantomOS/
├── android/          # AOSP-Integration und Patches
├── kernel/           # Kernel-Quellcode und Konfiguration
├── boot/             # Boot-Chain (checkm8, PongoOS-Integration)
├── hal/              # Hardware Abstraction Layer
├── drivers/          # Hardware-Treiber
├── framework/        # Phantom Framework (Systemdienste, APIs)
├── system/           # Core-Systemkomponenten
├── gui/              # System-UI (Launcher, Lockscreen, Settings)
├── apps/             # Phantom Native Apps
├── libraries/        # Shared Libraries
├── sdk/              # Phantom SDK für App-Entwicklung
├── tools/            # Build- und Validierungstools
├── tests/            # Automatisierte Tests
├── docs/             # Dokumentation
├── README.md
├── TODO.md
├── Erledigt.md
├── Getestet.md
├── install.md
└── LICENSE
```

---

## Status

**Aktuelle Version:** 0.1.0 — Architektur & Phase 0

Diese Version enthält:
- Vollständige Architektur-Dokumentation (alle 20 geforderten Sektionen)
- Projekt-Repository-Skeleton (14 Verzeichnisse)
- Entwicklungsumgebungs-Dokumentation
- Projekt-Validierungstools und Tests
- Hardware-Recherche und Machbarkeitsanalyse
- Git-Repository initialisiert

Diese Version enthält NICHT:
- Bootbaren OS-Code
- AOSP-Integration
- Hardware-Treiber
- iPhone-X-Boot-Fähigkeit

---

## Bekannte Einschränkungen

1. Die meisten iPhone-X-Hardwarekomponenten haben keine Linux-Treiber (`UNKNOWN`)
2. Secure-Enclave-(SEP)-Treiber existiert nicht — Face ID möglicherweise nicht verfügbar
3. Wi-Fi, Bluetooth, GPS, Modem, Audio, Kamera — alle nicht funktionsfähig in aktuellen Linux-Ports
4. Google-Play-Zertifizierung ist für ein Custom-OS auf iPhone X nicht realistisch
5. A11 kann nicht aus DFU booten, wenn DFU über Force-Reset erreicht wurde — `libirecovery` erforderlich
6. Technische Dokumentation ist auf Englisch verfasst (internationaler Entwickler-Standard); Übersetzung auf Deutsch auf Anfrage

---

## Lizenz

Phantom OS ist unter der GNU General Public License v3.0 lizenziert. Siehe [LICENSE](./LICENSE) für den vollständigen Lizenztext.

---

## Referenzen

- [checkm8 — Wikipedia](https://en.wikipedia.org/wiki/Checkm8)
- [postmarketOS iPhone X Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))
- [Project Sandcastle](https://projectsandcastle.org/)
- [Apple A11 — Wikipedia](https://en.wikipedia.org/wiki/Apple_A11)
- [iPhone X — Wikipedia](https://en.wikipedia.org/wiki/IPhone_X)
- [AOSP Build Requirements](https://source.android.com/docs/setup/start/requirements)
- [Google Mobile Services](https://www.android.com/gms/)
- [Play Integrity API](https://developer.android.com/google/play/integrity)
- [palera1n — GitHub](https://github.com/palera1n/palera1n)
- [Apple Platform Security Guide](https://help.apple.com/pdf/security/en_US/apple-platform-security-guide.pdf)
