# Phantom OS – Installations- und Build-Anleitung

**Version:** 0.1.0  
**Datum:** 2026-09-19  

---

## 1. Voraussetzungen

### 1.1 Host-System

| Anforderung | Phase 0 | Phase 2+ (AOSP) |
|-------------|---------|-----------------|
| OS | Ubuntu 22.04+ oder Debian 12+ | Ubuntu 22.04+ |
| Architektur | 64-bit x86 | 64-bit x86 |
| RAM | 4 GB | 64 GB |
| Speicher | 5 GB frei | 500 GB frei |
| CPU | 2 Kerne | 8+ Kerne |

### 1.2 Benötigte Pakete

```bash
sudo apt-get update
sudo apt-get install -y \
    git \
    python3 \
    python3-pip \
    build-essential \
    zip \
    unzip \
    curl
```

---

## 2. Abhängigkeiten

### 2.1 Phase 0: Abhängigkeiten

- Python 3.8+
- Git

### 2.2 Phase 2+: AOSP-Abhängigkeiten (GEPLANT — noch nicht implementiert)

```bash
# HINWEIS: Diese Pakete werden für Phase 2+ benötigt, noch nicht für Phase 0.
# Status: PLANNED — noch nicht getestet.
sudo apt-get install -y \
    git-core gnupg flex bison build-essential zip curl \
    zlib1g-dev libc6-dev-i386 x11proto-core-dev libx11-dev \
    lib32z1-dev libgl1-mesa-dev libxml2-utils xsltproc \
    unzip fontconfig repo
```

AOSP benötigt 400 GB Speicherplatz (250 GB Checkout + 150 GB Build) und mindestens 64 GB RAM ([AOSP Setup Guide](https://source.android.com/docs/setup/start/requirements)).

### 2.3 iPhone X Entwicklungs-Abhängigkeiten (GEPLANT — noch nicht getestet)

```bash
# HINWEIS: Diese Tools werden für Phase 9+ benötigt.
# Status: PLANNED — noch nicht getestet mit Phantom OS.
sudo apt-get install -y \
    libimobiledevice-dev \
    libusb-1.0-0-dev \
    libreadline-dev
```

---

## 3. Build

### 3.1 Phase 0: Projekt-Validierung

```bash
# Projekt aus ZIP entpacken
unzip PhantomOS-v0.1.0.zip
cd PhantomOS

# Projektstruktur validieren
python3 tools/validate_project.py

# Tests ausführen
python3 tests/test_project_structure.py
```

Dies ist der einzige funktionierende Build-Schritt in v0.1.0. Alle weiteren Build-Schritte sind `PLANNED` und noch nicht implementiert.

### 3.2 Phase 2+: AOSP-Build (GEPLANT — noch nicht implementiert)

```bash
# Status: PLANNED — noch nicht funktionsfähig.
# Die folgenden Befehle sind geplant, aber noch NICHT getestet.

# AOSP-Repository initialisieren (Phase 2)
mkdir -p ~/aosp
cd ~/aosp
repo init -u https://android.googlesource.com/platform/manifest -b android14-release
repo sync

# Phantom OS Patches anwenden (Phase 2)
# (noch nicht implementiert)

# Build (Phase 2)
source build/envsetup.sh
lunch phantom-iphone_x-userdebug
m
```

**Achtung:** Der AOSP-Build ist in v0.1.0 NICHT implementiert. Die obigen Befehle sind geplante Workflow-Schritte.

---

## 4. Emulator

### 4.1 QEMU (ARM64) — GEPLANT

Für Tests der Phantom OS Userspace ohne physische Hardware:

```bash
# Status: PLANNED — noch nicht implementiert.
sudo apt-get install -y qemu-system-aarch64
```

### 4.2 Android Emulator — GEPLANT

```bash
# Status: PLANNED — Phase 7+.
```

---

## 5. Tests

### 5.1 Projektstruktur-Tests (funktionsfähig)

```bash
python3 tests/test_project_structure.py
```

Erwartetes Ergebnis: 11 Tests, alle PASS.

### 5.2 Unit-Tests — GEPLANT

```bash
# Status: PLANNED — Phase 3+.
```

### 5.3 Hardware-Tests — GEPLANT

```bash
# Status: PLANNED — Phase 9+.
```

---

## 6. Hardware (iPhone X)

### 6.1 Geräte-Vorbereitung

**Warnung:** Das Modifizieren des iPhone X-Speichers kann irreversibel sein. NVMe-Namespace 2 darf NICHT verändert werden — Daten sind selbst mit DFU-Restore nicht wiederherstellbar ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))).

### 6.2 DFU-Modus — GEPLANT (Phase 9+)

1. iPhone X mit USB-A-auf-Lightning-Kabel an Host verbinden
2. Gerät ausschalten
3. Recovery-Modus aktivieren (Halten bis Apple-Logo erscheint und verschwindet)
4. DFU-Modus aktivieren:
   - `irecovery -c reset` auf Host ausführen (erforderlich für A11)
   - Für 2 Sekunden halten
   - Für 8 Sekunden loslassen (PongoOS/palera1n-Anweisungen befolgen)

**Hinweis:** A11 kann nicht aus DFU booten, wenn DFU über Force-Reset erreicht wurde — `libirecovery` ist erforderlich ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))).

**Status:** `PLANNED` — Noch nicht mit Phantom OS getestet.

### 6.3 Phantom OS booten — GEPLANT (Phase 9+)

```bash
# Status: PLANNED — noch nicht implementiert.
# Wird checkm8 → PongoOS → Linux Kernel → Phantom OS verwenden.
```

---

## 7. iPhone X Entwicklung

### 7.1 Kabel-Anforderungen

- USB-A-auf-Lightning-Kabel: FUNKTIONIERT (laut postmarketOS)
- USB-C-auf-Lightning-Kabel: FUNKTIONIERT MÖGLICHERWEISE NICHT im DFU-Modus
- USB-C-only-Hosts: USB-A-auf-USB-C-Adapter verwenden

### 7.2 Firmware-Anforderung

Linux-Speicher-Support erfordert Geräte-Firmware mindestens iOS 14 aufgrund von RTKit-Protokoll-Einschränkungen ([postmarketOS Wiki](https://wiki.postmarketos.org/wiki/Apple_iPhone_X_(Global)_(apple-d22))).

### 7.3 Recovery

Das Gerät kann mit `idevicerestore` zu iOS zurückgesetzt werden, aber nur zu einer signierten Version (in der Regel die neueste verfügbare).

---

## 8. Debugging

### 8.1 USB-Netzwerk — GEPLANT (Phase 9+)

Wenn Phantom OS über checkm8/PongoOS bootet, ist USB-Netzwerk die primäre Debugging-Schnittstelle (funktioniert in postmarketOS auf iPhone X).

```bash
# Status: PLANNED — noch nicht implementiert.
```

---

## 9. Recovery

### 9.1 Zurück zu iOS

```bash
# Auf neueste signierte iOS-Version zurücksetzen
idevicerestore --latest
```

**Warnung:** Dies löscht alle Daten auf dem Gerät.

### 9.2 Recovery-Modus

Wenn das Gerät hängen bleibt:
1. Mit Host verbinden
2. Recovery-Modus aktivieren
3. `idevicerestore` verwenden

---

## 10. Bekannte Einschränkungen

1. **Kein bootbares OS** — v0.1.0 ist nur Architektur und Dokumentation
2. **Kein AOSP-Build** — AOSP-Integration beginnt in Phase 2
3. **Keine Hardware-Treiber** — Die meisten iPhone-X-Komponenten haben keine Linux-Treiber
4. **Kein iPhone-X-Boot** — Boot-Fähigkeit beginnt in Phase 9
5. **A11-DFU-Limitation** — Kann nicht aus DFU booten, wenn über Force-Reset erreicht
6. **NVMe-Namespace 2** — Darf nicht modifiziert werden (irreversibel)
7. **iOS 14+ Firmware** — Erforderlich für Linux-NVMe-Speicher-Support
8. **USB-C-Kabel** — Funktionieren möglicherweise nicht im DFU-Modus
9. **Secure Enclave** — Kein öffentlicher Linux-Treiber; Face ID möglicherweise nicht funktionsfähig
10. **Wi-Fi/Bluetooth/GPS/Modem** — Alle nicht funktionsfähig in aktuellen Linux-Ports
