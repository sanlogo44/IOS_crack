#!/usr/bin/env python3
"""
Phantom OS - Project Structure Validator

Validates that the Phantom OS project repository has the correct structure,
required files, and documentation.
"""

import os
import sys

# Project root is the parent of the tools directory
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

REQUIRED_DIRS = [
    "android",
    "kernel",
    "boot",
    "hal",
    "drivers",
    "framework",
    "system",
    "gui",
    "apps",
    "libraries",
    "sdk",
    "tools",
    "tests",
    "docs",
]

REQUIRED_FILES = [
    "README.md",
    "TODO.md",
    "Erledigt.md",
    "Getestet.md",
    "install.md",
    "LICENSE",
]

REQUIRED_DOCS = [
    "docs/architecture.md",
    "docs/hardware-iphone-x.md",
    "docs/privacy.md",
    "docs/privacy-architecture.md",
    "docs/data-flows.md",
    "docs/threat-model.md",
    "docs/security-architecture.md",
    "docs/android-compatibility.md",
    "docs/google-play-compatibility.md",
    "docs/roadmap.md",
    "docs/phase-0-development-environment.md",
]

REQUIRED_TOOLS = [
    "tools/validate_project.py",
]

REQUIRED_TESTS = [
    "tests/test_project_structure.py",
]

# Architecture document must contain these sections
ARCH_REQUIRED_SECTIONS = [
    "Overview",
    "System Architecture",
    "Kernel",
    "AOSP",
    "Android Runtime",
    "Phantom Framework",
    "Privacy Layer",
    "Security Layer",
    "Phantom HAL",
    "GUI",
    "App System",
    "Google Play Compatibility",
    "Update System",
    "Hardware Abstraction",
    "Data Flow",
    "Threat Model",
    "Privacy Model",
    "Development Environment",
    "Test Strategy",
    "Roadmap",
    "Risks",
]


def check_directory_exists(name, path):
    """Check if a directory exists."""
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isdir(full_path):
        return True, f"  [PASS] Directory exists: {path}"
    else:
        return False, f"  [FAIL] Directory missing: {path}"


def check_file_exists(name, path):
    """Check if a file exists and is non-empty."""
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isfile(full_path):
        size = os.path.getsize(full_path)
        if size > 0:
            return True, f"  [PASS] File exists ({size} bytes): {path}"
        else:
            return False, f"  [FAIL] File is empty: {path}"
    else:
        return False, f"  [FAIL] File missing: {path}"


def check_doc_sections(path, required_sections):
    """Check if a documentation file contains required sections."""
    full_path = os.path.join(PROJECT_ROOT, path)
    if not os.path.isfile(full_path):
        return False, f"  [FAIL] Document missing: {path}"

    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()

    missing = []
    for section in required_sections:
        if section.lower() not in content.lower():
            missing.append(section)

    if missing:
        return False, f"  [FAIL] {path} missing sections: {', '.join(missing)}"
    else:
        return True, f"  [PASS] {path} contains all required sections"


def check_no_fabricated_hardware():
    """Check that hardware documentation uses status markers, not fabricated specs."""
    full_path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
    if not os.path.isfile(full_path):
        return False, "  [FAIL] hardware-iphone-x.md missing"

    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Check for status markers
    status_markers = ["KNOWN", "UNKNOWN", "PARTIALLY KNOWN", "REVERSE ENGINEERED",
                      "NOT FEASIBLE", "CURRENTLY NOT FEASIBLE", "NEEDS RESEARCH"]
    has_markers = any(marker in content for marker in status_markers)

    if has_markers:
        return True, "  [PASS] Hardware documentation uses status markers"
    else:
        return False, "  [FAIL] Hardware documentation missing status markers"


def main():
    print("=" * 60)
    print("  Phantom OS - Project Structure Validation")
    print("=" * 60)
    print()

    all_passed = True
    errors = []

    # Check directories
    print("Checking directories...")
    for d in REQUIRED_DIRS:
        passed, msg = check_directory_exists(d, d)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing directory: {d}")
    print()

    # Check required files
    print("Checking required files...")
    for f in REQUIRED_FILES:
        passed, msg = check_file_exists(f, f)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing file: {f}")
    print()

    # Check documentation
    print("Checking documentation...")
    for doc in REQUIRED_DOCS:
        passed, msg = check_file_exists(doc, doc)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing doc: {doc}")
    print()

    # Check architecture sections
    print("Checking architecture document sections...")
    passed, msg = check_doc_sections("docs/architecture.md", ARCH_REQUIRED_SECTIONS)
    print(msg)
    if not passed:
        all_passed = False
        errors.append("Architecture document missing sections")
    print()

    # Check tools
    print("Checking tools...")
    for t in REQUIRED_TOOLS:
        passed, msg = check_file_exists(t, t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing tool: {t}")
    print()

    # Check tests
    print("Checking tests...")
    for t in REQUIRED_TESTS:
        passed, msg = check_file_exists(t, t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing test: {t}")
    print()

    # Check no fabricated hardware data
    print("Checking for fabricated hardware data...")
    passed, msg = check_no_fabricated_hardware()
    print(msg)
    if not passed:
        all_passed = False
        errors.append("Fabricated hardware data detected")
    print()

    # Summary
    print("=" * 60)
    if all_passed:
        print("  RESULT: ALL CHECKS PASSED")
    else:
        print(f"  RESULT: {len(errors)} ERRORS FOUND")
        for e in errors:
            print(f"    - {e}")
    print("=" * 60)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
