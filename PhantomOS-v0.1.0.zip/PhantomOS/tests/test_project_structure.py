#!/usr/bin/env python3
"""
Phantom OS - Project Structure Tests

Tests for project structure integrity, required file presence,
and documentation completeness.
"""

import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestProjectStructure(unittest.TestCase):
    """Test that all required directories exist."""

    REQUIRED_DIRS = [
        "android", "kernel", "boot", "hal", "drivers", "framework",
        "system", "gui", "apps", "libraries", "sdk", "tools", "tests", "docs",
    ]

    def test_required_directories_exist(self):
        for d in self.REQUIRED_DIRS:
            path = os.path.join(PROJECT_ROOT, d)
            self.assertTrue(os.path.isdir(path), f"Directory missing: {d}")

    def test_required_files_exist(self):
        required_files = [
            "README.md", "TODO.md", "Erledigt.md", "Getestet.md",
            "install.md", "LICENSE",
        ]
        for f in required_files:
            path = os.path.join(PROJECT_ROOT, f)
            self.assertTrue(os.path.isfile(path), f"File missing: {f}")
            self.assertGreater(os.path.getsize(path), 0, f"File is empty: {f}")


class TestDocumentation(unittest.TestCase):
    """Test that all required documentation exists."""

    REQUIRED_DOCS = [
        "docs/architecture.md",
        "docs/hardware-iphone-x.md",
        "docs/privacy.md",
        "docs/privacy-architecture.md",
        "docs/data-flows.md",
        "docs/threat-model.md",
        "docs/security-architecture.md",
        "docs/android-compatibility.md",
        "docs/google-play-compatibility.md",
        "docs/roadmap.md",
        "docs/phase-0-development-environment.md",
    ]

    def test_required_docs_exist(self):
        for doc in self.REQUIRED_DOCS:
            path = os.path.join(PROJECT_ROOT, doc)
            self.assertTrue(os.path.isfile(path), f"Doc missing: {doc}")
            self.assertGreater(os.path.getsize(path), 100, f"Doc too small: {doc}")

    def test_architecture_has_required_sections(self):
        path = os.path.join(PROJECT_ROOT, "docs/architecture.md")
        with open(path, "r") as f:
            content = f.read()

        required_sections = [
            "Overview", "Kernel", "AOSP", "Android Runtime",
            "Phantom Framework", "Privacy Layer", "Security Layer",
            "Phantom HAL", "GUI", "App System", "Google Play",
            "Update System", "Hardware", "Data Flow", "Threat Model",
            "Privacy Model", "Development Environment", "Test Strategy",
            "Roadmap", "Risks",
        ]
        for section in required_sections:
            self.assertIn(section.lower(), content.lower(),
                         f"Architecture missing section: {section}")

    def test_hardware_doc_has_status_markers(self):
        path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
        with open(path, "r") as f:
            content = f.read()

        markers = ["KNOWN", "UNKNOWN", "PARTIALLY KNOWN"]
        for marker in markers:
            self.assertIn(marker, content, f"Hardware doc missing status marker: {marker}")

    def test_privacy_doc_has_phantom_principle(self):
        path = os.path.join(PROJECT_ROOT, "docs/privacy.md")
        with open(path, "r") as f:
            content = f.read()

        self.assertIn("not collected", content.lower())

    def test_roadmap_has_all_phases(self):
        path = os.path.join(PROJECT_ROOT, "docs/roadmap.md")
        with open(path, "r") as f:
            content = f.read()

        for phase in range(30):
            self.assertIn(f"Phase {phase}", content, f"Roadmap missing Phase {phase}")


class TestNoFabricatedData(unittest.TestCase):
    """Test that no fabricated hardware data is present."""

    def test_hardware_doc_has_no_fake_registers(self):
        path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
        with open(path, "r") as f:
            content = f.read()

        # Should not have fabricated register addresses
        fake_patterns = ["0xDEADBEEF", "0xCAFEBABE", "fake_register", "TODO: add register"]
        for pattern in fake_patterns:
            self.assertNotIn(pattern, content, f"Fabricated data found: {pattern}")

    def test_hardware_doc_uses_unknown_status(self):
        path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
        with open(path, "r") as f:
            content = f.read()

        # Should have UNKNOWN status for uncertain components
        self.assertIn("UNKNOWN", content)
        self.assertIn("PARTIALLY KNOWN", content)


class TestToolsAndTests(unittest.TestCase):
    """Test that tools and tests exist."""

    def test_validate_tool_exists(self):
        path = os.path.join(PROJECT_ROOT, "tools/validate_project.py")
        self.assertTrue(os.path.isfile(path), "validate_project.py missing")
        self.assertGreater(os.path.getsize(path), 100)

    def test_test_file_exists(self):
        path = os.path.join(PROJECT_ROOT, "tests/test_project_structure.py")
        self.assertTrue(os.path.isfile(path), "test_project_structure.py missing")
        self.assertGreater(os.path.getsize(path), 100)


if __name__ == "__main__":
    unittest.main(verbosity=2)
