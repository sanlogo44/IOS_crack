# Phantom OS – TODO

**Letztes Update:** 2026-09-19  
**Version:** 0.4.0

---

## Projekt-Tracking

### v0.4.0 — Widget Toolkit + System-Komponenten — ABGESCHLOSSEN ✓

- [x] Bitmap Font (5x7, ASCII 32-126, Text-Rendering, Clipping)
- [x] Widget Toolkit (Button, Label, TextField, ListView)
- [x] Layout-System (LinearLayout, FrameLayout)
- [x] Property-Based Configuration System
- [x] Custom URI Scheme (phapp://)
- [x] Lokalisierung-System (Deutsch, Englisch)
- [x] App Sandbox System (Policy-Modell, seccomp-bpf Stub)
- [x] 253 neue Unit-Tests (7 Test-Suiten, 100% PASS)
- [x] CMake-Build-System erweitert (8 Libraries, 18 Tests)
- [x] ZIP erstellt und validiert

### v0.5.0 — Nächste Schritte (AUSSTEHEND)

- [ ] Text-Rendering Erweiterung (Multi-Line, Text-Wrapping)
- [ ] Widget-Erweiterungen (CheckBox, RadioButton, ProgressBar, Slider)
- [ ] Layout-Erweiterungen (RelativeLayout, GridLayout)
- [ ] Animation System (Tween, Transition)
- [ ] Theme System (Dark/Light Mode)
- [ ] App Lifecycle Manager (Start, Stop, Pause, Resume)
- [ ] Inter-Process Communication (IPC) Framework
- [ ] Package Manager / Installer
- [ ] Settings App Prototyp
- [ ] AOSP Environment Vorbereitung (BLOCKIERT — 64GB RAM, 400GB Disk)

### Phase 1: AOSP Setup (BLOCKIERT — Physische Ressourcen erforderlich)

- [ ] Debian/Ubuntu Linux PC einrichten (64GB RAM, 400GB Disk)
- [ ] AOSP Source Download (~150GB)
- [ ] Build-Umgebung konfigurieren (ccache, Java, Python)
- [ ] Kali Linux 2-VM Setup für Network Intrusion Detection
- [ ] Treiber-Dokumentation für iPhone X erstellen
- [ ] Hardware-Verifizierung dokumentieren

### Phase 2: Jailbreak und Boot (NEEDS RESEARCH)

- [ ] checkm8 Boot ROM Exploit dokumentieren
- [ ] postmarketOS Cross-compile Toolchain einrichten
- [ ] Treiber für Wi-Fi, Bluetooth, GPU testen
- [ ] Boot-Strategie evaluieren (Boot ROM vs Side-Loaded)
- [ ] GMS-Lizenzing-Kosten recherchieren (ausstehend)
- [ ] Kernel Support Status für iPhone X (needs verification)
- [ ] GPU- und Display-Treiber Status für iPhone X (needs verification)

### Phase 3+: Kernel & Treiber

- [ ] ARM64 Kernel Compilation mit ccache
- [ ] Treiber für Wi-Fi (Broadcom), Bluetooth, Modem, Audio, GPU, Display, USB, Power
- [ ] SEP-Interface dokumentieren (Secure Enclave Processor)
- [ ] Face ID / Touch ID Evaluierung (möglicherweise CURRENTLY NOT FEASIBLE)
- [ ] Init-System für Phantom OS

### Phase 5+: Framework & System

- [ ] System Server / Init Process
- [ ] Inter-Process Communication (IPC)
- [ ] Package Manager / Installer
- [ ] Security Sandbox Implementation (seccomp-bpf aktivieren)
- [ ] Network Intrusion Detection System

### Phase 7+: GUI Erweiterung & Apps

- [ ] Erweiterte Widgets (CheckBox, RadioButton, ProgressBar, Slider)
- [ ] RelativeLayout, GridLayout
- [ ] Animation System
- [ ] Theme System
- [ ] Settings App
- [ ] Phone App (Telefon/Anruf)
- [ ] Wi-Fi Settings
- [ ] Bluetooth Settings
- [ ] Camera App
- [ ] Media Player
- [ ] Web Browser
- [ ] Terminal

### Phase 10+: Hardware Verifizierung

- [ ] Physisches iPhone X Testgerät beschaffen
- [ ] Boot Test mit checkm8
- [ ] Display Ausgabe Test
- [ ] Touch Input Test
- [ ] Wi-Fi Connectivity Test
- [ ] Bluetooth Test
- [ ] Audio Test
- [ ] Kamera Test
- [ ] GPS Test
- [ ] Modem/LTE Test
- [ ] Face ID / SEP Test

### Phase 12+: Update & Recovery

- [ ] Update-System (OTA / Local / Emergency)
- [ ] Recovery-Modus
- [ ] Rollback-Mechanismus
- [ ] Backup & Restore

### Phase 13: Google Play & Zertifizierung

- [ ] GMS-Lizenz beantragen (ausstehend — Preis konnte nicht verifiziert werden)
- [ ] MLO-Pflichtklassen implementieren (Remote Notification, Cloud Messaging, etc.)
- [ ] Hardware-Security-Modul integrieren (Trusty TEE)
- [ ] SafetyNet Attestation
- [ ] Play Integrity API
- [ ] CTS Tests durchführen
- [ ] Google MLO Review
- [ ] Google Play Account erstellen ($25)

### Phase 15: Final Release

- [ ] Alle Tests bestanden
- [ ] GPL-3.0 Lizenz finalisiert
- [ ] Build-System vollständig dokumentiert
- [ ] Installationsanleitung finalisiert
- [ ] Recovery-Modus getestet
- [ ] Öffentliche Veröffentlichung

---

## Ungeklärte Fragen / BLOCKIERT

- [ ] GMS-Lizenzierungsbedingungen und Kosten (konnten nicht verifiziert werden — MUST RESEARCH)
- [ ] Apple Watch / Apple TV Unterstützung (spätere Phase)
- [ ] Project Sandcastle als Boot-Strategie für iPhone X (ONLY FOR iPhone 7/7+)
- [ ] Kernel Support Status für iPhone X (needs verification)
- [ ] GPU- und Display-Treiber Status für iPhone X (needs verification)
- [ ] AOSP Build in Sandbox (BLOCKIERT — 64GB RAM, 400GB Disk erforderlich)
