#!/usr/bin/env python3
"""
Phantom OS - Project Structure Tests v0.23.0
"""

import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestPhantomOSDirectories(unittest.TestCase):
    """Test that all required directories exist."""

    REQUIRED_DIRS = [
        "android", "kernel", "boot", "hal", "drivers", "framework",
        "system", "gui", "apps", "libraries", "sdk", "tools", "tests", "docs",
        "framework/include/phantom", "framework/src",
        "libraries/privacy/include/phantom/privacy", "libraries/privacy/src",
        "libraries/config/include/phantom/config", "libraries/config/src",
        "libraries/i18n/include/phantom/i18n", "libraries/i18n/src",
        "libraries/uri/include/phantom/uri", "libraries/uri/src",
        "libraries/security/include/phantom/security", "libraries/security/src",
        "libraries/ipc/include/phantom/ipc", "libraries/ipc/src",
        "libraries/package_manager/include/phantom/package_manager", "libraries/package_manager/src",
        "libraries/linux_compat/include/phantom/linux_compat", "libraries/linux_compat/src",
        "hal/include/phantom/hal", "hal/mock",
        "system/src", "tests/unit",
        "gui/include/phantom/gui", "gui/src",
        "gui/include/phantom/gui/widgets", "gui/src/widgets",
        # v0.10.0 Settings App
        "apps/settings/include/phantom/settings", "apps/settings/src",
        # v0.11.0 Terminal App
        "apps/terminal/include/phantom/terminal", "apps/terminal/src",
        # v0.12.0 File Manager
        "apps/filemanager/include/phantom/filemanager", "apps/filemanager/src",
        # v0.13.0 System Monitor
        "apps/sysmon/include/phantom/sysmon", "apps/sysmon/src",
        # v0.14.0 NIDS
        "security/nids/include/phantom/nids", "security/nids/src",
        # v0.15.0 System Server
        "system/server/include/phantom/sysserver", "system/server/src",
        # v0.16.0 Driver Framework
        "drivers/framework/include/phantom/drivers", "drivers/framework/src",
        # v0.17.0 Log Server
        "system/logging/include/phantom/logging", "system/logging/src",
        # v0.18.0 Notification Manager + v0.19.0 Crash Reporter + v0.20.0 Update Manager
        "system/notifications/include/phantom/notifications", "system/notifications/src",
        "system/crashreporter/include/phantom/crashreporter", "system/crashreporter/src",
        "system/updatemanager/include/phantom/updatemanager", "system/updatemanager/src",
        # v0.21.0 Backup & Restore Manager
        "system/backup/include/phantom/backup", "system/backup/src",
        # v0.22.0 Recovery Mode Manager
        "system/recovery/include/phantom/recovery", "system/recovery/src",
        # v0.23.0 KeyStore / Crypto Service
        "system/keystore/include/phantom/keystore", "system/keystore/src",
        # v0.24.0 Device Lock / Authentication Manager
        "system/auth/include/phantom/auth", "system/auth/src",
        # v0.25.0 Network / Connectivity Manager
        "system/network/include/phantom/network", "system/network/src",
        # v0.26.0 Power Manager
        "system/power/include/phantom/power", "system/power/src",
        # v0.27.0 Clipboard Manager
        "system/clipboard/include/phantom/clipboard", "system/clipboard/src",
        # v0.28.0 Location Manager
        "system/location/include/phantom/location", "system/location/src",
        # v0.29.0 Sensor Manager
        "system/sensor/include/phantom/sensor", "system/sensor/src",
        "system/camera/include/phantom/camera", "system/camera/src",
    ]

    def test_required_directories_exist(self):
        for d in self.REQUIRED_DIRS:
            full_path = os.path.join(PROJECT_ROOT, d)
            self.assertTrue(
                os.path.isdir(full_path),
                f"Directory '{d}' does not exist"
            )


class TestPhantomOSFiles(unittest.TestCase):
    """Test that all required files exist."""

    REQUIRED_FILES = [
        "README.md", "TODO.md", "Erledigt.md", "Getestet.md",
        "install.md", "LICENSE", "CMakeLists.txt",
    ]

    def test_required_files_exist(self):
        for f in self.REQUIRED_FILES:
            full_path = os.path.join(PROJECT_ROOT, f)
            self.assertTrue(
                os.path.isfile(full_path),
                f"File '{f}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"File '{f}' is empty"
            )


class TestPhantomOSDocumentation(unittest.TestCase):
    """Test that all required documentation files exist."""

    REQUIRED_DOCS = [
        "docs/architecture.md",
        "docs/hardware-iphone-x.md",
        "docs/privacy.md",
        "docs/privacy-architecture.md",
        "docs/data-flows.md",
        "docs/threat-model.md",
        "docs/security-architecture.md",
        "docs/android-compatibility.md",
        "docs/google-play-compatibility.md",
        "docs/roadmap.md",
        "docs/phase-0-development-environment.md",
    ]

    def test_required_docs_exist(self):
        for doc in self.REQUIRED_DOCS:
            full_path = os.path.join(PROJECT_ROOT, doc)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Documentation '{doc}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Documentation '{doc}' is empty"
            )

    def test_architecture_has_required_sections(self):
        arch_path = os.path.join(PROJECT_ROOT, "docs/architecture.md")
        with open(arch_path, "r", encoding="utf-8") as f:
            content = f.read()

        required_sections = [
            "Overview", "System Architecture", "Kernel", "AOSP",
            "Android Runtime", "Phantom Framework", "Privacy Layer",
            "Security Layer", "Phantom HAL", "GUI", "App System",
            "Google Play", "Update System", "Hardware",
            "Data Flow", "Threat Model", "Privacy Model",
            "Development Environment", "Test Strategy",
            "Roadmap", "Risks"
        ]
        for section in required_sections:
            self.assertIn(
                section.lower(), content.lower(),
                f"Architecture document missing section: {section}"
            )


class TestPhantomOSCppComponents(unittest.TestCase):
    """Test that all v0.6.0 C++ components exist."""

    REQUIRED_CPP_FILES = [
        "hal/include/phantom/hal/hal_types.h",
        "hal/include/phantom/hal/hal_interfaces.h",
        "hal/mock/mock_hal.cpp",
        "hal/mock/mock_hal_factory.h",
        "framework/include/phantom/service.h",
        "framework/include/phantom/service_manager.h",
        "framework/src/service_manager.cpp",
        "libraries/privacy/include/phantom/privacy/permission.h",
        "libraries/privacy/src/permission.cpp",
        "libraries/privacy/include/phantom/privacy/permission_manager.h",
        "libraries/privacy/src/permission_manager.cpp",
        "libraries/privacy/include/phantom/privacy/identity_manager.h",
        "libraries/privacy/src/identity_manager.cpp",
        "libraries/privacy/include/phantom/privacy/data_sanitizer.h",
        "libraries/privacy/src/data_sanitizer.cpp",
        "system/src/mock_runtime.cpp",
        # v0.3.0 GUI components
        "gui/include/phantom/gui/geometry.h",
        "gui/include/phantom/gui/color.h",
        "gui/include/phantom/gui/framebuffer.h",
        "gui/src/framebuffer.cpp",
        "gui/include/phantom/gui/surface.h",
        "gui/src/surface.cpp",
        "gui/include/phantom/gui/window.h",
        "gui/src/window.cpp",
        "gui/include/phantom/gui/window_manager.h",
        "gui/src/window_manager.cpp",
        "gui/include/phantom/gui/compositor.h",
        "gui/src/compositor.cpp",
        "gui/include/phantom/gui/input_dispatcher.h",
        "gui/src/input_dispatcher.cpp",
        # v0.4.0 GUI components
        "gui/include/phantom/gui/bitmap_font.h",
        "gui/src/bitmap_font.cpp",
        "gui/include/phantom/gui/widget.h",
        "gui/src/widget.cpp",
        "gui/include/phantom/gui/layout.h",
        "gui/src/layout.cpp",
        "gui/include/phantom/gui/widgets/widgets.h",
        "gui/src/widgets/widgets.cpp",
        # v0.4.0 System libraries
        "libraries/config/include/phantom/config/config.h",
        "libraries/config/src/config.cpp",
        "libraries/i18n/include/phantom/i18n/localization.h",
        "libraries/i18n/src/localization.cpp",
        "libraries/uri/include/phantom/uri/uri_parser.h",
        "libraries/uri/src/uri_parser.cpp",
        "libraries/security/include/phantom/security/sandbox.h",
        "libraries/security/src/sandbox.cpp",
        # v0.5.0 GUI components
        "gui/include/phantom/gui/multi_line_text.h",
        "gui/src/multi_line_text.cpp",
        "gui/include/phantom/gui/extended_layout.h",
        "gui/src/extended_layout.cpp",
        "gui/include/phantom/gui/widgets/extended_widgets.h",
        "gui/src/widgets/extended_widgets.cpp",
        # v0.6.0 GUI components
        "gui/include/phantom/gui/animation.h",
        "gui/src/animation.cpp",
        # v0.6.0 Theme System
        "gui/include/phantom/gui/theme.h",
        "gui/src/theme.cpp",
        # v0.7.0 Framework components
        "framework/include/phantom/app_lifecycle.h",
        "framework/src/app_lifecycle.cpp",
        # v0.7.0 IPC components
        "libraries/ipc/include/phantom/ipc/message.h",
        "libraries/ipc/include/phantom/ipc/message_bus.h",
        "libraries/ipc/src/message_bus.cpp",
    ]

    def test_cpp_components_exist(self):
        for f in self.REQUIRED_CPP_FILES:
            full_path = os.path.join(PROJECT_ROOT, f)
            self.assertTrue(
                os.path.isfile(full_path),
                f"C++ file '{f}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"C++ file '{f}' is empty"
            )


class TestPhantomOSTests(unittest.TestCase):
    """Test that all required test files exist."""

    REQUIRED_TESTS = [
        "tests/test_project_structure.py",
        "tests/unit/test_permission.cpp",
        "tests/unit/test_permission_manager.cpp",
        "tests/unit/test_identity.cpp",
        "tests/unit/test_data_sanitizer.cpp",
        "tests/unit/test_service_manager.cpp",
        "tests/unit/test_hal_mock.cpp",
        "tests/unit/test_gui_geometry.cpp",
        "tests/unit/test_framebuffer.cpp",
        "tests/unit/test_window_manager.cpp",
        "tests/unit/test_compositor.cpp",
        "tests/unit/test_input_dispatcher.cpp",
        # v0.4.0 tests
        "tests/unit/test_bitmap_font.cpp",
        "tests/unit/test_widgets.cpp",
        "tests/unit/test_layout.cpp",
        "tests/unit/test_config.cpp",
        "tests/unit/test_i18n.cpp",
        "tests/unit/test_uri.cpp",
        "tests/unit/test_sandbox.cpp",
        # v0.5.0 tests
        "tests/unit/test_multi_line_text.cpp",
        "tests/unit/test_extended_widgets.cpp",
        "tests/unit/test_extended_layouts.cpp",
        # v0.6.0 tests
        "tests/unit/test_animation.cpp",
        # v0.6.0 Theme System tests
        "tests/unit/test_theme.cpp",
        # v0.8.0 Package Manager components
        "libraries/package_manager/include/phantom/package_manager/package.h",
        "libraries/package_manager/include/phantom/package_manager/package_manager.h",
        "libraries/package_manager/src/package_manager.cpp",
        # v0.9.0 Linux Compatibility Layer components
        "libraries/linux_compat/include/phantom/linux_compat/linux_program.h",
        "libraries/linux_compat/include/phantom/linux_compat/program_executor.h",
        "libraries/linux_compat/src/program_executor.cpp",

        # v0.7.0 tests
        "tests/unit/test_app_lifecycle.cpp",
        "tests/unit/test_ipc.cpp",
        "tests/unit/test_package_manager.cpp",
        "tests/unit/test_linux_compat.cpp",
        # v0.10.0 Settings App components and test
        "apps/settings/include/phantom/settings/settings_app.h",
        "apps/settings/src/settings_app.cpp",
        "tests/unit/test_settings_app.cpp",
        # v0.11.0 Terminal App components and test
        "apps/terminal/include/phantom/terminal/terminal_app.h",
        "apps/terminal/src/terminal_app.cpp",
        "tests/unit/test_terminal_app.cpp",
        # v0.12.0 File Manager components and test
        "apps/filemanager/include/phantom/filemanager/file_manager.h",
        "apps/filemanager/src/file_manager.cpp",
        "tests/unit/test_file_manager.cpp",
        # v0.13.0 System Monitor components and test
        "apps/sysmon/include/phantom/sysmon/system_monitor.h",
        "apps/sysmon/src/system_monitor.cpp",
        "tests/unit/test_system_monitor.cpp",
        # v0.14.0 NIDS components and test
        "security/nids/include/phantom/nids/nids_engine.h",
        "security/nids/src/nids_engine.cpp",
        "tests/unit/test_nids_engine.cpp",
        # v0.15.0 System Server components and test
        "system/server/include/phantom/sysserver/system_server.h",
        "system/server/src/system_server.cpp",
        "tests/unit/test_system_server.cpp",
        # v0.16.0 Driver Framework components and test
        "drivers/framework/include/phantom/drivers/driver_manager.h",
        "drivers/framework/src/driver_manager.cpp",
        "tests/unit/test_driver_framework.cpp",
        # v0.17.0 Log Server components and test
        "system/logging/include/phantom/logging/log_server.h",
        "system/logging/src/log_server.cpp",
        "tests/unit/test_log_server.cpp",
        # v0.18.0 Notification Manager + v0.19.0 Crash Reporter + v0.20.0 Update Manager components and test
        "system/notifications/include/phantom/notifications/notification_manager.h",
        "system/notifications/src/notification_manager.cpp",
        "system/crashreporter/include/phantom/crashreporter/crash_reporter.h",
        "system/crashreporter/src/crash_reporter.cpp",
        "system/updatemanager/include/phantom/updatemanager/update_manager.h",
        "system/updatemanager/src/update_manager.cpp",
        # v0.21.0 Backup & Restore Manager components
        "system/backup/include/phantom/backup/backup_manager.h",
        "system/backup/src/backup_manager.cpp",
        # v0.22.0 Recovery Mode Manager
        "system/recovery/include/phantom/recovery/recovery_manager.h",
        "system/recovery/src/recovery_manager.cpp",
        # v0.23.0 KeyStore / Crypto Service
        "system/keystore/include/phantom/keystore/keystore_manager.h",
        "system/keystore/src/keystore_manager.cpp",
        # v0.24.0 Device Lock / Authentication Manager
        "system/auth/include/phantom/auth/auth_manager.h",
        "system/auth/src/auth_manager.cpp",
        # v0.25.0 Network / Connectivity Manager
        "system/network/include/phantom/network/network_manager.h",
        "system/network/src/network_manager.cpp",
        # v0.26.0 Power Manager
        "system/power/include/phantom/power/power_manager.h",
        "system/power/src/power_manager.cpp",
        # v0.27.0 Clipboard Manager
        "system/clipboard/include/phantom/clipboard/clipboard_manager.h",
        "system/clipboard/src/clipboard_manager.cpp",
        # v0.28.0 Location Manager
        "system/location/include/phantom/location/location_manager.h",
        "system/location/src/location_manager.cpp",
        # v0.29.0 Sensor Manager
        "system/sensor/include/phantom/sensor/sensor_manager.h",
        "system/sensor/src/sensor_manager.cpp",
        "system/camera/include/phantom/camera/camera_manager.h",
        "system/camera/src/camera_manager.cpp",
        "tests/unit/test_notification_manager.cpp",
        "tests/unit/test_crash_reporter.cpp",
        "tests/unit/test_update_manager.cpp",
        # v0.21.0 Backup & Restore Manager test
        "tests/unit/test_backup_manager.cpp",
        # v0.22.0 Recovery Mode Manager
        "tests/unit/test_recovery_manager.cpp",
        # v0.23.0 KeyStore / Crypto Service
        "tests/unit/test_keystore_manager.cpp",
        # v0.24.0 Device Lock / Authentication Manager
        "tests/unit/test_auth_manager.cpp",
        # v0.25.0 Network / Connectivity Manager
        "tests/unit/test_network_manager.cpp",
        # v0.26.0 Power Manager
        "tests/unit/test_power_manager.cpp",
        # v0.27.0 Clipboard Manager
        "tests/unit/test_clipboard_manager.cpp",
        # v0.28.0 Location Manager
        "tests/unit/test_location_manager.cpp",
        # v0.29.0 Sensor Manager
        "tests/unit/test_sensor_manager.cpp",
        "tests/unit/test_camera_manager.cpp",
    ]

    def test_files_exist(self):
        for t in self.REQUIRED_TESTS:
            full_path = os.path.join(PROJECT_ROOT, t)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Test file '{t}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Test file '{t}' is empty"
            )


class TestPhantomOSTools(unittest.TestCase):
    """Test that all required tools exist."""

    REQUIRED_TOOLS = [
        "tools/validate_project.py",
        "tools/build.sh",
    ]

    def test_tools_exist(self):
        for t in self.REQUIRED_TOOLS:
            full_path = os.path.join(PROJECT_ROOT, t)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Tool '{t}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Tool '{t}' is empty"
            )


class TestPhantomOSHonestyMarkers(unittest.TestCase):
    """Test that honesty markers are used in documentation."""

    HONESTY_MARKERS = ["KNOWN", "UNKNOWN", "NEEDS RESEARCH",
                       "CURRENTLY NOT FEASIBLE", "BLOCKED"]

    def test_hardware_doc_uses_markers(self):
        hw_path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
        with open(hw_path, "r", encoding="utf-8") as f:
            content = f.read()
        found = any(marker in content for marker in self.HONESTY_MARKERS)
        self.assertTrue(
            found,
            "Hardware document should use honesty markers (KNOWN, UNKNOWN, etc.)"
        )


class TestPhantomOSCMakeBuildSystem(unittest.TestCase):
    """Test that CMake build system is properly configured."""

    def test_cmake_file_exists(self):
        cmake_path = os.path.join(PROJECT_ROOT, "CMakeLists.txt")
        self.assertTrue(os.path.isfile(cmake_path))

    def test_cmake_has_required_targets(self):
        cmake_path = os.path.join(PROJECT_ROOT, "CMakeLists.txt")
        with open(cmake_path, "r", encoding="utf-8") as f:
            content = f.read()

        required_targets = [
            "phantom_privacy", "phantom_framework", "phantom_hal_mock",
            "phantom_gui", "phantom_mock_runtime",
            "test_permission", "test_permission_manager",
            "test_identity", "test_data_sanitizer",
            "test_service_manager", "test_hal_mock",
            "test_gui_geometry", "test_framebuffer",
            "test_window_manager", "test_compositor",
            "test_input_dispatcher",
            # v0.4.0 targets
            "phantom_config", "phantom_i18n", "phantom_uri", "phantom_security",
            "test_bitmap_font", "test_widgets", "test_layout",
            "test_config", "test_i18n", "test_uri", "test_sandbox",
            # v0.5.0 targets
            "test_multi_line_text", "test_extended_widgets", "test_extended_layouts",
            # v0.6.0 targets
            "test_animation",
            # v0.6.0 Theme System target
            "test_theme",
            # v0.9.0 targets
            "phantom_linux_compat",
            "test_linux_compat",

            # v0.8.0 targets
            "phantom_package_manager",
            "test_package_manager",

            # v0.7.0 targets
            "phantom_ipc",
            "test_app_lifecycle",
            "test_ipc",
            # v0.10.0 targets
            "phantom_settings",
            "test_settings_app",
            # v0.11.0 targets
            "phantom_terminal",
            "test_terminal_app",
            # v0.12.0 targets
            "phantom_filemanager",
            "test_file_manager",
            # v0.13.0 targets
            "phantom_sysmon",
            "test_system_monitor",
            # v0.14.0 targets
            "phantom_nids",
            "test_nids_engine",
            # v0.15.0 targets
            "phantom_sysserver",
            "test_system_server",
            # v0.16.0 targets
            "phantom_drivers",
            "test_driver_framework",
            # v0.17.0 targets
            "phantom_logserver",
            "test_log_server",
            # v0.18.0 + v0.19.0 + v0.20.0 targets
            "phantom_notifications",
            "phantom_crashreporter",
            "phantom_updatemanager",
            "phantom_backup",
            "phantom_recovery",
            "phantom_keystore",
            "phantom_auth",
            "test_notification_manager",
            "test_crash_reporter",
            "test_update_manager",
            "test_backup_manager",
            "test_recovery_manager",
            "test_keystore_manager",
            "test_auth_manager",
            # v0.25.0 targets
            "phantom_network",
            "test_network_manager",
            # v0.26.0 targets
            "phantom_power",
            "test_power_manager",
            # v0.27.0 targets
            "phantom_clipboard",
            "test_clipboard_manager",
            # v0.28.0 targets
            "phantom_location",
            "test_location_manager",
            # v0.29.0 targets
            "phantom_sensor",
            "test_sensor_manager",
            "phantom_camera",
            "test_camera_manager",
        ]
        for target in required_targets:
            self.assertIn(
                target, content,
                f"CMakeLists.txt missing target: {target}"
            )


if __name__ == "__main__":
    unittest.main()
