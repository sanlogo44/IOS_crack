#!/usr/bin/env python3
"""
Phantom OS - Project Structure Validator v0.2.0

Validates project structure, required files, documentation,
and v0.2.0 C++ components.
"""

import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

REQUIRED_DIRS = [
    "android", "kernel", "boot", "hal", "drivers", "framework",
    "system", "gui", "apps", "libraries", "sdk", "tools", "tests", "docs",
    "framework/include/phantom", "framework/src",
    "libraries/privacy/include/phantom/privacy", "libraries/privacy/src",
    "hal/include/phantom/hal", "hal/mock",
    "system/src", "tests/unit",
    "gui/include/phantom/gui", "gui/src",
]

REQUIRED_FILES = [
    "README.md", "TODO.md", "Erledigt.md", "Getestet.md", "install.md", "LICENSE",
    "CMakeLists.txt",
]

REQUIRED_DOCS = [
    "docs/architecture.md",
    "docs/hardware-iphone-x.md",
    "docs/privacy.md",
    "docs/privacy-architecture.md",
    "docs/data-flows.md",
    "docs/threat-model.md",
    "docs/security-architecture.md",
    "docs/android-compatibility.md",
    "docs/google-play-compatibility.md",
    "docs/roadmap.md",
    "docs/phase-0-development-environment.md",
]

# v0.2.0 C++ components
REQUIRED_CPP_FILES = [
    "hal/include/phantom/hal/hal_types.h",
    "hal/include/phantom/hal/hal_interfaces.h",
    "hal/mock/mock_hal.cpp",
    "hal/mock/mock_hal_factory.h",
    "framework/include/phantom/service.h",
    "framework/include/phantom/service_manager.h",
    "framework/src/service_manager.cpp",
    "libraries/privacy/include/phantom/privacy/permission.h",
    "libraries/privacy/src/permission.cpp",
    "libraries/privacy/include/phantom/privacy/permission_manager.h",
    "libraries/privacy/src/permission_manager.cpp",
    "libraries/privacy/include/phantom/privacy/identity_manager.h",
    "libraries/privacy/src/identity_manager.cpp",
    "libraries/privacy/include/phantom/privacy/data_sanitizer.h",
    "libraries/privacy/src/data_sanitizer.cpp",
    "system/src/mock_runtime.cpp",
    # v0.3.0 GUI components
    "gui/include/phantom/gui/geometry.h",
    "gui/include/phantom/gui/color.h",
    "gui/include/phantom/gui/framebuffer.h",
    "gui/src/framebuffer.cpp",
    "gui/include/phantom/gui/surface.h",
    "gui/src/surface.cpp",
    "gui/include/phantom/gui/window.h",
    "gui/src/window.cpp",
    "gui/include/phantom/gui/window_manager.h",
    "gui/src/window_manager.cpp",
    "gui/include/phantom/gui/compositor.h",
    "gui/src/compositor.cpp",
    "gui/include/phantom/gui/input_dispatcher.h",
    "gui/src/input_dispatcher.cpp",
]

REQUIRED_TESTS = [
    "tests/test_project_structure.py",
    "tests/unit/test_permission.cpp",
    "tests/unit/test_permission_manager.cpp",
    "tests/unit/test_identity.cpp",
    "tests/unit/test_data_sanitizer.cpp",
    "tests/unit/test_service_manager.cpp",
    "tests/unit/test_hal_mock.cpp",
    "tests/unit/test_gui_geometry.cpp",
    "tests/unit/test_framebuffer.cpp",
    "tests/unit/test_window_manager.cpp",
    "tests/unit/test_compositor.cpp",
    "tests/unit/test_input_dispatcher.cpp",
]

REQUIRED_TOOLS = [
    "tools/validate_project.py",
    "tools/build.sh",
]

ARCH_REQUIRED_SECTIONS = [
    "Overview", "System Architecture", "Kernel", "AOSP", "Android Runtime",
    "Phantom Framework", "Privacy Layer", "Security Layer", "Phantom HAL",
    "GUI", "App System", "Google Play", "Update System", "Hardware",
    "Data Flow", "Threat Model", "Privacy Model", "Development Environment",
    "Test Strategy", "Roadmap", "Risks",
]


def check_directory_exists(path):
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isdir(full_path):
        return True, f"  [PASS] Directory: {path}"
    else:
        return False, f"  [FAIL] Directory missing: {path}"


def check_file_exists(path):
    full_path = os.path.join(PROJECT_ROOT, path)
    if os.path.isfile(full_path):
        size = os.path.getsize(full_path)
        if size > 0:
            return True, f"  [PASS] File ({size}B): {path}"
        else:
            return False, f"  [FAIL] File empty: {path}"
    else:
        return False, f"  [FAIL] File missing: {path}"


def check_doc_sections(path, required_sections):
    full_path = os.path.join(PROJECT_ROOT, path)
    if not os.path.isfile(full_path):
        return False, f"  [FAIL] Document missing: {path}"
    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()
    missing = [s for s in required_sections if s.lower() not in content.lower()]
    if missing:
        return False, f"  [FAIL] {path} missing: {', '.join(missing)}"
    else:
        return True, f"  [PASS] {path} has all required sections"


def main():
    print("=" * 60)
    print("  Phantom OS v0.3.0 - Project Validation")
    print("=" * 60)
    print()

    all_passed = True
    errors = []

    # Directories
    print("Checking directories...")
    for d in REQUIRED_DIRS:
        passed, msg = check_directory_exists(d)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing directory: {d}")
    print()

    # Required files
    print("Checking required files...")
    for f in REQUIRED_FILES:
        passed, msg = check_file_exists(f)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing file: {f}")
    print()

    # Documentation
    print("Checking documentation...")
    for doc in REQUIRED_DOCS:
        passed, msg = check_file_exists(doc)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing doc: {doc}")
    print()

    # C++ components
    print("Checking C++ components (v0.3.0)...")
    for f in REQUIRED_CPP_FILES:
        passed, msg = check_file_exists(f)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing C++ file: {f}")
    print()

    # Architecture sections
    print("Checking architecture document sections...")
    passed, msg = check_doc_sections("docs/architecture.md", ARCH_REQUIRED_SECTIONS)
    print(msg)
    if not passed:
        all_passed = False
        errors.append("Architecture doc missing sections")
    print()

    # Tests
    print("Checking test files...")
    for t in REQUIRED_TESTS:
        passed, msg = check_file_exists(t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing test: {t}")
    print()

    # Tools
    print("Checking tools...")
    for t in REQUIRED_TOOLS:
        passed, msg = check_file_exists(t)
        print(msg)
        if not passed:
            all_passed = False
            errors.append(f"Missing tool: {t}")
    print()

    # Summary
    print("=" * 60)
    if all_passed:
        print("  RESULT: ALL CHECKS PASSED")
    else:
        print(f"  RESULT: {len(errors)} ERRORS FOUND")
        for e in errors:
            print(f"    - {e}")
    print("=" * 60)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
