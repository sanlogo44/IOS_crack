# Phantom OS – TODO

**Letztes Update:** 2026-09-19  
**Version:** 0.3.0

---

## Projekt-Tracking

### v0.3.0 — GUI Framework — ABGESCHLOSSEN ✓

- [x] GUI Geometry (Point, Size, Rect)
- [x] GUI Color (RGBA, Alpha-Blending)
- [x] Framebuffer (CPU-backed, fillRect, blit, blitBlended)
- [x] Surface (Offscreen-Zeichenfläche, Z-Order, Opazität)
- [x] Window (Metadaten, State, Flags, Backing-Surface)
- [x] Window Manager (Lifecycle, Z-Order, Fokus, Hit-Test)
- [x] Compositor (Software, Offscreen, Alpha-Blending)
- [x] Input Dispatcher (Touch-Routing, Event-Queue)
- [x] 35 Unit-Tests (5 Test-Suiten, 100% PASS)
- [x] CMake-Build-System um GUI erweitert
- [x] ZIP erstellt und validiert

### v0.4.0 — Nächste Schritte (AUSSTEHEND)

- [ ] Widget Toolkit (Button, Label, TextField, ListView)
- [ ] Layout-System (LinearLayout, FrameLayout)
- [ ] Text-Rendering (Bitmap-Font, grundlegend)
- [ ] App Sandbox System (seccomp-bpf)
- [ ] Property-Based Configuration System
- [ ] Custom URI Scheme (phapp://)
- [ ] Lokalisierung-System (Deutsch, Englisch)
- [ ] AOSP Environment Vorbereitung (BLOCKIERT — 64GB RAM, 400GB Disk)

### Phase 1: AOSP Setup (BLOCKIERT — Physische Ressourcen erforderlich)

- [ ] Debian/Ubuntu Linux PC einrichten (64GB RAM, 400GB Disk)
- [ ] AOSP Source Download (~150GB)
- [ ] Build-Umgebung konfigurieren (ccache, Java, Python)
- [ ] Kali Linux 2-VM Setup für Network Intrusion Detection
- [ ] Treiber-Dokumentation für iPhone X erstellen
- [ ] Hardware-Verifizierung dokumentieren

### Phase 2: Jailbreak und Boot (NEEDS RESEARCH)

- [ ] checkm8 Boot ROM Exploit dokumentieren
- [ ] postmarketOS Cross-compile Toolchain einrichten
- [ ] Treiber für Wi-Fi, Bluetooth, GPU testen
- [ ] Boot-Strategie evaluieren (Boot ROM vs Side-Loaded)
- [ ] GMS-Lizenzing-Kosten recherchieren (ausstehend)
- [ ] Kernel Support Status für iPhone X (needs verification)
- [ ] GPU- und Display-Treiber Status für iPhone X (needs verification)

### Phase 3+: Kernel & Treiber

- [ ] ARM64 Kernel Compilation mit ccache
- [ ] Treiber für Wi-Fi (Broadcom), Bluetooth, Modem, Audio, GPU, Display, USB, Power
- [ ] SEP-Interface dokumentieren (Secure Enclave Processor)
- [ ] Face ID / Touch ID Evaluierung (möglicherweise CURRENTLY NOT FEASIBLE)
- [ ] Init-System für Phantom OS

### Phase 5+: Framework & System

- [ ] System Server / Init Process
- [ ] Inter-Process Communication (IPC)
- [ ] Package Manager / Installer
- [ ] Security Sandbox Implementation
- [ ] Network Intrusion Detection System

### Phase 7+: GUI Erweiterung & Apps

- [ ] Widget Toolkit (Button, Label, TextField, ListView)
- [ ] Layout-System (LinearLayout, FrameLayout)
- [ ] Text-Rendering (Bitmap-Font)
- [ ] Settings App
- [ ] Phone App (Telefon/Anruf)
- [ ] Wi-Fi Settings
- [ ] Bluetooth Settings
- [ ] Camera App
- [ ] Media Player
- [ ] Web Browser
- [ ] Terminal

### Phase 10+: Hardware Verifizierung

- [ ] Physisches iPhone X Testgerät beschaffen
- [ ] Boot Test mit checkm8
- [ ] Display Ausgabe Test
- [ ] Touch Input Test
- [ ] Wi-Fi Connectivity Test
- [ ] Bluetooth Test
- [ ] Audio Test
- [ ] Kamera Test
- [ ] GPS Test
- [ ] Modem/LTE Test
- [ ] Face ID / SEP Test

### Phase 12+: Update & Recovery

- [ ] Update-System (OTA / Local / Emergency)
- [ ] Recovery-Modus
- [ ] Rollback-Mechanismus
- [ ] Backup & Restore

### Phase 13: Google Play & Zertifizierung

- [ ] GMS-Lizenz beantragen (ausstehend — Preis konnte nicht verifiziert werden)
- [ ] MLO-Pflichtklassen implementieren (Remote Notification, Cloud Messaging, etc.)
- [ ] Hardware-Security-Modul integrieren (Trusty TEE)
- [ ] SafetyNet Attestation
- [ ] Play Integrity API
- [ ] CTS Tests durchführen
- [ ] Google MLO Review
- [ ] Google Play Account erstellen ($25)

### Phase 15: Final Release

- [ ] Alle Tests bestanden
- [ ] GPL-3.0 Lizenz finalisiert
- [ ] Build-System vollständig dokumentiert
- [ ] Installationsanleitung finalisiert
- [ ] Recovery-Modus getestet
- [ ] Öffentliche Veröffentlichung

---

## Ungeklärte Fragen / BLOCKIERT

- [ ] GMS-Lizenzierungsbedingungen und Kosten (konnten nicht verifiziert werden — MUST RESEARCH)
- [ ] Apple Watch / Apple TV Unterstützung (spätere Phase)
- [ ] Project Sandcastle als Boot-Strategie für iPhone X (ONLY FOR iPhone 7/7+)
- [ ] Kernel Support Status für iPhone X (needs verification)
- [ ] GPU- und Display-Treiber Status für iPhone X (needs verification)
- [ ] AOSP Build in Sandbox (BLOCKIERT — 64GB RAM, 400GB Disk erforderlich)
