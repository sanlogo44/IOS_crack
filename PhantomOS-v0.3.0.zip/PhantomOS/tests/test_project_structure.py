#!/usr/bin/env python3
"""
Phantom OS - Project Structure Tests v0.2.0
"""

import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestPhantomOSDirectories(unittest.TestCase):
    """Test that all required directories exist."""

    REQUIRED_DIRS = [
        "android", "kernel", "boot", "hal", "drivers", "framework",
        "system", "gui", "apps", "libraries", "sdk", "tools", "tests", "docs",
        "framework/include/phantom", "framework/src",
        "libraries/privacy/include/phantom/privacy", "libraries/privacy/src",
        "hal/include/phantom/hal", "hal/mock",
        "system/src", "tests/unit",
        "gui/include/phantom/gui", "gui/src",
    ]

    def test_required_directories_exist(self):
        for d in self.REQUIRED_DIRS:
            full_path = os.path.join(PROJECT_ROOT, d)
            self.assertTrue(
                os.path.isdir(full_path),
                f"Directory '{d}' does not exist"
            )


class TestPhantomOSFiles(unittest.TestCase):
    """Test that all required files exist."""

    REQUIRED_FILES = [
        "README.md", "TODO.md", "Erledigt.md", "Getestet.md",
        "install.md", "LICENSE", "CMakeLists.txt",
    ]

    def test_required_files_exist(self):
        for f in self.REQUIRED_FILES:
            full_path = os.path.join(PROJECT_ROOT, f)
            self.assertTrue(
                os.path.isfile(full_path),
                f"File '{f}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"File '{f}' is empty"
            )


class TestPhantomOSDocumentation(unittest.TestCase):
    """Test that all required documentation files exist."""

    REQUIRED_DOCS = [
        "docs/architecture.md",
        "docs/hardware-iphone-x.md",
        "docs/privacy.md",
        "docs/privacy-architecture.md",
        "docs/data-flows.md",
        "docs/threat-model.md",
        "docs/security-architecture.md",
        "docs/android-compatibility.md",
        "docs/google-play-compatibility.md",
        "docs/roadmap.md",
        "docs/phase-0-development-environment.md",
    ]

    def test_required_docs_exist(self):
        for doc in self.REQUIRED_DOCS:
            full_path = os.path.join(PROJECT_ROOT, doc)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Documentation '{doc}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Documentation '{doc}' is empty"
            )

    def test_architecture_has_required_sections(self):
        arch_path = os.path.join(PROJECT_ROOT, "docs/architecture.md")
        with open(arch_path, "r", encoding="utf-8") as f:
            content = f.read()

        required_sections = [
            "Overview", "System Architecture", "Kernel", "AOSP",
            "Android Runtime", "Phantom Framework", "Privacy Layer",
            "Security Layer", "Phantom HAL", "GUI", "App System",
            "Google Play", "Update System", "Hardware",
            "Data Flow", "Threat Model", "Privacy Model",
            "Development Environment", "Test Strategy",
            "Roadmap", "Risks"
        ]
        for section in required_sections:
            self.assertIn(
                section.lower(), content.lower(),
                f"Architecture document missing section: {section}"
            )


class TestPhantomOSCppComponents(unittest.TestCase):
    """Test that all v0.2.0 C++ components exist."""

    REQUIRED_CPP_FILES = [
        "hal/include/phantom/hal/hal_types.h",
        "hal/include/phantom/hal/hal_interfaces.h",
        "hal/mock/mock_hal.cpp",
        "hal/mock/mock_hal_factory.h",
        "framework/include/phantom/service.h",
        "framework/include/phantom/service_manager.h",
        "framework/src/service_manager.cpp",
        "libraries/privacy/include/phantom/privacy/permission.h",
        "libraries/privacy/src/permission.cpp",
        "libraries/privacy/include/phantom/privacy/permission_manager.h",
        "libraries/privacy/src/permission_manager.cpp",
        "libraries/privacy/include/phantom/privacy/identity_manager.h",
        "libraries/privacy/src/identity_manager.cpp",
        "libraries/privacy/include/phantom/privacy/data_sanitizer.h",
        "libraries/privacy/src/data_sanitizer.cpp",
        "system/src/mock_runtime.cpp",
        "gui/include/phantom/gui/geometry.h",
        "gui/include/phantom/gui/color.h",
        "gui/include/phantom/gui/framebuffer.h",
        "gui/src/framebuffer.cpp",
        "gui/include/phantom/gui/surface.h",
        "gui/src/surface.cpp",
        "gui/include/phantom/gui/window.h",
        "gui/src/window.cpp",
        "gui/include/phantom/gui/window_manager.h",
        "gui/src/window_manager.cpp",
        "gui/include/phantom/gui/compositor.h",
        "gui/src/compositor.cpp",
        "gui/include/phantom/gui/input_dispatcher.h",
        "gui/src/input_dispatcher.cpp",
    ]

    def test_cpp_components_exist(self):
        for f in self.REQUIRED_CPP_FILES:
            full_path = os.path.join(PROJECT_ROOT, f)
            self.assertTrue(
                os.path.isfile(full_path),
                f"C++ file '{f}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"C++ file '{f}' is empty"
            )


class TestPhantomOSTests(unittest.TestCase):
    """Test that all required test files exist."""

    REQUIRED_TESTS = [
        "tests/test_project_structure.py",
        "tests/unit/test_permission.cpp",
        "tests/unit/test_permission_manager.cpp",
        "tests/unit/test_identity.cpp",
        "tests/unit/test_data_sanitizer.cpp",
        "tests/unit/test_service_manager.cpp",
        "tests/unit/test_hal_mock.cpp",
        "tests/unit/test_gui_geometry.cpp",
        "tests/unit/test_framebuffer.cpp",
        "tests/unit/test_window_manager.cpp",
        "tests/unit/test_compositor.cpp",
        "tests/unit/test_input_dispatcher.cpp",
    ]

    def test_files_exist(self):
        for t in self.REQUIRED_TESTS:
            full_path = os.path.join(PROJECT_ROOT, t)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Test file '{t}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Test file '{t}' is empty"
            )


class TestPhantomOSTools(unittest.TestCase):
    """Test that all required tools exist."""

    REQUIRED_TOOLS = [
        "tools/validate_project.py",
        "tools/build.sh",
    ]

    def test_tools_exist(self):
        for t in self.REQUIRED_TOOLS:
            full_path = os.path.join(PROJECT_ROOT, t)
            self.assertTrue(
                os.path.isfile(full_path),
                f"Tool '{t}' does not exist"
            )
            self.assertGreater(
                os.path.getsize(full_path), 0,
                f"Tool '{t}' is empty"
            )


class TestPhantomOSHonestyMarkers(unittest.TestCase):
    """Test that honesty markers are used in documentation."""

    HONESTY_MARKERS = ["KNOWN", "UNKNOWN", "NEEDS RESEARCH",
                       "CURRENTLY NOT FEASIBLE", "BLOCKED"]

    def test_hardware_doc_uses_markers(self):
        hw_path = os.path.join(PROJECT_ROOT, "docs/hardware-iphone-x.md")
        with open(hw_path, "r", encoding="utf-8") as f:
            content = f.read()
        found = any(marker in content for marker in self.HONESTY_MARKERS)
        self.assertTrue(
            found,
            "Hardware document should use honesty markers (KNOWN, UNKNOWN, etc.)"
        )


class TestPhantomOSCMakeBuildSystem(unittest.TestCase):
    """Test that CMake build system is properly configured."""

    def test_cmake_file_exists(self):
        cmake_path = os.path.join(PROJECT_ROOT, "CMakeLists.txt")
        self.assertTrue(os.path.isfile(cmake_path))

    def test_cmake_has_required_targets(self):
        cmake_path = os.path.join(PROJECT_ROOT, "CMakeLists.txt")
        with open(cmake_path, "r", encoding="utf-8") as f:
            content = f.read()

        required_targets = [
            "phantom_privacy", "phantom_framework", "phantom_hal_mock",
            "phantom_gui", "phantom_mock_runtime",
            "test_permission", "test_permission_manager",
            "test_identity", "test_data_sanitizer",
            "test_service_manager", "test_hal_mock",
            "test_gui_geometry", "test_framebuffer",
            "test_window_manager", "test_compositor",
            "test_input_dispatcher",
        ]
        for target in required_targets:
            self.assertIn(
                target, content,
                f"CMakeLists.txt missing target: {target}"
            )


if __name__ == "__main__":
    unittest.main()
