# Phantom OS

**Sichere, datenschutzorientierte Android-basierte Plattform — Für iPhone X (A11 SoC)**

**Version:** 0.2.0 — Framework Prototype + Privacy Core  
**Lizenz:** GPL-3.0  
**Status:** Framework-Prototyp mit funktionsfähigem Privacy Layer, HAL-Interfaces und Mock Runtime  
**Entwicklungsphase:** Phase 0 abgeschlossen, Phase 1 (AOSP Setup) BLOCKIERT

---

## Was ist Phantom OS?

Phantom OS ist ein Android-basiertes Betriebssystem, das mit maximaler Datenschutz-Sicherheit, minimaler Telemetrie und kompletter lokaler Kontrolle entwickelt wird. Das Projekt zielt darauf ab, eine funktionsfähige Android-Plattform auf einem iPhone X (A11 SoC) bereitzustellen — unter Einhaltung der Android Compatibility Definition Document (CDD) und der GPL-3.0-Lizenz.

## Aktueller Status (v0.2.0)

### Abgeschlossen:
- Vollständige Systemarchitektur (21 Sektionen)
- Threat Model und Privacy-Architektur
- iPhone X Hardware-Analyse mit Status-Markern
- Framework: Service Manager (Lifecycle, Priority, Health-Check)
- Privacy Layer: Permission Manager (Default-Deny, 15 Berechtigungen, 5 Grant-Typen)
- Privacy Layer: Identity Manager (App-spezifische IDs, Hardware-ID-Schutz)
- Privacy Layer: Data Sanitizer (Location-Approximation, Metadaten-Entfernung)
- HAL: Interfaces für alle Hardware-Komponenten
- HAL: Mock-Implementierungen (iPhone X Simulation)
- Mock Runtime: Demonstriert Framework + Privacy + HAL
- CMake Build-System
- 49 Unit-Tests (6 Test-Suiten, alle PASS)
- 11 Python-Projektstruktur-Tests (alle PASS)

### Blockiert:
- AOSP Source Setup (benötigt 64GB RAM, 400GB Disk)
- Physische Hardware-Tests (iPhone X Testgerät erforderlich)

## Schnellstart

```bash
# 1. Build
cd PhantomOS
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . -j$(nproc)

# 2. Tests ausführen
ctest --output-on-failure

# 3. Mock Runtime starten
./bin/phantom_mock_runtime

# 4. Projektstruktur validieren
python3 ../tools/validate_project.py
python3 ../tests/test_project_structure.py
```

## Projektstruktur

```
PhantomOS/
├── android/              # AOSP Source (leer — Phase 1)
├── boot/                 # Bootloader und Boot ROM Exploit (leer)
├── kernel/               # ARM64 Kernel Source (leer — Phase 3)
├── hal/                  # Hardware Abstraction Layer
│   ├── include/phantom/hal/   # HAL Interfaces
│   └── mock/                 # Mock-Implementierungen
├── framework/            # Phantom OS Framework
│   ├── include/phantom/      # Service Manager
│   └── src/                  # Implementierung
├── libraries/privacy/    # Privacy Layer
│   ├── include/phantom/privacy/  # Permission, Identity, Data Sanitizer
│   └── src/                       # Implementierung
├── system/               # System Runtime
│   └── src/                  # Mock Runtime
├── gui/                  # GUI Framework (leer — Phase 7)
├── apps/                 # Anwendungen (leer — Phase 7+)
├── drivers/              # Hardware-Treiber (leer — Phase 3+)
├── sdk/                  # Developer SDK (leer)
├── tools/                # Build- und Test-Tools
├── tests/                # Unit Tests
│   ├── unit/                 # C++ Unit Tests
│   └── test_project_structure.py  # Python Struktur-Tests
├── docs/                 # Architektur und Dokumentation
├── CMakeLists.txt        # CMake Build-System
├── README.md             # Diese Datei
├── install.md            # Installationsanleitung
├── TODO.md               # Aufgaben-Tracker
├── Erledigt.md           # Abgeschlossene Aufgaben
├── Getestet.md           # Testergebnisse
└── LICENSE               # GPL-3.0
```

## Schlüsselkomponenten

### Phantom Framework
Service Manager mit Lifecycle-Management (CREATED → STARTING → RUNNING → STOPPING → STOPPED), Prioritätsbasierter Start-Reihenfolge (CRITICAL > HIGH > NORMAL > LOW), Health-Checks und State-Change-Callbacks.

### Privacy Layer
- **Permission Manager:** Default-Deny mit 15 Berechtigungstypen, 5 Grant-Typen (ALLOW_ONCE, ALLOW_10_MIN, ALLOW_WHILE_USING, ALLOW_ALWAYS, DENY), zeitlich begrenzte Grants, Privacy-Profile (Normal, Privacy, Maximum, Developer, Custom), Location-Approximation (Precise → Approximate → City → Region → Country → None).
- **Identity Manager:** App-spezifische Identifikatoren (keine globalen Geräte-IDs), Hardware-ID-Schutz (IMEI, MAC, Seriennummer standardmäßig DENIED).
- **Data Sanitizer:** Metadaten-Entfernung (GPS, Geräteinfo, Kamera-Metadaten etc.), Location-Approximation auf 6 Genauigkeitsstufen.

### HAL (Hardware Abstraction Layer)
Saubere C++ Interfaces für Display, Input, Storage, Network, Sensors, Camera, Audio, Power. Mock-Implementierungen simulieren iPhone X Hardware (2436x1125 OLED, 458 DPI, 64GB NVMe, Wi-Fi 6, Bluetooth 5.0, A11 Bionic SoC).

## Architektur-Dokumentation

Die vollständige Architektur-Dokumentation befindet sich unter `docs/architecture.md` mit folgenden Sektionen:

1. Overview — 2. System Architecture — 3. Kernel — 4. AOSP — 5. Android Runtime — 6. Phantom Framework — 7. Privacy Layer — 8. Security Layer — 9. Phantom HAL — 10. GUI — 11. App System — 12. Google Play — 13. Update System — 14. Hardware — 15. Data Flow — 16. Threat Model — 17. Privacy Model — 18. Development Environment — 19. Test Strategy — 20. Roadmap — 21. Risks

Weitere Dokumentation:
- `docs/privacy.md` — Datenschutz-Dokumentation
- `docs/privacy-architecture.md` — Privacy Layer Architektur
- `docs/threat-model.md` — Bedrohungsmodell
- `docs/security-architecture.md` — Sicherheitsarchitektur
- `docs/hardware-iphone-x.md` — iPhone X Hardware-Analyse
- `docs/android-compatibility.md` — Android-Kompatibilität
- `docs/google-play-compatibility.md` — Google Play Assessment
- `docs/data-flows.md` — Datenflüsse
- `docs/roadmap.md` — Entwicklungs-Roadmap
- `docs/phase-0-development-environment.md` — Phase 0 Entwicklungsumgebung

## Datenschutz

Phantom OS folgt dem Prinzip: **So wenig persönliche Daten wie möglich erfassen, speichern und weitergeben.**

- Keine Telemetrie standardmäßig
- Keine automatischen Absturzberichte standardmäßig
- Keine Cloud-Analyse standardmäßig
- Kein Tracking standardmäßig
- Hardware-IDs (IMEI, MAC, Seriennummer) werden standardmäßig nicht an Apps weitergegeben
- App-spezifische Identifikatoren statt globaler Geräte-IDs
- Location-Approximation je nach Privacy-Profil
- Metadaten-Entfernung aus Mediendateien

Siehe `docs/privacy.md` und `docs/privacy-architecture.md` für Details.

## Lizenz

Phantom OS ist unter der GNU General Public License v3.0 (GPL-3.0) lizenziert. Siehe `LICENSE` für den vollständigen Lizenztext.
