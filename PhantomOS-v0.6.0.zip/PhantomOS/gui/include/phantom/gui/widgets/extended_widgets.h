/*
 * Phantom OS - Extended GUI Widgets
 * CheckBox, RadioButton, ProgressBar, Slider
 *
 * License: GPL-3.0
 */

#pragma once

#include "phantom/gui/widget.h"
#include "phantom/gui/bitmap_font.h"
#include "phantom/gui/framebuffer.h"
#include "phantom/gui/multi_line_text.h"
#include <string>
#include <functional>
#include <vector>

namespace phantom::gui {

// ============================================================
// CheckBox: toggle widget with checkmark
// ============================================================
class CheckBox : public Widget {
public:
    using ChangeCallback = std::function<void(bool checked)>;

    CheckBox() = default;
    CheckBox(WidgetId id, const std::string& label = "");

    const std::string& getLabel() const { return label_; }
    void setLabel(const std::string& label) { label_ = label; }

    bool isChecked() const { return checked_; }
    void setChecked(bool checked);

    Color getTextColor() const { return textColor_; }
    void setTextColor(const Color& c) { textColor_ = c; }

    Color getBoxColor() const { return boxColor_; }
    void setBoxColor(const Color& c) { boxColor_ = c; }

    Color getCheckColor() const { return checkColor_; }
    void setCheckColor(const Color& c) { checkColor_ = c; }

    void setOnChange(const ChangeCallback& cb) { onChange_ = cb; }

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    bool onTouchUp(int32_t x, int32_t y) override;

private:
    std::string label_;
    bool checked_ = false;
    bool pressed_ = false;
    Color textColor_ = Color::White;
    Color boxColor_ = Color::LightGray;
    Color checkColor_ = Color::Green;
    ChangeCallback onChange_;

    static const int32_t BOX_SIZE = 9;  // 7px + 2px border
    static const int32_t BOX_PADDING = 2;

    void toggle();
};

// ============================================================
// RadioButton: radio button with group support
// ============================================================
class RadioButton : public Widget {
public:
    using ChangeCallback = std::function<void(int32_t radioButtonId, bool selected)>;

    RadioButton() = default;
    RadioButton(WidgetId id, const std::string& label = "", int32_t groupId = 0);
    ~RadioButton() override { unregisterRadioButton(this); }

    const std::string& getLabel() const { return label_; }
    void setLabel(const std::string& label) { label_ = label; }

    bool isSelected() const { return selected_; }
    void setSelected(bool selected);

    int32_t getGroupId() const { return groupId_; }
    void setGroupId(int32_t id) { groupId_ = id; }

    Color getTextColor() const { return textColor_; }
    void setTextColor(const Color& c) { textColor_ = c; }

    Color getCircleColor() const { return circleColor_; }
    void setCircleColor(const Color& c) { circleColor_ = c; }

    Color getDotColor() const { return dotColor_; }
    void setDotColor(const Color& c) { dotColor_ = c; }

    void setOnChange(const ChangeCallback& cb) { onChange_ = cb; }

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    bool onTouchUp(int32_t x, int32_t y) override;

    // Static group management: only one radio button per group can be selected
    static void registerRadioButton(RadioButton* rb);
    static void unregisterRadioButton(RadioButton* rb);
    static void selectInGroup(int32_t groupId, int32_t radioButtonId);

private:
    std::string label_;
    bool selected_ = false;
    bool pressed_ = false;
    int32_t groupId_ = 0;
    Color textColor_ = Color::White;
    Color circleColor_ = Color::LightGray;
    Color dotColor_ = Color::Blue;
    ChangeCallback onChange_;

    static const int32_t CIRCLE_RADIUS = 4;
    static const int32_t DOT_RADIUS = 2;

    static std::vector<RadioButton*> registeredButtons_;
};

// ============================================================
// ProgressBar: horizontal or vertical progress indicator
// ============================================================
class ProgressBar : public Widget {
public:
    enum class Orientation {
        HORIZONTAL = 0,
        VERTICAL = 1,
    };

    ProgressBar() = default;
    ProgressBar(WidgetId id, int32_t min = 0, int32_t max = 100, int32_t value = 0);

    int32_t getMin() const { return min_; }
    void setMin(int32_t min) { min_ = min; clampValue(); }

    int32_t getMax() const { return max_; }
    void setMax(int32_t max) { max_ = max; clampValue(); }

    int32_t getValue() const { return value_; }
    void setValue(int32_t value);

    Orientation getOrientation() const { return orientation_; }
    void setOrientation(Orientation o) { orientation_ = o; }

    bool isIndeterminate() const { return indeterminate_; }
    void setIndeterminate(bool ind) { indeterminate_ = ind; }

    Color getBackgroundColor() const { return bgColor_; }
    void setBackgroundColor(const Color& c) { bgColor_ = c; }

    Color getFillColor() const { return fillColor_; }
    void setFillColor(const Color& c) { fillColor_ = c; }

    Color getBorderColor() const { return borderColor_; }
    void setBorderColor(const Color& c) { borderColor_ = c; }

    // Get progress as percentage (0-100)
    int32_t getPercentage() const;

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;

private:
    int32_t min_ = 0;
    int32_t max_ = 100;
    int32_t value_ = 0;
    Orientation orientation_ = Orientation::HORIZONTAL;
    bool indeterminate_ = false;
    Color bgColor_ = Color::DarkGray;
    Color fillColor_ = Color::Green;
    Color borderColor_ = Color::LightGray;

    void clampValue();
    int32_t range() const { return max_ - min_; }
};

// ============================================================
// Slider: draggable value selector
// ============================================================
class Slider : public Widget {
public:
    using ChangeCallback = std::function<void(int32_t value)>;

    Slider() = default;
    Slider(WidgetId id, int32_t min = 0, int32_t max = 100, int32_t value = 50);

    int32_t getMin() const { return min_; }
    void setMin(int32_t min) { min_ = min; clampValue(); }

    int32_t getMax() const { return max_; }
    void setMax(int32_t max) { max_ = max; clampValue(); }

    int32_t getValue() const { return value_; }
    void setValue(int32_t value);

    int32_t getThumbSize() const { return thumbSize_; }
    void setThumbSize(int32_t s) { thumbSize_ = s; }

    Color getTrackColor() const { return trackColor_; }
    void setTrackColor(const Color& c) { trackColor_ = c; }

    Color getThumbColor() const { return thumbColor_; }
    void setThumbColor(const Color& c) { thumbColor_ = c; }

    Color getFillColor() const { return fillColor_; }
    void setFillColor(const Color& c) { fillColor_ = c; }

    void setOnChange(const ChangeCallback& cb) { onChange_ = cb; }

    // Convert a pixel position to a value
    int32_t positionToValue(int32_t x) const;
    // Convert a value to thumb pixel position
    int32_t valueToPosition() const;

    Size onMeasure() const override;
    void onRender(Framebuffer& fb, const BitmapFont& font) const override;
    bool onTouchDown(int32_t x, int32_t y) override;
    bool onTouchMove(int32_t x, int32_t y) override;
    bool onTouchUp(int32_t x, int32_t y) override;

private:
    int32_t min_ = 0;
    int32_t max_ = 100;
    int32_t value_ = 50;
    int32_t thumbSize_ = 5;  // Half-width of thumb
    bool dragging_ = false;
    Color trackColor_ = Color::DarkGray;
    Color thumbColor_ = Color::White;
    Color fillColor_ = Color::Blue;
    ChangeCallback onChange_;

    void clampValue();
    int32_t range() const { return max_ - min_; }
};

}  // namespace phantom::gui
