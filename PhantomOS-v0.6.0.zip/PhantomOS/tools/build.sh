#!/bin/bash
# Phantom OS - Build Script
# Builds all Phantom OS components and runs tests
#
# License: GPL-3.0

set -e

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build"

echo "=== Phantom OS Build Script ==="
echo "Project root: $PROJECT_ROOT"
echo "Build dir: $BUILD_DIR"
echo ""

# Check for CMake
if ! command -v cmake &> /dev/null; then
    echo "ERROR: cmake not found. Please install cmake."
    echo "  sudo apt-get install cmake"
    exit 1
fi

# Check for C++ compiler
if ! command -v g++ &> /dev/null; then
    echo "ERROR: g++ not found. Please install build-essential."
    echo "  sudo apt-get install build-essential"
    exit 1
fi

# Create build directory
mkdir -p "$BUILD_DIR"

# Configure
echo "[1/3] Configuring build..."
cd "$BUILD_DIR"
cmake "$PROJECT_ROOT" -DCMAKE_BUILD_TYPE=Release

# Build
echo ""
echo "[2/3] Building..."
cmake --build . -j$(nproc)

# Run tests
echo ""
echo "[3/3] Running tests..."
ctest --output-on-failure

echo ""
echo "=== Build complete ==="
echo "Binaries in: $BUILD_DIR/bin/"
echo "Tests passed: see above"
